00000000001c0400 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_clause 0x1                                               // 0000001C0400: BF850001
	s_load_b128 s[12:15], s[0:1], 0x20                         // 0000001C0404: F4080300 F8000020
	s_load_b128 s[24:27], s[0:1], 0x38                         // 0000001C040C: F4080600 F8000038
	s_mov_b32 s20, s3                                          // 0000001C0414: BE940003
	s_ashr_i32 s3, s2, 31                                      // 0000001C0418: 86039F02
	s_waitcnt lgkmcnt(0)                                       // 0000001C041C: BF89FC07
	s_load_b32 s6, s[14:15], null                              // 0000001C0420: F4000187 F8000000
	s_load_b32 s29, s[0:1], 0x48                               // 0000001C0428: F4000740 F8000048
	s_lshl_b64 s[4:5], s[2:3], 2                               // 0000001C0430: 84848202
	s_waitcnt lgkmcnt(0)                                       // 0000001C0434: BF89FC07
	s_add_i32 s3, s6, s2                                       // 0000001C0438: 81030206
	s_add_u32 s14, s26, s4                                     // 0000001C043C: 800E041A
	s_addc_u32 s15, s27, s5                                    // 0000001C0440: 820F051B
	s_load_b256 s[4:11], s[0:1], null                          // 0000001C0444: F40C0100 F8000000
	s_load_b32 s1, s[14:15], null                              // 0000001C044C: F4000047 F8000000
	s_add_i32 s16, s3, 1                                       // 0000001C0454: 81108103
	s_mul_hi_i32 s15, s29, s2                                  // 0000001C0458: 970F021D
	s_ashr_i32 s0, s16, 31                                     // 0000001C045C: 86009F10
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001C0460: BF870499
	s_lshr_b32 s0, s0, 30                                      // 0000001C0464: 85009E00
	s_add_i32 s0, s16, s0                                      // 0000001C0468: 81000010
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001C046C: BF870499
	s_and_b32 s14, s0, -4                                      // 0000001C0470: 8B0EC400
	s_sub_i32 s16, s3, s14                                     // 0000001C0474: 81900E03
	s_ashr_i32 s3, s0, 2                                       // 0000001C0478: 86038200
	s_cmp_gt_i32 s16, -1                                       // 0000001C047C: BF02C110
	s_mul_i32 s14, s29, s2                                     // 0000001C0480: 960E021D
	s_cselect_b32 s17, -1, 0                                   // 0000001C0484: 981180C1
	s_lshl_b64 s[14:15], s[14:15], 2                           // 0000001C0488: 848E820E
	s_mov_b32 s26, s3                                          // 0000001C048C: BE9A0003
	s_add_u32 s14, s24, s14                                    // 0000001C0490: 800E0E18
	s_addc_u32 s15, s25, s15                                   // 0000001C0494: 820F0F19
	s_and_b32 vcc_lo, exec_lo, s17                             // 0000001C0498: 8B6A117E
	s_cbranch_vccnz 11                                         // 0000001C049C: BFA4000B <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xcc>
	s_waitcnt lgkmcnt(0)                                       // 0000001C04A0: BF89FC07
	s_max_i32 s18, s1, 1                                       // 0000001C04A4: 8A128101
	s_mov_b32 s19, 0                                           // 0000001C04A8: BE930080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001C04AC: BF870499
	s_lshl_b64 s[18:19], s[18:19], 2                           // 0000001C04B0: 84928212
	s_add_u32 s0, s14, s18                                     // 0000001C04B4: 8000120E
	s_addc_u32 s19, s15, s19                                   // 0000001C04B8: 8213130F
	s_add_u32 s18, s0, -4                                      // 0000001C04BC: 8012C400
	s_addc_u32 s19, s19, -1                                    // 0000001C04C0: 8213C113
	s_load_b32 s26, s[18:19], null                             // 0000001C04C4: F4000689 F8000000
	v_lshrrev_b32_e32 v7, 5, v0                                // 0000001C04CC: 320E0085
	s_mov_b32 s18, exec_lo                                     // 0000001C04D0: BE92007E
	v_cmpx_gt_u32_e32 0x180, v0                                // 0000001C04D4: 7D9800FF 00000180
	s_cbranch_execz 61                                         // 0000001C04DC: BFA5003D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1d4>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001C04E0: BF870002
	v_mul_u32_u24_e32 v1, 0x210, v7                            // 0000001C04E4: 16020EFF 00000210
	v_and_b32_e32 v2, 31, v0                                   // 0000001C04EC: 3604009F
	s_mul_i32 s22, s20, 0xc00                                  // 0000001C04F0: 9616FF14 00000C00
	s_mul_i32 s19, s2, 0x3000                                  // 0000001C04F8: 9613FF02 00003000
	s_ashr_i32 s23, s22, 31                                    // 0000001C0500: 86179F16
	s_mul_hi_i32 s0, s2, 0x3000                                // 0000001C0504: 9700FF02 00003000
	s_lshl_b64 s[22:23], s[22:23], 1                           // 0000001C050C: 84968116
	v_lshl_add_u32 v4, v2, 4, v1                               // 0000001C0510: D6460004 04050902
	v_lshlrev_b32_e32 v1, 4, v0                                // 0000001C0518: 30020084
	s_waitcnt lgkmcnt(0)                                       // 0000001C051C: BF89FC07
	s_add_u32 s4, s4, s22                                      // 0000001C0520: 80041604
	s_addc_u32 s5, s5, s23                                     // 0000001C0524: 82051705
	s_add_u32 s4, s4, s19                                      // 0000001C0528: 80041304
	s_addc_u32 s0, s5, s0                                      // 0000001C052C: 82000005
	.long 0xd7000401                                           // 0000001C0530: D7000401
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000001C0534: 02020204
	v_lshl_or_b32 v3, v0, 3, 0xfffffe00                        // 0000001C0538: D6560003 03FD0700 FFFFFE00
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 0000001C0544: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 0000001C054C: BE840080
	s_nop 0                                                    // 0000001C0550: BF800000
	s_nop 0                                                    // 0000001C0554: BF800000
	s_nop 0                                                    // 0000001C0558: BF800000
	s_nop 0                                                    // 0000001C055C: BF800000
	s_nop 0                                                    // 0000001C0560: BF800000
	s_nop 0                                                    // 0000001C0564: BF800000
	s_nop 0                                                    // 0000001C0568: BF800000
	s_nop 0                                                    // 0000001C056C: BF800000
	s_nop 0                                                    // 0000001C0570: BF800000
	s_nop 0                                                    // 0000001C0574: BF800000
	s_nop 0                                                    // 0000001C0578: BF800000
	s_nop 0                                                    // 0000001C057C: BF800000
	global_load_b128 v[8:11], v[1:2], off                      // 0000001C0580: DC5E0000 087C0001
	v_add_nc_u32_e32 v3, 0x200, v3                             // 0000001C0588: 4A0606FF 00000200
	.long 0xd7006a01                                           // 0000001C0590: D7006A01
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001C0594: 020202FF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C059C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000001C05A0: D5207C02 01AA0480
	.long 0xd4490000                                           // 0000001C05A8: D4490000
	v_cndmask_b32_e32 v1, 0x9ff, v3, vcc_lo                    // 0000001C05AC: 020206FF 000009FF
	s_or_b32 s4, s0, s4                                        // 0000001C05B4: 8C040400
	s_waitcnt vmcnt(0)                                         // 0000001C05B8: BF8903F7
	ds_store_b128 v4, v[8:11] offset:1024                      // 0000001C05BC: DB7C0400 00000804
	v_add_nc_u32_e32 v4, 0x420, v4                             // 0000001C05C4: 4A0808FF 00000420
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001C05CC: 917E047E
	s_cbranch_execnz 65515                                     // 0000001C05D0: BFA6FFEB <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x180>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000001C05D4: 8C7E127E
	v_cndmask_b32_e64 v1, 0, 1, s17                            // 0000001C05D8: D5010001 00450280
	v_lshlrev_b32_e32 v174, 7, v7                              // 0000001C05E0: 315C0E87
	s_waitcnt lgkmcnt(0)                                       // 0000001C05E4: BF89FC07
	s_barrier                                                  // 0000001C05E8: BFBD0000
	buffer_gl0_inv                                             // 0000001C05EC: E0AC0000 00000000
	v_readfirstlane_b32 s0, v1                                 // 0000001C05F4: 7E000501
	s_add_i32 s27, s1, s0                                      // 0000001C05F8: 811B0001
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001C05FC: BF870499
	s_add_i32 s0, s27, 3                                       // 0000001C0600: 8100831B
	s_ashr_i32 s28, s0, 2                                      // 0000001C0604: 861C8200
	s_mov_b32 s0, 0                                            // 0000001C0608: BE800080
	s_cmp_gt_i32 s28, 0                                        // 0000001C060C: BF02801C
	s_cbranch_scc1 2                                           // 0000001C0610: BFA20002 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x21c>
	v_lshlrev_b32_e32 v8, 7, v7                                // 0000001C0614: 30100E87
	s_branch 1                                                 // 0000001C0618: BFA00001 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x220>
	s_mov_b32 s0, -1                                           // 0000001C061C: BE8000C1
	v_mov_b32_e32 v38, 0                                       // 0000001C0620: 7E4C0280
	v_and_b32_e32 v172, 15, v0                                 // 0000001C0624: 3758008F
	v_bfe_u32 v173, v0, 4, 1                                   // 0000001C0628: D61000AD 02050900
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000001C0630: 916A007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C0634: BF870003
	v_mov_b32_e32 v37, v38                                     // 0000001C0638: 7E4A0326
	v_mov_b32_e32 v36, v38                                     // 0000001C063C: 7E480326
	v_mov_b32_e32 v35, v38                                     // 0000001C0640: 7E460326
	v_mov_b32_e32 v34, v38                                     // 0000001C0644: 7E440326
	v_mov_b32_e32 v33, v38                                     // 0000001C0648: 7E420326
	v_mov_b32_e32 v46, v38                                     // 0000001C064C: 7E5C0326
	v_mov_b32_e32 v45, v38                                     // 0000001C0650: 7E5A0326
	v_mov_b32_e32 v44, v38                                     // 0000001C0654: 7E580326
	v_mov_b32_e32 v43, v38                                     // 0000001C0658: 7E560326
	v_mov_b32_e32 v42, v38                                     // 0000001C065C: 7E540326
	v_mov_b32_e32 v41, v38                                     // 0000001C0660: 7E520326
	v_mov_b32_e32 v54, v38                                     // 0000001C0664: 7E6C0326
	v_mov_b32_e32 v53, v38                                     // 0000001C0668: 7E6A0326
	v_mov_b32_e32 v52, v38                                     // 0000001C066C: 7E680326
	v_mov_b32_e32 v51, v38                                     // 0000001C0670: 7E660326
	v_mov_b32_e32 v50, v38                                     // 0000001C0674: 7E640326
	v_mov_b32_e32 v49, v38                                     // 0000001C0678: 7E620326
	v_mov_b32_e32 v62, v38                                     // 0000001C067C: 7E7C0326
	v_mov_b32_e32 v61, v38                                     // 0000001C0680: 7E7A0326
	v_mov_b32_e32 v60, v38                                     // 0000001C0684: 7E780326
	v_mov_b32_e32 v59, v38                                     // 0000001C0688: 7E760326
	v_mov_b32_e32 v58, v38                                     // 0000001C068C: 7E740326
	v_mov_b32_e32 v57, v38                                     // 0000001C0690: 7E720326
	v_mov_b32_e32 v30, v38                                     // 0000001C0694: 7E3C0326
	v_mov_b32_e32 v29, v38                                     // 0000001C0698: 7E3A0326
	v_mov_b32_e32 v28, v38                                     // 0000001C069C: 7E380326
	v_mov_b32_e32 v27, v38                                     // 0000001C06A0: 7E360326
	v_mov_b32_e32 v26, v38                                     // 0000001C06A4: 7E340326
	v_mov_b32_e32 v25, v38                                     // 0000001C06A8: 7E320326
	v_mov_b32_e32 v22, v38                                     // 0000001C06AC: 7E2C0326
	v_mov_b32_e32 v21, v38                                     // 0000001C06B0: 7E2A0326
	v_mov_b32_e32 v20, v38                                     // 0000001C06B4: 7E280326
	v_mov_b32_e32 v19, v38                                     // 0000001C06B8: 7E260326
	v_mov_b32_e32 v18, v38                                     // 0000001C06BC: 7E240326
	v_mov_b32_e32 v17, v38                                     // 0000001C06C0: 7E220326
	v_mov_b32_e32 v14, v38                                     // 0000001C06C4: 7E1C0326
	v_mov_b32_e32 v13, v38                                     // 0000001C06C8: 7E1A0326
	v_mov_b32_e32 v12, v38                                     // 0000001C06CC: 7E180326
	v_mov_b32_e32 v11, v38                                     // 0000001C06D0: 7E160326
	v_mov_b32_e32 v10, v38                                     // 0000001C06D4: 7E140326
	v_mov_b32_e32 v9, v38                                      // 0000001C06D8: 7E120326
	v_mov_b32_e32 v6, v38                                      // 0000001C06DC: 7E0C0326
	v_mov_b32_e32 v5, v38                                      // 0000001C06E0: 7E0A0326
	v_mov_b32_e32 v4, v38                                      // 0000001C06E4: 7E080326
	v_mov_b32_e32 v3, v38                                      // 0000001C06E8: 7E060326
	v_mov_b32_e32 v2, v38                                      // 0000001C06EC: 7E040326
	v_mov_b32_e32 v1, v38                                      // 0000001C06F0: 7E020326
	v_mov_b32_e32 v91, v38                                     // 0000001C06F4: 7EB60326
	v_mov_b32_e32 v170, v38                                    // 0000001C06F8: 7F540326
	v_mov_b32_e32 v90, v38                                     // 0000001C06FC: 7EB40326
	v_mov_b32_e32 v171, v38                                    // 0000001C0700: 7F560326
	v_mov_b32_e32 v89, v38                                     // 0000001C0704: 7EB20326
	v_mov_b32_e32 v169, v38                                    // 0000001C0708: 7F520326
	s_cbranch_vccnz 1253                                       // 0000001C070C: BFA404E5 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x16a4>
	s_ashr_i32 s21, s20, 31                                    // 0000001C0710: 86159F14
	s_lshl2_add_u32 s0, s1, s16                                // 0000001C0714: 87801001
	v_dual_mov_b32 v184, 0xf149f2ca :: v_dual_lshlrev_b32 v3, 10, v7// 0000001C0718: CA2200FF B8020E8A F149F2CA
	s_lshl_b64 s[4:5], s[20:21], 11                            // 0000001C0724: 84848B14
	s_add_i32 s29, s29, -4                                     // 0000001C0728: 811DC41D
	s_add_i32 s30, s0, 1                                       // 0000001C072C: 811E8100
	v_dual_mov_b32 v169, 0 :: v_dual_lshlrev_b32 v0, 5, v0     // 0000001C0730: CA220080 A9000085
	s_add_u32 s0, s6, s4                                       // 0000001C0738: 80000406
	s_addc_u32 s4, s7, s5                                      // 0000001C073C: 82040507
	.long 0xd7000005                                           // 0000001C0740: D7000005
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000001C0744: 02020600
	v_cmp_gt_u32_e32 vcc_lo, 12, v172                          // 0000001C0748: 7C99588C
	s_load_b128 s[16:19], s[14:15], null                       // 0000001C074C: F4080407 F8000000
	v_add_co_ci_u32_e64 v6, null, s4, 0, s0                    // 0000001C0754: D5207C06 00010004
	s_lshl_b64 s[4:5], s[20:21], 8                             // 0000001C075C: 84848814
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001C0760: BF8701B9
	v_dual_mov_b32 v182, s5 :: v_dual_lshlrev_b32 v1, 2, v172  // 0000001C0764: CA220005 B6015882
	v_dual_mov_b32 v65, 0 :: v_dual_lshlrev_b32 v4, 9, v7      // 0000001C076C: CA220080 41040E89
	v_and_b32_e32 v0, 0x60, v0                                 // 0000001C0774: 360000FF 00000060
	v_lshl_or_b32 v1, v173, 6, v1                              // 0000001C077C: D6560001 04050DAD
	v_cndmask_b32_e32 v2, 0, v172, vcc_lo                      // 0000001C0784: 02055880
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001C0788: BF8700B4
	v_dual_mov_b32 v71, v65 :: v_dual_lshlrev_b32 v8, 1, v172  // 0000001C078C: CA220141 47095881
	v_mov_b32_e32 v67, v65                                     // 0000001C0794: 7E860341
	.long 0xd7000000                                           // 0000001C0798: D7000000
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 0000001C079C: 02020105
	v_add_co_ci_u32_e64 v176, null, 0, v6, s0                  // 0000001C07A0: D5207CB0 00020C80
	s_movk_i32 s0, 0x210                                       // 0000001C07A8: B0000210
	v_add_nc_u32_e32 v1, 0x1cc0, v1                            // 0000001C07AC: 4A0202FF 00001CC0
	v_xor_b32_e32 v5, 1, v7                                    // 0000001C07B4: 3A0A0E81
	v_dual_mov_b32 v69, v65 :: v_dual_lshlrev_b32 v6, 5, v173  // 0000001C07B8: CA220141 45075A85
	v_mad_u32_u24 v2, v2, s0, 0x400                            // 0000001C07C0: D60B0002 03FC0102 00000400
	v_dual_mov_b32 v66, v65 :: v_dual_lshlrev_b32 v7, 8, v7    // 0000001C07CC: CA220141 42060E88
	v_lshrrev_b32_e32 v175, 2, v172                            // 0000001C07D4: 335F5882
	v_dual_mov_b32 v186, 0xf149f2ca :: v_dual_add_nc_u32 v177, v1, v3// 0000001C07D8: CA2000FF BAB00701 F149F2CA
	v_lshl_add_u32 v178, v5, 10, v1                            // 0000001C07E4: D64600B2 04051505
	v_or3_b32 v179, v4, v6, v8                                 // 0000001C07EC: D65800B3 04220D04
	v_lshl_or_b32 v180, v172, 5, v4                            // 0000001C07F4: D65600B4 04110BAC
	v_or3_b32 v181, s4, v172, v174                             // 0000001C07FC: D65800B5 06BB5804
	v_dual_mov_b32 v68, v65 :: v_dual_add_nc_u32 v183, v2, v7  // 0000001C0804: CA200141 44B60F02
	v_dual_mov_b32 v70, v65 :: v_dual_mov_b32 v185, 0xf149f2ca // 0000001C080C: CA100141 46B800FF F149F2CA
	v_dual_mov_b32 v72, v65 :: v_dual_mov_b32 v187, 0xf149f2ca // 0000001C0818: CA100141 48BA00FF F149F2CA
	v_dual_mov_b32 v188, 0xf149f2ca :: v_dual_mov_b32 v189, 0xf149f2ca// 0000001C0824: CA1000FF BCBC00FF F149F2CA
	v_dual_mov_b32 v190, 0xf149f2ca :: v_dual_mov_b32 v89, 0   // 0000001C0830: CA1000FF BE580080 F149F2CA
	v_dual_mov_b32 v192, 0xf149f2ca :: v_dual_mov_b32 v171, 0  // 0000001C083C: CA1000FF C0AA0080 F149F2CA
	v_dual_mov_b32 v90, 0 :: v_dual_mov_b32 v91, 0             // 0000001C0848: CA100080 5A5A0080
	v_dual_mov_b32 v170, 0 :: v_dual_mov_b32 v191, 0           // 0000001C0850: CA100080 AABE0080
	v_dual_mov_b32 v193, 0 :: v_dual_mov_b32 v2, v169          // 0000001C0858: CA100080 C10201A9
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v4, v169            // 0000001C0860: CA100080 010401A9
	v_mov_b32_e32 v3, v169                                     // 0000001C0868: 7E0603A9
	v_mov_b32_e32 v5, v169                                     // 0000001C086C: 7E0A03A9
	v_dual_mov_b32 v6, v169 :: v_dual_mov_b32 v9, 0            // 0000001C0870: CA1001A9 06080080
	v_mov_b32_e32 v7, v169                                     // 0000001C0878: 7E0E03A9
	v_dual_mov_b32 v8, v169 :: v_dual_mov_b32 v17, 0           // 0000001C087C: CA1001A9 08100080
	v_dual_mov_b32 v10, v169 :: v_dual_mov_b32 v25, 0          // 0000001C0884: CA1001A9 0A180080
	v_mov_b32_e32 v11, v169                                    // 0000001C088C: 7E1603A9
	v_dual_mov_b32 v12, v169 :: v_dual_mov_b32 v57, 0          // 0000001C0890: CA1001A9 0C380080
	v_mov_b32_e32 v13, v169                                    // 0000001C0898: 7E1A03A9
	v_dual_mov_b32 v14, v169 :: v_dual_mov_b32 v49, 0          // 0000001C089C: CA1001A9 0E300080
	v_mov_b32_e32 v15, v169                                    // 0000001C08A4: 7E1E03A9
	v_dual_mov_b32 v16, v169 :: v_dual_mov_b32 v41, 0          // 0000001C08A8: CA1001A9 10280080
	v_dual_mov_b32 v18, v169 :: v_dual_mov_b32 v33, 0          // 0000001C08B0: CA1001A9 12200080
	v_mov_b32_e32 v19, v169                                    // 0000001C08B8: 7E2603A9
	v_mov_b32_e32 v20, v169                                    // 0000001C08BC: 7E2803A9
	v_mov_b32_e32 v21, v169                                    // 0000001C08C0: 7E2A03A9
	v_mov_b32_e32 v22, v169                                    // 0000001C08C4: 7E2C03A9
	v_mov_b32_e32 v23, v169                                    // 0000001C08C8: 7E2E03A9
	v_mov_b32_e32 v24, v169                                    // 0000001C08CC: 7E3003A9
	v_mov_b32_e32 v26, v169                                    // 0000001C08D0: 7E3403A9
	v_mov_b32_e32 v27, v169                                    // 0000001C08D4: 7E3603A9
	v_mov_b32_e32 v28, v169                                    // 0000001C08D8: 7E3803A9
	v_mov_b32_e32 v29, v169                                    // 0000001C08DC: 7E3A03A9
	v_mov_b32_e32 v30, v169                                    // 0000001C08E0: 7E3C03A9
	v_mov_b32_e32 v31, v169                                    // 0000001C08E4: 7E3E03A9
	v_mov_b32_e32 v32, v169                                    // 0000001C08E8: 7E4003A9
	v_mov_b32_e32 v58, v169                                    // 0000001C08EC: 7E7403A9
	v_mov_b32_e32 v59, v169                                    // 0000001C08F0: 7E7603A9
	v_mov_b32_e32 v60, v169                                    // 0000001C08F4: 7E7803A9
	v_mov_b32_e32 v61, v169                                    // 0000001C08F8: 7E7A03A9
	v_mov_b32_e32 v62, v169                                    // 0000001C08FC: 7E7C03A9
	v_mov_b32_e32 v63, v169                                    // 0000001C0900: 7E7E03A9
	v_mov_b32_e32 v64, v169                                    // 0000001C0904: 7E8003A9
	v_mov_b32_e32 v50, v169                                    // 0000001C0908: 7E6403A9
	v_mov_b32_e32 v51, v169                                    // 0000001C090C: 7E6603A9
	v_mov_b32_e32 v52, v169                                    // 0000001C0910: 7E6803A9
	v_mov_b32_e32 v53, v169                                    // 0000001C0914: 7E6A03A9
	v_mov_b32_e32 v54, v169                                    // 0000001C0918: 7E6C03A9
	v_mov_b32_e32 v55, v169                                    // 0000001C091C: 7E6E03A9
	v_mov_b32_e32 v56, v169                                    // 0000001C0920: 7E7003A9
	v_mov_b32_e32 v42, v169                                    // 0000001C0924: 7E5403A9
	v_mov_b32_e32 v43, v169                                    // 0000001C0928: 7E5603A9
	v_mov_b32_e32 v44, v169                                    // 0000001C092C: 7E5803A9
	v_mov_b32_e32 v45, v169                                    // 0000001C0930: 7E5A03A9
	v_mov_b32_e32 v46, v169                                    // 0000001C0934: 7E5C03A9
	v_mov_b32_e32 v47, v169                                    // 0000001C0938: 7E5E03A9
	v_mov_b32_e32 v48, v169                                    // 0000001C093C: 7E6003A9
	v_mov_b32_e32 v34, v169                                    // 0000001C0940: 7E4403A9
	v_mov_b32_e32 v35, v169                                    // 0000001C0944: 7E4603A9
	v_mov_b32_e32 v36, v169                                    // 0000001C0948: 7E4803A9
	v_mov_b32_e32 v37, v169                                    // 0000001C094C: 7E4A03A9
	v_mov_b32_e32 v38, v169                                    // 0000001C0950: 7E4C03A9
	v_mov_b32_e32 v39, v169                                    // 0000001C0954: 7E4E03A9
	v_mov_b32_e32 v40, v169                                    // 0000001C0958: 7E5003A9
	s_mov_b32 s21, 0                                           // 0000001C095C: BE950080
	v_cmp_eq_u32_e32 vcc_lo, 2, v175                           // 0000001C0960: 7C955E82
	s_branch 1051                                              // 0000001C0964: BFA0041B <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x15d4>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001C0968: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C096C: BF870099
	s_or_b32 exec_lo, exec_lo, s17                             // 0000001C0970: 8C7E117E
	v_ashrrev_i32_e32 v74, 31, v73                             // 0000001C0974: 3494929F
	s_ashr_i32 s17, s16, 31                                    // 0000001C0978: 86119F10
	s_ashr_i32 s23, s22, 31                                    // 0000001C097C: 86179F16
	s_lshl_b64 s[16:17], s[16:17], 9                           // 0000001C0980: 84908910
	s_ashr_i32 s19, s18, 31                                    // 0000001C0984: 86139F12
	.long 0xd73c0049                                           // 0000001C0988: D73C0049
	v_cndmask_b32_e32 v1, 12, v73, vcc_lo                      // 0000001C098C: 0202928C
	s_lshl_b64 s[22:23], s[22:23], 9                           // 0000001C0990: 84968916
	s_ashr_i32 s25, s24, 31                                    // 0000001C0994: 86199F18
	s_lshl_b64 s[18:19], s[18:19], 9                           // 0000001C0998: 84928912
	s_lshl_b64 s[24:25], s[24:25], 9                           // 0000001C099C: 84988918
	s_add_i32 s28, s28, -1                                     // 0000001C09A0: 811CC11C
	.long 0xd70000d5                                           // 0000001C09A4: D70000D5
	v_cndmask_b32_e32 v1, v0, v73, vcc_lo                      // 0000001C09A8: 02029300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C09AC: BF870001
	v_add_co_ci_u32_e64 v214, null, v176, v74, s0              // 0000001C09B0: D5207CD6 000295B0
	ds_load_b128 v[145:148], v183                              // 0000001C09B8: DBFC0000 910000B7
	ds_load_b128 v[149:152], v183 offset:16                    // 0000001C09C0: DBFC0010 950000B7
	ds_load_b128 v[197:200], v183 offset:32                    // 0000001C09C8: DBFC0020 C50000B7
	ds_load_b128 v[201:204], v183 offset:48                    // 0000001C09D0: DBFC0030 C90000B7
	ds_load_b128 v[77:80], v183 offset:80                      // 0000001C09D8: DBFC0050 4D0000B7
	ds_load_b128 v[73:76], v183 offset:64                      // 0000001C09E0: DBFC0040 490000B7
	ds_load_b128 v[85:88], v183 offset:112                     // 0000001C09E8: DBFC0070 550000B7
	ds_load_b128 v[81:84], v183 offset:96                      // 0000001C09F0: DBFC0060 510000B7
	ds_load_b128 v[93:96], v183 offset:144                     // 0000001C09F8: DBFC0090 5D0000B7
	ds_load_b128 v[89:92], v183 offset:128                     // 0000001C0A00: DBFC0080 590000B7
	ds_load_b128 v[101:104], v183 offset:176                   // 0000001C0A08: DBFC00B0 650000B7
	ds_load_b128 v[97:100], v183 offset:160                    // 0000001C0A10: DBFC00A0 610000B7
	ds_load_b128 v[117:120], v183 offset:208                   // 0000001C0A18: DBFC00D0 750000B7
	ds_load_b128 v[113:116], v183 offset:192                   // 0000001C0A20: DBFC00C0 710000B7
	ds_load_b128 v[125:128], v183 offset:240                   // 0000001C0A28: DBFC00F0 7D0000B7
	ds_load_b128 v[121:124], v183 offset:224                   // 0000001C0A30: DBFC00E0 790000B7
	s_clause 0x9                                               // 0000001C0A38: BF850009
	global_load_b128 v[133:136], v[213:214], off offset:16     // 0000001C0A3C: DC5E0010 857C00D5
	global_load_b128 v[129:132], v[213:214], off               // 0000001C0A44: DC5E0000 817C00D5
	global_load_b128 v[141:144], v[213:214], off offset:144    // 0000001C0A4C: DC5E0090 8D7C00D5
	global_load_b128 v[137:140], v[213:214], off offset:128    // 0000001C0A54: DC5E0080 897C00D5
	global_load_b128 v[209:212], v[213:214], off offset:272    // 0000001C0A5C: DC5E0110 D17C00D5
	global_load_b128 v[205:208], v[213:214], off offset:256    // 0000001C0A64: DC5E0100 CD7C00D5
	global_load_b128 v[165:168], v[213:214], off offset:400    // 0000001C0A6C: DC5E0190 A57C00D5
	global_load_b128 v[161:164], v[213:214], off offset:384    // 0000001C0A74: DC5E0180 A17C00D5
	global_load_b128 v[157:160], v[213:214], off offset:528    // 0000001C0A7C: DC5E0210 9D7C00D5
	global_load_b128 v[153:156], v[213:214], off offset:512    // 0000001C0A84: DC5E0200 997C00D5
	s_waitcnt vmcnt(8) lgkmcnt(0)                              // 0000001C0A8C: BF892007
	v_wmma_f32_16x16x16_bf16 v[105:112], v[145:152], v[129:136], v[65:72]// 0000001C0A90: CC414069 1D070391
	s_clause 0x3                                               // 0000001C0A98: BF850003
	global_load_b128 v[149:152], v[213:214], off offset:656    // 0000001C0A9C: DC5E0290 957C00D5
	global_load_b128 v[145:148], v[213:214], off offset:640    // 0000001C0AA4: DC5E0280 917C00D5
	global_load_b128 v[133:136], v[213:214], off offset:784    // 0000001C0AAC: DC5E0310 857C00D5
	global_load_b128 v[129:132], v[213:214], off offset:768    // 0000001C0AB4: DC5E0300 817C00D5
	s_waitcnt vmcnt(10)                                        // 0000001C0ABC: BF892BF7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[197:204], v[137:144], v[105:112]// 0000001C0AC0: CC414069 1DA713C5
	s_clause 0x1                                               // 0000001C0AC8: BF850001
	global_load_b128 v[141:144], v[213:214], off offset:912    // 0000001C0ACC: DC5E0390 8D7C00D5
	global_load_b128 v[137:140], v[213:214], off offset:896    // 0000001C0AD4: DC5E0380 897C00D5
	.long 0xd59c40c5                                           // 0000001C0ADC: D59C40C5
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 0000001C0AE0: 02010080
	s_waitcnt vmcnt(10)                                        // 0000001C0AE4: BF892BF7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[73:80], v[205:212], v[105:112]// 0000001C0AE8: CC414069 1DA79B49
	.long 0xd7000049                                           // 0000001C0AF0: D7000049
	v_cndmask_b32_e32 v1, s16, v181, vcc_lo                    // 0000001C0AF4: 02036A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001C0AF8: BF8701A1
	v_add_co_ci_u32_e64 v74, null, s17, v182, s0               // 0000001C0AFC: D5207C4A 00036C11
	s_waitcnt vmcnt(8)                                         // 0000001C0B04: BF8923F7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[81:88], v[161:168], v[105:112]// 0000001C0B08: CC414069 1DA74351
	.long 0xd700004b                                           // 0000001C0B10: D700004B
	v_cndmask_b32_e32 v1, s22, v181, vcc_lo                    // 0000001C0B14: 02036A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001C0B18: BF8701A1
	v_add_co_ci_u32_e64 v76, null, s23, v182, s0               // 0000001C0B1C: D5207C4C 00036C17
	s_waitcnt vmcnt(6)                                         // 0000001C0B24: BF891BF7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[89:96], v[153:160], v[105:112]// 0000001C0B28: CC414069 1DA73359
	.long 0xd700004d                                           // 0000001C0B30: D700004D
	v_cndmask_b32_e32 v1, s18, v181, vcc_lo                    // 0000001C0B34: 02036A12
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C0B38: BF870001
	v_add_co_ci_u32_e64 v78, null, s19, v182, s0               // 0000001C0B3C: D5207C4E 00036C13
	.long 0xd700004f                                           // 0000001C0B44: D700004F
	v_cndmask_b32_e32 v1, s24, v181, vcc_lo                    // 0000001C0B48: 02036A18
	.long 0xd73c0049                                           // 0000001C0B4C: D73C0049
	v_cndmask_b32_e32 v1, 3, v73, vcc_lo                       // 0000001C0B50: 02029283
	v_add_co_ci_u32_e64 v80, null, s25, v182, s0               // 0000001C0B54: D5207C50 00036C19
	.long 0xd73c004b                                           // 0000001C0B5C: D73C004B
	v_cndmask_b32_e32 v1, 3, v75, vcc_lo                       // 0000001C0B60: 02029683
	.long 0xd73c004d                                           // 0000001C0B64: D73C004D
	v_cndmask_b32_e32 v1, 3, v77, vcc_lo                       // 0000001C0B68: 02029A83
	.long 0xd59c485e                                           // 0000001C0B6C: D59C485E
	v_cndmask_b32_e32 v0, v197, v128, vcc_lo                   // 0000001C0B70: 020101C5
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C0B74: BF870004
	.long 0xd73c004f                                           // 0000001C0B78: D73C004F
	v_cndmask_b32_e32 v1, 3, v79, vcc_lo                       // 0000001C0B7C: 02029E83
	.long 0xd59c485d                                           // 0000001C0B80: D59C485D
	v_cndmask_b32_e32 v0, v197, v128, vcc_lo                   // 0000001C0B84: 020101C5
	.long 0xd59c485f                                           // 0000001C0B88: D59C485F
	v_cndmask_b32_e32 v0, v197, v128, vcc_lo                   // 0000001C0B8C: 020101C5
	.long 0xd59c4860                                           // 0000001C0B90: D59C4860
	v_cndmask_b32_e32 v0, v197, v128, vcc_lo                   // 0000001C0B94: 020101C5
	s_mov_b32 s19, s7                                          // 0000001C0B98: BE930007
	s_mov_b32 s18, s6                                          // 0000001C0B9C: BE920006
	s_mov_b32 s17, s5                                          // 0000001C0BA0: BE910005
	s_mov_b32 s16, s4                                          // 0000001C0BA4: BE900004
	s_waitcnt vmcnt(4)                                         // 0000001C0BA8: BF8913F7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[97:104], v[145:152], v[105:112]// 0000001C0BAC: CC414069 1DA72361
	s_waitcnt vmcnt(2)                                         // 0000001C0BB4: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C0BB8: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[105:112], v[113:120], v[129:136], v[105:112]// 0000001C0BBC: CC414069 1DA70371
	.long 0xd7000077                                           // 0000001C0BC4: D7000077
	v_cndmask_b32_e32 v1, s8, v73, vcc_lo                      // 0000001C0BC8: 02029208
	v_add_co_ci_u32_e64 v120, null, s9, v74, s0                // 0000001C0BCC: D5207C78 00029409
	s_waitcnt vmcnt(0)                                         // 0000001C0BD4: BF8903F7
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C0BD8: BF870003
	v_wmma_f32_16x16x16_bf16 v[105:112], v[121:128], v[137:144], v[105:112]// 0000001C0BDC: CC414069 1DA71379
	.long 0xd7000079                                           // 0000001C0BE4: D7000079
	v_cndmask_b32_e32 v1, s8, v75, vcc_lo                      // 0000001C0BE8: 02029608
	ds_store_2addr_b32 v177, v105, v106 offset1:32             // 0000001C0BEC: D8382000 006A69B1
	ds_store_2addr_b32 v177, v107, v108 offset0:64 offset1:96  // 0000001C0BF4: D8386040 006C6BB1
	ds_store_2addr_b32 v177, v109, v110 offset0:128 offset1:160// 0000001C0BFC: D838A080 006E6DB1
	ds_store_2addr_b32 v177, v111, v112 offset0:192 offset1:224// 0000001C0C04: D838E0C0 00706FB1
	v_add_co_ci_u32_e64 v122, null, s9, v76, s0                // 0000001C0C0C: D5207C7A 00029809
	.long 0xd700007b                                           // 0000001C0C14: D700007B
	v_cndmask_b32_e32 v1, s8, v77, vcc_lo                      // 0000001C0C18: 02029A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C0C1C: BF8700A1
	v_add_co_ci_u32_e64 v124, null, s9, v78, s0                // 0000001C0C20: D5207C7C 00029C09
	.long 0xd7000093                                           // 0000001C0C28: D7000093
	v_cndmask_b32_e32 v1, s8, v79, vcc_lo                      // 0000001C0C2C: 02029E08
	v_add_co_ci_u32_e64 v148, null, s9, v80, s0                // 0000001C0C30: D5207C94 0002A009
	.long 0xd4440000                                           // 0000001C0C38: D4440000
	v_cndmask_b32_e32 v1, s30, v172, vcc_lo                    // 0000001C0C3C: 0203581E
	s_add_i32 s30, s30, -16                                    // 0000001C0C40: 811ED01E
	s_cmp_lg_u32 s28, 0                                        // 0000001C0C44: BF07801C
	s_waitcnt lgkmcnt(0)                                       // 0000001C0C48: BF89FC07
	s_barrier                                                  // 0000001C0C4C: BFBD0000
	buffer_gl0_inv                                             // 0000001C0C50: E0AC0000 00000000
	ds_load_2addr_b32 v[81:82], v178 offset1:32                // 0000001C0C58: D8DC2000 510000B2
	ds_load_2addr_b32 v[83:84], v178 offset0:64 offset1:96     // 0000001C0C60: D8DC6040 530000B2
	ds_load_2addr_b32 v[85:86], v178 offset0:128 offset1:160   // 0000001C0C68: D8DCA080 550000B2
	ds_load_2addr_b32 v[87:88], v178 offset0:192 offset1:224   // 0000001C0C70: D8DCE0C0 570000B2
	s_waitcnt lgkmcnt(3)                                       // 0000001C0C78: BF89FC37
	v_dual_add_f32 v73, v106, v82 :: v_dual_add_f32 v74, v105, v81// 0000001C0C7C: C908A56A 494AA369
	s_waitcnt lgkmcnt(2)                                       // 0000001C0C84: BF89FC27
	v_dual_add_f32 v75, v108, v84 :: v_dual_add_f32 v76, v107, v83// 0000001C0C88: C908A96C 4B4CA76B
	s_waitcnt lgkmcnt(1)                                       // 0000001C0C90: BF89FC17
	v_dual_add_f32 v77, v110, v86 :: v_dual_add_f32 v78, v109, v85// 0000001C0C94: C908AD6E 4D4EAB6D
	v_dual_mul_f32 v73, 0x3d800000, v73 :: v_dual_mul_f32 v74, 0x3d800000, v74// 0000001C0C9C: C8C692FF 494A94FF 3D800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001C0CA8: BF8701B3
	v_dual_mul_f32 v75, 0x3d800000, v75 :: v_dual_mul_f32 v76, 0x3d800000, v76// 0000001C0CAC: C8C696FF 4B4C98FF 3D800000
	s_waitcnt lgkmcnt(0)                                       // 0000001C0CB8: BF89FC07
	v_dual_add_f32 v79, v112, v88 :: v_dual_add_f32 v80, v111, v87// 0000001C0CBC: C908B170 4F50AF6F
	v_cndmask_b32_e64 v73, 0xf149f2ca, v73, s0                 // 0000001C0CC4: D5010049 000292FF F149F2CA
	v_cndmask_b32_e64 v74, 0xf149f2ca, v74, s0                 // 0000001C0CD0: D501004A 000294FF F149F2CA
	v_dual_mul_f32 v77, 0x3d800000, v77 :: v_dual_mul_f32 v78, 0x3d800000, v78// 0000001C0CDC: C8C69AFF 4D4E9CFF 3D800000
	v_cndmask_b32_e64 v75, 0xf149f2ca, v75, s0                 // 0000001C0CE8: D501004B 000296FF F149F2CA
	v_cndmask_b32_e64 v76, 0xf149f2ca, v76, s0                 // 0000001C0CF4: D501004C 000298FF F149F2CA
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C0D00: BF870004
	v_mov_b32_dpp v81, v74 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0D04: 7EA202FA FF09614A
	v_mov_b32_dpp v82, v73 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0D0C: 7EA402FA FF096149
	v_dual_mul_f32 v79, 0x3d800000, v79 :: v_dual_mul_f32 v80, 0x3d800000, v80// 0000001C0D14: C8C69EFF 4F50A0FF 3D800000
	v_cndmask_b32_e64 v77, 0xf149f2ca, v77, s0                 // 0000001C0D20: D501004D 00029AFF F149F2CA
	v_cndmask_b32_e64 v78, 0xf149f2ca, v78, s0                 // 0000001C0D2C: D501004E 00029CFF F149F2CA
	v_mov_b32_dpp v83, v76 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0D38: 7EA602FA FF09614C
	v_mov_b32_dpp v84, v75 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0D40: 7EA802FA FF09614B
	v_dual_max_f32 v81, v81, v81 :: v_dual_max_f32 v82, v82, v82// 0000001C0D48: CA94A351 5152A552
	v_cndmask_b32_e64 v79, 0xf149f2ca, v79, s0                 // 0000001C0D50: D501004F 00029EFF F149F2CA
	v_cndmask_b32_e64 v80, 0xf149f2ca, v80, s0                 // 0000001C0D5C: D5010050 0002A0FF F149F2CA
	v_mov_b32_dpp v85, v78 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0D68: 7EAA02FA FF09614E
	v_mov_b32_dpp v86, v77 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0D70: 7EAC02FA FF09614D
	v_dual_max_f32 v83, v83, v83 :: v_dual_max_f32 v84, v84, v84// 0000001C0D78: CA94A753 5354A954
	v_dual_max_f32 v81, v74, v81 :: v_dual_max_f32 v82, v73, v82// 0000001C0D80: CA94A34A 5152A549
	v_mov_b32_dpp v87, v80 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0D88: 7EAE02FA FF096150
	v_mov_b32_dpp v88, v79 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0D90: 7EB002FA FF09614F
	v_dual_max_f32 v85, v85, v85 :: v_dual_max_f32 v86, v86, v86// 0000001C0D98: CA94AB55 5556AD56
	v_dual_max_f32 v83, v76, v83 :: v_dual_max_f32 v84, v75, v84// 0000001C0DA0: CA94A74C 5354A94B
	v_mov_b32_dpp v89, v81 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0DA8: 7EB202FA FF096251
	v_mov_b32_dpp v90, v82 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0DB0: 7EB402FA FF096252
	v_dual_max_f32 v87, v87, v87 :: v_dual_max_f32 v88, v88, v88// 0000001C0DB8: CA94AF57 5758B158
	v_dual_max_f32 v85, v78, v85 :: v_dual_max_f32 v86, v77, v86// 0000001C0DC0: CA94AB4E 5556AD4D
	v_mov_b32_dpp v91, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0DC8: 7EB602FA FF096253
	v_mov_b32_dpp v92, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0DD0: 7EB802FA FF096254
	v_dual_max_f32 v89, v89, v89 :: v_dual_max_f32 v90, v90, v90// 0000001C0DD8: CA94B359 595AB55A
	v_dual_max_f32 v87, v80, v87 :: v_dual_max_f32 v88, v79, v88// 0000001C0DE0: CA94AF50 5758B14F
	v_mov_b32_dpp v97, v85 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0DE8: 7EC202FA FF096255
	v_mov_b32_dpp v98, v86 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0DF0: 7EC402FA FF096256
	v_dual_max_f32 v91, v91, v91 :: v_dual_max_f32 v92, v92, v92// 0000001C0DF8: CA94B75B 5B5CB95C
	v_dual_max_f32 v81, v81, v89 :: v_dual_max_f32 v82, v82, v90// 0000001C0E00: CA94B351 5152B552
	v_mov_b32_dpp v99, v87 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0E08: 7EC602FA FF096257
	v_mov_b32_dpp v100, v88 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0E10: 7EC802FA FF096258
	v_dual_max_f32 v97, v97, v97 :: v_dual_max_f32 v98, v98, v98// 0000001C0E18: CA94C361 6162C562
	v_dual_max_f32 v83, v83, v91 :: v_dual_max_f32 v84, v84, v92// 0000001C0E20: CA94B753 5354B954
	v_mov_b32_dpp v89, v81 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0E28: 7EB202FA FF096451
	v_mov_b32_dpp v90, v82 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0E30: 7EB402FA FF096452
	v_dual_max_f32 v99, v99, v99 :: v_dual_max_f32 v100, v100, v100// 0000001C0E38: CA94C763 6364C964
	v_dual_max_f32 v85, v85, v97 :: v_dual_max_f32 v86, v86, v98// 0000001C0E40: CA94C355 5556C556
	v_mov_b32_dpp v91, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0E48: 7EB602FA FF096453
	v_mov_b32_dpp v92, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0E50: 7EB802FA FF096454
	v_dual_max_f32 v89, v89, v89 :: v_dual_max_f32 v90, v90, v90// 0000001C0E58: CA94B359 595AB55A
	v_dual_max_f32 v87, v87, v99 :: v_dual_max_f32 v88, v88, v100// 0000001C0E60: CA94C757 5758C958
	v_mov_b32_dpp v97, v85 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0E68: 7EC202FA FF096455
	v_mov_b32_dpp v98, v86 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0E70: 7EC402FA FF096456
	v_dual_max_f32 v91, v91, v91 :: v_dual_max_f32 v92, v92, v92// 0000001C0E78: CA94B75B 5B5CB95C
	v_dual_max_f32 v81, v81, v89 :: v_dual_max_f32 v82, v82, v90// 0000001C0E80: CA94B351 5152B552
	v_mov_b32_dpp v99, v87 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0E88: 7EC602FA FF096457
	v_mov_b32_dpp v100, v88 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0E90: 7EC802FA FF096458
	v_dual_max_f32 v97, v97, v97 :: v_dual_max_f32 v98, v98, v98// 0000001C0E98: CA94C361 6162C562
	v_dual_max_f32 v83, v83, v91 :: v_dual_max_f32 v84, v84, v92// 0000001C0EA0: CA94B753 5354B954
	v_mov_b32_dpp v89, v81 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0EA8: 7EB202FA FF096851
	v_mov_b32_dpp v90, v82 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0EB0: 7EB402FA FF096852
	v_dual_max_f32 v99, v99, v99 :: v_dual_max_f32 v100, v100, v100// 0000001C0EB8: CA94C763 6364C964
	v_dual_max_f32 v85, v85, v97 :: v_dual_max_f32 v86, v86, v98// 0000001C0EC0: CA94C355 5556C556
	v_mov_b32_dpp v91, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0EC8: 7EB602FA FF096853
	v_mov_b32_dpp v92, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0ED0: 7EB802FA FF096854
	v_max3_f32 v149, v184, v81, v89                            // 0000001C0ED8: D61C0095 0566A3B8
	v_max3_f32 v150, v185, v82, v90                            // 0000001C0EE0: D61C0096 056AA5B9
	v_dual_max_f32 v87, v87, v99 :: v_dual_max_f32 v88, v88, v100// 0000001C0EE8: CA94C757 5758C958
	v_mov_b32_dpp v97, v85 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0EF0: 7EC202FA FF096855
	v_mov_b32_dpp v98, v86 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0EF8: 7EC402FA FF096856
	v_max3_f32 v151, v186, v83, v91                            // 0000001C0F00: D61C0097 056EA7BA
	v_max3_f32 v152, v187, v84, v92                            // 0000001C0F08: D61C0098 0572A9BB
	v_dual_sub_f32 v74, v74, v149 :: v_dual_sub_f32 v73, v73, v150// 0000001C0F10: C94B2B4A 4A492D49
	v_mov_b32_dpp v99, v87 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0F18: 7EC602FA FF096857
	v_mov_b32_dpp v100, v88 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C0F20: 7EC802FA FF096858
	v_max3_f32 v153, v188, v85, v97                            // 0000001C0F28: D61C0099 0586ABBC
	v_max3_f32 v154, v189, v86, v98                            // 0000001C0F30: D61C009A 058AADBD
	v_dual_sub_f32 v76, v76, v151 :: v_dual_sub_f32 v75, v75, v152// 0000001C0F38: C94B2F4C 4C4B314B
	v_dual_mul_f32 v81, 0x3fb8aa3b, v73 :: v_dual_mul_f32 v82, 0x3fb8aa3b, v74// 0000001C0F40: C8C692FF 515294FF 3FB8AA3B
	v_max3_f32 v155, v190, v87, v99                            // 0000001C0F4C: D61C009B 058EAFBE
	v_max3_f32 v156, v192, v88, v100                           // 0000001C0F54: D61C009C 0592B1C0
	v_dual_sub_f32 v78, v78, v153 :: v_dual_sub_f32 v77, v77, v154// 0000001C0F5C: C94B334E 4E4D354D
	v_dual_mul_f32 v83, 0x3fb8aa3b, v75 :: v_dual_mul_f32 v84, 0x3fb8aa3b, v76// 0000001C0F64: C8C696FF 535498FF 3FB8AA3B
	v_fma_f32 v89, 0x3fb8aa3b, v73, -v81                       // 0000001C0F70: D6130059 854692FF 3FB8AA3B
	v_rndne_f32_e32 v90, v81                                   // 0000001C0F7C: 7EB44751
	v_dual_sub_f32 v80, v80, v155 :: v_dual_sub_f32 v79, v79, v156// 0000001C0F80: C94B3750 504F394F
	v_dual_mul_f32 v85, 0x3fb8aa3b, v77 :: v_dual_mul_f32 v86, 0x3fb8aa3b, v78// 0000001C0F88: C8C69AFF 55569CFF 3FB8AA3B
	v_fma_f32 v91, 0x3fb8aa3b, v74, -v82                       // 0000001C0F94: D613005B 854A94FF 3FB8AA3B
	v_rndne_f32_e32 v92, v82                                   // 0000001C0FA0: 7EB84752
	v_rndne_f32_e32 v100, v84                                  // 0000001C0FA4: 7EC84754
	v_fmac_f32_e32 v89, 0x32a5705f, v73                        // 0000001C0FA8: 56B292FF 32A5705F
	v_sub_f32_e32 v81, v81, v90                                // 0000001C0FB0: 08A2B551
	v_dual_mul_f32 v87, 0x3fb8aa3b, v79 :: v_dual_mul_f32 v88, 0x3fb8aa3b, v80// 0000001C0FB4: C8C69EFF 5758A0FF 3FB8AA3B
	v_fma_f32 v97, 0x3fb8aa3b, v75, -v83                       // 0000001C0FC0: D6130061 854E96FF 3FB8AA3B
	v_rndne_f32_e32 v98, v83                                   // 0000001C0FCC: 7EC44753
	v_fma_f32 v99, 0x3fb8aa3b, v76, -v84                       // 0000001C0FD0: D6130063 855298FF 3FB8AA3B
	v_rndne_f32_e32 v104, v86                                  // 0000001C0FDC: 7ED04756
	v_dual_fmac_f32 v91, 0x32a5705f, v74 :: v_dual_sub_f32 v82, v82, v92// 0000001C0FE0: C80A94FF 5B52B952 32A5705F
	v_dual_sub_f32 v84, v84, v100 :: v_dual_add_f32 v81, v81, v89// 0000001C0FEC: C948C954 5450B351
	v_sub_f32_e32 v164, v187, v152                             // 0000001C0FF4: 094931BB
	v_fma_f32 v103, 0x3fb8aa3b, v78, -v86                      // 0000001C0FF8: D6130067 855A9CFF 3FB8AA3B
	v_rndne_f32_e32 v108, v88                                  // 0000001C1004: 7ED84758
	v_dual_fmac_f32 v97, 0x32a5705f, v75 :: v_dual_sub_f32 v86, v86, v104// 0000001C1008: C80A96FF 6156D156 32A5705F
	v_dual_sub_f32 v83, v83, v98 :: v_dual_add_f32 v82, v82, v91// 0000001C1014: C948C553 5352B752
	v_exp_f32_e32 v81, v81                                     // 0000001C101C: 7EA24B51
	v_fma_f32 v101, 0x3fb8aa3b, v77, -v85                      // 0000001C1020: D6130065 85569AFF 3FB8AA3B
	v_rndne_f32_e32 v102, v85                                  // 0000001C102C: 7ECC4755
	v_fma_f32 v107, 0x3fb8aa3b, v80, -v88                      // 0000001C1030: D613006B 8562A0FF 3FB8AA3B
	v_cvt_i32_f32_e32 v90, v90                                 // 0000001C103C: 7EB4115A
	v_fmac_f32_e32 v103, 0x32a5705f, v78                       // 0000001C1040: 56CE9CFF 32A5705F
	v_fmac_f32_e32 v99, 0x32a5705f, v76                        // 0000001C1048: 56C698FF 32A5705F
	v_dual_sub_f32 v88, v88, v108 :: v_dual_add_f32 v83, v83, v97// 0000001C1050: C948D958 5852C353
	v_sub_f32_e32 v162, v185, v150                             // 0000001C1058: 09452DB9
	v_exp_f32_e32 v82, v82                                     // 0000001C105C: 7EA44B52
	v_cvt_i32_f32_e32 v92, v92                                 // 0000001C1060: 7EB8115C
	v_fmac_f32_e32 v107, 0x32a5705f, v80                       // 0000001C1064: 56D6A0FF 32A5705F
	v_dual_sub_f32 v85, v85, v102 :: v_dual_add_f32 v86, v86, v103// 0000001C106C: C948CD55 5556CF56
	v_dual_fmac_f32 v101, 0x32a5705f, v77 :: v_dual_add_f32 v84, v84, v99// 0000001C1074: C8089AFF 6554C754 32A5705F
	v_exp_f32_e32 v83, v83                                     // 0000001C1080: 7EA64B53
	.long 0xd71c0051                                           // 0000001C1084: D71C0051
	v_cndmask_b32_e32 v1, v81, v90, vcc_lo                     // 0000001C1088: 0202B551
	.long 0xd41b0000                                           // 0000001C108C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v73, vcc_lo              // 0000001C1090: 020292FF C2CE8ED0
	v_fma_f32 v105, 0x3fb8aa3b, v79, -v87                      // 0000001C1098: D6130069 855E9EFF 3FB8AA3B
	v_rndne_f32_e32 v106, v87                                  // 0000001C10A4: 7ED44757
	v_cvt_i32_f32_e32 v98, v98                                 // 0000001C10A8: 7EC41162
	v_dual_add_f32 v88, v88, v107 :: v_dual_add_f32 v85, v85, v101// 0000001C10AC: C908D758 5854CB55
	v_sub_f32_e32 v168, v192, v156                             // 0000001C10B4: 095139C0
	v_exp_f32_e32 v84, v84                                     // 0000001C10B8: 7EA84B54
	.long 0xd71c0052                                           // 0000001C10BC: D71C0052
	v_cndmask_b32_e32 v1, v82, v92, vcc_lo                     // 0000001C10C0: 0202B952
	v_cndmask_b32_e64 v81, 0, v81, s0                          // 0000001C10C4: D5010051 0002A280
	.long 0xd41b0000                                           // 0000001C10CC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v74, vcc_lo              // 0000001C10D0: 020294FF C2CE8ED0
	v_cvt_i32_f32_e32 v100, v100                               // 0000001C10D8: 7EC81164
	v_fmac_f32_e32 v105, 0x32a5705f, v79                       // 0000001C10DC: 56D29EFF 32A5705F
	v_sub_f32_e32 v87, v87, v106                               // 0000001C10E4: 08AED557
	v_exp_f32_e32 v85, v85                                     // 0000001C10E8: 7EAA4B55
	.long 0xd71c0053                                           // 0000001C10EC: D71C0053
	v_cndmask_b32_e32 v1, v83, v98, vcc_lo                     // 0000001C10F0: 0202C553
	v_cndmask_b32_e64 v82, 0, v82, s0                          // 0000001C10F4: D5010052 0002A480
	.long 0xd41b0000                                           // 0000001C10FC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v75, vcc_lo              // 0000001C1100: 020296FF C2CE8ED0
	v_cvt_i32_f32_e32 v102, v102                               // 0000001C1108: 7ECC1166
	v_dual_add_f32 v87, v87, v105 :: v_dual_sub_f32 v166, v189, v154// 0000001C110C: C90AD357 57A735BD
	v_exp_f32_e32 v86, v86                                     // 0000001C1114: 7EAC4B56
	.long 0xd71c0054                                           // 0000001C1118: D71C0054
	v_cndmask_b32_e32 v1, v84, v100, vcc_lo                    // 0000001C111C: 0202C954
	v_cndmask_b32_e64 v83, 0, v83, s0                          // 0000001C1120: D5010053 0002A680
	.long 0xd41b0000                                           // 0000001C1128: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v76, vcc_lo              // 0000001C112C: 020298FF C2CE8ED0
	v_cvt_i32_f32_e32 v104, v104                               // 0000001C1134: 7ED01168
	v_exp_f32_e32 v87, v87                                     // 0000001C1138: 7EAE4B57
	.long 0xd71c0055                                           // 0000001C113C: D71C0055
	v_cndmask_b32_e32 v1, v85, v102, vcc_lo                    // 0000001C1140: 0202CD55
	v_exp_f32_e32 v88, v88                                     // 0000001C1144: 7EB04B58
	v_cndmask_b32_e64 v84, 0, v84, s0                          // 0000001C1148: D5010054 0002A880
	.long 0xd41b0000                                           // 0000001C1150: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v77, vcc_lo              // 0000001C1154: 02029AFF C2CE8ED0
	v_cvt_i32_f32_e32 v89, v106                                // 0000001C115C: 7EB2116A
	.long 0xd71c0056                                           // 0000001C1160: D71C0056
	v_cndmask_b32_e32 v1, v86, v104, vcc_lo                    // 0000001C1164: 0202D156
	v_cvt_i32_f32_e32 v91, v108                                // 0000001C1168: 7EB6116C
	v_dual_sub_f32 v163, v186, v151 :: v_dual_mov_b32 v192, v156// 0000001C116C: C9512FBA A3C0019C
	v_cndmask_b32_e64 v85, 0, v85, s0                          // 0000001C1174: D5010055 0002AA80
	.long 0xd41b0000                                           // 0000001C117C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v78, vcc_lo              // 0000001C1180: 02029CFF C2CE8ED0
	.long 0xd71c0057                                           // 0000001C1188: D71C0057
	v_cndmask_b32_e32 v1, v87, v89, vcc_lo                     // 0000001C118C: 0202B357
	.long 0xd71c0058                                           // 0000001C1190: D71C0058
	v_cndmask_b32_e32 v1, v88, v91, vcc_lo                     // 0000001C1194: 0202B758
	v_dual_mov_b32 v186, v151 :: v_dual_sub_f32 v161, v184, v149// 0000001C1198: CA0A0197 BAA12BB8
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001C11A0: BF8701C4
	v_cndmask_b32_e64 v86, 0, v86, s0                          // 0000001C11A4: D5010056 0002AC80
	.long 0xd41b0000                                           // 0000001C11AC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v79, vcc_lo              // 0000001C11B0: 02029EFF C2CE8ED0
	v_dual_mov_b32 v184, v149 :: v_dual_sub_f32 v165, v188, v153// 0000001C11B8: CA0A0195 B8A533BC
	v_dual_sub_f32 v167, v190, v155 :: v_dual_mov_b32 v188, v153// 0000001C11C0: C95137BE A7BC0199
	v_cndmask_b32_e64 v87, 0, v87, s0                          // 0000001C11C8: D5010057 0002AE80
	.long 0xd41b0000                                           // 0000001C11D0: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v80, vcc_lo              // 0000001C11D4: 0202A0FF C2CE8ED0
	v_dual_mov_b32 v190, v155 :: v_dual_mov_b32 v185, v150     // 0000001C11DC: CA10019B BEB80196
	v_mul_f32_e32 v156, 0x3fb8aa3b, v168                       // 0000001C11E4: 113950FF 3FB8AA3B
	v_mul_f32_e32 v150, 0x3fb8aa3b, v162                       // 0000001C11EC: 112D44FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C11F4: BF870224
	v_cndmask_b32_e64 v88, 0, v88, s0                          // 0000001C11F8: D5010058 0002B080
	.long 0xd41e0000                                           // 0000001C1200: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v73, vcc_lo              // 0000001C1204: 020292FF 42B17218
	v_fma_f32 v211, 0x3fb8aa3b, v168, -v156                    // 0000001C120C: D61300D3 867350FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C1218: BF870224
	v_rndne_f32_e32 v200, v150                                 // 0000001C121C: 7F904796
	v_mov_b32_e32 v187, v152                                   // 0000001C1220: 7F760398
	v_cndmask_b32_e64 v89, 0x7f800000, v81, s0                 // 0000001C1224: D5010059 0002A2FF 7F800000
	.long 0xd41e0000                                           // 0000001C1230: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v74, vcc_lo              // 0000001C1234: 020294FF 42B17218
	v_mul_f32_e32 v152, 0x3fb8aa3b, v164                       // 0000001C123C: 113148FF 3FB8AA3B
	v_fma_f32 v199, 0x3fb8aa3b, v162, -v150                    // 0000001C1244: D61300C7 865B44FF 3FB8AA3B
	v_rndne_f32_e32 v212, v156                                 // 0000001C1250: 7FA8479C
	.long 0xd59c08c5                                           // 0000001C1254: D59C08C5
	v_cndmask_b32_e32 v0, v89, v128, vcc_lo                    // 0000001C1258: 02010159
	v_cndmask_b32_e64 v157, 0x7f800000, v82, s0                // 0000001C125C: D501009D 0002A4FF 7F800000
	.long 0xd41e0000                                           // 0000001C1268: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v75, vcc_lo              // 0000001C126C: 020296FF 42B17218
	v_rndne_f32_e32 v204, v152                                 // 0000001C1274: 7F984798
	v_mov_b32_e32 v189, v154                                   // 0000001C1278: 7F7A039A
	v_and_b32_e32 v73, 1, v197                                 // 0000001C127C: 36938A81
	.long 0xd59c085d                                           // 0000001C1280: D59C085D
	v_cndmask_b32_e32 v0, v157, v128, vcc_lo                   // 0000001C1284: 0201019D
	v_cndmask_b32_e64 v90, 0x7f800000, v83, s0                 // 0000001C1288: D501005A 0002A6FF 7F800000
	.long 0xd41e0000                                           // 0000001C1294: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v76, vcc_lo              // 0000001C1298: 020298FF 42B17218
	v_mul_f32_e32 v154, 0x3fb8aa3b, v166                       // 0000001C12A0: 11354CFF 3FB8AA3B
	v_add3_u32 v73, v89, v73, 0x7fff                           // 0000001C12A8: D6550049 03FE9359 00007FFF
	v_and_b32_e32 v75, 1, v93                                  // 0000001C12B4: 3696BA81
	.long 0xd59c08c5                                           // 0000001C12B8: D59C08C5
	v_cndmask_b32_e32 v0, v90, v128, vcc_lo                    // 0000001C12BC: 0201015A
	v_cndmask_b32_e64 v158, 0x7f800000, v84, s0                // 0000001C12C0: D501009E 0002A8FF 7F800000
	.long 0xd41e0000                                           // 0000001C12CC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v77, vcc_lo              // 0000001C12D0: 02029AFF 42B17218
	v_rndne_f32_e32 v208, v154                                 // 0000001C12D8: 7FA0479A
	v_add3_u32 v75, v157, v75, 0x7fff                          // 0000001C12DC: D655004B 03FE979D 00007FFF
	v_and_b32_e32 v74, 1, v197                                 // 0000001C12E8: 36958A81
	.long 0xd59c085e                                           // 0000001C12EC: D59C085E
	v_cndmask_b32_e32 v0, v158, v128, vcc_lo                   // 0000001C12F0: 0201019E
	v_cndmask_b32_e64 v91, 0x7f800000, v85, s0                 // 0000001C12F4: D501005B 0002AAFF 7F800000
	.long 0xd41e0000                                           // 0000001C1300: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v78, vcc_lo              // 0000001C1304: 02029CFF 42B17218
	v_mul_f32_e32 v149, 0x3fb8aa3b, v161                       // 0000001C130C: 112B42FF 3FB8AA3B
	v_add3_u32 v74, v90, v74, 0x7fff                           // 0000001C1314: D655004A 03FE955A 00007FFF
	v_and_b32_e32 v76, 1, v94                                  // 0000001C1320: 3698BC81
	.long 0xd59c08c5                                           // 0000001C1324: D59C08C5
	v_cndmask_b32_e32 v0, v91, v128, vcc_lo                    // 0000001C1328: 0201015B
	v_cndmask_b32_e64 v159, 0x7f800000, v86, s0                // 0000001C132C: D501009F 0002ACFF 7F800000
	.long 0xd41e0000                                           // 0000001C1338: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v79, vcc_lo              // 0000001C133C: 02029EFF 42B17218
	v_fma_f32 v203, 0x3fb8aa3b, v164, -v152                    // 0000001C1344: D61300CB 866348FF 3FB8AA3B
	v_add3_u32 v76, v158, v76, 0x7fff                          // 0000001C1350: D655004C 03FE999E 00007FFF
	v_and_b32_e32 v78, 1, v197                                 // 0000001C135C: 369D8A81
	.long 0xd59c085f                                           // 0000001C1360: D59C085F
	v_cndmask_b32_e32 v0, v159, v128, vcc_lo                   // 0000001C1364: 0201019F
	v_cndmask_b32_e64 v92, 0x7f800000, v87, s0                 // 0000001C1368: D501005C 0002AEFF 7F800000
	.long 0xd41e0000                                           // 0000001C1374: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v80, vcc_lo              // 0000001C1378: 0202A0FF 42B17218
	v_fma_f32 v207, 0x3fb8aa3b, v166, -v154                    // 0000001C1380: D61300CF 866B4CFF 3FB8AA3B
	v_add3_u32 v78, v91, v78, 0x7fff                           // 0000001C138C: D655004E 03FE9D5B 00007FFF
	v_and_b32_e32 v77, 1, v95                                  // 0000001C1398: 369ABE81
	.long 0xd59c08c5                                           // 0000001C139C: D59C08C5
	v_cndmask_b32_e32 v0, v92, v128, vcc_lo                    // 0000001C13A0: 0201015C
	v_cndmask_b32_e64 v160, 0x7f800000, v88, s0                // 0000001C13A4: D50100A0 0002B0FF 7F800000
	v_sub_f32_e32 v154, v154, v208                             // 0000001C13B0: 0935A19A
	v_rndne_f32_e32 v198, v149                                 // 0000001C13B4: 7F8C4795
	v_add3_u32 v77, v159, v77, 0x7fff                          // 0000001C13B8: D655004D 03FE9B9F 00007FFF
	v_and_b32_e32 v80, 1, v197                                 // 0000001C13C4: 36A18A81
	.long 0xd59c0860                                           // 0000001C13C8: D59C0860
	v_cndmask_b32_e32 v0, v160, v128, vcc_lo                   // 0000001C13CC: 020101A0
	v_fma_f32 v197, 0x3fb8aa3b, v161, -v149                    // 0000001C13D0: D61300C5 865742FF 3FB8AA3B
	v_dual_mul_f32 v151, 0x3fb8aa3b, v163 :: v_dual_sub_f32 v156, v156, v212// 0000001C13DC: C8CB46FF 979DA99C 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C13E8: BF870214
	v_add3_u32 v80, v92, v80, 0x7fff                           // 0000001C13EC: D6550050 03FEA15C 00007FFF
	v_and_b32_e32 v79, 1, v96                                  // 0000001C13F8: 369EC081
	v_fmac_f32_e32 v203, 0x32a5705f, v164                      // 0000001C13FC: 579748FF 32A5705F
	v_dual_sub_f32 v152, v152, v204 :: v_dual_fmac_f32 v197, 0x32a5705f, v161// 0000001C1404: C9419998 98C542FF 32A5705F
	v_fmac_f32_e32 v207, 0x32a5705f, v166                      // 0000001C1410: 579F4CFF 32A5705F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C1418: BF870004
	v_add3_u32 v79, v160, v79, 0x7fff                          // 0000001C141C: D655004F 03FE9FA0 00007FFF
	ds_store_b16_d16_hi v179, v75                              // 0000001C1428: DA840000 00004BB3
	ds_store_b16_d16_hi v179, v73 offset:64                    // 0000001C1430: DA840040 000049B3
	ds_store_b16_d16_hi v179, v76 offset:128                   // 0000001C1438: DA840080 00004CB3
	ds_store_b16_d16_hi v179, v74 offset:192                   // 0000001C1440: DA8400C0 00004AB3
	ds_store_b16_d16_hi v179, v77 offset:256                   // 0000001C1448: DA840100 00004DB3
	ds_store_b16_d16_hi v179, v78 offset:320                   // 0000001C1450: DA840140 00004EB3
	ds_store_b16_d16_hi v179, v79 offset:384                   // 0000001C1458: DA840180 00004FB3
	ds_store_b16_d16_hi v179, v80 offset:448                   // 0000001C1460: DA8401C0 000050B3
	ds_load_b128 v[73:76], v180                                // 0000001C1468: DBFC0000 490000B4
	ds_load_b128 v[77:80], v180 offset:16                      // 0000001C1470: DBFC0010 4D0000B4
	s_clause 0x1f                                              // 0000001C1478: BF85001F
	global_load_b64 v[81:82], v[119:120], off                  // 0000001C147C: DC560000 517C0077
	global_load_b64 v[93:94], v[119:120], off offset:128       // 0000001C1484: DC560080 5D7C0077
	global_load_b64 v[101:102], v[119:120], off offset:256     // 0000001C148C: DC560100 657C0077
	global_load_b64 v[109:110], v[119:120], off offset:384     // 0000001C1494: DC560180 6D7C0077
	global_load_b64 v[83:84], v[121:122], off                  // 0000001C149C: DC560000 537C0079
	global_load_b64 v[95:96], v[121:122], off offset:128       // 0000001C14A4: DC560080 5F7C0079
	global_load_b64 v[103:104], v[121:122], off offset:256     // 0000001C14AC: DC560100 677C0079
	global_load_b64 v[111:112], v[121:122], off offset:384     // 0000001C14B4: DC560180 6F7C0079
	global_load_b64 v[85:86], v[123:124], off                  // 0000001C14BC: DC560000 557C007B
	global_load_b64 v[97:98], v[123:124], off offset:128       // 0000001C14C4: DC560080 617C007B
	global_load_b64 v[105:106], v[123:124], off offset:256     // 0000001C14CC: DC560100 697C007B
	global_load_b64 v[113:114], v[123:124], off offset:384     // 0000001C14D4: DC560180 717C007B
	global_load_b64 v[87:88], v[147:148], off                  // 0000001C14DC: DC560000 577C0093
	global_load_b64 v[99:100], v[147:148], off offset:128      // 0000001C14E4: DC560080 637C0093
	global_load_b64 v[107:108], v[147:148], off offset:256     // 0000001C14EC: DC560100 6B7C0093
	global_load_b64 v[115:116], v[147:148], off offset:384     // 0000001C14F4: DC560180 737C0093
	global_load_b64 v[117:118], v[119:120], off offset:512     // 0000001C14FC: DC560200 757C0077
	global_load_b64 v[125:126], v[119:120], off offset:640     // 0000001C1504: DC560280 7D7C0077
	global_load_b64 v[133:134], v[119:120], off offset:768     // 0000001C150C: DC560300 857C0077
	global_load_b64 v[141:142], v[119:120], off offset:896     // 0000001C1514: DC560380 8D7C0077
	global_load_b64 v[119:120], v[121:122], off offset:512     // 0000001C151C: DC560200 777C0079
	global_load_b64 v[127:128], v[121:122], off offset:640     // 0000001C1524: DC560280 7F7C0079
	global_load_b64 v[135:136], v[121:122], off offset:768     // 0000001C152C: DC560300 877C0079
	global_load_b64 v[143:144], v[121:122], off offset:896     // 0000001C1534: DC560380 8F7C0079
	global_load_b64 v[121:122], v[123:124], off offset:512     // 0000001C153C: DC560200 797C007B
	global_load_b64 v[129:130], v[123:124], off offset:640     // 0000001C1544: DC560280 817C007B
	global_load_b64 v[137:138], v[123:124], off offset:768     // 0000001C154C: DC560300 897C007B
	global_load_b64 v[145:146], v[123:124], off offset:896     // 0000001C1554: DC560380 917C007B
	global_load_b64 v[123:124], v[147:148], off offset:512     // 0000001C155C: DC560200 7B7C0093
	global_load_b64 v[131:132], v[147:148], off offset:640     // 0000001C1564: DC560280 837C0093
	global_load_b64 v[139:140], v[147:148], off offset:768     // 0000001C156C: DC560300 8B7C0093
	global_load_b64 v[147:148], v[147:148], off offset:896     // 0000001C1574: DC560380 937C0093
	v_dual_sub_f32 v149, v149, v198 :: v_dual_add_f32 v154, v154, v207// 0000001C157C: C9498D95 959B9F9A
	v_fma_f32 v201, 0x3fb8aa3b, v163, -v151                    // 0000001C1584: D61300C9 865F46FF 3FB8AA3B
	v_rndne_f32_e32 v202, v151                                 // 0000001C1590: 7F944797
	v_sub_f32_e32 v150, v150, v200                             // 0000001C1594: 092D9196
	v_fmac_f32_e32 v211, 0x32a5705f, v168                      // 0000001C1598: 57A750FF 32A5705F
	v_dual_fmac_f32 v199, 0x32a5705f, v162 :: v_dual_add_f32 v152, v152, v203// 0000001C15A0: C80944FF C7999798 32A5705F
	v_add_f32_e32 v149, v149, v197                             // 0000001C15AC: 072B8B95
	v_fmac_f32_e32 v201, 0x32a5705f, v163                      // 0000001C15B0: 579346FF 32A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C15B8: BF870214
	v_dual_sub_f32 v151, v151, v202 :: v_dual_add_f32 v156, v156, v211// 0000001C15BC: C9499597 979DA79C
	v_dual_mul_f32 v153, 0x3fb8aa3b, v165 :: v_dual_add_f32 v150, v150, v199// 0000001C15C4: C8C94AFF 99978F96 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001C15D0: BF8701A4
	v_exp_f32_e32 v149, v149                                   // 0000001C15D4: 7F2A4B95
	v_cvt_i32_f32_e32 v198, v198                               // 0000001C15D8: 7F8C11C6
	v_add_f32_e32 v151, v151, v201                             // 0000001C15DC: 072F9397
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C15E0: BF870003
	v_fma_f32 v205, 0x3fb8aa3b, v165, -v153                    // 0000001C15E4: D61300CD 86674AFF 3FB8AA3B
	v_rndne_f32_e32 v206, v153                                 // 0000001C15F0: 7F9C4799
	v_exp_f32_e32 v150, v150                                   // 0000001C15F4: 7F2C4B96
	v_mul_f32_e32 v155, 0x3fb8aa3b, v167                       // 0000001C15F8: 11374EFF 3FB8AA3B
	v_cvt_i32_f32_e32 v200, v200                               // 0000001C1600: 7F9011C8
	v_fmac_f32_e32 v205, 0x32a5705f, v165                      // 0000001C1604: 579B4AFF 32A5705F
	v_sub_f32_e32 v153, v153, v206                             // 0000001C160C: 09339D99
	v_exp_f32_e32 v151, v151                                   // 0000001C1610: 7F2E4B97
	.long 0xd71c0095                                           // 0000001C1614: D71C0095
	v_cndmask_b32_e32 v1, v149, v198, vcc_lo                   // 0000001C1618: 02038D95
	.long 0xd41b0000                                           // 0000001C161C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v161, vcc_lo             // 0000001C1620: 020342FF C2CE8ED0
	v_fma_f32 v209, 0x3fb8aa3b, v167, -v155                    // 0000001C1628: D61300D1 866F4EFF 3FB8AA3B
	v_rndne_f32_e32 v210, v155                                 // 0000001C1634: 7FA4479B
	v_cvt_i32_f32_e32 v202, v202                               // 0000001C1638: 7F9411CA
	v_add_f32_e32 v153, v153, v205                             // 0000001C163C: 07339B99
	v_exp_f32_e32 v152, v152                                   // 0000001C1640: 7F304B98
	.long 0xd71c0096                                           // 0000001C1644: D71C0096
	v_cndmask_b32_e32 v1, v150, v200, vcc_lo                   // 0000001C1648: 02039196
	v_cndmask_b32_e64 v149, 0, v149, s0                        // 0000001C164C: D5010095 00032A80
	.long 0xd41b0000                                           // 0000001C1654: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v162, vcc_lo             // 0000001C1658: 020344FF C2CE8ED0
	v_cvt_i32_f32_e32 v204, v204                               // 0000001C1660: 7F9811CC
	v_fmac_f32_e32 v209, 0x32a5705f, v167                      // 0000001C1664: 57A34EFF 32A5705F
	v_sub_f32_e32 v155, v155, v210                             // 0000001C166C: 0937A59B
	v_exp_f32_e32 v153, v153                                   // 0000001C1670: 7F324B99
	.long 0xd71c0097                                           // 0000001C1674: D71C0097
	v_cndmask_b32_e32 v1, v151, v202, vcc_lo                   // 0000001C1678: 02039597
	v_cndmask_b32_e64 v150, 0, v150, s0                        // 0000001C167C: D5010096 00032C80
	.long 0xd41b0000                                           // 0000001C1684: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v163, vcc_lo             // 0000001C1688: 020346FF C2CE8ED0
	v_cvt_i32_f32_e32 v206, v206                               // 0000001C1690: 7F9C11CE
	v_add_f32_e32 v155, v155, v209                             // 0000001C1694: 0737A39B
	v_exp_f32_e32 v154, v154                                   // 0000001C1698: 7F344B9A
	.long 0xd71c0098                                           // 0000001C169C: D71C0098
	v_cndmask_b32_e32 v1, v152, v204, vcc_lo                   // 0000001C16A0: 02039998
	v_cndmask_b32_e64 v151, 0, v151, s0                        // 0000001C16A4: D5010097 00032E80
	.long 0xd41b0000                                           // 0000001C16AC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v164, vcc_lo             // 0000001C16B0: 020348FF C2CE8ED0
	v_cvt_i32_f32_e32 v208, v208                               // 0000001C16B8: 7FA011D0
	v_exp_f32_e32 v155, v155                                   // 0000001C16BC: 7F364B9B
	.long 0xd71c0099                                           // 0000001C16C0: D71C0099
	v_cndmask_b32_e32 v1, v153, v206, vcc_lo                   // 0000001C16C4: 02039D99
	v_exp_f32_e32 v156, v156                                   // 0000001C16C8: 7F384B9C
	v_cndmask_b32_e64 v152, 0, v152, s0                        // 0000001C16CC: D5010098 00033080
	.long 0xd41b0000                                           // 0000001C16D4: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v165, vcc_lo             // 0000001C16D8: 02034AFF C2CE8ED0
	v_cvt_i32_f32_e32 v197, v210                               // 0000001C16E0: 7F8A11D2
	.long 0xd71c009a                                           // 0000001C16E4: D71C009A
	v_cndmask_b32_e32 v1, v154, v208, vcc_lo                   // 0000001C16E8: 0203A19A
	v_cvt_i32_f32_e32 v199, v212                               // 0000001C16EC: 7F8E11D4
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C16F0: BF870004
	v_cndmask_b32_e64 v153, 0, v153, s0                        // 0000001C16F4: D5010099 00033280
	.long 0xd41b0000                                           // 0000001C16FC: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v166, vcc_lo             // 0000001C1700: 02034CFF C2CE8ED0
	.long 0xd71c009b                                           // 0000001C1708: D71C009B
	v_cndmask_b32_e32 v1, v155, v197, vcc_lo                   // 0000001C170C: 02038B9B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 0000001C1710: BF870205
	.long 0xd71c009c                                           // 0000001C1714: D71C009C
	v_cndmask_b32_e32 v1, v156, v199, vcc_lo                   // 0000001C1718: 02038F9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C171C: BF8700A3
	v_cndmask_b32_e64 v154, 0, v154, s0                        // 0000001C1720: D501009A 00033480
	.long 0xd41b0000                                           // 0000001C1728: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v167, vcc_lo             // 0000001C172C: 02034EFF C2CE8ED0
	v_cndmask_b32_e64 v155, 0, v155, s0                        // 0000001C1734: D501009B 00033680
	.long 0xd41b0000                                           // 0000001C173C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v168, vcc_lo             // 0000001C1740: 020350FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C1748: BF8700A1
	v_cndmask_b32_e64 v156, 0, v156, s0                        // 0000001C174C: D501009C 00033880
	.long 0xd41e0000                                           // 0000001C1754: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v161, vcc_lo             // 0000001C1758: 020342FF 42B17218
	v_cndmask_b32_e64 v149, 0x7f800000, v149, s0               // 0000001C1760: D5010095 00032AFF 7F800000
	.long 0xd41e0000                                           // 0000001C176C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v162, vcc_lo             // 0000001C1770: 020344FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C1778: BF870112
	v_mul_f32_e32 v9, v9, v149                                 // 0000001C177C: 10132B09
	v_cndmask_b32_e64 v150, 0x7f800000, v150, s0               // 0000001C1780: D5010096 00032CFF 7F800000
	.long 0xd41e0000                                           // 0000001C178C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v163, vcc_lo             // 0000001C1790: 020346FF 42B17218
	v_mul_f32_e32 v1, v1, v149                                 // 0000001C1798: 10032B01
	v_fma_f32 v169, v169, v149, v157                           // 0000001C179C: D61300A9 06772BA9
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C17A4: BF870214
	v_mul_f32_e32 v58, v58, v150                               // 0000001C17A8: 10752D3A
	v_cndmask_b32_e64 v151, 0x7f800000, v151, s0               // 0000001C17AC: D5010097 00032EFF 7F800000
	.long 0xd41e0000                                           // 0000001C17B8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v164, vcc_lo             // 0000001C17BC: 020348FF 42B17218
	v_mul_f32_e32 v50, v50, v150                               // 0000001C17C4: 10652D32
	v_mul_f32_e32 v42, v42, v150                               // 0000001C17C8: 10552D2A
	v_mul_f32_e32 v34, v34, v150                               // 0000001C17CC: 10452D22
	v_mul_f32_e32 v26, v26, v150                               // 0000001C17D0: 10352D1A
	v_cndmask_b32_e64 v152, 0x7f800000, v152, s0               // 0000001C17D4: D5010098 000330FF 7F800000
	.long 0xd41e0000                                           // 0000001C17E0: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v165, vcc_lo             // 0000001C17E4: 02034AFF 42B17218
	v_dual_mul_f32 v17, v17, v149 :: v_dual_mul_f32 v18, v18, v150// 0000001C17EC: C8C72B11 11132D12
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C17F4: BF870193
	v_dual_mul_f32 v19, v19, v151 :: v_dual_mul_f32 v60, v60, v152// 0000001C17F8: C8C72F13 133D313C
	v_cndmask_b32_e64 v153, 0x7f800000, v153, s0               // 0000001C1800: D5010099 000332FF 7F800000
	.long 0xd41e0000                                           // 0000001C180C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v166, vcc_lo             // 0000001C1810: 02034CFF 42B17218
	v_mul_f32_e32 v52, v52, v152                               // 0000001C1818: 10693134
	v_mul_f32_e32 v44, v44, v152                               // 0000001C181C: 1059312C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C1820: BF870214
	v_dual_mul_f32 v36, v36, v152 :: v_dual_mul_f32 v61, v61, v153// 0000001C1824: C8C73124 243D333D
	v_cndmask_b32_e64 v154, 0x7f800000, v154, s0               // 0000001C182C: D501009A 000334FF 7F800000
	.long 0xd41e0000                                           // 0000001C1838: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v167, vcc_lo             // 0000001C183C: 02034EFF 42B17218
	v_mul_f32_e32 v57, v57, v149                               // 0000001C1844: 10732B39
	v_mul_f32_e32 v49, v49, v149                               // 0000001C1848: 10632B31
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C184C: BF870214
	v_dual_mul_f32 v53, v53, v153 :: v_dual_mul_f32 v62, v62, v154// 0000001C1850: C8C73335 353F353E
	v_cndmask_b32_e64 v155, 0x7f800000, v155, s0               // 0000001C1858: D501009B 000336FF 7F800000
	.long 0xd41e0000                                           // 0000001C1864: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v168, vcc_lo             // 0000001C1868: 020350FF 42B17218
	v_dual_mul_f32 v54, v54, v154 :: v_dual_mul_f32 v41, v41, v149// 0000001C1870: C8C73536 36292B29
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C1878: BF870223
	v_dual_mul_f32 v22, v22, v154 :: v_dual_mul_f32 v63, v63, v155// 0000001C187C: C8C73516 163F373F
	v_mul_f32_e32 v28, v28, v152                               // 0000001C1884: 1039311C
	v_cndmask_b32_e64 v156, 0x7f800000, v156, s0               // 0000001C1888: D501009C 000338FF 7F800000
	v_mul_f32_e32 v59, v59, v151                               // 0000001C1894: 10772F3B
	v_mul_f32_e32 v51, v51, v151                               // 0000001C1898: 10672F33
	v_dual_mul_f32 v55, v55, v155 :: v_dual_mul_f32 v20, v20, v152// 0000001C189C: C8C73737 37153114
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C18A4: BF870004
	v_mul_f32_e32 v64, v64, v156                               // 0000001C18A8: 10813940
	v_dual_mul_f32 v56, v56, v156 :: v_dual_mul_f32 v43, v43, v151// 0000001C18AC: C8C73938 382B2F2B
	v_dual_mul_f32 v24, v24, v156 :: v_dual_mul_f32 v45, v45, v153// 0000001C18B4: C8C73918 182D332D
	v_mul_f32_e32 v10, v10, v150                               // 0000001C18BC: 10152D0A
	v_dual_mul_f32 v46, v46, v154 :: v_dual_mul_f32 v47, v47, v155// 0000001C18C0: C8C7352E 2E2F372F
	v_mul_f32_e32 v12, v12, v152                               // 0000001C18C8: 1019310C
	v_dual_mul_f32 v48, v48, v156 :: v_dual_mul_f32 v33, v33, v149// 0000001C18CC: C8C73930 30212B21
	v_dual_mul_f32 v14, v14, v154 :: v_dual_mul_f32 v35, v35, v151// 0000001C18D4: C8C7350E 0E232F23
	v_dual_mul_f32 v16, v16, v156 :: v_dual_mul_f32 v37, v37, v153// 0000001C18DC: C8C73910 10253325
	v_mul_f32_e32 v2, v2, v150                                 // 0000001C18E4: 10052D02
	v_dual_mul_f32 v38, v38, v154 :: v_dual_mul_f32 v39, v39, v155// 0000001C18E8: C8C73526 26273727
	v_mul_f32_e32 v4, v4, v152                                 // 0000001C18F0: 10093104
	v_dual_mul_f32 v40, v40, v156 :: v_dual_mul_f32 v25, v25, v149// 0000001C18F4: C8C73928 28192B19
	v_dual_mul_f32 v6, v6, v154 :: v_dual_mul_f32 v27, v27, v151// 0000001C18FC: C8C73506 061B2F1B
	v_fmac_f32_e32 v92, v193, v156                             // 0000001C1904: 56B939C1
	v_dual_mul_f32 v29, v29, v153 :: v_dual_mul_f32 v8, v8, v156// 0000001C1908: C8C7331D 1D093908
	v_dual_mul_f32 v30, v30, v154 :: v_dual_mul_f32 v31, v31, v155// 0000001C1910: C8C7351E 1E1F371F
	v_dual_mul_f32 v32, v32, v156 :: v_dual_mul_f32 v21, v21, v153// 0000001C1918: C8C73920 20153315
	v_mul_f32_e32 v23, v23, v155                               // 0000001C1920: 102F3717
	v_mul_f32_e32 v11, v11, v151                               // 0000001C1924: 10172F0B
	v_mul_f32_e32 v13, v13, v153                               // 0000001C1928: 101B330D
	v_mul_f32_e32 v15, v15, v155                               // 0000001C192C: 101F370F
	v_mul_f32_e32 v3, v3, v151                                 // 0000001C1930: 10072F03
	v_mul_f32_e32 v5, v5, v153                                 // 0000001C1934: 100B3305
	v_mul_f32_e32 v7, v7, v155                                 // 0000001C1938: 100F3707
	v_fma_f32 v171, v171, v151, v158                           // 0000001C193C: D61300AB 067B2FAB
	v_fma_f32 v170, v170, v153, v159                           // 0000001C1944: D61300AA 067F33AA
	v_fma_f32 v191, v191, v155, v160                           // 0000001C194C: D61300BF 068337BF
	v_dual_fmac_f32 v89, v196, v150 :: v_dual_fmac_f32 v90, v195, v152// 0000001C1954: C8012DC4 595B31C3
	v_fmac_f32_e32 v91, v194, v154                             // 0000001C195C: 56B735C2
	v_mov_b32_e32 v193, v92                                    // 0000001C1960: 7F82035C
	s_waitcnt vmcnt(19) lgkmcnt(0)                             // 0000001C1964: BF894C07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[73:80], v[81:88], v[57:64]// 0000001C1968: CC414039 1CE6A349
	s_waitcnt vmcnt(18)                                        // 0000001C1970: BF894BF7
	v_wmma_f32_16x16x16_bf16 v[49:56], v[73:80], v[93:100], v[49:56]// 0000001C1974: CC414031 1CC6BB49
	s_waitcnt vmcnt(17)                                        // 0000001C197C: BF8947F7
	v_wmma_f32_16x16x16_bf16 v[41:48], v[73:80], v[101:108], v[41:48]// 0000001C1980: CC414029 1CA6CB49
	s_waitcnt vmcnt(16)                                        // 0000001C1988: BF8943F7
	v_wmma_f32_16x16x16_bf16 v[33:40], v[73:80], v[109:116], v[33:40]// 0000001C198C: CC414021 1C86DB49
	s_waitcnt vmcnt(3)                                         // 0000001C1994: BF890FF7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[73:80], v[117:124], v[25:32]// 0000001C1998: CC414019 1C66EB49
	s_waitcnt vmcnt(2)                                         // 0000001C19A0: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[17:24], v[73:80], v[125:132], v[17:24]// 0000001C19A4: CC414011 1C46FB49
	s_waitcnt vmcnt(1)                                         // 0000001C19AC: BF8907F7
	v_wmma_f32_16x16x16_bf16 v[9:16], v[73:80], v[133:140], v[9:16]// 0000001C19B0: CC414009 1C270B49
	s_waitcnt vmcnt(0)                                         // 0000001C19B8: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[1:8], v[73:80], v[141:148], v[1:8]// 0000001C19BC: CC414001 1C071B49
	s_barrier                                                  // 0000001C19C4: BFBD0000
	buffer_gl0_inv                                             // 0000001C19C8: E0AC0000 00000000
	s_cbranch_scc0 51                                          // 0000001C19D0: BFA10033 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x16a0>
	s_mov_b32 s0, s21                                          // 0000001C19D4: BE800015
	s_add_i32 s21, s21, 4                                      // 0000001C19D8: 81158415
	v_dual_mov_b32 v194, v91 :: v_dual_mov_b32 v195, v90       // 0000001C19DC: CA10015B C2C2015A
	s_min_i32 s4, s21, s29                                     // 0000001C19E4: 89041D15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001C19E8: BF870499
	s_ashr_i32 s5, s4, 31                                      // 0000001C19EC: 86059F04
	s_lshl_b64 s[4:5], s[4:5], 2                               // 0000001C19F0: 84848204
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001C19F4: BF870009
	s_add_u32 s4, s14, s4                                      // 0000001C19F8: 8004040E
	s_addc_u32 s5, s15, s5                                     // 0000001C19FC: 8205050F
	s_cmp_lt_i32 s0, s27                                       // 0000001C1A00: BF041B00
	s_cselect_b32 s6, s3, s26                                  // 0000001C1A04: 98061A03
	s_cmp_lt_i32 s0, s1                                        // 0000001C1A08: BF040100
	s_waitcnt lgkmcnt(0)                                       // 0000001C1A0C: BF89FC07
	s_cselect_b32 s16, s16, s6                                 // 0000001C1A10: 98100610
	s_add_i32 s22, s0, 1                                       // 0000001C1A14: 81168100
	s_load_b128 s[4:7], s[4:5], null                           // 0000001C1A18: F4080102 F8000000
	s_cmp_lt_i32 s22, s27                                      // 0000001C1A20: BF041B16
	v_dual_mov_b32 v196, v89 :: v_dual_mov_b32 v73, s16        // 0000001C1A24: CA100159 C4480010
	s_cselect_b32 s23, s3, s26                                 // 0000001C1A2C: 98171A03
	s_cmp_lt_i32 s22, s1                                       // 0000001C1A30: BF040116
	s_cselect_b32 s22, s17, s23                                // 0000001C1A34: 98161711
	s_add_i32 s17, s0, 2                                       // 0000001C1A38: 81118200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001C1A3C: BF8704D9
	s_cmp_lt_i32 s17, s27                                      // 0000001C1A40: BF041B11
	s_cselect_b32 s23, s3, s26                                 // 0000001C1A44: 98171A03
	s_cmp_lt_i32 s17, s1                                       // 0000001C1A48: BF040111
	s_cselect_b32 s18, s18, s23                                // 0000001C1A4C: 98121712
	s_add_i32 s17, s0, 3                                       // 0000001C1A50: 81118300
	s_cmp_lt_i32 s17, s27                                      // 0000001C1A54: BF041B11
	s_cselect_b32 s23, s3, s26                                 // 0000001C1A58: 98171A03
	s_cmp_lt_i32 s17, s1                                       // 0000001C1A5C: BF040111
	s_mov_b32 s17, exec_lo                                     // 0000001C1A60: BE91007E
	s_cselect_b32 s24, s19, s23                                // 0000001C1A64: 98181713
	v_cmpx_lt_i32_e32 0, v175                                  // 0000001C1A68: 7D835E80
	s_cbranch_execz 64447                                      // 0000001C1A6C: BFA5FBBF <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x56c>
	.long 0xd44d0000                                           // 0000001C1A70: D44D0000
	v_cndmask_b32_e32 v1, 1, v175, vcc_lo                      // 0000001C1A74: 02035E81
	s_and_saveexec_b32 s19, s0                                 // 0000001C1A78: BE932000
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001C1A7C: BF870009
	s_xor_b32 s0, exec_lo, s19                                 // 0000001C1A80: 8D00137E
	v_mov_b32_e32 v73, s18                                     // 0000001C1A84: 7E920212
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C1A88: BF870001
	v_cndmask_b32_e32 v73, s24, v73, vcc_lo                    // 0000001C1A8C: 02929218
	s_and_not1_saveexec_b32 s0, s0                             // 0000001C1A90: BE803000
	s_cbranch_execz 64436                                      // 0000001C1A94: BFA5FBB4 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x568>
	v_mov_b32_e32 v73, s22                                     // 0000001C1A98: 7E920216
	s_branch 64434                                             // 0000001C1A9C: BFA0FBB2 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x568>
	v_mov_b32_e32 v8, v174                                     // 0000001C1AA0: 7E1003AE
	s_mul_i32 s0, s20, 12                                      // 0000001C1AA4: 96008C14
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C1AA8: BF870001
	v_or_b32_e32 v7, v8, v172                                  // 0000001C1AAC: 380F5908
	v_or_b32_e32 v0, s0, v173                                  // 0000001C1AB0: 38015A00
	v_mov_b32_dpp v78, v91 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1AB4: 7E9C02FA FF09615B
	v_mov_b32_dpp v75, v90 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1ABC: 7E9602FA FF09615A
	v_mov_b32_dpp v74, v171 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1AC4: 7E9402FA FF0961AB
	v_mov_b32_dpp v76, v170 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1ACC: 7E9802FA FF0961AA
	v_lshlrev_b32_e32 v0, 8, v0                                // 0000001C1AD4: 30000088
	v_mov_b32_e32 v8, 0                                        // 0000001C1AD8: 7E100280
	v_dual_add_f32 v78, v91, v78 :: v_dual_add_f32 v81, v90, v75// 0000001C1ADC: C9089D5B 4E50975A
	v_add_f32_e32 v83, v171, v74                               // 0000001C1AE4: 06A695AB
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C1AE8: BF870214
	v_add_nc_u32_e32 v23, 0x400, v0                            // 0000001C1AEC: 4A2E00FF 00000400
	v_mad_i64_i32 v[7:8], null, 0x1800, s2, v[7:8]             // 0000001C1AF4: D6FF7C07 041C04FF 00001800
	v_ashrrev_i32_e32 v16, 31, v0                              // 0000001C1B00: 3420009F
	v_add_nc_u32_e32 v31, 0x600, v0                            // 0000001C1B04: 4A3E00FF 00000600
	v_add_nc_u32_e32 v39, 0x800, v0                            // 0000001C1B0C: 4A4E00FF 00000800
	v_ashrrev_i32_e32 v24, 31, v23                             // 0000001C1B14: 34302E9F
	v_or_b32_e32 v65, 0x200, v0                                // 0000001C1B18: 388200FF 00000200
	v_add_f32_dpp v81, v81, v81 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1B20: 06A2A2FA FF096251
	v_ashrrev_i32_e32 v32, 31, v31                             // 0000001C1B28: 34403E9F
	.long 0xd7006a0f                                           // 0000001C1B2C: D7006A0F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000001C1B30: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C1B34: BF8700A1
	v_add_co_ci_u32_e64 v16, null, v8, v16, vcc_lo             // 0000001C1B38: D5207C10 01AA2108
	.long 0xd7006a17                                           // 0000001C1B40: D7006A17
	v_cndmask_b32_e32 v1, v7, v23, vcc_lo                      // 0000001C1B44: 02022F07
	v_add_co_ci_u32_e64 v24, null, v8, v24, vcc_lo             // 0000001C1B48: D5207C18 01AA3108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001C1B50: BF870233
	.long 0xd73c000f                                           // 0000001C1B54: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000001C1B58: 02021E81
	v_add_nc_u32_e32 v0, 0xa00, v0                             // 0000001C1B5C: 4A0000FF 00000A00
	v_ashrrev_i32_e32 v40, 31, v39                             // 0000001C1B64: 34504E9F
	.long 0xd73c0017                                           // 0000001C1B68: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000001C1B6C: 02022E81
	v_ashrrev_i32_e32 v66, 31, v65                             // 0000001C1B70: 3484829F
	v_add_f32_dpp v78, v78, v78 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1B74: 069C9CFA FF09624E
	.long 0xd7006a45                                           // 0000001C1B7C: D7006A45
	v_cndmask_b32_e32 v1, s10, v15, vcc_lo                     // 0000001C1B80: 02021E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C1B84: BF8700A1
	v_add_co_ci_u32_e64 v70, null, s11, v16, vcc_lo            // 0000001C1B88: D5207C46 01AA200B
	.long 0xd7006a1f                                           // 0000001C1B90: D7006A1F
	v_cndmask_b32_e32 v1, v7, v31, vcc_lo                      // 0000001C1B94: 02023F07
	v_add_co_ci_u32_e64 v32, null, v8, v32, vcc_lo             // 0000001C1B98: D5207C20 01AA4108
	.long 0xd7006a37                                           // 0000001C1BA0: D7006A37
	v_cndmask_b32_e32 v1, s10, v23, vcc_lo                     // 0000001C1BA4: 02022E0A
	v_ashrrev_i32_e32 v48, 31, v0                              // 0000001C1BA8: 3460009F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001C1BAC: BF8700B3
	.long 0xd73c001f                                           // 0000001C1BB0: D73C001F
	v_cndmask_b32_e32 v1, 1, v31, vcc_lo                       // 0000001C1BB4: 02023E81
	v_add_co_ci_u32_e64 v56, null, s11, v24, vcc_lo            // 0000001C1BB8: D5207C38 01AA300B
	.long 0xd7006a27                                           // 0000001C1BC0: D7006A27
	v_cndmask_b32_e32 v1, v7, v39, vcc_lo                      // 0000001C1BC4: 02024F07
	v_add_co_ci_u32_e64 v40, null, v8, v40, vcc_lo             // 0000001C1BC8: D5207C28 01AA5108
	.long 0xd7006a2f                                           // 0000001C1BD0: D7006A2F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000001C1BD4: 02020107
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C1BD8: BF870001
	v_add_co_ci_u32_e64 v48, null, v8, v48, vcc_lo             // 0000001C1BDC: D5207C30 01AA6108
	.long 0xd7006a3f                                           // 0000001C1BE4: D7006A3F
	v_cndmask_b32_e32 v1, s10, v31, vcc_lo                     // 0000001C1BE8: 02023E0A
	global_load_u16 v73, v[69:70], off offset:1024             // 0000001C1BEC: DC4A0400 497C0045
	v_add_co_ci_u32_e64 v64, null, s11, v32, vcc_lo            // 0000001C1BF4: D5207C40 01AA400B
	.long 0xd7006a07                                           // 0000001C1BFC: D7006A07
	v_cndmask_b32_e32 v1, v7, v65, vcc_lo                      // 0000001C1C00: 02028307
	s_clause 0x2                                               // 0000001C1C04: BF850002
	global_load_u16 v80, v[69:70], off                         // 0000001C1C08: DC4A0000 507C0045
	global_load_u16 v82, v[69:70], off offset:32               // 0000001C1C10: DC4A0020 527C0045
	global_load_u16 v103, v[69:70], off offset:64              // 0000001C1C18: DC4A0040 677C0045
	v_add_co_ci_u32_e64 v8, null, v8, v66, vcc_lo              // 0000001C1C20: D5207C08 01AA8508
	.long 0xd73c0027                                           // 0000001C1C28: D73C0027
	v_cndmask_b32_e32 v1, 1, v39, vcc_lo                       // 0000001C1C2C: 02024E81
	.long 0xd73c002f                                           // 0000001C1C30: D73C002F
	v_cndmask_b32_e32 v1, 1, v47, vcc_lo                       // 0000001C1C34: 02025E81
	v_add_f32_dpp v83, v83, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1C38: 06A6A6FA FF096253
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C1C40: BF8700C4
	.long 0xd73c0056                                           // 0000001C1C44: D73C0056
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 0000001C1C48: 02020E81
	v_mov_b32_dpp v8, v89 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1C4C: 7E1002FA FF096159
	v_mov_b32_dpp v7, v169 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1C54: 7E0E02FA FF0961A9
	.long 0xd7006a43                                           // 0000001C1C5C: D7006A43
	v_cndmask_b32_e32 v1, s10, v39, vcc_lo                     // 0000001C1C60: 02024E0A
	v_add_co_ci_u32_e64 v68, null, s11, v40, vcc_lo            // 0000001C1C64: D5207C44 01AA500B
	.long 0xd7006a41                                           // 0000001C1C6C: D7006A41
	v_cndmask_b32_e32 v1, s10, v47, vcc_lo                     // 0000001C1C70: 02025E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C1C74: BF8700A1
	v_add_co_ci_u32_e64 v66, null, s11, v48, vcc_lo            // 0000001C1C78: D5207C42 01AA600B
	.long 0xd7006a47                                           // 0000001C1C80: D7006A47
	v_cndmask_b32_e32 v1, s10, v86, vcc_lo                     // 0000001C1C84: 0202AC0A
	v_add_co_ci_u32_e64 v72, null, s11, v87, vcc_lo            // 0000001C1C88: D5207C48 01AAAE0B
	s_clause 0x9                                               // 0000001C1C90: BF850009
	global_load_u16 v99, v[63:64], off                         // 0000001C1C94: DC4A0000 637C003F
	global_load_u16 v98, v[55:56], off                         // 0000001C1C9C: DC4A0000 627C0037
	global_load_u16 v101, v[65:66], off                        // 0000001C1CA4: DC4A0000 657C0041
	global_load_u16 v100, v[67:68], off                        // 0000001C1CAC: DC4A0000 647C0043
	global_load_u16 v102, v[71:72], off offset:32              // 0000001C1CB4: DC4A0020 667C0047
	global_load_u16 v94, v[63:64], off offset:32               // 0000001C1CBC: DC4A0020 5E7C003F
	global_load_u16 v93, v[55:56], off offset:32               // 0000001C1CC4: DC4A0020 5D7C0037
	global_load_u16 v96, v[65:66], off offset:32               // 0000001C1CCC: DC4A0020 607C0041
	global_load_u16 v95, v[67:68], off offset:32               // 0000001C1CD4: DC4A0020 5F7C0043
	global_load_u16 v97, v[71:72], off offset:64               // 0000001C1CDC: DC4A0040 617C0047
	v_add_f32_e32 v8, v89, v8                                  // 0000001C1CE4: 06101159
	v_add_f32_e32 v7, v169, v7                                 // 0000001C1CE8: 060E0FA9
	v_add_f32_dpp v83, v83, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1CEC: 06A6A6FA FF096453
	v_add_f32_dpp v81, v81, v81 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1CF4: 06A2A2FA FF096451
	v_add_f32_dpp v78, v78, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1CFC: 069C9CFA FF09644E
	v_add_f32_dpp v8, v8, v8 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1D04: 061010FA FF096208
	v_add_f32_dpp v7, v7, v7 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1D0C: 060E0EFA FF096207
	v_add_f32_dpp v89, v83, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1D14: 06B2A6FA FF096853
	v_add_f32_dpp v88, v81, v81 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1D1C: 06B0A2FA FF096851
	v_add_f32_dpp v81, v78, v78 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1D24: 06A29CFA FF09684E
	v_add_f32_dpp v8, v8, v8 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1D2C: 061010FA FF096408
	v_add_f32_dpp v7, v7, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1D34: 060E0EFA FF096407
	v_div_scale_f32 v109, null, v89, v89, 1.0                  // 0000001C1D3C: D6FC7C6D 03CAB359
	v_div_scale_f32 v110, null, v88, v88, 1.0                  // 0000001C1D44: D6FC7C6E 03CAB158
	v_div_scale_f32 v115, null, v81, v81, 1.0                  // 0000001C1D4C: D6FC7C73 03CAA351
	v_add_f32_dpp v107, v8, v8 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1D54: 06D610FA FF096808
	v_add_f32_dpp v108, v7, v7 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1D5C: 06D80EFA FF096807
	.long 0xd7000507                                           // 0000001C1D64: D7000507
	v_cndmask_b32_e32 v1, s12, v15, vcc_lo                     // 0000001C1D68: 02021E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001C1D6C: BF8700B1
	v_add_co_ci_u32_e64 v8, null, s13, v16, s5                 // 0000001C1D70: D5207C08 0016200D
	v_rcp_f32_e32 v91, v109                                    // 0000001C1D78: 7EB6556D
	.long 0xd700050f                                           // 0000001C1D7C: D700050F
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 0000001C1D80: 02022E0C
	v_add_co_ci_u32_e64 v16, null, s13, v24, s5                // 0000001C1D84: D5207C10 0016300D
	.long 0xd7000517                                           // 0000001C1D8C: D7000517
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 0000001C1D90: 02023E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C1D94: BF8700A1
	v_add_co_ci_u32_e64 v24, null, s13, v32, s5                // 0000001C1D98: D5207C18 0016400D
	.long 0xd700051f                                           // 0000001C1DA0: D700051F
	v_cndmask_b32_e32 v1, s12, v39, vcc_lo                     // 0000001C1DA4: 02024E0C
	v_add_co_ci_u32_e64 v32, null, s13, v40, s5                // 0000001C1DA8: D5207C20 0016500D
	.long 0xd7000527                                           // 0000001C1DB0: D7000527
	v_cndmask_b32_e32 v1, s12, v47, vcc_lo                     // 0000001C1DB4: 02025E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C1DB8: BF8700A1
	v_add_co_ci_u32_e64 v40, null, s13, v48, s5                // 0000001C1DBC: D5207C28 0016600D
	.long 0xd700052f                                           // 0000001C1DC4: D700052F
	v_cndmask_b32_e32 v1, s12, v86, vcc_lo                     // 0000001C1DC8: 0202AC0C
	v_add_co_ci_u32_e64 v48, null, s13, v87, s5                // 0000001C1DCC: D5207C30 0016AE0D
	s_clause 0x1f                                              // 0000001C1DD4: BF85001F
	global_load_u16 v78, v[69:70], off offset:96               // 0000001C1DD8: DC4A0060 4E7C0045
	global_load_u16 v86, v[69:70], off offset:128              // 0000001C1DE0: DC4A0080 567C0045
	global_load_u16 v87, v[69:70], off offset:160              // 0000001C1DE8: DC4A00A0 577C0045
	global_load_u16 v92, v[69:70], off offset:192              // 0000001C1DF0: DC4A00C0 5C7C0045
	global_load_u16 v69, v[69:70], off offset:224              // 0000001C1DF8: DC4A00E0 457C0045
	global_load_u16 v138, v[55:56], off offset:64              // 0000001C1E00: DC4A0040 8A7C0037
	global_load_u16 v133, v[55:56], off offset:96              // 0000001C1E08: DC4A0060 857C0037
	global_load_u16 v128, v[55:56], off offset:128             // 0000001C1E10: DC4A0080 807C0037
	global_load_u16 v124, v[55:56], off offset:160             // 0000001C1E18: DC4A00A0 7C7C0037
	global_load_u16 v104, v[55:56], off offset:192             // 0000001C1E20: DC4A00C0 687C0037
	global_load_u16 v137, v[63:64], off offset:64              // 0000001C1E28: DC4A0040 897C003F
	global_load_u16 v132, v[63:64], off offset:96              // 0000001C1E30: DC4A0060 847C003F
	global_load_u16 v127, v[63:64], off offset:128             // 0000001C1E38: DC4A0080 7F7C003F
	global_load_u16 v123, v[63:64], off offset:160             // 0000001C1E40: DC4A00A0 7B7C003F
	global_load_u16 v70, v[63:64], off offset:192              // 0000001C1E48: DC4A00C0 467C003F
	global_load_u16 v56, v[55:56], off offset:224              // 0000001C1E50: DC4A00E0 387C0037
	global_load_u16 v140, v[67:68], off offset:64              // 0000001C1E58: DC4A0040 8C7C0043
	global_load_u16 v135, v[67:68], off offset:96              // 0000001C1E60: DC4A0060 877C0043
	global_load_u16 v130, v[67:68], off offset:128             // 0000001C1E68: DC4A0080 827C0043
	global_load_u16 v126, v[67:68], off offset:160             // 0000001C1E70: DC4A00A0 7E7C0043
	global_load_u16 v106, v[67:68], off offset:192             // 0000001C1E78: DC4A00C0 6A7C0043
	global_load_u16 v55, v[63:64], off offset:224              // 0000001C1E80: DC4A00E0 377C003F
	global_load_u16 v139, v[65:66], off offset:64              // 0000001C1E88: DC4A0040 8B7C0041
	global_load_u16 v134, v[65:66], off offset:96              // 0000001C1E90: DC4A0060 867C0041
	global_load_u16 v129, v[65:66], off offset:128             // 0000001C1E98: DC4A0080 817C0041
	global_load_u16 v125, v[65:66], off offset:160             // 0000001C1EA0: DC4A00A0 7D7C0041
	global_load_u16 v105, v[65:66], off offset:192             // 0000001C1EA8: DC4A00C0 697C0041
	global_load_u16 v63, v[67:68], off offset:224              // 0000001C1EB0: DC4A00E0 3F7C0043
	global_load_u16 v141, v[71:72], off offset:96              // 0000001C1EB8: DC4A0060 8D7C0047
	global_load_u16 v136, v[71:72], off offset:128             // 0000001C1EC0: DC4A0080 887C0047
	global_load_u16 v131, v[71:72], off offset:160             // 0000001C1EC8: DC4A00A0 837C0047
	global_load_u16 v68, v[71:72], off offset:192              // 0000001C1ED0: DC4A00C0 447C0047
	s_clause 0x1                                               // 0000001C1ED8: BF850001
	global_load_u16 v67, v[71:72], off offset:224              // 0000001C1EDC: DC4A00E0 437C0047
	global_load_u16 v64, v[65:66], off offset:224              // 0000001C1EE4: DC4A00E0 407C0041
	v_fma_f32 v71, -v109, v91, 1.0                             // 0000001C1EEC: D6130047 23CAB76D
	v_add_f32_e32 v84, v170, v76                               // 0000001C1EF4: 06A899AA
	v_div_scale_f32 v117, null, v108, v108, 1.0                // 0000001C1EF8: D6FC7C75 03CAD96C
	v_div_scale_f32 v118, null, v107, v107, 1.0                // 0000001C1F00: D6FC7C76 03CAD76B
	v_rcp_f32_e32 v90, v110                                    // 0000001C1F08: 7EB4556E
	v_fmac_f32_e32 v91, v71, v91                               // 0000001C1F0C: 56B6B747
	v_add_f32_dpp v84, v84, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1F10: 06A8A8FA FF096254
	v_rcp_f32_e32 v122, v117                                   // 0000001C1F18: 7EF45575
	v_rcp_f32_e32 v121, v118                                   // 0000001C1F1C: 7EF25576
	v_div_scale_f32 v119, vcc_lo, 1.0, v108, 1.0               // 0000001C1F20: D6FC6A77 03CAD8F2
	v_div_scale_f32 v120, s4, 1.0, v107, 1.0                   // 0000001C1F28: D6FC0478 03CAD6F2
	v_add_f32_dpp v84, v84, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1F30: 06A8A8FA FF096454
	v_div_scale_f32 v112, s2, 1.0, v89, 1.0                    // 0000001C1F38: D6FC0270 03CAB2F2
	v_div_scale_f32 v116, s1, 1.0, v81, 1.0                    // 0000001C1F40: D6FC0174 03CAA2F2
	v_fma_f32 v72, -v110, v90, 1.0                             // 0000001C1F48: D6130048 23CAB56E
	v_div_scale_f32 v113, s3, 1.0, v88, 1.0                    // 0000001C1F50: D6FC0371 03CAB0F2
	v_add_f32_dpp v83, v84, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001C1F58: 06A6A8FA FF096854
	v_fma_f32 v65, -v117, v122, 1.0                            // 0000001C1F60: D6130041 23CAF575
	v_fma_f32 v66, -v118, v121, 1.0                            // 0000001C1F68: D6130042 23CAF376
	v_fmac_f32_e32 v90, v72, v90                               // 0000001C1F70: 56B4B548
	v_rcp_f32_e32 v84, v115                                    // 0000001C1F74: 7EA85573
	v_div_scale_f32 v111, null, v83, v83, 1.0                  // 0000001C1F78: D6FC7C6F 03CAA753
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001C1F80: BF870233
	v_dual_fmac_f32 v122, v65, v122 :: v_dual_fmac_f32 v121, v66, v121// 0000001C1F84: C800F541 7A78F342
	v_div_scale_f32 v114, s0, 1.0, v83, 1.0                    // 0000001C1F8C: D6FC0072 03CAA6F2
	v_dual_mul_f32 v71, v112, v91 :: v_dual_mul_f32 v72, v113, v90// 0000001C1F94: C8C6B770 4748B571
	v_rcp_f32_e32 v85, v111                                    // 0000001C1F9C: 7EAA556F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001C1FA0: BF870313
	v_dual_mul_f32 v65, v119, v122 :: v_dual_mul_f32 v66, v120, v121// 0000001C1FA4: C8C6F577 4142F378
	v_fma_f32 v143, -v115, v84, 1.0                            // 0000001C1FAC: D613008F 23CAA973
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C1FB4: BF870223
	v_fma_f32 v146, -v109, v71, v112                           // 0000001C1FB8: D6130092 25C28F6D
	v_fma_f32 v147, -v110, v72, v113                           // 0000001C1FC0: D6130093 25C6916E
	v_fma_f32 v144, -v117, v65, v119                           // 0000001C1FC8: D6130090 25DE8375
	v_fma_f32 v145, -v118, v66, v120                           // 0000001C1FD0: D6130091 25E28576
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C1FD8: BF870214
	v_dual_fmac_f32 v84, v143, v84 :: v_dual_fmac_f32 v71, v146, v91// 0000001C1FDC: C800A98F 5446B792
	v_fmac_f32_e32 v72, v147, v90                              // 0000001C1FE4: 5690B593
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C1FE8: BF870215
	v_fma_f32 v142, -v111, v85, 1.0                            // 0000001C1FEC: D613008E 23CAAB6F
	v_dual_fmac_f32 v65, v144, v122 :: v_dual_fmac_f32 v66, v145, v121// 0000001C1FF4: C800F590 4142F391
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C1FFC: BF870224
	v_mul_f32_e32 v143, v116, v84                              // 0000001C2000: 111EA974
	v_fma_f32 v109, -v109, v71, v112                           // 0000001C2004: D613006D 25C28F6D
	v_fmac_f32_e32 v85, v142, v85                              // 0000001C200C: 56AAAB8E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C2010: BF870004
	v_fma_f32 v117, -v117, v65, v119                           // 0000001C2014: D6130075 25DE8375
	v_fma_f32 v118, -v118, v66, v120                           // 0000001C201C: D6130076 25E28576
	v_fma_f32 v144, -v115, v143, v116                          // 0000001C2024: D6130090 25D31F73
	.long 0x7f003880                                           // 0000001C202C: 7F003880
	v_mul_f32_e32 v142, v114, v85                              // 0000001C2030: 111CAB72
	v_div_fmas_f32 v65, v117, v122, v65                        // 0000001C2034: D6370041 0506F575
	s_mov_b32 vcc_lo, s4                                       // 0000001C203C: BEEA0004
	v_div_fmas_f32 v117, v118, v121, v66                       // 0000001C2040: D6370075 050AF376
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C2048: BF870193
	v_fma_f32 v148, -v111, v142, v114                          // 0000001C204C: D6130094 25CB1D6F
	v_div_fixup_f32 v66, v65, v108, 1.0                        // 0000001C2054: D6270042 03CAD941
	v_fma_f32 v108, -v110, v72, v113                           // 0000001C205C: D613006C 25C6916E
	.long 0x7f9e3980                                           // 0000001C2064: 7F9E3980
	v_div_fixup_f32 v65, v117, v107, 1.0                       // 0000001C2068: D6270041 03CAD775
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001C2070: BF870234
	v_dual_fmac_f32 v142, v148, v85 :: v_dual_mul_f32 v57, v57, v66// 0000001C2074: C806AB94 8E388539
	v_fmac_f32_e32 v143, v144, v84                             // 0000001C207C: 571EA990
	.long 0x7f983980                                           // 0000001C2080: 7F983980
	v_mul_f32_e32 v58, v58, v65                                // 0000001C2084: 1074833A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C2088: BF870004
	v_fma_f32 v107, -v111, v142, v114                          // 0000001C208C: D613006B 25CB1D6F
	v_mul_f32_e32 v111, v49, v66                               // 0000001C2094: 10DE8531
	v_fma_f32 v110, -v115, v143, v116                          // 0000001C2098: D613006E 25D31F73
	.long 0x7f9a3980                                           // 0000001C20A0: 7F9A3980
	.long 0x7f963980                                           // 0000001C20A4: 7F963980
	.long 0x7f943980                                           // 0000001C20A8: 7F943980
	v_dual_mul_f32 v33, v33, v66 :: v_dual_mul_f32 v26, v26, v65// 0000001C20AC: C8C68521 211A831A
	v_mul_f32_e32 v25, v25, v66                                // 0000001C20B4: 10328519
	v_mul_f32_e32 v17, v17, v66                                // 0000001C20B8: 10228511
	v_mul_f32_e32 v9, v9, v66                                  // 0000001C20BC: 10128509
	v_dual_mul_f32 v1, v1, v66 :: v_dual_mul_f32 v18, v18, v65 // 0000001C20C0: C8C68501 01128312
	v_mul_f32_e32 v42, v42, v65                                // 0000001C20C8: 1054832A
	v_mul_f32_e32 v34, v34, v65                                // 0000001C20CC: 10448322
	v_mul_f32_e32 v10, v10, v65                                // 0000001C20D0: 1014830A
	v_mul_f32_e32 v2, v2, v65                                  // 0000001C20D4: 10048302
	s_waitcnt vmcnt(47)                                        // 0000001C20D8: BF89BFF7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000001C20DC: 30929290
	s_waitcnt vmcnt(46)                                        // 0000001C20E0: BF89BBF7
	v_dual_mul_f32 v80, v50, v65 :: v_dual_lshlrev_b32 v49, 16, v80// 0000001C20E4: C8E28332 5030A090
	s_waitcnt vmcnt(45)                                        // 0000001C20EC: BF89B7F7
	v_lshlrev_b32_e32 v50, 16, v82                             // 0000001C20F0: 3064A490
	s_waitcnt vmcnt(44)                                        // 0000001C20F4: BF89B3F7
	v_lshlrev_b32_e32 v82, 16, v103                            // 0000001C20F8: 30A4CE90
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C20FC: BF870001
	v_mul_f32_e32 v114, 0xbfb8aa3b, v82                        // 0000001C2100: 10E4A4FF BFB8AA3B
	v_mul_f32_e32 v112, 0xbfb8aa3b, v73                        // 0000001C2108: 10E092FF BFB8AA3B
	v_mul_f32_e32 v103, 0xbfb8aa3b, v49                        // 0000001C2110: 10CE62FF BFB8AA3B
	v_mul_f32_e32 v113, 0xbfb8aa3b, v50                        // 0000001C2118: 10E264FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001C2120: 7C3C62FF 42CE8ED0
	v_rndne_f32_e32 v152, v114                                 // 0000001C2128: 7F304772
	v_fma_f32 v117, 0xbfb8aa3b, v73, -v112                     // 0000001C212C: D6130075 85C292FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v49, -v103                     // 0000001C2138: D6130073 859E62FF BFB8AA3B
	v_rndne_f32_e32 v116, v103                                 // 0000001C2144: 7EE84767
	s_waitcnt vmcnt(40)                                        // 0000001C2148: BF89A3F7
	v_lshlrev_b32_e32 v100, 16, v100                           // 0000001C214C: 30C8C890
	v_lshlrev_b32_e32 v98, 16, v98                             // 0000001C2150: 30C4C490
	v_rndne_f32_e32 v118, v112                                 // 0000001C2154: 7EEC4770
	v_lshlrev_b32_e32 v101, 16, v101                           // 0000001C2158: 30CACA90
	v_lshlrev_b32_e32 v99, 16, v99                             // 0000001C215C: 30C6C690
	s_waitcnt vmcnt(37)                                        // 0000001C2160: BF8997F7
	v_lshlrev_b32_e32 v93, 16, v93                             // 0000001C2164: 30BABA90
	v_dual_mul_f32 v121, 0xbfb8aa3b, v100 :: v_dual_lshlrev_b32 v102, 16, v102// 0000001C2168: C8E2C8FF 7966CC90 BFB8AA3B
	v_mul_f32_e32 v119, 0xbfb8aa3b, v98                        // 0000001C2174: 10EEC4FF BFB8AA3B
	v_fma_f32 v151, 0xbfb8aa3b, v82, -v114                     // 0000001C217C: D6130097 85CAA4FF BFB8AA3B
	v_dual_fmac_f32 v115, 0xb2a5705f, v49 :: v_dual_sub_f32 v112, v112, v118// 0000001C2188: C80A62FF 7370ED70 B2A5705F
	v_dual_fmac_f32 v117, 0xb2a5705f, v73 :: v_dual_sub_f32 v114, v114, v152// 0000001C2194: C80A92FF 75733172 B2A5705F
	v_dual_sub_f32 v103, v103, v116 :: v_dual_mul_f32 v122, 0xbfb8aa3b, v101// 0000001C21A0: C946E967 677ACAFF BFB8AA3B
	v_mul_f32_e32 v120, 0xbfb8aa3b, v99                        // 0000001C21AC: 10F0C6FF BFB8AA3B
	v_fma_f32 v145, 0xbfb8aa3b, v50, -v113                     // 0000001C21B4: D6130091 85C664FF BFB8AA3B
	v_rndne_f32_e32 v146, v113                                 // 0000001C21C0: 7F244771
	v_dual_mul_f32 v147, 0xbfb8aa3b, v93 :: v_dual_mul_f32 v144, 0xbfb8aa3b, v102// 0000001C21C4: C8C6BAFF 9390CCFF BFB8AA3B
	v_fma_f32 v154, 0xbfb8aa3b, v98, -v119                     // 0000001C21D0: D613009A 85DEC4FF BFB8AA3B
	v_dual_add_f32 v112, v112, v117 :: v_dual_add_f32 v103, v103, v115// 0000001C21DC: C908EB70 7066E767
	v_fma_f32 v156, 0xbfb8aa3b, v99, -v120                     // 0000001C21E4: D613009C 85E2C6FF BFB8AA3B
	v_fma_f32 v158, 0xbfb8aa3b, v100, -v121                    // 0000001C21F0: D613009E 85E6C8FF BFB8AA3B
	v_rndne_f32_e32 v163, v144                                 // 0000001C21FC: 7F464790
	v_fmac_f32_e32 v145, 0xb2a5705f, v50                       // 0000001C2200: 572264FF B2A5705F
	v_sub_f32_e32 v113, v113, v146                             // 0000001C2208: 08E32571
	v_fmac_f32_e32 v154, 0xb2a5705f, v98                       // 0000001C220C: 5734C4FF B2A5705F
	v_exp_f32_e32 v103, v103                                   // 0000001C2214: 7ECE4B67
	s_waitcnt vmcnt(35)                                        // 0000001C2218: BF898FF7
	v_lshlrev_b32_e32 v95, 16, v95                             // 0000001C221C: 30BEBE90
	s_waitcnt vmcnt(34)                                        // 0000001C2220: BF898BF7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000001C2224: 30C2C290
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000001C2228: 30C0C090
	v_cvt_i32_f32_e32 v116, v116                               // 0000001C222C: 7EE81174
	v_rndne_f32_e32 v155, v119                                 // 0000001C2230: 7F364777
	v_fma_f32 v160, 0xbfb8aa3b, v101, -v122                    // 0000001C2234: D61300A0 85EACAFF BFB8AA3B
	v_rndne_f32_e32 v161, v122                                 // 0000001C2240: 7F42477A
	v_fma_f32 v162, 0xbfb8aa3b, v102, -v144                    // 0000001C2244: D61300A2 8642CCFF BFB8AA3B
	v_fmac_f32_e32 v156, 0xb2a5705f, v99                       // 0000001C2250: 5738C6FF B2A5705F
	v_fmac_f32_e32 v158, 0xb2a5705f, v100                      // 0000001C2258: 573CC8FF B2A5705F
	v_dual_sub_f32 v144, v144, v163 :: v_dual_add_f32 v113, v113, v145// 0000001C2260: C9494790 90712371
	v_exp_f32_e32 v112, v112                                   // 0000001C2268: 7EE04B70
	v_dual_mul_f32 v149, 0xbfb8aa3b, v95 :: v_dual_lshlrev_b32 v94, 16, v94// 0000001C226C: C8E2BEFF 955EBC90 BFB8AA3B
	v_dual_mul_f32 v153, 0xbfb8aa3b, v97 :: v_dual_mul_f32 v150, 0xbfb8aa3b, v96// 0000001C2278: C8C6C2FF 9996C0FF BFB8AA3B
	v_cvt_i32_f32_e32 v118, v118                               // 0000001C2284: 7EEC1176
	v_rndne_f32_e32 v157, v120                                 // 0000001C2288: 7F3A4778
	v_dual_fmac_f32 v151, 0xb2a5705f, v82 :: v_dual_fmac_f32 v160, 0xb2a5705f, v101// 0000001C228C: C800A4FF 97A0CAFF B2A5705F
	v_dual_sub_f32 v115, v119, v155 :: v_dual_sub_f32 v122, v122, v161// 0000001C2298: C94B3777 737B437A
	v_exp_f32_e32 v113, v113                                   // 0000001C22A0: 7EE24B71
	.long 0xd71c0067                                           // 0000001C22A4: D71C0067
	v_cndmask_b32_e32 v1, v103, v116, vcc_lo                   // 0000001C22A8: 0202E967
	v_mul_f32_e32 v148, 0xbfb8aa3b, v94                        // 0000001C22AC: 1128BCFF BFB8AA3B
	v_rndne_f32_e32 v159, v121                                 // 0000001C22B4: 7F3E4779
	v_cvt_i32_f32_e32 v146, v146                               // 0000001C22B8: 7F241192
	v_fma_f32 v164, 0xbfb8aa3b, v93, -v147                     // 0000001C22BC: D61300A4 864EBAFF BFB8AA3B
	v_fma_f32 v168, 0xbfb8aa3b, v95, -v149                     // 0000001C22C8: D61300A8 8656BEFF BFB8AA3B
	v_fma_f32 v170, 0xbfb8aa3b, v96, -v150                     // 0000001C22D4: D61300AA 865AC0FF BFB8AA3B
	v_rndne_f32_e32 v171, v150                                 // 0000001C22E0: 7F564796
	v_dual_sub_f32 v119, v120, v157 :: v_dual_fmac_f32 v162, 0xb2a5705f, v102// 0000001C22E4: C9413B78 77A2CCFF B2A5705F
	v_dual_add_f32 v122, v122, v160 :: v_dual_cndmask_b32 v103, 0, v103// 0000001C22F0: C913417A 7A66CE80
	.long 0xd71c0070                                           // 0000001C22F8: D71C0070
	v_cndmask_b32_e32 v1, v112, v118, vcc_lo                   // 0000001C22FC: 0202ED70
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000001C2300: 7C3C92FF 42CE8ED0
	v_rndne_f32_e32 v165, v147                                 // 0000001C2308: 7F4A4793
	v_fma_f32 v166, 0xbfb8aa3b, v94, -v148                     // 0000001C230C: D61300A6 8652BCFF BFB8AA3B
	v_dual_sub_f32 v121, v121, v159 :: v_dual_fmac_f32 v164, 0xb2a5705f, v93// 0000001C2318: C9413F79 79A4BAFF B2A5705F
	v_dual_fmac_f32 v168, 0xb2a5705f, v95 :: v_dual_add_f32 v115, v115, v154// 0000001C2324: C808BEFF A8733573 B2A5705F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001C2330: BF870002
	v_dual_fmac_f32 v170, 0xb2a5705f, v96 :: v_dual_add_f32 v121, v121, v158// 0000001C2334: C808C0FF AA793D79 B2A5705F
	v_dual_sub_f32 v150, v150, v171 :: v_dual_add_f32 v119, v119, v156// 0000001C2340: C9495796 96773977
	.long 0xd71c0071                                           // 0000001C2348: D71C0071
	v_cndmask_b32_e32 v1, v113, v146, vcc_lo                   // 0000001C234C: 02032571
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 0000001C2350: 02E0E080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v50                  // 0000001C2354: 7C3C64FF 42CE8ED0
	v_dual_sub_f32 v145, v147, v165 :: v_dual_fmac_f32 v166, 0xb2a5705f, v94// 0000001C235C: C9414B93 91A6BCFF B2A5705F
	v_add_f32_e32 v144, v144, v162                             // 0000001C2368: 07214590
	v_dual_add_f32 v150, v150, v170 :: v_dual_cndmask_b32 v113, 0, v113// 0000001C236C: C9135596 9670E280
	v_exp_f32_e32 v115, v115                                   // 0000001C2374: 7EE64B73
	v_exp_f32_e32 v119, v119                                   // 0000001C2378: 7EEE4B77
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001C237C: 7C3662FF C2B17218
	v_cvt_i32_f32_e32 v117, v155                               // 0000001C2384: 7EEA119B
	v_cvt_i32_f32_e32 v120, v157                               // 0000001C2388: 7EF0119D
	v_add_f32_e32 v145, v145, v164                             // 0000001C238C: 07234991
	v_exp_f32_e32 v144, v144                                   // 0000001C2390: 7F204B90
	v_cndmask_b32_e32 v49, 0x7f800000, v103, vcc_lo            // 0000001C2394: 0262CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000001C239C: 7C3692FF C2B17218
	v_cvt_i32_f32_e32 v155, v159                               // 0000001C23A4: 7F36119F
	v_cvt_i32_f32_e32 v159, v163                               // 0000001C23A8: 7F3E11A3
	v_exp_f32_e32 v121, v121                                   // 0000001C23AC: 7EF24B79
	.long 0xd71c0073                                           // 0000001C23B0: D71C0073
	v_cndmask_b32_e32 v1, v115, v117, vcc_lo                   // 0000001C23B4: 0202EB73
	.long 0xd71c0075                                           // 0000001C23B8: D71C0075
	v_cndmask_b32_e32 v1, v119, v120, vcc_lo                   // 0000001C23BC: 0202F177
	v_cndmask_b32_e32 v73, 0x7f800000, v112, vcc_lo            // 0000001C23C0: 0292E0FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v98                  // 0000001C23C8: 7C3CC4FF 42CE8ED0
	v_exp_f32_e32 v122, v122                                   // 0000001C23D0: 7EF44B7A
	.long 0xd71c0078                                           // 0000001C23D4: D71C0078
	v_cndmask_b32_e32 v1, v144, v159, vcc_lo                   // 0000001C23D8: 02033F90
	v_rndne_f32_e32 v167, v148                                 // 0000001C23DC: 7F4E4794
	v_cvt_i32_f32_e32 v157, v161                               // 0000001C23E0: 7F3A11A1
	v_cndmask_b32_e32 v103, 0, v115, vcc_lo                    // 0000001C23E4: 02CEE680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v99                  // 0000001C23E8: 7C3CC6FF 42CE8ED0
	.long 0xd71c0076                                           // 0000001C23F0: D71C0076
	v_cndmask_b32_e32 v1, v121, v155, vcc_lo                   // 0000001C23F4: 02033779
	v_rndne_f32_e32 v169, v149                                 // 0000001C23F8: 7F524795
	v_sub_f32_e32 v148, v148, v167                             // 0000001C23FC: 09294F94
	v_exp_f32_e32 v145, v145                                   // 0000001C2400: 7F224B91
	v_cndmask_b32_e32 v112, 0, v117, vcc_lo                    // 0000001C2404: 02E0EA80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v100                 // 0000001C2408: 7C3CC8FF 42CE8ED0
	.long 0xd71c0077                                           // 0000001C2410: D71C0077
	v_cndmask_b32_e32 v1, v122, v157, vcc_lo                   // 0000001C2414: 02033B7A
	v_dual_sub_f32 v149, v149, v169 :: v_dual_add_f32 v148, v148, v166// 0000001C2418: C9495395 95954D94
	v_cvt_i32_f32_e32 v147, v165                               // 0000001C2420: 7F2611A5
	v_cndmask_b32_e32 v115, 0, v118, vcc_lo                    // 0000001C2424: 02E6EC80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v101                 // 0000001C2428: 7C3CCAFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C2430: BF870004
	v_add_f32_e32 v149, v149, v168                             // 0000001C2434: 072B5195
	v_exp_f32_e32 v148, v148                                   // 0000001C2438: 7F284B94
	v_exp_f32_e32 v116, v150                                   // 0000001C243C: 7EE84B96
	v_cvt_i32_f32_e32 v161, v167                               // 0000001C2440: 7F4211A7
	v_cndmask_b32_e32 v117, 0, v119, vcc_lo                    // 0000001C2444: 02EAEE80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v102                 // 0000001C2448: 7C3CCCFF 42CE8ED0
	v_cvt_i32_f32_e32 v165, v171                               // 0000001C2450: 7F4A11AB
	v_exp_f32_e32 v149, v149                                   // 0000001C2454: 7F2A4B95
	.long 0xd71c0079                                           // 0000001C2458: D71C0079
	v_cndmask_b32_e32 v1, v145, v147, vcc_lo                   // 0000001C245C: 02032791
	v_cvt_i32_f32_e32 v163, v169                               // 0000001C2460: 7F4611A9
	v_cndmask_b32_e32 v118, 0, v120, vcc_lo                    // 0000001C2464: 02ECF080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v50                  // 0000001C2468: 7C3664FF C2B17218
	.long 0xd71c007a                                           // 0000001C2470: D71C007A
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 0000001C2474: 02034394
	.long 0xd71c0074                                           // 0000001C2478: D71C0074
	v_cndmask_b32_e32 v1, v116, v165, vcc_lo                   // 0000001C247C: 02034B74
	v_add_f32_e32 v120, 1.0, v49                               // 0000001C2480: 06F062F2
	.long 0xd41b0005                                           // 0000001C2484: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v94, vcc_lo              // 0000001C2488: 0202BCFF C2B17218
	v_cndmask_b32_e32 v50, 0x7f800000, v113, vcc_lo            // 0000001C2490: 0264E2FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v93                  // 0000001C2498: 7C3CBAFF 42CE8ED0
	.long 0xd71c0090                                           // 0000001C24A0: D71C0090
	v_cndmask_b32_e32 v1, v149, v163, vcc_lo                   // 0000001C24A4: 02034795
	v_cndmask_b32_e32 v113, 0, v121, vcc_lo                    // 0000001C24A8: 02E2F280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v94                  // 0000001C24AC: 7C3CBCFF 42CE8ED0
	v_div_scale_f32 v121, null, v120, v120, v57                // 0000001C24B4: D6FC7C79 04E6F178
	v_cndmask_b32_e32 v119, 0, v122, vcc_lo                    // 0000001C24BC: 02EEF480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v95                  // 0000001C24C0: 7C3CBEFF 42CE8ED0
	v_cndmask_b32_e32 v49, 0, v144, vcc_lo                     // 0000001C24C8: 02632080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000001C24CC: 7C3CC0FF 42CE8ED0
	v_cndmask_b32_e32 v116, 0, v116, vcc_lo                    // 0000001C24D4: 02E8E880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v98                  // 0000001C24D8: 7C36C4FF C2B17218
	v_cndmask_b32_e32 v98, 0x7f800000, v103, vcc_lo            // 0000001C24E0: 02C4CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v99                  // 0000001C24E8: 7C36C6FF C2B17218
	v_rcp_f32_e32 v103, v121                                   // 0000001C24F0: 7ECE5579
	v_cndmask_b32_e64 v94, 0x7f800000, v119, s5                // 0000001C24F4: D501005E 0016EEFF 7F800000
	.long 0xd41b0005                                           // 0000001C2500: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v95, vcc_lo              // 0000001C2504: 0202BEFF C2B17218
	v_dual_add_f32 v98, 1.0, v98 :: v_dual_cndmask_b32 v99, 0x7f800000, v112// 0000001C250C: C912C4F2 6262E0FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v100                 // 0000001C2518: 7C36C8FF C2B17218
	v_dual_add_f32 v73, 1.0, v73 :: v_dual_cndmask_b32 v100, 0x7f800000, v115// 0000001C2520: C91292F2 4964E6FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C252C: BF870121
	v_div_scale_f32 v122, null, v73, v73, v58                  // 0000001C2530: D6FC7C7A 04EA9349
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v101                 // 0000001C2538: 7C36CAFF C2B17218
	v_rcp_f32_e32 v112, v122                                   // 0000001C2540: 7EE0557A
	v_cndmask_b32_e32 v101, 0x7f800000, v117, vcc_lo           // 0000001C2544: 02CAEAFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v102                 // 0000001C254C: 7C36CCFF C2B17218
	v_cndmask_b32_e32 v102, 0x7f800000, v118, vcc_lo           // 0000001C2554: 02CCECFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v93                  // 0000001C255C: 7C36BAFF C2B17218
	v_div_scale_f32 v118, s4, v58, v73, v58                    // 0000001C2564: D6FC0476 04EA933A
	v_cndmask_b32_e64 v95, 0x7f800000, v49, s5                 // 0000001C256C: D501005F 001662FF 7F800000
	.long 0xd41b0005                                           // 0000001C2578: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v96, vcc_lo              // 0000001C257C: 0202C0FF C2B17218
	v_dual_add_f32 v102, 1.0, v102 :: v_dual_cndmask_b32 v93, 0x7f800000, v113// 0000001C2584: C912CCF2 665CE2FF 7F800000
	v_div_scale_f32 v117, vcc_lo, v57, v120, v57               // 0000001C2590: D6FC6A75 04E6F139
	v_add_f32_e32 v115, 1.0, v50                               // 0000001C2598: 06E664F2
	v_fma_f32 v50, -v121, v103, 1.0                            // 0000001C259C: D6130032 23CACF79
	v_fma_f32 v113, -v122, v112, 1.0                           // 0000001C25A4: D6130071 23CAE17A
	v_div_scale_f32 v119, null, v102, v102, v80                // 0000001C25AC: D6FC7C77 0542CD66
	v_cndmask_b32_e64 v96, 0x7f800000, v116, s5                // 0000001C25B4: D5010060 0016E8FF 7F800000
	v_dual_add_f32 v94, 1.0, v94 :: v_dual_add_f32 v95, 1.0, v95// 0000001C25C0: C908BCF2 5E5EBEF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C25C8: BF870214
	v_dual_fmac_f32 v103, v50, v103 :: v_dual_fmac_f32 v112, v113, v112// 0000001C25CC: C800CF32 6770E171
	v_rcp_f32_e32 v146, v119                                   // 0000001C25D4: 7F245577
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C25D8: BF870111
	v_mul_f32_e32 v50, v117, v103                              // 0000001C25DC: 1064CF75
	v_mul_f32_e32 v144, v118, v112                             // 0000001C25E0: 1120E176
	v_div_scale_f32 v113, null, v115, v115, v111               // 0000001C25E4: D6FC7C71 05BEE773
	v_div_scale_f32 v116, s5, v111, v115, v111                 // 0000001C25EC: D6FC0574 05BEE76F
	v_add_f32_e32 v93, 1.0, v93                                // 0000001C25F4: 06BABAF2
	v_fma_f32 v49, -v121, v50, v117                            // 0000001C25F8: D6130031 25D66579
	v_fma_f32 v147, -v122, v144, v118                          // 0000001C2600: D6130093 25DB217A
	v_rcp_f32_e32 v145, v113                                   // 0000001C2608: 7F225571
	v_add_f32_e32 v99, 1.0, v99                                // 0000001C260C: 06C6C6F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C2610: BF870193
	v_fmac_f32_e32 v50, v49, v103                              // 0000001C2614: 5664CF31
	v_fmac_f32_e32 v144, v147, v112                            // 0000001C2618: 5720E193
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C261C: BF870112
	v_fma_f32 v117, -v121, v50, v117                           // 0000001C2620: D6130075 25D66579
	v_fma_f32 v118, -v122, v144, v118                          // 0000001C2628: D6130076 25DB217A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C2630: BF870225
	v_fma_f32 v49, -v113, v145, 1.0                            // 0000001C2634: D6130031 23CB2371
	v_fma_f32 v121, -v119, v146, 1.0                           // 0000001C263C: D6130079 23CB2577
	v_div_fmas_f32 v103, v117, v103, v50                       // 0000001C2644: D6370067 04CACF75
	s_mov_b32 vcc_lo, s4                                       // 0000001C264C: BEEA0004
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C2650: BF870003
	v_fmac_f32_e32 v145, v49, v145                             // 0000001C2654: 57232331
	v_div_fmas_f32 v112, v118, v112, v144                      // 0000001C2658: D6370070 0642E176
	s_mov_b32 vcc_lo, s2                                       // 0000001C2660: BEEA0002
	v_fmac_f32_e32 v146, v121, v146                            // 0000001C2664: 57252579
	v_div_fmas_f32 v50, v109, v91, v71                         // 0000001C2668: D6370032 051EB76D
	s_mov_b32 vcc_lo, s3                                       // 0000001C2670: BEEA0003
	v_div_fixup_f32 v57, v103, v120, v57                       // 0000001C2674: D6270039 04E6F167
	v_div_fmas_f32 v71, v108, v90, v72                         // 0000001C267C: D6370047 0522B56C
	v_div_scale_f32 v72, s2, v80, v102, v80                    // 0000001C2684: D6FC0248 0542CD50
	v_div_fixup_f32 v50, v50, v89, 1.0                         // 0000001C268C: D6270032 03CAB332
	v_add_f32_e32 v90, 1.0, v100                               // 0000001C2694: 06B4C8F2
	v_add_f32_e32 v96, 1.0, v96                                // 0000001C2698: 06C0C0F2
	v_div_fixup_f32 v49, v71, v88, 1.0                         // 0000001C269C: D6270031 03CAB147
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001C26A4: BF870244
	v_dual_mul_f32 v88, v116, v145 :: v_dual_mul_f32 v59, v59, v50// 0000001C26A8: C8C72374 583A653B
	v_add_f32_e32 v71, 1.0, v101                               // 0000001C26B0: 068ECAF2
	v_mul_f32_e32 v103, v51, v50                               // 0000001C26B4: 10CE6533
	.long 0x7e9e39b9                                           // 0000001C26B8: 7E9E39B9
	v_fma_f32 v91, -v113, v88, v116                            // 0000001C26BC: D613005B 25D2B171
	v_mul_f32_e32 v89, v72, v146                               // 0000001C26C4: 10B32548
	v_div_scale_f32 v100, null, v98, v98, v59                  // 0000001C26C8: D6FC7C64 04EEC562
	v_div_fixup_f32 v58, v112, v73, v58                        // 0000001C26D0: D627003A 04EA9370
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C26D8: BF870214
	v_dual_fmac_f32 v88, v91, v145 :: v_dual_and_b32 v79, 1, v79// 0000001C26DC: C825235B 584E9E81
	v_fma_f32 v101, -v119, v89, v72                            // 0000001C26E4: D6130065 2522B377
	v_mul_f32_e32 v60, v60, v49                                // 0000001C26EC: 1078633C
	v_rcp_f32_e32 v91, v100                                    // 0000001C26F0: 7EB65564
	.long 0x7e0039ba                                           // 0000001C26F4: 7E0039BA
	v_fma_f32 v109, -v113, v88, v116                           // 0000001C26F8: D613006D 25D2B171
	v_fmac_f32_e32 v89, v101, v146                             // 0000001C2700: 56B32565
	v_div_scale_f32 v108, null, v99, v99, v60                  // 0000001C2704: D6FC7C6C 04F2C763
	v_mul_f32_e32 v113, v52, v49                               // 0000001C270C: 10E26334
	v_div_scale_f32 v116, vcc_lo, v59, v98, v59                // 0000001C2710: D6FC6A74 04EEC53B
	v_div_scale_f32 v122, s4, v103, v93, v103                  // 0000001C2718: D6FC047A 059EBB67
	v_div_scale_f32 v117, null, v93, v93, v103                 // 0000001C2720: D6FC7C75 059EBB5D
	v_rcp_f32_e32 v101, v108                                   // 0000001C2728: 7ECA556C
	v_fma_f32 v51, -v100, v91, 1.0                             // 0000001C272C: D6130033 23CAB764
	v_fma_f32 v72, -v119, v89, v72                             // 0000001C2734: D6130048 2522B377
	v_add3_u32 v57, v57, v79, 0x7fff                           // 0000001C273C: D6550039 03FE9F39 00007FFF
	v_rcp_f32_e32 v112, v117                                   // 0000001C2748: 7EE05575
	v_dual_mul_f32 v43, v43, v50 :: v_dual_mul_f32 v44, v44, v49// 0000001C274C: C8C6652B 2B2C632C
	v_dual_mul_f32 v36, v36, v49 :: v_dual_mul_f32 v35, v35, v50// 0000001C2754: C8C66324 24226523
	v_mul_f32_e32 v28, v28, v49                                // 0000001C275C: 1038631C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001C2760: BF870246
	v_fma_f32 v52, -v108, v101, 1.0                            // 0000001C2764: D6130034 23CACB6C
	v_dual_mul_f32 v20, v20, v49 :: v_dual_mul_f32 v27, v27, v50// 0000001C276C: C8C66314 141A651B
	v_dual_mul_f32 v12, v12, v49 :: v_dual_mul_f32 v19, v19, v50// 0000001C2774: C8C6630C 0C126513
	v_mul_f32_e32 v4, v4, v49                                  // 0000001C277C: 10086304
	v_fmac_f32_e32 v101, v52, v101                             // 0000001C2780: 56CACB34
	v_fmac_f32_e32 v91, v51, v91                               // 0000001C2784: 56B6B733
	v_div_scale_f32 v51, s3, v60, v99, v60                     // 0000001C2788: D6FC0333 04F2C73C
	v_mul_f32_e32 v11, v11, v50                                // 0000001C2790: 1016650B
	v_mul_f32_e32 v3, v3, v50                                  // 0000001C2794: 10066503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C2798: BF870093
	v_mul_f32_e32 v118, v51, v101                              // 0000001C279C: 10ECCB33
	v_fma_f32 v121, -v108, v118, v51                           // 0000001C27A0: D6130079 24CEED6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C27A8: BF870121
	v_fmac_f32_e32 v118, v121, v101                            // 0000001C27AC: 56ECCB79
	v_mul_f32_e32 v52, v116, v91                               // 0000001C27B0: 1068B774
	v_fma_f32 v51, -v108, v118, v51                            // 0000001C27B4: D6130033 24CEED6C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C27BC: BF870092
	v_fma_f32 v120, -v100, v52, v116                           // 0000001C27C0: D6130078 25D26964
	v_fmac_f32_e32 v52, v120, v91                              // 0000001C27C8: 5668B778
	v_fma_f32 v120, -v117, v112, 1.0                           // 0000001C27CC: D6130078 23CAE175
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C27D4: BF870092
	v_fma_f32 v100, -v100, v52, v116                           // 0000001C27D8: D6130064 25D26964
	v_div_fmas_f32 v91, v100, v91, v52                         // 0000001C27E0: D637005B 04D2B764
	s_mov_b32 vcc_lo, s3                                       // 0000001C27E8: BEEA0003
	v_div_fmas_f32 v100, v51, v101, v118                       // 0000001C27EC: D6370064 05DACB33
	s_mov_b32 vcc_lo, s0                                       // 0000001C27F4: BEEA0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001C27F8: BF870002
	v_div_fixup_f32 v59, v91, v98, v59                         // 0000001C27FC: D627003B 04EEC55B
	v_div_fmas_f32 v51, v107, v85, v142                        // 0000001C2804: D6370033 063AAB6B
	s_mov_b32 vcc_lo, s1                                       // 0000001C280C: BEEA0001
	v_div_fixup_f32 v60, v100, v99, v60                        // 0000001C2810: D627003C 04F2C764
	v_div_fmas_f32 v84, v110, v84, v143                        // 0000001C2818: D6370054 063EA96E
	v_and_b32_e32 v85, 1, v0                                   // 0000001C2820: 36AA0081
	v_div_fixup_f32 v52, v51, v83, 1.0                         // 0000001C2824: D6270034 03CAA733
	.long 0x7e9a39bb                                           // 0000001C282C: 7E9A39BB
	.long 0x7e0039bc                                           // 0000001C2830: 7E0039BC
	v_div_fixup_f32 v51, v84, v81, 1.0                         // 0000001C2834: D6270033 03CAA354
	v_add3_u32 v58, v58, v85, 0x7fff                           // 0000001C283C: D655003A 03FEAB3A 00007FFF
	v_mul_f32_e32 v61, v61, v52                                // 0000001C2848: 107A693D
	s_clause 0x1                                               // 0000001C284C: BF850001
	global_store_d16_hi_b16 v[7:8], v57, off                   // 0000001C2850: DC960000 007C3907
	global_store_d16_hi_b16 v[7:8], v58, off offset:1024       // 0000001C2858: DC960400 007C3A07
	v_mul_f32_e32 v62, v62, v51                                // 0000001C2860: 107C673E
	v_div_scale_f32 v73, null, v94, v94, v113                  // 0000001C2864: D6FC7C49 05C6BD5E
	v_div_scale_f32 v121, s6, v113, v94, v113                  // 0000001C286C: D6FC0679 05C6BD71
	v_mul_f32_e32 v54, v54, v51                                // 0000001C2874: 106C6736
	v_div_scale_f32 v85, null, v90, v90, v61                   // 0000001C2878: D6FC7C55 04F6B55A
	v_mul_f32_e32 v53, v53, v52                                // 0000001C2880: 106A6935
	v_rcp_f32_e32 v119, v73                                    // 0000001C2884: 7EEE5549
	v_div_scale_f32 v99, vcc_lo, v61, v90, v61                 // 0000001C2888: D6FC6A63 04F6B53D
	v_div_scale_f32 v116, null, v96, v96, v54                  // 0000001C2890: D6FC7C74 04DAC160
	v_mul_f32_e32 v37, v37, v52                                // 0000001C2898: 104A6925
	v_div_scale_f32 v100, null, v95, v95, v53                  // 0000001C289C: D6FC7C64 04D6BF5F
	v_div_scale_f32 v110, s1, v53, v95, v53                    // 0000001C28A4: D6FC016E 04D6BF35
	v_dual_mul_f32 v22, v22, v51 :: v_dual_mul_f32 v29, v29, v52// 0000001C28AC: C8C66716 161C691D
	v_mul_f32_e32 v14, v14, v51                                // 0000001C28B4: 101C670E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001C28B8: BF870314
	v_rcp_f32_e32 v107, v100                                   // 0000001C28BC: 7ED65564
	v_fma_f32 v144, -v73, v119, 1.0                            // 0000001C28C0: D6130090 23CAEF49
	v_mul_f32_e32 v21, v21, v52                                // 0000001C28C8: 102A6915
	v_mul_f32_e32 v13, v13, v52                                // 0000001C28CC: 101A690D
	v_dual_mul_f32 v5, v5, v52 :: v_dual_mul_f32 v6, v6, v51   // 0000001C28D0: C8C66905 05066706
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C28D8: BF870094
	v_fmac_f32_e32 v119, v144, v119                            // 0000001C28DC: 56EEEF90
	v_dual_fmac_f32 v112, v120, v112 :: v_dual_mul_f32 v81, v121, v119// 0000001C28E0: C806E178 7050EF79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C28E8: BF870111
	v_mul_f32_e32 v83, v122, v112                              // 0000001C28EC: 10A6E17A
	v_fma_f32 v84, -v73, v81, v121                             // 0000001C28F0: D6130054 25E6A349
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C28F8: BF870092
	v_fma_f32 v79, -v117, v83, v122                            // 0000001C28FC: D613004F 25EAA775
	v_fmac_f32_e32 v83, v79, v112                              // 0000001C2904: 56A6E14F
	v_div_scale_f32 v79, null, v71, v71, v62                   // 0000001C2908: D6FC7C4F 04FA8F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001C2910: BF870291
	v_rcp_f32_e32 v91, v79                                     // 0000001C2914: 7EB6554F
	v_fma_f32 v98, -v79, v91, 1.0                              // 0000001C2918: D6130062 23CAB74F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001C2920: BF870131
	v_dual_fmac_f32 v91, v98, v91 :: v_dual_and_b32 v98, 1, v0 // 0000001C2924: C824B762 5B620081
	v_fmac_f32_e32 v81, v84, v119                              // 0000001C292C: 56A2EF54
	v_rcp_f32_e32 v84, v85                                     // 0000001C2930: 7EA85555
	v_add3_u32 v60, v60, v98, 0x7fff                           // 0000001C2934: D655003C 03FEC53C 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001C2940: BF870292
	v_fma_f32 v58, -v73, v81, v121                             // 0000001C2944: D613003A 25E6A349
	v_fma_f32 v73, -v85, v84, 1.0                              // 0000001C294C: D6130049 23CAA955
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C2954: BF8700A1
	v_fmac_f32_e32 v84, v73, v84                               // 0000001C2958: 56A8A949
	v_div_scale_f32 v73, s0, v62, v71, v62                     // 0000001C295C: D6FC0049 04FA8F3E
	v_dual_mul_f32 v101, v99, v84 :: v_dual_mul_f32 v108, v73, v91// 0000001C2964: C8C6A963 656CB749
	v_fma_f32 v57, -v117, v83, v122                            // 0000001C296C: D6130039 25EAA775
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C2974: BF870092
	v_fma_f32 v117, -v79, v108, v73                            // 0000001C2978: D6130075 2526D94F
	v_dual_fmac_f32 v108, v117, v91 :: v_dual_and_b32 v77, 1, v77// 0000001C2980: C824B775 6C4C9A81
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C2988: BF870001
	v_add3_u32 v59, v59, v77, 0x7fff                           // 0000001C298C: D655003B 03FE9B3B 00007FFF
	v_fma_f32 v77, -v85, v101, v99                             // 0000001C2998: D613004D 258ECB55
	global_store_d16_hi_b16 v[15:16], v59, off                 // 0000001C29A0: DC960000 007C3B0F
	v_fma_f32 v59, -v100, v107, 1.0                            // 0000001C29A8: D613003B 23CAD764
	global_store_d16_hi_b16 v[23:24], v60, off                 // 0000001C29B0: DC960000 007C3C17
	v_fmac_f32_e32 v107, v59, v107                             // 0000001C29B8: 56D6D73B
	v_fmac_f32_e32 v101, v77, v84                              // 0000001C29BC: 56CAA94D
	v_fma_f32 v59, -v79, v108, v73                             // 0000001C29C0: D613003B 2526D94F
	v_rcp_f32_e32 v77, v116                                    // 0000001C29C8: 7E9A5574
	s_waitcnt vmcnt(23)                                        // 0000001C29CC: BF895FF7
	v_lshlrev_b32_e32 v79, 16, v137                            // 0000001C29D0: 309F1290
	v_mul_f32_e32 v41, v41, v66                                // 0000001C29D4: 10528529
	v_fma_f32 v60, -v85, v101, v99                             // 0000001C29D8: D613003C 258ECB55
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000001C29E0: BF870141
	v_div_fmas_f32 v60, v60, v84, v101                         // 0000001C29E4: D637003C 0596A93C
	s_mov_b32 vcc_lo, s0                                       // 0000001C29EC: BEEA0000
	v_div_fmas_f32 v59, v59, v91, v108                         // 0000001C29F0: D637003B 05B2B73B
	s_mov_b32 vcc_lo, s2                                       // 0000001C29F8: BEEA0002
	v_div_fixup_f32 v60, v60, v90, v61                         // 0000001C29FC: D627003C 04F6B53C
	v_div_fmas_f32 v72, v72, v146, v89                         // 0000001C2A04: D6370048 05672548
	s_mov_b32 vcc_lo, s5                                       // 0000001C2A0C: BEEA0005
	v_div_fixup_f32 v59, v59, v71, v62                         // 0000001C2A10: D627003B 04FA8F3B
	v_div_fmas_f32 v61, v109, v145, v88                        // 0000001C2A18: D637003D 0563236D
	.long 0x7e9839bc                                           // 0000001C2A20: 7E9839BC
	v_div_fixup_f32 v62, v72, v102, v80                        // 0000001C2A24: D627003E 0542CD48
	s_mov_b32 vcc_lo, s4                                       // 0000001C2A2C: BEEA0004
	.long 0x7e0039bb                                           // 0000001C2A30: 7E0039BB
	v_div_fixup_f32 v61, v61, v115, v111                       // 0000001C2A34: D627003D 05BEE73D
	v_and_b32_e32 v72, 1, v76                                  // 0000001C2A3C: 36909881
	.long 0x7e9639be                                           // 0000001C2A40: 7E9639BE
	v_div_fmas_f32 v57, v57, v112, v83                         // 0000001C2A44: D6370039 054EE139
	v_and_b32_e32 v71, 1, v0                                   // 0000001C2A4C: 368E0081
	.long 0x7e0039bd                                           // 0000001C2A50: 7E0039BD
	v_add3_u32 v60, v60, v72, 0x7fff                           // 0000001C2A54: D655003C 03FE913C 00007FFF
	v_fma_f32 v72, 0xbfb8aa3b, v97, -v153                      // 0000001C2A60: D6130048 8666C2FF BFB8AA3B
	s_mov_b32 vcc_lo, s6                                       // 0000001C2A6C: BEEA0006
	v_add3_u32 v59, v59, v71, 0x7fff                           // 0000001C2A70: D655003B 03FE8F3B 00007FFF
	v_div_fmas_f32 v58, v58, v119, v81                         // 0000001C2A7C: D637003A 0546EF3A
	v_div_fixup_f32 v57, v57, v93, v103                        // 0000001C2A84: D6270039 059EBB39
	v_dual_fmac_f32 v72, 0xb2a5705f, v97 :: v_dual_and_b32 v73, 1, v75// 0000001C2A8C: C824C2FF 48489681 B2A5705F
	v_and_b32_e32 v75, 1, v0                                   // 0000001C2A98: 36960081
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C2A9C: BF870004
	v_div_fixup_f32 v58, v58, v94, v113                        // 0000001C2AA0: D627003A 05C6BD3A
	s_clause 0x1                                               // 0000001C2AA8: BF850001
	global_store_d16_hi_b16 v[31:32], v60, off                 // 0000001C2AAC: DC960000 007C3C1F
	global_store_d16_hi_b16 v[39:40], v59, off                 // 0000001C2AB4: DC960000 007C3B27
	v_fma_f32 v60, -v116, v77, 1.0                             // 0000001C2ABC: D613003C 23CA9B74
	v_add3_u32 v62, v62, v73, 0x7fff                           // 0000001C2AC4: D655003E 03FE933E 00007FFF
	v_add3_u32 v61, v61, v75, 0x7fff                           // 0000001C2AD0: D655003D 03FE973D 00007FFF
	s_clause 0x1                                               // 0000001C2ADC: BF850001
	global_store_d16_hi_b16 v[7:8], v61, off offset:32         // 0000001C2AE0: DC960020 007C3D07
	global_store_d16_hi_b16 v[47:48], v62, off offset:32       // 0000001C2AE8: DC960020 007C3E2F
	v_add_f32_e32 v61, v114, v151                              // 0000001C2AF0: 067B2F72
	.long 0x7e0039ba                                           // 0000001C2AF4: 7E0039BA
	.long 0x7e9439b9                                           // 0000001C2AF8: 7E9439B9
	v_rndne_f32_e32 v73, v153                                  // 0000001C2AFC: 7E924799
	v_fmac_f32_e32 v77, v60, v77                               // 0000001C2B00: 569A9B3C
	v_exp_f32_e32 v60, v61                                     // 0000001C2B04: 7E784B3D
	v_div_scale_f32 v61, s0, v54, v96, v54                     // 0000001C2B08: D6FC003D 04DAC136
	v_and_b32_e32 v59, 1, v0                                   // 0000001C2B10: 36760081
	v_dual_sub_f32 v74, v153, v73 :: v_dual_and_b32 v71, 1, v74// 0000001C2B14: C9649399 4A469481
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v82                  // 0000001C2B1C: 7C3CA4FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C2B24: BF870004
	v_mul_f32_e32 v76, v61, v77                                // 0000001C2B28: 10989B3D
	v_mul_f32_e32 v62, v110, v107                              // 0000001C2B2C: 107CD76E
	v_add3_u32 v58, v58, v59, 0x7fff                           // 0000001C2B30: D655003A 03FE773A 00007FFF
	v_cvt_i32_f32_e32 v59, v152                                // 0000001C2B3C: 7E761198
	v_add_f32_e32 v72, v74, v72                                // 0000001C2B40: 0690914A
	v_add3_u32 v57, v57, v71, 0x7fff                           // 0000001C2B44: D6550039 03FE8F39 00007FFF
	v_fma_f32 v75, -v100, v62, v110                            // 0000001C2B50: D613004B 25BA7D64
	v_mul_f32_e32 v80, 0xbfb8aa3b, v79                         // 0000001C2B58: 10A09EFF BFB8AA3B
	.long 0xd71c003b                                           // 0000001C2B60: D71C003B
	v_cndmask_b32_e32 v1, v60, v59, vcc_lo                     // 0000001C2B64: 0202773C
	v_fma_f32 v60, -v116, v76, v61                             // 0000001C2B68: D613003C 24F69974
	v_exp_f32_e32 v71, v72                                     // 0000001C2B70: 7E8E4B48
	v_fmac_f32_e32 v62, v75, v107                              // 0000001C2B74: 567CD74B
	global_store_d16_hi_b16 v[15:16], v57, off offset:32       // 0000001C2B78: DC960020 007C390F
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 0000001C2B80: 02767680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v82                  // 0000001C2B84: 7C36A4FF C2B17218
	v_fmac_f32_e32 v76, v60, v77                               // 0000001C2B8C: 56989B3C
	v_fma_f32 v72, -v100, v62, v110                            // 0000001C2B90: D6130048 25BA7D64
	v_cvt_i32_f32_e32 v60, v73                                 // 0000001C2B98: 7E781149
	global_store_d16_hi_b16 v[23:24], v58, off offset:32       // 0000001C2B9C: DC960020 007C3A17
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 0000001C2BA4: 027676FF 7F800000
	s_mov_b32 vcc_lo, s1                                       // 0000001C2BAC: BEEA0001
	v_fma_f32 v61, -v116, v76, v61                             // 0000001C2BB0: D613003D 24F69974
	v_div_fmas_f32 v62, v72, v107, v62                         // 0000001C2BB8: D637003E 04FAD748
	.long 0xd71c003c                                           // 0000001C2BC0: D71C003C
	v_cndmask_b32_e32 v1, v71, v60, vcc_lo                     // 0000001C2BC4: 02027947
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000001C2BC8: 7C3CC2FF 42CE8ED0
	.long 0x7f903980                                           // 0000001C2BD0: 7F903980
	v_fma_f32 v82, 0xbfb8aa3b, v79, -v80                       // 0000001C2BD4: D6130052 85429EFF BFB8AA3B
	v_div_fixup_f32 v53, v62, v95, v53                         // 0000001C2BE0: D6270035 04D6BF3E
	v_rndne_f32_e32 v83, v80                                   // 0000001C2BE8: 7EA64750
	v_cndmask_b32_e32 v60, 0, v60, vcc_lo                      // 0000001C2BEC: 02787880
	s_mov_b32 vcc_lo, s0                                       // 0000001C2BF0: BEEA0000
	v_div_fmas_f32 v61, v61, v77, v76                          // 0000001C2BF4: D637003D 05329B3D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001C2BFC: 7C36C2FF C2B17218
	.long 0x7e9039b5                                           // 0000001C2C04: 7E9039B5
	v_sub_f32_e32 v80, v80, v83                                // 0000001C2C08: 08A0A750
	v_fmac_f32_e32 v82, 0xb2a5705f, v79                        // 0000001C2C0C: 56A49EFF B2A5705F
	v_div_fixup_f32 v54, v61, v96, v54                         // 0000001C2C14: D6270036 04DAC13D
	v_dual_cndmask_b32 v60, 0x7f800000, v60 :: v_dual_lshlrev_b32 v61, 16, v138// 0000001C2C1C: CA6278FF 3C3D1490 7F800000
	v_and_b32_e32 v72, 1, v72                                  // 0000001C2C28: 36909081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C2C2C: BF870214
	v_add_f32_e32 v80, v80, v82                                // 0000001C2C30: 06A0A550
	.long 0x7e0039b6                                           // 0000001C2C34: 7E0039B6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001C2C38: BF870234
	v_add_f32_e32 v60, 1.0, v60                                // 0000001C2C3C: 067878F2
	v_mul_f32_e32 v62, 0xbfb8aa3b, v61                         // 0000001C2C40: 107C7AFF BFB8AA3B
	v_add3_u32 v53, v53, v72, 0x7fff                           // 0000001C2C48: D6550035 03FE9135 00007FFF
	v_and_b32_e32 v77, 1, v0                                   // 0000001C2C54: 369A0081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C2C58: BF870214
	v_div_scale_f32 v58, null, v60, v60, v42                   // 0000001C2C5C: D6FC7C3A 04AA793C
	v_fma_f32 v75, 0xbfb8aa3b, v61, -v62                       // 0000001C2C64: D613004B 84FA7AFF BFB8AA3B
	v_rndne_f32_e32 v76, v62                                   // 0000001C2C70: 7E98473E
	global_store_d16_hi_b16 v[31:32], v53, off offset:32       // 0000001C2C74: DC960020 007C351F
	v_add3_u32 v54, v54, v77, 0x7fff                           // 0000001C2C7C: D6550036 03FE9B36 00007FFF
	v_rcp_f32_e32 v74, v58                                     // 0000001C2C88: 7E94553A
	v_sub_f32_e32 v62, v62, v76                                // 0000001C2C8C: 087C993E
	v_cvt_i32_f32_e32 v76, v76                                 // 0000001C2C90: 7E98114C
	global_store_d16_hi_b16 v[39:40], v54, off offset:32       // 0000001C2C94: DC960020 007C3627
	v_fma_f32 v81, -v58, v74, 1.0                              // 0000001C2C9C: D6130051 23CA953A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C2CA4: BF870091
	v_dual_add_f32 v59, 1.0, v59 :: v_dual_fmac_f32 v74, v81, v74// 0000001C2CA8: C90076F2 3B4A9551
	v_div_scale_f32 v71, null, v59, v59, v41                   // 0000001C2CB0: D6FC7C47 04A6773B
	v_div_scale_f32 v81, s0, v42, v60, v42                     // 0000001C2CB8: D6FC0051 04AA792A
	v_fmac_f32_e32 v75, 0xb2a5705f, v61                        // 0000001C2CC0: 56967AFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C2CC8: BF870113
	v_rcp_f32_e32 v57, v71                                     // 0000001C2CCC: 7E725547
	v_mul_f32_e32 v84, v81, v74                                // 0000001C2CD0: 10A89551
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001C2CD4: BF8701A2
	v_add_f32_e32 v62, v62, v75                                // 0000001C2CD8: 067C973E
	.long 0xd41e0001                                           // 0000001C2CDC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v61, vcc_lo              // 0000001C2CE0: 02027AFF 42CE8ED0
	v_fma_f32 v72, -v58, v84, v81                              // 0000001C2CE8: D6130048 2546A93A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001C2CF0: BF870313
	v_exp_f32_e32 v62, v62                                     // 0000001C2CF4: 7E7C4B3E
	v_fma_f32 v73, -v71, v57, 1.0                              // 0000001C2CF8: D6130049 23CA7347
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001C2D00: BF8701A2
	v_fmac_f32_e32 v84, v72, v74                               // 0000001C2D04: 56A89548
	v_cvt_i32_f32_e32 v72, v83                                 // 0000001C2D08: 7E901153
	v_fmac_f32_e32 v57, v73, v57                               // 0000001C2D0C: 56727349
	v_div_scale_f32 v73, vcc_lo, v41, v59, v41                 // 0000001C2D10: D6FC6A49 04A67729
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001C2D18: BF8701B5
	.long 0xd71c003e                                           // 0000001C2D1C: D71C003E
	v_cndmask_b32_e32 v1, v62, v76, vcc_lo                     // 0000001C2D20: 0202993E
	v_exp_f32_e32 v76, v80                                     // 0000001C2D24: 7E984B50
	v_fma_f32 v58, -v58, v84, v81                              // 0000001C2D28: D613003A 2546A93A
	v_mul_f32_e32 v75, v73, v57                                // 0000001C2D30: 10967349
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001C2D34: BF8701A3
	v_cndmask_b32_e64 v62, 0, v62, s1                          // 0000001C2D38: D501003E 00067C80
	.long 0xd41b0001                                           // 0000001C2D40: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v61, vcc_lo              // 0000001C2D44: 02027AFF C2B17218
	v_fma_f32 v77, -v71, v75, v73                              // 0000001C2D4C: D613004D 25269747
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001C2D54: BF870292
	v_cndmask_b32_e64 v61, 0x7f800000, v62, s1                 // 0000001C2D58: D501003D 00067CFF 7F800000
	.long 0xd71c003e                                           // 0000001C2D64: D71C003E
	v_cndmask_b32_e32 v1, v76, v72, vcc_lo                     // 0000001C2D68: 0202914C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C2D6C: BF870093
	v_fmac_f32_e32 v75, v77, v57                               // 0000001C2D70: 5696734D
	v_fma_f32 v71, -v71, v75, v73                              // 0000001C2D74: D6130047 25269747
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C2D7C: BF870121
	v_div_fmas_f32 v57, v71, v57, v75                          // 0000001C2D80: D6370039 052E7347
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v79                  // 0000001C2D88: 7C3C9EFF 42CE8ED0
	v_div_fixup_f32 v41, v57, v59, v41                         // 0000001C2D90: D6270029 04A67739
	v_cndmask_b32_e32 v62, 0, v62, vcc_lo                      // 0000001C2D98: 027C7C80
	s_mov_b32 vcc_lo, s0                                       // 0000001C2D9C: BEEA0000
	.long 0x7f763980                                           // 0000001C2DA0: 7F763980
	v_div_fmas_f32 v58, v58, v74, v84                          // 0000001C2DA4: D637003A 0552953A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v79                  // 0000001C2DAC: 7C369EFF C2B17218
	v_add_f32_e32 v61, 1.0, v61                                // 0000001C2DB4: 067A7AF2
	.long 0x7e7639a9                                           // 0000001C2DB8: 7E7639A9
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C2DBC: BF870224
	v_div_fixup_f32 v42, v58, v60, v42                         // 0000001C2DC0: D627002A 04AA793A
	v_cndmask_b32_e32 v62, 0x7f800000, v62, vcc_lo             // 0000001C2DC8: 027C7CFF 7F800000
	v_div_scale_f32 v71, null, v61, v61, v43                   // 0000001C2DD0: D6FC7C47 04AE7B3D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C2DD8: BF870113
	.long 0x7e0039aa                                           // 0000001C2DDC: 7E0039AA
	v_rcp_f32_e32 v53, v71                                     // 0000001C2DE0: 7E6A5547
	s_waitcnt vmcnt(17)                                        // 0000001C2DE4: BF8947F7
	v_lshlrev_b32_e32 v60, 16, v140                            // 0000001C2DE8: 30791890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C2DEC: BF870092
	v_dual_add_f32 v58, 1.0, v62 :: v_dual_and_b32 v75, 1, v0  // 0000001C2DF0: C9247CF2 3A4A0081
	v_add3_u32 v42, v42, v75, 0x7fff                           // 0000001C2DF8: D655002A 03FE972A 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C2E04: BF870095
	v_fma_f32 v62, -v71, v53, 1.0                              // 0000001C2E08: D613003E 23CA6B47
	v_fmac_f32_e32 v53, v62, v53                               // 0000001C2E10: 566A6B3E
	v_mul_f32_e32 v57, 0xbfb8aa3b, v60                         // 0000001C2E14: 107278FF BFB8AA3B
	v_div_scale_f32 v54, null, v58, v58, v44                   // 0000001C2E1C: D6FC7C36 04B2753A
	v_div_scale_f32 v62, vcc_lo, v43, v61, v43                 // 0000001C2E24: D6FC6A3E 04AE7B2B
	.long 0xd41e0001                                           // 0000001C2E2C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v60, vcc_lo              // 0000001C2E30: 020278FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C2E38: BF870214
	v_fma_f32 v73, 0xbfb8aa3b, v60, -v57                       // 0000001C2E3C: D6130049 84E678FF BFB8AA3B
	v_rcp_f32_e32 v72, v54                                     // 0000001C2E48: 7E905536
	v_rndne_f32_e32 v74, v57                                   // 0000001C2E4C: 7E944739
	s_waitcnt vmcnt(11)                                        // 0000001C2E50: BF892FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C2E54: BF870092
	v_dual_fmac_f32 v73, 0xb2a5705f, v60 :: v_dual_lshlrev_b32 v76, 16, v139// 0000001C2E58: C82278FF 494D1690 B2A5705F
	v_mul_f32_e32 v77, 0xbfb8aa3b, v76                         // 0000001C2E64: 109A98FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001C2E6C: BF8701A5
	v_fma_f32 v79, -v54, v72, 1.0                              // 0000001C2E70: D613004F 23CA9136
	v_sub_f32_e32 v57, v57, v74                                // 0000001C2E78: 08729539
	v_fma_f32 v80, 0xbfb8aa3b, v76, -v77                       // 0000001C2E7C: D6130050 853698FF BFB8AA3B
	v_and_b32_e32 v59, 1, v59                                  // 0000001C2E88: 36767681
	v_rndne_f32_e32 v81, v77                                   // 0000001C2E8C: 7EA2474D
	v_fmac_f32_e32 v72, v79, v72                               // 0000001C2E90: 5690914F
	v_div_scale_f32 v79, s0, v44, v58, v44                     // 0000001C2E94: D6FC004F 04B2752C
	v_dual_add_f32 v57, v57, v73 :: v_dual_fmac_f32 v80, 0xb2a5705f, v76// 0000001C2E9C: C9009339 395098FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C2EA8: BF870224
	v_sub_f32_e32 v77, v77, v81                                // 0000001C2EAC: 089AA34D
	v_add3_u32 v41, v41, v59, 0x7fff                           // 0000001C2EB0: D6550029 03FE7729 00007FFF
	v_mul_f32_e32 v82, v79, v72                                // 0000001C2EBC: 10A4914F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C2EC0: BF870004
	v_exp_f32_e32 v57, v57                                     // 0000001C2EC4: 7E724B39
	v_cvt_i32_f32_e32 v74, v74                                 // 0000001C2EC8: 7E94114A
	v_add_f32_e32 v77, v77, v80                                // 0000001C2ECC: 069AA14D
	global_store_d16_hi_b16 v[7:8], v41, off offset:64         // 0000001C2ED0: DC960040 007C2907
	v_fma_f32 v59, -v54, v82, v79                              // 0000001C2ED8: D613003B 253EA536
	v_mul_f32_e32 v73, v62, v53                                // 0000001C2EE0: 10926B3E
	global_store_d16_hi_b16 v[47:48], v42, off offset:64       // 0000001C2EE4: DC960040 007C2A2F
	v_fmac_f32_e32 v82, v59, v72                               // 0000001C2EEC: 56A4913B
	v_fma_f32 v75, -v71, v73, v62                              // 0000001C2EF0: D613004B 24FA9347
	.long 0xd71c0039                                           // 0000001C2EF8: D71C0039
	v_cndmask_b32_e32 v1, v57, v74, vcc_lo                     // 0000001C2EFC: 02029539
	v_exp_f32_e32 v74, v77                                     // 0000001C2F00: 7E944B4D
	v_cvt_i32_f32_e32 v59, v81                                 // 0000001C2F04: 7E761151
	v_fma_f32 v54, -v54, v82, v79                              // 0000001C2F08: D6130036 253EA536
	v_fmac_f32_e32 v73, v75, v53                               // 0000001C2F10: 56926B4B
	v_cndmask_b32_e64 v57, 0, v57, s1                          // 0000001C2F14: D5010039 00067280
	.long 0xd41b0001                                           // 0000001C2F1C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v60, vcc_lo              // 0000001C2F20: 020278FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001C2F28: BF870293
	v_fma_f32 v62, -v71, v73, v62                              // 0000001C2F2C: D613003E 24FA9347
	.long 0xd71c003b                                           // 0000001C2F34: D71C003B
	v_cndmask_b32_e32 v1, v74, v59, vcc_lo                     // 0000001C2F38: 0202774A
	s_waitcnt vmcnt(5)                                         // 0000001C2F3C: BF8917F7
	v_lshlrev_b32_e32 v74, 16, v141                            // 0000001C2F40: 30951A90
	v_cndmask_b32_e64 v57, 0x7f800000, v57, s1                 // 0000001C2F44: D5010039 000672FF 7F800000
	v_div_fmas_f32 v53, v62, v53, v73                          // 0000001C2F50: D6370035 05266B3E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v76                  // 0000001C2F58: 7C3C98FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C2F60: BF870194
	v_mul_f32_e32 v75, 0xbfb8aa3b, v74                         // 0000001C2F64: 109694FF BFB8AA3B
	v_div_fixup_f32 v43, v53, v61, v43                         // 0000001C2F6C: D627002B 04AE7B35
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 0000001C2F74: 02767680
	s_mov_b32 vcc_lo, s0                                       // 0000001C2F78: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001C2F7C: BF8701B3
	v_fma_f32 v77, 0xbfb8aa3b, v74, -v75                       // 0000001C2F80: D613004D 852E94FF BFB8AA3B
	v_div_fmas_f32 v54, v54, v72, v82                          // 0000001C2F8C: D6370036 054A9136
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v76                  // 0000001C2F94: 7C3698FF C2B17218
	v_fmac_f32_e32 v77, 0xb2a5705f, v74                        // 0000001C2F9C: 569A94FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C2FA4: BF870003
	v_div_fixup_f32 v41, v54, v58, v44                         // 0000001C2FA8: D6270029 04B27536
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 0000001C2FB0: 027676FF 7F800000
	v_mul_f32_e32 v44, v46, v51                                // 0000001C2FB8: 1058672E
	v_lshlrev_b32_e32 v58, 16, v78                             // 0000001C2FBC: 30749C90
	v_rndne_f32_e32 v78, v75                                   // 0000001C2FC0: 7E9C474B
	.long 0x7e0039a9                                           // 0000001C2FC4: 7E0039A9
	v_add_f32_e32 v54, 1.0, v59                                // 0000001C2FC8: 066C76F2
	.long 0x7e7639ab                                           // 0000001C2FCC: 7E7639AB
	v_mul_f32_e32 v53, 0xbfb8aa3b, v58                         // 0000001C2FD0: 106A74FF BFB8AA3B
	.long 0x7f763980                                           // 0000001C2FD8: 7F763980
	v_sub_f32_e32 v75, v75, v78                                // 0000001C2FDC: 08969D4B
	v_div_scale_f32 v42, null, v54, v54, v44                   // 0000001C2FE0: D6FC7C2A 04B26D36
	.long 0xd41e0001                                           // 0000001C2FE8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v58, vcc_lo              // 0000001C2FEC: 020274FF 42CE8ED0
	v_fma_f32 v71, 0xbfb8aa3b, v58, -v53                       // 0000001C2FF4: D6130047 84D674FF BFB8AA3B
	v_rndne_f32_e32 v72, v53                                   // 0000001C3000: 7E904735
	v_and_b32_e32 v59, 1, v59                                  // 0000001C3004: 36767681
	v_rcp_f32_e32 v62, v42                                     // 0000001C3008: 7E7C552A
	v_add_f32_e32 v75, v75, v77                                // 0000001C300C: 06969B4B
	v_fmac_f32_e32 v71, 0xb2a5705f, v58                        // 0000001C3010: 568E74FF B2A5705F
	v_sub_f32_e32 v53, v53, v72                                // 0000001C3018: 086A9135
	v_cvt_i32_f32_e32 v72, v72                                 // 0000001C301C: 7E901148
	v_add3_u32 v43, v43, v59, 0x7fff                           // 0000001C3020: D655002B 03FE772B 00007FFF
	v_and_b32_e32 v73, 1, v0                                   // 0000001C302C: 36920081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001C3030: BF870294
	v_add_f32_e32 v53, v53, v71                                // 0000001C3034: 066A8F35
	v_fma_f32 v76, -v42, v62, 1.0                              // 0000001C3038: D613004C 23CA7D2A
	v_mul_f32_e32 v45, v45, v52                                // 0000001C3040: 105A692D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C3044: BF870214
	v_add3_u32 v41, v41, v73, 0x7fff                           // 0000001C3048: D6550029 03FE9329 00007FFF
	v_exp_f32_e32 v53, v53                                     // 0000001C3054: 7E6A4B35
	global_store_d16_hi_b16 v[15:16], v43, off offset:64       // 0000001C3058: DC960040 007C2B0F
	v_fmac_f32_e32 v62, v76, v62                               // 0000001C3060: 567C7D4C
	v_div_scale_f32 v76, s0, v44, v54, v44                     // 0000001C3064: D6FC004C 04B26D2C
	global_store_d16_hi_b16 v[23:24], v41, off offset:64       // 0000001C306C: DC960040 007C2917
	v_mul_f32_e32 v79, v76, v62                                // 0000001C3074: 109E7D4C
	.long 0xd71c0035                                           // 0000001C3078: D71C0035
	v_cndmask_b32_e32 v1, v53, v72, vcc_lo                     // 0000001C307C: 02029135
	v_exp_f32_e32 v72, v75                                     // 0000001C3080: 7E904B4B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C3084: BF870112
	v_fma_f32 v59, -v42, v79, v76                              // 0000001C3088: D613003B 25329F2A
	v_cndmask_b32_e64 v53, 0, v53, s1                          // 0000001C3090: D5010035 00066A80
	.long 0xd41b0001                                           // 0000001C3098: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v58, vcc_lo              // 0000001C309C: 020274FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001C30A4: BF8701A3
	v_fmac_f32_e32 v79, v59, v62                               // 0000001C30A8: 569E7D3B
	v_cvt_i32_f32_e32 v59, v78                                 // 0000001C30AC: 7E76114E
	v_cndmask_b32_e64 v53, 0x7f800000, v53, s1                 // 0000001C30B0: D5010035 00066AFF 7F800000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C30BC: BF870003
	v_fma_f32 v42, -v42, v79, v76                              // 0000001C30C0: D613002A 25329F2A
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001C30C8: BF870185
	.long 0xd71c003a                                           // 0000001C30CC: D71C003A
	v_cndmask_b32_e32 v1, v72, v59, vcc_lo                     // 0000001C30D0: 02027748
	v_dual_add_f32 v57, 1.0, v57 :: v_dual_lshlrev_b32 v72, 16, v132// 0000001C30D4: C92272F2 39490890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C30DC: BF870091
	v_div_scale_f32 v60, null, v57, v57, v45                   // 0000001C30E0: D6FC7C3C 04B67339
	v_rcp_f32_e32 v46, v60                                     // 0000001C30E8: 7E5C553C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C30EC: BF870095
	v_fma_f32 v61, -v60, v46, 1.0                              // 0000001C30F0: D613003D 23CA5D3C
	v_fmac_f32_e32 v46, v61, v46                               // 0000001C30F8: 565C5D3D
	v_div_scale_f32 v61, vcc_lo, v45, v57, v45                 // 0000001C30FC: D6FC6A3D 04B6732D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C3104: BF870091
	v_mul_f32_e32 v71, v61, v46                                // 0000001C3108: 108E5D3D
	v_fma_f32 v73, -v60, v71, v61                              // 0000001C310C: D6130049 24F68F3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C3114: BF870121
	v_fmac_f32_e32 v71, v73, v46                               // 0000001C3118: 568E5D49
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 0000001C311C: 109290FF BFB8AA3B
	v_fma_f32 v60, -v60, v71, v61                              // 0000001C3124: D613003C 24F68F3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001C312C: BF8701A2
	v_fma_f32 v75, 0xbfb8aa3b, v72, -v73                       // 0000001C3130: D613004B 852690FF BFB8AA3B
	v_rndne_f32_e32 v76, v73                                   // 0000001C313C: 7E984749
	v_div_fmas_f32 v46, v60, v46, v71                          // 0000001C3140: D637002E 051E5D3C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v74                  // 0000001C3148: 7C3C94FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C3150: BF870214
	v_fmac_f32_e32 v75, 0xb2a5705f, v72                        // 0000001C3154: 569690FF B2A5705F
	v_dual_sub_f32 v73, v73, v76 :: v_dual_cndmask_b32 v58, 0, v58// 0000001C315C: C9529949 493A7480
	s_mov_b32 vcc_lo, s0                                       // 0000001C3164: BEEA0000
	v_div_fixup_f32 v45, v46, v57, v45                         // 0000001C3168: D627002D 04B6732E
	v_div_fmas_f32 v42, v42, v62, v79                          // 0000001C3170: D637002A 053E7D2A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v74                  // 0000001C3178: 7C3694FF C2B17218
	.long 0x7f723980                                           // 0000001C3180: 7F723980
	v_add_f32_e32 v73, v73, v75                                // 0000001C3184: 06929749
	.long 0x7e7239ad                                           // 0000001C3188: 7E7239AD
	v_div_fixup_f32 v42, v42, v54, v44                         // 0000001C318C: D627002A 04B26D2A
	v_cndmask_b32_e32 v58, 0x7f800000, v58, vcc_lo             // 0000001C3194: 027474FF 7F800000
	v_lshlrev_b32_e32 v54, 16, v133                            // 0000001C319C: 306D0A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C31A0: BF870214
	v_and_b32_e32 v57, 1, v57                                  // 0000001C31A4: 36727281
	.long 0x7e0039aa                                           // 0000001C31A8: 7E0039AA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C31AC: BF870214
	v_add_f32_e32 v44, 1.0, v58                                // 0000001C31B0: 065874F2
	v_mul_f32_e32 v46, 0xbfb8aa3b, v54                         // 0000001C31B4: 105C6CFF BFB8AA3B
	.long 0xd41e0001                                           // 0000001C31BC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v54, vcc_lo              // 0000001C31C0: 02026CFF 42CE8ED0
	v_add3_u32 v45, v45, v57, 0x7fff                           // 0000001C31C8: D655002D 03FE732D 00007FFF
	v_and_b32_e32 v71, 1, v0                                   // 0000001C31D4: 368E0081
	v_div_scale_f32 v41, null, v44, v44, v34                   // 0000001C31D8: D6FC7C29 048A592C
	v_fma_f32 v61, 0xbfb8aa3b, v54, -v46                       // 0000001C31E0: D613003D 84BA6CFF BFB8AA3B
	v_rndne_f32_e32 v62, v46                                   // 0000001C31EC: 7E7C472E
	global_store_d16_hi_b16 v[31:32], v45, off offset:64       // 0000001C31F0: DC960040 007C2D1F
	v_add3_u32 v42, v42, v71, 0x7fff                           // 0000001C31F8: D655002A 03FE8F2A 00007FFF
	v_rcp_f32_e32 v60, v41                                     // 0000001C3204: 7E785529
	v_fmac_f32_e32 v61, 0xb2a5705f, v54                        // 0000001C3208: 567A6CFF B2A5705F
	v_sub_f32_e32 v46, v46, v62                                // 0000001C3210: 085C7D2E
	v_cvt_i32_f32_e32 v62, v62                                 // 0000001C3214: 7E7C113E
	v_lshlrev_b32_e32 v45, 16, v135                            // 0000001C3218: 305B0E90
	global_store_d16_hi_b16 v[39:40], v42, off offset:64       // 0000001C321C: DC960040 007C2A27
	v_add_f32_e32 v46, v46, v61                                // 0000001C3224: 065C7B2E
	v_fma_f32 v74, -v41, v60, 1.0                              // 0000001C3228: D613004A 23CA7929
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C3230: BF870092
	v_exp_f32_e32 v46, v46                                     // 0000001C3234: 7E5C4B2E
	v_fmac_f32_e32 v60, v74, v60                               // 0000001C3238: 5678794A
	v_div_scale_f32 v74, s0, v34, v44, v34                     // 0000001C323C: D6FC004A 048A5922
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001C3244: BF870291
	v_mul_f32_e32 v77, v74, v60                                // 0000001C3248: 109A794A
	.long 0xd71c002e                                           // 0000001C324C: D71C002E
	v_cndmask_b32_e32 v1, v46, v62, vcc_lo                     // 0000001C3250: 02027D2E
	v_exp_f32_e32 v62, v73                                     // 0000001C3254: 7E7C4B49
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C3258: BF870112
	v_fma_f32 v57, -v41, v77, v74                              // 0000001C325C: D6130039 252A9B29
	v_cndmask_b32_e64 v46, 0, v46, s1                          // 0000001C3264: D501002E 00065C80
	.long 0xd41b0001                                           // 0000001C326C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v54, vcc_lo              // 0000001C3270: 02026CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001C3278: BF8701A3
	v_fmac_f32_e32 v77, v57, v60                               // 0000001C327C: 569A7939
	v_cvt_i32_f32_e32 v57, v76                                 // 0000001C3280: 7E72114C
	v_cndmask_b32_e64 v46, 0x7f800000, v46, s1                 // 0000001C3284: D501002E 00065CFF 7F800000
	.long 0xd41e0001                                           // 0000001C3290: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v45, vcc_lo              // 0000001C3294: 02025AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C329C: BF870004
	v_fma_f32 v41, -v41, v77, v74                              // 0000001C32A0: D6130029 252A9B29
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 0000001C32A8: BF870205
	.long 0xd71c0036                                           // 0000001C32AC: D71C0036
	v_cndmask_b32_e32 v1, v62, v57, vcc_lo                     // 0000001C32B0: 0202733E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C32B4: BF870124
	v_dual_add_f32 v53, 1.0, v53 :: v_dual_add_f32 v46, 1.0, v46// 0000001C32B8: C9086AF2 352E5CF2
	v_lshlrev_b32_e32 v62, 16, v134                            // 0000001C32C0: 307D0C90
	v_div_scale_f32 v59, null, v53, v53, v33                   // 0000001C32C4: D6FC7C3B 04866B35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C32CC: BF870113
	v_div_scale_f32 v57, null, v46, v46, v35                   // 0000001C32D0: D6FC7C39 048E5D2E
	v_rcp_f32_e32 v43, v59                                     // 0000001C32D8: 7E56553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C32DC: BF870095
	v_fma_f32 v58, -v59, v43, 1.0                              // 0000001C32E0: D613003A 23CA573B
	v_fmac_f32_e32 v43, v58, v43                               // 0000001C32E8: 5656573A
	v_div_scale_f32 v58, vcc_lo, v33, v53, v33                 // 0000001C32EC: D6FC6A3A 04866B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C32F4: BF870091
	v_mul_f32_e32 v61, v58, v43                                // 0000001C32F8: 107A573A
	v_fma_f32 v71, -v59, v61, v58                              // 0000001C32FC: D6130047 24EA7B3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C3304: BF870121
	v_fmac_f32_e32 v61, v71, v43                               // 0000001C3308: 567A5747
	v_mul_f32_e32 v71, 0xbfb8aa3b, v62                         // 0000001C330C: 108E7CFF BFB8AA3B
	v_fma_f32 v58, -v59, v61, v58                              // 0000001C3314: D613003A 24EA7B3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001C331C: BF8701A2
	v_fma_f32 v73, 0xbfb8aa3b, v62, -v71                       // 0000001C3320: D6130049 851E7CFF BFB8AA3B
	v_rndne_f32_e32 v74, v71                                   // 0000001C332C: 7E944747
	v_div_fmas_f32 v43, v58, v43, v61                          // 0000001C3330: D637002B 04F6573A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000001C3338: 7C3C90FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C3340: BF870214
	v_fmac_f32_e32 v73, 0xb2a5705f, v62                        // 0000001C3344: 56927CFF B2A5705F
	v_sub_f32_e32 v71, v71, v74                                // 0000001C334C: 088E9547
	v_cndmask_b32_e32 v54, 0, v54, vcc_lo                      // 0000001C3350: 026C6C80
	s_mov_b32 vcc_lo, s0                                       // 0000001C3354: BEEA0000
	v_div_fixup_f32 v33, v43, v53, v33                         // 0000001C3358: D6270021 04866B2B
	v_div_fmas_f32 v41, v41, v60, v77                          // 0000001C3360: D6370029 05367929
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000001C3368: 7C3690FF C2B17218
	v_mul_f32_e32 v43, 0xbfb8aa3b, v45                         // 0000001C3370: 10565AFF BFB8AA3B
	.long 0x7f6a3980                                           // 0000001C3378: 7F6A3980
	.long 0x7e6a39a1                                           // 0000001C337C: 7E6A39A1
	v_div_fixup_f32 v34, v41, v44, v34                         // 0000001C3380: D6270022 048A5929
	v_cndmask_b32_e32 v54, 0x7f800000, v54, vcc_lo             // 0000001C3388: 026C6CFF 7F800000
	v_rcp_f32_e32 v41, v57                                     // 0000001C3390: 7E525539
	v_fma_f32 v59, 0xbfb8aa3b, v45, -v43                       // 0000001C3394: D613003B 84AE5AFF BFB8AA3B
	v_rndne_f32_e32 v60, v43                                   // 0000001C33A0: 7E78472B
	.long 0x7e0039a2                                           // 0000001C33A4: 7E0039A2
	v_dual_add_f32 v44, 1.0, v54 :: v_dual_and_b32 v53, 1, v53 // 0000001C33A8: C9246CF2 2C346A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C33B0: BF870214
	v_fmac_f32_e32 v59, 0xb2a5705f, v45                        // 0000001C33B4: 56765AFF B2A5705F
	v_sub_f32_e32 v43, v43, v60                                // 0000001C33BC: 0856792B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C33C0: BF870214
	v_and_b32_e32 v61, 1, v0                                   // 0000001C33C4: 367A0081
	v_div_scale_f32 v42, null, v44, v44, v36                   // 0000001C33C8: D6FC7C2A 0492592C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001C33D0: BF870005
	v_fma_f32 v54, -v57, v41, 1.0                              // 0000001C33D4: D6130036 23CA5339
	v_cvt_i32_f32_e32 v60, v60                                 // 0000001C33DC: 7E78113C
	v_add_f32_e32 v43, v43, v59                                // 0000001C33E0: 0656772B
	v_add3_u32 v34, v34, v61, 0x7fff                           // 0000001C33E4: D6550022 03FE7B22 00007FFF
	v_rcp_f32_e32 v58, v42                                     // 0000001C33F0: 7E74552A
	v_fmac_f32_e32 v41, v54, v41                               // 0000001C33F4: 56525336
	v_div_scale_f32 v54, vcc_lo, v35, v46, v35                 // 0000001C33F8: D6FC6A36 048E5D23
	v_exp_f32_e32 v43, v43                                     // 0000001C3400: 7E564B2B
	v_add_f32_e32 v71, v71, v73                                // 0000001C3404: 068E9347
	v_add3_u32 v33, v33, v53, 0x7fff                           // 0000001C3408: D6550021 03FE6B21 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001C3414: BF870313
	v_mul_f32_e32 v59, v54, v41                                // 0000001C3418: 10765336
	v_fma_f32 v72, -v42, v58, 1.0                              // 0000001C341C: D6130048 23CA752A
	global_store_d16_hi_b16 v[7:8], v33, off offset:96         // 0000001C3424: DC960060 007C2107
	v_fma_f32 v61, -v57, v59, v54                              // 0000001C342C: D613003D 24DA7739
	.long 0xd71c002b                                           // 0000001C3434: D71C002B
	v_cndmask_b32_e32 v1, v43, v60, vcc_lo                     // 0000001C3438: 0202792B
	v_exp_f32_e32 v60, v71                                     // 0000001C343C: 7E784B47
	v_fmac_f32_e32 v58, v72, v58                               // 0000001C3440: 56747548
	v_div_scale_f32 v72, s0, v36, v44, v36                     // 0000001C3444: D6FC0048 04925924
	v_fmac_f32_e32 v59, v61, v41                               // 0000001C344C: 5676533D
	v_cndmask_b32_e64 v43, 0, v43, s1                          // 0000001C3450: D501002B 00065680
	.long 0xd41b0001                                           // 0000001C3458: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v45, vcc_lo              // 0000001C345C: 02025AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v34, off offset:96       // 0000001C3464: DC960060 007C222F
	v_mul_f32_e32 v75, v72, v58                                // 0000001C346C: 10967548
	v_fma_f32 v54, -v57, v59, v54                              // 0000001C3470: D6130036 24DA7739
	v_cndmask_b32_e64 v43, 0x7f800000, v43, s1                 // 0000001C3478: D501002B 000656FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C3484: BF870193
	v_fma_f32 v53, -v42, v75, v72                              // 0000001C3488: D6130035 2522972A
	v_div_fmas_f32 v41, v54, v41, v59                          // 0000001C3490: D6370029 04EE5336
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v62                  // 0000001C3498: 7C3C7CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C34A0: BF870214
	v_add_f32_e32 v43, 1.0, v43                                // 0000001C34A4: 065656F2
	v_fmac_f32_e32 v75, v53, v58                               // 0000001C34A8: 56967535
	v_cvt_i32_f32_e32 v53, v74                                 // 0000001C34AC: 7E6A114A
	v_div_fixup_f32 v35, v41, v46, v35                         // 0000001C34B0: D6270023 048E5D29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C34B8: BF870193
	v_fma_f32 v42, -v42, v75, v72                              // 0000001C34BC: D613002A 2522972A
	.long 0xd71c002d                                           // 0000001C34C4: D71C002D
	v_cndmask_b32_e32 v1, v60, v53, vcc_lo                     // 0000001C34C8: 02026B3C
	v_div_scale_f32 v53, null, v43, v43, v37                   // 0000001C34CC: D6FC7C35 0496572B
	s_waitcnt vmcnt(4)                                         // 0000001C34D4: BF8913F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C34D8: BF8700A2
	v_dual_cndmask_b32 v45, 0, v45 :: v_dual_lshlrev_b32 v60, 16, v136// 0000001C34DC: CA625A80 2D3D1090
	s_mov_b32 vcc_lo, s0                                       // 0000001C34E4: BEEA0000
	v_mul_f32_e32 v61, 0xbfb8aa3b, v60                         // 0000001C34E8: 107A78FF BFB8AA3B
	v_div_fmas_f32 v42, v42, v58, v75                          // 0000001C34F0: D637002A 052E752A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v62                  // 0000001C34F8: 7C367CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C3500: BF870193
	v_fma_f32 v71, 0xbfb8aa3b, v60, -v61                       // 0000001C3504: D6130047 84F678FF BFB8AA3B
	v_div_fixup_f32 v33, v42, v44, v36                         // 0000001C3510: D6270021 0492592A
	v_dual_cndmask_b32 v45, 0x7f800000, v45 :: v_dual_mul_f32 v36, v38, v51// 0000001C3518: CA465AFF 2D246726 7F800000
	v_lshlrev_b32_e32 v44, 16, v86                             // 0000001C3524: 3058AC90
	v_rcp_f32_e32 v38, v53                                     // 0000001C3528: 7E4C5535
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C352C: BF870193
	.long 0x7e0039a1                                           // 0000001C3530: 7E0039A1
	v_add_f32_e32 v42, 1.0, v45                                // 0000001C3534: 06545AF2
	v_rndne_f32_e32 v72, v61                                   // 0000001C3538: 7E90473D
	v_mul_f32_e32 v41, 0xbfb8aa3b, v44                         // 0000001C353C: 105258FF BFB8AA3B
	.long 0x7e5a39a3                                           // 0000001C3544: 7E5A39A3
	.long 0x7f5a3980                                           // 0000001C3548: 7F5A3980
	v_div_scale_f32 v34, null, v42, v42, v36                   // 0000001C354C: D6FC7C22 0492552A
	v_and_b32_e32 v59, 1, v0                                   // 0000001C3554: 36760081
	v_fma_f32 v57, 0xbfb8aa3b, v44, -v41                       // 0000001C3558: D6130039 84A658FF BFB8AA3B
	v_rndne_f32_e32 v58, v41                                   // 0000001C3564: 7E744729
	v_fma_f32 v46, -v53, v38, 1.0                              // 0000001C3568: D613002E 23CA4D35
	v_rcp_f32_e32 v54, v34                                     // 0000001C3570: 7E6C5522
	v_fmac_f32_e32 v71, 0xb2a5705f, v60                        // 0000001C3574: 568E78FF B2A5705F
	v_fmac_f32_e32 v57, 0xb2a5705f, v44                        // 0000001C357C: 567258FF B2A5705F
	v_sub_f32_e32 v41, v41, v58                                // 0000001C3584: 08527529
	v_fmac_f32_e32 v38, v46, v38                               // 0000001C3588: 564C4D2E
	v_div_scale_f32 v46, vcc_lo, v37, v43, v37                 // 0000001C358C: D6FC6A2E 04965725
	v_sub_f32_e32 v61, v61, v72                                // 0000001C3594: 087A913D
	v_and_b32_e32 v45, 1, v45                                  // 0000001C3598: 365A5A81
	v_add_f32_e32 v41, v41, v57                                // 0000001C359C: 06527329
	v_add3_u32 v33, v33, v59, 0x7fff                           // 0000001C35A0: D6550021 03FE7721 00007FFF
	v_fma_f32 v62, -v34, v54, 1.0                              // 0000001C35AC: D613003E 23CA6D22
	v_mul_f32_e32 v57, v46, v38                                // 0000001C35B4: 10724D2E
	v_cvt_i32_f32_e32 v58, v58                                 // 0000001C35B8: 7E74113A
	v_exp_f32_e32 v41, v41                                     // 0000001C35BC: 7E524B29
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001C35C0: BF870253
	v_dual_add_f32 v61, v61, v71 :: v_dual_fmac_f32 v54, v62, v54// 0000001C35C4: C9008F3D 3D366D3E
	v_div_scale_f32 v62, s0, v36, v42, v36                     // 0000001C35CC: D6FC003E 04925524
	v_fma_f32 v59, -v53, v57, v46                              // 0000001C35D4: D613003B 24BA7335
	v_add3_u32 v35, v35, v45, 0x7fff                           // 0000001C35DC: D6550023 03FE5B23 00007FFF
	.long 0xd41e0001                                           // 0000001C35E8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v44, vcc_lo              // 0000001C35EC: 020258FF 42CE8ED0
	v_mul_f32_e32 v73, v62, v54                                // 0000001C35F4: 10926D3E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001C35F8: BF870294
	v_fmac_f32_e32 v57, v59, v38                               // 0000001C35FC: 56724D3B
	.long 0xd71c0029                                           // 0000001C3600: D71C0029
	v_cndmask_b32_e32 v1, v41, v58, vcc_lo                     // 0000001C3604: 02027529
	v_exp_f32_e32 v58, v61                                     // 0000001C3608: 7E744B3D
	global_store_d16_hi_b16 v[15:16], v35, off offset:96       // 0000001C360C: DC960060 007C230F
	v_fma_f32 v45, -v34, v73, v62                              // 0000001C3614: D613002D 24FA9322
	v_fma_f32 v46, -v53, v57, v46                              // 0000001C361C: D613002E 24BA7335
	v_cndmask_b32_e64 v41, 0, v41, s1                          // 0000001C3624: D5010029 00065280
	.long 0xd41b0001                                           // 0000001C362C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v44, vcc_lo              // 0000001C3630: 020258FF C2B17218
	global_store_d16_hi_b16 v[23:24], v33, off offset:96       // 0000001C3638: DC960060 007C2117
	v_fmac_f32_e32 v73, v45, v54                               // 0000001C3640: 56926D2D
	v_cvt_i32_f32_e32 v45, v72                                 // 0000001C3644: 7E5A1148
	v_div_fmas_f32 v38, v46, v38, v57                          // 0000001C3648: D6370026 04E64D2E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v60                  // 0000001C3650: 7C3C78FF 42CE8ED0
	v_cndmask_b32_e64 v41, 0x7f800000, v41, s1                 // 0000001C3658: D5010029 000652FF 7F800000
	v_fma_f32 v34, -v34, v73, v62                              // 0000001C3664: D6130022 24FA9322
	.long 0xd71c002c                                           // 0000001C366C: D71C002C
	v_cndmask_b32_e32 v1, v58, v45, vcc_lo                     // 0000001C3670: 02025B3A
	v_div_fixup_f32 v37, v38, v43, v37                         // 0000001C3674: D6270025 04965726
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C367C: BF870224
	v_dual_add_f32 v41, 1.0, v41 :: v_dual_lshlrev_b32 v58, 16, v127// 0000001C3680: C92252F2 293AFE90
	.long 0x7f563980                                           // 0000001C3688: 7F563980
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo                      // 0000001C368C: 02585880
	s_mov_b32 vcc_lo, s0                                       // 0000001C3690: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C3694: BF870003
	v_mul_f32_e32 v59, 0xbfb8aa3b, v58                         // 0000001C3698: 107674FF BFB8AA3B
	v_div_fmas_f32 v34, v34, v54, v73                          // 0000001C36A0: D6370022 05266D22
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v60                  // 0000001C36A8: 7C3678FF C2B17218
	v_div_scale_f32 v45, null, v41, v41, v25                   // 0000001C36B0: D6FC7C2D 04665329
	.long 0x7e5639a5                                           // 0000001C36B8: 7E5639A5
	v_fma_f32 v61, 0xbfb8aa3b, v58, -v59                       // 0000001C36BC: D613003D 84EE74FF BFB8AA3B
	v_div_fixup_f32 v34, v34, v42, v36                         // 0000001C36C8: D6270022 04925522
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo             // 0000001C36D0: 025858FF 7F800000
	v_lshlrev_b32_e32 v42, 16, v128                            // 0000001C36D8: 30550090
	v_rcp_f32_e32 v35, v45                                     // 0000001C36DC: 7E46552D
	v_rndne_f32_e32 v62, v59                                   // 0000001C36E0: 7E7C473B
	.long 0x7e0039a2                                           // 0000001C36E4: 7E0039A2
	v_add_f32_e32 v36, 1.0, v44                                // 0000001C36E8: 064858F2
	v_mul_f32_e32 v38, 0xbfb8aa3b, v42                         // 0000001C36EC: 104C54FF BFB8AA3B
	v_fmac_f32_e32 v61, 0xb2a5705f, v58                        // 0000001C36F4: 567A74FF B2A5705F
	v_sub_f32_e32 v59, v59, v62                                // 0000001C36FC: 08767D3B
	v_and_b32_e32 v57, 1, v0                                   // 0000001C3700: 36720081
	v_div_scale_f32 v33, null, v36, v36, v26                   // 0000001C3704: D6FC7C21 046A4924
	v_fma_f32 v53, 0xbfb8aa3b, v42, -v38                       // 0000001C370C: D6130035 849A54FF BFB8AA3B
	v_rndne_f32_e32 v54, v38                                   // 0000001C3718: 7E6C4726
	v_fma_f32 v44, -v45, v35, 1.0                              // 0000001C371C: D613002C 23CA472D
	v_and_b32_e32 v43, 1, v43                                  // 0000001C3724: 36565681
	v_rcp_f32_e32 v46, v33                                     // 0000001C3728: 7E5C5521
	v_fmac_f32_e32 v53, 0xb2a5705f, v42                        // 0000001C372C: 566A54FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001C3734: BF870243
	v_dual_sub_f32 v38, v38, v54 :: v_dual_fmac_f32 v35, v44, v35// 0000001C3738: C9406D26 2622472C
	v_div_scale_f32 v44, vcc_lo, v25, v41, v25                 // 0000001C3740: D6FC6A2C 04665319
	v_add3_u32 v34, v34, v57, 0x7fff                           // 0000001C3748: D6550022 03FE7322 00007FFF
	v_cvt_i32_f32_e32 v54, v54                                 // 0000001C3754: 7E6C1136
	v_add_f32_e32 v38, v38, v53                                // 0000001C3758: 064C6B26
	v_add_f32_e32 v59, v59, v61                                // 0000001C375C: 06767B3B
	v_mul_f32_e32 v53, v44, v35                                // 0000001C3760: 106A472C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001C3764: BF870005
	v_fma_f32 v60, -v33, v46, 1.0                              // 0000001C3768: D613003C 23CA5D21
	v_add3_u32 v37, v37, v43, 0x7fff                           // 0000001C3770: D6550025 03FE5725 00007FFF
	v_exp_f32_e32 v38, v38                                     // 0000001C377C: 7E4C4B26
	.long 0xd41e0001                                           // 0000001C3780: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v42, vcc_lo              // 0000001C3784: 020254FF 42CE8ED0
	v_fma_f32 v57, -v45, v53, v44                              // 0000001C378C: D6130039 24B26B2D
	v_fmac_f32_e32 v46, v60, v46                               // 0000001C3794: 565C5D3C
	v_div_scale_f32 v60, s0, v26, v36, v26                     // 0000001C3798: D6FC003C 046A491A
	global_store_d16_hi_b16 v[31:32], v37, off offset:96       // 0000001C37A0: DC960060 007C251F
	v_lshlrev_b32_e32 v37, 16, v130                            // 0000001C37A8: 304B0490
	v_fmac_f32_e32 v53, v57, v35                               // 0000001C37AC: 566A4739
	global_store_d16_hi_b16 v[39:40], v34, off offset:96       // 0000001C37B0: DC960060 007C2227
	v_mul_f32_e32 v71, v60, v46                                // 0000001C37B8: 108E5D3C
	.long 0xd71c0026                                           // 0000001C37BC: D71C0026
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 0000001C37C0: 02026D26
	v_exp_f32_e32 v54, v59                                     // 0000001C37C4: 7E6C4B3B
	v_fma_f32 v44, -v45, v53, v44                              // 0000001C37C8: D613002C 24B26B2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C37D0: BF870193
	v_fma_f32 v43, -v33, v71, v60                              // 0000001C37D4: D613002B 24F28F21
	v_cndmask_b32_e64 v38, 0, v38, s1                          // 0000001C37DC: D5010026 00064C80
	.long 0xd41b0001                                           // 0000001C37E4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v42, vcc_lo              // 0000001C37E8: 020254FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C37F0: BF870004
	v_div_fmas_f32 v35, v44, v35, v53                          // 0000001C37F4: D6370023 04D6472C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v58                  // 0000001C37FC: 7C3C74FF 42CE8ED0
	v_fmac_f32_e32 v71, v43, v46                               // 0000001C3804: 568E5D2B
	v_cvt_i32_f32_e32 v43, v62                                 // 0000001C3808: 7E56113E
	v_cndmask_b32_e64 v38, 0x7f800000, v38, s1                 // 0000001C380C: D5010026 00064CFF 7F800000
	v_div_fixup_f32 v25, v35, v41, v25                         // 0000001C3818: D6270019 04665323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v37                         // 0000001C3820: 10464AFF BFB8AA3B
	v_fma_f32 v33, -v33, v71, v60                              // 0000001C3828: D6130021 24F28F21
	.long 0xd71c002a                                           // 0000001C3830: D71C002A
	v_cndmask_b32_e32 v1, v54, v43, vcc_lo                     // 0000001C3834: 02025736
	v_add_f32_e32 v38, 1.0, v38                                // 0000001C3838: 064C4CF2
	v_lshlrev_b32_e32 v54, 16, v129                            // 0000001C383C: 306D0290
	v_fma_f32 v45, 0xbfb8aa3b, v37, -v35                       // 0000001C3840: D613002D 848E4AFF BFB8AA3B
	.long 0x7e523999                                           // 0000001C384C: 7E523999
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000001C3850: 02545480
	s_mov_b32 vcc_lo, s0                                       // 0000001C3854: BEEA0000
	v_div_scale_f32 v43, null, v38, v38, v27                   // 0000001C3858: D6FC7C2B 046E4D26
	v_div_fmas_f32 v33, v33, v46, v71                          // 0000001C3860: D6370021 051E5D21
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v58                  // 0000001C3868: 7C3674FF C2B17218
	v_rndne_f32_e32 v46, v35                                   // 0000001C3870: 7E5C4723
	v_fmac_f32_e32 v45, 0xb2a5705f, v37                        // 0000001C3874: 565A4AFF B2A5705F
	v_mul_f32_e32 v57, 0xbfb8aa3b, v54                         // 0000001C387C: 10726CFF BFB8AA3B
	v_div_fixup_f32 v26, v33, v36, v26                         // 0000001C3884: D627001A 046A4921
	v_cndmask_b32_e32 v42, 0x7f800000, v42, vcc_lo             // 0000001C388C: 025454FF 7F800000
	v_rcp_f32_e32 v33, v43                                     // 0000001C3894: 7E42552B
	v_sub_f32_e32 v35, v35, v46                                // 0000001C3898: 08465D23
	v_fma_f32 v59, 0xbfb8aa3b, v54, -v57                       // 0000001C389C: D613003B 84E66CFF BFB8AA3B
	.long 0x7e00399a                                           // 0000001C38A8: 7E00399A
	v_add_f32_e32 v36, 1.0, v42                                // 0000001C38AC: 064854F2
	v_rndne_f32_e32 v60, v57                                   // 0000001C38B0: 7E784739
	v_add_f32_e32 v35, v35, v45                                // 0000001C38B4: 06465B23
	.long 0x7f523980                                           // 0000001C38B8: 7F523980
	v_and_b32_e32 v53, 1, v0                                   // 0000001C38BC: 366A0081
	v_div_scale_f32 v34, null, v36, v36, v28                   // 0000001C38C0: D6FC7C22 04724924
	v_fma_f32 v42, -v43, v33, 1.0                              // 0000001C38C8: D613002A 23CA432B
	v_exp_f32_e32 v35, v35                                     // 0000001C38D0: 7E464B23
	v_fmac_f32_e32 v59, 0xb2a5705f, v54                        // 0000001C38D4: 56766CFF B2A5705F
	v_sub_f32_e32 v57, v57, v60                                // 0000001C38DC: 08727939
	v_rcp_f32_e32 v44, v34                                     // 0000001C38E0: 7E585522
	v_fmac_f32_e32 v33, v42, v33                               // 0000001C38E4: 5642432A
	v_div_scale_f32 v42, vcc_lo, v27, v38, v27                 // 0000001C38E8: D6FC6A2A 046E4D1B
	v_and_b32_e32 v41, 1, v41                                  // 0000001C38F0: 36525281
	v_add3_u32 v26, v26, v53, 0x7fff                           // 0000001C38F4: D655001A 03FE6B1A 00007FFF
	v_cvt_i32_f32_e32 v46, v46                                 // 0000001C3900: 7E5C112E
	v_add_f32_e32 v57, v57, v59                                // 0000001C3904: 06727739
	v_mul_f32_e32 v45, v42, v33                                // 0000001C3908: 105A432A
	v_add3_u32 v25, v25, v41, 0x7fff                           // 0000001C390C: D6550019 03FE5319 00007FFF
	.long 0xd41e0001                                           // 0000001C3918: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v37, vcc_lo              // 0000001C391C: 02024AFF 42CE8ED0
	v_fma_f32 v58, -v34, v44, 1.0                              // 0000001C3924: D613003A 23CA5922
	.long 0xd71c0023                                           // 0000001C392C: D71C0023
	v_cndmask_b32_e32 v1, v35, v46, vcc_lo                     // 0000001C3930: 02025D23
	v_fma_f32 v53, -v43, v45, v42                              // 0000001C3934: D6130035 24AA5B2B
	v_exp_f32_e32 v46, v57                                     // 0000001C393C: 7E5C4B39
	global_store_d16_hi_b16 v[7:8], v25, off offset:128        // 0000001C3940: DC960080 007C1907
	v_fmac_f32_e32 v44, v58, v44                               // 0000001C3948: 5658593A
	v_div_scale_f32 v58, s0, v28, v36, v28                     // 0000001C394C: D6FC003A 0472491C
	v_fmac_f32_e32 v45, v53, v33                               // 0000001C3954: 565A4335
	v_cndmask_b32_e64 v35, 0, v35, s1                          // 0000001C3958: D5010023 00064680
	.long 0xd41b0001                                           // 0000001C3960: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v37, vcc_lo              // 0000001C3964: 02024AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v26, off offset:128      // 0000001C396C: DC960080 007C1A2F
	v_mul_f32_e32 v61, v58, v44                                // 0000001C3974: 107A593A
	v_fma_f32 v42, -v43, v45, v42                              // 0000001C3978: D613002A 24AA5B2B
	v_cndmask_b32_e64 v35, 0x7f800000, v35, s1                 // 0000001C3980: D5010023 000646FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C398C: BF870193
	v_fma_f32 v41, -v34, v61, v58                              // 0000001C3990: D6130029 24EA7B22
	v_div_fmas_f32 v33, v42, v33, v45                          // 0000001C3998: D6370021 04B6432A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v54                  // 0000001C39A0: 7C3C6CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C39A8: BF870214
	v_add_f32_e32 v35, 1.0, v35                                // 0000001C39AC: 064646F2
	v_fmac_f32_e32 v61, v41, v44                               // 0000001C39B0: 567A5929
	v_cvt_i32_f32_e32 v41, v60                                 // 0000001C39B4: 7E52113C
	v_div_fixup_f32 v27, v33, v38, v27                         // 0000001C39B8: D627001B 046E4D21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C39C0: BF870193
	v_fma_f32 v34, -v34, v61, v58                              // 0000001C39C4: D6130022 24EA7B22
	.long 0xd71c0025                                           // 0000001C39CC: D71C0025
	v_cndmask_b32_e32 v1, v46, v41, vcc_lo                     // 0000001C39D0: 0202532E
	v_div_scale_f32 v41, null, v35, v35, v29                   // 0000001C39D4: D6FC7C29 04764723
	s_waitcnt vmcnt(3)                                         // 0000001C39DC: BF890FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C39E0: BF8700A2
	v_dual_cndmask_b32 v37, 0, v37 :: v_dual_lshlrev_b32 v46, 16, v131// 0000001C39E4: CA624A80 252F0690
	s_mov_b32 vcc_lo, s0                                       // 0000001C39EC: BEEA0000
	v_mul_f32_e32 v53, 0xbfb8aa3b, v46                         // 0000001C39F0: 106A5CFF BFB8AA3B
	v_div_fmas_f32 v34, v34, v44, v61                          // 0000001C39F8: D6370022 04F65922
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v54                  // 0000001C3A00: 7C366CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C3A08: BF870193
	v_fma_f32 v57, 0xbfb8aa3b, v46, -v53                       // 0000001C3A0C: D6130039 84D65CFF BFB8AA3B
	v_div_fixup_f32 v25, v34, v36, v28                         // 0000001C3A18: D6270019 04724922
	v_dual_cndmask_b32 v37, 0x7f800000, v37 :: v_dual_mul_f32 v28, v30, v51// 0000001C3A20: CA464AFF 251C671E 7F800000
	v_lshlrev_b32_e32 v36, 16, v87                             // 0000001C3A2C: 3048AE90
	v_rcp_f32_e32 v30, v41                                     // 0000001C3A30: 7E3C5529
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C3A34: BF870193
	.long 0x7e003999                                           // 0000001C3A38: 7E003999
	v_add_f32_e32 v34, 1.0, v37                                // 0000001C3A3C: 06444AF2
	v_rndne_f32_e32 v58, v53                                   // 0000001C3A40: 7E744735
	v_mul_f32_e32 v33, 0xbfb8aa3b, v36                         // 0000001C3A44: 104248FF BFB8AA3B
	.long 0x7e4a399b                                           // 0000001C3A4C: 7E4A399B
	.long 0x7f4a3980                                           // 0000001C3A50: 7F4A3980
	v_div_scale_f32 v26, null, v34, v34, v28                   // 0000001C3A54: D6FC7C1A 04724522
	v_and_b32_e32 v45, 1, v0                                   // 0000001C3A5C: 365A0081
	v_fma_f32 v43, 0xbfb8aa3b, v36, -v33                       // 0000001C3A60: D613002B 848648FF BFB8AA3B
	v_rndne_f32_e32 v44, v33                                   // 0000001C3A6C: 7E584721
	v_fma_f32 v38, -v41, v30, 1.0                              // 0000001C3A70: D6130026 23CA3D29
	v_rcp_f32_e32 v42, v26                                     // 0000001C3A78: 7E54551A
	v_fmac_f32_e32 v57, 0xb2a5705f, v46                        // 0000001C3A7C: 56725CFF B2A5705F
	v_fmac_f32_e32 v43, 0xb2a5705f, v36                        // 0000001C3A84: 565648FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001C3A8C: BF870243
	v_dual_sub_f32 v33, v33, v44 :: v_dual_fmac_f32 v30, v38, v30// 0000001C3A90: C9405921 211E3D26
	v_div_scale_f32 v38, vcc_lo, v29, v35, v29                 // 0000001C3A98: D6FC6A26 0476471D
	v_sub_f32_e32 v53, v53, v58                                // 0000001C3AA0: 086A7535
	v_and_b32_e32 v37, 1, v37                                  // 0000001C3AA4: 364A4A81
	v_add_f32_e32 v33, v33, v43                                // 0000001C3AA8: 06425721
	v_add3_u32 v25, v25, v45, 0x7fff                           // 0000001C3AAC: D6550019 03FE5B19 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001C3AB8: BF8701C5
	v_fma_f32 v54, -v26, v42, 1.0                              // 0000001C3ABC: D6130036 23CA551A
	v_mul_f32_e32 v43, v38, v30                                // 0000001C3AC4: 10563D26
	v_cvt_i32_f32_e32 v44, v44                                 // 0000001C3AC8: 7E58112C
	v_exp_f32_e32 v33, v33                                     // 0000001C3ACC: 7E424B21
	v_dual_add_f32 v53, v53, v57 :: v_dual_fmac_f32 v42, v54, v42// 0000001C3AD0: C9007335 352A5536
	v_div_scale_f32 v54, s0, v28, v34, v28                     // 0000001C3AD8: D6FC0036 0472451C
	v_fma_f32 v45, -v41, v43, v38                              // 0000001C3AE0: D613002D 249A5729
	v_add3_u32 v27, v27, v37, 0x7fff                           // 0000001C3AE8: D655001B 03FE4B1B 00007FFF
	.long 0xd41e0001                                           // 0000001C3AF4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v36, vcc_lo              // 0000001C3AF8: 020248FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C3B00: BF870214
	v_mul_f32_e32 v59, v54, v42                                // 0000001C3B04: 10765536
	v_fmac_f32_e32 v43, v45, v30                               // 0000001C3B08: 56563D2D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001C3B0C: BF870005
	.long 0xd71c0021                                           // 0000001C3B10: D71C0021
	v_cndmask_b32_e32 v1, v33, v44, vcc_lo                     // 0000001C3B14: 02025921
	v_exp_f32_e32 v44, v53                                     // 0000001C3B18: 7E584B35
	global_store_d16_hi_b16 v[15:16], v27, off offset:128      // 0000001C3B1C: DC960080 007C1B0F
	v_fma_f32 v37, -v26, v59, v54                              // 0000001C3B24: D6130025 24DA771A
	v_fma_f32 v38, -v41, v43, v38                              // 0000001C3B2C: D6130026 249A5729
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 0000001C3B34: D5010021 00064280
	.long 0xd41b0001                                           // 0000001C3B3C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v36, vcc_lo              // 0000001C3B40: 020248FF C2B17218
	global_store_d16_hi_b16 v[23:24], v25, off offset:128      // 0000001C3B48: DC960080 007C1917
	v_fmac_f32_e32 v59, v37, v42                               // 0000001C3B50: 56765525
	v_cvt_i32_f32_e32 v37, v58                                 // 0000001C3B54: 7E4A113A
	v_div_fmas_f32 v30, v38, v30, v43                          // 0000001C3B58: D637001E 04AE3D26
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v46                  // 0000001C3B60: 7C3C5CFF 42CE8ED0
	v_cndmask_b32_e64 v33, 0x7f800000, v33, s1                 // 0000001C3B68: D5010021 000642FF 7F800000
	v_fma_f32 v26, -v26, v59, v54                              // 0000001C3B74: D613001A 24DA771A
	.long 0xd71c0024                                           // 0000001C3B7C: D71C0024
	v_cndmask_b32_e32 v1, v44, v37, vcc_lo                     // 0000001C3B80: 02024B2C
	v_div_fixup_f32 v29, v30, v35, v29                         // 0000001C3B84: D627001D 0476471E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C3B8C: BF870224
	v_dual_add_f32 v33, 1.0, v33 :: v_dual_lshlrev_b32 v44, 16, v123// 0000001C3B90: C92242F2 212CF690
	.long 0x7f463980                                           // 0000001C3B98: 7F463980
	v_cndmask_b32_e32 v36, 0, v36, vcc_lo                      // 0000001C3B9C: 02484880
	s_mov_b32 vcc_lo, s0                                       // 0000001C3BA0: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C3BA4: BF870003
	v_mul_f32_e32 v45, 0xbfb8aa3b, v44                         // 0000001C3BA8: 105A58FF BFB8AA3B
	v_div_fmas_f32 v26, v26, v42, v59                          // 0000001C3BB0: D637001A 04EE551A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v46                  // 0000001C3BB8: 7C365CFF C2B17218
	v_div_scale_f32 v37, null, v33, v33, v17                   // 0000001C3BC0: D6FC7C25 04464321
	.long 0x7e46399d                                           // 0000001C3BC8: 7E46399D
	v_fma_f32 v53, 0xbfb8aa3b, v44, -v45                       // 0000001C3BCC: D6130035 84B658FF BFB8AA3B
	v_div_fixup_f32 v26, v26, v34, v28                         // 0000001C3BD8: D627001A 0472451A
	v_cndmask_b32_e32 v36, 0x7f800000, v36, vcc_lo             // 0000001C3BE0: 024848FF 7F800000
	v_lshlrev_b32_e32 v34, 16, v124                            // 0000001C3BE8: 3044F890
	v_rcp_f32_e32 v27, v37                                     // 0000001C3BEC: 7E365525
	v_rndne_f32_e32 v54, v45                                   // 0000001C3BF0: 7E6C472D
	.long 0x7e00399a                                           // 0000001C3BF4: 7E00399A
	v_add_f32_e32 v28, 1.0, v36                                // 0000001C3BF8: 063848F2
	v_mul_f32_e32 v30, 0xbfb8aa3b, v34                         // 0000001C3BFC: 103C44FF BFB8AA3B
	v_fmac_f32_e32 v53, 0xb2a5705f, v44                        // 0000001C3C04: 566A58FF B2A5705F
	v_sub_f32_e32 v45, v45, v54                                // 0000001C3C0C: 085A6D2D
	v_and_b32_e32 v43, 1, v0                                   // 0000001C3C10: 36560081
	v_div_scale_f32 v25, null, v28, v28, v18                   // 0000001C3C14: D6FC7C19 044A391C
	v_fma_f32 v41, 0xbfb8aa3b, v34, -v30                       // 0000001C3C1C: D6130029 847A44FF BFB8AA3B
	v_rndne_f32_e32 v42, v30                                   // 0000001C3C28: 7E54471E
	v_fma_f32 v36, -v37, v27, 1.0                              // 0000001C3C2C: D6130024 23CA3725
	v_and_b32_e32 v35, 1, v35                                  // 0000001C3C34: 36464681
	v_rcp_f32_e32 v38, v25                                     // 0000001C3C38: 7E4C5519
	v_fmac_f32_e32 v41, 0xb2a5705f, v34                        // 0000001C3C3C: 565244FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001C3C44: BF870243
	v_dual_sub_f32 v30, v30, v42 :: v_dual_fmac_f32 v27, v36, v27// 0000001C3C48: C940551E 1E1A3724
	v_div_scale_f32 v36, vcc_lo, v17, v33, v17                 // 0000001C3C50: D6FC6A24 04464311
	v_add3_u32 v26, v26, v43, 0x7fff                           // 0000001C3C58: D655001A 03FE571A 00007FFF
	v_cvt_i32_f32_e32 v42, v42                                 // 0000001C3C64: 7E54112A
	v_add_f32_e32 v30, v30, v41                                // 0000001C3C68: 063C531E
	v_add_f32_e32 v45, v45, v53                                // 0000001C3C6C: 065A6B2D
	v_mul_f32_e32 v41, v36, v27                                // 0000001C3C70: 10523724
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001C3C74: BF870005
	v_fma_f32 v46, -v25, v38, 1.0                              // 0000001C3C78: D613002E 23CA4D19
	v_add3_u32 v29, v29, v35, 0x7fff                           // 0000001C3C80: D655001D 03FE471D 00007FFF
	v_exp_f32_e32 v30, v30                                     // 0000001C3C8C: 7E3C4B1E
	.long 0xd41e0001                                           // 0000001C3C90: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v34, vcc_lo              // 0000001C3C94: 020244FF 42CE8ED0
	v_fma_f32 v43, -v37, v41, v36                              // 0000001C3C9C: D613002B 24925325
	v_fmac_f32_e32 v38, v46, v38                               // 0000001C3CA4: 564C4D2E
	v_div_scale_f32 v46, s0, v18, v28, v18                     // 0000001C3CA8: D6FC002E 044A3912
	s_clause 0x1                                               // 0000001C3CB0: BF850001
	global_store_d16_hi_b16 v[31:32], v29, off offset:128      // 0000001C3CB4: DC960080 007C1D1F
	global_store_d16_hi_b16 v[39:40], v26, off offset:128      // 0000001C3CBC: DC960080 007C1A27
	v_dual_fmac_f32 v41, v43, v27 :: v_dual_lshlrev_b32 v26, 16, v126// 0000001C3CC4: C822372B 291AFC90
	v_mul_f32_e32 v57, v46, v38                                // 0000001C3CCC: 10724D2E
	.long 0xd71c001e                                           // 0000001C3CD0: D71C001E
	v_cndmask_b32_e32 v1, v30, v42, vcc_lo                     // 0000001C3CD4: 0202551E
	v_exp_f32_e32 v42, v45                                     // 0000001C3CD8: 7E544B2D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C3CDC: BF870003
	v_fma_f32 v36, -v37, v41, v36                              // 0000001C3CE0: D6130024 24925325
	.long 0x7f3a3980                                           // 0000001C3CE8: 7F3A3980
	v_fma_f32 v35, -v25, v57, v46                              // 0000001C3CEC: D6130023 24BA7319
	v_cndmask_b32_e64 v30, 0, v30, s1                          // 0000001C3CF4: D501001E 00063C80
	.long 0xd41b0001                                           // 0000001C3CFC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v34, vcc_lo              // 0000001C3D00: 020244FF C2B17218
	v_div_fmas_f32 v27, v36, v27, v41                          // 0000001C3D08: D637001B 04A63724
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v44                  // 0000001C3D10: 7C3C58FF 42CE8ED0
	v_fmac_f32_e32 v57, v35, v38                               // 0000001C3D18: 56724D23
	v_cvt_i32_f32_e32 v35, v54                                 // 0000001C3D1C: 7E461136
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000001C3D20: D501001E 00063CFF 7F800000
	v_div_fixup_f32 v17, v27, v33, v17                         // 0000001C3D2C: D6270011 0446431B
	v_mul_f32_e32 v33, 0xbfb8aa3b, v26                         // 0000001C3D34: 104234FF BFB8AA3B
	v_fma_f32 v25, -v25, v57, v46                              // 0000001C3D3C: D6130019 24BA7319
	.long 0xd71c0022                                           // 0000001C3D44: D71C0022
	v_cndmask_b32_e32 v1, v42, v35, vcc_lo                     // 0000001C3D48: 0202472A
	v_add_f32_e32 v30, 1.0, v30                                // 0000001C3D4C: 063C3CF2
	.long 0xd41e0001                                           // 0000001C3D50: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v26, vcc_lo              // 0000001C3D54: 020234FF 42CE8ED0
	v_fma_f32 v41, 0xbfb8aa3b, v26, -v33                       // 0000001C3D5C: D6130029 848634FF BFB8AA3B
	v_rndne_f32_e32 v42, v33                                   // 0000001C3D68: 7E544721
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000001C3D6C: 02444480
	s_mov_b32 vcc_lo, s0                                       // 0000001C3D70: BEEA0000
	v_div_scale_f32 v35, null, v30, v30, v19                   // 0000001C3D74: D6FC7C23 044E3D1E
	v_div_fmas_f32 v25, v25, v38, v57                          // 0000001C3D7C: D6370019 04E64D19
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v44                  // 0000001C3D84: 7C3658FF C2B17218
	v_dual_fmac_f32 v41, 0xb2a5705f, v26 :: v_dual_lshlrev_b32 v38, 16, v125// 0000001C3D8C: C82234FF 2926FA90 B2A5705F
	v_sub_f32_e32 v33, v33, v42                                // 0000001C3D98: 08425521
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C3D9C: BF870004
	v_div_fixup_f32 v18, v25, v28, v18                         // 0000001C3DA0: D6270012 044A3919
	v_cndmask_b32_e32 v34, 0x7f800000, v34, vcc_lo             // 0000001C3DA8: 024444FF 7F800000
	v_rcp_f32_e32 v25, v35                                     // 0000001C3DB0: 7E325523
	v_mul_f32_e32 v43, 0xbfb8aa3b, v38                         // 0000001C3DB4: 10564CFF BFB8AA3B
	v_add_f32_e32 v33, v33, v41                                // 0000001C3DBC: 06425321
	.long 0x7e003992                                           // 0000001C3DC0: 7E003992
	v_add_f32_e32 v28, 1.0, v34                                // 0000001C3DC4: 063844F2
	v_cvt_i32_f32_e32 v42, v42                                 // 0000001C3DC8: 7E54112A
	v_fma_f32 v46, 0xbfb8aa3b, v38, -v43                       // 0000001C3DCC: D613002E 84AE4CFF BFB8AA3B
	v_rndne_f32_e32 v53, v43                                   // 0000001C3DD8: 7E6A472B
	v_exp_f32_e32 v33, v33                                     // 0000001C3DDC: 7E424B21
	v_div_scale_f32 v27, null, v28, v28, v20                   // 0000001C3DE0: D6FC7C1B 0452391C
	v_fma_f32 v34, -v35, v25, 1.0                              // 0000001C3DE8: D6130022 23CA3323
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C3DF0: BF870223
	v_dual_fmac_f32 v46, 0xb2a5705f, v38 :: v_dual_sub_f32 v43, v43, v53// 0000001C3DF4: C80A4CFF 2E2A6B2B B2A5705F
	v_div_scale_f32 v41, s0, v20, v28, v20                     // 0000001C3E00: D6FC0029 04523914
	v_rcp_f32_e32 v36, v27                                     // 0000001C3E08: 7E48551B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C3E0C: BF870003
	v_fmac_f32_e32 v25, v34, v25                               // 0000001C3E10: 56323322
	v_div_scale_f32 v34, vcc_lo, v19, v30, v19                 // 0000001C3E14: D6FC6A22 044E3D13
	v_and_b32_e32 v37, 1, v0                                   // 0000001C3E1C: 364A0081
	v_add_f32_e32 v43, v43, v46                                // 0000001C3E20: 06565D2B
	.long 0xd71c0021                                           // 0000001C3E24: D71C0021
	v_cndmask_b32_e32 v1, v33, v42, vcc_lo                     // 0000001C3E28: 02025521
	.long 0x7e3a3991                                           // 0000001C3E2C: 7E3A3991
	v_mul_f32_e32 v45, v34, v25                                // 0000001C3E30: 105A3322
	v_add3_u32 v18, v18, v37, 0x7fff                           // 0000001C3E34: D6550012 03FE4B12 00007FFF
	v_exp_f32_e32 v37, v43                                     // 0000001C3E40: 7E4A4B2B
	v_fma_f32 v44, -v27, v36, 1.0                              // 0000001C3E44: D613002C 23CA491B
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 0000001C3E4C: D5010021 00064280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C3E54: BF870122
	v_dual_fmac_f32 v36, v44, v36 :: v_dual_and_b32 v29, 1, v29// 0000001C3E58: C824492C 241C3A81
	v_fma_f32 v44, -v35, v45, v34                              // 0000001C3E60: D613002C 248A5B23
	v_add3_u32 v17, v17, v29, 0x7fff                           // 0000001C3E68: D6550011 03FE3B11 00007FFF
	v_lshlrev_b32_e32 v29, 16, v92                             // 0000001C3E74: 303AB890
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C3E78: BF870003
	v_dual_mul_f32 v54, v41, v36 :: v_dual_fmac_f32 v45, v44, v25// 0000001C3E7C: C8C04929 362C332C
	s_clause 0x1                                               // 0000001C3E84: BF850001
	global_store_d16_hi_b16 v[7:8], v17, off offset:160        // 0000001C3E88: DC9600A0 007C1107
	global_store_d16_hi_b16 v[47:48], v18, off offset:160      // 0000001C3E90: DC9600A0 007C122F
	v_fma_f32 v44, -v27, v54, v41                              // 0000001C3E98: D613002C 24A66D1B
	v_fma_f32 v34, -v35, v45, v34                              // 0000001C3EA0: D6130022 248A5B23
	v_cvt_i32_f32_e32 v35, v53                                 // 0000001C3EA8: 7E461135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C3EAC: BF870193
	v_fmac_f32_e32 v54, v44, v36                               // 0000001C3EB0: 566C492C
	v_div_fmas_f32 v25, v34, v25, v45                          // 0000001C3EB4: D6370019 04B63322
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v26                  // 0000001C3EBC: 7C3634FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C3EC4: BF870004
	.long 0xd71c0022                                           // 0000001C3EC8: D71C0022
	v_cndmask_b32_e32 v1, v37, v35, vcc_lo                     // 0000001C3ECC: 02024725
	v_mul_f32_e32 v35, 0xbfb8aa3b, v29                         // 0000001C3ED0: 10463AFF BFB8AA3B
	v_fma_f32 v27, -v27, v54, v41                              // 0000001C3ED8: D613001B 24A66D1B
	v_div_fixup_f32 v17, v25, v30, v19                         // 0000001C3EE0: D6270011 044E3D19
	v_cndmask_b32_e32 v26, 0x7f800000, v33, vcc_lo             // 0000001C3EE8: 023442FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 0000001C3EF0: 7C3C4CFF 42CE8ED0
	.long 0x7f3c3980                                           // 0000001C3EF8: 7F3C3980
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C3EFC: BF870214
	.long 0x7e3c3991                                           // 0000001C3F00: 7E3C3991
	v_add_f32_e32 v26, 1.0, v26                                // 0000001C3F04: 063434F2
	v_cndmask_b32_e32 v33, 0, v34, vcc_lo                      // 0000001C3F08: 02424480
	s_mov_b32 vcc_lo, s0                                       // 0000001C3F0C: BEEA0000
	v_div_fmas_f32 v27, v27, v36, v54                          // 0000001C3F10: D637001B 04DA491B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 0000001C3F18: 7C364CFF C2B17218
	v_rndne_f32_e32 v36, v35                                   // 0000001C3F20: 7E484723
	s_waitcnt vmcnt(2)                                         // 0000001C3F24: BF890BF7
	v_lshlrev_b32_e32 v38, 16, v68                             // 0000001C3F28: 304C8890
	v_and_b32_e32 v30, 1, v30                                  // 0000001C3F2C: 363C3C81
	v_div_fixup_f32 v20, v27, v28, v20                         // 0000001C3F30: D6270014 0452391B
	v_cndmask_b32_e32 v33, 0x7f800000, v33, vcc_lo             // 0000001C3F38: 024242FF 7F800000
	v_div_scale_f32 v27, null, v26, v26, v21                   // 0000001C3F40: D6FC7C1B 0456351A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C3F48: BF870214
	v_add3_u32 v17, v17, v30, 0x7fff                           // 0000001C3F4C: D6550011 03FE3D11 00007FFF
	.long 0x7e003994                                           // 0000001C3F58: 7E003994
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C3F5C: BF870214
	v_add_f32_e32 v28, 1.0, v33                                // 0000001C3F60: 063842F2
	v_rcp_f32_e32 v19, v27                                     // 0000001C3F64: 7E26551B
	global_store_d16_hi_b16 v[15:16], v17, off offset:160      // 0000001C3F68: DC9600A0 007C110F
	v_and_b32_e32 v33, 1, v0                                   // 0000001C3F70: 36420081
	v_div_scale_f32 v25, null, v28, v28, v22                   // 0000001C3F74: D6FC7C19 045A391C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C3F7C: BF870112
	v_add3_u32 v20, v20, v33, 0x7fff                           // 0000001C3F80: D6550014 03FE4314 00007FFF
	v_rcp_f32_e32 v34, v25                                     // 0000001C3F8C: 7E445519
	v_fma_f32 v18, -v27, v19, 1.0                              // 0000001C3F90: D6130012 23CA271B
	v_fma_f32 v33, 0xbfb8aa3b, v29, -v35                       // 0000001C3F98: D6130021 848E3AFF BFB8AA3B
	v_sub_f32_e32 v35, v35, v36                                // 0000001C3FA4: 08464923
	v_cvt_i32_f32_e32 v36, v36                                 // 0000001C3FA8: 7E481124
	global_store_d16_hi_b16 v[23:24], v20, off offset:160      // 0000001C3FAC: DC9600A0 007C1417
	v_fmac_f32_e32 v19, v18, v19                               // 0000001C3FB4: 56262712
	v_div_scale_f32 v18, vcc_lo, v21, v26, v21                 // 0000001C3FB8: D6FC6A12 04563515
	v_fmac_f32_e32 v33, 0xb2a5705f, v29                        // 0000001C3FC0: 56423AFF B2A5705F
	v_fma_f32 v37, -v25, v34, 1.0                              // 0000001C3FC8: D6130025 23CA4519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C3FD0: BF870193
	v_mul_f32_e32 v41, v18, v19                                // 0000001C3FD4: 10522712
	v_add_f32_e32 v33, v35, v33                                // 0000001C3FD8: 06424323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v38                         // 0000001C3FDC: 10464CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C3FE4: BF870004
	v_fmac_f32_e32 v34, v37, v34                               // 0000001C3FE8: 56444525
	v_div_scale_f32 v37, s0, v22, v28, v22                     // 0000001C3FEC: D6FC0025 045A3916
	v_fma_f32 v30, -v27, v41, v18                              // 0000001C3FF4: D613001E 244A531B
	v_exp_f32_e32 v33, v33                                     // 0000001C3FFC: 7E424B21
	v_fma_f32 v43, 0xbfb8aa3b, v38, -v35                       // 0000001C4000: D613002B 848E4CFF BFB8AA3B
	v_rndne_f32_e32 v44, v35                                   // 0000001C400C: 7E584723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C4010: BF870193
	v_dual_mul_f32 v42, v37, v34 :: v_dual_fmac_f32 v41, v30, v19// 0000001C4014: C8C04525 2A28271E
	v_fmac_f32_e32 v43, 0xb2a5705f, v38                        // 0000001C401C: 56564CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C4024: BF870193
	v_sub_f32_e32 v35, v35, v44                                // 0000001C4028: 08465923
	v_fma_f32 v30, -v25, v42, v37                              // 0000001C402C: D613001E 24965519
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001C4034: BF870294
	v_fma_f32 v17, -v27, v41, v18                              // 0000001C4038: D6130011 244A531B
	.long 0xd71c0012                                           // 0000001C4040: D71C0012
	v_cndmask_b32_e32 v1, v33, v36, vcc_lo                     // 0000001C4044: 02024921
	v_cvt_i32_f32_e32 v20, v44                                 // 0000001C4048: 7E28112C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C404C: BF870214
	v_dual_add_f32 v27, v35, v43 :: v_dual_fmac_f32 v42, v30, v34// 0000001C4050: C9005723 1B2A451E
	v_div_fmas_f32 v17, v17, v19, v41                          // 0000001C4058: D6370011 04A62711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001C4060: 7C3C3AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C4068: BF870213
	v_fma_f32 v19, -v25, v42, v37                              // 0000001C406C: D6130013 24965519
	v_exp_f32_e32 v25, v27                                     // 0000001C4074: 7E324B1B
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001C4078: 02242480
	s_mov_b32 vcc_lo, s0                                       // 0000001C407C: BEEA0000
	v_div_fixup_f32 v17, v17, v26, v21                         // 0000001C4080: D6270011 04563511
	v_div_fmas_f32 v19, v19, v34, v42                          // 0000001C4088: D6370013 04AA4513
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001C4090: 7C363AFF C2B17218
	.long 0x7f2a3980                                           // 0000001C4098: 7F2A3980
	v_lshlrev_b32_e32 v34, 16, v70                             // 0000001C409C: 30448C90
	.long 0x7e2a3991                                           // 0000001C40A0: 7E2A3991
	v_div_fixup_f32 v19, v19, v28, v22                         // 0000001C40A4: D6270013 045A3913
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001C40AC: 022424FF 7F800000
	.long 0xd71c0014                                           // 0000001C40B4: D71C0014
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 0000001C40B8: 02022919
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 0000001C40BC: 7C3C4CFF 42CE8ED0
	v_lshlrev_b32_e32 v25, 16, v104                            // 0000001C40C4: 3032D090
	.long 0x7e003993                                           // 0000001C40C8: 7E003993
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_and_b32 v21, 1, v21 // 0000001C40CC: C92424F2 12142A81
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001C40D4: 02282880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 0000001C40D8: 7C364CFF C2B17218
	v_mul_f32_e32 v27, 0xbfb8aa3b, v25                         // 0000001C40E0: 103632FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001C40E8: BF870234
	v_div_scale_f32 v22, null, v18, v18, v9                    // 0000001C40EC: D6FC7C16 04262512
	v_dual_mul_f32 v37, 0xbfb8aa3b, v34 :: v_dual_and_b32 v28, 1, v0// 0000001C40F4: C8E444FF 251C0081 BFB8AA3B
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 0000001C4100: 022828FF 7F800000
	v_fma_f32 v29, 0xbfb8aa3b, v25, -v27                       // 0000001C4108: D613001D 846E32FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001C4114: BF8701B4
	v_rcp_f32_e32 v26, v22                                     // 0000001C4118: 7E345516
	v_rndne_f32_e32 v30, v27                                   // 0000001C411C: 7E3C471B
	v_add3_u32 v17, v17, v21, 0x7fff                           // 0000001C4120: D6550011 03FE2B11 00007FFF
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_fmac_f32 v29, 0xb2a5705f, v25// 0000001C412C: C90028F2 141C32FF B2A5705F
	v_add3_u32 v19, v19, v28, 0x7fff                           // 0000001C4138: D6550013 03FE3913 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C4144: BF870224
	v_sub_f32_e32 v27, v27, v30                                // 0000001C4148: 08363D1B
	v_rndne_f32_e32 v28, v37                                   // 0000001C414C: 7E384725
	v_div_scale_f32 v33, null, v20, v20, v10                   // 0000001C4150: D6FC7C21 042A2914
	v_cvt_i32_f32_e32 v30, v30                                 // 0000001C4158: 7E3C111E
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001C415C: BF870005
	v_fma_f32 v35, -v22, v26, 1.0                              // 0000001C4160: D6130023 23CA3516
	v_add_f32_e32 v21, v27, v29                                // 0000001C4168: 062A3B1B
	v_fma_f32 v27, 0xbfb8aa3b, v34, -v37                       // 0000001C416C: D613001B 849644FF BFB8AA3B
	v_rcp_f32_e32 v36, v33                                     // 0000001C4178: 7E485521
	v_div_scale_f32 v29, vcc_lo, v9, v18, v9                   // 0000001C417C: D6FC6A1D 04262509
	v_fmac_f32_e32 v26, v35, v26                               // 0000001C4184: 56343523
	v_exp_f32_e32 v21, v21                                     // 0000001C4188: 7E2A4B15
	v_fmac_f32_e32 v27, 0xb2a5705f, v34                        // 0000001C418C: 563644FF B2A5705F
	v_sub_f32_e32 v37, v37, v28                                // 0000001C4194: 084A3925
	global_store_d16_hi_b16 v[31:32], v17, off offset:160      // 0000001C4198: DC9600A0 007C111F
	v_mul_f32_e32 v38, v29, v26                                // 0000001C41A0: 104C351D
	.long 0xd41e0001                                           // 0000001C41A4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001C41A8: 020232FF 42CE8ED0
	v_cvt_i32_f32_e32 v28, v28                                 // 0000001C41B0: 7E38111C
	v_fma_f32 v35, -v33, v36, 1.0                              // 0000001C41B4: D6130023 23CA4921
	v_add_f32_e32 v27, v37, v27                                // 0000001C41BC: 06363725
	global_store_d16_hi_b16 v[39:40], v19, off offset:160      // 0000001C41C0: DC9600A0 007C1327
	.long 0xd71c0011                                           // 0000001C41C8: D71C0011
	v_cndmask_b32_e32 v1, v21, v30, vcc_lo                     // 0000001C41CC: 02023D15
	v_fma_f32 v21, -v22, v38, v29                              // 0000001C41D0: D6130015 24764D16
	v_fmac_f32_e32 v36, v35, v36                               // 0000001C41D8: 56484923
	v_div_scale_f32 v35, s0, v10, v20, v10                     // 0000001C41DC: D6FC0023 042A290A
	v_exp_f32_e32 v27, v27                                     // 0000001C41E4: 7E364B1B
	v_cndmask_b32_e64 v17, 0, v17, s1                          // 0000001C41E8: D5010011 00062280
	v_fmac_f32_e32 v38, v21, v26                               // 0000001C41F0: 564C3515
	.long 0xd41b0001                                           // 0000001C41F4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v25, vcc_lo              // 0000001C41F8: 020232FF C2B17218
	v_dual_mul_f32 v30, v35, v36 :: v_dual_lshlrev_b32 v19, 16, v106// 0000001C4200: C8E24923 1E12D490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C4208: BF870193
	v_fma_f32 v22, -v22, v38, v29                              // 0000001C420C: D6130016 24764D16
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s1                 // 0000001C4214: D5010011 000622FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C4220: BF870213
	v_fma_f32 v21, -v33, v30, v35                              // 0000001C4224: D6130015 248E3D21
	.long 0xd41e0001                                           // 0000001C422C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v19, vcc_lo              // 0000001C4230: 020226FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C4238: BF870224
	v_div_fmas_f32 v22, v22, v26, v38                          // 0000001C423C: D6370016 049A3516
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 0000001C4244: 7C3C44FF 42CE8ED0
	v_fmac_f32_e32 v30, v21, v36                               // 0000001C424C: 563C4915
	.long 0xd71c0015                                           // 0000001C4250: D71C0015
	v_cndmask_b32_e32 v1, v27, v28, vcc_lo                     // 0000001C4254: 0202391B
	v_add_f32_e32 v17, 1.0, v17                                // 0000001C4258: 062222F2
	v_div_fixup_f32 v9, v22, v18, v9                           // 0000001C425C: D6270009 04262516
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C4264: BF870214
	v_fma_f32 v25, -v33, v30, v35                              // 0000001C4268: D6130019 248E3D21
	v_cndmask_b32_e32 v21, 0, v21, vcc_lo                      // 0000001C4270: 022A2A80
	s_mov_b32 vcc_lo, s0                                       // 0000001C4274: BEEA0000
	v_div_scale_f32 v26, null, v17, v17, v11                   // 0000001C4278: D6FC7C1A 042E2311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001C4280: BF870233
	v_div_fmas_f32 v25, v25, v36, v30                          // 0000001C4284: D6370019 047A4919
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 0000001C428C: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v34, 16, v105                            // 0000001C4294: 3044D290
	v_rcp_f32_e32 v27, v26                                     // 0000001C4298: 7E36551A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C429C: BF870003
	v_div_fixup_f32 v10, v25, v20, v10                         // 0000001C42A0: D627000A 042A2919
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001C42A8: 022A2AFF 7F800000
	v_mul_f32_e32 v25, 0xbfb8aa3b, v19                         // 0000001C42B0: 103226FF BFB8AA3B
	v_div_scale_f32 v33, vcc_lo, v11, v17, v11                 // 0000001C42B8: D6FC6A21 042E230B
	v_mul_f32_e32 v36, 0xbfb8aa3b, v34                         // 0000001C42C0: 104844FF BFB8AA3B
	.long 0x7e00398a                                           // 0000001C42C8: 7E00398A
	v_add_f32_e32 v18, 1.0, v21                                // 0000001C42CC: 06242AF2
	v_fma_f32 v29, 0xbfb8aa3b, v19, -v25                       // 0000001C42D0: D613001D 846626FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001C42DC: BF870005
	v_fma_f32 v21, -v26, v27, 1.0                              // 0000001C42E0: D6130015 23CA371A
	v_rndne_f32_e32 v30, v25                                   // 0000001C42E8: 7E3C4719
	v_and_b32_e32 v28, 1, v0                                   // 0000001C42EC: 36380081
	v_div_scale_f32 v22, null, v18, v18, v12                   // 0000001C42F0: D6FC7C16 04322512
	v_fmac_f32_e32 v29, 0xb2a5705f, v19                        // 0000001C42F8: 563A26FF B2A5705F
	v_fmac_f32_e32 v27, v21, v27                               // 0000001C4300: 56363715
	v_sub_f32_e32 v25, v25, v30                                // 0000001C4304: 08323D19
	.long 0x7e283989                                           // 0000001C4308: 7E283989
	v_rcp_f32_e32 v21, v22                                     // 0000001C430C: 7E2A5516
	.long 0x7f283980                                           // 0000001C4310: 7F283980
	v_mul_f32_e32 v35, v33, v27                                // 0000001C4314: 10463721
	v_add_f32_e32 v25, v25, v29                                // 0000001C4318: 06323B19
	v_fma_f32 v37, 0xbfb8aa3b, v34, -v36                       // 0000001C431C: D6130025 849244FF BFB8AA3B
	v_rndne_f32_e32 v38, v36                                   // 0000001C4328: 7E4C4724
	v_add3_u32 v10, v10, v28, 0x7fff                           // 0000001C432C: D655000A 03FE390A 00007FFF
	v_and_b32_e32 v20, 1, v20                                  // 0000001C4338: 36282881
	v_fma_f32 v29, -v26, v35, v33                              // 0000001C433C: D613001D 2486471A
	v_exp_f32_e32 v25, v25                                     // 0000001C4344: 7E324B19
	v_fma_f32 v28, -v22, v21, 1.0                              // 0000001C4348: D613001C 23CA2B16
	v_fmac_f32_e32 v37, 0xb2a5705f, v34                        // 0000001C4350: 564A44FF B2A5705F
	v_sub_f32_e32 v36, v36, v38                                // 0000001C4358: 08484D24
	v_add3_u32 v9, v9, v20, 0x7fff                             // 0000001C435C: D6550009 03FE2909 00007FFF
	v_cvt_i32_f32_e32 v20, v30                                 // 0000001C4368: 7E28111E
	v_fmac_f32_e32 v21, v28, v21                               // 0000001C436C: 562A2B1C
	v_div_scale_f32 v28, s0, v12, v18, v12                     // 0000001C4370: D6FC001C 0432250C
	v_dual_fmac_f32 v35, v29, v27 :: v_dual_add_f32 v30, v36, v37// 0000001C4378: C808371D 231E4B24
	global_store_d16_hi_b16 v[7:8], v9, off offset:192         // 0000001C4380: DC9600C0 007C0907
	.long 0xd71c0009                                           // 0000001C4388: D71C0009
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 0000001C438C: 02022919
	v_mul_f32_e32 v29, v28, v21                                // 0000001C4390: 103A2B1C
	v_fma_f32 v20, -v26, v35, v33                              // 0000001C4394: D6130014 2486471A
	v_exp_f32_e32 v26, v30                                     // 0000001C439C: 7E344B1E
	global_store_d16_hi_b16 v[47:48], v10, off offset:192      // 0000001C43A0: DC9600C0 007C0A2F
	v_cndmask_b32_e64 v9, 0, v9, s1                            // 0000001C43A8: D5010009 00061280
	v_fma_f32 v25, -v22, v29, v28                              // 0000001C43B0: D6130019 24723B16
	v_div_fmas_f32 v20, v20, v27, v35                          // 0000001C43B8: D6370014 048E3714
	v_cvt_i32_f32_e32 v27, v38                                 // 0000001C43C0: 7E361126
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v19                  // 0000001C43C4: 7C3626FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C43CC: BF870214
	v_fmac_f32_e32 v29, v25, v21                               // 0000001C43D0: 563A2B19
	v_div_fixup_f32 v11, v20, v17, v11                         // 0000001C43D4: D627000B 042E2314
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C43DC: BF870004
	.long 0xd71c0011                                           // 0000001C43E0: D71C0011
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000001C43E4: 0202371A
	v_cndmask_b32_e32 v9, 0x7f800000, v9, vcc_lo               // 0000001C43E8: 021212FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 0000001C43F0: 7C3C44FF 42CE8ED0
	v_fma_f32 v19, -v22, v29, v28                              // 0000001C43F8: D6130013 24723B16
	s_waitcnt vmcnt(1)                                         // 0000001C4400: BF8907F7
	v_lshlrev_b32_e32 v25, 16, v67                             // 0000001C4404: 30328690
	.long 0x7e2c398b                                           // 0000001C4408: 7E2C398B
	v_add_f32_e32 v9, 1.0, v9                                  // 0000001C440C: 061212F2
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000001C4410: 02222280
	s_mov_b32 vcc_lo, s0                                       // 0000001C4414: BEEA0000
	v_mul_f32_e32 v30, 0xbfb8aa3b, v25                         // 0000001C4418: 103C32FF BFB8AA3B
	v_div_fmas_f32 v19, v19, v21, v29                          // 0000001C4420: D6370013 04762B13
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 0000001C4428: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v21, 16, v69                             // 0000001C4430: 302A8A90
	v_div_scale_f32 v20, null, v9, v9, v13                     // 0000001C4434: D6FC7C14 04361309
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v30                       // 0000001C443C: D6130022 847A32FF BFB8AA3B
	v_div_fixup_f32 v12, v19, v18, v12                         // 0000001C4448: D627000C 04322513
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 0000001C4450: 022222FF 7F800000
	v_mul_f32_e32 v19, 0xbfb8aa3b, v21                         // 0000001C4458: 10262AFF BFB8AA3B
	v_rcp_f32_e32 v18, v20                                     // 0000001C4460: 7E245514
	v_rndne_f32_e32 v35, v30                                   // 0000001C4464: 7E46471E
	v_fmac_f32_e32 v34, 0xb2a5705f, v25                        // 0000001C4468: 564432FF B2A5705F
	v_add_f32_e32 v17, 1.0, v17                                // 0000001C4470: 062222F2
	v_fma_f32 v27, 0xbfb8aa3b, v21, -v19                       // 0000001C4474: D613001B 844E2AFF BFB8AA3B
	v_rndne_f32_e32 v28, v19                                   // 0000001C4480: 7E384713
	.long 0xd41e0001                                           // 0000001C4484: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v21, vcc_lo              // 0000001C4488: 02022AFF 42CE8ED0
	.long 0x7e00398c                                           // 0000001C4490: 7E00398C
	v_div_scale_f32 v26, null, v17, v17, v14                   // 0000001C4494: D6FC7C1A 043A2311
	v_fmac_f32_e32 v27, 0xb2a5705f, v21                        // 0000001C449C: 56362AFF B2A5705F
	v_sub_f32_e32 v19, v19, v28                                // 0000001C44A4: 08263913
	v_fma_f32 v29, -v20, v18, 1.0                              // 0000001C44A8: D613001D 23CA2514
	v_cvt_i32_f32_e32 v28, v28                                 // 0000001C44B0: 7E38111C
	v_rcp_f32_e32 v33, v26                                     // 0000001C44B4: 7E42551A
	.long 0x7f2c3980                                           // 0000001C44B8: 7F2C3980
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001C44BC: BF8701B3
	v_dual_add_f32 v19, v19, v27 :: v_dual_fmac_f32 v18, v29, v18// 0000001C44C0: C9003713 1312251D
	v_div_scale_f32 v27, vcc_lo, v13, v9, v13                  // 0000001C44C8: D6FC6A1B 0436130D
	v_dual_sub_f32 v29, v30, v35 :: v_dual_and_b32 v36, 1, v0  // 0000001C44D0: C964471E 1D240081
	v_exp_f32_e32 v19, v19                                     // 0000001C44D8: 7E264B13
	v_and_b32_e32 v22, 1, v22                                  // 0000001C44DC: 362C2C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001C44E0: BF870313
	v_mul_f32_e32 v37, v27, v18                                // 0000001C44E4: 104A251B
	v_fma_f32 v30, -v26, v33, 1.0                              // 0000001C44E8: D613001E 23CA431A
	v_add_f32_e32 v29, v29, v34                                // 0000001C44F0: 063A451D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C44F4: BF870214
	v_add3_u32 v10, v11, v22, 0x7fff                           // 0000001C44F8: D655000A 03FE2D0B 00007FFF
	v_fma_f32 v34, -v20, v37, v27                              // 0000001C4504: D6130022 246E4B14
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C450C: BF870004
	v_fmac_f32_e32 v33, v30, v33                               // 0000001C4510: 5642431E
	v_div_scale_f32 v30, s0, v14, v17, v14                     // 0000001C4514: D6FC001E 043A230E
	v_exp_f32_e32 v29, v29                                     // 0000001C451C: 7E3A4B1D
	.long 0xd71c0013                                           // 0000001C4520: D71C0013
	v_cndmask_b32_e32 v1, v19, v28, vcc_lo                     // 0000001C4524: 02023913
	v_fmac_f32_e32 v37, v34, v18                               // 0000001C4528: 564A2522
	v_cvt_i32_f32_e32 v34, v35                                 // 0000001C452C: 7E441123
	v_mul_f32_e32 v28, v30, v33                                // 0000001C4530: 1038431E
	v_add3_u32 v11, v12, v36, 0x7fff                           // 0000001C4534: D655000B 03FE490C 00007FFF
	v_cndmask_b32_e64 v19, 0, v19, s1                          // 0000001C4540: D5010013 00062680
	.long 0xd41b0001                                           // 0000001C4548: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v21, vcc_lo              // 0000001C454C: 02022AFF C2B17218
	v_fma_f32 v20, -v20, v37, v27                              // 0000001C4554: D6130014 246E4B14
	v_fma_f32 v35, -v26, v28, v30                              // 0000001C455C: D6130023 247A391A
	.long 0xd71c001b                                           // 0000001C4564: D71C001B
	v_cndmask_b32_e32 v1, v29, v34, vcc_lo                     // 0000001C4568: 0202451D
	global_store_d16_hi_b16 v[15:16], v10, off offset:192      // 0000001C456C: DC9600C0 007C0A0F
	v_cndmask_b32_e64 v19, 0x7f800000, v19, s1                 // 0000001C4574: D5010013 000626FF 7F800000
	.long 0xd41e0001                                           // 0000001C4580: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001C4584: 020232FF 42CE8ED0
	v_fmac_f32_e32 v28, v35, v33                               // 0000001C458C: 56384323
	v_div_fmas_f32 v18, v20, v18, v37                          // 0000001C4590: D6370012 04962514
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001C4598: 7C3632FF C2B17218
	v_add_f32_e32 v19, 1.0, v19                                // 0000001C45A0: 062626F2
	v_cndmask_b32_e64 v21, 0, v27, s1                          // 0000001C45A4: D5010015 00063680
	v_fma_f32 v20, -v26, v28, v30                              // 0000001C45AC: D6130014 247A391A
	v_div_fixup_f32 v9, v18, v9, v13                           // 0000001C45B4: D6270009 04361312
	global_store_d16_hi_b16 v[23:24], v11, off offset:192      // 0000001C45BC: DC9600C0 007C0B17
	v_div_scale_f32 v26, null, v19, v19, v1                    // 0000001C45C4: D6FC7C1A 04062713
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001C45CC: 022A2AFF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001C45D4: BEEA0000
	v_lshlrev_b32_e32 v18, 16, v56                             // 0000001C45D8: 30247090
	v_div_fmas_f32 v20, v20, v33, v28                          // 0000001C45DC: D6370014 04724314
	v_rcp_f32_e32 v25, v26                                     // 0000001C45E4: 7E32551A
	v_add_f32_e32 v21, 1.0, v21                                // 0000001C45E8: 062A2AF2
	v_lshlrev_b32_e32 v29, 16, v55                             // 0000001C45EC: 303A6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C45F0: BF870223
	v_div_fixup_f32 v12, v20, v17, v14                         // 0000001C45F4: D627000C 043A2314
	.long 0x7e223989                                           // 0000001C45FC: 7E223989
	v_div_scale_f32 v14, null, v21, v21, v2                    // 0000001C4600: D6FC7C0E 040A2B15
	.long 0x7f223980                                           // 0000001C4608: 7F223980
	v_mul_f32_e32 v30, 0xbfb8aa3b, v29                         // 0000001C460C: 103C3AFF BFB8AA3B
	.long 0x7e00398c                                           // 0000001C4614: 7E00398C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001C4618: BF8701B5
	v_fma_f32 v10, -v26, v25, 1.0                              // 0000001C461C: D613000A 23CA331A
	v_rcp_f32_e32 v13, v14                                     // 0000001C4624: 7E1A550E
	v_and_b32_e32 v17, 1, v17                                  // 0000001C4628: 36222281
	v_and_b32_e32 v11, 1, v0                                   // 0000001C462C: 36160081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C4630: BF870223
	v_fmac_f32_e32 v25, v10, v25                               // 0000001C4634: 5632330A
	v_div_scale_f32 v10, vcc_lo, v1, v19, v1                   // 0000001C4638: D6FC6A0A 04062701
	v_add3_u32 v9, v9, v17, 0x7fff                             // 0000001C4640: D6550009 03FE2309 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C464C: BF870224
	v_add3_u32 v11, v12, v11, 0x7fff                           // 0000001C4650: D655000B 03FE170C 00007FFF
	v_mul_f32_e32 v12, 0xbfb8aa3b, v18                         // 0000001C465C: 101824FF BFB8AA3B
	v_mul_f32_e32 v20, v10, v25                                // 0000001C4664: 1028330A
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001C4668: BF870005
	v_fma_f32 v22, -v14, v13, 1.0                              // 0000001C466C: D6130016 23CA1B0E
	s_clause 0x1                                               // 0000001C4674: BF850001
	global_store_d16_hi_b16 v[31:32], v9, off offset:192       // 0000001C4678: DC9600C0 007C091F
	global_store_d16_hi_b16 v[39:40], v11, off offset:192      // 0000001C4680: DC9600C0 007C0B27
	v_fma_f32 v27, 0xbfb8aa3b, v18, -v12                       // 0000001C4688: D613001B 843224FF BFB8AA3B
	v_fma_f32 v17, -v26, v20, v10                              // 0000001C4694: D6130011 242A291A
	v_fmac_f32_e32 v13, v22, v13                               // 0000001C469C: 561A1B16
	v_div_scale_f32 v22, s0, v2, v21, v2                       // 0000001C46A0: D6FC0016 040A2B02
	v_rndne_f32_e32 v28, v12                                   // 0000001C46A8: 7E38470C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C46AC: BF870114
	v_dual_fmac_f32 v27, 0xb2a5705f, v18 :: v_dual_fmac_f32 v20, v17, v25// 0000001C46B0: C80024FF 1B143311 B2A5705F
	v_dual_mul_f32 v17, v22, v13 :: v_dual_sub_f32 v12, v12, v28// 0000001C46BC: C8CA1B16 110C390C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001C46C4: BF8701A2
	v_fma_f32 v9, -v26, v20, v10                               // 0000001C46C8: D6130009 242A291A
	v_fma_f32 v26, 0xbfb8aa3b, v29, -v30                       // 0000001C46D0: D613001A 847A3AFF BFB8AA3B
	v_fma_f32 v10, -v14, v17, v22                              // 0000001C46DC: D613000A 245A230E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C46E4: BF870004
	v_add_f32_e32 v12, v12, v27                                // 0000001C46E8: 0618370C
	v_rndne_f32_e32 v27, v30                                   // 0000001C46EC: 7E36471E
	v_div_fmas_f32 v9, v9, v25, v20                            // 0000001C46F0: D6370009 04523309
	v_fmac_f32_e32 v26, 0xb2a5705f, v29                        // 0000001C46F8: 56343AFF B2A5705F
	v_fmac_f32_e32 v17, v10, v13                               // 0000001C4700: 56221B0A
	v_exp_f32_e32 v10, v12                                     // 0000001C4704: 7E144B0C
	v_sub_f32_e32 v12, v30, v27                                // 0000001C4708: 0818371E
	v_lshlrev_b32_e32 v20, 16, v63                             // 0000001C470C: 30287E90
	v_cvt_i32_f32_e32 v25, v28                                 // 0000001C4710: 7E32111C
	v_fma_f32 v14, -v14, v17, v22                              // 0000001C4714: D613000E 245A230E
	s_waitcnt vmcnt(0)                                         // 0000001C471C: BF8903F7
	v_lshlrev_b32_e32 v22, 16, v64                             // 0000001C4720: 302C8090
	v_add_f32_e32 v12, v12, v26                                // 0000001C4724: 0618350C
	v_mul_f32_e32 v26, 0xbfb8aa3b, v20                         // 0000001C4728: 103428FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v18                  // 0000001C4730: 7C3C24FF 42CE8ED0
	v_cvt_i32_f32_e32 v27, v27                                 // 0000001C4738: 7E36111B
	v_mul_f32_e32 v28, 0xbfb8aa3b, v22                         // 0000001C473C: 10382CFF BFB8AA3B
	.long 0xd71c000a                                           // 0000001C4744: D71C000A
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 0000001C4748: 0202330A
	v_fma_f32 v25, 0xbfb8aa3b, v20, -v26                       // 0000001C474C: D6130019 846A28FF BFB8AA3B
	v_rndne_f32_e32 v30, v26                                   // 0000001C4758: 7E3C471A
	v_exp_f32_e32 v12, v12                                     // 0000001C475C: 7E184B0C
	v_fma_f32 v33, 0xbfb8aa3b, v22, -v28                       // 0000001C4760: D6130021 84722CFF BFB8AA3B
	v_rndne_f32_e32 v34, v28                                   // 0000001C476C: 7E44471C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C4770: BF870223
	v_dual_fmac_f32 v25, 0xb2a5705f, v20 :: v_dual_sub_f32 v26, v26, v30// 0000001C4774: C80A28FF 191A3D1A B2A5705F
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000001C4780: 02141480
	v_fmac_f32_e32 v33, 0xb2a5705f, v22                        // 0000001C4784: 56422CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 0000001C478C: BF8702B4
	v_sub_f32_e32 v28, v28, v34                                // 0000001C4790: 0838451C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v18                  // 0000001C4794: 7C3624FF C2B17218
	v_add_f32_e32 v25, v26, v25                                // 0000001C479C: 0632331A
	.long 0xd71c000c                                           // 0000001C47A0: D71C000C
	v_cndmask_b32_e32 v1, v12, v27, vcc_lo                     // 0000001C47A4: 0202370C
	v_cvt_i32_f32_e32 v27, v34                                 // 0000001C47A8: 7E361122
	v_add_f32_e32 v26, v28, v33                                // 0000001C47AC: 0634431C
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo             // 0000001C47B0: 021414FF 7F800000
	v_exp_f32_e32 v18, v25                                     // 0000001C47B8: 7E244B19
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001C47BC: 7C3C3AFF 42CE8ED0
	v_div_fixup_f32 v1, v9, v19, v1                            // 0000001C47C4: D6270001 04062709
	v_exp_f32_e32 v25, v26                                     // 0000001C47CC: 7E324B1A
	v_cvt_i32_f32_e32 v26, v30                                 // 0000001C47D0: 7E34111E
	v_add_f32_e32 v10, 1.0, v10                                // 0000001C47D4: 061414F2
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 0000001C47D8: 02181880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001C47DC: 7C363AFF C2B17218
	.long 0x7e443981                                           // 0000001C47E4: 7E443981
	.long 0x7f443980                                           // 0000001C47E8: 7F443980
	.long 0xd71c0012                                           // 0000001C47EC: D71C0012
	v_cndmask_b32_e32 v1, v18, v26, vcc_lo                     // 0000001C47F0: 02023512
	v_div_scale_f32 v26, null, v10, v10, v3                    // 0000001C47F4: D6FC7C1A 040E150A
	v_cndmask_b32_e32 v12, 0x7f800000, v12, vcc_lo             // 0000001C47FC: 021818FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v20                  // 0000001C4804: 7C3C28FF 42CE8ED0
	.long 0xd71c0019                                           // 0000001C480C: D71C0019
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 0000001C4810: 02023719
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C4814: BF870194
	v_rcp_f32_e32 v27, v26                                     // 0000001C4818: 7E36551A
	v_add_f32_e32 v12, 1.0, v12                                // 0000001C481C: 061818F2
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001C4820: 02242480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v22                  // 0000001C4824: 7C3C2CFF 42CE8ED0
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000001C482C: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v20                  // 0000001C4830: 7C3628FF C2B17218
	v_div_scale_f32 v20, null, v12, v12, v4                    // 0000001C4838: D6FC7C14 0412190C
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001C4840: 022424FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v22                  // 0000001C4848: 7C362CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C4850: BF870113
	v_rcp_f32_e32 v28, v20                                     // 0000001C4854: 7E385514
	v_add_f32_e32 v18, 1.0, v18                                // 0000001C4858: 062424F2
	v_cndmask_b32_e32 v22, 0x7f800000, v25, vcc_lo             // 0000001C485C: 022C32FF 7F800000
	v_fma_f32 v25, -v26, v27, 1.0                              // 0000001C4864: D6130019 23CA371A
	s_mov_b32 vcc_lo, s0                                       // 0000001C486C: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C4870: BF870193
	v_div_scale_f32 v29, null, v18, v18, v5                    // 0000001C4874: D6FC7C1D 04162512
	v_add_f32_e32 v22, 1.0, v22                                // 0000001C487C: 062C2CF2
	v_div_fmas_f32 v13, v14, v13, v17                          // 0000001C4880: D637000D 04461B0E
	v_fmac_f32_e32 v27, v25, v27                               // 0000001C4888: 56363719
	v_div_scale_f32 v17, vcc_lo, v3, v10, v3                   // 0000001C488C: D6FC6A11 040E1503
	v_rcp_f32_e32 v14, v29                                     // 0000001C4894: 7E1C551D
	v_div_scale_f32 v25, null, v22, v22, v6                    // 0000001C4898: D6FC7C19 041A2D16
	v_fma_f32 v30, -v20, v28, 1.0                              // 0000001C48A0: D613001E 23CA3914
	v_div_fixup_f32 v2, v13, v21, v2                           // 0000001C48A8: D6270002 040A2B0D
	v_mul_f32_e32 v11, v17, v27                                // 0000001C48B0: 10163711
	v_div_scale_f32 v21, s0, v4, v12, v4                       // 0000001C48B4: D6FC0015 04121904
	v_rcp_f32_e32 v13, v25                                     // 0000001C48BC: 7E1A5519
	v_fmac_f32_e32 v28, v30, v28                               // 0000001C48C0: 5638391E
	.long 0x7e003982                                           // 0000001C48C4: 7E003982
	v_fma_f32 v9, -v26, v11, v17                               // 0000001C48C8: D6130009 2446171A
	v_fma_f32 v30, -v29, v14, 1.0                              // 0000001C48D0: D613001E 23CA1D1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C48D8: BF870114
	v_mul_f32_e32 v19, v21, v28                                // 0000001C48DC: 10263915
	v_dual_fmac_f32 v11, v9, v27 :: v_dual_fmac_f32 v14, v30, v14// 0000001C48E0: C8003709 0B0E1D1E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C48E8: BF870225
	v_fma_f32 v33, -v25, v13, 1.0                              // 0000001C48EC: D6130021 23CA1B19
	v_div_scale_f32 v30, s1, v5, v18, v5                       // 0000001C48F4: D6FC011E 04162505
	v_fma_f32 v9, -v20, v19, v21                               // 0000001C48FC: D6130009 24562714
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C4904: BF870214
	v_fma_f32 v17, -v26, v11, v17                              // 0000001C4908: D6130011 2446171A
	v_fmac_f32_e32 v13, v33, v13                               // 0000001C4910: 561A1B21
	v_div_scale_f32 v33, s2, v6, v22, v6                       // 0000001C4914: D6FC0221 041A2D06
	v_mul_f32_e32 v35, v30, v14                                // 0000001C491C: 10461D1E
	v_fmac_f32_e32 v19, v9, v28                                // 0000001C4920: 56263909
	v_div_fmas_f32 v11, v17, v27, v11                          // 0000001C4924: D637000B 042E3711
	s_mov_b32 vcc_lo, s0                                       // 0000001C492C: BEEA0000
	v_mul_f32_e32 v26, v33, v13                                // 0000001C4930: 10341B21
	v_fma_f32 v9, -v29, v35, v30                               // 0000001C4934: D6130009 247A471D
	v_fma_f32 v17, -v20, v19, v21                              // 0000001C493C: D6130011 24562714
	v_div_fixup_f32 v3, v11, v10, v3                           // 0000001C4944: D6270003 040E150B
	v_and_b32_e32 v11, 1, v34                                  // 0000001C494C: 36164481
	v_fma_f32 v20, -v25, v26, v33                              // 0000001C4950: D6130014 24863519
	v_fmac_f32_e32 v35, v9, v14                                // 0000001C4958: 56461D09
	v_div_fmas_f32 v9, v17, v28, v19                           // 0000001C495C: D6370009 044E3911
	s_mov_b32 vcc_lo, s1                                       // 0000001C4964: BEEA0001
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C4968: BF870193
	v_dual_fmac_f32 v26, v20, v13 :: v_dual_and_b32 v17, 1, v0 // 0000001C496C: C8241B14 1A100081
	v_fma_f32 v10, -v29, v35, v30                              // 0000001C4974: D613000A 247A471D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C497C: BF870003
	v_div_fixup_f32 v4, v9, v12, v4                            // 0000001C4980: D6270004 04121909
	.long 0x7f183980                                           // 0000001C4988: 7F183980
	v_add3_u32 v1, v1, v11, 0x7fff                             // 0000001C498C: D6550001 03FE1701 00007FFF
	v_fma_f32 v9, -v25, v26, v33                               // 0000001C4998: D6130009 24863519
	v_div_fmas_f32 v10, v10, v14, v35                          // 0000001C49A0: D637000A 048E1D0A
	s_mov_b32 vcc_lo, s2                                       // 0000001C49A8: BEEA0002
	.long 0x7e003984                                           // 0000001C49AC: 7E003984
	v_add3_u32 v2, v2, v17, 0x7fff                             // 0000001C49B0: D6550002 03FE2302 00007FFF
	v_div_fmas_f32 v9, v9, v13, v26                            // 0000001C49BC: D6370009 046A1B09
	v_div_fixup_f32 v5, v10, v18, v5                           // 0000001C49C4: D6270005 0416250A
	.long 0x7e143983                                           // 0000001C49CC: 7E143983
	.long 0x7f143980                                           // 0000001C49D0: 7F143980
	global_store_d16_hi_b16 v[7:8], v1, off offset:224         // 0000001C49D4: DC9600E0 007C0107
	v_div_fixup_f32 v6, v9, v22, v6                            // 0000001C49DC: D6270006 041A2D09
	.long 0x7e183985                                           // 0000001C49E4: 7E183985
	v_and_b32_e32 v9, 1, v0                                    // 0000001C49E8: 36120081
	v_and_b32_e32 v10, 1, v10                                  // 0000001C49EC: 36141481
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001C49F0: BF870214
	.long 0x7e003986                                           // 0000001C49F4: 7E003986
	v_and_b32_e32 v11, 1, v12                                  // 0000001C49F8: 36161881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001C49FC: BF870223
	v_add3_u32 v1, v3, v10, 0x7fff                             // 0000001C4A00: D6550001 03FE1503 00007FFF
	v_add3_u32 v3, v4, v9, 0x7fff                              // 0000001C4A0C: D6550003 03FE1304 00007FFF
	v_and_b32_e32 v0, 1, v0                                    // 0000001C4A18: 36000081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C4A1C: BF870114
	v_add3_u32 v4, v5, v11, 0x7fff                             // 0000001C4A20: D6550004 03FE1705 00007FFF
	v_add3_u32 v0, v6, v0, 0x7fff                              // 0000001C4A2C: D6550000 03FE0106 00007FFF
	s_clause 0x4                                               // 0000001C4A38: BF850004
	global_store_d16_hi_b16 v[47:48], v2, off offset:224       // 0000001C4A3C: DC9600E0 007C022F
	global_store_d16_hi_b16 v[15:16], v1, off offset:224       // 0000001C4A44: DC9600E0 007C010F
	global_store_d16_hi_b16 v[23:24], v3, off offset:224       // 0000001C4A4C: DC9600E0 007C0317
	global_store_d16_hi_b16 v[31:32], v4, off offset:224       // 0000001C4A54: DC9600E0 007C041F
	global_store_d16_hi_b16 v[39:40], v0, off offset:224       // 0000001C4A5C: DC9600E0 007C0027
	s_nop 0                                                    // 0000001C4A64: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001C4A68: BFB60003
	s_endpgm                                                   // 0000001C4A6C: BFB00000
		...

