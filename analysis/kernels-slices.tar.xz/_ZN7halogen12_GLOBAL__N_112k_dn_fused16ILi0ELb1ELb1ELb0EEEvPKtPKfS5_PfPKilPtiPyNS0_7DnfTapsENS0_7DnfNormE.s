000000000000f500 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE>:
; _ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE():
	s_clause 0x1                                               // 00000000F500: BF850001
	s_load_b256 s[20:27], s[0:1], 0x20                         // 00000000F504: F40C0500 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 00000000F50C: F40C0200 F8000000
	v_readfirstlane_b32 s3, v0                                 // 00000000F514: 7E060500
	v_dual_mov_b32 v142, 0 :: v_dual_lshlrev_b32 v1, 5, v0     // 00000000F518: CA220080 8E000085
	v_lshrrev_b32_e32 v73, 4, v0                               // 00000000F520: 32920084
	s_load_b32 s29, s[0:1], 0x38                               // 00000000F524: F4000740 F8000038
	v_lshlrev_b32_e32 v66, 4, v0                               // 00000000F52C: 30840084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000F530: BF870193
	v_and_b32_e32 v3, 0x200, v1                                // 00000000F534: 360602FF 00000200
	v_lshlrev_b32_e32 v65, 9, v73                              // 00000000F53C: 30829289
	s_waitcnt lgkmcnt(0)                                       // 00000000F540: BF89FC07
	s_load_b32 s6, s[20:21], null                              // 00000000F544: F400018A F8000000
	s_lshr_b32 s20, s3, 5                                      // 00000000F54C: 85148503
	s_lshl_b64 s[4:5], s[22:23], 2                             // 00000000F550: 84848216
	s_lshl_b32 s28, s20, 4                                     // 00000000F554: 841C8414
	s_ashr_i32 s3, s2, 31                                      // 00000000F558: 86039F02
	v_and_or_b32 v141, v0, 15, s28                             // 00000000F55C: D657008D 00711F00
	s_add_u32 s4, s14, s4                                      // 00000000F564: 8004040E
	s_addc_u32 s5, s15, s5                                     // 00000000F568: 8205050F
	s_lshl_b64 s[22:23], s[2:3], 16                            // 00000000F56C: 84969002
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000F570: BF870001
	.long 0xd73c0001                                           // 00000000F574: D73C0001
	v_cndmask_b32_e32 v1, 2, v141, vcc_lo                      // 00000000F578: 02031A82
	s_add_u32 s4, s4, s22                                      // 00000000F57C: 80041604
	s_addc_u32 s5, s5, s23                                     // 00000000F580: 82051705
	s_waitcnt lgkmcnt(0)                                       // 00000000F584: BF89FC07
	s_mul_i32 s7, s6, 0x9000000                                // 00000000F588: 9607FF06 09000000
	s_mul_hi_i32 s6, s6, 0x9000000                             // 00000000F590: 9706FF06 09000000
	s_add_u32 s4, s4, s7                                       // 00000000F598: 80040704
	s_addc_u32 s5, s5, s6                                      // 00000000F59C: 82050605
	.long 0xd7006a3f                                           // 00000000F5A0: D7006A3F
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000000F5A4: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000000F5A8: BF8700B1
	v_add_co_ci_u32_e64 v64, null, s5, v2, vcc_lo              // 00000000F5AC: D5207C40 01AA0405
	s_add_i32 s30, s29, -1                                     // 00000000F5B4: 811EC11D
	.long 0xd7006abe                                           // 00000000F5B8: D7006ABE
	v_cndmask_b32_e32 v1, v63, v3, vcc_lo                      // 00000000F5BC: 0202073F
	v_add_co_ci_u32_e64 v191, null, 0, v64, vcc_lo             // 00000000F5C0: D5207CBF 01AA8080
	s_mul_hi_i32 s4, s2, 0x55555556                            // 00000000F5C8: 9704FF02 55555556
	.long 0xd7006a01                                           // 00000000F5D0: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v190, vcc_lo                 // 00000000F5D4: 02037CFF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000F5DC: BF8700A1
	v_add_co_ci_u32_e64 v2, null, 0, v191, vcc_lo              // 00000000F5E0: D5207C02 01AB7E80
	.long 0xd7006a11                                           // 00000000F5E8: D7006A11
	v_cndmask_b32_e32 v0, v190, v255, vcc_lo                   // 00000000F5EC: 0201FFBE
	.long 0x00002000                                           // 00000000F5F0: 00002000
	v_add_co_ci_u32_e64 v18, null, 0, v191, vcc_lo             // 00000000F5F4: D5207C12 01AB7E80
	.long 0xd7006a07                                           // 00000000F5FC: D7006A07
	v_cndmask_b32_e32 v1, 0x2000, v190, vcc_lo                 // 00000000F600: 02037CFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000F608: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v191, vcc_lo              // 00000000F60C: D5207C08 01AB7E80
	.long 0xd7006a09                                           // 00000000F614: D7006A09
	v_cndmask_b32_e32 v1, 0x3000, v190, vcc_lo                 // 00000000F618: 02037CFF 00003000
	v_add_co_ci_u32_e64 v10, null, 0, v191, vcc_lo             // 00000000F620: D5207C0A 01AB7E80
	.long 0xd7006a13                                           // 00000000F628: D7006A13
	v_cndmask_b32_e32 v0, v190, v255, vcc_lo                   // 00000000F62C: 0201FFBE
	.long 0x00004000                                           // 00000000F630: 00004000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000F634: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v191, vcc_lo             // 00000000F638: D5207C14 01AB7E80
	.long 0xd7006a15                                           // 00000000F640: D7006A15
	v_cndmask_b32_e32 v1, 0x4000, v190, vcc_lo                 // 00000000F644: 02037CFF 00004000
	v_add_co_ci_u32_e64 v22, null, 0, v191, vcc_lo             // 00000000F64C: D5207C16 01AB7E80
	.long 0xd7006a17                                           // 00000000F654: D7006A17
	v_cndmask_b32_e32 v1, 0x5000, v190, vcc_lo                 // 00000000F658: 02037CFF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000F660: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v191, vcc_lo             // 00000000F664: D5207C18 01AB7E80
	.long 0xd7006a19                                           // 00000000F66C: D7006A19
	v_cndmask_b32_e32 v0, v190, v255, vcc_lo                   // 00000000F670: 0201FFBE
	.long 0x00006000                                           // 00000000F674: 00006000
	v_add_co_ci_u32_e64 v26, null, 0, v191, vcc_lo             // 00000000F678: D5207C1A 01AB7E80
	.long 0xd7006a1b                                           // 00000000F680: D7006A1B
	v_cndmask_b32_e32 v1, 0x6000, v190, vcc_lo                 // 00000000F684: 02037CFF 00006000
	s_clause 0x7                                               // 00000000F68C: BF850007
	global_load_b32 v4, v[1:2], off offset:1024                // 00000000F690: DC520400 047C0001
	global_load_b32 v5, v[1:2], off offset:2048                // 00000000F698: DC520800 057C0001
	global_load_b32 v6, v[1:2], off offset:3072                // 00000000F6A0: DC520C00 067C0001
	global_load_b32 v1, v[7:8], off offset:1024                // 00000000F6A8: DC520400 017C0007
	global_load_b32 v2, v[7:8], off offset:2048                // 00000000F6B0: DC520800 027C0007
	global_load_b32 v3, v[7:8], off offset:3072                // 00000000F6B8: DC520C00 037C0007
	global_load_b32 v7, v[9:10], off offset:1024               // 00000000F6C0: DC520400 077C0009
	global_load_b32 v8, v[9:10], off offset:2048               // 00000000F6C8: DC520800 087C0009
	v_add_co_ci_u32_e64 v28, null, 0, v191, vcc_lo             // 00000000F6D0: D5207C1C 01AB7E80
	s_clause 0x7                                               // 00000000F6D8: BF850007
	global_load_b32 v15, v[9:10], off offset:3072              // 00000000F6DC: DC520C00 0F7C0009
	global_load_b32 v12, v[21:22], off offset:1024             // 00000000F6E4: DC520400 0C7C0015
	global_load_b32 v13, v[21:22], off offset:2048             // 00000000F6EC: DC520800 0D7C0015
	global_load_b32 v14, v[21:22], off offset:3072             // 00000000F6F4: DC520C00 0E7C0015
	global_load_b32 v9, v[23:24], off offset:1024              // 00000000F6FC: DC520400 097C0017
	global_load_b32 v10, v[23:24], off offset:2048             // 00000000F704: DC520800 0A7C0017
	global_load_b32 v11, v[23:24], off offset:3072             // 00000000F70C: DC520C00 0B7C0017
	global_load_b32 v16, v[27:28], off offset:1024             // 00000000F714: DC520400 107C001B
	v_or_b32_e32 v21, 0x7c00, v65                              // 00000000F71C: 382A82FF 00007C00
	.long 0xd7006a17                                           // 00000000F724: D7006A17
	v_cndmask_b32_e32 v1, 0x7000, v190, vcc_lo                 // 00000000F728: 02037CFF 00007000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000F730: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v191, vcc_lo             // 00000000F734: D5207C18 01AB7E80
	.long 0xd7006a1e                                           // 00000000F73C: D7006A1E
	v_cndmask_b32_e32 v0, v190, v255, vcc_lo                   // 00000000F740: 0201FFBE
	.long 0x00008000                                           // 00000000F744: 00008000
	v_add_co_ci_u32_e64 v31, null, 0, v191, vcc_lo             // 00000000F748: D5207C1F 01AB7E80
	.long 0xd7006a4e                                           // 00000000F750: D7006A4E
	v_cndmask_b32_e32 v1, v63, v21, vcc_lo                     // 00000000F754: 02022B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000F758: BF8700A1
	v_add_co_ci_u32_e64 v79, null, 0, v64, vcc_lo              // 00000000F75C: D5207C4F 01AA8080
	.long 0xd7006a21                                           // 00000000F764: D7006A21
	v_cndmask_b32_e32 v1, 0x8000, v190, vcc_lo                 // 00000000F768: 02037CFF 00008000
	v_add_co_ci_u32_e64 v34, null, 0, v191, vcc_lo             // 00000000F770: D5207C22 01AB7E80
	.long 0xd7006a25                                           // 00000000F778: D7006A25
	v_cndmask_b32_e32 v1, 0x9000, v190, vcc_lo                 // 00000000F77C: 02037CFF 00009000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000F784: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v191, vcc_lo             // 00000000F788: D5207C26 01AB7E80
	.long 0xd7006a29                                           // 00000000F790: D7006A29
	v_cndmask_b32_e32 v0, v190, v255, vcc_lo                   // 00000000F794: 0201FFBE
	.long 0x0000a000                                           // 00000000F798: 0000A000
	v_add_co_ci_u32_e64 v42, null, 0, v191, vcc_lo             // 00000000F79C: D5207C2A 01AB7E80
	.long 0xd7006a27                                           // 00000000F7A4: D7006A27
	v_cndmask_b32_e32 v1, 0xa000, v190, vcc_lo                 // 00000000F7A8: 02037CFF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000F7B0: BF8700A1
	v_add_co_ci_u32_e64 v40, null, 0, v191, vcc_lo             // 00000000F7B4: D5207C28 01AB7E80
	.long 0xd7006a2b                                           // 00000000F7BC: D7006A2B
	v_cndmask_b32_e32 v1, 0xb000, v190, vcc_lo                 // 00000000F7C0: 02037CFF 0000B000
	v_add_co_ci_u32_e64 v44, null, 0, v191, vcc_lo             // 00000000F7C8: D5207C2C 01AB7E80
	.long 0xd7006a2f                                           // 00000000F7D0: D7006A2F
	v_cndmask_b32_e32 v0, v190, v255, vcc_lo                   // 00000000F7D4: 0201FFBE
	.long 0x0000c000                                           // 00000000F7D8: 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000F7DC: BF8700A1
	v_add_co_ci_u32_e64 v48, null, 0, v191, vcc_lo             // 00000000F7E0: D5207C30 01AB7E80
	.long 0xd7006a31                                           // 00000000F7E8: D7006A31
	v_cndmask_b32_e32 v1, 0xc000, v190, vcc_lo                 // 00000000F7EC: 02037CFF 0000C000
	v_add_co_ci_u32_e64 v50, null, 0, v191, vcc_lo             // 00000000F7F4: D5207C32 01AB7E80
	.long 0xd7006a37                                           // 00000000F7FC: D7006A37
	v_cndmask_b32_e32 v1, 0xd000, v190, vcc_lo                 // 00000000F800: 02037CFF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000F808: BF8700A1
	v_add_co_ci_u32_e64 v56, null, 0, v191, vcc_lo             // 00000000F80C: D5207C38 01AB7E80
	.long 0xd7006a33                                           // 00000000F814: D7006A33
	v_cndmask_b32_e32 v0, v190, v255, vcc_lo                   // 00000000F818: 0201FFBE
	.long 0x0000e000                                           // 00000000F81C: 0000E000
	v_add_co_ci_u32_e64 v52, null, 0, v191, vcc_lo             // 00000000F820: D5207C34 01AB7E80
	.long 0xd7006a39                                           // 00000000F828: D7006A39
	v_cndmask_b32_e32 v1, 0xe000, v190, vcc_lo                 // 00000000F82C: 02037CFF 0000E000
	s_clause 0x17                                              // 00000000F834: BF850017
	global_load_b32 v32, v[17:18], off offset:-4096            // 00000000F838: DC521000 207C0011
	global_load_b32 v29, v[17:18], off                         // 00000000F840: DC520000 1D7C0011
	global_load_b32 v22, v[19:20], off offset:-4096            // 00000000F848: DC521000 167C0013
	global_load_b32 v21, v[19:20], off                         // 00000000F850: DC520000 157C0013
	global_load_b32 v20, v[25:26], off offset:-4096            // 00000000F858: DC521000 147C0019
	global_load_b32 v19, v[25:26], off                         // 00000000F860: DC520000 137C0019
	global_load_b32 v18, v[30:31], off offset:-4096            // 00000000F868: DC521000 127C001E
	global_load_b32 v17, v[30:31], off                         // 00000000F870: DC520000 117C001E
	global_load_b32 v30, v[27:28], off offset:2048             // 00000000F878: DC520800 1E7C001B
	global_load_b32 v31, v[27:28], off offset:3072             // 00000000F880: DC520C00 1F7C001B
	global_load_b32 v26, v[23:24], off offset:1024             // 00000000F888: DC520400 1A7C0017
	global_load_b32 v27, v[23:24], off offset:2048             // 00000000F890: DC520800 1B7C0017
	global_load_b32 v23, v[33:34], off offset:1024             // 00000000F898: DC520400 177C0021
	global_load_b32 v24, v[33:34], off offset:2048             // 00000000F8A0: DC520800 187C0021
	global_load_b32 v25, v[33:34], off offset:3072             // 00000000F8A8: DC520C00 197C0021
	global_load_b32 v28, v[37:38], off offset:1024             // 00000000F8B0: DC520400 1C7C0025
	global_load_b32 v36, v[37:38], off offset:2048             // 00000000F8B8: DC520800 247C0025
	global_load_b32 v37, v[37:38], off offset:3072             // 00000000F8C0: DC520C00 257C0025
	global_load_b32 v33, v[39:40], off offset:1024             // 00000000F8C8: DC520400 217C0027
	global_load_b32 v34, v[39:40], off offset:2048             // 00000000F8D0: DC520800 227C0027
	global_load_b32 v35, v[39:40], off offset:3072             // 00000000F8D8: DC520C00 237C0027
	global_load_b32 v38, v[43:44], off offset:1024             // 00000000F8E0: DC520400 267C002B
	global_load_b32 v39, v[43:44], off offset:2048             // 00000000F8E8: DC520800 277C002B
	global_load_b32 v40, v[43:44], off offset:3072             // 00000000F8F0: DC520C00 287C002B
	v_add_co_ci_u32_e64 v58, null, 0, v191, vcc_lo             // 00000000F8F8: D5207C3A 01AB7E80
	s_clause 0xd                                               // 00000000F900: BF85000D
	global_load_b32 v46, v[41:42], off offset:-4096            // 00000000F904: DC521000 2E7C0029
	global_load_b32 v45, v[41:42], off                         // 00000000F90C: DC520000 2D7C0029
	global_load_b32 v44, v[47:48], off offset:-4096            // 00000000F914: DC521000 2C7C002F
	global_load_b32 v43, v[47:48], off                         // 00000000F91C: DC520000 2B7C002F
	global_load_b32 v42, v[51:52], off offset:-4096            // 00000000F924: DC521000 2A7C0033
	global_load_b32 v41, v[51:52], off                         // 00000000F92C: DC520000 297C0033
	global_load_b32 v52, v[49:50], off offset:1024             // 00000000F934: DC520400 347C0031
	global_load_b32 v53, v[49:50], off offset:2048             // 00000000F93C: DC520800 357C0031
	global_load_b32 v54, v[49:50], off offset:3072             // 00000000F944: DC520C00 367C0031
	global_load_b32 v49, v[55:56], off offset:1024             // 00000000F94C: DC520400 317C0037
	global_load_b32 v50, v[55:56], off offset:2048             // 00000000F954: DC520800 327C0037
	global_load_b32 v51, v[55:56], off offset:3072             // 00000000F95C: DC520C00 337C0037
	global_load_b32 v47, v[57:58], off offset:1024             // 00000000F964: DC520400 2F7C0039
	global_load_b32 v48, v[57:58], off offset:2048             // 00000000F96C: DC520800 307C0039
	v_min_i32_e32 v55, s30, v73                                // 00000000F974: 226E921E
	s_lshr_b32 s5, s4, 31                                      // 00000000F978: 85059F04
	.long 0xd7006a3b                                           // 00000000F97C: D7006A3B
	v_cndmask_b32_e32 v1, 0xf000, v190, vcc_lo                 // 00000000F980: 02037CFF 0000F000
	s_add_i32 s4, s4, s5                                       // 00000000F988: 81040504
	v_mad_i64_i32 v[61:62], null, 0x5000, v55, s[8:9]          // 00000000F98C: D6FF7C3D 00226EFF 00005000
	s_lshl_b32 s4, s4, 7                                       // 00000000F998: 84048704
	v_add_co_ci_u32_e64 v60, null, 0, v191, vcc_lo             // 00000000F99C: D5207C3C 01AB7E80
	s_ashr_i32 s5, s4, 31                                      // 00000000F9A4: 86059F04
	s_clause 0x3                                               // 00000000F9A8: BF850003
	global_load_b32 v55, v[57:58], off offset:3072             // 00000000F9AC: DC520C00 377C0039
	global_load_b32 v56, v[59:60], off                         // 00000000F9B4: DC520000 387C003B
	global_load_b32 v57, v[59:60], off offset:1024             // 00000000F9BC: DC520400 397C003B
	global_load_b32 v58, v[59:60], off offset:2048             // 00000000F9C4: DC520800 3A7C003B
	s_lshl_b64 s[6:7], s[4:5], 1                               // 00000000F9CC: 84868104
	v_and_b32_e32 v59, 0xf0, v66                               // 00000000F9D0: 367684FF 000000F0
	.long 0xd7006a3c                                           // 00000000F9D8: D7006A3C
	v_cndmask_b32_e32 v0, v61, v6, vcc_lo                      // 00000000F9DC: 02000D3D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000000F9E0: BF8701A1
	v_add_co_ci_u32_e64 v61, null, s7, v62, vcc_lo             // 00000000F9E4: D5207C3D 01AA7C07
	v_or_b32_e32 v62, 0xfc00, v65                              // 00000000F9EC: 387C82FF 0000FC00
	.long 0xd7006a41                                           // 00000000F9F4: D7006A41
	v_cndmask_b32_e32 v1, v60, v59, vcc_lo                     // 00000000F9F8: 0202773C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000F9FC: BF870191
	v_add_co_ci_u32_e64 v66, null, 0, v61, vcc_lo              // 00000000FA00: D5207C42 01AA7A80
	.long 0xd7006a89                                           // 00000000FA08: D7006A89
	v_cndmask_b32_e32 v1, v63, v62, vcc_lo                     // 00000000FA0C: 02027D3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000FA10: BF870211
	v_add_co_ci_u32_e64 v138, null, 0, v64, vcc_lo             // 00000000FA14: D5207C8A 01AA8080
	.long 0xd7006a45                                           // 00000000FA1C: D7006A45
	v_cndmask_b32_e32 v1, 0x1000, v65, vcc_lo                  // 00000000FA20: 020282FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000FA28: BF870001
	v_add_co_ci_u32_e64 v70, null, 0, v66, vcc_lo              // 00000000FA2C: D5207C46 01AA8480
	s_clause 0x5                                               // 00000000FA34: BF850005
	global_load_b32 v61, v[190:191], off                       // 00000000FA38: DC520000 3D7C00BE
	global_load_b32 v62, v[190:191], off offset:1024           // 00000000FA40: DC520400 3E7C00BE
	global_load_b32 v63, v[190:191], off offset:2048           // 00000000FA48: DC520800 3F7C00BE
	global_load_b32 v64, v[190:191], off offset:3072           // 00000000FA50: DC520C00 407C00BE
	global_load_b32 v60, v[78:79], off                         // 00000000FA58: DC520000 3C7C004E
	global_load_b32 v59, v[137:138], off                       // 00000000FA60: DC520000 3B7C0089
	s_clause 0x1                                               // 00000000FA68: BF850001
	global_load_b128 v[65:68], v[65:66], off                   // 00000000FA6C: DC5E0000 417C0041
	global_load_b128 v[69:72], v[69:70], off                   // 00000000FA74: DC5E0000 457C0045
	s_mov_b32 s4, exec_lo                                      // 00000000FA7C: BE84007E
	.long 0xd4c3007e                                           // 00000000FA80: D4C3007E
	v_cndmask_b32_e32 v1, s29, v73, vcc_lo                     // 00000000FA84: 0202921D
	s_cbranch_execz 11                                         // 00000000FA88: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5b8>
	s_waitcnt vmcnt(1)                                         // 00000000FA8C: BF8907F7
	v_mov_b32_e32 v65, 0                                       // 00000000FA90: 7E820280
	s_waitcnt vmcnt(0)                                         // 00000000FA94: BF8903F7
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000FA98: BF870001
	v_mov_b32_e32 v72, v65                                     // 00000000FA9C: 7E900341
	v_mov_b32_e32 v71, v65                                     // 00000000FAA0: 7E8E0341
	v_mov_b32_e32 v70, v65                                     // 00000000FAA4: 7E8C0341
	v_mov_b32_e32 v69, v65                                     // 00000000FAA8: 7E8A0341
	v_mov_b32_e32 v66, v65                                     // 00000000FAAC: 7E840341
	v_mov_b32_e32 v67, v65                                     // 00000000FAB0: 7E860341
	v_mov_b32_e32 v68, v65                                     // 00000000FAB4: 7E880341
	s_or_b32 exec_lo, exec_lo, s4                              // 00000000FAB8: 8C7E047E
	v_cmp_gt_u32_e32 vcc_lo, 16, v0                            // 00000000FABC: 7C980090
	.long 0xd4440004                                           // 00000000FAC0: D4440004
	v_cndmask_b32_e32 v1, s29, v0, vcc_lo                      // 00000000FAC4: 0202001D
	v_mov_b32_e32 v136, 0                                      // 00000000FAC8: 7F100280
	s_and_b32 s5, vcc_lo, s4                                   // 00000000FACC: 8B05046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000000FAD0: BF870009
	s_and_saveexec_b32 s4, s5                                  // 00000000FAD4: BE842005
	s_cbranch_execz 27                                         // 00000000FAD8: BFA5001B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x648>
	v_mul_u32_u24_e32 v73, 0xc0, v0                            // 00000000FADC: 169200FF 000000C0
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000000FAE4: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000FAE8: BF870091
	.long 0xd700054a                                           // 00000000FAEC: D700054A
	v_cndmask_b32_e32 v1, s10, v73, vcc_lo                     // 00000000FAF0: 0202920A
	v_add_co_ci_u32_e64 v75, null, s11, 0, s5                  // 00000000FAF4: D5207C4B 0015000B
	.long 0xd700054c                                           // 00000000FAFC: D700054C
	v_cndmask_b32_e32 v1, s12, v73, vcc_lo                     // 00000000FB00: 0202920C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000FB04: BF870211
	v_add_co_ci_u32_e64 v77, null, s13, 0, s5                  // 00000000FB08: D5207C4D 0015000D
	.long 0xd7006a49                                           // 00000000FB10: D7006A49
	v_cndmask_b32_e32 v0, v74, v14, vcc_lo                     // 00000000FB14: 02001D4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000FB18: BF870211
	v_add_co_ci_u32_e64 v74, null, s15, v75, vcc_lo            // 00000000FB1C: D5207C4A 01AA960F
	.long 0xd7006a4b                                           // 00000000FB24: D7006A4B
	v_cndmask_b32_e32 v0, v76, v14, vcc_lo                     // 00000000FB28: 02001D4C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000000FB2C: BF870001
	v_add_co_ci_u32_e64 v76, null, s15, v77, vcc_lo            // 00000000FB30: D5207C4C 01AA9A0F
	global_load_b32 v136, v[73:74], off                        // 00000000FB38: DC520000 887C0049
	global_load_b32 v142, v[75:76], off                        // 00000000FB40: DC520000 8E7C004B
	s_or_b32 exec_lo, exec_lo, s4                              // 00000000FB48: 8C7E047E
	s_waitcnt vmcnt(6)                                         // 00000000FB4C: BF891BF7
	v_dual_mul_f32 v135, 0x43800000, v61 :: v_dual_mul_f32 v134, 0x43800000, v62// 00000000FB50: C8C67AFF 87867CFF 43800000
	s_waitcnt vmcnt(4)                                         // 00000000FB5C: BF8913F7
	v_dual_mul_f32 v133, 0x43800000, v63 :: v_dual_mul_f32 v132, 0x43800000, v64// 00000000FB60: C8C67EFF 858480FF 43800000
	v_dual_mul_f32 v131, 0x43800000, v32 :: v_dual_mul_f32 v154, 0x43800000, v6// 00000000FB6C: C8C640FF 839A0CFF 43800000
	v_dual_mul_f32 v130, 0x43800000, v4 :: v_dual_mul_f32 v129, 0x43800000, v5// 00000000FB78: C8C608FF 82800AFF 43800000
	v_dual_mul_f32 v128, 0x43800000, v29 :: v_dual_mul_f32 v125, 0x43800000, v3// 00000000FB84: C8C63AFF 807C06FF 43800000
	v_dual_mul_f32 v127, 0x43800000, v1 :: v_dual_mul_f32 v126, 0x43800000, v2// 00000000FB90: C8C602FF 7F7E04FF 43800000
	v_dual_mul_f32 v124, 0x43800000, v22 :: v_dual_mul_f32 v123, 0x43800000, v7// 00000000FB9C: C8C62CFF 7C7A0EFF 43800000
	v_dual_mul_f32 v122, 0x43800000, v8 :: v_dual_mul_f32 v153, 0x43800000, v15// 00000000FBA8: C8C610FF 7A981EFF 43800000
	v_dual_mul_f32 v121, 0x43800000, v21 :: v_dual_mul_f32 v120, 0x43800000, v12// 00000000FBB4: C8C62AFF 797818FF 43800000
	v_dual_mul_f32 v119, 0x43800000, v13 :: v_dual_mul_f32 v118, 0x43800000, v14// 00000000FBC0: C8C61AFF 77761CFF 43800000
	v_dual_mul_f32 v117, 0x43800000, v20 :: v_dual_mul_f32 v116, 0x43800000, v9// 00000000FBCC: C8C628FF 757412FF 43800000
	v_dual_mul_f32 v115, 0x43800000, v10 :: v_dual_mul_f32 v152, 0x43800000, v11// 00000000FBD8: C8C614FF 739816FF 43800000
	v_dual_mul_f32 v114, 0x43800000, v19 :: v_dual_mul_f32 v113, 0x43800000, v16// 00000000FBE4: C8C626FF 727020FF 43800000
	v_dual_mul_f32 v112, 0x43800000, v30 :: v_dual_mul_f32 v111, 0x43800000, v31// 00000000FBF0: C8C63CFF 706E3EFF 43800000
	s_waitcnt vmcnt(3)                                         // 00000000FBFC: BF890FF7
	v_dual_mul_f32 v110, 0x43800000, v18 :: v_dual_mul_f32 v151, 0x43800000, v60// 00000000FC00: C8C624FF 6E9678FF 43800000
	v_dual_mul_f32 v109, 0x43800000, v26 :: v_dual_mul_f32 v108, 0x43800000, v27// 00000000FC0C: C8C634FF 6D6C36FF 43800000
	v_dual_mul_f32 v107, 0x43800000, v17 :: v_dual_mul_f32 v106, 0x43800000, v23// 00000000FC18: C8C622FF 6B6A2EFF 43800000
	v_dual_mul_f32 v105, 0x43800000, v24 :: v_dual_mul_f32 v104, 0x43800000, v25// 00000000FC24: C8C630FF 696832FF 43800000
	v_dual_mul_f32 v103, 0x43800000, v46 :: v_dual_mul_f32 v102, 0x43800000, v28// 00000000FC30: C8C65CFF 676638FF 43800000
	v_dual_mul_f32 v101, 0x43800000, v36 :: v_dual_mul_f32 v150, 0x43800000, v37// 00000000FC3C: C8C648FF 65964AFF 43800000
	v_dual_mul_f32 v100, 0x43800000, v45 :: v_dual_mul_f32 v97, 0x43800000, v35// 00000000FC48: C8C65AFF 646046FF 43800000
	v_dual_mul_f32 v99, 0x43800000, v33 :: v_dual_mul_f32 v98, 0x43800000, v34// 00000000FC54: C8C642FF 636244FF 43800000
	v_dual_mul_f32 v96, 0x43800000, v44 :: v_dual_mul_f32 v95, 0x43800000, v38// 00000000FC60: C8C658FF 605E4CFF 43800000
	v_dual_mul_f32 v94, 0x43800000, v39 :: v_dual_mul_f32 v149, 0x43800000, v40// 00000000FC6C: C8C64EFF 5E9450FF 43800000
	v_dual_mul_f32 v93, 0x43800000, v43 :: v_dual_mul_f32 v92, 0x43800000, v52// 00000000FC78: C8C656FF 5D5C68FF 43800000
	v_dual_mul_f32 v91, 0x43800000, v53 :: v_dual_mul_f32 v90, 0x43800000, v54// 00000000FC84: C8C66AFF 5B5A6CFF 43800000
	v_dual_mul_f32 v89, 0x43800000, v42 :: v_dual_mul_f32 v88, 0x43800000, v49// 00000000FC90: C8C654FF 595862FF 43800000
	v_dual_mul_f32 v87, 0x43800000, v50 :: v_dual_mul_f32 v148, 0x43800000, v51// 00000000FC9C: C8C664FF 579466FF 43800000
	v_dual_mul_f32 v86, 0x43800000, v41 :: v_dual_mul_f32 v85, 0x43800000, v47// 00000000FCA8: C8C652FF 56545EFF 43800000
	v_dual_mul_f32 v84, 0x43800000, v48 :: v_dual_mul_f32 v83, 0x43800000, v55// 00000000FCB4: C8C660FF 54526EFF 43800000
	v_dual_mul_f32 v82, 0x43800000, v56 :: v_dual_mul_f32 v81, 0x43800000, v57// 00000000FCC0: C8C670FF 525072FF 43800000
	v_mul_f32_e32 v141, 0x43800000, v58                        // 00000000FCCC: 111A74FF 43800000
	s_waitcnt vmcnt(2)                                         // 00000000FCD4: BF890BF7
	v_mul_f32_e32 v147, 0x43800000, v59                        // 00000000FCD8: 112676FF 43800000
	s_cmp_lt_i32 s29, 1                                        // 00000000FCE0: BF04811D
	s_cbranch_scc1 5076                                        // 00000000FCE4: BFA213D4 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5738>
	s_add_u32 s4, s8, s6                                       // 00000000FCE8: 80040608
	s_addc_u32 s5, s9, s7                                      // 00000000FCEC: 82050709
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000000FCF0: 848E8202
	s_clause 0x1                                               // 00000000FCF4: BF850001
	scratch_store_b64 off, v[137:138], off offset:8            // 00000000FCF8: DC6D0008 007C8900
	scratch_store_b64 off, v[78:79], off                       // 00000000FD00: DC6D0000 007C4E00
	s_add_u32 s6, s10, s14                                     // 00000000FD08: 80060E0A
	s_addc_u32 s7, s11, s15                                    // 00000000FD0C: 82070F0B
	s_add_u32 s10, s12, s14                                    // 00000000FD10: 800A0E0C
	s_addc_u32 s11, s13, s15                                   // 00000000FD14: 820B0F0D
	s_load_b256 s[12:19], s[0:1], 0x48                         // 00000000FD18: F40C0300 F8000048
	s_add_i32 s3, s29, 15                                      // 00000000FD20: 81038F1D
	s_load_b64 s[0:1], s[0:1], 0x68                            // 00000000FD24: F4040000 F8000068
	s_waitcnt lgkmcnt(0)                                       // 00000000FD2C: BF89FC07
	s_ashr_i32 s15, s3, 31                                     // 00000000FD30: 860F9F03
	s_lshl_b32 s2, s2, 7                                       // 00000000FD34: 84028702
	s_lshr_b32 s15, s15, 28                                    // 00000000FD38: 850F9C0F
	.long 0xd71f008a                                           // 00000000FD3C: D71F008A
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000000FD40: 020100C1
	s_add_i32 s3, s3, s15                                      // 00000000FD44: 81030F03
	v_mov_b32_e32 v145, 0x1000504                              // 00000000FD48: 7F2202FF 01000504
	s_ashr_i32 s15, s3, 4                                      // 00000000FD50: 860F8403
	s_ashr_i32 s3, s2, 31                                      // 00000000FD54: 86039F02
	s_cmp_eq_u32 s20, 0                                        // 00000000FD58: BF068014
	v_and_b32_e32 v1, 16, v138                                 // 00000000FD5C: 36031490
	s_cselect_b32 s31, -1, 0                                   // 00000000FD60: 981F80C1
	s_cmp_lg_u32 s20, 0                                        // 00000000FD64: BF078014
	v_mov_b32_e32 v139, 0                                      // 00000000FD68: 7F160280
	s_cselect_b32 s33, -1, 0                                   // 00000000FD6C: 982180C1
	s_lshl_b64 s[2:3], s[2:3], 1                               // 00000000FD70: 84828102
	v_add_nc_u32_e32 v140, 16, v1                              // 00000000FD74: 4B180290
	s_add_u32 s34, s24, s2                                     // 00000000FD78: 80220218
	s_addc_u32 s35, s25, s3                                    // 00000000FD7C: 82230319
	s_max_i32 s36, s15, 1                                      // 00000000FD80: 8A24810F
	s_add_u32 s16, s16, s22                                    // 00000000FD84: 80101610
	s_addc_u32 s17, s17, s23                                   // 00000000FD88: 82111711
	s_add_u32 s18, s18, s22                                    // 00000000FD8C: 80121612
	v_xor_b32_e32 v137, 1, v138                                // 00000000FD90: 3B131481
	v_xor_b32_e32 v146, 2, v138                                // 00000000FD94: 3B251482
	v_xor_b32_e32 v143, 4, v138                                // 00000000FD98: 3B1F1484
	v_xor_b32_e32 v144, 8, v138                                // 00000000FD9C: 3B211488
	s_mov_b32 s20, 0                                           // 00000000FDA0: BE940080
	s_addc_u32 s19, s19, s23                                   // 00000000FDA4: 82131713
	s_add_u32 s37, s0, s22                                     // 00000000FDA8: 80251600
	s_addc_u32 s38, s1, s23                                    // 00000000FDAC: 82261701
	s_movk_i32 s39, 0x110                                      // 00000000FDB0: B0270110
	s_movk_i32 s40, 0x1800                                     // 00000000FDB4: B0281800
	s_mov_b32 s41, 0x41800000                                  // 00000000FDB8: BEA900FF 41800000
	s_mov_b32 s21, s20                                         // 00000000FDC0: BE950014
	s_mov_b32 s22, s20                                         // 00000000FDC4: BE960014
	s_mov_b32 s23, s20                                         // 00000000FDC8: BE970014
	s_mov_b32 s24, s20                                         // 00000000FDCC: BE980014
	s_mov_b32 s25, s20                                         // 00000000FDD0: BE990014
	s_mov_b32 s26, s20                                         // 00000000FDD4: BE9A0014
	s_mov_b32 s27, s20                                         // 00000000FDD8: BE9B0014
	s_mov_b32 s42, 0x76543210                                  // 00000000FDDC: BEAA00FF 76543210
	s_mov_b32 s43, s20                                         // 00000000FDE4: BEAB0014
	s_branch 10                                                // 00000000FDE8: BFA0000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x914>
	v_dual_mov_b32 v147, v32 :: v_dual_mov_b32 v152, v37       // 00000000FDEC: CA100120 93980125
	v_dual_mov_b32 v148, v36 :: v_dual_mov_b32 v153, v45       // 00000000FDF4: CA100124 9498012D
	v_dual_mov_b32 v149, v24 :: v_dual_mov_b32 v154, v53       // 00000000FDFC: CA100118 959A0135
	v_mov_b32_e32 v150, v8                                     // 00000000FE04: 7F2C0308
	v_mov_b32_e32 v151, v16                                    // 00000000FE08: 7F2E0310
	s_cmp_eq_u32 s43, s36                                      // 00000000FE0C: BF06242B
	s_cbranch_scc1 4995                                        // 00000000FE10: BFA21383 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5720>
	v_mov_b32_e32 v5, v0                                       // 00000000FE14: 7E0A0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000000FE18: BF8701B1
	v_ashrrev_i32_e32 v6, 4, v5                                // 00000000FE1C: 340C0A84
	v_and_b32_e32 v156, 15, v5                                 // 00000000FE20: 37380A8F
	.long 0xd4440000                                           // 00000000FE24: D4440000
	v_cndmask_b32_e32 v1, 16, v5, vcc_lo                       // 00000000FE28: 02020A90
	v_mad_u64_u32 v[3:4], null, v6, s39, 0x2900                // 00000000FE2C: D6FE7C03 03FC4F06 00002900
	v_lshlrev_b32_e32 v4, 2, v5                                // 00000000FE38: 30080A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000FE3C: BF870092
	v_lshl_add_u32 v1, v156, 4, v3                             // 00000000FE40: D6460001 040D099C
	v_add_nc_u32_e32 v2, 0xffffef00, v1                        // 00000000FE48: 4A0402FF FFFFEF00
	s_waitcnt vmcnt(1)                                         // 00000000FE50: BF8907F7
	ds_store_b128 v1, v[65:68]                                 // 00000000FE54: DB7C0000 00004101
	s_waitcnt vmcnt(0)                                         // 00000000FE5C: BF8903F7
	ds_store_b128 v2, v[69:72]                                 // 00000000FE60: DB7C0000 00004502
	s_and_saveexec_b32 s1, s0                                  // 00000000FE68: BE812000
	ds_store_b32 v4, v142 offset:24064                         // 00000000FE6C: D8345E00 00008E04
	s_or_b32 exec_lo, exec_lo, s1                              // 00000000FE74: 8C7E017E
	v_and_b32_e32 v18, 1, v5                                   // 00000000FE78: 36240A81
	s_lshl_b32 s44, s43, 4                                     // 00000000FE7C: 842C842B
	v_or_b32_e32 v155, s28, v156                               // 00000000FE80: 3937381C
	s_mov_b32 s45, exec_lo                                     // 00000000FE84: BEAD007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000000FE88: BF870112
	v_or_b32_e32 v17, s44, v18                                 // 00000000FE8C: 3822242C
	v_and_b32_e32 v8, 0x7ffffffe, v155                         // 00000000FE90: 361136FF 7FFFFFFE
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000000FE98: BF870232
	v_min_i32_e32 v1, s30, v17                                 // 00000000FE9C: 2202221E
	v_or_b32_e32 v7, 2, v17                                    // 00000000FEA0: 380E2282
	v_or_b32_e32 v9, 4, v17                                    // 00000000FEA4: 38122284
	v_lshlrev_b32_e32 v21, 1, v8                               // 00000000FEA8: 302A1081
	v_or_b32_e32 v10, 6, v17                                   // 00000000FEAC: 38142286
	v_mad_i64_i32 v[1:2], null, 0x5000, v1, s[8:9]             // 00000000FEB0: D6FF7C01 002202FF 00005000
	v_min_i32_e32 v7, s30, v7                                  // 00000000FEBC: 220E0E1E
	v_min_i32_e32 v9, s30, v9                                  // 00000000FEC0: 2212121E
	v_or_b32_e32 v20, 12, v17                                  // 00000000FEC4: 3828228C
	v_min_i32_e32 v10, s30, v10                                // 00000000FEC8: 2214141E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000FECC: BF8700A4
	v_mad_i64_i32 v[7:8], null, 0x5000, v7, s[8:9]             // 00000000FED0: D6FF7C07 00220EFF 00005000
	.long 0xd7006a0b                                           // 00000000FEDC: D7006A0B
	v_cndmask_b32_e32 v0, v1, v2, vcc_lo                       // 00000000FEE0: 02000501
	v_add_co_ci_u32_e64 v12, null, s3, v2, vcc_lo              // 00000000FEE4: D5207C0C 01AA0403
	v_mad_i64_i32 v[1:2], null, 0x5000, v9, s[8:9]             // 00000000FEEC: D6FF7C01 002212FF 00005000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000FEF8: BF870093
	.long 0xd7006a09                                           // 00000000FEFC: D7006A09
	v_cndmask_b32_e32 v1, v11, v21, vcc_lo                     // 00000000FF00: 02022B0B
	v_add_co_ci_u32_e64 v11, null, 0, v12, vcc_lo              // 00000000FF04: D5207C0B 01AA1880
	.long 0xd7006a0c                                           // 00000000FF0C: D7006A0C
	v_cndmask_b32_e32 v0, v7, v2, vcc_lo                       // 00000000FF10: 02000507
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000FF14: BF870211
	v_add_co_ci_u32_e64 v13, null, s3, v8, vcc_lo              // 00000000FF18: D5207C0D 01AA1003
	.long 0xd7006a07                                           // 00000000FF20: D7006A07
	v_cndmask_b32_e32 v1, 0x2000, v9, vcc_lo                   // 00000000FF24: 020212FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000000FF2C: BF870211
	v_add_co_ci_u32_e64 v8, null, 0, v11, vcc_lo               // 00000000FF30: D5207C08 01AA1680
	.long 0xd7006a09                                           // 00000000FF38: D7006A09
	v_cndmask_b32_e32 v1, v12, v21, vcc_lo                     // 00000000FF3C: 02022B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000FF40: BF8700A1
	v_add_co_ci_u32_e64 v11, null, 0, v13, vcc_lo              // 00000000FF44: D5207C0B 01AA1A80
	.long 0xd7006a0c                                           // 00000000FF4C: D7006A0C
	v_cndmask_b32_e32 v0, v1, v2, vcc_lo                       // 00000000FF50: 02000501
	v_add_co_ci_u32_e64 v13, null, s3, v2, vcc_lo              // 00000000FF54: D5207C0D 01AA0403
	v_mad_i64_i32 v[1:2], null, 0x5000, v10, s[8:9]            // 00000000FF5C: D6FF7C01 002214FF 00005000
	.long 0xd7006a09                                           // 00000000FF68: D7006A09
	v_cndmask_b32_e32 v1, 0x2000, v9, vcc_lo                   // 00000000FF6C: 020212FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000FF74: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v11, vcc_lo              // 00000000FF78: D5207C0A 01AA1680
	.long 0xd7006a0b                                           // 00000000FF80: D7006A0B
	v_cndmask_b32_e32 v1, v12, v21, vcc_lo                     // 00000000FF84: 02022B0C
	v_add_co_ci_u32_e64 v12, null, 0, v13, vcc_lo              // 00000000FF88: D5207C0C 01AA1A80
	v_or_b32_e32 v13, 8, v17                                   // 00000000FF90: 381A2288
	.long 0xd7006a01                                           // 00000000FF94: D7006A01
	v_cndmask_b32_e32 v0, v1, v2, vcc_lo                       // 00000000FF98: 02000501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000000FF9C: BF870191
	v_add_co_ci_u32_e64 v2, null, s3, v2, vcc_lo               // 00000000FFA0: D5207C02 01AA0403
	v_min_i32_e32 v13, s30, v13                                // 00000000FFA8: 221A1A1E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000000FFAC: BF870093
	.long 0xd7006a0e                                           // 00000000FFB0: D7006A0E
	v_cndmask_b32_e32 v1, v1, v21, vcc_lo                      // 00000000FFB4: 02022B01
	v_add_co_ci_u32_e64 v15, null, 0, v2, vcc_lo               // 00000000FFB8: D5207C0F 01AA0480
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000000FFC0: BF8700A3
	v_mad_i64_i32 v[1:2], null, 0x5000, v13, s[8:9]            // 00000000FFC4: D6FF7C01 00221AFF 00005000
	.long 0xd7006a0b                                           // 00000000FFD0: D7006A0B
	v_cndmask_b32_e32 v1, 0x2000, v11, vcc_lo                  // 00000000FFD4: 020216FF 00002000
	v_add_co_ci_u32_e64 v12, null, 0, v12, vcc_lo              // 00000000FFDC: D5207C0C 01AA1880
	.long 0xd7006a0d                                           // 00000000FFE4: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v14, vcc_lo                  // 00000000FFE8: 02021CFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000000FFF0: BF8700B1
	v_add_co_ci_u32_e64 v14, null, 0, v15, vcc_lo              // 00000000FFF4: D5207C0E 01AA1E80
	v_or_b32_e32 v15, 10, v17                                  // 00000000FFFC: 381E228A
	.long 0xd7006a01                                           // 000000010000: D7006A01
	v_cndmask_b32_e32 v0, v1, v2, vcc_lo                       // 000000010004: 02000501
	v_add_co_ci_u32_e64 v2, null, s3, v2, vcc_lo               // 000000010008: D5207C02 01AA0403
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010010: BF870193
	v_min_i32_e32 v15, s30, v15                                // 000000010014: 221E1E1E
	.long 0xd7006a10                                           // 000000010018: D7006A10
	v_cndmask_b32_e32 v1, v1, v21, vcc_lo                      // 00000001001C: 02022B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010020: BF870191
	v_add_co_ci_u32_e64 v19, null, 0, v2, vcc_lo               // 000000010024: D5207C13 01AA0480
	v_mad_i64_i32 v[1:2], null, 0x5000, v15, s[8:9]            // 00000001002C: D6FF7C01 00221EFF 00005000
	v_or_b32_e32 v17, 14, v17                                  // 000000010038: 3822228E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001003C: BF870094
	.long 0xd7006a0f                                           // 000000010040: D7006A0F
	v_cndmask_b32_e32 v1, 0x2000, v16, vcc_lo                  // 000000010044: 020220FF 00002000
	v_add_co_ci_u32_e64 v16, null, 0, v19, vcc_lo              // 00000001004C: D5207C10 01AA2680
	v_min_i32_e32 v19, s30, v20                                // 000000010054: 2226281E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000010058: BF8700A4
	v_min_i32_e32 v17, s30, v17                                // 00000001005C: 2222221E
	.long 0xd7006a14                                           // 000000010060: D7006A14
	v_cndmask_b32_e32 v0, v1, v2, vcc_lo                       // 000000010064: 02000501
	v_add_co_ci_u32_e64 v22, null, s3, v2, vcc_lo              // 000000010068: D5207C16 01AA0403
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010070: BF870194
	v_mad_i64_i32 v[1:2], null, 0x5000, v19, s[8:9]            // 000000010074: D6FF7C01 002226FF 00005000
	.long 0xd7006a17                                           // 000000010080: D7006A17
	v_cndmask_b32_e32 v1, v20, v21, vcc_lo                     // 000000010084: 02022B14
	v_mad_i64_i32 v[19:20], null, 0x5000, v17, s[8:9]          // 000000010088: D6FF7C13 002222FF 00005000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010094: BF870194
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 000000010098: D5207C16 01AA2C80
	.long 0xd7006a1b                                           // 0000000100A0: D7006A1B
	v_cndmask_b32_e32 v1, 0x2000, v23, vcc_lo                  // 0000000100A4: 02022EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000100AC: BF8700A1
	v_add_co_ci_u32_e64 v28, null, 0, v22, vcc_lo              // 0000000100B0: D5207C1C 01AA2C80
	.long 0xd7006a01                                           // 0000000100B8: D7006A01
	v_cndmask_b32_e32 v0, v1, v2, vcc_lo                       // 0000000100BC: 02000501
	v_add_co_ci_u32_e64 v2, null, s3, v2, vcc_lo               // 0000000100C0: D5207C02 01AA0403
	.long 0xd7006a11                                           // 0000000100C8: D7006A11
	v_cndmask_b32_e32 v0, v19, v2, vcc_lo                      // 0000000100CC: 02000513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000100D0: BF870211
	v_add_co_ci_u32_e64 v19, null, s3, v20, vcc_lo             // 0000000100D4: D5207C13 01AA2803
	.long 0xd7006a01                                           // 0000000100DC: D7006A01
	v_cndmask_b32_e32 v1, v1, v21, vcc_lo                      // 0000000100E0: 02022B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000100E4: BF870211
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000000100E8: D5207C02 01AA0480
	.long 0xd7006a11                                           // 0000000100F0: D7006A11
	v_cndmask_b32_e32 v1, v17, v21, vcc_lo                     // 0000000100F4: 02022B11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000100F8: BF870211
	v_add_co_ci_u32_e64 v19, null, 0, v19, vcc_lo              // 0000000100FC: D5207C13 01AA2680
	.long 0xd7006a01                                           // 000000010104: D7006A01
	v_cndmask_b32_e32 v1, 0x2000, v1, vcc_lo                   // 000000010108: 020202FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000010110: BF870211
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000010114: D5207C02 01AA0480
	.long 0xd7006a1d                                           // 00000001011C: D7006A1D
	v_cndmask_b32_e32 v1, 0x2000, v17, vcc_lo                  // 000000010120: 020222FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000010128: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v19, vcc_lo              // 00000001012C: D5207C1E 01AA2680
	s_clause 0x7                                               // 000000010134: BF850007
	global_load_b32 v26, v[7:8], off                           // 000000010138: DC520000 1A7C0007
	global_load_b32 v25, v[9:10], off                          // 000000010140: DC520000 197C0009
	global_load_b32 v24, v[11:12], off                         // 000000010148: DC520000 187C000B
	global_load_b32 v23, v[13:14], off                         // 000000010150: DC520000 177C000D
	global_load_b32 v22, v[15:16], off                         // 000000010158: DC520000 167C000F
	global_load_b32 v21, v[27:28], off                         // 000000010160: DC520000 157C001B
	global_load_b32 v20, v[1:2], off                           // 000000010168: DC520000 147C0001
	global_load_b32 v19, v[29:30], off                         // 000000010170: DC520000 137C001D
	v_and_b32_e32 v2, 0xffff0000, v65                          // 000000010178: 360482FF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v66                         // 000000010180: 361484FF FFFF0000
	v_lshlrev_b32_e32 v7, 16, v69                              // 000000010188: 300E8A90
	v_lshlrev_b32_e32 v11, 16, v67                             // 00000001018C: 30168690
	v_and_b32_e32 v12, 0xffff0000, v67                         // 000000010190: 361886FF FFFF0000
	v_mul_f32_e32 v2, v2, v2                                   // 000000010198: 10040502
	v_and_b32_e32 v8, 0xffff0000, v69                          // 00000001019C: 36108AFF FFFF0000
	v_lshlrev_b32_e32 v1, 16, v65                              // 0000000101A4: 30028290
	v_mul_f32_e32 v7, v7, v7                                   // 0000000101A8: 100E0F07
	v_cmp_lt_u32_e32 vcc_lo, v137, v140                        // 0000000101AC: 7C931989
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000101B0: BF870123
	v_dual_mul_f32 v8, v8, v8 :: v_dual_mul_f32 v1, v1, v1     // 0000000101B4: C8C61108 08000301
	v_lshlrev_b32_e32 v9, 16, v66                              // 0000000101BC: 30128490
	v_dual_add_f32 v1, v1, v2 :: v_dual_add_f32 v2, v7, v8     // 0000000101C0: C9080501 01021107
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000101C8: BF870122
	v_dual_mul_f32 v7, v9, v9 :: v_dual_mul_f32 v8, v10, v10   // 0000000101CC: C8C61309 0708150A
	v_lshlrev_b32_e32 v9, 16, v70                              // 0000000101D4: 30128C90
	v_dual_add_f32 v7, v7, v8 :: v_dual_and_b32 v10, 0xffff0000, v70// 0000000101D8: C9241107 070A8CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000101E4: BF8701B1
	v_dual_mul_f32 v8, v9, v9 :: v_dual_mul_f32 v9, v10, v10   // 0000000101E8: C8C61309 0808150A
	v_dual_mul_f32 v10, v11, v11 :: v_dual_mul_f32 v11, v12, v12// 0000000101F0: C8C6170B 0A0A190C
	v_and_b32_e32 v13, 0xffff0000, v68                         // 0000000101F8: 361A88FF FFFF0000
	v_dual_add_f32 v1, v1, v7 :: v_dual_add_f32 v8, v8, v9     // 000000010200: C9080F01 01081308
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000010208: BF8700A3
	v_add_f32_e32 v10, v10, v11                                // 00000001020C: 0614170A
	v_and_b32_e32 v15, 0xffff0000, v71                         // 000000010210: 361E8EFF FFFF0000
	v_dual_mul_f32 v15, v15, v15 :: v_dual_lshlrev_b32 v12, 16, v68// 000000010218: C8E21F0F 0F0C8890
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000010220: BF870121
	v_dual_mul_f32 v11, v12, v12 :: v_dual_lshlrev_b32 v14, 16, v71// 000000010224: C8E2190C 0B0E8E90
	v_dual_mul_f32 v12, v13, v13 :: v_dual_lshlrev_b32 v13, 16, v72// 00000001022C: C8E21B0D 0C0C9090
	v_mul_f32_e32 v14, v14, v14                                // 000000010234: 101C1D0E
	v_and_b32_e32 v16, 0xffff0000, v72                         // 000000010238: 362090FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010240: BF870193
	v_dual_add_f32 v11, v11, v12 :: v_dual_mul_f32 v12, v13, v13// 000000010244: C906190B 0B0C1B0D
	v_add_f32_e32 v9, v14, v15                                 // 00000001024C: 06121F0E
	v_add_f32_e32 v2, v2, v8                                   // 000000010250: 06041102
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000010254: BF8701C3
	v_add_f32_e32 v7, v10, v11                                 // 000000010258: 060E170A
	v_cndmask_b32_e32 v11, v138, v137, vcc_lo                  // 00000001025C: 0217138A
	v_mul_f32_e32 v13, v16, v16                                // 000000010260: 101A2110
	v_cmp_lt_u32_e32 vcc_lo, v146, v140                        // 000000010264: 7C931992
	v_lshlrev_b32_e32 v8, 2, v11                               // 000000010268: 30101682
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001026C: BF870093
	v_dual_add_f32 v10, v12, v13 :: v_dual_add_f32 v1, v1, v7  // 000000010270: C9081B0C 0A000F01
	v_add_f32_e32 v7, v9, v10                                  // 000000010278: 060E1509
	v_cndmask_b32_e32 v9, v138, v146, vcc_lo                   // 00000001027C: 0213258A
	v_cmp_lt_u32_e32 vcc_lo, v143, v140                        // 000000010280: 7C93198F
	v_lshlrev_b32_e32 v10, 2, v6                               // 000000010284: 30140C82
	s_delay_alu instid0(VALU_DEP_4)                            // 000000010288: BF870004
	v_add_f32_e32 v2, v2, v7                                   // 00000001028C: 06040F02
	ds_bpermute_b32 v7, v8, v1                                 // 000000010290: DACC0000 07000108
	ds_bpermute_b32 v8, v8, v2                                 // 000000010298: DACC0000 08000208
	s_waitcnt lgkmcnt(0)                                       // 0000000102A0: BF89FC07
	v_dual_add_f32 v2, v2, v8 :: v_dual_add_f32 v1, v1, v7     // 0000000102A4: C9081102 02000F01
	v_lshlrev_b32_e32 v7, 2, v9                                // 0000000102AC: 300E1282
	v_cndmask_b32_e32 v9, v138, v143, vcc_lo                   // 0000000102B0: 02131F8A
	v_cmp_lt_u32_e32 vcc_lo, v144, v140                        // 0000000102B4: 7C931990
	ds_bpermute_b32 v8, v7, v1                                 // 0000000102B8: DACC0000 08000107
	ds_bpermute_b32 v7, v7, v2                                 // 0000000102C0: DACC0000 07000207
	s_waitcnt lgkmcnt(1)                                       // 0000000102C8: BF89FC17
	v_dual_add_f32 v1, v1, v8 :: v_dual_lshlrev_b32 v8, 2, v9  // 0000000102CC: C9221101 01081282
	s_waitcnt lgkmcnt(0)                                       // 0000000102D4: BF89FC07
	v_add_f32_e32 v7, v2, v7                                   // 0000000102D8: 060E0F02
	v_cndmask_b32_e32 v9, v138, v144, vcc_lo                   // 0000000102DC: 0213218A
	ds_bpermute_b32 v2, v8, v1                                 // 0000000102E0: DACC0000 02000108
	ds_bpermute_b32 v8, v8, v7                                 // 0000000102E8: DACC0000 08000708
	s_waitcnt lgkmcnt(1)                                       // 0000000102F0: BF89FC17
	v_dual_add_f32 v2, v1, v2 :: v_dual_lshlrev_b32 v1, 2, v9  // 0000000102F4: C9220501 02001282
	s_waitcnt lgkmcnt(0)                                       // 0000000102FC: BF89FC07
	v_add_f32_e32 v7, v7, v8                                   // 000000010300: 060E1107
	ds_bpermute_b32 v9, v1, v2                                 // 000000010304: DACC0000 09000201
	ds_bpermute_b32 v8, v1, v7                                 // 00000001030C: DACC0000 08000701
	v_add_nc_u32_e32 v1, 0x5c00, v10                           // 000000010314: 4A0214FF 00005C00
	v_cmpx_eq_u32_e32 0, v156                                  // 00000001031C: 7D953880
	s_cbranch_execz 38                                         // 000000010320: BFA50026 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xebc>
	s_waitcnt lgkmcnt(0)                                       // 000000010324: BF89FC07
	v_dual_add_f32 v2, v2, v9 :: v_dual_add_f32 v7, v7, v8     // 000000010328: C9081302 02061107
	v_rsq_f32_e32 v9, 0x43000000                               // 000000010330: 7E125CFF 43000000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000010338: BF870091
	v_dual_add_f32 v2, 0x358637bd, v2 :: v_dual_add_f32 v7, 0x358637bd, v7// 00000001033C: C90804FF 02060EFF 358637BD
	v_mul_f32_e32 v8, 0x4b800000, v2                           // 000000010348: 101004FF 4B800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v2                      // 000000010350: 7C2804FF 00800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010358: BF870193
	.long 0xd4140001                                           // 00000001035C: D4140001
	v_cndmask_b32_e32 v1, 0x800000, v7, vcc_lo                 // 000000010360: 02020EFF 00800000
	v_cndmask_b32_e32 v2, v2, v8, vcc_lo                       // 000000010368: 02041102
	v_mul_f32_e32 v8, 0x4b800000, v7                           // 00000001036C: 10100EFF 4B800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000010374: BF870092
	v_rsq_f32_e32 v2, v2                                       // 000000010378: 7E045D02
	v_cndmask_b32_e64 v7, v7, v8, s1                           // 00000001037C: D5010007 00061107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000010384: BF870311
	v_rsq_f32_e32 v7, v7                                       // 000000010388: 7E0E5D07
	v_mul_f32_e32 v8, 0x45800000, v2                           // 00000001038C: 101004FF 45800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000010394: BF870291
	v_cndmask_b32_e32 v2, v2, v8, vcc_lo                       // 000000010398: 02041102
	v_mul_f32_e32 v8, 0x45800000, v7                           // 00000001039C: 10100EFF 45800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000103A4: BF870112
	v_mul_f32_e32 v2, v9, v2                                   // 0000000103A8: 10040509
	v_cndmask_b32_e64 v7, v7, v8, s1                           // 0000000103AC: D5010007 00061107
	ds_store_2addr_b32 v1, v7, v2 offset0:208 offset1:224      // 0000000103B4: D838E0D0 00020701
	s_or_b32 exec_lo, exec_lo, s45                             // 0000000103BC: 8C7E2D7E
	v_and_b32_e32 v27, 31, v5                                  // 0000000103C0: 36360A9F
	s_and_not1_b32 vcc_lo, exec_lo, s31                        // 0000000103C4: 916A1F7E
	s_cbranch_vccnz 119                                        // 0000000103C8: BFA40077 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10a8>
	.long 0xd760003c                                           // 0000000103CC: D760003C
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 0000000103D0: 02010188
	.long 0xd760003b                                           // 0000000103D4: D760003B
	v_cndmask_b32_e32 v0, v136, v129, vcc_lo                   // 0000000103D8: 02010388
	.long 0xd760003a                                           // 0000000103DC: D760003A
	v_cndmask_b32_e32 v0, v136, v130, vcc_lo                   // 0000000103E0: 02010588
	.long 0xd7600039                                           // 0000000103E4: D7600039
	v_cndmask_b32_e32 v0, v136, v131, vcc_lo                   // 0000000103E8: 02010788
	.long 0xd7600038                                           // 0000000103EC: D7600038
	v_cndmask_b32_e32 v0, v136, v132, vcc_lo                   // 0000000103F0: 02010988
	.long 0xd7600037                                           // 0000000103F4: D7600037
	v_cndmask_b32_e32 v0, v136, v133, vcc_lo                   // 0000000103F8: 02010B88
	.long 0xd7600036                                           // 0000000103FC: D7600036
	v_cndmask_b32_e32 v0, v136, v134, vcc_lo                   // 000000010400: 02010D88
	.long 0xd7600035                                           // 000000010404: D7600035
	v_cndmask_b32_e32 v0, v136, v135, vcc_lo                   // 000000010408: 02010F88
	.long 0xd7600034                                           // 00000001040C: D7600034
	v_cndmask_b32_e32 v0, v136, v136, vcc_lo                   // 000000010410: 02011188
	.long 0xd7600033                                           // 000000010414: D7600033
	v_cndmask_b32_e32 v0, v136, v137, vcc_lo                   // 000000010418: 02011388
	.long 0xd7600032                                           // 00000001041C: D7600032
	v_cndmask_b32_e32 v0, v136, v138, vcc_lo                   // 000000010420: 02011588
	.long 0xd7600031                                           // 000000010424: D7600031
	v_cndmask_b32_e32 v0, v136, v139, vcc_lo                   // 000000010428: 02011788
	.long 0xd7600030                                           // 00000001042C: D7600030
	v_cndmask_b32_e32 v0, v136, v140, vcc_lo                   // 000000010430: 02011988
	.long 0xd760002f                                           // 000000010434: D760002F
	v_cndmask_b32_e32 v0, v136, v141, vcc_lo                   // 000000010438: 02011B88
	.long 0xd760002e                                           // 00000001043C: D760002E
	v_cndmask_b32_e32 v0, v136, v142, vcc_lo                   // 000000010440: 02011D88
	.long 0xd760002d                                           // 000000010444: D760002D
	v_cndmask_b32_e32 v0, v136, v143, vcc_lo                   // 000000010448: 02011F88
	s_mov_b32 s1, exec_lo                                      // 00000001044C: BE81007E
	v_cmpx_gt_u32_e32 16, v27                                  // 000000010450: 7D983690
	s_cbranch_execz 83                                         // 000000010454: BFA50053 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10a4>
	v_cmp_eq_u32_e32 vcc_lo, 0, v27                            // 000000010458: 7C943680
	s_add_f32 s60, s60, 0                                      // 00000001045C: A03C803C
	v_lshlrev_b32_e32 v7, 2, v27                               // 000000010460: 300E3682
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000010464: BF8704BA
	s_add_f32 s59, s60, s59                                    // 000000010468: A03B3B3C
	v_cndmask_b32_e64 v2, 0, s60, vcc_lo                       // 00000001046C: D5010002 01A87880
	v_cmp_eq_u32_e32 vcc_lo, 1, v27                            // 000000010474: 7C943681
	s_add_f32 s58, s59, s58                                    // 000000010478: A03A3A3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000001047C: BF8704A2
	v_cndmask_b32_e64 v2, v2, s59, vcc_lo                      // 000000010480: D5010002 01A87702
	v_cmp_eq_u32_e32 vcc_lo, 2, v27                            // 000000010488: 7C943682
	s_add_f32 s57, s58, s57                                    // 00000001048C: A039393A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000010490: BF8704A2
	v_cndmask_b32_e64 v2, v2, s58, vcc_lo                      // 000000010494: D5010002 01A87502
	v_cmp_eq_u32_e32 vcc_lo, 3, v27                            // 00000001049C: 7C943683
	s_add_f32 s56, s57, s56                                    // 0000000104A0: A0383839
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000104A4: BF8704A2
	v_cndmask_b32_e64 v2, v2, s57, vcc_lo                      // 0000000104A8: D5010002 01A87302
	v_cmp_eq_u32_e32 vcc_lo, 4, v27                            // 0000000104B0: 7C943684
	s_add_f32 s55, s56, s55                                    // 0000000104B4: A0373738
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000104B8: BF8704A2
	v_cndmask_b32_e64 v2, v2, s56, vcc_lo                      // 0000000104BC: D5010002 01A87102
	v_cmp_eq_u32_e32 vcc_lo, 5, v27                            // 0000000104C4: 7C943685
	s_add_f32 s54, s55, s54                                    // 0000000104C8: A0363637
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000104CC: BF8704A2
	v_cndmask_b32_e64 v2, v2, s55, vcc_lo                      // 0000000104D0: D5010002 01A86F02
	v_cmp_eq_u32_e32 vcc_lo, 6, v27                            // 0000000104D8: 7C943686
	s_add_f32 s53, s54, s53                                    // 0000000104DC: A0353536
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000104E0: BF8704A2
	v_cndmask_b32_e64 v2, v2, s54, vcc_lo                      // 0000000104E4: D5010002 01A86D02
	v_cmp_eq_u32_e32 vcc_lo, 7, v27                            // 0000000104EC: 7C943687
	s_add_f32 s52, s53, s52                                    // 0000000104F0: A0343435
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000104F4: BF8704A2
	v_cndmask_b32_e64 v2, v2, s53, vcc_lo                      // 0000000104F8: D5010002 01A86B02
	v_cmp_eq_u32_e32 vcc_lo, 8, v27                            // 000000010500: 7C943688
	s_add_f32 s51, s52, s51                                    // 000000010504: A0333334
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000010508: BF8704A2
	v_cndmask_b32_e64 v2, v2, s52, vcc_lo                      // 00000001050C: D5010002 01A86902
	v_cmp_eq_u32_e32 vcc_lo, 9, v27                            // 000000010514: 7C943689
	s_add_f32 s50, s51, s50                                    // 000000010518: A0323233
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000001051C: BF8704A2
	v_cndmask_b32_e64 v2, v2, s51, vcc_lo                      // 000000010520: D5010002 01A86702
	v_cmp_eq_u32_e32 vcc_lo, 10, v27                           // 000000010528: 7C94368A
	s_add_f32 s49, s50, s49                                    // 00000001052C: A0313132
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000010530: BF8704A2
	v_cndmask_b32_e64 v2, v2, s50, vcc_lo                      // 000000010534: D5010002 01A86502
	v_cmp_eq_u32_e32 vcc_lo, 11, v27                           // 00000001053C: 7C94368B
	s_add_f32 s48, s49, s48                                    // 000000010540: A0303031
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000010544: BF8704A2
	v_cndmask_b32_e64 v2, v2, s49, vcc_lo                      // 000000010548: D5010002 01A86302
	v_cmp_eq_u32_e32 vcc_lo, 12, v27                           // 000000010550: 7C94368C
	s_add_f32 s47, s48, s47                                    // 000000010554: A02F2F30
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000010558: BF8704A2
	v_cndmask_b32_e64 v2, v2, s48, vcc_lo                      // 00000001055C: D5010002 01A86102
	v_cmp_eq_u32_e32 vcc_lo, 13, v27                           // 000000010564: 7C94368D
	s_add_f32 s46, s47, s46                                    // 000000010568: A02E2E2F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000001056C: BF8704A2
	v_cndmask_b32_e64 v2, v2, s47, vcc_lo                      // 000000010570: D5010002 01A85F02
	v_cmp_eq_u32_e32 vcc_lo, 14, v27                           // 000000010578: 7C94368E
	s_add_f32 s45, s46, s45                                    // 00000001057C: A02D2D2E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000010580: BF870002
	v_cndmask_b32_e64 v2, v2, s46, vcc_lo                      // 000000010584: D5010002 01A85D02
	v_cmp_eq_u32_e32 vcc_lo, 15, v27                           // 00000001058C: 7C94368F
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 000000010590: BF870482
	v_cndmask_b32_e64 v2, v2, s45, vcc_lo                      // 000000010594: D5010002 01A85B02
	ds_store_b32 v7, v2 offset:24128                           // 00000001059C: D8345E40 00000207
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000105A4: 8C7E017E
	s_add_i32 s43, s43, 1                                      // 0000000105A8: 812B812B
	s_waitcnt lgkmcnt(0)                                       // 0000000105AC: BF89FC07
	s_barrier                                                  // 0000000105B0: BFBD0000
	s_cmp_ge_i32 s43, s15                                      // 0000000105B4: BF030F2B
	s_cbranch_scc1 68                                          // 0000000105B8: BFA20044 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11cc>
	s_lshl_b32 s1, s43, 4                                      // 0000000105BC: 8401842B
	s_waitcnt lgkmcnt(1)                                       // 0000000105C0: BF89FC17
	v_lshlrev_b32_e32 v9, 4, v5                                // 0000000105C4: 30120A84
	v_add_nc_u32_e32 v2, s1, v6                                // 0000000105C8: 4A040C01
	s_mov_b32 s45, exec_lo                                     // 0000000105CC: BEAD007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000105D0: BF870112
	v_and_b32_e32 v9, 0xf0, v9                                 // 0000000105D4: 361212FF 000000F0
	v_min_i32_e32 v7, s30, v2                                  // 0000000105DC: 220E041E
	s_waitcnt lgkmcnt(0)                                       // 0000000105E0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000105E4: BF870091
	v_mad_i64_i32 v[7:8], null, 0x5000, v7, s[4:5]             // 0000000105E8: D6FF7C07 00120EFF 00005000
	.long 0xd7006a07                                           // 0000000105F4: D7006A07
	v_cndmask_b32_e32 v1, v7, v9, vcc_lo                       // 0000000105F8: 02021307
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000105FC: BF870111
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 000000010600: D5207C08 01AA1080
	.long 0xd7006a0b                                           // 000000010608: D7006A0B
	v_cndmask_b32_e32 v1, 0x1000, v7, vcc_lo                   // 00000001060C: 02020EFF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000010614: BF870001
	v_add_co_ci_u32_e64 v12, null, 0, v8, vcc_lo               // 000000010618: D5207C0C 01AA1080
	s_clause 0x1                                               // 000000010620: BF850001
	global_load_b128 v[65:68], v[7:8], off                     // 000000010624: DC5E0000 417C0007
	global_load_b128 v[69:72], v[11:12], off                   // 00000001062C: DC5E0000 457C000B
	.long 0xd4c3007e                                           // 000000010634: D4C3007E
	v_cndmask_b32_e32 v1, s29, v2, vcc_lo                      // 000000010638: 0202041D
	s_cbranch_execz 11                                         // 00000001063C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x116c>
	s_waitcnt vmcnt(1)                                         // 000000010640: BF8907F7
	v_mov_b32_e32 v65, 0                                       // 000000010644: 7E820280
	s_waitcnt vmcnt(0)                                         // 000000010648: BF8903F7
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001064C: BF870001
	v_mov_b32_e32 v72, v65                                     // 000000010650: 7E900341
	v_mov_b32_e32 v71, v65                                     // 000000010654: 7E8E0341
	v_mov_b32_e32 v70, v65                                     // 000000010658: 7E8C0341
	v_mov_b32_e32 v69, v65                                     // 00000001065C: 7E8A0341
	v_mov_b32_e32 v66, v65                                     // 000000010660: 7E840341
	v_mov_b32_e32 v67, v65                                     // 000000010664: 7E860341
	v_mov_b32_e32 v68, v65                                     // 000000010668: 7E880341
	s_or_b32 exec_lo, exec_lo, s45                             // 00000001066C: 8C7E2D7E
	s_and_saveexec_b32 s45, s0                                 // 000000010670: BEAD2000
	s_cbranch_execz 19                                         // 000000010674: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11c4>
	v_add_nc_u32_e32 v2, s1, v5                                // 000000010678: 4A040A01
	v_mov_b32_e32 v136, 0                                      // 00000001067C: 7F100280
	v_mov_b32_e32 v142, 0                                      // 000000010680: 7F1C0280
	s_mov_b32 s1, exec_lo                                      // 000000010684: BE81007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000010688: BF870003
	.long 0xd4c4007e                                           // 00000001068C: D4C4007E
	v_cndmask_b32_e32 v1, s29, v2, vcc_lo                      // 000000010690: 0202041D
	s_cbranch_execz 10                                         // 000000010694: BFA5000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11c0>
	v_mad_i64_i32 v[7:8], null, 0xc0, v2, s[6:7]               // 000000010698: D6FF7C07 001A04FF 000000C0
	v_mad_i64_i32 v[11:12], null, 0xc0, v2, s[10:11]           // 0000000106A4: D6FF7C0B 002A04FF 000000C0
	global_load_b32 v136, v[7:8], off                          // 0000000106B0: DC520000 887C0007
	global_load_b32 v142, v[11:12], off                        // 0000000106B8: DC520000 8E7C000B
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000106C0: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000106C4: BF870009
	s_or_b32 exec_lo, exec_lo, s45                             // 0000000106C8: 8C7E2D7E
	ds_load_2addr_b32 v[1:2], v1 offset0:128 offset1:208       // 0000000106CC: D8DCD080 01000001
	v_lshlrev_b32_e32 v7, 2, v156                              // 0000000106D4: 300F3882
	v_add_nc_u32_e32 v11, 0xffffef00, v3                       // 0000000106D8: 4A1606FF FFFFEF00
	v_add_nc_u32_e32 v3, 0x5f80, v10                           // 0000000106E0: 4A0614FF 00005F80
	v_mad_u32_u24 v12, 0x110, v156, s40                        // 0000000106E8: D60B000C 00A338FF 00000110
	v_mov_b32_e32 v51, 0                                       // 0000000106F4: 7E660280
	s_mov_b32 s1, 0                                            // 0000000106F8: BE810080
	v_mov_b32_e32 v52, 0                                       // 0000000106FC: 7E680280
	s_waitcnt lgkmcnt(0)                                       // 000000010700: BF89FC07
	v_mov_b32_e32 v14, v1                                      // 000000010704: 7E1C0301
	ds_load_b32 v8, v7 offset:24384                            // 000000010708: D8D85F40 08000007
	ds_load_b32 v9, v10 offset:24448                           // 000000010710: D8D85F80 0900000A
	v_or_b32_e32 v10, 0x5f40, v7                               // 000000010718: 38140EFF 00005F40
	v_dual_mov_b32 v13, v1 :: v_dual_mov_b32 v30, v2           // 000000010720: CA100101 0D1E0102
	v_dual_mov_b32 v15, v1 :: v_dual_mov_b32 v32, v2           // 000000010728: CA100101 0F200102
	v_mov_b32_e32 v16, v1                                      // 000000010730: 7E200301
	v_mov_b32_e32 v17, v1                                      // 000000010734: 7E220301
	v_mov_b32_e32 v28, v1                                      // 000000010738: 7E380301
	v_mov_b32_e32 v29, v1                                      // 00000001073C: 7E3A0301
	v_mov_b32_e32 v31, v2                                      // 000000010740: 7E3E0302
	v_mov_b32_e32 v33, v2                                      // 000000010744: 7E420302
	v_mov_b32_e32 v41, v2                                      // 000000010748: 7E520302
	v_mov_b32_e32 v42, v2                                      // 00000001074C: 7E540302
	s_waitcnt lgkmcnt(1)                                       // 000000010750: BF89FC17
	v_dual_mov_b32 v43, v2 :: v_dual_mov_b32 v34, v8           // 000000010754: CA100102 2B220108
	v_mov_b32_e32 v35, v8                                      // 00000001075C: 7E460308
	v_mov_b32_e32 v36, v8                                      // 000000010760: 7E480308
	s_waitcnt lgkmcnt(0)                                       // 000000010764: BF89FC07
	v_dual_mov_b32 v37, v8 :: v_dual_mov_b32 v44, v9           // 000000010768: CA100108 252C0109
	v_mov_b32_e32 v38, v8                                      // 000000010770: 7E4C0308
	v_dual_mov_b32 v39, v8 :: v_dual_mov_b32 v46, v9           // 000000010774: CA100108 272E0109
	v_dual_mov_b32 v40, v8 :: v_dual_mov_b32 v45, v9           // 00000001077C: CA100108 282C0109
	v_mov_b32_e32 v47, v9                                      // 000000010784: 7E5E0309
	v_mov_b32_e32 v48, v9                                      // 000000010788: 7E600309
	v_mov_b32_e32 v49, v9                                      // 00000001078C: 7E620309
	v_mov_b32_e32 v50, v9                                      // 000000010790: 7E640309
	s_lshl_b32 s45, s1, 1                                      // 000000010794: 842D8101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000010798: BF870009
	v_add_nc_u32_e32 v58, s45, v11                             // 00000001079C: 4A74162D
	v_add_nc_u32_e32 v57, s45, v12                             // 0000000107A0: 4A72182D
	s_add_i32 s45, s1, 16                                      // 0000000107A4: 812D9001
	s_cmpk_gt_u32 s1, 0x6f                                     // 0000000107A8: B581006F
	s_mov_b32 s1, s45                                          // 0000000107AC: BE81002D
	ds_load_b128 v[53:56], v58                                 // 0000000107B0: DBFC0000 3500003A
	ds_load_b128 v[59:62], v58 offset:16                       // 0000000107B8: DBFC0010 3B00003A
	s_waitcnt lgkmcnt(1)                                       // 0000000107C0: BF89FC17
	v_and_b32_e32 v63, 0xffff0000, v56                         // 0000000107C4: 367E70FF FFFF0000
	v_lshlrev_b32_e32 v64, 16, v56                             // 0000000107CC: 30807090
	v_and_b32_e32 v77, 0xffff0000, v55                         // 0000000107D0: 369A6EFF FFFF0000
	v_lshlrev_b32_e32 v78, 16, v55                             // 0000000107D8: 309C6E90
	v_and_b32_e32 v79, 0xffff0000, v54                         // 0000000107DC: 369E6CFF FFFF0000
	v_lshlrev_b32_e32 v80, 16, v54                             // 0000000107E4: 30A06C90
	v_and_b32_e32 v157, 0xffff0000, v53                        // 0000000107E8: 373A6AFF FFFF0000
	v_lshlrev_b32_e32 v158, 16, v53                            // 0000000107F0: 313C6A90
	ds_load_b128 v[53:56], v57                                 // 0000000107F4: DBFC0000 35000039
	ds_load_b128 v[73:76], v57 offset:16                       // 0000000107FC: DBFC0010 49000039
	s_waitcnt lgkmcnt(1)                                       // 000000010804: BF89FC17
	v_and_b32_e32 v159, 0xffff0000, v55                        // 000000010808: 373E6EFF FFFF0000
	v_and_b32_e32 v160, 0xffff0000, v54                        // 000000010810: 37406CFF FFFF0000
	v_lshlrev_b32_e32 v54, 16, v54                             // 000000010818: 306C6C90
	v_lshlrev_b32_e32 v55, 16, v55                             // 00000001081C: 306E6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010820: BF870193
	v_dual_mul_f32 v159, v38, v159 :: v_dual_mul_f32 v160, v36, v160// 000000010824: C8C73F26 9FA14124
	v_dual_mul_f32 v163, v35, v54 :: v_dual_mul_f32 v54, v42, v64// 00000001082C: C8C66D23 A336812A
	v_dual_mul_f32 v64, v31, v80 :: v_dual_and_b32 v161, 0xffff0000, v53// 000000010834: C8E4A11F 40A06AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000010840: BF870114
	v_dual_mul_f32 v164, v37, v55 :: v_dual_lshlrev_b32 v53, 16, v53// 000000010844: C8E26F25 A4346A90
	v_dual_mul_f32 v55, v41, v77 :: v_dual_mul_f32 v64, v15, v64// 00000001084C: C8C69B29 3740810F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010854: BF870193
	v_mul_f32_e32 v161, v34, v161                              // 000000010858: 11434322
	v_dual_mul_f32 v162, v8, v53 :: v_dual_mul_f32 v53, v43, v63// 00000001085C: C8C66B08 A2347F2B
	v_and_b32_e32 v57, 0xffff0000, v56                         // 000000010864: 367270FF FFFF0000
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000001086C: 30707090
	v_dual_mul_f32 v54, v29, v54 :: v_dual_mul_f32 v63, v32, v79// 000000010870: C8C66D1D 363E9F20
	v_mul_f32_e32 v64, v163, v64                               // 000000010878: 108081A3
	v_lshlrev_b32_e32 v79, 16, v60                             // 00000001087C: 309E7890
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000010880: BF8701B4
	v_dual_mul_f32 v165, v39, v56 :: v_dual_mul_f32 v56, v33, v78// 000000010884: C8C67127 A5389D21
	v_mul_f32_e32 v78, v2, v158                                // 00000001088C: 109D3D02
	v_mul_f32_e32 v77, v30, v157                               // 000000010890: 109B3B1E
	v_dual_mul_f32 v63, v16, v63 :: v_dual_mul_f32 v54, v165, v54// 000000010894: C8C67F10 3F366DA5
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001089C: BF870194
	v_mul_f32_e32 v56, v17, v56                                // 0000000108A0: 10707111
	v_dual_mul_f32 v78, v13, v78 :: v_dual_mul_f32 v77, v14, v77// 0000000108A4: C8C69D0D 4E4C9B0E
	v_mul_f32_e32 v55, v28, v55                                // 0000000108AC: 106E6F1C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000108B0: BF870214
	v_mul_f32_e32 v63, v160, v63                               // 0000000108B4: 107E7FA0
	v_dual_mul_f32 v53, v1, v53 :: v_dual_mul_f32 v56, v164, v56// 0000000108B8: C8C66B01 353871A4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000108C0: BF870214
	v_dual_mul_f32 v78, v162, v78 :: v_dual_mul_f32 v77, v161, v77// 0000000108C4: C8C69DA2 4E4C9BA1
	v_mul_f32_e32 v55, v159, v55                               // 0000000108CC: 106E6F9F
	v_dual_mul_f32 v57, v40, v57 :: v_dual_and_b32 v80, 0xffff0000, v59// 0000000108D0: C8E47328 395076FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000108DC: BF870113
	v_add_f32_e32 v51, v51, v78                                // 0000000108E0: 06669D33
	v_mul_f32_e32 v53, v57, v53                                // 0000000108E4: 106A6B39
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000108E8: BF870092
	v_add_f32_e32 v51, v51, v77                                // 0000000108EC: 06669B33
	v_add_f32_e32 v51, v51, v64                                // 0000000108F0: 06668133
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000108F4: BF870091
	v_add_f32_e32 v51, v51, v63                                // 0000000108F8: 06667F33
	v_add_f32_e32 v51, v51, v56                                // 0000000108FC: 06667133
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000010900: BF870091
	v_add_f32_e32 v51, v51, v55                                // 000000010904: 06666F33
	v_add_f32_e32 v51, v51, v54                                // 000000010908: 06666D33
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001090C: BF870001
	v_add_f32_e32 v51, v51, v53                                // 000000010910: 06666B33
	ds_load_b128 v[53:56], v58 offset:4352                     // 000000010914: DBFC1100 3500003A
	s_waitcnt lgkmcnt(0)                                       // 00000001091C: BF89FC07
	v_and_b32_e32 v78, 0xffff0000, v53                         // 000000010920: 369C6AFF FFFF0000
	v_lshlrev_b32_e32 v53, 16, v53                             // 000000010928: 306A6A90
	v_and_b32_e32 v64, 0xffff0000, v55                         // 00000001092C: 36806EFF FFFF0000
	v_and_b32_e32 v77, 0xffff0000, v54                         // 000000010934: 369A6CFF FFFF0000
	v_lshlrev_b32_e32 v54, 16, v54                             // 00000001093C: 306C6C90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000010940: BF870214
	v_dual_mul_f32 v78, v44, v78 :: v_dual_mul_f32 v53, v9, v53// 000000010944: C8C69D2C 4E346B09
	v_mul_f32_e32 v64, v48, v64                                // 00000001094C: 10808130
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010950: BF870193
	v_mul_f32_e32 v54, v45, v54                                // 000000010954: 106C6D2D
	v_mul_f32_e32 v53, v53, v162                               // 000000010958: 106B4535
	v_and_b32_e32 v63, 0xffff0000, v56                         // 00000001095C: 367E70FF FFFF0000
	v_lshlrev_b32_e32 v56, 16, v56                             // 000000010964: 30707090
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010968: BF870194
	v_mul_f32_e32 v54, v54, v163                               // 00000001096C: 106D4736
	v_dual_add_f32 v52, v52, v53 :: v_dual_mul_f32 v63, v50, v63// 000000010970: C9066B34 343E7F32
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000010978: BF870113
	v_dual_mul_f32 v56, v49, v56 :: v_dual_lshlrev_b32 v53, 16, v73// 00000001097C: C8E27131 38349290
	v_mul_f32_e32 v57, v63, v57                                // 000000010984: 1072733F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000010988: BF8700A2
	v_mul_f32_e32 v56, v56, v165                               // 00000001098C: 10714B38
	v_mul_f32_e32 v77, v46, v77                                // 000000010990: 109A9B2E
	v_dual_mul_f32 v63, v64, v159 :: v_dual_mul_f32 v64, v77, v160// 000000010994: C8C73F40 3F41414D
	v_dual_mul_f32 v77, v78, v161 :: v_dual_and_b32 v78, 0xffff0000, v60// 00000001099C: C8E5434E 4D4E78FF FFFF0000
	v_lshlrev_b32_e32 v60, 16, v76                             // 0000000109A8: 30789890
	v_lshlrev_b32_e32 v55, 16, v55                             // 0000000109AC: 306E6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000109B0: BF870193
	v_dual_add_f32 v52, v52, v77 :: v_dual_lshlrev_b32 v157, 16, v59// 0000000109B4: C9229B34 349C7690
	v_mul_f32_e32 v60, v39, v60                                // 0000000109BC: 10787927
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000109C0: BF8701B2
	v_dual_mul_f32 v55, v47, v55 :: v_dual_add_f32 v52, v52, v54// 0000000109C4: C8C86F2F 37346D34
	v_and_b32_e32 v54, 0xffff0000, v73                         // 0000000109CC: 366C92FF FFFF0000
	v_lshlrev_b32_e32 v77, 16, v61                             // 0000000109D4: 309A7A90
	v_mul_f32_e32 v55, v55, v164                               // 0000000109D8: 106F4937
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000109DC: BF870004
	v_add_f32_e32 v52, v52, v64                                // 0000000109E0: 06688134
	v_and_b32_e32 v64, 0xffff0000, v61                         // 0000000109E4: 36807AFF FFFF0000
	v_and_b32_e32 v61, 0xffff0000, v76                         // 0000000109EC: 367A98FF FFFF0000
	v_mul_f32_e32 v76, v30, v80                                // 0000000109F4: 1098A11E
	v_mul_f32_e32 v54, v34, v54                                // 0000000109F8: 106C6D22
	v_dual_add_f32 v52, v52, v55 :: v_dual_lshlrev_b32 v55, 16, v74// 0000000109FC: C9226F34 34369490
	v_dual_mul_f32 v64, v41, v64 :: v_dual_and_b32 v59, 0xffff0000, v75// 000000010A04: C8E48129 403A96FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010A10: BF870194
	v_mul_f32_e32 v76, v14, v76                                // 000000010A14: 1098990E
	v_dual_add_f32 v52, v52, v63 :: v_dual_mul_f32 v73, v33, v77// 000000010A18: C9067F34 34489B21
	v_mul_f32_e32 v77, v2, v157                                // 000000010A20: 109B3B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010A24: BF870194
	v_dual_mul_f32 v55, v35, v55 :: v_dual_mul_f32 v64, v28, v64// 000000010A28: C8C66F23 3740811C
	v_add_f32_e32 v52, v52, v56                                // 000000010A30: 06687134
	v_and_b32_e32 v56, 0xffff0000, v74                         // 000000010A34: 367094FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000010A3C: BF870224
	v_dual_mul_f32 v74, v32, v78 :: v_dual_mul_f32 v77, v13, v77// 000000010A40: C8C69D20 4A4C9B0D
	v_mul_f32_e32 v76, v54, v76                                // 000000010A48: 10989936
	v_dual_add_f32 v52, v52, v57 :: v_dual_lshlrev_b32 v57, 16, v75// 000000010A4C: C9227334 34389690
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000010A54: BF8701C3
	v_mul_f32_e32 v74, v16, v74                                // 000000010A58: 10949510
	v_mul_f32_e32 v53, v8, v53                                 // 000000010A5C: 106A6B08
	v_dual_mul_f32 v56, v36, v56 :: v_dual_and_b32 v63, 0xffff0000, v62// 000000010A60: C8E47124 383E7CFF FFFF0000
	v_dual_mul_f32 v73, v17, v73 :: v_dual_lshlrev_b32 v62, 16, v62// 000000010A6C: C8E29311 493E7C90
	v_mul_f32_e32 v77, v53, v77                                // 000000010A74: 109A9B35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010A78: BF870193
	v_dual_mul_f32 v63, v43, v63 :: v_dual_mul_f32 v74, v56, v74// 000000010A7C: C8C67F2B 3F4A9538
	v_dual_mul_f32 v62, v42, v62 :: v_dual_mul_f32 v75, v31, v79// 000000010A84: C8C67D2A 3E4A9F1F
	v_mul_f32_e32 v59, v38, v59                                // 000000010A8C: 10767726
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010A90: BF870192
	v_dual_add_f32 v51, v51, v77 :: v_dual_mul_f32 v62, v29, v62// 000000010A94: C9069B33 333E7D1D
	v_mul_f32_e32 v75, v15, v75                                // 000000010A9C: 1096970F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010AA0: BF870193
	v_dual_mul_f32 v61, v40, v61 :: v_dual_mul_f32 v64, v59, v64// 000000010AA4: C8C67B28 3D40813B
	v_add_f32_e32 v51, v51, v76                                // 000000010AAC: 06669933
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000010AB0: BF870214
	v_dual_mul_f32 v57, v37, v57 :: v_dual_mul_f32 v62, v60, v62// 000000010AB4: C8C67325 393E7D3C
	v_mul_f32_e32 v75, v55, v75                                // 000000010ABC: 10969737
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000010AC0: BF870112
	v_mul_f32_e32 v73, v57, v73                                // 000000010AC4: 10929339
	v_add_f32_e32 v51, v51, v75                                // 000000010AC8: 06669733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000010ACC: BF870091
	v_add_f32_e32 v51, v51, v74                                // 000000010AD0: 06669533
	v_add_f32_e32 v51, v51, v73                                // 000000010AD4: 06669333
	ds_load_b128 v[73:76], v58 offset:4368                     // 000000010AD8: DBFC1110 4900003A
	v_mul_f32_e32 v63, v1, v63                                 // 000000010AE0: 107E7F01
	v_add_f32_e32 v51, v51, v64                                // 000000010AE4: 06668133
	s_waitcnt lgkmcnt(0)                                       // 000000010AE8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000010AEC: BF870241
	v_dual_add_f32 v51, v51, v62 :: v_dual_lshlrev_b32 v62, 16, v76// 000000010AF0: C9227D33 333E9890
	v_and_b32_e32 v58, 0xffff0000, v76                         // 000000010AF8: 367498FF FFFF0000
	v_lshlrev_b32_e32 v64, 16, v75                             // 000000010B00: 30809690
	v_dual_mul_f32 v63, v61, v63 :: v_dual_and_b32 v76, 0xffff0000, v73// 000000010B04: C8E47F3D 3F4C92FF FFFF0000
	v_mul_f32_e32 v62, v49, v62                                // 000000010B10: 107C7D31
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000010B14: BF870214
	v_mul_f32_e32 v58, v50, v58                                // 000000010B18: 10747532
	v_mul_f32_e32 v64, v47, v64                                // 000000010B1C: 1080812F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000010B20: BF870214
	v_mul_f32_e32 v76, v44, v76                                // 000000010B24: 1098992C
	v_dual_mul_f32 v60, v62, v60 :: v_dual_lshlrev_b32 v73, 16, v73// 000000010B28: C8E2793E 3C489290
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000010B30: BF870214
	v_mul_f32_e32 v58, v58, v61                                // 000000010B34: 10747B3A
	v_mul_f32_e32 v57, v64, v57                                // 000000010B38: 10727340
	v_add_f32_e32 v51, v51, v63                                // 000000010B3C: 06667F33
	v_and_b32_e32 v63, 0xffff0000, v75                         // 000000010B40: 367E96FF FFFF0000
	v_mul_f32_e32 v73, v9, v73                                 // 000000010B48: 10929309
	v_and_b32_e32 v75, 0xffff0000, v74                         // 000000010B4C: 369694FF FFFF0000
	v_lshlrev_b32_e32 v74, 16, v74                             // 000000010B54: 30949490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000010B58: BF870113
	v_dual_mul_f32 v54, v76, v54 :: v_dual_mul_f32 v53, v73, v53// 000000010B5C: C8C66D4C 36346B49
	v_dual_mul_f32 v75, v46, v75 :: v_dual_mul_f32 v74, v45, v74// 000000010B64: C8C6972E 4B4A952D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000010B6C: BF870112
	v_add_f32_e32 v52, v52, v53                                // 000000010B70: 06686B34
	v_dual_mul_f32 v56, v75, v56 :: v_dual_mul_f32 v55, v74, v55// 000000010B74: C8C6714B 38366F4A
	v_mul_f32_e32 v63, v48, v63                                // 000000010B7C: 107E7F30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000010B80: BF870091
	v_dual_add_f32 v52, v52, v54 :: v_dual_mul_f32 v59, v63, v59// 000000010B84: C9066D34 343A773F
	v_add_f32_e32 v52, v52, v55                                // 000000010B8C: 06686F34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000010B90: BF870091
	v_add_f32_e32 v52, v52, v56                                // 000000010B94: 06687134
	v_add_f32_e32 v52, v52, v57                                // 000000010B98: 06687334
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000010B9C: BF870091
	v_add_f32_e32 v52, v52, v59                                // 000000010BA0: 06687734
	v_add_f32_e32 v52, v52, v60                                // 000000010BA4: 06687934
	s_delay_alu instid0(VALU_DEP_1)                            // 000000010BA8: BF870001
	v_add_f32_e32 v52, v52, v58                                // 000000010BAC: 06687534
	s_cbranch_scc0 65272                                       // 000000010BB0: BFA1FEF8 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1294>
	v_add_nc_u32_e32 v1, 0xfffffec0, v3                        // 000000010BB4: 4A0206FF FFFFFEC0
	v_add_nc_u32_e32 v2, 0xffffff00, v10                       // 000000010BBC: 4A0414FF FFFFFF00
	.long 0xd4410001                                           // 000000010BC4: D4410001
	v_cndmask_b32_e32 v1, v156, v6, vcc_lo                     // 000000010BC8: 02020D9C
	ds_load_b32 v1, v1                                         // 000000010BCC: D8D80000 01000001
	ds_load_b32 v2, v2                                         // 000000010BD4: D8D80000 02000002
	s_waitcnt lgkmcnt(0)                                       // 000000010BDC: BF89FC07
	v_sub_f32_e32 v1, v1, v2                                   // 000000010BE0: 08020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000010BE4: BF870091
	v_mul_f32_e32 v2, 0x3fb8aa3b, v1                           // 000000010BE8: 100402FF 3FB8AA3B
	v_fma_f32 v3, 0x3fb8aa3b, v1, -v2                          // 000000010BF0: D6130003 840A02FF 3FB8AA3B
	v_rndne_f32_e32 v8, v2                                     // 000000010BFC: 7E104702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000010C00: BF870091
	v_dual_fmac_f32 v3, 0x32a5705f, v1 :: v_dual_sub_f32 v2, v2, v8// 000000010C04: C80A02FF 03021102 32A5705F
	v_add_f32_e32 v2, v2, v3                                   // 000000010C10: 06040702
	v_cvt_i32_f32_e32 v3, v8                                   // 000000010C14: 7E061108
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1                   // 000000010C18: 7C3602FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000010C20: BF870293
	v_exp_f32_e32 v2, v2                                       // 000000010C24: 7E044B02
	.long 0xd71c0002                                           // 000000010C28: D71C0002
	v_cndmask_b32_e32 v1, v2, v3, vcc_lo                       // 000000010C2C: 02020702
	.long 0xd72c0003                                           // 000000010C30: D72C0003
	v_cndmask_b32_e32 v0, v6, v176, vcc_lo                     // 000000010C34: 02016106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000010C38: BF8701A2
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 000000010C3C: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1                   // 000000010C40: 7C3C02FF 42B17218
	v_lshl_add_u32 v3, v156, 1, v3                             // 000000010C48: D6460003 040D039C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000010C50: BF870123
	v_cndmask_b32_e32 v1, 0x7f800000, v2, vcc_lo               // 000000010C54: 020204FF 7F800000
	v_cmp_le_i32_e32 vcc_lo, v156, v6                          // 000000010C5C: 7C860D9C
	v_mul_f32_e32 v2, v52, v1                                  // 000000010C60: 10040334
	.long 0xd5080008                                           // 000000010C64: D5080008
	v_sub_co_ci_u32_e32 v1, vcc_lo, v51, v1, vcc_lo            // 000000010C68: 42020333
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000010C6C: BF8701A2
	v_fma_mixlo_f16 v1, v2, s41, 0                             // 000000010C70: CC210001 02005302
	v_lshl_or_b32 v2, v6, 6, v7                                // 000000010C78: D6560002 041D0D06
	v_cndmask_b32_e64 v6, 0, v8, s1                            // 000000010C80: D5010006 00061080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000010C88: BF870003
	v_cndmask_b16 v1, 0, v1, vcc_lo                            // 000000010C8C: D65D0001 01AA0280
	ds_store_b32 v2, v6 offset:22272                           // 000000010C94: D8345700 00000602
	ds_store_b16 v3, v1 offset:23296                           // 000000010C9C: D87C5B00 00000103
	s_and_saveexec_b32 s1, s0                                  // 000000010CA4: BE812000
	s_cbranch_execz 69                                         // 000000010CA8: BFA50045 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x18c0>
	v_add_nc_u32_e32 v3, 0x5c00, v4                            // 000000010CAC: 4A0608FF 00005C00
	ds_load_b32 v8, v4 offset:24384                            // 000000010CB4: D8D85F40 08000004
	ds_load_2addr_b32 v[1:2], v3 offset0:128 offset1:144       // 000000010CBC: D8DC9080 01000003
	ds_load_b32 v6, v139 offset:24188                          // 000000010CC4: D8D85E7C 0600008B
	s_waitcnt lgkmcnt(1)                                       // 000000010CCC: BF89FC17
	v_mul_f32_e32 v7, 0x3fb8aa3b, v2                           // 000000010CD0: 100E04FF 3FB8AA3B
	s_waitcnt lgkmcnt(0)                                       // 000000010CD8: BF89FC07
	v_sub_f32_e32 v6, v6, v2                                   // 000000010CDC: 080C0506
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2                   // 000000010CE0: 7C3604FF C2CE8ED0
	v_mul_f32_e32 v1, v8, v1                                   // 000000010CE8: 10020308
	v_fma_f32 v9, 0x3fb8aa3b, v2, -v7                          // 000000010CEC: D6130009 841E04FF 3FB8AA3B
	v_rndne_f32_e32 v10, v7                                    // 000000010CF8: 7E144707
	v_mul_f32_e32 v11, 0x3fb8aa3b, v6                          // 000000010CFC: 10160CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010D04: BF870193
	v_fmac_f32_e32 v9, 0x32a5705f, v2                          // 000000010D08: 561204FF 32A5705F
	v_sub_f32_e32 v7, v7, v10                                  // 000000010D10: 080E1507
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000010D14: BF8701B3
	v_fma_f32 v12, 0x3fb8aa3b, v6, -v11                        // 000000010D18: D613000C 842E0CFF 3FB8AA3B
	v_cvt_i32_f32_e32 v10, v10                                 // 000000010D24: 7E14110A
	v_rndne_f32_e32 v13, v11                                   // 000000010D28: 7E1A470B
	v_dual_add_f32 v7, v7, v9 :: v_dual_fmac_f32 v12, 0x32a5705f, v6// 000000010D2C: C9001307 070C0CFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000010D38: BF870291
	v_exp_f32_e32 v7, v7                                       // 000000010D3C: 7E0E4B07
	.long 0xd71c0007                                           // 000000010D40: D71C0007
	v_cndmask_b32_e32 v1, v7, v10, vcc_lo                      // 000000010D44: 02021507
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000010D48: BF870113
	v_cvt_i32_f32_e32 v10, v13                                 // 000000010D4C: 7E14110D
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo                        // 000000010D50: 020E0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2                   // 000000010D54: 7C3C04FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000010D5C: BF870092
	v_dual_sub_f32 v9, v11, v13 :: v_dual_cndmask_b32 v2, 0x7f800000, v7// 000000010D60: C9521B0B 09020EFF 7F800000
	v_add_f32_e32 v9, v9, v12                                  // 000000010D6C: 06121909
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v6                   // 000000010D70: 7C360CFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000010D78: BF870193
	v_mul_f32_e32 v1, v2, v1                                   // 000000010D7C: 10020302
	v_exp_f32_e32 v9, v9                                       // 000000010D80: 7E124B09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000010D84: BF870291
	v_mul_f32_e32 v1, 0x41800000, v1                           // 000000010D88: 100202FF 41800000
	.long 0xd71c0009                                           // 000000010D90: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000010D94: 02021509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000010D98: BF870121
	v_cndmask_b32_e32 v7, 0, v9, vcc_lo                        // 000000010D9C: 020E1280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v6                   // 000000010DA0: 7C3C0CFF 42B17218
	v_cndmask_b32_e32 v6, 0x7f800000, v7, vcc_lo               // 000000010DA8: 020C0EFF 7F800000
	ds_store_b32 v4, v2 offset:24320                           // 000000010DB0: D8345F00 00000204
	ds_store_2addr_b32 v3, v6, v1 offset0:160 offset1:176      // 000000010DB8: D838B0A0 00010603
	s_or_b32 exec_lo, exec_lo, s1                              // 000000010DC0: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 000000010DC4: BF89FC07
	s_barrier                                                  // 000000010DC8: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s33                             // 000000010DCC: 8B6A217E
	s_mov_b32 s0, -1                                           // 000000010DD0: BE8000C1
	s_cbranch_vccz 176                                         // 000000010DD4: BFA300B0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b98>
	s_mov_b32 s0, exec_lo                                      // 000000010DD8: BE80007E
	v_cmpx_gt_i32_e32 0x120, v5                                // 000000010DDC: 7D880AFF 00000120
	s_cbranch_execz 170                                        // 000000010DE4: BFA500AA <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b90>
	v_add_nc_u32_e32 v1, 0xffffff00, v5                        // 000000010DE8: 4A020AFF FFFFFF00
	s_mov_b32 s1, 0                                            // 000000010DF0: BE810080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000010DF4: BF870001
	v_mov_b32_e32 v2, v1                                       // 000000010DF8: 7E040301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000010DFC: BF870091
	v_add_nc_u32_e32 v2, 0xe0, v2                              // 000000010E00: 4A0404FF 000000E0
	v_ashrrev_i32_e32 v3, 7, v2                                // 000000010E08: 34060487
	v_and_b32_e32 v14, 0x7f, v2                                // 000000010E0C: 361C04FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000010E14: BF870122
	.long 0xd72c0004                                           // 000000010E18: D72C0004
	v_cndmask_b32_e32 v1, 0x880, v3, vcc_lo                    // 000000010E1C: 020206FF 00000880
	v_lshlrev_b32_e32 v28, 5, v3                               // 000000010E24: 30380685
	v_lshl_add_u32 v4, v14, 1, v4                              // 000000010E28: D6460004 0411030E
	ds_load_u16 v32, v4 offset:7776                            // 000000010E30: D8F01E60 20000004
	ds_load_u16 v33, v4 offset:7232                            // 000000010E38: D8F01C40 21000004
	ds_load_u16 v34, v4 offset:6688                            // 000000010E40: D8F01A20 22000004
	ds_load_u16 v35, v4 offset:6144                            // 000000010E48: D8F01800 23000004
	ds_load_u16 v36, v4 offset:6416                            // 000000010E50: D8F01910 24000004
	ds_load_u16 v37, v4 offset:6960                            // 000000010E58: D8F01B30 25000004
	ds_load_u16 v38, v4 offset:7504                            // 000000010E60: D8F01D50 26000004
	ds_load_u16 v4, v4 offset:8048                             // 000000010E68: D8F01F70 04000004
	ds_load_b128 v[6:9], v28 offset:24384                      // 000000010E70: DBFC5F40 0600001C
	ds_load_b128 v[10:13], v28 offset:24400                    // 000000010E78: DBFC5F50 0A00001C
	s_waitcnt lgkmcnt(4)                                       // 000000010E80: BF89FC47
	v_lshlrev_b32_e32 v37, 16, v37                             // 000000010E84: 304A4A90
	s_waitcnt lgkmcnt(2)                                       // 000000010E88: BF89FC27
	v_lshlrev_b32_e32 v4, 16, v4                               // 000000010E8C: 30080890
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000010E90: 30424290
	s_waitcnt lgkmcnt(1)                                       // 000000010E94: BF89FC17
	v_mul_f32_e32 v9, v9, v37                                  // 000000010E98: 10124B09
	v_mul_u32_u24_e32 v29, 48, v14                             // 000000010E9C: 163A1CB0
	s_waitcnt lgkmcnt(0)                                       // 000000010EA0: BF89FC07
	v_mul_f32_e32 v4, v13, v4                                  // 000000010EA4: 1008090D
	v_mul_f32_e32 v10, v10, v33                                // 000000010EA8: 1014430A
	v_lshlrev_b32_e32 v32, 16, v32                             // 000000010EAC: 30404090
	v_lshl_add_u32 v3, v3, 4, v29                              // 000000010EB0: D6460003 04750903
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000010EB8: BF8700A2
	v_mul_f32_e32 v12, v12, v32                                // 000000010EBC: 1018410C
	v_lshlrev_b32_e32 v38, 16, v38                             // 000000010EC0: 304C4C90
	v_mul_f32_e32 v11, v11, v38                                // 000000010EC4: 10164D0B
	ds_load_b128 v[14:17], v28 offset:24192                    // 000000010EC8: DBFC5E80 0E00001C
	ds_load_b128 v[28:31], v28 offset:24208                    // 000000010ED0: DBFC5E90 1C00001C
	v_lshlrev_b32_e32 v34, 16, v34                             // 000000010ED8: 30444490
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000010EDC: BF870091
	v_dual_mul_f32 v8, v8, v34 :: v_dual_lshlrev_b32 v35, 16, v35// 000000010EE0: C8E24508 08224690
	v_mul_f32_e32 v6, v6, v35                                  // 000000010EE8: 100C4706
	s_waitcnt lgkmcnt(1)                                       // 000000010EEC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000010EF0: BF870091
	v_dual_mul_f32 v13, v14, v6 :: v_dual_lshlrev_b32 v36, 16, v36// 000000010EF4: C8E20D0E 0D244890
	v_mul_f32_e32 v7, v7, v36                                  // 000000010EFC: 100E4907
	v_mul_f32_e32 v8, v16, v8                                  // 000000010F00: 10101110
	s_waitcnt lgkmcnt(0)                                       // 000000010F04: BF89FC07
	v_mul_f32_e32 v4, v31, v4                                  // 000000010F08: 1008091F
	v_cmp_lt_i32_e32 vcc_lo, 31, v2                            // 000000010F0C: 7C82049F
	v_dual_mul_f32 v6, v15, v7 :: v_dual_mul_f32 v7, v17, v9   // 000000010F10: C8C60F0F 06061311
	v_dual_mul_f32 v9, v28, v10 :: v_dual_mul_f32 v10, v29, v11// 000000010F18: C8C6151C 090A171D
	v_mul_f32_e32 v11, v30, v12                                // 000000010F20: 1016191E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000010F24: BF870003
	v_fma_mixhi_f16 v6, v6, s41, 0                             // 000000010F28: CC220006 02005306
	v_fma_mixlo_f16 v6, v13, s41, 0                            // 000000010F30: CC210006 0200530D
	v_fma_mixhi_f16 v7, v7, s41, 0                             // 000000010F38: CC220007 02005307
	v_fma_mixlo_f16 v7, v8, s41, 0                             // 000000010F40: CC210007 02005308
	v_fma_mixhi_f16 v8, v10, s41, 0                            // 000000010F48: CC220008 0200530A
	v_fma_mixlo_f16 v8, v9, s41, 0                             // 000000010F50: CC210008 02005309
	v_fma_mixhi_f16 v9, v4, s41, 0                             // 000000010F58: CC220009 02005304
	v_fma_mixlo_f16 v9, v11, s41, 0                            // 000000010F60: CC210009 0200530B
	s_or_b32 s1, vcc_lo, s1                                    // 000000010F68: 8C01016A
	ds_store_b128 v3, v[6:9]                                   // 000000010F6C: DB7C0000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000010F74: 917E017E
	s_cbranch_execnz 65440                                     // 000000010F78: BFA6FFA0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x18fc>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000010F7C: 8C7E017E
	v_lshl_add_u32 v2, v5, 3, 0xffffff00                       // 000000010F80: D6460002 03FD0705 FFFFFF00
	s_mov_b32 s1, 0                                            // 000000010F8C: BE810080
	v_add_nc_u32_e32 v1, 0xe0, v1                              // 000000010F90: 4A0202FF 000000E0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000010F98: BF8701A2
	v_and_b32_e32 v3, 0x78, v2                                 // 000000010F9C: 360604FF 00000078
	v_add_nc_u32_e32 v2, 0x700, v2                             // 000000010FA4: 4A0404FF 00000700
	v_ashrrev_i32_e32 v4, 4, v1                                // 000000010FAC: 34080284
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000010FB0: BF870121
	.long 0xd72c0005                                           // 000000010FB4: D72C0005
	v_cndmask_b32_e32 v1, 0x110, v4, vcc_lo                    // 000000010FB8: 020208FF 00000110
	v_lshlrev_b32_e32 v7, 2, v4                                // 000000010FC0: 300E0882
	v_lshl_add_u32 v8, v3, 1, v5                               // 000000010FC4: D6460008 04150303
	ds_load_b128 v[3:6], v8 offset:10496                       // 000000010FCC: DBFC2900 03000008
	ds_load_b32 v7, v7 offset:24448                            // 000000010FD4: D8D85F80 07000007
	s_waitcnt lgkmcnt(1)                                       // 000000010FDC: BF89FC17
	v_and_b32_e32 v11, 0xffff0000, v5                          // 000000010FE0: 36160AFF FFFF0000
	v_lshlrev_b32_e32 v5, 16, v5                               // 000000010FE8: 300A0A90
	v_and_b32_e32 v12, 0xffff0000, v6                          // 000000010FEC: 36180CFF FFFF0000
	v_and_b32_e32 v9, 0xffff0000, v3                           // 000000010FF4: 361206FF FFFF0000
	v_lshlrev_b32_e32 v3, 16, v3                               // 000000010FFC: 30060690
	v_and_b32_e32 v10, 0xffff0000, v4                          // 000000011000: 361408FF FFFF0000
	v_lshlrev_b32_e32 v4, 16, v4                               // 000000011008: 30080890
	s_waitcnt lgkmcnt(0)                                       // 00000001100C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000011010: BF8701A3
	v_dual_mul_f32 v13, v7, v3 :: v_dual_lshlrev_b32 v6, 16, v6// 000000011014: C8E20707 0D060C90
	v_mul_f32_e32 v3, v7, v9                                   // 00000001101C: 10061307
	v_mul_f32_e32 v9, v7, v4                                   // 000000011020: 10120907
	v_mul_f32_e32 v4, v7, v10                                  // 000000011024: 10081507
	v_mul_f32_e32 v10, v7, v5                                  // 000000011028: 10140B07
	v_mul_f32_e32 v5, v7, v11                                  // 00000001102C: 100A1707
	v_mul_f32_e32 v11, v7, v6                                  // 000000011030: 10160D07
	v_mul_f32_e32 v6, v7, v12                                  // 000000011034: 100C1907
	v_cmp_lt_i32_e32 vcc_lo, 31, v1                            // 000000011038: 7C82029F
	v_fma_mixhi_f16 v3, v3, s41, 0                             // 00000001103C: CC220003 02005303
	v_fma_mixlo_f16 v3, v13, s41, 0                            // 000000011044: CC210003 0200530D
	v_fma_mixhi_f16 v4, v4, s41, 0                             // 00000001104C: CC220004 02005304
	v_fma_mixlo_f16 v4, v9, s41, 0                             // 000000011054: CC210004 02005309
	v_fma_mixhi_f16 v5, v5, s41, 0                             // 00000001105C: CC220005 02005305
	v_fma_mixlo_f16 v5, v10, s41, 0                            // 000000011064: CC210005 0200530A
	v_fma_mixhi_f16 v6, v6, s41, 0                             // 00000001106C: CC220006 02005306
	v_fma_mixlo_f16 v6, v11, s41, 0                            // 000000011074: CC210006 0200530B
	s_or_b32 s1, vcc_lo, s1                                    // 00000001107C: 8C01016A
	ds_store_b128 v8, v[3:6] offset:10496                      // 000000011080: DB7C2900 00000308
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000011088: 917E017E
	s_cbranch_execnz 65472                                     // 00000001108C: BFA6FFC0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1a90>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000011090: 8C7E007E
	s_mov_b32 s0, 0                                            // 000000011094: BE800080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000011098: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000001109C: 916A007E
	s_cbranch_vccnz 531                                        // 0000000110A0: BFA40213 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x23f0>
	s_mov_b32 s0, exec_lo                                      // 0000000110A4: BE80007E
	v_cmpx_gt_u32_e32 16, v27                                  // 0000000110A8: 7D983690
	s_cbranch_execz 527                                        // 0000000110AC: BFA5020F <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x23ec>
	v_cmp_eq_u32_e32 vcc_lo, 0, v27                            // 0000000110B0: 7C943680
	ds_load_b128 v[48:51], v139 offset:23248                   // 0000000110B4: DBFC5AD0 3000008B
	ds_load_b128 v[52:55], v139 offset:23264                   // 0000000110BC: DBFC5AE0 3400008B
	ds_load_b96 v[13:15], v139 offset:23280                    // 0000000110C4: DBF85AF0 0D00008B
	ds_load_b128 v[9:12], v139 offset:23168                    // 0000000110CC: DBFC5A80 0900008B
	ds_load_b128 v[5:8], v139 offset:23184                     // 0000000110D4: DBFC5A90 0500008B
	ds_load_b128 v[1:4], v139 offset:23200                     // 0000000110DC: DBFC5AA0 0100008B
	ds_load_b64 v[16:17], v139 offset:23216                    // 0000000110E4: D9D85AB0 1000008B
	v_cndmask_b32_e64 v43, 0, 1.0, vcc_lo                      // 0000000110EC: D501002B 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 1, v27                            // 0000000110F4: 7C943681
	ds_load_b128 v[44:47], v139 offset:23232                   // 0000000110F8: DBFC5AC0 2C00008B
	v_cndmask_b32_e64 v42, 0, 1.0, vcc_lo                      // 000000011100: D501002A 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 2, v27                            // 000000011108: 7C943682
	v_cndmask_b32_e64 v41, 0, 1.0, vcc_lo                      // 00000001110C: D5010029 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 3, v27                            // 000000011114: 7C943683
	v_cndmask_b32_e64 v40, 0, 1.0, vcc_lo                      // 000000011118: D5010028 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 4, v27                            // 000000011120: 7C943684
	v_cndmask_b32_e64 v38, 0, 1.0, vcc_lo                      // 000000011124: D5010026 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 5, v27                            // 00000001112C: 7C943685
	v_cndmask_b32_e64 v39, 0, 1.0, vcc_lo                      // 000000011130: D5010027 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 6, v27                            // 000000011138: 7C943686
	v_cndmask_b32_e64 v37, 0, 1.0, vcc_lo                      // 00000001113C: D5010025 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 7, v27                            // 000000011144: 7C943687
	v_cndmask_b32_e64 v36, 0, 1.0, vcc_lo                      // 000000011148: D5010024 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 8, v27                            // 000000011150: 7C943688
	v_cndmask_b32_e64 v34, 0, 1.0, vcc_lo                      // 000000011154: D5010022 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 9, v27                            // 00000001115C: 7C943689
	v_cndmask_b32_e64 v32, 0, 1.0, vcc_lo                      // 000000011160: D5010020 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 10, v27                           // 000000011168: 7C94368A
	v_cndmask_b32_e64 v35, 0, 1.0, vcc_lo                      // 00000001116C: D5010023 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 11, v27                           // 000000011174: 7C94368B
	v_cndmask_b32_e64 v33, 0, 1.0, vcc_lo                      // 000000011178: D5010021 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 12, v27                           // 000000011180: 7C94368C
	v_cndmask_b32_e64 v29, 0, 1.0, vcc_lo                      // 000000011184: D501001D 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 13, v27                           // 00000001118C: 7C94368D
	v_cndmask_b32_e64 v31, 0, 1.0, vcc_lo                      // 000000011190: D501001F 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 14, v27                           // 000000011198: 7C94368E
	v_cndmask_b32_e64 v30, 0, 1.0, vcc_lo                      // 00000001119C: D501001E 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 15, v27                           // 0000000111A4: 7C94368F
	v_cndmask_b32_e64 v28, 0, 1.0, vcc_lo                      // 0000000111A8: D501001C 01A9E480
	s_waitcnt lgkmcnt(5)                                       // 0000000111B0: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000111B4: BF8700B1
	v_fmac_f32_e32 v30, v28, v15                               // 0000000111B8: 563C1F1C
	v_fmac_f32_e32 v33, v28, v55                               // 0000000111BC: 56426F1C
	s_waitcnt lgkmcnt(2)                                       // 0000000111C0: BF89FC27
	v_dual_fmac_f32 v36, v28, v51 :: v_dual_fmac_f32 v33, v30, v4// 0000000111C4: C800671C 2420091E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000111CC: BF870091
	v_dual_fmac_f32 v39, v28, v49 :: v_dual_fmac_f32 v36, v30, v8// 0000000111D0: C800631C 2724111E
	v_dual_fmac_f32 v38, v28, v48 :: v_dual_fmac_f32 v39, v30, v6// 0000000111D8: C800611C 26260D1E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000111E0: BF870091
	v_dual_fmac_f32 v37, v28, v50 :: v_dual_fmac_f32 v38, v30, v5// 0000000111E4: C800651C 25260B1E
	v_dual_fmac_f32 v34, v28, v52 :: v_dual_fmac_f32 v37, v30, v7// 0000000111EC: C800691C 22240F1E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000111F4: BF870091
	v_dual_fmac_f32 v35, v28, v54 :: v_dual_fmac_f32 v34, v30, v1// 0000000111F8: C8006D1C 2322031E
	v_dual_fmac_f32 v32, v28, v53 :: v_dual_fmac_f32 v35, v30, v3// 000000011200: C8006B1C 2022071E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000011208: BF870151
	v_fmac_f32_e32 v32, v30, v2                                // 00000001120C: 5640051E
	ds_load_b128 v[1:4], v139 offset:23040                     // 000000011210: DBFC5A00 0100008B
	s_waitcnt lgkmcnt(1)                                       // 000000011218: BF89FC17
	v_fmac_f32_e32 v40, v28, v47                               // 00000001121C: 56505F1C
	v_fmac_f32_e32 v31, v28, v14                               // 000000011220: 563E1D1C
	v_dual_fmac_f32 v41, v28, v46 :: v_dual_fmac_f32 v40, v30, v12// 000000011224: C8005D1C 2928191E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000001122C: BF870002
	v_fmac_f32_e32 v31, v30, v17                               // 000000011230: 563E231E
	v_fmac_f32_e32 v29, v28, v13                               // 000000011234: 563A1B1C
	ds_load_b128 v[48:51], v139 offset:23104                   // 000000011238: DBFC5A40 3000008B
	ds_load_b128 v[52:55], v139 offset:23120                   // 000000011240: DBFC5A50 3400008B
	ds_load_b128 v[56:59], v139 offset:23136                   // 000000011248: DBFC5A60 3800008B
	ds_load_b32 v13, v139 offset:23152                         // 000000011250: D8D85A70 0D00008B
	v_dual_fmac_f32 v42, v28, v45 :: v_dual_fmac_f32 v41, v30, v11// 000000011258: C8005B1C 2A28171E
	v_fmac_f32_e32 v43, v28, v44                               // 000000011260: 5656591C
	ds_load_b128 v[44:47], v139 offset:24064                   // 000000011264: DBFC5E00 2C00008B
	ds_load_b32 v17, v139 offset:22880                         // 00000001126C: D8D85960 1100008B
	v_fmac_f32_e32 v42, v30, v10                               // 000000011274: 5654151E
	v_fmac_f32_e32 v43, v30, v9                                // 000000011278: 5656131E
	ds_load_b128 v[5:8], v139 offset:23056                     // 00000001127C: DBFC5A10 0500008B
	ds_load_b128 v[9:12], v139 offset:23072                    // 000000011284: DBFC5A20 0900008B
	s_waitcnt lgkmcnt(7)                                       // 00000001128C: BF89FC77
	v_fmac_f32_e32 v43, v31, v48                               // 000000011290: 5656611F
	v_dual_fmac_f32 v40, v31, v51 :: v_dual_fmac_f32 v29, v30, v16// 000000011294: C800671F 281C211E
	v_fmac_f32_e32 v42, v31, v49                               // 00000001129C: 5654631F
	s_waitcnt lgkmcnt(4)                                       // 0000000112A0: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000112A4: BF870002
	v_fmac_f32_e32 v29, v31, v13                               // 0000000112A8: 563A1B1F
	ds_load_b128 v[13:16], v139 offset:22976                   // 0000000112AC: DBFC59C0 0D00008B
	v_fmac_f32_e32 v43, v29, v1                                // 0000000112B4: 5656031D
	v_fmac_f32_e32 v42, v29, v2                                // 0000000112B8: 5654051D
	v_fmac_f32_e32 v38, v31, v52                               // 0000000112BC: 564C691F
	v_fmac_f32_e32 v41, v31, v50                               // 0000000112C0: 5652651F
	v_dual_fmac_f32 v33, v31, v59 :: v_dual_fmac_f32 v40, v29, v4// 0000000112C4: C800771F 2128091D
	s_waitcnt lgkmcnt(2)                                       // 0000000112CC: BF89FC27
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000112D0: BF870193
	v_fmac_f32_e32 v38, v29, v5                                // 0000000112D4: 564C0B1D
	v_dual_fmac_f32 v34, v31, v56 :: v_dual_fmac_f32 v41, v29, v3// 0000000112D8: C800711F 2228071D
	ds_load_b128 v[1:4], v139 offset:22912                     // 0000000112E0: DBFC5980 0100008B
	s_waitcnt lgkmcnt(2)                                       // 0000000112E8: BF89FC27
	v_fmac_f32_e32 v33, v29, v12                               // 0000000112EC: 5642191D
	s_waitcnt lgkmcnt(1)                                       // 0000000112F0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000112F4: BF870001
	v_dual_fmac_f32 v35, v31, v58 :: v_dual_fmac_f32 v40, v33, v16// 0000000112F8: C800751F 23282121
	v_fmac_f32_e32 v42, v33, v14                               // 000000011300: 56541D21
	v_dual_fmac_f32 v37, v31, v54 :: v_dual_fmac_f32 v34, v29, v9// 000000011304: C8006D1F 2522131D
	v_fmac_f32_e32 v36, v31, v55                               // 00000001130C: 56486F1F
	v_fmac_f32_e32 v39, v31, v53                               // 000000011310: 564E6B1F
	ds_load_b128 v[48:51], v139 offset:22992                   // 000000011314: DBFC59D0 3000008B
	ds_load_b96 v[52:54], v139 offset:23008                    // 00000001131C: DBF859E0 3400008B
	v_dual_fmac_f32 v32, v31, v57 :: v_dual_fmac_f32 v37, v29, v7// 000000011324: C800731F 20240F1D
	v_fmac_f32_e32 v36, v29, v8                                // 00000001132C: 5648111D
	v_fmac_f32_e32 v39, v29, v6                                // 000000011330: 564E0D1D
	ds_load_b128 v[5:8], v139 offset:22928                     // 000000011334: DBFC5990 0500008B
	ds_load_b64 v[55:56], v139 offset:22944                    // 00000001133C: D9D859A0 3700008B
	v_fmac_f32_e32 v32, v29, v10                               // 000000011344: 5640151D
	v_fmac_f32_e32 v35, v29, v11                               // 000000011348: 5646171D
	ds_load_b128 v[9:12], v139 offset:22848                    // 00000001134C: DBFC5940 0900008B
	s_waitcnt lgkmcnt(3)                                       // 000000011354: BF89FC37
	v_fmac_f32_e32 v35, v33, v54                               // 000000011358: 56466D21
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001135C: BF870001
	v_fmac_f32_e32 v42, v35, v2                                // 000000011360: 56540523
	v_fmac_f32_e32 v32, v33, v53                               // 000000011364: 56406B21
	v_dual_fmac_f32 v43, v33, v13 :: v_dual_fmac_f32 v40, v35, v4// 000000011368: C8001B21 2B280923
	v_fmac_f32_e32 v39, v33, v49                               // 000000011370: 564E6321
	v_fmac_f32_e32 v38, v33, v48                               // 000000011374: 564C6121
	s_waitcnt lgkmcnt(1)                                       // 000000011378: BF89FC17
	v_fmac_f32_e32 v32, v35, v56                               // 00000001137C: 56407123
	s_delay_alu instid0(VALU_DEP_3)                            // 000000011380: BF870003
	v_dual_fmac_f32 v36, v33, v51 :: v_dual_fmac_f32 v39, v35, v6// 000000011384: C8006721 24260D23
	v_fmac_f32_e32 v37, v33, v50                               // 00000001138C: 564A6521
	ds_load_b128 v[48:51], v139 offset:22800                   // 000000011390: DBFC5910 3000008B
	s_waitcnt lgkmcnt(1)                                       // 000000011398: BF89FC17
	v_dual_fmac_f32 v40, v32, v12 :: v_dual_fmac_f32 v43, v35, v1// 00000001139C: C8001920 282A0323
	v_dual_fmac_f32 v41, v33, v15 :: v_dual_fmac_f32 v38, v35, v5// 0000000113A4: C8001F21 29260B23
	ds_load_b128 v[13:16], v139 offset:22864                   // 0000000113AC: DBFC5950 0D00008B
	v_fmac_f32_e32 v34, v33, v52                               // 0000000113B4: 56446921
	ds_load_b96 v[52:54], v139 offset:22736                    // 0000000113B8: DBF858D0 3400008B
	v_fmac_f32_e32 v41, v35, v3                                // 0000000113C0: 56520723
	ds_load_b128 v[1:4], v139 offset:22784                     // 0000000113C4: DBFC5900 0100008B
	v_fmac_f32_e32 v36, v35, v8                                // 0000000113CC: 56481123
	v_fmac_f32_e32 v37, v35, v7                                // 0000000113D0: 564A0F23
	v_dual_fmac_f32 v34, v35, v55 :: v_dual_fmac_f32 v43, v32, v9// 0000000113D4: C8006F23 222A1320
	ds_load_b128 v[5:8], v139 offset:22720                     // 0000000113DC: DBFC58C0 0500008B
	ds_load_b64 v[55:56], v139 offset:22672                    // 0000000113E4: D9D85890 3700008B
	v_fmac_f32_e32 v42, v32, v10                               // 0000000113EC: 56541520
	v_fmac_f32_e32 v34, v32, v17                               // 0000000113F0: 56442320
	s_waitcnt lgkmcnt(4)                                       // 0000000113F4: BF89FC47
	v_fmac_f32_e32 v39, v32, v14                               // 0000000113F8: 564E1D20
	v_fmac_f32_e32 v37, v32, v15                               // 0000000113FC: 564A1F20
	v_fmac_f32_e32 v36, v32, v16                               // 000000011400: 56482120
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000011404: BF870191
	v_fmac_f32_e32 v36, v34, v51                               // 000000011408: 56486722
	v_fmac_f32_e32 v37, v34, v50                               // 00000001140C: 564A6522
	v_fmac_f32_e32 v39, v34, v49                               // 000000011410: 564E6322
	s_waitcnt lgkmcnt(3)                                       // 000000011414: BF89FC37
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000011418: BF870112
	v_fmac_f32_e32 v37, v36, v54                               // 00000001141C: 564A6D24
	v_fmac_f32_e32 v39, v36, v53                               // 000000011420: 564E6B24
	s_waitcnt lgkmcnt(0)                                       // 000000011424: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000011428: BF870001
	v_fmac_f32_e32 v39, v37, v56                               // 00000001142C: 564E7125
	v_dual_fmac_f32 v41, v32, v11 :: v_dual_fmac_f32 v42, v34, v2// 000000011430: C8001720 292A0522
	ds_load_b128 v[9:12], v139 offset:22656                    // 000000011438: DBFC5880 0900008B
	v_fmac_f32_e32 v38, v32, v13                               // 000000011440: 564C1B20
	v_fmac_f32_e32 v43, v34, v1                                // 000000011444: 56560322
	v_fmac_f32_e32 v41, v34, v3                                // 000000011448: 56520722
	v_fmac_f32_e32 v40, v34, v4                                // 00000001144C: 56500922
	ds_load_b128 v[1:4], v139 offset:22592                     // 000000011450: DBFC5840 0100008B
	ds_load_b32 v17, v139 offset:22608                         // 000000011458: D8D85850 1100008B
	v_fmac_f32_e32 v38, v34, v48                               // 000000011460: 564C6122
	ds_load_b128 v[13:16], v139 offset:22528                   // 000000011464: DBFC5800 0D00008B
	v_fmac_f32_e32 v43, v36, v5                                // 00000001146C: 56560B24
	ds_load_b128 v[48:51], v139 offset:24288                   // 000000011470: DBFC5EE0 3000008B
	s_waitcnt lgkmcnt(4)                                       // 000000011478: BF89FC47
	v_dual_fmac_f32 v43, v37, v9 :: v_dual_fmac_f32 v38, v36, v52// 00000001147C: C8001325 2B266924
	v_fmac_f32_e32 v42, v36, v6                                // 000000011484: 56540D24
	v_fmac_f32_e32 v40, v36, v8                                // 000000011488: 56501124
	ds_load_b64 v[8:9], v139 offset:22400                      // 00000001148C: D9D85780 0800008B
	v_fmac_f32_e32 v38, v37, v55                               // 000000011494: 564C6F25
	ds_load_b128 v[52:55], v139 offset:24304                   // 000000011498: DBFC5EF0 3400008B
	s_waitcnt lgkmcnt(2)                                       // 0000000114A0: BF89FC27
	v_fma_mixlo_f16 v59, v32, v49, 0                           // 0000000114A4: CC21003B 02026320
	v_dual_fmac_f32 v38, v39, v17 :: v_dual_fmac_f32 v41, v36, v7// 0000000114AC: C8002327 26280F24
	v_fmac_f32_e32 v40, v37, v12                               // 0000000114B4: 56501925
	ds_load_b96 v[5:7], v139 offset:22464                      // 0000000114B8: DBF857C0 0500008B
	v_fmac_f32_e32 v42, v37, v10                               // 0000000114C0: 56541525
	ds_load_b32 v10, v139 offset:22336                         // 0000000114C4: D8D85740 0A00008B
	v_dual_fmac_f32 v41, v37, v11 :: v_dual_fmac_f32 v42, v39, v2// 0000000114CC: C8001725 292A0527
	v_fmac_f32_e32 v43, v39, v1                                // 0000000114D4: 56560327
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000114D8: BF870002
	v_fmac_f32_e32 v41, v39, v3                                // 0000000114DC: 56520727
	v_fmac_f32_e32 v40, v39, v4                                // 0000000114E0: 56500927
	ds_load_b128 v[1:4], v139 offset:24256                     // 0000000114E4: DBFC5EC0 0100008B
	v_fmac_f32_e32 v42, v38, v14                               // 0000000114EC: 56541D26
	v_fmac_f32_e32 v43, v38, v13                               // 0000000114F0: 56561B26
	v_fmac_f32_e32 v41, v38, v15                               // 0000000114F4: 56521F26
	v_fmac_f32_e32 v40, v38, v16                               // 0000000114F8: 56502126
	s_waitcnt lgkmcnt(2)                                       // 0000000114FC: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000011500: BF8700A1
	v_fmac_f32_e32 v41, v40, v7                                // 000000011504: 56520F28
	v_fmac_f32_e32 v42, v40, v6                                // 000000011508: 56540D28
	v_fmac_f32_e32 v42, v41, v9                                // 00000001150C: 56541329
	v_fmac_f32_e32 v43, v40, v5                                // 000000011510: 56560B28
	s_waitcnt lgkmcnt(0)                                       // 000000011514: BF89FC07
	v_fma_mixlo_f16 v56, v40, v4, 0                            // 000000011518: CC210038 02020928
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000011520: BF870122
	v_dual_mul_f32 v14, v42, v2 :: v_dual_fmac_f32 v43, v41, v8// 000000011524: C8C0052A 0E2A1129
	v_fma_mixlo_f16 v17, v42, v2, 0                            // 00000001152C: CC210011 0202052A
	v_fmac_f32_e32 v43, v42, v10                               // 000000011534: 5656152A
	ds_load_b128 v[5:8], v139 offset:24272                     // 000000011538: DBFC5ED0 0500008B
	ds_load_b128 v[9:12], v139 offset:24112                    // 000000011540: DBFC5E30 0900008B
	v_fma_mix_f32 v14, v17, -1.0, v14 op_sel_hi:[1,1,0]        // 000000011548: CC20000E 1C39E711
	v_mul_f32_e32 v13, v43, v1                                 // 000000011550: 101A032B
	v_fma_mixlo_f16 v1, v43, v1, 0                             // 000000011554: CC210001 0202032B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000001155C: BF870211
	v_fma_mix_f32 v2, v1, -1.0, v13 op_sel_hi:[1,1,0]          // 000000011560: CC200002 1C35E701
	.long 0x7f1a150e                                           // 000000011568: 7F1A150E
	v_mul_f32_e32 v14, v41, v3                                 // 00000001156C: 101C0729
	v_mul_f32_e32 v62, v30, v54                                // 000000011570: 107C6D1E
	.long 0x7f023911                                           // 000000011574: 7F023911
	v_cvt_f16_f32_e32 v13, v2                                  // 000000011578: 7E1A1502
	v_fma_mixlo_f16 v2, v41, v3, 0                             // 00000001157C: CC210002 02020729
	s_waitcnt lgkmcnt(1)                                       // 000000011584: BF89FC17
	v_dual_mul_f32 v3, v40, v4 :: v_dual_mul_f32 v4, v38, v5   // 000000011588: C8C60928 03040B26
	v_mul_f32_e32 v15, v39, v6                                 // 000000011590: 101E0D27
	v_fma_mixlo_f16 v57, v39, v6, 0                            // 000000011594: CC210039 02020D27
	s_delay_alu instid0(VALU_DEP_3)                            // 00000001159C: BF870003
	v_fma_mix_f32 v16, v56, -1.0, v3 op_sel_hi:[1,1,0]         // 0000000115A0: CC200010 1C0DE738
	v_fma_mixlo_f16 v3, v38, v5, 0                             // 0000000115A8: CC210003 02020B26
	v_fma_mix_f32 v6, v2, -1.0, v14 op_sel_hi:[1,1,0]          // 0000000115B0: CC200006 1C39E702
	v_fma_mixlo_f16 v58, v36, v8, 0                            // 0000000115B8: CC21003A 02021124
	v_fma_mix_f32 v5, v57, -1.0, v15 op_sel_hi:[1,1,0]         // 0000000115C0: CC200005 1C3DE739
	.long 0x7f1c1510                                           // 0000000115C8: 7F1C1510
	v_fma_mix_f32 v4, v3, -1.0, v4 op_sel_hi:[1,1,0]           // 0000000115CC: CC200004 1C11E703
	v_cvt_f16_f32_e32 v14, v6                                  // 0000000115D4: 7E1C1506
	v_mul_f32_e32 v6, v37, v7                                  // 0000000115D8: 100C0F25
	.long 0x7f1e1505                                           // 0000000115DC: 7F1E1505
	v_fma_mixlo_f16 v5, v34, v48, 0                            // 0000000115E0: CC210005 02026122
	v_cvt_f16_f32_e32 v15, v4                                  // 0000000115E8: 7E1E1504
	v_fma_mixlo_f16 v4, v37, v7, 0                             // 0000000115EC: CC210004 02020F25
	v_mul_f32_e32 v7, v36, v8                                  // 0000000115F4: 100E1124
	v_mul_f32_e32 v8, v34, v48                                 // 0000000115F8: 10106122
	v_dual_mul_f32 v48, v32, v49 :: v_dual_mul_f32 v49, v35, v50// 0000000115FC: C8C66320 30306523
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000011604: BF870224
	v_fma_mix_f32 v6, v4, -1.0, v6 op_sel_hi:[1,1,0]           // 000000011608: CC200006 1C19E704
	.long 0x7f043938                                           // 000000011610: 7F043938
	v_fma_mix_f32 v8, v5, -1.0, v8 op_sel_hi:[1,1,0]           // 000000011614: CC200008 1C21E705
	s_delay_alu instid0(VALU_DEP_4)                            // 00000001161C: BF870004
	v_fma_mix_f32 v60, v59, -1.0, v48 op_sel_hi:[1,1,0]        // 000000011620: CC20003C 1CC1E73B
	.long 0x7f0a393b                                           // 000000011628: 7F0A393B
	v_cvt_f16_f32_e32 v16, v6                                  // 00000001162C: 7E201506
	v_fma_mixlo_f16 v6, v35, v50, 0                            // 000000011630: CC210006 02026523
	v_cvt_f16_f32_e32 v48, v8                                  // 000000011638: 7E601508
	v_mul_f32_e32 v8, v33, v51                                 // 00000001163C: 10106721
	v_fma_mix_f32 v7, v58, -1.0, v7 op_sel_hi:[1,1,0]          // 000000011640: CC200007 1C1DE73A
	.long 0x7f60153c                                           // 000000011648: 7F60153C
	v_fma_mixlo_f16 v60, v33, v51, 0                           // 00000001164C: CC21003C 02026721
	v_dual_mul_f32 v50, v29, v52 :: v_dual_mul_f32 v51, v31, v53// 000000011654: C8C6691D 32326B1F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000001165C: BF870004
	.long 0x7f201507                                           // 000000011660: 7F201507
	v_fma_mix_f32 v7, v6, -1.0, v49 op_sel_hi:[1,1,0]          // 000000011664: CC200007 1CC5E706
	v_fma_mixlo_f16 v53, v31, v53, 0                           // 00000001166C: CC210035 02026B1F
	v_fma_mix_f32 v61, v60, -1.0, v8 op_sel_hi:[1,1,0]         // 000000011674: CC20003D 1C21E73C
	v_fma_mixlo_f16 v8, v30, v54, 0                            // 00000001167C: CC210008 02026D1E
	v_mul_f32_e32 v54, v28, v55                                // 000000011684: 106C6F1C
	v_cvt_f16_f32_e32 v49, v7                                  // 000000011688: 7E621507
	v_fma_mixlo_f16 v7, v29, v52, 0                            // 00000001168C: CC210007 0202691D
	v_fma_mix_f32 v51, v53, -1.0, v51 op_sel_hi:[1,1,0]        // 000000011694: CC200033 1CCDE735
	v_fma_mix_f32 v52, v8, -1.0, v62 op_sel_hi:[1,1,0]         // 00000001169C: CC200034 1CF9E708
	v_fma_mixlo_f16 v55, v28, v55, 0                           // 0000000116A4: CC210037 02026F1C
	.long 0x7f62153d                                           // 0000000116AC: 7F62153D
	v_fma_mix_f32 v50, v7, -1.0, v50 op_sel_hi:[1,1,0]         // 0000000116B0: CC200032 1CC9E707
	.long 0x7f0e3935                                           // 0000000116B8: 7F0E3935
	v_mul_u32_u24_e32 v62, 48, v27                             // 0000000116BC: 167C36B0
	v_fma_mix_f32 v61, v55, -1.0, v54 op_sel_hi:[1,1,0]        // 0000000116C0: CC20003D 1CD9E737
	.long 0x7f103937                                           // 0000000116C8: 7F103937
	v_cvt_f16_f32_e32 v50, v50                                 // 0000000116CC: 7E641532
	.long 0x7f641533                                           // 0000000116D0: 7F641533
	v_cvt_f16_f32_e32 v51, v52                                 // 0000000116D4: 7E661534
	ds_load_b128 v[52:55], v139 offset:24080                   // 0000000116D8: DBFC5E10 3400008B
	.long 0x7f0c393c                                           // 0000000116E0: 7F0C393C
	.long 0x7f063939                                           // 0000000116E4: 7F063939
	.long 0x7f08393a                                           // 0000000116E8: 7F08393A
	v_mul_f32_e32 v17, v43, v44                                // 0000000116EC: 1022592B
	v_fma_mixlo_f16 v43, v43, v44, 0                           // 0000000116F0: CC21002B 0202592B
	v_mul_f32_e32 v44, v42, v45                                // 0000000116F8: 10585B2A
	v_fma_mixlo_f16 v42, v42, v45, 0                           // 0000000116FC: CC21002A 02025B2A
	ds_store_b128 v62, v[5:8] offset:19216                     // 000000011704: DB7C4B10 0000053E
	ds_store_b128 v62, v[1:4] offset:19200                     // 00000001170C: DB7C4B00 0000013E
	ds_load_b128 v[1:4], v139 offset:24096                     // 000000011714: DBFC5E20 0100008B
	v_fma_mix_f32 v17, v43, -1.0, v17 op_sel_hi:[1,1,0]        // 00000001171C: CC200011 1C45E72B
	v_mul_f32_e32 v7, v40, v47                                 // 000000011724: 100E5F28
	v_fma_mix_f32 v44, v42, -1.0, v44 op_sel_hi:[1,1,0]        // 000000011728: CC20002C 1CB1E72A
	v_mul_f32_e32 v6, v41, v46                                 // 000000011730: 100C5D29
	.long 0x7f66153d                                           // 000000011734: 7F66153D
	v_cvt_f16_f32_e32 v5, v17                                  // 000000011738: 7E0A1511
	v_fma_mixlo_f16 v17, v40, v47, 0                           // 00000001173C: CC210011 02025F28
	.long 0x7f0a152c                                           // 000000011744: 7F0A152C
	v_fma_mixlo_f16 v44, v41, v46, 0                           // 000000011748: CC21002C 02025D29
	.long 0x7f56392a                                           // 000000011750: 7F56392A
	s_waitcnt lgkmcnt(3)                                       // 000000011754: BF89FC37
	v_mul_f32_e32 v8, v38, v52                                 // 000000011758: 10106926
	v_mul_f32_e32 v40, v39, v53                                // 00000001175C: 10506B27
	v_fma_mixlo_f16 v39, v39, v53, 0                           // 000000011760: CC210027 02026B27
	v_fma_mixlo_f16 v45, v38, v52, 0                           // 000000011768: CC21002D 02026926
	v_fma_mix_f32 v7, v17, -1.0, v7 op_sel_hi:[1,1,0]          // 000000011770: CC200007 1C1DE711
	v_fma_mixlo_f16 v46, v37, v54, 0                           // 000000011778: CC21002E 02026D25
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000011780: BF870214
	v_fma_mix_f32 v38, v39, -1.0, v40 op_sel_hi:[1,1,0]        // 000000011784: CC200026 1CA1E727
	v_fma_mix_f32 v8, v45, -1.0, v8 op_sel_hi:[1,1,0]          // 00000001178C: CC200008 1C21E72D
	v_dual_mul_f32 v40, v37, v54 :: v_dual_mul_f32 v37, v36, v55// 000000011794: C8C66D25 28246F24
	v_fma_mix_f32 v6, v44, -1.0, v6 op_sel_hi:[1,1,0]          // 00000001179C: CC200006 1C19E72C
	v_fma_mixlo_f16 v36, v36, v55, 0                           // 0000000117A4: CC210024 02026F24
	.long 0x7f583911                                           // 0000000117AC: 7F583911
	.long 0x7f5a3927                                           // 0000000117B0: 7F5A3927
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000117B4: BF870004
	v_cvt_f16_f32_e32 v6, v6                                   // 0000000117B8: 7E0C1506
	.long 0x7f0c1507                                           // 0000000117BC: 7F0C1507
	v_cvt_f16_f32_e32 v7, v8                                   // 0000000117C0: 7E0E1508
	.long 0x7f0e1526                                           // 0000000117C4: 7F0E1526
	v_fma_mix_f32 v8, v46, -1.0, v40 op_sel_hi:[1,1,0]         // 0000000117C8: CC200008 1CA1E72E
	s_waitcnt lgkmcnt(0)                                       // 0000000117D0: BF89FC07
	v_mul_f32_e32 v38, v34, v1                                 // 0000000117D4: 104C0322
	v_fma_mixlo_f16 v1, v34, v1, 0                             // 0000000117D8: CC210001 02020322
	v_mul_f32_e32 v34, v32, v2                                 // 0000000117E0: 10440520
	v_fma_mixlo_f16 v40, v32, v2, 0                            // 0000000117E4: CC210028 02020520
	v_fma_mix_f32 v2, v36, -1.0, v37 op_sel_hi:[1,1,0]         // 0000000117EC: CC200002 1C95E724
	v_cvt_f16_f32_e32 v8, v8                                   // 0000000117F4: 7E101508
	v_mul_f32_e32 v32, v35, v3                                 // 0000000117F8: 10400723
	v_fma_mix_f32 v37, v1, -1.0, v38 op_sel_hi:[1,1,0]         // 0000000117FC: CC200025 1C99E701
	v_fma_mix_f32 v34, v40, -1.0, v34 op_sel_hi:[1,1,0]        // 000000011804: CC200022 1C89E728
	.long 0x7f101502                                           // 00000001180C: 7F101502
	v_fma_mixlo_f16 v2, v35, v3, 0                             // 000000011810: CC210002 02020723
	v_mul_f32_e32 v35, v31, v10                                // 000000011818: 1046151F
	v_fma_mixlo_f16 v10, v31, v10, 0                           // 00000001181C: CC21000A 0202151F
	.long 0x7f023928                                           // 000000011824: 7F023928
	.long 0x7f5c3924                                           // 000000011828: 7F5C3924
	v_fma_mix_f32 v3, v2, -1.0, v32 op_sel_hi:[1,1,0]          // 00000001182C: CC200003 1C81E702
	v_cvt_f16_f32_e32 v32, v37                                 // 000000011834: 7E401525
	.long 0x7f401522                                           // 000000011838: 7F401522
	v_mul_f32_e32 v34, v33, v4                                 // 00000001183C: 10440921
	v_fma_mixlo_f16 v37, v33, v4, 0                            // 000000011840: CC210025 02020921
	v_cvt_f16_f32_e32 v33, v3                                  // 000000011848: 7E421503
	v_mul_f32_e32 v4, v29, v9                                  // 00000001184C: 1008131D
	v_fma_mixlo_f16 v3, v29, v9, 0                             // 000000011850: CC210003 0202131D
	v_fma_mix_f32 v29, v10, -1.0, v35 op_sel_hi:[1,1,0]        // 000000011858: CC20001D 1C8DE70A
	v_fma_mix_f32 v31, v37, -1.0, v34 op_sel_hi:[1,1,0]        // 000000011860: CC20001F 1C89E725
	v_mul_f32_e32 v34, v30, v11                                // 000000011868: 1044171E
	.long 0x7f043925                                           // 00000001186C: 7F043925
	v_fma_mix_f32 v9, v3, -1.0, v4 op_sel_hi:[1,1,0]           // 000000011870: CC200009 1C11E703
	v_fma_mixlo_f16 v4, v30, v11, 0                            // 000000011878: CC210004 0202171E
	v_mul_f32_e32 v30, v28, v12                                // 000000011880: 103C191C
	v_fma_mixlo_f16 v12, v28, v12, 0                           // 000000011884: CC21000C 0202191C
	.long 0x7f06390a                                           // 00000001188C: 7F06390A
	.long 0x7f42151f                                           // 000000011890: 7F42151F
	v_fma_mix_f32 v11, v4, -1.0, v34 op_sel_hi:[1,1,0]         // 000000011894: CC20000B 1C89E704
	v_cvt_f16_f32_e32 v34, v9                                  // 00000001189C: 7E441509
	v_fma_mix_f32 v9, v12, -1.0, v30 op_sel_hi:[1,1,0]         // 0000000118A0: CC200009 1C79E70C
	.long 0x7f08390c                                           // 0000000118A8: 7F08390C
	.long 0x7f44151d                                           // 0000000118AC: 7F44151D
	v_cvt_f16_f32_e32 v35, v11                                 // 0000000118B0: 7E46150B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000118B4: BF870004
	.long 0x7f461509                                           // 0000000118B8: 7F461509
	ds_store_b128 v62, v[48:51] offset:19984                   // 0000000118BC: DB7C4E10 0000303E
	ds_store_b128 v62, v[13:16] offset:19968                   // 0000000118C4: DB7C4E00 00000D3E
	ds_store_b128 v62, v[1:4] offset:20752                     // 0000000118CC: DB7C5110 0000013E
	ds_store_b128 v62, v[43:46] offset:20736                   // 0000000118D4: DB7C5100 00002B3E
	ds_store_b128 v62, v[32:35] offset:21520                   // 0000000118DC: DB7C5410 0000203E
	ds_store_b128 v62, v[5:8] offset:21504                     // 0000000118E4: DB7C5400 0000053E
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000118EC: 8C7E007E
	v_cmp_eq_u32_e32 vcc_lo, 0, v18                            // 0000000118F0: 7C942480
	v_mov_b32_e32 v3, 0                                        // 0000000118F4: 7E060280
	v_dual_mov_b32 v7, 0 :: v_dual_lshlrev_b32 v158, 1, v155   // 0000000118F8: CA220080 079F3681
	s_waitcnt lgkmcnt(0)                                       // 000000011900: BF89FC07
	s_barrier                                                  // 000000011904: BFBD0000
	v_dual_cndmask_b32 v9, 0x7060302, v145 :: v_dual_mov_b32 v10, 0// 000000011908: CA5122FF 090A0080 07060302
	s_waitcnt vmcnt(6)                                         // 000000011914: BF891BF7
	v_mov_b32_dpp v3, v25 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000011918: 7E0602FA FF00B119
	v_lshrrev_b32_e32 v157, 4, v27                             // 000000011920: 333A3684
	s_cmp_lt_i32 s44, s29                                      // 000000011924: BF041D2C
	v_mul_u32_u24_e32 v159, 48, v156                           // 000000011928: 173F38B0
	s_waitcnt vmcnt(3)                                         // 00000001192C: BF890FF7
	v_mov_b32_dpp v10, v22 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000011930: 7E1402FA FF00B116
	v_perm_b32 v3, v25, v3, v9                                 // 000000011938: D6440003 04260719
	v_mov_b32_e32 v1, 0                                        // 000000011940: 7E020280
	v_cmp_eq_u32_e32 vcc_lo, 0, v157                           // 000000011944: 7C953A80
	s_cselect_b32 s0, -1, 0                                    // 000000011948: 980080C1
	v_perm_b32 v22, v22, v10, v9                               // 00000001194C: D6440016 04261516
	v_and_b32_e32 v4, 0xffff0000, v3                           // 000000011954: 360806FF FFFF0000
	v_mov_b32_dpp v1, v26 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000001195C: 7E0202FA FF00B11A
	v_mov_b32_e32 v10, 0                                       // 000000011964: 7E140280
	v_mov_b32_dpp v7, v23 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000011968: 7E0E02FA FF00B117
	s_or_b32 s1, s44, 1                                        // 000000011970: 8C01812C
	ds_load_b128 v[37:40], v159 offset:19984                   // 000000011974: DBFC4E10 2500009F
	ds_load_b128 v[33:36], v159 offset:19968                   // 00000001197C: DBFC4E00 2100009F
	v_perm_b32 v1, v26, v1, v9                                 // 000000011984: D6440001 0426031A
	s_waitcnt vmcnt(2)                                         // 00000001198C: BF890BF7
	v_mov_b32_dpp v10, v21 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000011990: 7E1402FA FF00B115
	v_mov_b32_e32 v5, 0                                        // 000000011998: 7E0A0280
	v_perm_b32 v7, v23, v7, v9                                 // 00000001199C: D6440007 04260F17
	v_and_b32_e32 v23, 0xffff0000, v22                         // 0000000119A4: 362E2CFF FFFF0000
	v_and_b32_e32 v2, 0xffff0000, v1                           // 0000000119AC: 360402FF FFFF0000
	v_lshlrev_b32_e32 v1, 16, v1                               // 0000000119B4: 30020290
	v_mov_b32_dpp v5, v24 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 0000000119B8: 7E0A02FA FF00B118
	s_cmp_lt_i32 s1, s29                                       // 0000000119C0: BF041D01
	v_and_b32_e32 v8, 0xffff0000, v7                           // 0000000119C4: 36100EFF FFFF0000
	s_cselect_b32 s1, -1, 0                                    // 0000000119CC: 980180C1
	v_cvt_f16_f32_e32 v1, v1                                   // 0000000119D0: 7E021501
	v_perm_b32 v5, v24, v5, v9                                 // 0000000119D4: D6440005 04260B18
	v_perm_b32 v24, v21, v10, v9                               // 0000000119DC: D6440018 04261515
	v_mov_b32_e32 v10, 0                                       // 0000000119E4: 7E140280
	s_or_b32 s45, s44, 2                                       // 0000000119E8: 8C2D822C
	v_mul_u32_u24_e32 v160, 0x110, v156                        // 0000000119EC: 174138FF 00000110
	s_cmp_lt_i32 s45, s29                                      // 0000000119F4: BF041D2D
	v_and_b32_e32 v25, 0xffff0000, v24                         // 0000000119F8: 363230FF FFFF0000
	s_waitcnt vmcnt(1)                                         // 000000011A00: BF8907F7
	v_mov_b32_dpp v10, v20 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000011A04: 7E1402FA FF00B114
	s_cselect_b32 s45, -1, 0                                   // 000000011A0C: 982D80C1
	s_or_b32 s46, s44, 3                                       // 000000011A10: 8C2E832C
	v_and_b32_e32 v6, 0xffff0000, v5                           // 000000011A14: 360C0AFF FFFF0000
	s_cmp_lt_i32 s46, s29                                      // 000000011A1C: BF041D2E
	v_perm_b32 v26, v20, v10, v9                               // 000000011A20: D644001A 04261514
	v_mov_b32_e32 v10, 0                                       // 000000011A28: 7E140280
	s_cselect_b32 s46, -1, 0                                   // 000000011A2C: 982E80C1
	s_or_b32 s47, s44, 4                                       // 000000011A30: 8C2F842C
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000011A34: BF870009
	s_cmp_lt_i32 s47, s29                                      // 000000011A38: BF041D2F
	s_waitcnt vmcnt(0)                                         // 000000011A3C: BF8903F7
	v_mov_b32_dpp v10, v19 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000011A40: 7E1402FA FF00B113
	s_cselect_b32 s47, -1, 0                                   // 000000011A48: 982F80C1
	s_or_b32 s48, s44, 5                                       // 000000011A4C: 8C30852C
	v_and_b32_e32 v27, 0xffff0000, v26                         // 000000011A50: 363634FF FFFF0000
	s_cmp_lt_i32 s48, s29                                      // 000000011A58: BF041D30
	v_perm_b32 v28, v19, v10, v9                               // 000000011A5C: D644001C 04261513
	ds_load_u16 v9, v158 offset:6416                           // 000000011A64: D8F01910 0900009E
	ds_load_u16 v10, v158 offset:6144                          // 000000011A6C: D8F01800 0A00009E
	s_cselect_b32 s48, -1, 0                                   // 000000011A74: 983080C1
	s_or_b32 s49, s44, 6                                       // 000000011A78: 8C31862C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000011A7C: BF8704C9
	s_cmp_lt_i32 s49, s29                                      // 000000011A80: BF041D31
	v_and_b32_e32 v29, 0xffff0000, v28                         // 000000011A84: 363A38FF FFFF0000
	s_cselect_b32 s49, -1, 0                                   // 000000011A8C: 983180C1
	s_or_b32 s50, s44, 7                                       // 000000011A90: 8C32872C
	s_cmp_lt_i32 s50, s29                                      // 000000011A94: BF041D32
	s_cselect_b32 s50, -1, 0                                   // 000000011A98: 983280C1
	s_or_b32 s51, s44, 8                                       // 000000011A9C: 8C33882C
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000011AA0: BF870009
	s_cmp_lt_i32 s51, s29                                      // 000000011AA4: BF041D33
	s_cselect_b32 s51, -1, 0                                   // 000000011AA8: 983380C1
	s_or_b32 s52, s44, 9                                       // 000000011AAC: 8C34892C
	s_waitcnt lgkmcnt(1)                                       // 000000011AB0: BF89FC17
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000011AB4: 30121290
	s_waitcnt lgkmcnt(0)                                       // 000000011AB8: BF89FC07
	v_lshlrev_b32_e32 v10, 16, v10                             // 000000011ABC: 30141490
	s_cmp_lt_i32 s52, s29                                      // 000000011AC0: BF041D34
	s_cselect_b32 s52, -1, 0                                   // 000000011AC4: 983480C1
	.long 0x7f121509                                           // 000000011AC8: 7F121509
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000011ACC: BF8704C2
	v_cvt_f16_f32_e32 v9, v10                                  // 000000011AD0: 7E12150A
	ds_load_u16 v10, v158 offset:6960                          // 000000011AD4: D8F01B30 0A00009E
	ds_load_u16 v11, v158 offset:6688                          // 000000011ADC: D8F01A20 0B00009E
	s_or_b32 s53, s44, 10                                      // 000000011AE4: 8C358A2C
	s_cmp_lt_i32 s53, s29                                      // 000000011AE8: BF041D35
	s_cselect_b32 s53, -1, 0                                   // 000000011AEC: 983580C1
	s_or_b32 s54, s44, 11                                      // 000000011AF0: 8C368B2C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000011AF4: BF8704B9
	s_cmp_lt_i32 s54, s29                                      // 000000011AF8: BF041D36
	s_cselect_b32 s54, -1, 0                                   // 000000011AFC: 983680C1
	s_or_b32 s55, s44, 12                                      // 000000011B00: 8C378C2C
	s_cmp_lt_i32 s55, s29                                      // 000000011B04: BF041D37
	s_cselect_b32 s55, -1, 0                                   // 000000011B08: 983780C1
	s_or_b32 s56, s44, 13                                      // 000000011B0C: 8C388D2C
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000011B10: BF870009
	s_cmp_lt_i32 s56, s29                                      // 000000011B14: BF041D38
	s_waitcnt lgkmcnt(1)                                       // 000000011B18: BF89FC17
	v_lshlrev_b32_e32 v10, 16, v10                             // 000000011B1C: 30141490
	s_waitcnt lgkmcnt(0)                                       // 000000011B20: BF89FC07
	v_lshlrev_b32_e32 v11, 16, v11                             // 000000011B24: 30161690
	s_cselect_b32 s56, -1, 0                                   // 000000011B28: 983880C1
	s_or_b32 s57, s44, 14                                      // 000000011B2C: 8C398E2C
	.long 0x7f14150a                                           // 000000011B30: 7F14150A
	s_delay_alu instid0(VALU_DEP_2)                            // 000000011B34: BF870002
	v_cvt_f16_f32_e32 v10, v11                                 // 000000011B38: 7E14150B
	ds_load_u16 v11, v158 offset:7504                          // 000000011B3C: D8F01D50 0B00009E
	ds_load_u16 v12, v158 offset:7232                          // 000000011B44: D8F01C40 0C00009E
	s_cmp_lt_i32 s57, s29                                      // 000000011B4C: BF041D39
	s_cselect_b32 s57, -1, 0                                   // 000000011B50: 983980C1
	s_or_b32 s58, s44, 15                                      // 000000011B54: 8C3A8F2C
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000011B58: BF870009
	s_cmp_lt_i32 s58, s29                                      // 000000011B5C: BF041D3A
	s_cselect_b32 s58, -1, 0                                   // 000000011B60: 983A80C1
	s_waitcnt lgkmcnt(1)                                       // 000000011B64: BF89FC17
	v_lshlrev_b32_e32 v11, 16, v11                             // 000000011B68: 30161690
	s_waitcnt lgkmcnt(0)                                       // 000000011B6C: BF89FC07
	v_lshlrev_b32_e32 v12, 16, v12                             // 000000011B70: 30181890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000011B74: BF870112
	.long 0x7f16150b                                           // 000000011B78: 7F16150B
	v_cvt_f16_f32_e32 v11, v12                                 // 000000011B7C: 7E16150C
	ds_load_u16 v12, v158 offset:8048                          // 000000011B80: D8F01F70 0C00009E
	ds_load_u16 v13, v158 offset:7776                          // 000000011B88: D8F01E60 0D00009E
	s_waitcnt lgkmcnt(1)                                       // 000000011B90: BF89FC17
	v_lshlrev_b32_e32 v12, 16, v12                             // 000000011B94: 30181890
	s_waitcnt lgkmcnt(0)                                       // 000000011B98: BF89FC07
	v_lshlrev_b32_e32 v13, 16, v13                             // 000000011B9C: 301A1A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000011BA0: BF870112
	.long 0x7f18150c                                           // 000000011BA4: 7F18150C
	v_cvt_f16_f32_e32 v12, v13                                 // 000000011BA8: 7E18150D
	ds_load_u16 v13, v158 offset:8592                          // 000000011BAC: D8F02190 0D00009E
	ds_load_u16 v14, v158 offset:8320                          // 000000011BB4: D8F02080 0E00009E
	s_waitcnt lgkmcnt(1)                                       // 000000011BBC: BF89FC17
	v_lshlrev_b32_e32 v13, 16, v13                             // 000000011BC0: 301A1A90
	s_waitcnt lgkmcnt(0)                                       // 000000011BC4: BF89FC07
	v_lshlrev_b32_e32 v14, 16, v14                             // 000000011BC8: 301C1C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000011BCC: BF870112
	.long 0x7f1a150d                                           // 000000011BD0: 7F1A150D
	v_cvt_f16_f32_e32 v13, v14                                 // 000000011BD4: 7E1A150E
	ds_load_u16 v14, v158 offset:9136                          // 000000011BD8: D8F023B0 0E00009E
	ds_load_u16 v15, v158 offset:8864                          // 000000011BE0: D8F022A0 0F00009E
	s_waitcnt lgkmcnt(1)                                       // 000000011BE8: BF89FC17
	v_lshlrev_b32_e32 v14, 16, v14                             // 000000011BEC: 301C1C90
	s_waitcnt lgkmcnt(0)                                       // 000000011BF0: BF89FC07
	v_lshlrev_b32_e32 v15, 16, v15                             // 000000011BF4: 301E1E90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000011BF8: BF870112
	.long 0x7f1c150e                                           // 000000011BFC: 7F1C150E
	v_cvt_f16_f32_e32 v14, v15                                 // 000000011C00: 7E1C150F
	ds_load_u16 v15, v158 offset:9680                          // 000000011C04: D8F025D0 0F00009E
	ds_load_u16 v16, v158 offset:9408                          // 000000011C0C: D8F024C0 1000009E
	s_waitcnt lgkmcnt(1)                                       // 000000011C14: BF89FC17
	v_lshlrev_b32_e32 v15, 16, v15                             // 000000011C18: 301E1E90
	s_waitcnt lgkmcnt(0)                                       // 000000011C1C: BF89FC07
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000011C20: 30202090
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000011C24: BF870112
	.long 0x7f1e150f                                           // 000000011C28: 7F1E150F
	v_cvt_f16_f32_e32 v15, v16                                 // 000000011C2C: 7E1E1510
	ds_load_u16 v16, v158 offset:10224                         // 000000011C30: D8F027F0 1000009E
	ds_load_u16 v17, v158 offset:9952                          // 000000011C38: D8F026E0 1100009E
	s_waitcnt lgkmcnt(1)                                       // 000000011C40: BF89FC17
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000011C44: 30202090
	s_waitcnt lgkmcnt(0)                                       // 000000011C48: BF89FC07
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000011C4C: 30222290
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000011C50: BF870112
	.long 0x7f201510                                           // 000000011C54: 7F201510
	v_cvt_f16_f32_e32 v16, v17                                 // 000000011C58: 7E201511
	v_cndmask_b16 v17, 0, v1, s0                               // 000000011C5C: D65D0011 00020280
	v_cvt_f16_f32_e32 v1, v2                                   // 000000011C64: 7E021502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000011C68: BF8700A1
	v_cndmask_b16 v17, 0, v1, s1                               // 000000011C6C: D65D4011 00060280
	v_lshlrev_b32_e32 v1, 16, v3                               // 000000011C74: 30020690
	v_cvt_f16_f32_e32 v1, v1                                   // 000000011C78: 7E021501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000011C7C: BF8700A1
	v_cndmask_b16 v18, 0, v1, s45                              // 000000011C80: D65D0012 00B60280
	v_cvt_f16_f32_e32 v1, v4                                   // 000000011C88: 7E021504
	v_cndmask_b16 v18, 0, v1, s46                              // 000000011C8C: D65D4012 00BA0280
	v_lshlrev_b32_e32 v1, 16, v5                               // 000000011C94: 30020A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000011C98: BF870091
	v_cvt_f16_f32_e32 v1, v1                                   // 000000011C9C: 7E021501
	v_cndmask_b16 v19, 0, v1, s47                              // 000000011CA0: D65D0013 00BE0280
	v_cvt_f16_f32_e32 v1, v6                                   // 000000011CA8: 7E021506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000011CAC: BF8700A1
	v_cndmask_b16 v19, 0, v1, s48                              // 000000011CB0: D65D4013 00C20280
	v_lshlrev_b32_e32 v1, 16, v7                               // 000000011CB8: 30020E90
	v_cvt_f16_f32_e32 v1, v1                                   // 000000011CBC: 7E021501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000011CC0: BF8700A1
	v_cndmask_b16 v20, 0, v1, s49                              // 000000011CC4: D65D0014 00C60280
	v_cvt_f16_f32_e32 v1, v8                                   // 000000011CCC: 7E021508
	v_cndmask_b16 v20, 0, v1, s50                              // 000000011CD0: D65D4014 00CA0280
	v_lshlrev_b32_e32 v1, 16, v22                              // 000000011CD8: 30022C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000011CDC: BF870091
	v_cvt_f16_f32_e32 v1, v1                                   // 000000011CE0: 7E021501
	v_cndmask_b16 v21, 0, v1, s51                              // 000000011CE4: D65D0015 00CE0280
	v_cvt_f16_f32_e32 v1, v23                                  // 000000011CEC: 7E021517
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000011CF0: BF8700A1
	v_cndmask_b16 v21, 0, v1, s52                              // 000000011CF4: D65D4015 00D20280
	v_lshlrev_b32_e32 v1, 16, v24                              // 000000011CFC: 30023090
	v_cvt_f16_f32_e32 v1, v1                                   // 000000011D00: 7E021501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000011D04: BF8700A1
	v_cndmask_b16 v22, 0, v1, s53                              // 000000011D08: D65D0016 00D60280
	v_cvt_f16_f32_e32 v1, v25                                  // 000000011D10: 7E021519
	v_cndmask_b16 v22, 0, v1, s54                              // 000000011D14: D65D4016 00DA0280
	v_lshlrev_b32_e32 v1, 16, v26                              // 000000011D1C: 30023490
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000011D20: BF870091
	v_cvt_f16_f32_e32 v1, v1                                   // 000000011D24: 7E021501
	v_cndmask_b16 v23, 0, v1, s55                              // 000000011D28: D65D0017 00DE0280
	v_cvt_f16_f32_e32 v1, v27                                  // 000000011D30: 7E02151B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000011D34: BF8700A1
	v_cndmask_b16 v23, 0, v1, s56                              // 000000011D38: D65D4017 00E20280
	v_lshlrev_b32_e32 v1, 16, v28                              // 000000011D40: 30023890
	v_cvt_f16_f32_e32 v1, v1                                   // 000000011D44: 7E021501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000011D48: BF8700A1
	v_cndmask_b16 v24, 0, v1, s57                              // 000000011D4C: D65D0018 00E60280
	v_cvt_f16_f32_e32 v1, v29                                  // 000000011D54: 7E02151D
	v_cndmask_b16 v24, 0, v1, s58                              // 000000011D58: D65D4018 00EA0280
	v_dual_mov_b32 v1, s20 :: v_dual_mov_b32 v2, s21           // 000000011D60: CA100014 01020015
	v_dual_mov_b32 v3, s22 :: v_dual_mov_b32 v4, s23           // 000000011D68: CA100016 03040017
	v_dual_mov_b32 v5, s24 :: v_dual_mov_b32 v6, s25           // 000000011D70: CA100018 05060019
	v_dual_mov_b32 v7, s26 :: v_dual_mov_b32 v8, s27           // 000000011D78: CA10001A 0708001B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000011D80: BF870001
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[9:16], v[1:8]// 000000011D84: CC404019 1C061321
	ds_load_b128 v[33:36], v159 offset:19200                   // 000000011D8C: DBFC4B00 2100009F
	ds_load_b128 v[37:40], v159 offset:19216                   // 000000011D94: DBFC4B10 2500009F
	s_waitcnt lgkmcnt(0)                                       // 000000011D9C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[9:16], v[25:32]// 000000011DA0: CC404019 1C661321
	ds_load_b128 v[37:40], v159 offset:21520                   // 000000011DA8: DBFC5410 2500009F
	ds_load_b128 v[33:36], v159 offset:21504                   // 000000011DB0: DBFC5400 2100009F
	s_waitcnt lgkmcnt(0)                                       // 000000011DB8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[33:40], v[17:24], v[1:8]// 000000011DBC: CC404009 1C062321
	ds_load_b128 v[37:40], v159 offset:20752                   // 000000011DC4: DBFC5110 2500009F
	ds_load_b128 v[33:36], v159 offset:20736                   // 000000011DCC: DBFC5100 2100009F
	s_waitcnt lgkmcnt(0)                                       // 000000011DD4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[33:40], v[17:24], v[9:16]// 000000011DD8: CC404009 1C262321
	v_mad_u32_u24 v18, 0x110, v157, v158                       // 000000011DE0: D60B0012 067B3AFF 00000110
	v_cvt_f16_f32_e32 v17, v25                                 // 000000011DEC: 7E221519
	v_mul_f32_e32 v25, 0x3b800000, v154                        // 000000011DF0: 103334FF 3B800000
	ds_store_b16 v18, v17 offset:14848                         // 000000011DF8: D87C3A00 00001112
	v_cvt_f16_f32_e32 v17, v26                                 // 000000011E00: 7E22151A
	v_mul_f32_e32 v26, 0x3b800000, v129                        // 000000011E04: 103502FF 3B800000
	ds_store_b16 v18, v17 offset:15392                         // 000000011E0C: D87C3C20 00001112
	v_cvt_f16_f32_e32 v17, v27                                 // 000000011E14: 7E22151B
	v_mul_f32_e32 v27, 0x3b800000, v130                        // 000000011E18: 103704FF 3B800000
	ds_store_b16 v18, v17 offset:15936                         // 000000011E20: D87C3E40 00001112
	v_cvt_f16_f32_e32 v17, v28                                 // 000000011E28: 7E22151C
	v_mul_f32_e32 v28, 0x3b800000, v131                        // 000000011E2C: 103906FF 3B800000
	ds_store_b16 v18, v17 offset:16480                         // 000000011E34: D87C4060 00001112
	v_cvt_f16_f32_e32 v17, v29                                 // 000000011E3C: 7E22151D
	v_mul_f32_e32 v29, 0x3b800000, v132                        // 000000011E40: 103B08FF 3B800000
	ds_store_b16 v18, v17 offset:17024                         // 000000011E48: D87C4280 00001112
	v_cvt_f16_f32_e32 v17, v30                                 // 000000011E50: 7E22151E
	v_mul_f32_e32 v30, 0x3b800000, v133                        // 000000011E54: 103D0AFF 3B800000
	ds_store_b16 v18, v17 offset:17568                         // 000000011E5C: D87C44A0 00001112
	v_cvt_f16_f32_e32 v17, v31                                 // 000000011E64: 7E22151F
	v_mul_f32_e32 v31, 0x3b800000, v134                        // 000000011E68: 103F0CFF 3B800000
	ds_store_b16 v18, v17 offset:18112                         // 000000011E70: D87C46C0 00001112
	v_cvt_f16_f32_e32 v17, v32                                 // 000000011E78: 7E221520
	v_mul_f32_e32 v32, 0x3b800000, v135                        // 000000011E7C: 10410EFF 3B800000
	ds_store_b16 v18, v17 offset:18656                         // 000000011E84: D87C48E0 00001112
	v_mov_b32_e32 v49, v32                                     // 000000011E8C: 7E620320
	s_waitcnt lgkmcnt(0)                                       // 000000011E90: BF89FC07
	s_barrier                                                  // 000000011E94: BFBD0000
	ds_load_b128 v[21:24], v160 offset:14864                   // 000000011E98: DBFC3A10 150000A0
	ds_load_b128 v[17:20], v160 offset:14848                   // 000000011EA0: DBFC3A00 110000A0
	ds_load_b128 v[41:44], v160 offset:10496                   // 000000011EA8: DBFC2900 290000A0
	ds_load_b128 v[45:48], v160 offset:10512                   // 000000011EB0: DBFC2910 2D0000A0
	ds_load_b128 v[33:36], v160 offset:10528                   // 000000011EB8: DBFC2920 210000A0
	ds_load_b128 v[37:40], v160 offset:10544                   // 000000011EC0: DBFC2930 250000A0
	v_permlanex16_b32 v49, v49, s42, 0xfedcba98                // 000000011EC8: D65C0031 03FC5531 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000011ED4: BF870121
	v_cndmask_b32_e32 v50, v49, v32, vcc_lo                    // 000000011ED8: 02644131
	v_cndmask_b32_e32 v32, v32, v49, vcc_lo                    // 000000011EDC: 02406320
	v_fma_mixlo_f16 v49, v50, s41, 0                           // 000000011EE0: CC210031 02005332
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000011EE8: BF870112
	v_fma_mixlo_f16 v64, v32, s41, 0                           // 000000011EEC: CC210040 02005320
	v_fma_mixlo_f16 v57, v50, s41, -v49 op_sel_hi:[0,0,1]      // 000000011EF4: CC214039 84C45332
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000011EFC: BF870132
	v_fma_mixhi_f16 v57, v32, s41, -v64 op_sel_hi:[0,0,1]      // 000000011F00: CC224039 85005320
	v_mov_b32_e32 v32, v31                                     // 000000011F08: 7E40031F
	.long 0x7f623940                                           // 000000011F0C: 7F623940
	v_permlanex16_b32 v32, v32, s42, 0xfedcba98                // 000000011F10: D65C0020 03FC5520 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000011F1C: BF870121
	v_cndmask_b32_e32 v51, v32, v31, vcc_lo                    // 000000011F20: 02663F20
	v_cndmask_b32_e32 v31, v31, v32, vcc_lo                    // 000000011F24: 023E411F
	v_fma_mixlo_f16 v50, v51, s41, 0                           // 000000011F28: CC210032 02005333
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000011F30: BF870112
	v_fma_mixlo_f16 v32, v31, s41, 0                           // 000000011F34: CC210020 0200531F
	v_fma_mixlo_f16 v58, v51, s41, -v50 op_sel_hi:[0,0,1]      // 000000011F3C: CC21403A 84C85333
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000011F44: BF870132
	v_fma_mixhi_f16 v58, v31, s41, -v32 op_sel_hi:[0,0,1]      // 000000011F48: CC22403A 8480531F
	v_mov_b32_e32 v31, v30                                     // 000000011F50: 7E3E031E
	.long 0x7f643920                                           // 000000011F54: 7F643920
	v_permlanex16_b32 v31, v31, s42, 0xfedcba98                // 000000011F58: D65C001F 03FC551F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000011F64: BF870121
	v_cndmask_b32_e32 v52, v31, v30, vcc_lo                    // 000000011F68: 02683D1F
	v_cndmask_b32_e32 v30, v30, v31, vcc_lo                    // 000000011F6C: 023C3F1E
	v_fma_mixlo_f16 v51, v52, s41, 0                           // 000000011F70: CC210033 02005334
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000011F78: BF870112
	v_fma_mixlo_f16 v31, v30, s41, 0                           // 000000011F7C: CC21001F 0200531E
	v_fma_mixlo_f16 v59, v52, s41, -v51 op_sel_hi:[0,0,1]      // 000000011F84: CC21403B 84CC5334
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000011F8C: BF870132
	v_fma_mixhi_f16 v59, v30, s41, -v31 op_sel_hi:[0,0,1]      // 000000011F90: CC22403B 847C531E
	v_mov_b32_e32 v30, v29                                     // 000000011F98: 7E3C031D
	.long 0x7f66391f                                           // 000000011F9C: 7F66391F
	v_permlanex16_b32 v30, v30, s42, 0xfedcba98                // 000000011FA0: D65C001E 03FC551E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000011FAC: BF870121
	v_cndmask_b32_e32 v53, v30, v29, vcc_lo                    // 000000011FB0: 026A3B1E
	v_cndmask_b32_e32 v29, v29, v30, vcc_lo                    // 000000011FB4: 023A3D1D
	v_fma_mixlo_f16 v52, v53, s41, 0                           // 000000011FB8: CC210034 02005335
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000011FC0: BF870112
	v_fma_mixlo_f16 v30, v29, s41, 0                           // 000000011FC4: CC21001E 0200531D
	v_fma_mixlo_f16 v60, v53, s41, -v52 op_sel_hi:[0,0,1]      // 000000011FCC: CC21403C 84D05335
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000011FD4: BF870132
	v_fma_mixhi_f16 v60, v29, s41, -v30 op_sel_hi:[0,0,1]      // 000000011FD8: CC22403C 8478531D
	v_mov_b32_e32 v29, v28                                     // 000000011FE0: 7E3A031C
	.long 0x7f68391e                                           // 000000011FE4: 7F68391E
	v_permlanex16_b32 v29, v29, s42, 0xfedcba98                // 000000011FE8: D65C001D 03FC551D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000011FF4: BF870121
	v_cndmask_b32_e32 v54, v29, v28, vcc_lo                    // 000000011FF8: 026C391D
	v_cndmask_b32_e32 v28, v28, v29, vcc_lo                    // 000000011FFC: 02383B1C
	v_fma_mixlo_f16 v53, v54, s41, 0                           // 000000012000: CC210035 02005336
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012008: BF870112
	v_fma_mixlo_f16 v29, v28, s41, 0                           // 00000001200C: CC21001D 0200531C
	v_fma_mixlo_f16 v61, v54, s41, -v53 op_sel_hi:[0,0,1]      // 000000012014: CC21403D 84D45336
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000001201C: BF870132
	v_fma_mixhi_f16 v61, v28, s41, -v29 op_sel_hi:[0,0,1]      // 000000012020: CC22403D 8474531C
	v_mov_b32_e32 v28, v27                                     // 000000012028: 7E38031B
	.long 0x7f6a391d                                           // 00000001202C: 7F6A391D
	v_permlanex16_b32 v28, v28, s42, 0xfedcba98                // 000000012030: D65C001C 03FC551C FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001203C: BF870121
	v_cndmask_b32_e32 v55, v28, v27, vcc_lo                    // 000000012040: 026E371C
	v_cndmask_b32_e32 v27, v27, v28, vcc_lo                    // 000000012044: 0236391B
	v_fma_mixlo_f16 v54, v55, s41, 0                           // 000000012048: CC210036 02005337
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012050: BF870112
	v_fma_mixlo_f16 v28, v27, s41, 0                           // 000000012054: CC21001C 0200531B
	v_fma_mixlo_f16 v62, v55, s41, -v54 op_sel_hi:[0,0,1]      // 00000001205C: CC21403E 84D85337
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000012064: BF870132
	v_fma_mixhi_f16 v62, v27, s41, -v28 op_sel_hi:[0,0,1]      // 000000012068: CC22403E 8470531B
	v_mov_b32_e32 v27, v26                                     // 000000012070: 7E36031A
	.long 0x7f6c391c                                           // 000000012074: 7F6C391C
	v_permlanex16_b32 v27, v27, s42, 0xfedcba98                // 000000012078: D65C001B 03FC551B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012084: BF870121
	v_cndmask_b32_e32 v56, v27, v26, vcc_lo                    // 000000012088: 0270351B
	v_cndmask_b32_e32 v26, v26, v27, vcc_lo                    // 00000001208C: 0234371A
	v_fma_mixlo_f16 v55, v56, s41, 0                           // 000000012090: CC210037 02005338
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012098: BF870112
	v_fma_mixlo_f16 v27, v26, s41, 0                           // 00000001209C: CC21001B 0200531A
	v_fma_mixlo_f16 v63, v56, s41, -v55 op_sel_hi:[0,0,1]      // 0000000120A4: CC21403F 84DC5338
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000120AC: BF870132
	v_fma_mixhi_f16 v63, v26, s41, -v27 op_sel_hi:[0,0,1]      // 0000000120B0: CC22403F 846C531A
	v_mov_b32_e32 v26, v25                                     // 0000000120B8: 7E340319
	.long 0x7f6e391b                                           // 0000000120BC: 7F6E391B
	v_permlanex16_b32 v26, v26, s42, 0xfedcba98                // 0000000120C0: D65C001A 03FC551A FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000120CC: BF870121
	v_cndmask_b32_e32 v73, v26, v25, vcc_lo                    // 0000000120D0: 0292331A
	v_cndmask_b32_e32 v25, v25, v26, vcc_lo                    // 0000000120D4: 02323519
	v_fma_mixlo_f16 v56, v73, s41, 0                           // 0000000120D8: CC210038 02005349
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000120E0: BF870092
	v_fma_mixhi_f16 v56, v25, s41, 0                           // 0000000120E4: CC220038 02005319
	.long 0x7e3439b8                                           // 0000000120EC: 7E3439B8
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000120F0: BF870113
	v_fma_mixlo_f16 v64, v73, s41, -v56 op_sel_hi:[0,0,1]      // 0000000120F4: CC214040 84E05349
	v_fma_mixhi_f16 v64, v25, s41, -v26 op_sel_hi:[0,0,1]      // 0000000120FC: CC224040 84685319
	s_waitcnt lgkmcnt(4)                                       // 000000012104: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000012108: BF870091
	v_wmma_f32_16x16x16_f16 v[25:32], v[17:24], v[57:64], v[1:8]// 00000001210C: CC404019 1C067311
	v_wmma_f32_16x16x16_f16 v[25:32], v[17:24], v[49:56], v[25:32]// 000000012114: CC404019 1C666311
	s_waitcnt lgkmcnt(2)                                       // 00000001211C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[57:64], v[1:8]// 000000012120: CC404011 1C067329
	s_delay_alu instid0(VALU_DEP_1)                            // 000000012128: BF870001
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[49:56], v[17:24]// 00000001212C: CC404011 1C466329
	v_dual_mul_f32 v54, 0x3b800000, v123 :: v_dual_mul_f32 v49, 0x3b800000, v128// 000000012134: C8C6F6FF 363100FF 3B800000
	v_mul_f32_e32 v50, 0x3b800000, v127                        // 000000012140: 1064FEFF 3B800000
	v_mul_f32_e32 v52, 0x3b800000, v125                        // 000000012148: 1068FAFF 3B800000
	v_mul_f32_e32 v56, 0x3b800000, v153                        // 000000012150: 107132FF 3B800000
	ds_load_b128 v[45:48], v160 offset:14896                   // 000000012158: DBFC3A30 2D0000A0
	ds_load_b128 v[41:44], v160 offset:14880                   // 000000012160: DBFC3A20 290000A0
	v_mov_b32_e32 v57, v49                                     // 000000012168: 7E720331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001216C: BF870091
	v_permlanex16_b32 v57, v57, s42, 0xfedcba98                // 000000012170: D65C0039 03FC5539 FEDCBA98
	v_cndmask_b32_e32 v58, v57, v49, vcc_lo                    // 00000001217C: 02746339
	v_cndmask_b32_e32 v59, v49, v57, vcc_lo                    // 000000012180: 02767331
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012184: BF870112
	v_fma_mixlo_f16 v49, v58, s41, 0                           // 000000012188: CC210031 0200533A
	v_fma_mixlo_f16 v64, v59, s41, 0                           // 000000012190: CC210040 0200533B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012198: BF8701A2
	v_fma_mixlo_f16 v57, v58, s41, -v49 op_sel_hi:[0,0,1]      // 00000001219C: CC214039 84C4533A
	v_mov_b32_e32 v58, v50                                     // 0000000121A4: 7E740332
	v_fma_mixhi_f16 v57, v59, s41, -v64 op_sel_hi:[0,0,1]      // 0000000121A8: CC224039 8500533B
	.long 0x7f623940                                           // 0000000121B0: 7F623940
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000121B4: BF870093
	v_permlanex16_b32 v58, v58, s42, 0xfedcba98                // 0000000121B8: D65C003A 03FC553A FEDCBA98
	v_dual_mul_f32 v53, 0x3b800000, v124 :: v_dual_cndmask_b32 v60, v50, v58// 0000000121C4: C8D2F8FF 353C7532 3B800000
	v_cndmask_b32_e32 v59, v58, v50, vcc_lo                    // 0000000121D0: 0276653A
	v_mul_f32_e32 v51, 0x3b800000, v126                        // 0000000121D4: 1066FCFF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000121DC: BF870193
	v_fma_mixlo_f16 v73, v60, s41, 0                           // 0000000121E0: CC210049 0200533C
	v_fma_mixlo_f16 v50, v59, s41, 0                           // 0000000121E8: CC210032 0200533B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000121F0: BF870112
	v_fma_mixhi_f16 v58, v60, s41, -v73 op_sel_hi:[0,0,1]      // 0000000121F4: CC22403A 8524533C
	v_fma_mixlo_f16 v58, v59, s41, -v50 op_sel_hi:[0,0,1]      // 0000000121FC: CC21403A 84C8533B
	v_mov_b32_e32 v59, v51                                     // 000000012204: 7E760333
	.long 0x7f643949                                           // 000000012208: 7F643949
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001220C: BF870092
	v_permlanex16_b32 v59, v59, s42, 0xfedcba98                // 000000012210: D65C003B 03FC553B FEDCBA98
	v_cndmask_b32_e32 v60, v59, v51, vcc_lo                    // 00000001221C: 0278673B
	v_cndmask_b32_e32 v61, v51, v59, vcc_lo                    // 000000012220: 027A7733
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012224: BF870112
	v_fma_mixlo_f16 v51, v60, s41, 0                           // 000000012228: CC210033 0200533C
	v_fma_mixlo_f16 v74, v61, s41, 0                           // 000000012230: CC21004A 0200533D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012238: BF8701A2
	v_fma_mixlo_f16 v59, v60, s41, -v51 op_sel_hi:[0,0,1]      // 00000001223C: CC21403B 84CC533C
	v_mov_b32_e32 v60, v52                                     // 000000012244: 7E780334
	v_fma_mixhi_f16 v59, v61, s41, -v74 op_sel_hi:[0,0,1]      // 000000012248: CC22403B 8528533D
	.long 0x7f66394a                                           // 000000012250: 7F66394A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000012254: BF870093
	v_permlanex16_b32 v60, v60, s42, 0xfedcba98                // 000000012258: D65C003C 03FC553C FEDCBA98
	v_dual_mul_f32 v55, 0x3b800000, v122 :: v_dual_cndmask_b32 v62, v52, v60// 000000012264: C8D2F4FF 373E7934 3B800000
	v_cndmask_b32_e32 v61, v60, v52, vcc_lo                    // 000000012270: 027A693C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012274: BF870112
	v_fma_mixlo_f16 v75, v62, s41, 0                           // 000000012278: CC21004B 0200533E
	v_fma_mixlo_f16 v52, v61, s41, 0                           // 000000012280: CC210034 0200533D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012288: BF870112
	v_fma_mixhi_f16 v60, v62, s41, -v75 op_sel_hi:[0,0,1]      // 00000001228C: CC22403C 852C533E
	v_fma_mixlo_f16 v60, v61, s41, -v52 op_sel_hi:[0,0,1]      // 000000012294: CC21403C 84D0533D
	v_mov_b32_e32 v61, v53                                     // 00000001229C: 7E7A0335
	.long 0x7f68394b                                           // 0000000122A0: 7F68394B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000122A4: BF870092
	v_permlanex16_b32 v61, v61, s42, 0xfedcba98                // 0000000122A8: D65C003D 03FC553D FEDCBA98
	v_cndmask_b32_e32 v62, v61, v53, vcc_lo                    // 0000000122B4: 027C6B3D
	v_cndmask_b32_e32 v63, v53, v61, vcc_lo                    // 0000000122B8: 027E7B35
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000122BC: BF870112
	v_fma_mixlo_f16 v53, v62, s41, 0                           // 0000000122C0: CC210035 0200533E
	v_fma_mixlo_f16 v76, v63, s41, 0                           // 0000000122C8: CC21004C 0200533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000122D0: BF8701A2
	v_fma_mixlo_f16 v61, v62, s41, -v53 op_sel_hi:[0,0,1]      // 0000000122D4: CC21403D 84D4533E
	v_mov_b32_e32 v62, v54                                     // 0000000122DC: 7E7C0336
	v_fma_mixhi_f16 v61, v63, s41, -v76 op_sel_hi:[0,0,1]      // 0000000122E0: CC22403D 8530533F
	.long 0x7f6a394c                                           // 0000000122E8: 7F6A394C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000122EC: BF870093
	v_permlanex16_b32 v62, v62, s42, 0xfedcba98                // 0000000122F0: D65C003E 03FC553E FEDCBA98
	v_cndmask_b32_e32 v63, v62, v54, vcc_lo                    // 0000000122FC: 027E6D3E
	v_cndmask_b32_e32 v77, v54, v62, vcc_lo                    // 000000012300: 029A7D36
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012304: BF870112
	v_fma_mixlo_f16 v54, v63, s41, 0                           // 000000012308: CC210036 0200533F
	v_fma_mixlo_f16 v78, v77, s41, 0                           // 000000012310: CC21004E 0200534D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012318: BF8701A2
	v_fma_mixlo_f16 v62, v63, s41, -v54 op_sel_hi:[0,0,1]      // 00000001231C: CC21403E 84D8533F
	v_mov_b32_e32 v63, v55                                     // 000000012324: 7E7E0337
	v_fma_mixhi_f16 v62, v77, s41, -v78 op_sel_hi:[0,0,1]      // 000000012328: CC22403E 8538534D
	.long 0x7f6c394e                                           // 000000012330: 7F6C394E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000012334: BF870093
	v_permlanex16_b32 v63, v63, s42, 0xfedcba98                // 000000012338: D65C003F 03FC553F FEDCBA98
	v_cndmask_b32_e32 v77, v63, v55, vcc_lo                    // 000000012344: 029A6F3F
	v_cndmask_b32_e32 v79, v55, v63, vcc_lo                    // 000000012348: 029E7F37
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001234C: BF870112
	v_fma_mixlo_f16 v55, v77, s41, 0                           // 000000012350: CC210037 0200534D
	v_fma_mixlo_f16 v80, v79, s41, 0                           // 000000012358: CC210050 0200534F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012360: BF8701A2
	v_fma_mixlo_f16 v63, v77, s41, -v55 op_sel_hi:[0,0,1]      // 000000012364: CC21403F 84DC534D
	v_mov_b32_e32 v77, v56                                     // 00000001236C: 7E9A0338
	v_fma_mixhi_f16 v63, v79, s41, -v80 op_sel_hi:[0,0,1]      // 000000012370: CC22403F 8540534F
	.long 0x7f6e3950                                           // 000000012378: 7F6E3950
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001237C: BF870093
	v_permlanex16_b32 v77, v77, s42, 0xfedcba98                // 000000012380: D65C004D 03FC554D FEDCBA98
	v_cndmask_b32_e32 v79, v77, v56, vcc_lo                    // 00000001238C: 029E714D
	v_cndmask_b32_e32 v77, v56, v77, vcc_lo                    // 000000012390: 029A9B38
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012394: BF870112
	v_fma_mixlo_f16 v56, v79, s41, 0                           // 000000012398: CC210038 0200534F
	v_fma_mixhi_f16 v56, v77, s41, 0                           // 0000000123A0: CC220038 0200534D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000123A8: BF870191
	.long 0xd59c08a1                                           // 0000000123AC: D59C08A1
	v_cndmask_b32_e32 v0, v56, v128, vcc_lo                    // 0000000123B0: 02010138
	v_fma_mixlo_f16 v64, v79, s41, -v56 op_sel_hi:[0,0,1]      // 0000000123B4: CC214040 84E0534F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000123BC: BF8700A2
	v_fma_mixhi_f16 v64, v77, s41, -v161 op_sel_hi:[0,0,1]     // 0000000123C0: CC224040 8684534D
	s_waitcnt lgkmcnt(0)                                       // 0000000123C8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[57:64], v[25:32]// 0000000123CC: CC404019 1C667329
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[57:64], v[17:24]// 0000000123D4: CC404011 1C467321
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000123DC: BF870112
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[49:56], v[25:32]// 0000000123E0: CC404019 1C666329
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[49:56], v[17:24]// 0000000123E8: CC404011 1C466321
	v_dual_mul_f32 v49, 0x3b800000, v121 :: v_dual_mul_f32 v50, 0x3b800000, v120// 0000000123F0: C8C6F2FF 3132F0FF 3B800000
	v_dual_mul_f32 v51, 0x3b800000, v119 :: v_dual_mul_f32 v52, 0x3b800000, v118// 0000000123FC: C8C6EEFF 3334ECFF 3B800000
	v_mul_f32_e32 v53, 0x3b800000, v117                        // 000000012408: 106AEAFF 3B800000
	s_delay_alu instid0(VALU_DEP_3)                            // 000000012410: BF870003
	v_dual_mov_b32 v57, v49 :: v_dual_mul_f32 v54, 0x3b800000, v116// 000000012414: CA060131 3936E8FF 3B800000
	v_dual_mul_f32 v55, 0x3b800000, v115 :: v_dual_mul_f32 v56, 0x3b800000, v152// 000000012420: C8C6E6FF 373930FF 3B800000
	ds_load_b128 v[45:48], v160 offset:14928                   // 00000001242C: DBFC3A50 2D0000A0
	ds_load_b128 v[41:44], v160 offset:14912                   // 000000012434: DBFC3A40 290000A0
	ds_load_b128 v[37:40], v160 offset:10576                   // 00000001243C: DBFC2950 250000A0
	ds_load_b128 v[33:36], v160 offset:10560                   // 000000012444: DBFC2940 210000A0
	v_permlanex16_b32 v57, v57, s42, 0xfedcba98                // 00000001244C: D65C0039 03FC5539 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012458: BF870121
	v_cndmask_b32_e32 v58, v57, v49, vcc_lo                    // 00000001245C: 02746339
	v_cndmask_b32_e32 v59, v49, v57, vcc_lo                    // 000000012460: 02767331
	v_fma_mixlo_f16 v49, v58, s41, 0                           // 000000012464: CC210031 0200533A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001246C: BF870112
	v_fma_mixlo_f16 v64, v59, s41, 0                           // 000000012470: CC210040 0200533B
	v_fma_mixlo_f16 v57, v58, s41, -v49 op_sel_hi:[0,0,1]      // 000000012478: CC214039 84C4533A
	v_mov_b32_e32 v58, v50                                     // 000000012480: 7E740332
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012484: BF8701A3
	v_fma_mixhi_f16 v57, v59, s41, -v64 op_sel_hi:[0,0,1]      // 000000012488: CC224039 8500533B
	.long 0x7f623940                                           // 000000012490: 7F623940
	v_permlanex16_b32 v58, v58, s42, 0xfedcba98                // 000000012494: D65C003A 03FC553A FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000124A0: BF870121
	v_cndmask_b32_e32 v59, v58, v50, vcc_lo                    // 0000000124A4: 0276653A
	v_cndmask_b32_e32 v60, v50, v58, vcc_lo                    // 0000000124A8: 02787532
	v_fma_mixlo_f16 v50, v59, s41, 0                           // 0000000124AC: CC210032 0200533B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000124B4: BF870112
	v_fma_mixlo_f16 v73, v60, s41, 0                           // 0000000124B8: CC210049 0200533C
	v_fma_mixlo_f16 v58, v59, s41, -v50 op_sel_hi:[0,0,1]      // 0000000124C0: CC21403A 84C8533B
	v_mov_b32_e32 v59, v51                                     // 0000000124C8: 7E760333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000124CC: BF8701A3
	v_fma_mixhi_f16 v58, v60, s41, -v73 op_sel_hi:[0,0,1]      // 0000000124D0: CC22403A 8524533C
	.long 0x7f643949                                           // 0000000124D8: 7F643949
	v_permlanex16_b32 v59, v59, s42, 0xfedcba98                // 0000000124DC: D65C003B 03FC553B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000124E8: BF870121
	v_cndmask_b32_e32 v60, v59, v51, vcc_lo                    // 0000000124EC: 0278673B
	v_cndmask_b32_e32 v61, v51, v59, vcc_lo                    // 0000000124F0: 027A7733
	v_fma_mixlo_f16 v51, v60, s41, 0                           // 0000000124F4: CC210033 0200533C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000124FC: BF870112
	v_fma_mixlo_f16 v74, v61, s41, 0                           // 000000012500: CC21004A 0200533D
	v_fma_mixlo_f16 v59, v60, s41, -v51 op_sel_hi:[0,0,1]      // 000000012508: CC21403B 84CC533C
	v_mov_b32_e32 v60, v52                                     // 000000012510: 7E780334
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012514: BF8701A3
	v_fma_mixhi_f16 v59, v61, s41, -v74 op_sel_hi:[0,0,1]      // 000000012518: CC22403B 8528533D
	.long 0x7f66394a                                           // 000000012520: 7F66394A
	v_permlanex16_b32 v60, v60, s42, 0xfedcba98                // 000000012524: D65C003C 03FC553C FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012530: BF870121
	v_cndmask_b32_e32 v61, v60, v52, vcc_lo                    // 000000012534: 027A693C
	v_cndmask_b32_e32 v62, v52, v60, vcc_lo                    // 000000012538: 027C7934
	v_fma_mixlo_f16 v52, v61, s41, 0                           // 00000001253C: CC210034 0200533D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012544: BF870112
	v_fma_mixlo_f16 v75, v62, s41, 0                           // 000000012548: CC21004B 0200533E
	v_fma_mixlo_f16 v60, v61, s41, -v52 op_sel_hi:[0,0,1]      // 000000012550: CC21403C 84D0533D
	v_mov_b32_e32 v61, v53                                     // 000000012558: 7E7A0335
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001255C: BF8701A3
	v_fma_mixhi_f16 v60, v62, s41, -v75 op_sel_hi:[0,0,1]      // 000000012560: CC22403C 852C533E
	.long 0x7f68394b                                           // 000000012568: 7F68394B
	v_permlanex16_b32 v61, v61, s42, 0xfedcba98                // 00000001256C: D65C003D 03FC553D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012578: BF870121
	v_cndmask_b32_e32 v62, v61, v53, vcc_lo                    // 00000001257C: 027C6B3D
	v_cndmask_b32_e32 v63, v53, v61, vcc_lo                    // 000000012580: 027E7B35
	v_fma_mixlo_f16 v53, v62, s41, 0                           // 000000012584: CC210035 0200533E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001258C: BF870112
	v_fma_mixlo_f16 v76, v63, s41, 0                           // 000000012590: CC21004C 0200533F
	v_fma_mixlo_f16 v61, v62, s41, -v53 op_sel_hi:[0,0,1]      // 000000012598: CC21403D 84D4533E
	v_mov_b32_e32 v62, v54                                     // 0000000125A0: 7E7C0336
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000125A4: BF8701A3
	v_fma_mixhi_f16 v61, v63, s41, -v76 op_sel_hi:[0,0,1]      // 0000000125A8: CC22403D 8530533F
	.long 0x7f6a394c                                           // 0000000125B0: 7F6A394C
	v_permlanex16_b32 v62, v62, s42, 0xfedcba98                // 0000000125B4: D65C003E 03FC553E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000125C0: BF870121
	v_cndmask_b32_e32 v63, v62, v54, vcc_lo                    // 0000000125C4: 027E6D3E
	v_cndmask_b32_e32 v77, v54, v62, vcc_lo                    // 0000000125C8: 029A7D36
	v_fma_mixlo_f16 v54, v63, s41, 0                           // 0000000125CC: CC210036 0200533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000125D4: BF870112
	v_fma_mixlo_f16 v78, v77, s41, 0                           // 0000000125D8: CC21004E 0200534D
	v_fma_mixlo_f16 v62, v63, s41, -v54 op_sel_hi:[0,0,1]      // 0000000125E0: CC21403E 84D8533F
	v_mov_b32_e32 v63, v55                                     // 0000000125E8: 7E7E0337
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000125EC: BF8701A3
	v_fma_mixhi_f16 v62, v77, s41, -v78 op_sel_hi:[0,0,1]      // 0000000125F0: CC22403E 8538534D
	.long 0x7f6c394e                                           // 0000000125F8: 7F6C394E
	v_permlanex16_b32 v63, v63, s42, 0xfedcba98                // 0000000125FC: D65C003F 03FC553F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012608: BF870121
	v_cndmask_b32_e32 v77, v63, v55, vcc_lo                    // 00000001260C: 029A6F3F
	v_cndmask_b32_e32 v79, v55, v63, vcc_lo                    // 000000012610: 029E7F37
	v_fma_mixlo_f16 v55, v77, s41, 0                           // 000000012614: CC210037 0200534D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001261C: BF870112
	v_fma_mixlo_f16 v80, v79, s41, 0                           // 000000012620: CC210050 0200534F
	v_fma_mixlo_f16 v63, v77, s41, -v55 op_sel_hi:[0,0,1]      // 000000012628: CC21403F 84DC534D
	v_mov_b32_e32 v77, v56                                     // 000000012630: 7E9A0338
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012634: BF8701A3
	v_fma_mixhi_f16 v63, v79, s41, -v80 op_sel_hi:[0,0,1]      // 000000012638: CC22403F 8540534F
	.long 0x7f6e3950                                           // 000000012640: 7F6E3950
	v_permlanex16_b32 v77, v77, s42, 0xfedcba98                // 000000012644: D65C004D 03FC554D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012650: BF870121
	v_cndmask_b32_e32 v79, v77, v56, vcc_lo                    // 000000012654: 029E714D
	v_cndmask_b32_e32 v77, v56, v77, vcc_lo                    // 000000012658: 029A9B38
	v_fma_mixlo_f16 v56, v79, s41, 0                           // 00000001265C: CC210038 0200534F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000012664: BF870092
	v_fma_mixhi_f16 v56, v77, s41, 0                           // 000000012668: CC220038 0200534D
	.long 0xd59c08a1                                           // 000000012670: D59C08A1
	v_cndmask_b32_e32 v0, v56, v128, vcc_lo                    // 000000012674: 02010138
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012678: BF870113
	v_fma_mixlo_f16 v64, v79, s41, -v56 op_sel_hi:[0,0,1]      // 00000001267C: CC214040 84E0534F
	v_fma_mixhi_f16 v64, v77, s41, -v161 op_sel_hi:[0,0,1]     // 000000012684: CC224040 8684534D
	s_waitcnt lgkmcnt(2)                                       // 00000001268C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000012690: BF870131
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[57:64], v[25:32]// 000000012694: CC404019 1C667329
	s_waitcnt lgkmcnt(0)                                       // 00000001269C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[57:64], v[17:24]// 0000000126A0: CC404011 1C467321
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[49:56], v[25:32]// 0000000126A8: CC404019 1C666329
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000126B0: BF8701C2
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[49:56], v[17:24]// 0000000126B4: CC404011 1C466321
	v_dual_mul_f32 v49, 0x3b800000, v114 :: v_dual_mul_f32 v50, 0x3b800000, v113// 0000000126BC: C8C6E4FF 3132E2FF 3B800000
	v_dual_mul_f32 v51, 0x3b800000, v112 :: v_dual_mul_f32 v52, 0x3b800000, v111// 0000000126C8: C8C6E0FF 3334DEFF 3B800000
	v_mul_f32_e32 v53, 0x3b800000, v110                        // 0000000126D4: 106ADCFF 3B800000
	v_dual_mov_b32 v57, v49 :: v_dual_mul_f32 v54, 0x3b800000, v109// 0000000126DC: CA060131 3936DAFF 3B800000
	v_dual_mul_f32 v55, 0x3b800000, v108 :: v_dual_mul_f32 v56, 0x3b800000, v151// 0000000126E8: C8C6D8FF 37392EFF 3B800000
	ds_load_b128 v[45:48], v160 offset:14960                   // 0000000126F4: DBFC3A70 2D0000A0
	ds_load_b128 v[41:44], v160 offset:14944                   // 0000000126FC: DBFC3A60 290000A0
	ds_load_b128 v[37:40], v160 offset:10608                   // 000000012704: DBFC2970 250000A0
	ds_load_b128 v[33:36], v160 offset:10592                   // 00000001270C: DBFC2960 210000A0
	v_permlanex16_b32 v57, v57, s42, 0xfedcba98                // 000000012714: D65C0039 03FC5539 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012720: BF870121
	v_cndmask_b32_e32 v58, v57, v49, vcc_lo                    // 000000012724: 02746339
	v_cndmask_b32_e32 v59, v49, v57, vcc_lo                    // 000000012728: 02767331
	v_fma_mixlo_f16 v49, v58, s41, 0                           // 00000001272C: CC210031 0200533A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012734: BF870112
	v_fma_mixlo_f16 v64, v59, s41, 0                           // 000000012738: CC210040 0200533B
	v_fma_mixlo_f16 v57, v58, s41, -v49 op_sel_hi:[0,0,1]      // 000000012740: CC214039 84C4533A
	v_mov_b32_e32 v58, v50                                     // 000000012748: 7E740332
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001274C: BF8701A3
	v_fma_mixhi_f16 v57, v59, s41, -v64 op_sel_hi:[0,0,1]      // 000000012750: CC224039 8500533B
	.long 0x7f623940                                           // 000000012758: 7F623940
	v_permlanex16_b32 v58, v58, s42, 0xfedcba98                // 00000001275C: D65C003A 03FC553A FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012768: BF870121
	v_cndmask_b32_e32 v59, v58, v50, vcc_lo                    // 00000001276C: 0276653A
	v_cndmask_b32_e32 v60, v50, v58, vcc_lo                    // 000000012770: 02787532
	v_fma_mixlo_f16 v50, v59, s41, 0                           // 000000012774: CC210032 0200533B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001277C: BF870112
	v_fma_mixlo_f16 v73, v60, s41, 0                           // 000000012780: CC210049 0200533C
	v_fma_mixlo_f16 v58, v59, s41, -v50 op_sel_hi:[0,0,1]      // 000000012788: CC21403A 84C8533B
	v_mov_b32_e32 v59, v51                                     // 000000012790: 7E760333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012794: BF8701A3
	v_fma_mixhi_f16 v58, v60, s41, -v73 op_sel_hi:[0,0,1]      // 000000012798: CC22403A 8524533C
	.long 0x7f643949                                           // 0000000127A0: 7F643949
	v_permlanex16_b32 v59, v59, s42, 0xfedcba98                // 0000000127A4: D65C003B 03FC553B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000127B0: BF870121
	v_cndmask_b32_e32 v60, v59, v51, vcc_lo                    // 0000000127B4: 0278673B
	v_cndmask_b32_e32 v61, v51, v59, vcc_lo                    // 0000000127B8: 027A7733
	v_fma_mixlo_f16 v51, v60, s41, 0                           // 0000000127BC: CC210033 0200533C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000127C4: BF870112
	v_fma_mixlo_f16 v74, v61, s41, 0                           // 0000000127C8: CC21004A 0200533D
	v_fma_mixlo_f16 v59, v60, s41, -v51 op_sel_hi:[0,0,1]      // 0000000127D0: CC21403B 84CC533C
	v_mov_b32_e32 v60, v52                                     // 0000000127D8: 7E780334
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000127DC: BF8701A3
	v_fma_mixhi_f16 v59, v61, s41, -v74 op_sel_hi:[0,0,1]      // 0000000127E0: CC22403B 8528533D
	.long 0x7f66394a                                           // 0000000127E8: 7F66394A
	v_permlanex16_b32 v60, v60, s42, 0xfedcba98                // 0000000127EC: D65C003C 03FC553C FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000127F8: BF870121
	v_cndmask_b32_e32 v61, v60, v52, vcc_lo                    // 0000000127FC: 027A693C
	v_cndmask_b32_e32 v62, v52, v60, vcc_lo                    // 000000012800: 027C7934
	v_fma_mixlo_f16 v52, v61, s41, 0                           // 000000012804: CC210034 0200533D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001280C: BF870112
	v_fma_mixlo_f16 v75, v62, s41, 0                           // 000000012810: CC21004B 0200533E
	v_fma_mixlo_f16 v60, v61, s41, -v52 op_sel_hi:[0,0,1]      // 000000012818: CC21403C 84D0533D
	v_mov_b32_e32 v61, v53                                     // 000000012820: 7E7A0335
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012824: BF8701A3
	v_fma_mixhi_f16 v60, v62, s41, -v75 op_sel_hi:[0,0,1]      // 000000012828: CC22403C 852C533E
	.long 0x7f68394b                                           // 000000012830: 7F68394B
	v_permlanex16_b32 v61, v61, s42, 0xfedcba98                // 000000012834: D65C003D 03FC553D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012840: BF870121
	v_cndmask_b32_e32 v62, v61, v53, vcc_lo                    // 000000012844: 027C6B3D
	v_cndmask_b32_e32 v63, v53, v61, vcc_lo                    // 000000012848: 027E7B35
	v_fma_mixlo_f16 v53, v62, s41, 0                           // 00000001284C: CC210035 0200533E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012854: BF870112
	v_fma_mixlo_f16 v76, v63, s41, 0                           // 000000012858: CC21004C 0200533F
	v_fma_mixlo_f16 v61, v62, s41, -v53 op_sel_hi:[0,0,1]      // 000000012860: CC21403D 84D4533E
	v_mov_b32_e32 v62, v54                                     // 000000012868: 7E7C0336
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001286C: BF8701A3
	v_fma_mixhi_f16 v61, v63, s41, -v76 op_sel_hi:[0,0,1]      // 000000012870: CC22403D 8530533F
	.long 0x7f6a394c                                           // 000000012878: 7F6A394C
	v_permlanex16_b32 v62, v62, s42, 0xfedcba98                // 00000001287C: D65C003E 03FC553E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012888: BF870121
	v_cndmask_b32_e32 v63, v62, v54, vcc_lo                    // 00000001288C: 027E6D3E
	v_cndmask_b32_e32 v77, v54, v62, vcc_lo                    // 000000012890: 029A7D36
	v_fma_mixlo_f16 v54, v63, s41, 0                           // 000000012894: CC210036 0200533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001289C: BF870112
	v_fma_mixlo_f16 v78, v77, s41, 0                           // 0000000128A0: CC21004E 0200534D
	v_fma_mixlo_f16 v62, v63, s41, -v54 op_sel_hi:[0,0,1]      // 0000000128A8: CC21403E 84D8533F
	v_mov_b32_e32 v63, v55                                     // 0000000128B0: 7E7E0337
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000128B4: BF8701A3
	v_fma_mixhi_f16 v62, v77, s41, -v78 op_sel_hi:[0,0,1]      // 0000000128B8: CC22403E 8538534D
	.long 0x7f6c394e                                           // 0000000128C0: 7F6C394E
	v_permlanex16_b32 v63, v63, s42, 0xfedcba98                // 0000000128C4: D65C003F 03FC553F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000128D0: BF870121
	v_cndmask_b32_e32 v77, v63, v55, vcc_lo                    // 0000000128D4: 029A6F3F
	v_cndmask_b32_e32 v79, v55, v63, vcc_lo                    // 0000000128D8: 029E7F37
	v_fma_mixlo_f16 v55, v77, s41, 0                           // 0000000128DC: CC210037 0200534D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000128E4: BF870112
	v_fma_mixlo_f16 v80, v79, s41, 0                           // 0000000128E8: CC210050 0200534F
	v_fma_mixlo_f16 v63, v77, s41, -v55 op_sel_hi:[0,0,1]      // 0000000128F0: CC21403F 84DC534D
	v_mov_b32_e32 v77, v56                                     // 0000000128F8: 7E9A0338
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000128FC: BF8701A3
	v_fma_mixhi_f16 v63, v79, s41, -v80 op_sel_hi:[0,0,1]      // 000000012900: CC22403F 8540534F
	.long 0x7f6e3950                                           // 000000012908: 7F6E3950
	v_permlanex16_b32 v77, v77, s42, 0xfedcba98                // 00000001290C: D65C004D 03FC554D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012918: BF870121
	v_cndmask_b32_e32 v79, v77, v56, vcc_lo                    // 00000001291C: 029E714D
	v_cndmask_b32_e32 v77, v56, v77, vcc_lo                    // 000000012920: 029A9B38
	v_fma_mixlo_f16 v56, v79, s41, 0                           // 000000012924: CC210038 0200534F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001292C: BF870092
	v_fma_mixhi_f16 v56, v77, s41, 0                           // 000000012930: CC220038 0200534D
	.long 0xd59c08a1                                           // 000000012938: D59C08A1
	v_cndmask_b32_e32 v0, v56, v128, vcc_lo                    // 00000001293C: 02010138
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012940: BF870113
	v_fma_mixlo_f16 v64, v79, s41, -v56 op_sel_hi:[0,0,1]      // 000000012944: CC214040 84E0534F
	v_fma_mixhi_f16 v64, v77, s41, -v161 op_sel_hi:[0,0,1]     // 00000001294C: CC224040 8684534D
	s_waitcnt lgkmcnt(2)                                       // 000000012954: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000012958: BF870131
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[57:64], v[25:32]// 00000001295C: CC404019 1C667329
	s_waitcnt lgkmcnt(0)                                       // 000000012964: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[57:64], v[17:24]// 000000012968: CC404011 1C467321
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[49:56], v[25:32]// 000000012970: CC404019 1C666329
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000012978: BF8701C2
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[49:56], v[17:24]// 00000001297C: CC404011 1C466321
	v_dual_mul_f32 v49, 0x3b800000, v107 :: v_dual_mul_f32 v50, 0x3b800000, v106// 000000012984: C8C6D6FF 3132D4FF 3B800000
	v_dual_mul_f32 v51, 0x3b800000, v105 :: v_dual_mul_f32 v52, 0x3b800000, v104// 000000012990: C8C6D2FF 3334D0FF 3B800000
	v_mul_f32_e32 v53, 0x3b800000, v103                        // 00000001299C: 106ACEFF 3B800000
	v_dual_mov_b32 v57, v49 :: v_dual_mul_f32 v54, 0x3b800000, v102// 0000000129A4: CA060131 3936CCFF 3B800000
	v_dual_mul_f32 v55, 0x3b800000, v101 :: v_dual_mul_f32 v56, 0x3b800000, v150// 0000000129B0: C8C6CAFF 37392CFF 3B800000
	ds_load_b128 v[45:48], v160 offset:14992                   // 0000000129BC: DBFC3A90 2D0000A0
	ds_load_b128 v[41:44], v160 offset:14976                   // 0000000129C4: DBFC3A80 290000A0
	ds_load_b128 v[37:40], v160 offset:10640                   // 0000000129CC: DBFC2990 250000A0
	ds_load_b128 v[33:36], v160 offset:10624                   // 0000000129D4: DBFC2980 210000A0
	v_permlanex16_b32 v57, v57, s42, 0xfedcba98                // 0000000129DC: D65C0039 03FC5539 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000129E8: BF870121
	v_cndmask_b32_e32 v58, v57, v49, vcc_lo                    // 0000000129EC: 02746339
	v_cndmask_b32_e32 v59, v49, v57, vcc_lo                    // 0000000129F0: 02767331
	v_fma_mixlo_f16 v49, v58, s41, 0                           // 0000000129F4: CC210031 0200533A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000129FC: BF870112
	v_fma_mixlo_f16 v64, v59, s41, 0                           // 000000012A00: CC210040 0200533B
	v_fma_mixlo_f16 v57, v58, s41, -v49 op_sel_hi:[0,0,1]      // 000000012A08: CC214039 84C4533A
	v_mov_b32_e32 v58, v50                                     // 000000012A10: 7E740332
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012A14: BF8701A3
	v_fma_mixhi_f16 v57, v59, s41, -v64 op_sel_hi:[0,0,1]      // 000000012A18: CC224039 8500533B
	.long 0x7f623940                                           // 000000012A20: 7F623940
	v_permlanex16_b32 v58, v58, s42, 0xfedcba98                // 000000012A24: D65C003A 03FC553A FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012A30: BF870121
	v_cndmask_b32_e32 v59, v58, v50, vcc_lo                    // 000000012A34: 0276653A
	v_cndmask_b32_e32 v60, v50, v58, vcc_lo                    // 000000012A38: 02787532
	v_fma_mixlo_f16 v50, v59, s41, 0                           // 000000012A3C: CC210032 0200533B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012A44: BF870112
	v_fma_mixlo_f16 v73, v60, s41, 0                           // 000000012A48: CC210049 0200533C
	v_fma_mixlo_f16 v58, v59, s41, -v50 op_sel_hi:[0,0,1]      // 000000012A50: CC21403A 84C8533B
	v_mov_b32_e32 v59, v51                                     // 000000012A58: 7E760333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012A5C: BF8701A3
	v_fma_mixhi_f16 v58, v60, s41, -v73 op_sel_hi:[0,0,1]      // 000000012A60: CC22403A 8524533C
	.long 0x7f643949                                           // 000000012A68: 7F643949
	v_permlanex16_b32 v59, v59, s42, 0xfedcba98                // 000000012A6C: D65C003B 03FC553B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012A78: BF870121
	v_cndmask_b32_e32 v60, v59, v51, vcc_lo                    // 000000012A7C: 0278673B
	v_cndmask_b32_e32 v61, v51, v59, vcc_lo                    // 000000012A80: 027A7733
	v_fma_mixlo_f16 v51, v60, s41, 0                           // 000000012A84: CC210033 0200533C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012A8C: BF870112
	v_fma_mixlo_f16 v74, v61, s41, 0                           // 000000012A90: CC21004A 0200533D
	v_fma_mixlo_f16 v59, v60, s41, -v51 op_sel_hi:[0,0,1]      // 000000012A98: CC21403B 84CC533C
	v_mov_b32_e32 v60, v52                                     // 000000012AA0: 7E780334
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012AA4: BF8701A3
	v_fma_mixhi_f16 v59, v61, s41, -v74 op_sel_hi:[0,0,1]      // 000000012AA8: CC22403B 8528533D
	.long 0x7f66394a                                           // 000000012AB0: 7F66394A
	v_permlanex16_b32 v60, v60, s42, 0xfedcba98                // 000000012AB4: D65C003C 03FC553C FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012AC0: BF870121
	v_cndmask_b32_e32 v61, v60, v52, vcc_lo                    // 000000012AC4: 027A693C
	v_cndmask_b32_e32 v62, v52, v60, vcc_lo                    // 000000012AC8: 027C7934
	v_fma_mixlo_f16 v52, v61, s41, 0                           // 000000012ACC: CC210034 0200533D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012AD4: BF870112
	v_fma_mixlo_f16 v75, v62, s41, 0                           // 000000012AD8: CC21004B 0200533E
	v_fma_mixlo_f16 v60, v61, s41, -v52 op_sel_hi:[0,0,1]      // 000000012AE0: CC21403C 84D0533D
	v_mov_b32_e32 v61, v53                                     // 000000012AE8: 7E7A0335
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012AEC: BF8701A3
	v_fma_mixhi_f16 v60, v62, s41, -v75 op_sel_hi:[0,0,1]      // 000000012AF0: CC22403C 852C533E
	.long 0x7f68394b                                           // 000000012AF8: 7F68394B
	v_permlanex16_b32 v61, v61, s42, 0xfedcba98                // 000000012AFC: D65C003D 03FC553D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012B08: BF870121
	v_cndmask_b32_e32 v62, v61, v53, vcc_lo                    // 000000012B0C: 027C6B3D
	v_cndmask_b32_e32 v63, v53, v61, vcc_lo                    // 000000012B10: 027E7B35
	v_fma_mixlo_f16 v53, v62, s41, 0                           // 000000012B14: CC210035 0200533E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012B1C: BF870112
	v_fma_mixlo_f16 v76, v63, s41, 0                           // 000000012B20: CC21004C 0200533F
	v_fma_mixlo_f16 v61, v62, s41, -v53 op_sel_hi:[0,0,1]      // 000000012B28: CC21403D 84D4533E
	v_mov_b32_e32 v62, v54                                     // 000000012B30: 7E7C0336
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012B34: BF8701A3
	v_fma_mixhi_f16 v61, v63, s41, -v76 op_sel_hi:[0,0,1]      // 000000012B38: CC22403D 8530533F
	.long 0x7f6a394c                                           // 000000012B40: 7F6A394C
	v_permlanex16_b32 v62, v62, s42, 0xfedcba98                // 000000012B44: D65C003E 03FC553E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012B50: BF870121
	v_cndmask_b32_e32 v63, v62, v54, vcc_lo                    // 000000012B54: 027E6D3E
	v_cndmask_b32_e32 v77, v54, v62, vcc_lo                    // 000000012B58: 029A7D36
	v_fma_mixlo_f16 v54, v63, s41, 0                           // 000000012B5C: CC210036 0200533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012B64: BF870112
	v_fma_mixlo_f16 v78, v77, s41, 0                           // 000000012B68: CC21004E 0200534D
	v_fma_mixlo_f16 v62, v63, s41, -v54 op_sel_hi:[0,0,1]      // 000000012B70: CC21403E 84D8533F
	v_mov_b32_e32 v63, v55                                     // 000000012B78: 7E7E0337
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012B7C: BF8701A3
	v_fma_mixhi_f16 v62, v77, s41, -v78 op_sel_hi:[0,0,1]      // 000000012B80: CC22403E 8538534D
	.long 0x7f6c394e                                           // 000000012B88: 7F6C394E
	v_permlanex16_b32 v63, v63, s42, 0xfedcba98                // 000000012B8C: D65C003F 03FC553F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012B98: BF870121
	v_cndmask_b32_e32 v77, v63, v55, vcc_lo                    // 000000012B9C: 029A6F3F
	v_cndmask_b32_e32 v79, v55, v63, vcc_lo                    // 000000012BA0: 029E7F37
	v_fma_mixlo_f16 v55, v77, s41, 0                           // 000000012BA4: CC210037 0200534D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012BAC: BF870112
	v_fma_mixlo_f16 v80, v79, s41, 0                           // 000000012BB0: CC210050 0200534F
	v_fma_mixlo_f16 v63, v77, s41, -v55 op_sel_hi:[0,0,1]      // 000000012BB8: CC21403F 84DC534D
	v_mov_b32_e32 v77, v56                                     // 000000012BC0: 7E9A0338
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012BC4: BF8701A3
	v_fma_mixhi_f16 v63, v79, s41, -v80 op_sel_hi:[0,0,1]      // 000000012BC8: CC22403F 8540534F
	.long 0x7f6e3950                                           // 000000012BD0: 7F6E3950
	v_permlanex16_b32 v77, v77, s42, 0xfedcba98                // 000000012BD4: D65C004D 03FC554D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012BE0: BF870121
	v_cndmask_b32_e32 v79, v77, v56, vcc_lo                    // 000000012BE4: 029E714D
	v_cndmask_b32_e32 v77, v56, v77, vcc_lo                    // 000000012BE8: 029A9B38
	v_fma_mixlo_f16 v56, v79, s41, 0                           // 000000012BEC: CC210038 0200534F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000012BF4: BF870092
	v_fma_mixhi_f16 v56, v77, s41, 0                           // 000000012BF8: CC220038 0200534D
	.long 0xd59c08a1                                           // 000000012C00: D59C08A1
	v_cndmask_b32_e32 v0, v56, v128, vcc_lo                    // 000000012C04: 02010138
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012C08: BF870113
	v_fma_mixlo_f16 v64, v79, s41, -v56 op_sel_hi:[0,0,1]      // 000000012C0C: CC214040 84E0534F
	v_fma_mixhi_f16 v64, v77, s41, -v161 op_sel_hi:[0,0,1]     // 000000012C14: CC224040 8684534D
	s_waitcnt lgkmcnt(2)                                       // 000000012C1C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000012C20: BF870131
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[57:64], v[25:32]// 000000012C24: CC404019 1C667329
	s_waitcnt lgkmcnt(0)                                       // 000000012C2C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[57:64], v[17:24]// 000000012C30: CC404011 1C467321
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[49:56], v[25:32]// 000000012C38: CC404019 1C666329
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000012C40: BF8701C2
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[49:56], v[17:24]// 000000012C44: CC404011 1C466321
	v_dual_mul_f32 v49, 0x3b800000, v100 :: v_dual_mul_f32 v50, 0x3b800000, v99// 000000012C4C: C8C6C8FF 3132C6FF 3B800000
	v_dual_mul_f32 v51, 0x3b800000, v98 :: v_dual_mul_f32 v52, 0x3b800000, v97// 000000012C58: C8C6C4FF 3334C2FF 3B800000
	v_mul_f32_e32 v53, 0x3b800000, v96                         // 000000012C64: 106AC0FF 3B800000
	v_dual_mov_b32 v57, v49 :: v_dual_mul_f32 v54, 0x3b800000, v95// 000000012C6C: CA060131 3936BEFF 3B800000
	v_dual_mul_f32 v55, 0x3b800000, v94 :: v_dual_mul_f32 v56, 0x3b800000, v149// 000000012C78: C8C6BCFF 37392AFF 3B800000
	ds_load_b128 v[45:48], v160 offset:15024                   // 000000012C84: DBFC3AB0 2D0000A0
	ds_load_b128 v[41:44], v160 offset:15008                   // 000000012C8C: DBFC3AA0 290000A0
	ds_load_b128 v[37:40], v160 offset:10672                   // 000000012C94: DBFC29B0 250000A0
	ds_load_b128 v[33:36], v160 offset:10656                   // 000000012C9C: DBFC29A0 210000A0
	v_permlanex16_b32 v57, v57, s42, 0xfedcba98                // 000000012CA4: D65C0039 03FC5539 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012CB0: BF870121
	v_cndmask_b32_e32 v58, v57, v49, vcc_lo                    // 000000012CB4: 02746339
	v_cndmask_b32_e32 v59, v49, v57, vcc_lo                    // 000000012CB8: 02767331
	v_fma_mixlo_f16 v49, v58, s41, 0                           // 000000012CBC: CC210031 0200533A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012CC4: BF870112
	v_fma_mixlo_f16 v64, v59, s41, 0                           // 000000012CC8: CC210040 0200533B
	v_fma_mixlo_f16 v57, v58, s41, -v49 op_sel_hi:[0,0,1]      // 000000012CD0: CC214039 84C4533A
	v_mov_b32_e32 v58, v50                                     // 000000012CD8: 7E740332
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012CDC: BF8701A3
	v_fma_mixhi_f16 v57, v59, s41, -v64 op_sel_hi:[0,0,1]      // 000000012CE0: CC224039 8500533B
	.long 0x7f623940                                           // 000000012CE8: 7F623940
	v_permlanex16_b32 v58, v58, s42, 0xfedcba98                // 000000012CEC: D65C003A 03FC553A FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012CF8: BF870121
	v_cndmask_b32_e32 v59, v58, v50, vcc_lo                    // 000000012CFC: 0276653A
	v_cndmask_b32_e32 v60, v50, v58, vcc_lo                    // 000000012D00: 02787532
	v_fma_mixlo_f16 v50, v59, s41, 0                           // 000000012D04: CC210032 0200533B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012D0C: BF870112
	v_fma_mixlo_f16 v73, v60, s41, 0                           // 000000012D10: CC210049 0200533C
	v_fma_mixlo_f16 v58, v59, s41, -v50 op_sel_hi:[0,0,1]      // 000000012D18: CC21403A 84C8533B
	v_mov_b32_e32 v59, v51                                     // 000000012D20: 7E760333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012D24: BF8701A3
	v_fma_mixhi_f16 v58, v60, s41, -v73 op_sel_hi:[0,0,1]      // 000000012D28: CC22403A 8524533C
	.long 0x7f643949                                           // 000000012D30: 7F643949
	v_permlanex16_b32 v59, v59, s42, 0xfedcba98                // 000000012D34: D65C003B 03FC553B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012D40: BF870121
	v_cndmask_b32_e32 v60, v59, v51, vcc_lo                    // 000000012D44: 0278673B
	v_cndmask_b32_e32 v61, v51, v59, vcc_lo                    // 000000012D48: 027A7733
	v_fma_mixlo_f16 v51, v60, s41, 0                           // 000000012D4C: CC210033 0200533C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012D54: BF870112
	v_fma_mixlo_f16 v74, v61, s41, 0                           // 000000012D58: CC21004A 0200533D
	v_fma_mixlo_f16 v59, v60, s41, -v51 op_sel_hi:[0,0,1]      // 000000012D60: CC21403B 84CC533C
	v_mov_b32_e32 v60, v52                                     // 000000012D68: 7E780334
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012D6C: BF8701A3
	v_fma_mixhi_f16 v59, v61, s41, -v74 op_sel_hi:[0,0,1]      // 000000012D70: CC22403B 8528533D
	.long 0x7f66394a                                           // 000000012D78: 7F66394A
	v_permlanex16_b32 v60, v60, s42, 0xfedcba98                // 000000012D7C: D65C003C 03FC553C FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012D88: BF870121
	v_cndmask_b32_e32 v61, v60, v52, vcc_lo                    // 000000012D8C: 027A693C
	v_cndmask_b32_e32 v62, v52, v60, vcc_lo                    // 000000012D90: 027C7934
	v_fma_mixlo_f16 v52, v61, s41, 0                           // 000000012D94: CC210034 0200533D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012D9C: BF870112
	v_fma_mixlo_f16 v75, v62, s41, 0                           // 000000012DA0: CC21004B 0200533E
	v_fma_mixlo_f16 v60, v61, s41, -v52 op_sel_hi:[0,0,1]      // 000000012DA8: CC21403C 84D0533D
	v_mov_b32_e32 v61, v53                                     // 000000012DB0: 7E7A0335
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012DB4: BF8701A3
	v_fma_mixhi_f16 v60, v62, s41, -v75 op_sel_hi:[0,0,1]      // 000000012DB8: CC22403C 852C533E
	.long 0x7f68394b                                           // 000000012DC0: 7F68394B
	v_permlanex16_b32 v61, v61, s42, 0xfedcba98                // 000000012DC4: D65C003D 03FC553D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012DD0: BF870121
	v_cndmask_b32_e32 v62, v61, v53, vcc_lo                    // 000000012DD4: 027C6B3D
	v_cndmask_b32_e32 v63, v53, v61, vcc_lo                    // 000000012DD8: 027E7B35
	v_fma_mixlo_f16 v53, v62, s41, 0                           // 000000012DDC: CC210035 0200533E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012DE4: BF870112
	v_fma_mixlo_f16 v76, v63, s41, 0                           // 000000012DE8: CC21004C 0200533F
	v_fma_mixlo_f16 v61, v62, s41, -v53 op_sel_hi:[0,0,1]      // 000000012DF0: CC21403D 84D4533E
	v_mov_b32_e32 v62, v54                                     // 000000012DF8: 7E7C0336
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012DFC: BF8701A3
	v_fma_mixhi_f16 v61, v63, s41, -v76 op_sel_hi:[0,0,1]      // 000000012E00: CC22403D 8530533F
	.long 0x7f6a394c                                           // 000000012E08: 7F6A394C
	v_permlanex16_b32 v62, v62, s42, 0xfedcba98                // 000000012E0C: D65C003E 03FC553E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012E18: BF870121
	v_cndmask_b32_e32 v63, v62, v54, vcc_lo                    // 000000012E1C: 027E6D3E
	v_cndmask_b32_e32 v77, v54, v62, vcc_lo                    // 000000012E20: 029A7D36
	v_fma_mixlo_f16 v54, v63, s41, 0                           // 000000012E24: CC210036 0200533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012E2C: BF870112
	v_fma_mixlo_f16 v78, v77, s41, 0                           // 000000012E30: CC21004E 0200534D
	v_fma_mixlo_f16 v62, v63, s41, -v54 op_sel_hi:[0,0,1]      // 000000012E38: CC21403E 84D8533F
	v_mov_b32_e32 v63, v55                                     // 000000012E40: 7E7E0337
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012E44: BF8701A3
	v_fma_mixhi_f16 v62, v77, s41, -v78 op_sel_hi:[0,0,1]      // 000000012E48: CC22403E 8538534D
	.long 0x7f6c394e                                           // 000000012E50: 7F6C394E
	v_permlanex16_b32 v63, v63, s42, 0xfedcba98                // 000000012E54: D65C003F 03FC553F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012E60: BF870121
	v_cndmask_b32_e32 v77, v63, v55, vcc_lo                    // 000000012E64: 029A6F3F
	v_cndmask_b32_e32 v79, v55, v63, vcc_lo                    // 000000012E68: 029E7F37
	v_fma_mixlo_f16 v55, v77, s41, 0                           // 000000012E6C: CC210037 0200534D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012E74: BF870112
	v_fma_mixlo_f16 v80, v79, s41, 0                           // 000000012E78: CC210050 0200534F
	v_fma_mixlo_f16 v63, v77, s41, -v55 op_sel_hi:[0,0,1]      // 000000012E80: CC21403F 84DC534D
	v_mov_b32_e32 v77, v56                                     // 000000012E88: 7E9A0338
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012E8C: BF8701A3
	v_fma_mixhi_f16 v63, v79, s41, -v80 op_sel_hi:[0,0,1]      // 000000012E90: CC22403F 8540534F
	.long 0x7f6e3950                                           // 000000012E98: 7F6E3950
	v_permlanex16_b32 v77, v77, s42, 0xfedcba98                // 000000012E9C: D65C004D 03FC554D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012EA8: BF870121
	v_cndmask_b32_e32 v79, v77, v56, vcc_lo                    // 000000012EAC: 029E714D
	v_cndmask_b32_e32 v77, v56, v77, vcc_lo                    // 000000012EB0: 029A9B38
	v_fma_mixlo_f16 v56, v79, s41, 0                           // 000000012EB4: CC210038 0200534F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000012EBC: BF870092
	v_fma_mixhi_f16 v56, v77, s41, 0                           // 000000012EC0: CC220038 0200534D
	.long 0xd59c08a1                                           // 000000012EC8: D59C08A1
	v_cndmask_b32_e32 v0, v56, v128, vcc_lo                    // 000000012ECC: 02010138
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012ED0: BF870113
	v_fma_mixlo_f16 v64, v79, s41, -v56 op_sel_hi:[0,0,1]      // 000000012ED4: CC214040 84E0534F
	v_fma_mixhi_f16 v64, v77, s41, -v161 op_sel_hi:[0,0,1]     // 000000012EDC: CC224040 8684534D
	s_waitcnt lgkmcnt(2)                                       // 000000012EE4: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000012EE8: BF870131
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[57:64], v[25:32]// 000000012EEC: CC404019 1C667329
	s_waitcnt lgkmcnt(0)                                       // 000000012EF4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[57:64], v[17:24]// 000000012EF8: CC404011 1C467321
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[49:56], v[25:32]// 000000012F00: CC404019 1C666329
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000012F08: BF8701C2
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[49:56], v[17:24]// 000000012F0C: CC404011 1C466321
	v_dual_mul_f32 v49, 0x3b800000, v93 :: v_dual_mul_f32 v50, 0x3b800000, v92// 000000012F14: C8C6BAFF 3132B8FF 3B800000
	v_dual_mul_f32 v51, 0x3b800000, v91 :: v_dual_mul_f32 v52, 0x3b800000, v90// 000000012F20: C8C6B6FF 3334B4FF 3B800000
	v_mul_f32_e32 v53, 0x3b800000, v89                         // 000000012F2C: 106AB2FF 3B800000
	v_dual_mov_b32 v57, v49 :: v_dual_mul_f32 v54, 0x3b800000, v88// 000000012F34: CA060131 3936B0FF 3B800000
	v_dual_mul_f32 v55, 0x3b800000, v87 :: v_dual_mul_f32 v56, 0x3b800000, v148// 000000012F40: C8C6AEFF 373928FF 3B800000
	ds_load_b128 v[45:48], v160 offset:15056                   // 000000012F4C: DBFC3AD0 2D0000A0
	ds_load_b128 v[41:44], v160 offset:15040                   // 000000012F54: DBFC3AC0 290000A0
	ds_load_b128 v[37:40], v160 offset:10704                   // 000000012F5C: DBFC29D0 250000A0
	ds_load_b128 v[33:36], v160 offset:10688                   // 000000012F64: DBFC29C0 210000A0
	v_permlanex16_b32 v57, v57, s42, 0xfedcba98                // 000000012F6C: D65C0039 03FC5539 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012F78: BF870121
	v_cndmask_b32_e32 v58, v57, v49, vcc_lo                    // 000000012F7C: 02746339
	v_cndmask_b32_e32 v59, v49, v57, vcc_lo                    // 000000012F80: 02767331
	v_fma_mixlo_f16 v49, v58, s41, 0                           // 000000012F84: CC210031 0200533A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012F8C: BF870112
	v_fma_mixlo_f16 v64, v59, s41, 0                           // 000000012F90: CC210040 0200533B
	v_fma_mixlo_f16 v57, v58, s41, -v49 op_sel_hi:[0,0,1]      // 000000012F98: CC214039 84C4533A
	v_mov_b32_e32 v58, v50                                     // 000000012FA0: 7E740332
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012FA4: BF8701A3
	v_fma_mixhi_f16 v57, v59, s41, -v64 op_sel_hi:[0,0,1]      // 000000012FA8: CC224039 8500533B
	.long 0x7f623940                                           // 000000012FB0: 7F623940
	v_permlanex16_b32 v58, v58, s42, 0xfedcba98                // 000000012FB4: D65C003A 03FC553A FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000012FC0: BF870121
	v_cndmask_b32_e32 v59, v58, v50, vcc_lo                    // 000000012FC4: 0276653A
	v_cndmask_b32_e32 v60, v50, v58, vcc_lo                    // 000000012FC8: 02787532
	v_fma_mixlo_f16 v50, v59, s41, 0                           // 000000012FCC: CC210032 0200533B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000012FD4: BF870112
	v_fma_mixlo_f16 v73, v60, s41, 0                           // 000000012FD8: CC210049 0200533C
	v_fma_mixlo_f16 v58, v59, s41, -v50 op_sel_hi:[0,0,1]      // 000000012FE0: CC21403A 84C8533B
	v_mov_b32_e32 v59, v51                                     // 000000012FE8: 7E760333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000012FEC: BF8701A3
	v_fma_mixhi_f16 v58, v60, s41, -v73 op_sel_hi:[0,0,1]      // 000000012FF0: CC22403A 8524533C
	.long 0x7f643949                                           // 000000012FF8: 7F643949
	v_permlanex16_b32 v59, v59, s42, 0xfedcba98                // 000000012FFC: D65C003B 03FC553B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000013008: BF870121
	v_cndmask_b32_e32 v60, v59, v51, vcc_lo                    // 00000001300C: 0278673B
	v_cndmask_b32_e32 v61, v51, v59, vcc_lo                    // 000000013010: 027A7733
	v_fma_mixlo_f16 v51, v60, s41, 0                           // 000000013014: CC210033 0200533C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001301C: BF870112
	v_fma_mixlo_f16 v74, v61, s41, 0                           // 000000013020: CC21004A 0200533D
	v_fma_mixlo_f16 v59, v60, s41, -v51 op_sel_hi:[0,0,1]      // 000000013028: CC21403B 84CC533C
	v_mov_b32_e32 v60, v52                                     // 000000013030: 7E780334
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000013034: BF8701A3
	v_fma_mixhi_f16 v59, v61, s41, -v74 op_sel_hi:[0,0,1]      // 000000013038: CC22403B 8528533D
	.long 0x7f66394a                                           // 000000013040: 7F66394A
	v_permlanex16_b32 v60, v60, s42, 0xfedcba98                // 000000013044: D65C003C 03FC553C FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000013050: BF870121
	v_cndmask_b32_e32 v61, v60, v52, vcc_lo                    // 000000013054: 027A693C
	v_cndmask_b32_e32 v62, v52, v60, vcc_lo                    // 000000013058: 027C7934
	v_fma_mixlo_f16 v52, v61, s41, 0                           // 00000001305C: CC210034 0200533D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000013064: BF870112
	v_fma_mixlo_f16 v75, v62, s41, 0                           // 000000013068: CC21004B 0200533E
	v_fma_mixlo_f16 v60, v61, s41, -v52 op_sel_hi:[0,0,1]      // 000000013070: CC21403C 84D0533D
	v_mov_b32_e32 v61, v53                                     // 000000013078: 7E7A0335
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001307C: BF8701A3
	v_fma_mixhi_f16 v60, v62, s41, -v75 op_sel_hi:[0,0,1]      // 000000013080: CC22403C 852C533E
	.long 0x7f68394b                                           // 000000013088: 7F68394B
	v_permlanex16_b32 v61, v61, s42, 0xfedcba98                // 00000001308C: D65C003D 03FC553D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000013098: BF870121
	v_cndmask_b32_e32 v62, v61, v53, vcc_lo                    // 00000001309C: 027C6B3D
	v_cndmask_b32_e32 v63, v53, v61, vcc_lo                    // 0000000130A0: 027E7B35
	v_fma_mixlo_f16 v53, v62, s41, 0                           // 0000000130A4: CC210035 0200533E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000130AC: BF870112
	v_fma_mixlo_f16 v76, v63, s41, 0                           // 0000000130B0: CC21004C 0200533F
	v_fma_mixlo_f16 v61, v62, s41, -v53 op_sel_hi:[0,0,1]      // 0000000130B8: CC21403D 84D4533E
	v_mov_b32_e32 v62, v54                                     // 0000000130C0: 7E7C0336
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000130C4: BF8701A3
	v_fma_mixhi_f16 v61, v63, s41, -v76 op_sel_hi:[0,0,1]      // 0000000130C8: CC22403D 8530533F
	.long 0x7f6a394c                                           // 0000000130D0: 7F6A394C
	v_permlanex16_b32 v62, v62, s42, 0xfedcba98                // 0000000130D4: D65C003E 03FC553E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000130E0: BF870121
	v_cndmask_b32_e32 v63, v62, v54, vcc_lo                    // 0000000130E4: 027E6D3E
	v_cndmask_b32_e32 v77, v54, v62, vcc_lo                    // 0000000130E8: 029A7D36
	v_fma_mixlo_f16 v54, v63, s41, 0                           // 0000000130EC: CC210036 0200533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000130F4: BF870112
	v_fma_mixlo_f16 v78, v77, s41, 0                           // 0000000130F8: CC21004E 0200534D
	v_fma_mixlo_f16 v62, v63, s41, -v54 op_sel_hi:[0,0,1]      // 000000013100: CC21403E 84D8533F
	v_mov_b32_e32 v63, v55                                     // 000000013108: 7E7E0337
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001310C: BF8701A3
	v_fma_mixhi_f16 v62, v77, s41, -v78 op_sel_hi:[0,0,1]      // 000000013110: CC22403E 8538534D
	.long 0x7f6c394e                                           // 000000013118: 7F6C394E
	v_permlanex16_b32 v63, v63, s42, 0xfedcba98                // 00000001311C: D65C003F 03FC553F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000013128: BF870121
	v_cndmask_b32_e32 v77, v63, v55, vcc_lo                    // 00000001312C: 029A6F3F
	v_cndmask_b32_e32 v79, v55, v63, vcc_lo                    // 000000013130: 029E7F37
	v_fma_mixlo_f16 v55, v77, s41, 0                           // 000000013134: CC210037 0200534D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001313C: BF870112
	v_fma_mixlo_f16 v80, v79, s41, 0                           // 000000013140: CC210050 0200534F
	v_fma_mixlo_f16 v63, v77, s41, -v55 op_sel_hi:[0,0,1]      // 000000013148: CC21403F 84DC534D
	v_mov_b32_e32 v77, v56                                     // 000000013150: 7E9A0338
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000013154: BF8701A3
	v_fma_mixhi_f16 v63, v79, s41, -v80 op_sel_hi:[0,0,1]      // 000000013158: CC22403F 8540534F
	.long 0x7f6e3950                                           // 000000013160: 7F6E3950
	v_permlanex16_b32 v77, v77, s42, 0xfedcba98                // 000000013164: D65C004D 03FC554D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000013170: BF870121
	v_cndmask_b32_e32 v79, v77, v56, vcc_lo                    // 000000013174: 029E714D
	v_cndmask_b32_e32 v77, v56, v77, vcc_lo                    // 000000013178: 029A9B38
	v_fma_mixlo_f16 v56, v79, s41, 0                           // 00000001317C: CC210038 0200534F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013184: BF870092
	v_fma_mixhi_f16 v56, v77, s41, 0                           // 000000013188: CC220038 0200534D
	.long 0xd59c08a1                                           // 000000013190: D59C08A1
	v_cndmask_b32_e32 v0, v56, v128, vcc_lo                    // 000000013194: 02010138
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000013198: BF870113
	v_fma_mixlo_f16 v64, v79, s41, -v56 op_sel_hi:[0,0,1]      // 00000001319C: CC214040 84E0534F
	v_fma_mixhi_f16 v64, v77, s41, -v161 op_sel_hi:[0,0,1]     // 0000000131A4: CC224040 8684534D
	s_waitcnt lgkmcnt(2)                                       // 0000000131AC: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000131B0: BF870131
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[57:64], v[25:32]// 0000000131B4: CC404019 1C667329
	s_waitcnt lgkmcnt(0)                                       // 0000000131BC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[57:64], v[17:24]// 0000000131C0: CC404011 1C467321
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[49:56], v[25:32]// 0000000131C8: CC404019 1C666329
	v_dual_mul_f32 v41, 0x3b800000, v86 :: v_dual_mul_f32 v42, 0x3b800000, v85// 0000000131D0: C8C6ACFF 292AAAFF 3B800000
	v_dual_mul_f32 v43, 0x3b800000, v84 :: v_dual_mul_f32 v44, 0x3b800000, v83// 0000000131DC: C8C6A8FF 2B2CA6FF 3B800000
	v_mul_f32_e32 v45, 0x3b800000, v82                         // 0000000131E8: 105AA4FF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000131F0: BF8701B3
	v_dual_mov_b32 v57, v41 :: v_dual_mul_f32 v46, 0x3b800000, v81// 0000000131F4: CA060129 392EA2FF 3B800000
	v_dual_mul_f32 v47, 0x3b800000, v141 :: v_dual_mul_f32 v48, 0x3b800000, v147// 000000013200: C8C71AFF 2F3126FF 3B800000
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[49:56], v[17:24]// 00000001320C: CC404011 1C466321
	v_permlanex16_b32 v57, v57, s42, 0xfedcba98                // 000000013214: D65C0039 03FC5539 FEDCBA98
	ds_load_b128 v[53:56], v160 offset:15088                   // 000000013220: DBFC3AF0 350000A0
	ds_load_b128 v[49:52], v160 offset:15072                   // 000000013228: DBFC3AE0 310000A0
	ds_load_b128 v[37:40], v160 offset:10736                   // 000000013230: DBFC29F0 250000A0
	ds_load_b128 v[33:36], v160 offset:10720                   // 000000013238: DBFC29E0 210000A0
	v_cndmask_b32_e32 v58, v57, v41, vcc_lo                    // 000000013240: 02745339
	v_cndmask_b32_e32 v59, v41, v57, vcc_lo                    // 000000013244: 02767329
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000013248: BF870112
	v_fma_mixlo_f16 v41, v58, s41, 0                           // 00000001324C: CC210029 0200533A
	v_fma_mixlo_f16 v64, v59, s41, 0                           // 000000013254: CC210040 0200533B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001325C: BF8701A2
	v_fma_mixlo_f16 v57, v58, s41, -v41 op_sel_hi:[0,0,1]      // 000000013260: CC214039 84A4533A
	v_mov_b32_e32 v58, v42                                     // 000000013268: 7E74032A
	v_fma_mixhi_f16 v57, v59, s41, -v64 op_sel_hi:[0,0,1]      // 00000001326C: CC224039 8500533B
	.long 0x7f523940                                           // 000000013274: 7F523940
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013278: BF870093
	v_permlanex16_b32 v58, v58, s42, 0xfedcba98                // 00000001327C: D65C003A 03FC553A FEDCBA98
	v_cndmask_b32_e32 v59, v58, v42, vcc_lo                    // 000000013288: 0276553A
	v_cndmask_b32_e32 v60, v42, v58, vcc_lo                    // 00000001328C: 0278752A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000013290: BF870112
	v_fma_mixlo_f16 v42, v59, s41, 0                           // 000000013294: CC21002A 0200533B
	v_fma_mixlo_f16 v73, v60, s41, 0                           // 00000001329C: CC210049 0200533C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000132A4: BF8701A2
	v_fma_mixlo_f16 v58, v59, s41, -v42 op_sel_hi:[0,0,1]      // 0000000132A8: CC21403A 84A8533B
	v_mov_b32_e32 v59, v43                                     // 0000000132B0: 7E76032B
	v_fma_mixhi_f16 v58, v60, s41, -v73 op_sel_hi:[0,0,1]      // 0000000132B4: CC22403A 8524533C
	.long 0x7f543949                                           // 0000000132BC: 7F543949
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000132C0: BF870093
	v_permlanex16_b32 v59, v59, s42, 0xfedcba98                // 0000000132C4: D65C003B 03FC553B FEDCBA98
	v_cndmask_b32_e32 v60, v59, v43, vcc_lo                    // 0000000132D0: 0278573B
	v_cndmask_b32_e32 v61, v43, v59, vcc_lo                    // 0000000132D4: 027A772B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000132D8: BF870112
	v_fma_mixlo_f16 v43, v60, s41, 0                           // 0000000132DC: CC21002B 0200533C
	v_fma_mixlo_f16 v74, v61, s41, 0                           // 0000000132E4: CC21004A 0200533D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000132EC: BF8701A2
	v_fma_mixlo_f16 v59, v60, s41, -v43 op_sel_hi:[0,0,1]      // 0000000132F0: CC21403B 84AC533C
	v_mov_b32_e32 v60, v44                                     // 0000000132F8: 7E78032C
	v_fma_mixhi_f16 v59, v61, s41, -v74 op_sel_hi:[0,0,1]      // 0000000132FC: CC22403B 8528533D
	.long 0x7f56394a                                           // 000000013304: 7F56394A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013308: BF870093
	v_permlanex16_b32 v60, v60, s42, 0xfedcba98                // 00000001330C: D65C003C 03FC553C FEDCBA98
	v_cndmask_b32_e32 v61, v60, v44, vcc_lo                    // 000000013318: 027A593C
	v_cndmask_b32_e32 v62, v44, v60, vcc_lo                    // 00000001331C: 027C792C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000013320: BF870112
	v_fma_mixlo_f16 v44, v61, s41, 0                           // 000000013324: CC21002C 0200533D
	v_fma_mixlo_f16 v75, v62, s41, 0                           // 00000001332C: CC21004B 0200533E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000013334: BF8701A2
	v_fma_mixlo_f16 v60, v61, s41, -v44 op_sel_hi:[0,0,1]      // 000000013338: CC21403C 84B0533D
	v_mov_b32_e32 v61, v45                                     // 000000013340: 7E7A032D
	v_fma_mixhi_f16 v60, v62, s41, -v75 op_sel_hi:[0,0,1]      // 000000013344: CC22403C 852C533E
	.long 0x7f58394b                                           // 00000001334C: 7F58394B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013350: BF870093
	v_permlanex16_b32 v61, v61, s42, 0xfedcba98                // 000000013354: D65C003D 03FC553D FEDCBA98
	v_cndmask_b32_e32 v62, v61, v45, vcc_lo                    // 000000013360: 027C5B3D
	v_cndmask_b32_e32 v63, v45, v61, vcc_lo                    // 000000013364: 027E7B2D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000013368: BF870112
	v_fma_mixlo_f16 v45, v62, s41, 0                           // 00000001336C: CC21002D 0200533E
	v_fma_mixlo_f16 v76, v63, s41, 0                           // 000000013374: CC21004C 0200533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001337C: BF8701A2
	v_fma_mixlo_f16 v61, v62, s41, -v45 op_sel_hi:[0,0,1]      // 000000013380: CC21403D 84B4533E
	v_mov_b32_e32 v62, v46                                     // 000000013388: 7E7C032E
	v_fma_mixhi_f16 v61, v63, s41, -v76 op_sel_hi:[0,0,1]      // 00000001338C: CC22403D 8530533F
	.long 0x7f5a394c                                           // 000000013394: 7F5A394C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013398: BF870093
	v_permlanex16_b32 v62, v62, s42, 0xfedcba98                // 00000001339C: D65C003E 03FC553E FEDCBA98
	v_cndmask_b32_e32 v63, v62, v46, vcc_lo                    // 0000000133A8: 027E5D3E
	v_cndmask_b32_e32 v77, v46, v62, vcc_lo                    // 0000000133AC: 029A7D2E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000133B0: BF870112
	v_fma_mixlo_f16 v46, v63, s41, 0                           // 0000000133B4: CC21002E 0200533F
	v_fma_mixlo_f16 v78, v77, s41, 0                           // 0000000133BC: CC21004E 0200534D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000133C4: BF8701A2
	v_fma_mixlo_f16 v62, v63, s41, -v46 op_sel_hi:[0,0,1]      // 0000000133C8: CC21403E 84B8533F
	v_mov_b32_e32 v63, v47                                     // 0000000133D0: 7E7E032F
	v_fma_mixhi_f16 v62, v77, s41, -v78 op_sel_hi:[0,0,1]      // 0000000133D4: CC22403E 8538534D
	.long 0x7f5c394e                                           // 0000000133DC: 7F5C394E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000133E0: BF870093
	v_permlanex16_b32 v63, v63, s42, 0xfedcba98                // 0000000133E4: D65C003F 03FC553F FEDCBA98
	v_cndmask_b32_e32 v77, v63, v47, vcc_lo                    // 0000000133F0: 029A5F3F
	v_cndmask_b32_e32 v79, v47, v63, vcc_lo                    // 0000000133F4: 029E7F2F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000133F8: BF870112
	v_fma_mixlo_f16 v47, v77, s41, 0                           // 0000000133FC: CC21002F 0200534D
	v_fma_mixlo_f16 v80, v79, s41, 0                           // 000000013404: CC210050 0200534F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001340C: BF8701A2
	v_fma_mixlo_f16 v63, v77, s41, -v47 op_sel_hi:[0,0,1]      // 000000013410: CC21403F 84BC534D
	v_mov_b32_e32 v77, v48                                     // 000000013418: 7E9A0330
	v_fma_mixhi_f16 v63, v79, s41, -v80 op_sel_hi:[0,0,1]      // 00000001341C: CC22403F 8540534F
	.long 0x7f5e3950                                           // 000000013424: 7F5E3950
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013428: BF870093
	v_permlanex16_b32 v77, v77, s42, 0xfedcba98                // 00000001342C: D65C004D 03FC554D FEDCBA98
	v_cndmask_b32_e32 v79, v77, v48, vcc_lo                    // 000000013438: 029E614D
	v_cndmask_b32_e32 v77, v48, v77, vcc_lo                    // 00000001343C: 029A9B30
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000013440: BF870112
	v_fma_mixlo_f16 v48, v79, s41, 0                           // 000000013444: CC210030 0200534F
	v_fma_mixhi_f16 v48, v77, s41, 0                           // 00000001344C: CC220030 0200534D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000013454: BF870191
	.long 0xd59c08a0                                           // 000000013458: D59C08A0
	v_cndmask_b32_e32 v0, v48, v128, vcc_lo                    // 00000001345C: 02010130
	v_fma_mixlo_f16 v64, v79, s41, -v48 op_sel_hi:[0,0,1]      // 000000013460: CC214040 84C0534F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000013468: BF8700A2
	v_fma_mixhi_f16 v64, v77, s41, -v160 op_sel_hi:[0,0,1]     // 00000001346C: CC224040 8680534D
	s_waitcnt lgkmcnt(2)                                       // 000000013474: BF89FC27
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[57:64], v[25:32]// 000000013478: CC404019 1C667331
	s_waitcnt lgkmcnt(0)                                       // 000000013480: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[57:64], v[17:24]// 000000013484: CC404011 1C467321
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001348C: BF8701A2
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[41:48], v[25:32]// 000000013490: CC404019 1C665331
	v_or_b32_e32 v49, s44, v157                                // 000000013498: 38633A2C
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[41:48], v[17:24]// 00000001349C: CC404011 1C465321
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000134A4: BF870193
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 0000000134A8: 103232FF 3B800000
	.long 0xd4440000                                           // 0000000134B0: D4440000
	v_cndmask_b32_e32 v1, s29, v49, vcc_lo                     // 0000000134B4: 0202621D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000134B8: BF870092
	v_sub_f32_e32 v9, v9, v25                                  // 0000000134BC: 08123309
	v_fma_mixlo_f16 v9, v9, s41, 0                             // 0000000134C0: CC210009 02005309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000134C8: BF8700A1
	v_cndmask_b16 v25, 0, v9, s0                               // 0000000134CC: D65D0019 00021280
	v_or_b32_e32 v9, 2, v49                                    // 0000000134D4: 38126282
	.long 0xd4440001                                           // 0000000134D8: D4440001
	v_cndmask_b32_e32 v1, s29, v9, vcc_lo                      // 0000000134DC: 0202121D
	v_mul_f32_e32 v9, 0x3b800000, v26                          // 0000000134E0: 101234FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000134E8: BF870091
	v_sub_f32_e32 v9, v10, v9                                  // 0000000134EC: 0812130A
	v_fma_mixlo_f16 v9, v9, s41, 0                             // 0000000134F0: CC210009 02005309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000134F8: BF8700A1
	v_cndmask_b16 v25, 0, v9, s1                               // 0000000134FC: D65D4019 00061280
	v_or_b32_e32 v9, 4, v49                                    // 000000013504: 38126284
	.long 0xd4440001                                           // 000000013508: D4440001
	v_cndmask_b32_e32 v1, s29, v9, vcc_lo                      // 00000001350C: 0202121D
	v_mul_f32_e32 v9, 0x3b800000, v27                          // 000000013510: 101236FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013518: BF870091
	v_sub_f32_e32 v9, v11, v9                                  // 00000001351C: 0812130B
	v_fma_mixlo_f16 v9, v9, s41, 0                             // 000000013520: CC210009 02005309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000013528: BF8700A1
	v_cndmask_b16 v10, 0, v9, s1                               // 00000001352C: D65D000A 00061280
	v_or_b32_e32 v9, 6, v49                                    // 000000013534: 38126286
	.long 0xd4440001                                           // 000000013538: D4440001
	v_cndmask_b32_e32 v1, s29, v9, vcc_lo                      // 00000001353C: 0202121D
	v_mul_f32_e32 v9, 0x3b800000, v28                          // 000000013540: 101238FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013548: BF870091
	v_sub_f32_e32 v9, v12, v9                                  // 00000001354C: 0812130C
	v_fma_mixlo_f16 v9, v9, s41, 0                             // 000000013550: CC210009 02005309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000013558: BF8700A1
	v_cndmask_b16 v10, 0, v9, s1                               // 00000001355C: D65D400A 00061280
	v_or_b32_e32 v9, 8, v49                                    // 000000013564: 38126288
	.long 0xd4440001                                           // 000000013568: D4440001
	v_cndmask_b32_e32 v1, s29, v9, vcc_lo                      // 00000001356C: 0202121D
	v_mul_f32_e32 v9, 0x3b800000, v29                          // 000000013570: 10123AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000013578: BF870121
	v_sub_f32_e32 v9, v13, v9                                  // 00000001357C: 0812130D
	v_mov_b32_e32 v13, 0x3020706                               // 000000013580: 7E1A02FF 03020706
	v_fma_mixlo_f16 v9, v9, s41, 0                             // 000000013588: CC210009 02005309
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000013590: BF870112
	v_cndmask_b32_e32 v13, 0x7060302, v13, vcc_lo              // 000000013594: 021A1AFF 07060302
	v_cndmask_b16 v11, 0, v9, s1                               // 00000001359C: D65D000B 00061280
	v_or_b32_e32 v9, 10, v49                                   // 0000000135A4: 3812628A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000135A8: BF8700A1
	.long 0xd4440001                                           // 0000000135AC: D4440001
	v_cndmask_b32_e32 v1, s29, v9, vcc_lo                      // 0000000135B0: 0202121D
	v_mul_f32_e32 v9, 0x3b800000, v30                          // 0000000135B4: 10123CFF 3B800000
	v_dual_sub_f32 v9, v14, v9 :: v_dual_mov_b32 v14, v25      // 0000000135BC: C950130E 090E0119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000135C4: BF870111
	v_fma_mixlo_f16 v9, v9, s41, 0                             // 0000000135C8: CC210009 02005309
	v_permlanex16_b32 v14, v14, s42, 0xfedcba98                // 0000000135D0: D65C000E 03FC550E FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000135DC: BF8701A2
	v_cndmask_b16 v11, 0, v9, s1                               // 0000000135E0: D65D400B 00061280
	v_or_b32_e32 v9, 12, v49                                   // 0000000135E8: 3812628C
	v_perm_b32 v55, v25, v14, v13                              // 0000000135EC: D6440037 04361D19
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000135F4: BF8700A2
	.long 0xd4440001                                           // 0000000135F8: D4440001
	v_cndmask_b32_e32 v1, s29, v9, vcc_lo                      // 0000000135FC: 0202121D
	v_mul_f32_e32 v9, 0x3b800000, v31                          // 000000013600: 10123EFF 3B800000
	v_sub_f32_e32 v9, v15, v9                                  // 000000013608: 0812130F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001360C: BF870091
	v_fma_mixlo_f16 v9, v9, s41, 0                             // 000000013610: CC210009 02005309
	v_cndmask_b16 v12, 0, v9, s1                               // 000000013618: D65D000C 00061280
	v_or_b32_e32 v9, 14, v49                                   // 000000013620: 3812628E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000013624: BF8700A1
	.long 0xd4440001                                           // 000000013628: D4440001
	v_cndmask_b32_e32 v1, s29, v9, vcc_lo                      // 00000001362C: 0202121D
	v_mul_f32_e32 v9, 0x3b800000, v32                          // 000000013630: 101240FF 3B800000
	v_sub_f32_e32 v9, v16, v9                                  // 000000013638: 08121310
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001363C: BF870091
	v_fma_mixlo_f16 v9, v9, s41, 0                             // 000000013640: CC210009 02005309
	v_cndmask_b16 v12, 0, v9, s1                               // 000000013648: D65D400C 00061280
	v_cndmask_b32_e32 v9, 0x5040100, v145, vcc_lo              // 000000013650: 021322FF 05040100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000013658: BF8700D1
	v_perm_b32 v54, v25, v14, v9                               // 00000001365C: D6440036 04261D19
	v_mov_b32_e32 v14, v10                                     // 000000013664: 7E1C030A
	ds_load_b128 v[25:28], v159 offset:23296                   // 000000013668: DBFC5B00 1900009F
	ds_load_b128 v[29:32], v159 offset:23312                   // 000000013670: DBFC5B10 1D00009F
	v_permlanex16_b32 v14, v14, s42, 0xfedcba98                // 000000013678: D65C000E 03FC550E FEDCBA98
	v_perm_b32 v56, v10, v14, v9                               // 000000013684: D6440038 04261D0A
	v_perm_b32 v57, v10, v14, v13                              // 00000001368C: D6440039 04361D0A
	v_mov_b32_e32 v10, v11                                     // 000000013694: 7E14030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013698: BF870091
	v_permlanex16_b32 v10, v10, s42, 0xfedcba98                // 00000001369C: D65C000A 03FC550A FEDCBA98
	v_perm_b32 v58, v11, v10, v9                               // 0000000136A8: D644003A 0426150B
	v_perm_b32 v59, v11, v10, v13                              // 0000000136B0: D644003B 0436150B
	v_mov_b32_e32 v10, v12                                     // 0000000136B8: 7E14030C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000136BC: BF870091
	v_permlanex16_b32 v10, v10, s42, 0xfedcba98                // 0000000136C0: D65C000A 03FC550A FEDCBA98
	v_perm_b32 v60, v12, v10, v9                               // 0000000136CC: D644003C 0426150C
	v_perm_b32 v61, v12, v10, v13                              // 0000000136D4: D644003D 0436150C
	s_waitcnt lgkmcnt(0)                                       // 0000000136DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000136E0: BF8700A1
	v_wmma_f32_16x16x16_f16 v[9:16], v[25:32], v[54:61], v[1:8]// 0000000136E4: CC404009 1C066D19
	.long 0xd7000101                                           // 0000000136EC: D7000101
	v_cndmask_b32_e32 v1, s34, v158, vcc_lo                    // 0000000136F0: 02033C22
	v_add_co_ci_u32_e64 v2, null, s35, 0, s1                   // 0000000136F4: D5207C02 00050023
	v_lshlrev_b32_e32 v3, 2, v157                              // 0000000136FC: 30073A82
	s_and_saveexec_b32 s1, s0                                  // 000000013700: BE812000
	s_cbranch_execz 19                                         // 000000013704: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4254>
	ds_load_b32 v4, v3 offset:24320                            // 000000013708: D8D85F00 04000003
	s_waitcnt lgkmcnt(0)                                       // 000000013710: BF89FC07
	v_mul_f32_e32 v4, v17, v4                                  // 000000013714: 10080911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013718: BF870091
	v_add_f32_e32 v4, v9, v4                                   // 00000001371C: 06080909
	v_mul_f32_e32 v6, 0x3b800000, v4                           // 000000013720: 100C08FF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v49, v[1:2]            // 000000013728: D6FE7C04 040662FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013734: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000013738: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000013740: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000001374C: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s1                              // 000000013754: 8C7E017E
	v_or3_b32 v4, v157, s44, 2                                 // 000000013758: D6580004 0208599D
	s_mov_b32 s0, exec_lo                                      // 000000013760: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000013764: BF870001
	.long 0xd4c4007e                                           // 000000013768: D4C4007E
	v_cndmask_b32_e32 v1, s29, v4, vcc_lo                      // 00000001376C: 0202081D
	s_cbranch_execz 19                                         // 000000013770: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x42c0>
	ds_load_b32 v5, v3 offset:24328                            // 000000013774: D8D85F08 05000003
	s_waitcnt lgkmcnt(0)                                       // 00000001377C: BF89FC07
	v_mul_f32_e32 v5, v18, v5                                  // 000000013780: 100A0B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013784: BF870091
	v_add_f32_e32 v5, v10, v5                                  // 000000013788: 060A0B0A
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000001378C: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[1:2]             // 000000013794: D6FE7C04 040608FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000137A0: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 0000000137A4: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000000137AC: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 0000000137B8: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000137C0: 8C7E007E
	v_or3_b32 v4, v157, s44, 4                                 // 0000000137C4: D6580004 0210599D
	s_mov_b32 s0, exec_lo                                      // 0000000137CC: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000137D0: BF870001
	.long 0xd4c4007e                                           // 0000000137D4: D4C4007E
	v_cndmask_b32_e32 v1, s29, v4, vcc_lo                      // 0000000137D8: 0202081D
	s_cbranch_execz 19                                         // 0000000137DC: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x432c>
	ds_load_b32 v5, v3 offset:24336                            // 0000000137E0: D8D85F10 05000003
	s_waitcnt lgkmcnt(0)                                       // 0000000137E8: BF89FC07
	v_mul_f32_e32 v5, v19, v5                                  // 0000000137EC: 100A0B13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000137F0: BF870091
	v_add_f32_e32 v5, v11, v5                                  // 0000000137F4: 060A0B0B
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 0000000137F8: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[1:2]             // 000000013800: D6FE7C04 040608FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001380C: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000013810: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000013818: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000013824: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001382C: 8C7E007E
	v_or3_b32 v4, v157, s44, 6                                 // 000000013830: D6580004 0218599D
	s_mov_b32 s0, exec_lo                                      // 000000013838: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001383C: BF870001
	.long 0xd4c4007e                                           // 000000013840: D4C4007E
	v_cndmask_b32_e32 v1, s29, v4, vcc_lo                      // 000000013844: 0202081D
	s_cbranch_execz 19                                         // 000000013848: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4398>
	ds_load_b32 v5, v3 offset:24344                            // 00000001384C: D8D85F18 05000003
	s_waitcnt lgkmcnt(0)                                       // 000000013854: BF89FC07
	v_mul_f32_e32 v5, v20, v5                                  // 000000013858: 100A0B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001385C: BF870091
	v_add_f32_e32 v5, v12, v5                                  // 000000013860: 060A0B0C
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000013864: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[1:2]             // 00000001386C: D6FE7C04 040608FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013878: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000001387C: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000013884: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000013890: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s0                              // 000000013898: 8C7E007E
	v_or3_b32 v4, v157, s44, 8                                 // 00000001389C: D6580004 0220599D
	s_mov_b32 s0, exec_lo                                      // 0000000138A4: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000138A8: BF870001
	.long 0xd4c4007e                                           // 0000000138AC: D4C4007E
	v_cndmask_b32_e32 v1, s29, v4, vcc_lo                      // 0000000138B0: 0202081D
	s_cbranch_execz 19                                         // 0000000138B4: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4404>
	ds_load_b32 v5, v3 offset:24352                            // 0000000138B8: D8D85F20 05000003
	s_waitcnt lgkmcnt(0)                                       // 0000000138C0: BF89FC07
	v_mul_f32_e32 v5, v21, v5                                  // 0000000138C4: 100A0B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000138C8: BF870091
	v_add_f32_e32 v5, v13, v5                                  // 0000000138CC: 060A0B0D
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 0000000138D0: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[1:2]             // 0000000138D8: D6FE7C04 040608FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000138E4: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 0000000138E8: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000000138F0: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 0000000138FC: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s0                              // 000000013904: 8C7E007E
	v_or3_b32 v4, v157, s44, 10                                // 000000013908: D6580004 0228599D
	s_mov_b32 s0, exec_lo                                      // 000000013910: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000013914: BF870001
	.long 0xd4c4007e                                           // 000000013918: D4C4007E
	v_cndmask_b32_e32 v1, s29, v4, vcc_lo                      // 00000001391C: 0202081D
	s_cbranch_execz 19                                         // 000000013920: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4470>
	ds_load_b32 v5, v3 offset:24360                            // 000000013924: D8D85F28 05000003
	s_waitcnt lgkmcnt(0)                                       // 00000001392C: BF89FC07
	v_mul_f32_e32 v5, v22, v5                                  // 000000013930: 100A0B16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013934: BF870091
	v_add_f32_e32 v5, v14, v5                                  // 000000013938: 060A0B0E
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000001393C: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[1:2]             // 000000013944: D6FE7C04 040608FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013950: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000013954: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000001395C: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000013968: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s0                              // 000000013970: 8C7E007E
	v_or3_b32 v4, v157, s44, 12                                // 000000013974: D6580004 0230599D
	s_mov_b32 s0, exec_lo                                      // 00000001397C: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000013980: BF870001
	.long 0xd4c4007e                                           // 000000013984: D4C4007E
	v_cndmask_b32_e32 v1, s29, v4, vcc_lo                      // 000000013988: 0202081D
	s_cbranch_execz 19                                         // 00000001398C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44dc>
	ds_load_b32 v5, v3 offset:24368                            // 000000013990: D8D85F30 05000003
	s_waitcnt lgkmcnt(0)                                       // 000000013998: BF89FC07
	v_mul_f32_e32 v5, v23, v5                                  // 00000001399C: 100A0B17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000139A0: BF870091
	v_add_f32_e32 v5, v15, v5                                  // 0000000139A4: 060A0B0F
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 0000000139A8: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[1:2]             // 0000000139B0: D6FE7C04 040608FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000139BC: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 0000000139C0: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000000139C8: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 0000000139D4: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000139DC: 8C7E007E
	v_or3_b32 v4, v157, s44, 14                                // 0000000139E0: D6580004 0238599D
	s_mov_b32 s0, exec_lo                                      // 0000000139E8: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000139EC: BF870001
	.long 0xd4c4007e                                           // 0000000139F0: D4C4007E
	v_cndmask_b32_e32 v1, s29, v4, vcc_lo                      // 0000000139F4: 0202081D
	s_cbranch_execz 19                                         // 0000000139F8: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4548>
	ds_load_b32 v3, v3 offset:24376                            // 0000000139FC: D8D85F38 03000003
	v_mad_u64_u32 v[1:2], null, 0x3000, v4, v[1:2]             // 000000013A04: D6FE7C01 040608FF 00003000
	s_waitcnt lgkmcnt(0)                                       // 000000013A10: BF89FC07
	v_mul_f32_e32 v3, v24, v3                                  // 000000013A14: 10060718
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013A18: BF870091
	v_add_f32_e32 v3, v16, v3                                  // 000000013A1C: 06060710
	v_mul_f32_e32 v3, 0x3b800000, v3                           // 000000013A20: 100606FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013A28: BF870091
	v_bfe_u32 v5, v3, 16, 1                                    // 000000013A2C: D6100005 02052103
	v_add3_u32 v3, v3, v5, 0x7fff                              // 000000013A34: D6550003 03FE0B03 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off                    // 000000013A40: DC960000 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 000000013A48: 8C7E007E
	ds_load_b32 v25, v139 offset:24188                         // 000000013A4C: D8D85E7C 1900008B
	v_mad_u32_u24 v1, v156, 48, 0x4b00                         // 000000013A54: D60B0001 03FD619C 00004B00
	s_add_i32 s44, s44, 16                                     // 000000013A60: 812C902C
	v_mov_b32_e32 v181, s27                                    // 000000013A64: 7F6A021B
	v_dual_mov_b32 v179, s25 :: v_dual_mov_b32 v176, s22       // 000000013A68: CA100019 B3B00016
	s_delay_alu instid0(VALU_DEP_3)                            // 000000013A70: BF870003
	v_dual_mov_b32 v177, s23 :: v_dual_add_nc_u32 v26, 0xffffb500, v1// 000000013A74: CA200017 B11A02FF FFFFB500
	v_dual_mov_b32 v174, s20 :: v_dual_mov_b32 v175, s21       // 000000013A80: CA100014 AEAE0015
	ds_load_b128 v[162:165], v26 offset:2320                   // 000000013A88: DBFC0910 A200001A
	ds_load_b128 v[158:161], v26 offset:2304                   // 000000013A90: DBFC0900 9E00001A
	ds_load_b128 v[170:173], v26 offset:3088                   // 000000013A98: DBFC0C10 AA00001A
	ds_load_b128 v[166:169], v26 offset:3072                   // 000000013AA0: DBFC0C00 A600001A
	ds_load_b128 v[1:4], v26                                   // 000000013AA8: DBFC0000 0100001A
	ds_load_b128 v[5:8], v26 offset:16                         // 000000013AB0: DBFC0010 0500001A
	ds_load_b128 v[77:80], v26 offset:4624                     // 000000013AB8: DBFC1210 4D00001A
	ds_load_b128 v[73:76], v26 offset:4608                     // 000000013AC0: DBFC1200 4900001A
	ds_load_b128 v[186:189], v26 offset:3856                   // 000000013AC8: DBFC0F10 BA00001A
	ds_load_b128 v[182:185], v26 offset:3840                   // 000000013AD0: DBFC0F00 B600001A
	v_mov_b32_e32 v180, s26                                    // 000000013AD8: 7F68021A
	v_mov_b32_e32 v178, s24                                    // 000000013ADC: 7F640218
	s_waitcnt lgkmcnt(10)                                      // 000000013AE0: BF89FCA7
	v_readfirstlane_b32 s0, v25                                // 000000013AE4: 7E000519
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v25                  // 000000013AE8: 7C3632FF C2CE8ED0
	s_mul_f32 s0, s0, 0x3fb8aa3b                               // 000000013AF0: A200FF00 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 000000013AF8: BF87000B
	s_xor_b32 s1, s0, 0x80000000                               // 000000013AFC: 8D01FF00 80000000
	s_cmp_lg_u32 s12, s44                                      // 000000013B04: BF072C0C
	v_fma_f32 v9, 0x3fb8aa3b, v25, s1                          // 000000013B08: D6130009 000632FF 3FB8AA3B
	s_rndne_f32 s1, s0                                         // 000000013B14: BE816300
	s_waitcnt lgkmcnt(4)                                       // 000000013B18: BF89FC47
	v_wmma_f32_16x16x16_f16 v[46:53], v[1:8], v[54:61], v[174:181]// 000000013B1C: CC40402E 1EBA6D01
	s_delay_alu instid0(VALU_DEP_2)                            // 000000013B24: BF870002
	v_fmac_f32_e32 v9, 0x32a5705f, v25                         // 000000013B28: 561232FF 32A5705F
	s_sub_f32 s0, s0, s1                                       // 000000013B30: A0800100
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_3)    // 000000013B34: BF870581
	v_add_f32_e32 v27, s0, v9                                  // 000000013B38: 06361200
	ds_load_b128 v[13:16], v26 offset:784                      // 000000013B3C: DBFC0310 0D00001A
	ds_load_b128 v[9:12], v26 offset:768                       // 000000013B44: DBFC0300 0900001A
	ds_load_b128 v[21:24], v26 offset:1552                     // 000000013B4C: DBFC0610 1500001A
	ds_load_b128 v[17:20], v26 offset:1536                     // 000000013B54: DBFC0600 1100001A
	s_cvt_i32_f32 s0, s1                                       // 000000013B5C: BE806601
	v_exp_f32_e32 v27, v27                                     // 000000013B60: 7E364B1B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_2) // 000000013B64: BF870505
	.long 0xd71c001b                                           // 000000013B68: D71C001B
	v_cndmask_b32_e32 v0, v27, v0, vcc_lo                      // 000000013B6C: 0200011B
	s_waitcnt lgkmcnt(2)                                       // 000000013B70: BF89FC27
	v_wmma_f32_16x16x16_f16 v[38:45], v[9:16], v[54:61], v[174:181]// 000000013B74: CC404026 1EBA6D09
	s_delay_alu instid0(VALU_DEP_2)                            // 000000013B7C: BF870002
	v_cndmask_b32_e32 v1, 0, v27, vcc_lo                       // 000000013B80: 02023680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v25                  // 000000013B84: 7C3C32FF 42B17218
	v_wmma_f32_16x16x16_f16 v[9:16], v[158:165], v[54:61], v[174:181]// 000000013B8C: CC404009 1EBA6D9E
	ds_load_b128 v[162:165], v26 offset:5392                   // 000000013B94: DBFC1510 A200001A
	ds_load_b128 v[158:161], v26 offset:5376                   // 000000013B9C: DBFC1500 9E00001A
	s_waitcnt lgkmcnt(0)                                       // 000000013BA4: BF89FC07
	s_barrier                                                  // 000000013BA8: BFBD0000
	v_cndmask_b32_e32 v62, 0x7f800000, v1, vcc_lo              // 000000013BAC: 027C02FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000013BB4: BF8701D1
	v_fmac_f32_e32 v16, v151, v62                              // 000000013BB8: 56207D97
	s_waitcnt lgkmcnt(2)                                       // 000000013BBC: BF89FC27
	v_wmma_f32_16x16x16_f16 v[30:37], v[17:24], v[54:61], v[174:181]// 000000013BC0: CC40401E 1EBA6D11
	v_wmma_f32_16x16x16_f16 v[1:8], v[166:173], v[54:61], v[174:181]// 000000013BC8: CC404001 1EBA6DA6
	v_fma_f32 v135, v135, v62, v46                             // 000000013BD0: D6130087 04BA7D87
	v_fma_f32 v121, v121, v62, v30                             // 000000013BD8: D6130079 047A7D79
	s_delay_alu instid0(VALU_DEP_4)                            // 000000013BE0: BF870004
	v_fma_f32 v120, v120, v62, v31                             // 000000013BE4: D6130078 047E7D78
	v_fma_f32 v119, v119, v62, v32                             // 000000013BEC: D6130077 04827D77
	v_fma_f32 v118, v118, v62, v33                             // 000000013BF4: D6130076 04867D76
	v_fma_f32 v117, v117, v62, v34                             // 000000013BFC: D6130075 048A7D75
	v_fma_f32 v116, v116, v62, v35                             // 000000013C04: D6130074 048E7D74
	v_fma_f32 v115, v115, v62, v36                             // 000000013C0C: D6130073 04927D73
	v_wmma_f32_16x16x16_f16 v[29:36], v[73:80], v[54:61], v[174:181]// 000000013C14: CC40401D 1EBA6D49
	v_wmma_f32_16x16x16_f16 v[17:24], v[182:189], v[54:61], v[174:181]// 000000013C1C: CC404011 1EBA6DB6
	v_fma_f32 v134, v134, v62, v47                             // 000000013C24: D6130086 04BE7D86
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000013C2C: BF870213
	v_fma_f32 v93, v93, v62, v29                               // 000000013C30: D613005D 04767D5D
	v_fma_f32 v92, v92, v62, v30                               // 000000013C38: D613005C 047A7D5C
	v_fma_f32 v91, v91, v62, v31                               // 000000013C40: D613005B 047E7D5B
	v_fma_f32 v90, v90, v62, v32                               // 000000013C48: D613005A 04827D5A
	s_waitcnt lgkmcnt(0)                                       // 000000013C50: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[158:165], v[54:61], v[174:181]// 000000013C54: CC404019 1EBA6D9E
	v_fma_f32 v133, v133, v62, v48                             // 000000013C5C: D6130085 04C27D85
	v_fma_f32 v132, v132, v62, v49                             // 000000013C64: D6130084 04C67D84
	v_fma_f32 v131, v131, v62, v50                             // 000000013C6C: D6130083 04CA7D83
	v_fma_f32 v130, v130, v62, v51                             // 000000013C74: D6130082 04CE7D82
	v_fma_f32 v129, v129, v62, v52                             // 000000013C7C: D6130081 04D27D81
	v_fmac_f32_e32 v53, v154, v62                              // 000000013C84: 566A7D9A
	v_fma_f32 v128, v128, v62, v38                             // 000000013C88: D6130080 049A7D80
	v_fma_f32 v127, v127, v62, v39                             // 000000013C90: D613007F 049E7D7F
	v_fma_f32 v126, v126, v62, v40                             // 000000013C98: D613007E 04A27D7E
	v_fma_f32 v125, v125, v62, v41                             // 000000013CA0: D613007D 04A67D7D
	v_fma_f32 v124, v124, v62, v42                             // 000000013CA8: D613007C 04AA7D7C
	v_fma_f32 v123, v123, v62, v43                             // 000000013CB0: D613007B 04AE7D7B
	v_fma_f32 v122, v122, v62, v44                             // 000000013CB8: D613007A 04B27D7A
	v_fmac_f32_e32 v45, v153, v62                              // 000000013CC0: 565A7D99
	v_fma_f32 v114, v114, v62, v9                              // 000000013CC4: D6130072 04267D72
	v_fma_f32 v113, v113, v62, v10                             // 000000013CCC: D6130071 042A7D71
	v_fma_f32 v112, v112, v62, v11                             // 000000013CD4: D6130070 042E7D70
	v_fma_f32 v111, v111, v62, v12                             // 000000013CDC: D613006F 04327D6F
	v_fma_f32 v110, v110, v62, v13                             // 000000013CE4: D613006E 04367D6E
	v_fma_f32 v109, v109, v62, v14                             // 000000013CEC: D613006D 043A7D6D
	v_fma_f32 v108, v108, v62, v15                             // 000000013CF4: D613006C 043E7D6C
	v_fma_f32 v107, v107, v62, v1                              // 000000013CFC: D613006B 04067D6B
	v_fma_f32 v106, v106, v62, v2                              // 000000013D04: D613006A 040A7D6A
	v_fma_f32 v105, v105, v62, v3                              // 000000013D0C: D6130069 040E7D69
	v_fma_f32 v104, v104, v62, v4                              // 000000013D14: D6130068 04127D68
	v_fma_f32 v103, v103, v62, v5                              // 000000013D1C: D6130067 04167D67
	v_fma_f32 v102, v102, v62, v6                              // 000000013D24: D6130066 041A7D66
	v_fma_f32 v101, v101, v62, v7                              // 000000013D2C: D6130065 041E7D65
	v_fmac_f32_e32 v8, v150, v62                               // 000000013D34: 56107D96
	v_fma_f32 v100, v100, v62, v17                             // 000000013D38: D6130064 04467D64
	v_fma_f32 v99, v99, v62, v18                               // 000000013D40: D6130063 044A7D63
	v_fma_f32 v98, v98, v62, v19                               // 000000013D48: D6130062 044E7D62
	v_fma_f32 v97, v97, v62, v20                               // 000000013D50: D6130061 04527D61
	v_fma_f32 v96, v96, v62, v21                               // 000000013D58: D6130060 04567D60
	v_fma_f32 v95, v95, v62, v22                               // 000000013D60: D613005F 045A7D5F
	v_fma_f32 v94, v94, v62, v23                               // 000000013D68: D613005E 045E7D5E
	v_dual_fmac_f32 v24, v149, v62 :: v_dual_mul_f32 v153, 0x3b800000, v132// 000000013D70: C8067D95 189908FF 3B800000
	v_fma_f32 v89, v89, v62, v33                               // 000000013D7C: D6130059 04867D59
	v_fma_f32 v88, v88, v62, v34                               // 000000013D84: D6130058 048A7D58
	v_fma_f32 v87, v87, v62, v35                               // 000000013D8C: D6130057 048E7D57
	v_dual_fmac_f32 v36, v148, v62 :: v_dual_mul_f32 v3, 0x3b800000, v131// 000000013D94: C8067D94 240306FF 3B800000
	v_fma_f32 v86, v86, v62, v25                               // 000000013DA0: D6130056 04667D56
	v_fma_f32 v85, v85, v62, v26                               // 000000013DA8: D6130055 046A7D55
	v_fma_f32 v84, v84, v62, v27                               // 000000013DB0: D6130054 046E7D54
	v_fma_f32 v83, v83, v62, v28                               // 000000013DB8: D6130053 04727D53
	v_fma_f32 v82, v82, v62, v29                               // 000000013DC0: D6130052 04767D52
	v_fma_f32 v81, v81, v62, v30                               // 000000013DC8: D6130051 047A7D51
	v_fma_f32 v141, v141, v62, v31                             // 000000013DD0: D613008D 047E7D8D
	v_fmac_f32_e32 v32, v147, v62                              // 000000013DD8: 56407D93
	v_dual_mul_f32 v150, 0x3b800000, v135 :: v_dual_fmac_f32 v37, v152, v62// 000000013DDC: C8C10EFF 96247D98 3B800000
	v_mul_f32_e32 v156, 0x3b800000, v53                        // 000000013DE8: 11386AFF 3B800000
	v_lshl_add_u32 v1, v157, 7, v155                           // 000000013DF0: D6460001 066D0F9D
	v_dual_mul_f32 v151, 0x3b800000, v134 :: v_dual_mul_f32 v4, 0x3b800000, v128// 000000013DF8: C8C70CFF 970500FF 3B800000
	v_mul_f32_e32 v152, 0x3b800000, v133                       // 000000013E04: 11310AFF 3B800000
	v_dual_mul_f32 v154, 0x3b800000, v130 :: v_dual_mul_f32 v149, 0x3b800000, v127// 000000013E0C: C8C704FF 9A94FEFF 3B800000
	v_dual_mul_f32 v155, 0x3b800000, v129 :: v_dual_mul_f32 v62, 0x3b800000, v126// 000000013E18: C8C702FF 9B3EFCFF 3B800000
	v_mul_f32_e32 v63, 0x3b800000, v125                        // 000000013E24: 107EFAFF 3B800000
	v_dual_mul_f32 v5, 0x3b800000, v124 :: v_dual_mul_f32 v64, 0x3b800000, v123// 000000013E2C: C8C6F8FF 0540F6FF 3B800000
	v_dual_mul_f32 v147, 0x3b800000, v122 :: v_dual_mul_f32 v148, 0x3b800000, v45// 000000013E38: C8C6F4FF 93945AFF 3B800000
	v_dual_mul_f32 v6, 0x3b800000, v121 :: v_dual_mul_f32 v59, 0x3b800000, v120// 000000013E44: C8C6F2FF 063AF0FF 3B800000
	v_dual_mul_f32 v60, 0x3b800000, v119 :: v_dual_mul_f32 v61, 0x3b800000, v118// 000000013E50: C8C6EEFF 3C3CECFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v117 :: v_dual_mul_f32 v52, 0x3b800000, v116// 000000013E5C: C8C6EAFF 0734E8FF 3B800000
	v_dual_mul_f32 v54, 0x3b800000, v115 :: v_dual_mul_f32 v55, 0x3b800000, v37// 000000013E68: C8C6E6FF 36364AFF 3B800000
	v_dual_mul_f32 v9, 0x3b800000, v114 :: v_dual_mul_f32 v56, 0x3b800000, v113// 000000013E74: C8C6E4FF 0938E2FF 3B800000
	v_dual_mul_f32 v57, 0x3b800000, v112 :: v_dual_mul_f32 v58, 0x3b800000, v111// 000000013E80: C8C6E0FF 393ADEFF 3B800000
	v_dual_mul_f32 v10, 0x3b800000, v110 :: v_dual_mul_f32 v51, 0x3b800000, v108// 000000013E8C: C8C6DCFF 0A32D8FF 3B800000
	v_dual_mul_f32 v50, 0x3b800000, v109 :: v_dual_mul_f32 v41, 0x3b800000, v16// 000000013E98: C8C6DAFF 322820FF 3B800000
	v_dual_mul_f32 v11, 0x3b800000, v107 :: v_dual_mul_f32 v44, 0x3b800000, v105// 000000013EA4: C8C6D6FF 0B2CD2FF 3B800000
	v_dual_mul_f32 v43, 0x3b800000, v106 :: v_dual_mul_f32 v46, 0x3b800000, v104// 000000013EB0: C8C6D4FF 2B2ED0FF 3B800000
	v_dual_mul_f32 v13, 0x3b800000, v103 :: v_dual_mul_f32 v48, 0x3b800000, v101// 000000013EBC: C8C6CEFF 0D30CAFF 3B800000
	v_dual_mul_f32 v47, 0x3b800000, v102 :: v_dual_mul_f32 v14, 0x3b800000, v100// 000000013EC8: C8C6CCFF 2F0EC8FF 3B800000
	v_dual_mul_f32 v49, 0x3b800000, v8 :: v_dual_mul_f32 v42, 0x3b800000, v99// 000000013ED4: C8C610FF 312AC6FF 3B800000
	v_dual_mul_f32 v34, 0x3b800000, v98 :: v_dual_mul_f32 v35, 0x3b800000, v97// 000000013EE0: C8C6C4FF 2222C2FF 3B800000
	v_dual_mul_f32 v26, 0x3b800000, v96 :: v_dual_mul_f32 v39, 0x3b800000, v94// 000000013EEC: C8C6C0FF 1A26BCFF 3B800000
	v_dual_mul_f32 v38, 0x3b800000, v95 :: v_dual_mul_f32 v27, 0x3b800000, v93// 000000013EF8: C8C6BEFF 261ABAFF 3B800000
	v_dual_mul_f32 v40, 0x3b800000, v24 :: v_dual_mul_f32 v31, 0x3b800000, v91// 000000013F04: C8C630FF 281EB6FF 3B800000
	v_dual_mul_f32 v30, 0x3b800000, v92 :: v_dual_mul_f32 v33, 0x3b800000, v90// 000000013F10: C8C6B8FF 1E20B4FF 3B800000
	v_dual_mul_f32 v28, 0x3b800000, v89 :: v_dual_mul_f32 v19, 0x3b800000, v88// 000000013F1C: C8C6B2FF 1C12B0FF 3B800000
	v_dual_mul_f32 v20, 0x3b800000, v87 :: v_dual_mul_f32 v21, 0x3b800000, v36// 000000013F28: C8C6AEFF 141448FF 3B800000
	v_dual_mul_f32 v29, 0x3b800000, v86 :: v_dual_mul_f32 v22, 0x3b800000, v85// 000000013F34: C8C6ACFF 1D16AAFF 3B800000
	v_dual_mul_f32 v23, 0x3b800000, v84 :: v_dual_mul_f32 v18, 0x3b800000, v141// 000000013F40: C8C6A8FF 17131AFF 3B800000
	v_dual_mul_f32 v25, 0x3b800000, v83 :: v_dual_mul_f32 v12, 0x3b800000, v32// 000000013F4C: C8C6A6FF 190C40FF 3B800000
	v_mul_f32_e32 v15, 0x3b800000, v82                         // 000000013F58: 101EA4FF 3B800000
	v_mul_f32_e32 v17, 0x3b800000, v81                         // 000000013F60: 1022A2FF 3B800000
	s_cbranch_scc0 5                                           // 000000013F68: BFA10005 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4a80>
	s_cmp_lg_u32 s13, s44                                      // 000000013F6C: BF072C0D
	s_cbranch_scc0 273                                         // 000000013F70: BFA10111 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4eb8>
	s_cmp_lg_u32 s14, s44                                      // 000000013F74: BF072C0E
	s_cbranch_scc1 61340                                       // 000000013F78: BFA2EF9C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x8ec>
	s_branch 540                                               // 000000013F7C: BFA0021C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x52f0>
	v_mov_b32_e32 v73, v1                                      // 000000013F80: 7E920301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013F84: BF870091
	v_ashrrev_i32_e32 v74, 31, v73                             // 000000013F88: 3494929F
	.long 0xd73c0049                                           // 000000013F8C: D73C0049
	v_cndmask_b32_e32 v1, 2, v73, vcc_lo                       // 000000013F90: 02029282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013F94: BF870091
	.long 0xd7006a49                                           // 000000013F98: D7006A49
	v_cndmask_b32_e32 v1, s16, v73, vcc_lo                     // 000000013F9C: 02029210
	v_add_co_ci_u32_e64 v74, null, s17, v74, vcc_lo            // 000000013FA0: D5207C4A 01AA9411
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000013FA8: BF870092
	.long 0xd7006a4b                                           // 000000013FAC: D7006A4B
	v_cndmask_b32_e32 v1, 0x1000, v73, vcc_lo                  // 000000013FB0: 020292FF 00001000
	v_add_co_ci_u32_e64 v76, null, 0, v74, vcc_lo              // 000000013FB8: D5207C4C 01AA9480
	.long 0xd7006a4d                                           // 000000013FC0: D7006A4D
	v_cndmask_b32_e32 v0, v73, v255, vcc_lo                    // 000000013FC4: 0201FF49
	.long 0x00002000                                           // 000000013FC8: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000013FCC: BF8700A1
	v_add_co_ci_u32_e64 v78, null, 0, v74, vcc_lo              // 000000013FD0: D5207C4E 01AA9480
	.long 0xd7006a4f                                           // 000000013FD8: D7006A4F
	v_cndmask_b32_e32 v1, 0x2000, v73, vcc_lo                  // 000000013FDC: 020292FF 00002000
	v_add_co_ci_u32_e64 v80, null, 0, v74, vcc_lo              // 000000013FE4: D5207C50 01AA9480
	s_clause 0x7                                               // 000000013FEC: BF850007
	global_store_b32 v[73:74], v150, off                       // 000000013FF0: DC6A0000 007C9649
	global_store_b32 v[73:74], v151, off offset:1024           // 000000013FF8: DC6A0400 007C9749
	global_store_b32 v[73:74], v152, off offset:2048           // 000000014000: DC6A0800 007C9849
	global_store_b32 v[73:74], v153, off offset:3072           // 000000014008: DC6A0C00 007C9949
	global_store_b32 v[75:76], v154, off offset:1024           // 000000014010: DC6A0400 007C9A4B
	global_store_b32 v[75:76], v155, off offset:2048           // 000000014018: DC6A0800 007C9B4B
	global_store_b32 v[75:76], v156, off offset:3072           // 000000014020: DC6A0C00 007C9C4B
	global_store_b32 v[79:80], v149, off offset:1024           // 000000014028: DC6A0400 007C954F
	.long 0xd7006a4b                                           // 000000014030: D7006A4B
	v_cndmask_b32_e32 v1, 0x3000, v73, vcc_lo                  // 000000014034: 020292FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001403C: BF8700A1
	v_add_co_ci_u32_e64 v76, null, 0, v74, vcc_lo              // 000000014040: D5207C4C 01AA9480
	.long 0xd7006a9d                                           // 000000014048: D7006A9D
	v_cndmask_b32_e32 v0, v73, v255, vcc_lo                    // 00000001404C: 0201FF49
	.long 0x00004000                                           // 000000014050: 00004000
	v_add_co_ci_u32_e64 v158, null, 0, v74, vcc_lo             // 000000014054: D5207C9E 01AA9480
	.long 0xd7006a9f                                           // 00000001405C: D7006A9F
	v_cndmask_b32_e32 v1, 0x4000, v73, vcc_lo                  // 000000014060: 020292FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000014068: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v74, vcc_lo             // 00000001406C: D5207CA0 01AA9480
	s_clause 0x7                                               // 000000014074: BF850007
	global_store_b32 v[79:80], v62, off offset:2048            // 000000014078: DC6A0800 007C3E4F
	global_store_b32 v[79:80], v63, off offset:3072            // 000000014080: DC6A0C00 007C3F4F
	global_store_b32 v[75:76], v64, off offset:1024            // 000000014088: DC6A0400 007C404B
	global_store_b32 v[75:76], v147, off offset:2048           // 000000014090: DC6A0800 007C934B
	global_store_b32 v[75:76], v148, off offset:3072           // 000000014098: DC6A0C00 007C944B
	global_store_b32 v[159:160], v59, off offset:1024          // 0000000140A0: DC6A0400 007C3B9F
	global_store_b32 v[159:160], v60, off offset:2048          // 0000000140A8: DC6A0800 007C3C9F
	global_store_b32 v[159:160], v61, off offset:3072          // 0000000140B0: DC6A0C00 007C3D9F
	.long 0xd7006a4b                                           // 0000000140B8: D7006A4B
	v_cndmask_b32_e32 v1, 0x5000, v73, vcc_lo                  // 0000000140BC: 020292FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000140C4: BF8700A1
	v_add_co_ci_u32_e64 v76, null, 0, v74, vcc_lo              // 0000000140C8: D5207C4C 01AA9480
	.long 0xd7006a4f                                           // 0000000140D0: D7006A4F
	v_cndmask_b32_e32 v0, v73, v255, vcc_lo                    // 0000000140D4: 0201FF49
	.long 0x00006000                                           // 0000000140D8: 00006000
	v_add_co_ci_u32_e64 v80, null, 0, v74, vcc_lo              // 0000000140DC: D5207C50 01AA9480
	.long 0xd7006a9f                                           // 0000000140E4: D7006A9F
	v_cndmask_b32_e32 v1, 0x6000, v73, vcc_lo                  // 0000000140E8: 020292FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000140F0: BF8700A1
	v_add_co_ci_u32_e64 v160, null, 0, v74, vcc_lo             // 0000000140F4: D5207CA0 01AA9480
	.long 0xd7006aa1                                           // 0000000140FC: D7006AA1
	v_cndmask_b32_e32 v1, 0x7000, v73, vcc_lo                  // 000000014100: 020292FF 00007000
	v_add_co_ci_u32_e64 v162, null, 0, v74, vcc_lo             // 000000014108: D5207CA2 01AA9480
	.long 0xd7006aa3                                           // 000000014110: D7006AA3
	v_cndmask_b32_e32 v0, v73, v255, vcc_lo                    // 000000014114: 0201FF49
	.long 0x00008000                                           // 000000014118: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001411C: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v74, vcc_lo             // 000000014120: D5207CA4 01AA9480
	s_clause 0x7                                               // 000000014128: BF850007
	global_store_b32 v[75:76], v52, off offset:1024            // 00000001412C: DC6A0400 007C344B
	global_store_b32 v[75:76], v54, off offset:2048            // 000000014134: DC6A0800 007C364B
	global_store_b32 v[75:76], v55, off offset:3072            // 00000001413C: DC6A0C00 007C374B
	global_store_b32 v[159:160], v56, off offset:1024          // 000000014144: DC6A0400 007C389F
	global_store_b32 v[159:160], v57, off offset:2048          // 00000001414C: DC6A0800 007C399F
	global_store_b32 v[159:160], v58, off offset:3072          // 000000014154: DC6A0C00 007C3A9F
	global_store_b32 v[161:162], v50, off offset:1024          // 00000001415C: DC6A0400 007C32A1
	global_store_b32 v[161:162], v51, off offset:2048          // 000000014164: DC6A0800 007C33A1
	.long 0xd7006a4b                                           // 00000001416C: D7006A4B
	v_cndmask_b32_e32 v1, 0x8000, v73, vcc_lo                  // 000000014170: 020292FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000014178: BF8700A1
	v_add_co_ci_u32_e64 v76, null, 0, v74, vcc_lo              // 00000001417C: D5207C4C 01AA9480
	.long 0xd7006a9f                                           // 000000014184: D7006A9F
	v_cndmask_b32_e32 v1, 0x9000, v73, vcc_lo                  // 000000014188: 020292FF 00009000
	v_add_co_ci_u32_e64 v160, null, 0, v74, vcc_lo             // 000000014190: D5207CA0 01AA9480
	.long 0xd7006aa5                                           // 000000014198: D7006AA5
	v_cndmask_b32_e32 v0, v73, v255, vcc_lo                    // 00000001419C: 0201FF49
	.long 0x0000a000                                           // 0000000141A0: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000141A4: BF8700A1
	v_add_co_ci_u32_e64 v166, null, 0, v74, vcc_lo             // 0000000141A8: D5207CA6 01AA9480
	.long 0xd7006aa7                                           // 0000000141B0: D7006AA7
	v_cndmask_b32_e32 v1, 0xa000, v73, vcc_lo                  // 0000000141B4: 020292FF 0000A000
	v_add_co_ci_u32_e64 v168, null, 0, v74, vcc_lo             // 0000000141BC: D5207CA8 01AA9480
	s_clause 0x7                                               // 0000000141C4: BF850007
	global_store_b32 v[161:162], v41, off offset:3072          // 0000000141C8: DC6A0C00 007C29A1
	global_store_b32 v[75:76], v43, off offset:1024            // 0000000141D0: DC6A0400 007C2B4B
	global_store_b32 v[75:76], v44, off offset:2048            // 0000000141D8: DC6A0800 007C2C4B
	global_store_b32 v[75:76], v46, off offset:3072            // 0000000141E0: DC6A0C00 007C2E4B
	global_store_b32 v[159:160], v47, off offset:1024          // 0000000141E8: DC6A0400 007C2F9F
	global_store_b32 v[159:160], v48, off offset:2048          // 0000000141F0: DC6A0800 007C309F
	global_store_b32 v[159:160], v49, off offset:3072          // 0000000141F8: DC6A0C00 007C319F
	global_store_b32 v[167:168], v42, off offset:1024          // 000000014200: DC6A0400 007C2AA7
	.long 0xd7006a4b                                           // 000000014208: D7006A4B
	v_cndmask_b32_e32 v1, 0xb000, v73, vcc_lo                  // 00000001420C: 020292FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000014214: BF8700A1
	v_add_co_ci_u32_e64 v76, null, 0, v74, vcc_lo              // 000000014218: D5207C4C 01AA9480
	.long 0xd7006a9f                                           // 000000014220: D7006A9F
	v_cndmask_b32_e32 v0, v73, v255, vcc_lo                    // 000000014224: 0201FF49
	.long 0x0000c000                                           // 000000014228: 0000C000
	v_add_co_ci_u32_e64 v160, null, 0, v74, vcc_lo             // 00000001422C: D5207CA0 01AA9480
	.long 0xd7006aa1                                           // 000000014234: D7006AA1
	v_cndmask_b32_e32 v1, 0xc000, v73, vcc_lo                  // 000000014238: 020292FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000014240: BF870001
	v_add_co_ci_u32_e64 v162, null, 0, v74, vcc_lo             // 000000014244: D5207CA2 01AA9480
	s_clause 0x7                                               // 00000001424C: BF850007
	global_store_b32 v[167:168], v34, off offset:2048          // 000000014250: DC6A0800 007C22A7
	global_store_b32 v[167:168], v35, off offset:3072          // 000000014258: DC6A0C00 007C23A7
	global_store_b32 v[75:76], v38, off offset:1024            // 000000014260: DC6A0400 007C264B
	global_store_b32 v[75:76], v39, off offset:2048            // 000000014268: DC6A0800 007C274B
	global_store_b32 v[75:76], v40, off offset:3072            // 000000014270: DC6A0C00 007C284B
	global_store_b32 v[161:162], v30, off offset:1024          // 000000014278: DC6A0400 007C1EA1
	global_store_b32 v[161:162], v31, off offset:2048          // 000000014280: DC6A0800 007C1FA1
	global_store_b32 v[161:162], v33, off offset:3072          // 000000014288: DC6A0C00 007C21A1
	.long 0xd7006a4b                                           // 000000014290: D7006A4B
	v_cndmask_b32_e32 v1, 0xd000, v73, vcc_lo                  // 000000014294: 020292FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001429C: BF8700A1
	v_add_co_ci_u32_e64 v76, null, 0, v74, vcc_lo              // 0000000142A0: D5207C4C 01AA9480
	.long 0xd7006aa1                                           // 0000000142A8: D7006AA1
	v_cndmask_b32_e32 v0, v73, v255, vcc_lo                    // 0000000142AC: 0201FF49
	.long 0x0000e000                                           // 0000000142B0: 0000E000
	v_add_co_ci_u32_e64 v162, null, 0, v74, vcc_lo             // 0000000142B4: D5207CA2 01AA9480
	.long 0xd7006aa7                                           // 0000000142BC: D7006AA7
	v_cndmask_b32_e32 v1, 0xe000, v73, vcc_lo                  // 0000000142C0: 020292FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000142C8: BF870001
	v_add_co_ci_u32_e64 v168, null, 0, v74, vcc_lo             // 0000000142CC: D5207CA8 01AA9480
	.long 0xd7006a49                                           // 0000000142D4: D7006A49
	v_cndmask_b32_e32 v1, 0xf000, v73, vcc_lo                  // 0000000142D8: 020292FF 0000F000
	s_clause 0x7                                               // 0000000142E0: BF850007
	global_store_b32 v[163:164], v10, off offset:-4096         // 0000000142E4: DC6A1000 007C0AA3
	global_store_b32 v[163:164], v11, off                      // 0000000142EC: DC6A0000 007C0BA3
	global_store_b32 v[165:166], v13, off offset:-4096         // 0000000142F4: DC6A1000 007C0DA5
	global_store_b32 v[165:166], v14, off                      // 0000000142FC: DC6A0000 007C0EA5
	global_store_b32 v[159:160], v26, off offset:-4096         // 000000014304: DC6A1000 007C1A9F
	global_store_b32 v[159:160], v27, off                      // 00000001430C: DC6A0000 007C1B9F
	global_store_b32 v[161:162], v28, off offset:-4096         // 000000014314: DC6A1000 007C1CA1
	global_store_b32 v[161:162], v29, off                      // 00000001431C: DC6A0000 007C1DA1
	v_add_co_ci_u32_e64 v74, null, 0, v74, vcc_lo              // 000000014324: D5207C4A 01AA9480
	s_clause 0xf                                               // 00000001432C: BF85000F
	global_store_b32 v[75:76], v19, off offset:1024            // 000000014330: DC6A0400 007C134B
	global_store_b32 v[75:76], v20, off offset:2048            // 000000014338: DC6A0800 007C144B
	global_store_b32 v[75:76], v21, off offset:3072            // 000000014340: DC6A0C00 007C154B
	global_store_b32 v[167:168], v22, off offset:1024          // 000000014348: DC6A0400 007C16A7
	global_store_b32 v[167:168], v23, off offset:2048          // 000000014350: DC6A0800 007C17A7
	global_store_b32 v[167:168], v25, off offset:3072          // 000000014358: DC6A0C00 007C19A7
	global_store_b32 v[73:74], v15, off                        // 000000014360: DC6A0000 007C0F49
	global_store_b32 v[73:74], v17, off offset:1024            // 000000014368: DC6A0400 007C1149
	global_store_b32 v[73:74], v18, off offset:2048            // 000000014370: DC6A0800 007C1249
	global_store_b32 v[77:78], v3, off offset:-4096            // 000000014378: DC6A1000 007C034D
	global_store_b32 v[77:78], v4, off                         // 000000014380: DC6A0000 007C044D
	global_store_b32 v[157:158], v5, off offset:-4096          // 000000014388: DC6A1000 007C059D
	global_store_b32 v[157:158], v6, off                       // 000000014390: DC6A0000 007C069D
	global_store_b32 v[79:80], v7, off offset:-4096            // 000000014398: DC6A1000 007C074F
	global_store_b32 v[79:80], v9, off                         // 0000000143A0: DC6A0000 007C094F
	global_store_b32 v[73:74], v12, off offset:3072            // 0000000143A8: DC6A0C00 007C0C49
	s_cmp_lg_u32 s13, s44                                      // 0000000143B0: BF072C0D
	s_cbranch_scc1 65263                                       // 0000000143B4: BFA2FEEF <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4a74>
	v_mov_b32_e32 v73, v1                                      // 0000000143B8: 7E920301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000143BC: BF870091
	v_ashrrev_i32_e32 v74, 31, v73                             // 0000000143C0: 3494929F
	.long 0xd73c0049                                           // 0000000143C4: D73C0049
	v_cndmask_b32_e32 v1, 2, v73, vcc_lo                       // 0000000143C8: 02029282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000143CC: BF870091
	.long 0xd7006a49                                           // 0000000143D0: D7006A49
	v_cndmask_b32_e32 v1, s18, v73, vcc_lo                     // 0000000143D4: 02029212
	v_add_co_ci_u32_e64 v74, null, s19, v74, vcc_lo            // 0000000143D8: D5207C4A 01AA9413
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000143E0: BF870092
	.long 0xd7006a4b                                           // 0000000143E4: D7006A4B
	v_cndmask_b32_e32 v1, 0x1000, v73, vcc_lo                  // 0000000143E8: 020292FF 00001000
	v_add_co_ci_u32_e64 v76, null, 0, v74, vcc_lo              // 0000000143F0: D5207C4C 01AA9480
	.long 0xd7006a4d                                           // 0000000143F8: D7006A4D
	v_cndmask_b32_e32 v0, v73, v255, vcc_lo                    // 0000000143FC: 0201FF49
	.long 0x00002000                                           // 000000014400: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000014404: BF8700A1
	v_add_co_ci_u32_e64 v78, null, 0, v74, vcc_lo              // 000000014408: D5207C4E 01AA9480
	.long 0xd7006a4f                                           // 000000014410: D7006A4F
	v_cndmask_b32_e32 v1, 0x2000, v73, vcc_lo                  // 000000014414: 020292FF 00002000
	v_add_co_ci_u32_e64 v80, null, 0, v74, vcc_lo              // 00000001441C: D5207C50 01AA9480
	s_clause 0x7                                               // 000000014424: BF850007
	global_store_b32 v[73:74], v150, off                       // 000000014428: DC6A0000 007C9649
	global_store_b32 v[73:74], v151, off offset:1024           // 000000014430: DC6A0400 007C9749
	global_store_b32 v[73:74], v152, off offset:2048           // 000000014438: DC6A0800 007C9849
	global_store_b32 v[73:74], v153, off offset:3072           // 000000014440: DC6A0C00 007C9949
	global_store_b32 v[75:76], v154, off offset:1024           // 000000014448: DC6A0400 007C9A4B
	global_store_b32 v[75:76], v155, off offset:2048           // 000000014450: DC6A0800 007C9B4B
	global_store_b32 v[75:76], v156, off offset:3072           // 000000014458: DC6A0C00 007C9C4B
	global_store_b32 v[79:80], v149, off offset:1024           // 000000014460: DC6A0400 007C954F
	.long 0xd7006a4b                                           // 000000014468: D7006A4B
	v_cndmask_b32_e32 v1, 0x3000, v73, vcc_lo                  // 00000001446C: 020292FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000014474: BF8700A1
	v_add_co_ci_u32_e64 v76, null, 0, v74, vcc_lo              // 000000014478: D5207C4C 01AA9480
	.long 0xd7006a9d                                           // 000000014480: D7006A9D
	v_cndmask_b32_e32 v0, v73, v255, vcc_lo                    // 000000014484: 0201FF49
	.long 0x00004000                                           // 000000014488: 00004000
	v_add_co_ci_u32_e64 v158, null, 0, v74, vcc_lo             // 00000001448C: D5207C9E 01AA9480
	.long 0xd7006a9f                                           // 000000014494: D7006A9F
	v_cndmask_b32_e32 v1, 0x4000, v73, vcc_lo                  // 000000014498: 020292FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000144A0: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v74, vcc_lo             // 0000000144A4: D5207CA0 01AA9480
	s_clause 0x7                                               // 0000000144AC: BF850007
	global_store_b32 v[79:80], v62, off offset:2048            // 0000000144B0: DC6A0800 007C3E4F
	global_store_b32 v[79:80], v63, off offset:3072            // 0000000144B8: DC6A0C00 007C3F4F
	global_store_b32 v[75:76], v64, off offset:1024            // 0000000144C0: DC6A0400 007C404B
	global_store_b32 v[75:76], v147, off offset:2048           // 0000000144C8: DC6A0800 007C934B
	global_store_b32 v[75:76], v148, off offset:3072           // 0000000144D0: DC6A0C00 007C944B
	global_store_b32 v[159:160], v59, off offset:1024          // 0000000144D8: DC6A0400 007C3B9F
	global_store_b32 v[159:160], v60, off offset:2048          // 0000000144E0: DC6A0800 007C3C9F
	global_store_b32 v[159:160], v61, off offset:3072          // 0000000144E8: DC6A0C00 007C3D9F
	.long 0xd7006a4b                                           // 0000000144F0: D7006A4B
	v_cndmask_b32_e32 v1, 0x5000, v73, vcc_lo                  // 0000000144F4: 020292FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000144FC: BF8700A1
	v_add_co_ci_u32_e64 v76, null, 0, v74, vcc_lo              // 000000014500: D5207C4C 01AA9480
	.long 0xd7006a4f                                           // 000000014508: D7006A4F
	v_cndmask_b32_e32 v0, v73, v255, vcc_lo                    // 00000001450C: 0201FF49
	.long 0x00006000                                           // 000000014510: 00006000
	v_add_co_ci_u32_e64 v80, null, 0, v74, vcc_lo              // 000000014514: D5207C50 01AA9480
	.long 0xd7006a9f                                           // 00000001451C: D7006A9F
	v_cndmask_b32_e32 v1, 0x6000, v73, vcc_lo                  // 000000014520: 020292FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000014528: BF8700A1
	v_add_co_ci_u32_e64 v160, null, 0, v74, vcc_lo             // 00000001452C: D5207CA0 01AA9480
	.long 0xd7006aa1                                           // 000000014534: D7006AA1
	v_cndmask_b32_e32 v1, 0x7000, v73, vcc_lo                  // 000000014538: 020292FF 00007000
	v_add_co_ci_u32_e64 v162, null, 0, v74, vcc_lo             // 000000014540: D5207CA2 01AA9480
	.long 0xd7006aa3                                           // 000000014548: D7006AA3
	v_cndmask_b32_e32 v0, v73, v255, vcc_lo                    // 00000001454C: 0201FF49
	.long 0x00008000                                           // 000000014550: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000014554: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v74, vcc_lo             // 000000014558: D5207CA4 01AA9480
	s_clause 0x7                                               // 000000014560: BF850007
	global_store_b32 v[75:76], v52, off offset:1024            // 000000014564: DC6A0400 007C344B
	global_store_b32 v[75:76], v54, off offset:2048            // 00000001456C: DC6A0800 007C364B
	global_store_b32 v[75:76], v55, off offset:3072            // 000000014574: DC6A0C00 007C374B
	global_store_b32 v[159:160], v56, off offset:1024          // 00000001457C: DC6A0400 007C389F
	global_store_b32 v[159:160], v57, off offset:2048          // 000000014584: DC6A0800 007C399F
	global_store_b32 v[159:160], v58, off offset:3072          // 00000001458C: DC6A0C00 007C3A9F
	global_store_b32 v[161:162], v50, off offset:1024          // 000000014594: DC6A0400 007C32A1
	global_store_b32 v[161:162], v51, off offset:2048          // 00000001459C: DC6A0800 007C33A1
	.long 0xd7006a4b                                           // 0000000145A4: D7006A4B
	v_cndmask_b32_e32 v1, 0x8000, v73, vcc_lo                  // 0000000145A8: 020292FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000145B0: BF8700A1
	v_add_co_ci_u32_e64 v76, null, 0, v74, vcc_lo              // 0000000145B4: D5207C4C 01AA9480
	.long 0xd7006a9f                                           // 0000000145BC: D7006A9F
	v_cndmask_b32_e32 v1, 0x9000, v73, vcc_lo                  // 0000000145C0: 020292FF 00009000
	v_add_co_ci_u32_e64 v160, null, 0, v74, vcc_lo             // 0000000145C8: D5207CA0 01AA9480
	.long 0xd7006aa5                                           // 0000000145D0: D7006AA5
	v_cndmask_b32_e32 v0, v73, v255, vcc_lo                    // 0000000145D4: 0201FF49
	.long 0x0000a000                                           // 0000000145D8: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000145DC: BF8700A1
	v_add_co_ci_u32_e64 v166, null, 0, v74, vcc_lo             // 0000000145E0: D5207CA6 01AA9480
	.long 0xd7006aa7                                           // 0000000145E8: D7006AA7
	v_cndmask_b32_e32 v1, 0xa000, v73, vcc_lo                  // 0000000145EC: 020292FF 0000A000
	v_add_co_ci_u32_e64 v168, null, 0, v74, vcc_lo             // 0000000145F4: D5207CA8 01AA9480
	s_clause 0x7                                               // 0000000145FC: BF850007
	global_store_b32 v[161:162], v41, off offset:3072          // 000000014600: DC6A0C00 007C29A1
	global_store_b32 v[75:76], v43, off offset:1024            // 000000014608: DC6A0400 007C2B4B
	global_store_b32 v[75:76], v44, off offset:2048            // 000000014610: DC6A0800 007C2C4B
	global_store_b32 v[75:76], v46, off offset:3072            // 000000014618: DC6A0C00 007C2E4B
	global_store_b32 v[159:160], v47, off offset:1024          // 000000014620: DC6A0400 007C2F9F
	global_store_b32 v[159:160], v48, off offset:2048          // 000000014628: DC6A0800 007C309F
	global_store_b32 v[159:160], v49, off offset:3072          // 000000014630: DC6A0C00 007C319F
	global_store_b32 v[167:168], v42, off offset:1024          // 000000014638: DC6A0400 007C2AA7
	.long 0xd7006a4b                                           // 000000014640: D7006A4B
	v_cndmask_b32_e32 v1, 0xb000, v73, vcc_lo                  // 000000014644: 020292FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001464C: BF8700A1
	v_add_co_ci_u32_e64 v76, null, 0, v74, vcc_lo              // 000000014650: D5207C4C 01AA9480
	.long 0xd7006a9f                                           // 000000014658: D7006A9F
	v_cndmask_b32_e32 v0, v73, v255, vcc_lo                    // 00000001465C: 0201FF49
	.long 0x0000c000                                           // 000000014660: 0000C000
	v_add_co_ci_u32_e64 v160, null, 0, v74, vcc_lo             // 000000014664: D5207CA0 01AA9480
	.long 0xd7006aa1                                           // 00000001466C: D7006AA1
	v_cndmask_b32_e32 v1, 0xc000, v73, vcc_lo                  // 000000014670: 020292FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000014678: BF870001
	v_add_co_ci_u32_e64 v162, null, 0, v74, vcc_lo             // 00000001467C: D5207CA2 01AA9480
	s_clause 0x7                                               // 000000014684: BF850007
	global_store_b32 v[167:168], v34, off offset:2048          // 000000014688: DC6A0800 007C22A7
	global_store_b32 v[167:168], v35, off offset:3072          // 000000014690: DC6A0C00 007C23A7
	global_store_b32 v[75:76], v38, off offset:1024            // 000000014698: DC6A0400 007C264B
	global_store_b32 v[75:76], v39, off offset:2048            // 0000000146A0: DC6A0800 007C274B
	global_store_b32 v[75:76], v40, off offset:3072            // 0000000146A8: DC6A0C00 007C284B
	global_store_b32 v[161:162], v30, off offset:1024          // 0000000146B0: DC6A0400 007C1EA1
	global_store_b32 v[161:162], v31, off offset:2048          // 0000000146B8: DC6A0800 007C1FA1
	global_store_b32 v[161:162], v33, off offset:3072          // 0000000146C0: DC6A0C00 007C21A1
	.long 0xd7006a4b                                           // 0000000146C8: D7006A4B
	v_cndmask_b32_e32 v1, 0xd000, v73, vcc_lo                  // 0000000146CC: 020292FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000146D4: BF8700A1
	v_add_co_ci_u32_e64 v76, null, 0, v74, vcc_lo              // 0000000146D8: D5207C4C 01AA9480
	.long 0xd7006aa1                                           // 0000000146E0: D7006AA1
	v_cndmask_b32_e32 v0, v73, v255, vcc_lo                    // 0000000146E4: 0201FF49
	.long 0x0000e000                                           // 0000000146E8: 0000E000
	v_add_co_ci_u32_e64 v162, null, 0, v74, vcc_lo             // 0000000146EC: D5207CA2 01AA9480
	.long 0xd7006aa7                                           // 0000000146F4: D7006AA7
	v_cndmask_b32_e32 v1, 0xe000, v73, vcc_lo                  // 0000000146F8: 020292FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000014700: BF870001
	v_add_co_ci_u32_e64 v168, null, 0, v74, vcc_lo             // 000000014704: D5207CA8 01AA9480
	.long 0xd7006a49                                           // 00000001470C: D7006A49
	v_cndmask_b32_e32 v1, 0xf000, v73, vcc_lo                  // 000000014710: 020292FF 0000F000
	s_clause 0x7                                               // 000000014718: BF850007
	global_store_b32 v[163:164], v10, off offset:-4096         // 00000001471C: DC6A1000 007C0AA3
	global_store_b32 v[163:164], v11, off                      // 000000014724: DC6A0000 007C0BA3
	global_store_b32 v[165:166], v13, off offset:-4096         // 00000001472C: DC6A1000 007C0DA5
	global_store_b32 v[165:166], v14, off                      // 000000014734: DC6A0000 007C0EA5
	global_store_b32 v[159:160], v26, off offset:-4096         // 00000001473C: DC6A1000 007C1A9F
	global_store_b32 v[159:160], v27, off                      // 000000014744: DC6A0000 007C1B9F
	global_store_b32 v[161:162], v28, off offset:-4096         // 00000001474C: DC6A1000 007C1CA1
	global_store_b32 v[161:162], v29, off                      // 000000014754: DC6A0000 007C1DA1
	v_add_co_ci_u32_e64 v74, null, 0, v74, vcc_lo              // 00000001475C: D5207C4A 01AA9480
	s_clause 0xf                                               // 000000014764: BF85000F
	global_store_b32 v[75:76], v19, off offset:1024            // 000000014768: DC6A0400 007C134B
	global_store_b32 v[75:76], v20, off offset:2048            // 000000014770: DC6A0800 007C144B
	global_store_b32 v[75:76], v21, off offset:3072            // 000000014778: DC6A0C00 007C154B
	global_store_b32 v[167:168], v22, off offset:1024          // 000000014780: DC6A0400 007C16A7
	global_store_b32 v[167:168], v23, off offset:2048          // 000000014788: DC6A0800 007C17A7
	global_store_b32 v[167:168], v25, off offset:3072          // 000000014790: DC6A0C00 007C19A7
	global_store_b32 v[73:74], v15, off                        // 000000014798: DC6A0000 007C0F49
	global_store_b32 v[73:74], v17, off offset:1024            // 0000000147A0: DC6A0400 007C1149
	global_store_b32 v[73:74], v18, off offset:2048            // 0000000147A8: DC6A0800 007C1249
	global_store_b32 v[77:78], v3, off offset:-4096            // 0000000147B0: DC6A1000 007C034D
	global_store_b32 v[77:78], v4, off                         // 0000000147B8: DC6A0000 007C044D
	global_store_b32 v[157:158], v5, off offset:-4096          // 0000000147C0: DC6A1000 007C059D
	global_store_b32 v[157:158], v6, off                       // 0000000147C8: DC6A0000 007C069D
	global_store_b32 v[79:80], v7, off offset:-4096            // 0000000147D0: DC6A1000 007C074F
	global_store_b32 v[79:80], v9, off                         // 0000000147D8: DC6A0000 007C094F
	global_store_b32 v[73:74], v12, off offset:3072            // 0000000147E0: DC6A0C00 007C0C49
	s_cmp_lg_u32 s14, s44                                      // 0000000147E8: BF072C0E
	s_cbranch_scc1 60799                                       // 0000000147EC: BFA2ED7F <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x8ec>
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000000147F0: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000147F4: BF870091
	.long 0xd73c0001                                           // 0000000147F8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000000147FC: 02020282
	.long 0xd7006a01                                           // 000000014800: D7006A01
	v_cndmask_b32_e32 v1, s37, v1, vcc_lo                      // 000000014804: 02020225
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000014808: BF870111
	v_add_co_ci_u32_e64 v2, null, s38, v2, vcc_lo              // 00000001480C: D5207C02 01AA0426
	.long 0xd7006a49                                           // 000000014814: D7006A49
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 000000014818: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000014820: BF8700A1
	v_add_co_ci_u32_e64 v74, null, 0, v2, vcc_lo               // 000000014824: D5207C4A 01AA0480
	.long 0xd7006a4b                                           // 00000001482C: D7006A4B
	v_cndmask_b32_e32 v0, v1, v255, vcc_lo                     // 000000014830: 0201FF01
	.long 0x00002000                                           // 000000014834: 00002000
	v_add_co_ci_u32_e64 v76, null, 0, v2, vcc_lo               // 000000014838: D5207C4C 01AA0480
	.long 0xd7006a4d                                           // 000000014840: D7006A4D
	v_cndmask_b32_e32 v1, 0x2000, v1, vcc_lo                   // 000000014844: 020202FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001484C: BF870001
	v_add_co_ci_u32_e64 v78, null, 0, v2, vcc_lo               // 000000014850: D5207C4E 01AA0480
	s_clause 0x7                                               // 000000014858: BF850007
	global_store_b32 v[1:2], v150, off                         // 00000001485C: DC6A0000 007C9601
	global_store_b32 v[1:2], v151, off offset:1024             // 000000014864: DC6A0400 007C9701
	global_store_b32 v[1:2], v152, off offset:2048             // 00000001486C: DC6A0800 007C9801
	global_store_b32 v[1:2], v153, off offset:3072             // 000000014874: DC6A0C00 007C9901
	global_store_b32 v[73:74], v154, off offset:1024           // 00000001487C: DC6A0400 007C9A49
	global_store_b32 v[73:74], v155, off offset:2048           // 000000014884: DC6A0800 007C9B49
	global_store_b32 v[73:74], v156, off offset:3072           // 00000001488C: DC6A0C00 007C9C49
	global_store_b32 v[77:78], v149, off offset:1024           // 000000014894: DC6A0400 007C954D
	.long 0xd7006a49                                           // 00000001489C: D7006A49
	v_cndmask_b32_e32 v1, 0x3000, v1, vcc_lo                   // 0000000148A0: 020202FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000148A8: BF8700A1
	v_add_co_ci_u32_e64 v74, null, 0, v2, vcc_lo               // 0000000148AC: D5207C4A 01AA0480
	.long 0xd7006a4f                                           // 0000000148B4: D7006A4F
	v_cndmask_b32_e32 v0, v1, v255, vcc_lo                     // 0000000148B8: 0201FF01
	.long 0x00004000                                           // 0000000148BC: 00004000
	v_add_co_ci_u32_e64 v80, null, 0, v2, vcc_lo               // 0000000148C0: D5207C50 01AA0480
	.long 0xd7006a95                                           // 0000000148C8: D7006A95
	v_cndmask_b32_e32 v1, 0x4000, v1, vcc_lo                   // 0000000148CC: 020202FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000148D4: BF870001
	v_add_co_ci_u32_e64 v150, null, 0, v2, vcc_lo              // 0000000148D8: D5207C96 01AA0480
	s_clause 0x7                                               // 0000000148E0: BF850007
	global_store_b32 v[77:78], v62, off offset:2048            // 0000000148E4: DC6A0800 007C3E4D
	global_store_b32 v[77:78], v63, off offset:3072            // 0000000148EC: DC6A0C00 007C3F4D
	global_store_b32 v[73:74], v64, off offset:1024            // 0000000148F4: DC6A0400 007C4049
	global_store_b32 v[73:74], v147, off offset:2048           // 0000000148FC: DC6A0800 007C9349
	global_store_b32 v[73:74], v148, off offset:3072           // 000000014904: DC6A0C00 007C9449
	global_store_b32 v[149:150], v59, off offset:1024          // 00000001490C: DC6A0400 007C3B95
	global_store_b32 v[149:150], v60, off offset:2048          // 000000014914: DC6A0800 007C3C95
	global_store_b32 v[149:150], v61, off offset:3072          // 00000001491C: DC6A0C00 007C3D95
	.long 0xd7006a3b                                           // 000000014924: D7006A3B
	v_cndmask_b32_e32 v1, 0x5000, v1, vcc_lo                   // 000000014928: 020202FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000014930: BF8700A1
	v_add_co_ci_u32_e64 v60, null, 0, v2, vcc_lo               // 000000014934: D5207C3C 01AA0480
	.long 0xd7006a3d                                           // 00000001493C: D7006A3D
	v_cndmask_b32_e32 v0, v1, v255, vcc_lo                     // 000000014940: 0201FF01
	.long 0x00006000                                           // 000000014944: 00006000
	v_add_co_ci_u32_e64 v62, null, 0, v2, vcc_lo               // 000000014948: D5207C3E 01AA0480
	.long 0xd7006a3f                                           // 000000014950: D7006A3F
	v_cndmask_b32_e32 v1, 0x6000, v1, vcc_lo                   // 000000014954: 020202FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001495C: BF8700A1
	v_add_co_ci_u32_e64 v64, null, 0, v2, vcc_lo               // 000000014960: D5207C40 01AA0480
	.long 0xd7006a49                                           // 000000014968: D7006A49
	v_cndmask_b32_e32 v1, 0x7000, v1, vcc_lo                   // 00000001496C: 020202FF 00007000
	v_add_co_ci_u32_e64 v74, null, 0, v2, vcc_lo               // 000000014974: D5207C4A 01AA0480
	.long 0xd7006a4d                                           // 00000001497C: D7006A4D
	v_cndmask_b32_e32 v0, v1, v255, vcc_lo                     // 000000014980: 0201FF01
	.long 0x00008000                                           // 000000014984: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000014988: BF870001
	v_add_co_ci_u32_e64 v78, null, 0, v2, vcc_lo               // 00000001498C: D5207C4E 01AA0480
	s_clause 0x7                                               // 000000014994: BF850007
	global_store_b32 v[59:60], v52, off offset:1024            // 000000014998: DC6A0400 007C343B
	global_store_b32 v[59:60], v54, off offset:2048            // 0000000149A0: DC6A0800 007C363B
	global_store_b32 v[59:60], v55, off offset:3072            // 0000000149A8: DC6A0C00 007C373B
	global_store_b32 v[63:64], v56, off offset:1024            // 0000000149B0: DC6A0400 007C383F
	global_store_b32 v[63:64], v57, off offset:2048            // 0000000149B8: DC6A0800 007C393F
	global_store_b32 v[63:64], v58, off offset:3072            // 0000000149C0: DC6A0C00 007C3A3F
	global_store_b32 v[73:74], v50, off offset:1024            // 0000000149C8: DC6A0400 007C3249
	global_store_b32 v[73:74], v51, off offset:2048            // 0000000149D0: DC6A0800 007C3349
	.long 0xd7006a32                                           // 0000000149D8: D7006A32
	v_cndmask_b32_e32 v1, 0x8000, v1, vcc_lo                   // 0000000149DC: 020202FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000149E4: BF8700A1
	v_add_co_ci_u32_e64 v51, null, 0, v2, vcc_lo               // 0000000149E8: D5207C33 01AA0480
	.long 0xd7006a36                                           // 0000000149F0: D7006A36
	v_cndmask_b32_e32 v1, 0x9000, v1, vcc_lo                   // 0000000149F4: 020202FF 00009000
	v_add_co_ci_u32_e64 v55, null, 0, v2, vcc_lo               // 0000000149FC: D5207C37 01AA0480
	.long 0xd7006a38                                           // 000000014A04: D7006A38
	v_cndmask_b32_e32 v0, v1, v255, vcc_lo                     // 000000014A08: 0201FF01
	.long 0x0000a000                                           // 000000014A0C: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000014A10: BF8700A1
	v_add_co_ci_u32_e64 v57, null, 0, v2, vcc_lo               // 000000014A14: D5207C39 01AA0480
	.long 0xd7006a3a                                           // 000000014A1C: D7006A3A
	v_cndmask_b32_e32 v1, 0xa000, v1, vcc_lo                   // 000000014A20: 020202FF 0000A000
	v_add_co_ci_u32_e64 v59, null, 0, v2, vcc_lo               // 000000014A28: D5207C3B 01AA0480
	s_clause 0x7                                               // 000000014A30: BF850007
	global_store_b32 v[73:74], v41, off offset:3072            // 000000014A34: DC6A0C00 007C2949
	global_store_b32 v[50:51], v43, off offset:1024            // 000000014A3C: DC6A0400 007C2B32
	global_store_b32 v[50:51], v44, off offset:2048            // 000000014A44: DC6A0800 007C2C32
	global_store_b32 v[50:51], v46, off offset:3072            // 000000014A4C: DC6A0C00 007C2E32
	global_store_b32 v[54:55], v47, off offset:1024            // 000000014A54: DC6A0400 007C2F36
	global_store_b32 v[54:55], v48, off offset:2048            // 000000014A5C: DC6A0800 007C3036
	global_store_b32 v[54:55], v49, off offset:3072            // 000000014A64: DC6A0C00 007C3136
	global_store_b32 v[58:59], v42, off offset:1024            // 000000014A6C: DC6A0400 007C2A3A
	.long 0xd7006a29                                           // 000000014A74: D7006A29
	v_cndmask_b32_e32 v1, 0xb000, v1, vcc_lo                   // 000000014A78: 020202FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000014A80: BF8700A1
	v_add_co_ci_u32_e64 v42, null, 0, v2, vcc_lo               // 000000014A84: D5207C2A 01AA0480
	.long 0xd7006a2b                                           // 000000014A8C: D7006A2B
	v_cndmask_b32_e32 v0, v1, v255, vcc_lo                     // 000000014A90: 0201FF01
	.long 0x0000c000                                           // 000000014A94: 0000C000
	v_add_co_ci_u32_e64 v44, null, 0, v2, vcc_lo               // 000000014A98: D5207C2C 01AA0480
	.long 0xd7006a2e                                           // 000000014AA0: D7006A2E
	v_cndmask_b32_e32 v1, 0xc000, v1, vcc_lo                   // 000000014AA4: 020202FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000014AAC: BF870001
	v_add_co_ci_u32_e64 v47, null, 0, v2, vcc_lo               // 000000014AB0: D5207C2F 01AA0480
	s_clause 0x7                                               // 000000014AB8: BF850007
	global_store_b32 v[58:59], v34, off offset:2048            // 000000014ABC: DC6A0800 007C223A
	global_store_b32 v[58:59], v35, off offset:3072            // 000000014AC4: DC6A0C00 007C233A
	global_store_b32 v[41:42], v38, off offset:1024            // 000000014ACC: DC6A0400 007C2629
	global_store_b32 v[41:42], v39, off offset:2048            // 000000014AD4: DC6A0800 007C2729
	global_store_b32 v[41:42], v40, off offset:3072            // 000000014ADC: DC6A0C00 007C2829
	global_store_b32 v[46:47], v30, off offset:1024            // 000000014AE4: DC6A0400 007C1E2E
	global_store_b32 v[46:47], v31, off offset:2048            // 000000014AEC: DC6A0800 007C1F2E
	global_store_b32 v[46:47], v33, off offset:3072            // 000000014AF4: DC6A0C00 007C212E
	.long 0xd7006a1e                                           // 000000014AFC: D7006A1E
	v_cndmask_b32_e32 v1, 0xd000, v1, vcc_lo                   // 000000014B00: 020202FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000014B08: BF8700A1
	v_add_co_ci_u32_e64 v31, null, 0, v2, vcc_lo               // 000000014B0C: D5207C1F 01AA0480
	.long 0xd7006a21                                           // 000000014B14: D7006A21
	v_cndmask_b32_e32 v0, v1, v255, vcc_lo                     // 000000014B18: 0201FF01
	.long 0x0000e000                                           // 000000014B1C: 0000E000
	v_add_co_ci_u32_e64 v34, null, 0, v2, vcc_lo               // 000000014B20: D5207C22 01AA0480
	.long 0xd7006a26                                           // 000000014B28: D7006A26
	v_cndmask_b32_e32 v1, 0xe000, v1, vcc_lo                   // 000000014B2C: 020202FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000014B34: BF870001
	v_add_co_ci_u32_e64 v39, null, 0, v2, vcc_lo               // 000000014B38: D5207C27 01AA0480
	.long 0xd7006a01                                           // 000000014B40: D7006A01
	v_cndmask_b32_e32 v1, 0xf000, v1, vcc_lo                   // 000000014B44: 020202FF 0000F000
	s_clause 0x7                                               // 000000014B4C: BF850007
	global_store_b32 v[77:78], v10, off offset:-4096           // 000000014B50: DC6A1000 007C0A4D
	global_store_b32 v[77:78], v11, off                        // 000000014B58: DC6A0000 007C0B4D
	global_store_b32 v[56:57], v13, off offset:-4096           // 000000014B60: DC6A1000 007C0D38
	global_store_b32 v[56:57], v14, off                        // 000000014B68: DC6A0000 007C0E38
	global_store_b32 v[43:44], v26, off offset:-4096           // 000000014B70: DC6A1000 007C1A2B
	global_store_b32 v[43:44], v27, off                        // 000000014B78: DC6A0000 007C1B2B
	global_store_b32 v[33:34], v28, off offset:-4096           // 000000014B80: DC6A1000 007C1C21
	global_store_b32 v[33:34], v29, off                        // 000000014B88: DC6A0000 007C1D21
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000014B90: D5207C02 01AA0480
	s_clause 0xf                                               // 000000014B98: BF85000F
	global_store_b32 v[30:31], v19, off offset:1024            // 000000014B9C: DC6A0400 007C131E
	global_store_b32 v[30:31], v20, off offset:2048            // 000000014BA4: DC6A0800 007C141E
	global_store_b32 v[30:31], v21, off offset:3072            // 000000014BAC: DC6A0C00 007C151E
	global_store_b32 v[38:39], v22, off offset:1024            // 000000014BB4: DC6A0400 007C1626
	global_store_b32 v[38:39], v23, off offset:2048            // 000000014BBC: DC6A0800 007C1726
	global_store_b32 v[38:39], v25, off offset:3072            // 000000014BC4: DC6A0C00 007C1926
	global_store_b32 v[1:2], v15, off                          // 000000014BCC: DC6A0000 007C0F01
	global_store_b32 v[1:2], v17, off offset:1024              // 000000014BD4: DC6A0400 007C1101
	global_store_b32 v[1:2], v18, off offset:2048              // 000000014BDC: DC6A0800 007C1201
	global_store_b32 v[75:76], v3, off offset:-4096            // 000000014BE4: DC6A1000 007C034B
	global_store_b32 v[75:76], v4, off                         // 000000014BEC: DC6A0000 007C044B
	global_store_b32 v[79:80], v5, off offset:-4096            // 000000014BF4: DC6A1000 007C054F
	global_store_b32 v[79:80], v6, off                         // 000000014BFC: DC6A0000 007C064F
	global_store_b32 v[61:62], v7, off offset:-4096            // 000000014C04: DC6A1000 007C073D
	global_store_b32 v[61:62], v9, off                         // 000000014C0C: DC6A0000 007C093D
	global_store_b32 v[1:2], v12, off offset:3072              // 000000014C14: DC6A0C00 007C0C01
	s_branch 60531                                             // 000000014C1C: BFA0EC73 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x8ec>
	s_clause 0x1                                               // 000000014C20: BF850001
	scratch_load_b64 v[78:79], off, off                        // 000000014C24: DC550000 4E7C0000
	scratch_load_b64 v[137:138], off, off offset:8             // 000000014C2C: DC550008 897C0000
	s_branch 8                                                 // 000000014C34: BFA00008 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi0ELb1ELb1ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5758>
	v_dual_mov_b32 v53, v154 :: v_dual_mov_b32 v16, v151       // 000000014C38: CA10019A 35100197
	v_dual_mov_b32 v45, v153 :: v_dual_mov_b32 v8, v150        // 000000014C40: CA100199 2D080196
	v_dual_mov_b32 v37, v152 :: v_dual_mov_b32 v24, v149       // 000000014C48: CA100198 25180195
	v_mov_b32_e32 v36, v148                                    // 000000014C50: 7E480394
	v_mov_b32_e32 v32, v147                                    // 000000014C54: 7E400393
	.long 0xd7006a00                                           // 000000014C58: D7006A00
	v_cndmask_b32_e32 v0, v190, v255, vcc_lo                   // 000000014C5C: 0201FFBE
	.long 0x00002000                                           // 000000014C60: 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000014C64: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v191, vcc_lo              // 000000014C68: D5207C01 01AB7E80
	v_dual_mul_f32 v4, 0x3b800000, v129 :: v_dual_mul_f32 v13, 0x3b800000, v128// 000000014C70: C8C702FF 040D00FF 3B800000
	v_dual_mul_f32 v5, 0x3b800000, v53 :: v_dual_mul_f32 v14, 0x3b800000, v127// 000000014C7C: C8C66AFF 050EFEFF 3B800000
	.long 0xd7006a02                                           // 000000014C88: D7006A02
	v_cndmask_b32_e32 v0, v190, v255, vcc_lo                   // 000000014C8C: 0201FFBE
	.long 0x00004000                                           // 000000014C90: 00004000
	v_dual_mul_f32 v15, 0x3b800000, v126 :: v_dual_mul_f32 v18, 0x3b800000, v124// 000000014C94: C8C6FCFF 0F12F8FF 3B800000
	v_mul_f32_e32 v17, 0x3b800000, v125                        // 000000014CA0: 1022FAFF 3B800000
	v_add_co_ci_u32_e64 v3, null, 0, v191, vcc_lo              // 000000014CA8: D5207C03 01AB7E80
	v_mul_f32_e32 v19, 0x3b800000, v123                        // 000000014CB0: 1026F6FF 3B800000
	s_clause 0x7                                               // 000000014CB8: BF850007
	global_store_b32 v[0:1], v4, off offset:-2048              // 000000014CBC: DC6A1800 007C0400
	global_store_b32 v[0:1], v5, off offset:-1024              // 000000014CC4: DC6A1C00 007C0500
	global_store_b32 v[0:1], v13, off                          // 000000014CCC: DC6A0000 007C0D00
	global_store_b32 v[0:1], v14, off offset:1024              // 000000014CD4: DC6A0400 007C0E00
	global_store_b32 v[0:1], v15, off offset:2048              // 000000014CDC: DC6A0800 007C0F00
	global_store_b32 v[0:1], v17, off offset:3072              // 000000014CE4: DC6A0C00 007C1100
	global_store_b32 v[2:3], v18, off offset:-4096             // 000000014CEC: DC6A1000 007C1202
	global_store_b32 v[2:3], v19, off offset:-3072             // 000000014CF4: DC6A1400 007C1302
	v_dual_mul_f32 v13, 0x3b800000, v122 :: v_dual_mul_f32 v20, 0x3b800000, v117// 000000014CFC: C8C6F4FF 0D14EAFF 3B800000
	v_mul_f32_e32 v14, 0x3b800000, v45                         // 000000014D08: 101C5AFF 3B800000
	v_mul_f32_e32 v15, 0x3b800000, v121                        // 000000014D10: 101EF2FF 3B800000
	v_mul_f32_e32 v17, 0x3b800000, v120                        // 000000014D18: 1022F0FF 3B800000
	.long 0xd7006a04                                           // 000000014D20: D7006A04
	v_cndmask_b32_e32 v0, v190, v255, vcc_lo                   // 000000014D24: 0201FFBE
	.long 0x00006000                                           // 000000014D28: 00006000
	v_dual_mul_f32 v18, 0x3b800000, v119 :: v_dual_mul_f32 v19, 0x3b800000, v118// 000000014D2C: C8C6EEFF 1212ECFF 3B800000
	v_add_co_ci_u32_e64 v5, null, 0, v191, vcc_lo              // 000000014D38: D5207C05 01AB7E80
	v_mul_f32_e32 v21, 0x3b800000, v116                        // 000000014D40: 102AE8FF 3B800000
	s_clause 0x7                                               // 000000014D48: BF850007
	global_store_b32 v[2:3], v13, off offset:-2048             // 000000014D4C: DC6A1800 007C0D02
	global_store_b32 v[2:3], v14, off offset:-1024             // 000000014D54: DC6A1C00 007C0E02
	global_store_b32 v[2:3], v15, off                          // 000000014D5C: DC6A0000 007C0F02
	global_store_b32 v[2:3], v17, off offset:1024              // 000000014D64: DC6A0400 007C1102
	global_store_b32 v[2:3], v18, off offset:2048              // 000000014D6C: DC6A0800 007C1202
	global_store_b32 v[2:3], v19, off offset:3072              // 000000014D74: DC6A0C00 007C1302
	global_store_b32 v[4:5], v20, off offset:-4096             // 000000014D7C: DC6A1000 007C1404
	global_store_b32 v[4:5], v21, off offset:-3072             // 000000014D84: DC6A1400 007C1504
	v_dual_mul_f32 v13, 0x3b800000, v115 :: v_dual_mul_f32 v14, 0x3b800000, v37// 000000014D8C: C8C6E6FF 0D0E4AFF 3B800000
	v_mul_f32_e32 v15, 0x3b800000, v114                        // 000000014D98: 101EE4FF 3B800000
	v_mul_f32_e32 v17, 0x3b800000, v113                        // 000000014DA0: 1022E2FF 3B800000
	.long 0xd7006a02                                           // 000000014DA8: D7006A02
	v_cndmask_b32_e32 v0, v190, v255, vcc_lo                   // 000000014DAC: 0201FFBE
	.long 0x00008000                                           // 000000014DB0: 00008000
	v_dual_mul_f32 v18, 0x3b800000, v112 :: v_dual_mul_f32 v19, 0x3b800000, v111// 000000014DB4: C8C6E0FF 1212DEFF 3B800000
	v_mul_f32_e32 v8, 0x3b800000, v8                           // 000000014DC0: 101010FF 3B800000
	v_mul_f32_e32 v20, 0x3b800000, v110                        // 000000014DC8: 1028DCFF 3B800000
	v_add_co_ci_u32_e64 v3, null, 0, v191, vcc_lo              // 000000014DD0: D5207C03 01AB7E80
	v_mul_f32_e32 v21, 0x3b800000, v109                        // 000000014DD8: 102ADAFF 3B800000
	s_clause 0x7                                               // 000000014DE0: BF850007
	global_store_b32 v[4:5], v13, off offset:-2048             // 000000014DE4: DC6A1800 007C0D04
	global_store_b32 v[4:5], v14, off offset:-1024             // 000000014DEC: DC6A1C00 007C0E04
	global_store_b32 v[4:5], v15, off                          // 000000014DF4: DC6A0000 007C0F04
	global_store_b32 v[4:5], v17, off offset:1024              // 000000014DFC: DC6A0400 007C1104
	global_store_b32 v[4:5], v18, off offset:2048              // 000000014E04: DC6A0800 007C1204
	global_store_b32 v[4:5], v19, off offset:3072              // 000000014E0C: DC6A0C00 007C1304
	global_store_b32 v[2:3], v20, off offset:-4096             // 000000014E14: DC6A1000 007C1402
	global_store_b32 v[2:3], v21, off offset:-3072             // 000000014E1C: DC6A1400 007C1502
	v_mul_f32_e32 v13, 0x3b800000, v108                        // 000000014E24: 101AD8FF 3B800000
	v_dual_mul_f32 v15, 0x3b800000, v107 :: v_dual_mul_f32 v14, 0x3b800000, v16// 000000014E2C: C8C6D6FF 0F0E20FF 3B800000
	v_mul_f32_e32 v16, 0x3b800000, v106                        // 000000014E38: 1020D4FF 3B800000
	.long 0xd7006a04                                           // 000000014E40: D7006A04
	v_cndmask_b32_e32 v0, v190, v255, vcc_lo                   // 000000014E44: 0201FFBE
	.long 0x0000a000                                           // 000000014E48: 0000A000
	v_dual_mul_f32 v17, 0x3b800000, v105 :: v_dual_mul_f32 v18, 0x3b800000, v104// 000000014E4C: C8C6D2FF 1112D0FF 3B800000
	v_add_co_ci_u32_e64 v5, null, 0, v191, vcc_lo              // 000000014E58: D5207C05 01AB7E80
	v_dual_mul_f32 v19, 0x3b800000, v103 :: v_dual_mul_f32 v20, 0x3b800000, v102// 000000014E60: C8C6CEFF 1314CCFF 3B800000
	v_mul_f32_e32 v21, 0x3b800000, v101                        // 000000014E6C: 102ACAFF 3B800000
	s_clause 0x7                                               // 000000014E74: BF850007
	global_store_b32 v[2:3], v13, off offset:-2048             // 000000014E78: DC6A1800 007C0D02
	global_store_b32 v[2:3], v15, off                          // 000000014E80: DC6A0000 007C0F02
	global_store_b32 v[2:3], v16, off offset:1024              // 000000014E88: DC6A0400 007C1002
	global_store_b32 v[2:3], v17, off offset:2048              // 000000014E90: DC6A0800 007C1102
	global_store_b32 v[2:3], v18, off offset:3072              // 000000014E98: DC6A0C00 007C1202
	global_store_b32 v[4:5], v19, off offset:-4096             // 000000014EA0: DC6A1000 007C1304
	global_store_b32 v[4:5], v20, off offset:-3072             // 000000014EA8: DC6A1400 007C1404
	global_store_b32 v[4:5], v21, off offset:-2048             // 000000014EB0: DC6A1800 007C1504
	v_mul_f32_e32 v13, 0x3b800000, v100                        // 000000014EB8: 101AC8FF 3B800000
	v_dual_mul_f32 v15, 0x3b800000, v99 :: v_dual_mul_f32 v16, 0x3b800000, v98// 000000014EC0: C8C6C6FF 0F10C4FF 3B800000
	.long 0xd7006a02                                           // 000000014ECC: D7006A02
	v_cndmask_b32_e32 v0, v190, v255, vcc_lo                   // 000000014ED0: 0201FFBE
	.long 0x0000c000                                           // 000000014ED4: 0000C000
	v_dual_mul_f32 v17, 0x3b800000, v97 :: v_dual_mul_f32 v18, 0x3b800000, v96// 000000014ED8: C8C6C2FF 1112C0FF 3B800000
	v_add_co_ci_u32_e64 v3, null, 0, v191, vcc_lo              // 000000014EE4: D5207C03 01AB7E80
	v_dual_mul_f32 v19, 0x3b800000, v95 :: v_dual_mul_f32 v20, 0x3b800000, v94// 000000014EEC: C8C6BEFF 1314BCFF 3B800000
	s_clause 0x7                                               // 000000014EF8: BF850007
	global_store_b32 v[4:5], v8, off offset:-1024              // 000000014EFC: DC6A1C00 007C0804
	global_store_b32 v[4:5], v13, off                          // 000000014F04: DC6A0000 007C0D04
	global_store_b32 v[4:5], v15, off offset:1024              // 000000014F0C: DC6A0400 007C0F04
	global_store_b32 v[4:5], v16, off offset:2048              // 000000014F14: DC6A0800 007C1004
	global_store_b32 v[4:5], v17, off offset:3072              // 000000014F1C: DC6A0C00 007C1104
	global_store_b32 v[2:3], v18, off offset:-4096             // 000000014F24: DC6A1000 007C1202
	global_store_b32 v[2:3], v19, off offset:-3072             // 000000014F2C: DC6A1400 007C1302
	global_store_b32 v[2:3], v20, off offset:-2048             // 000000014F34: DC6A1800 007C1402
	v_dual_mul_f32 v8, 0x3b800000, v24 :: v_dual_mul_f32 v13, 0x3b800000, v93// 000000014F3C: C8C630FF 080CBAFF 3B800000
	v_dual_mul_f32 v15, 0x3b800000, v92 :: v_dual_mul_f32 v16, 0x3b800000, v91// 000000014F48: C8C6B8FF 0F10B6FF 3B800000
	.long 0xd7006a04                                           // 000000014F54: D7006A04
	v_cndmask_b32_e32 v0, v190, v255, vcc_lo                   // 000000014F58: 0201FFBE
	.long 0x0000e000                                           // 000000014F5C: 0000E000
	v_dual_mul_f32 v17, 0x3b800000, v90 :: v_dual_mul_f32 v6, 0x3b800000, v135// 000000014F60: C8C6B4FF 11070EFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v134 :: v_dual_mul_f32 v18, 0x3b800000, v89// 000000014F6C: C8C70CFF 0712B2FF 3B800000
	v_add_co_ci_u32_e64 v5, null, 0, v191, vcc_lo              // 000000014F78: D5207C05 01AB7E80
	v_dual_mul_f32 v19, 0x3b800000, v88 :: v_dual_mul_f32 v20, 0x3b800000, v87// 000000014F80: C8C6B0FF 1314AEFF 3B800000
	s_clause 0x7                                               // 000000014F8C: BF850007
	global_store_b32 v[2:3], v8, off offset:-1024              // 000000014F90: DC6A1C00 007C0802
	global_store_b32 v[2:3], v13, off                          // 000000014F98: DC6A0000 007C0D02
	global_store_b32 v[2:3], v15, off offset:1024              // 000000014FA0: DC6A0400 007C0F02
	global_store_b32 v[2:3], v16, off offset:2048              // 000000014FA8: DC6A0800 007C1002
	global_store_b32 v[2:3], v17, off offset:3072              // 000000014FB0: DC6A0C00 007C1102
	global_store_b32 v[4:5], v18, off offset:-4096             // 000000014FB8: DC6A1000 007C1204
	global_store_b32 v[4:5], v19, off offset:-3072             // 000000014FC0: DC6A1400 007C1304
	global_store_b32 v[4:5], v20, off offset:-2048             // 000000014FC8: DC6A1800 007C1404
	v_dual_mul_f32 v8, 0x3b800000, v36 :: v_dual_mul_f32 v13, 0x3b800000, v86// 000000014FD0: C8C648FF 080CACFF 3B800000
	v_dual_mul_f32 v9, 0x3b800000, v133 :: v_dual_mul_f32 v10, 0x3b800000, v132// 000000014FDC: C8C70AFF 090B08FF 3B800000
	v_dual_mul_f32 v15, 0x3b800000, v85 :: v_dual_mul_f32 v16, 0x3b800000, v84// 000000014FE8: C8C6AAFF 0F10A8FF 3B800000
	.long 0xd7006a02                                           // 000000014FF4: D7006A02
	v_cndmask_b32_e32 v0, v190, v255, vcc_lo                   // 000000014FF8: 0201FFBE
	.long 0x0000f800                                           // 000000014FFC: 0000F800
	v_mul_f32_e32 v17, 0x3b800000, v83                         // 000000015000: 1022A6FF 3B800000
	v_dual_mul_f32 v11, 0x3b800000, v131 :: v_dual_mul_f32 v12, 0x3b800000, v130// 000000015008: C8C706FF 0B0D04FF 3B800000
	v_mul_f32_e32 v18, 0x3b800000, v82                         // 000000015014: 1024A4FF 3B800000
	v_add_co_ci_u32_e64 v3, null, 0, v191, vcc_lo              // 00000001501C: D5207C03 01AB7E80
	v_mul_f32_e32 v19, 0x3b800000, v81                         // 000000015024: 1026A2FF 3B800000
	v_mul_f32_e32 v20, 0x3b800000, v141                        // 00000001502C: 10291AFF 3B800000
	s_clause 0x7                                               // 000000015034: BF850007
	global_store_b32 v[4:5], v8, off offset:-1024              // 000000015038: DC6A1C00 007C0804
	global_store_b32 v[4:5], v13, off                          // 000000015040: DC6A0000 007C0D04
	global_store_b32 v[4:5], v15, off offset:1024              // 000000015048: DC6A0400 007C0F04
	global_store_b32 v[4:5], v16, off offset:2048              // 000000015050: DC6A0800 007C1004
	global_store_b32 v[4:5], v17, off offset:3072              // 000000015058: DC6A0C00 007C1104
	global_store_b32 v[2:3], v18, off offset:-2048             // 000000015060: DC6A1800 007C1202
	global_store_b32 v[2:3], v19, off offset:-1024             // 000000015068: DC6A1C00 007C1302
	global_store_b32 v[2:3], v20, off                          // 000000015070: DC6A0000 007C1402
	v_mul_f32_e32 v2, 0x3b800000, v32                          // 000000015078: 100440FF 3B800000
	s_clause 0x3                                               // 000000015080: BF850003
	global_store_b32 v[190:191], v6, off                       // 000000015084: DC6A0000 007C06BE
	global_store_b32 v[190:191], v7, off offset:1024           // 00000001508C: DC6A0400 007C07BE
	global_store_b32 v[190:191], v9, off offset:2048           // 000000015094: DC6A0800 007C09BE
	global_store_b32 v[190:191], v10, off offset:3072          // 00000001509C: DC6A0C00 007C0ABE
	s_waitcnt vmcnt(1)                                         // 0000000150A4: BF8907F7
	s_clause 0x2                                               // 0000000150A8: BF850002
	global_store_b32 v[78:79], v14, off                        // 0000000150AC: DC6A0000 007C0E4E
	global_store_b32 v[0:1], v11, off offset:-4096             // 0000000150B4: DC6A1000 007C0B00
	global_store_b32 v[0:1], v12, off offset:-3072             // 0000000150BC: DC6A1400 007C0C00
	s_waitcnt vmcnt(0)                                         // 0000000150C4: BF8903F7
	global_store_b32 v[137:138], v2, off                       // 0000000150C8: DC6A0000 007C0289
	s_endpgm                                                   // 0000000150D0: BFB00000
		...

