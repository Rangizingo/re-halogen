00000000000f8600 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000F8600: BF850001
	s_load_b512 s[8:23], s[0:1], 0x8                           // 0000000F8604: F4100200 F8000008
	s_load_b128 s[24:27], s[0:1], 0x48                         // 0000000F860C: F4080600 F8000048
	s_mov_b32 s4, s3                                           // 0000000F8614: BE840003
	s_ashr_i32 s3, s2, 31                                      // 0000000F8618: 86039F02
	s_lshl_b32 s6, s4, 2                                       // 0000000F861C: 84068204
	s_lshl_b64 s[28:29], s[2:3], 14                            // 0000000F8620: 849C8E02
	v_cmp_gt_u32_e32 vcc_lo, 0x200, v0                         // 0000000F8624: 7C9800FF 00000200
	v_and_b32_e32 v47, 3, v0                                   // 0000000F862C: 365E0083
	v_or_b32_e32 v45, 0xffffff80, v0                           // 0000000F8630: 385A00FF FFFFFF80
	v_lshrrev_b32_e32 v46, 2, v0                               // 0000000F8638: 325C0082
	s_waitcnt lgkmcnt(0)                                       // 0000000F863C: BF89FC07
	s_load_b32 s5, s[22:23], null                              // 0000000F8640: F400014B F8000000
	s_add_u32 s4, s24, s28                                     // 0000000F8648: 80041C18
	s_addc_u32 s23, s25, s29                                   // 0000000F864C: 82171D19
	s_waitcnt lgkmcnt(0)                                       // 0000000F8650: BF89FC07
	s_mul_hi_i32 s7, s5, 0x2400000                             // 0000000F8654: 9707FF05 02400000
	s_mul_i32 s5, s5, 0x2400000                                // 0000000F865C: 9605FF05 02400000
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F8664: BF870009
	s_add_u32 s22, s4, s5                                      // 0000000F8668: 80160504
	s_addc_u32 s23, s23, s7                                    // 0000000F866C: 82170717
	s_and_saveexec_b32 s24, vcc_lo                             // 0000000F8670: BE98206A
	s_cbranch_execz 55                                         // 0000000F8674: BFA50037 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x154>
	s_ashr_i32 s7, s6, 31                                      // 0000000F8678: 86079F06
	v_lshlrev_b32_e32 v1, 9, v46                               // 0000000F867C: 30025C89
	s_lshl_b64 s[4:5], s[22:23], 2                             // 0000000F8680: 84848216
	s_lshl_b64 s[30:31], s[6:7], 2                             // 0000000F8684: 849E8206
	v_lshlrev_b32_e32 v2, 2, v47                               // 0000000F8688: 30045E82
	s_add_u32 s4, s30, s4                                      // 0000000F868C: 8004041E
	s_addc_u32 s5, s31, s5                                     // 0000000F8690: 8205051F
	.long 0xd7000401                                           // 0000000F8694: D7000401
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000000F8698: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000F869C: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s5, 0, s4                    // 0000000F86A0: D5207C04 00110005
	v_or_b32_e32 v3, 0xffffff80, v0                            // 0000000F86A8: 380600FF FFFFFF80
	.long 0xd7000401                                           // 0000000F86B0: D7000401
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000F86B4: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000F86B8: BF8701A1
	v_add_co_ci_u32_e64 v5, null, 0, v4, s4                    // 0000000F86BC: D5207C05 00120880
	v_mad_u32_u24 v4, v46, 20, v2                              // 0000000F86C4: D60B0004 0409292E
	.long 0xd7000401                                           // 0000000F86CC: D7000401
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 0000000F86D0: 02020214
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F86D4: BF870001
	v_add_co_ci_u32_e64 v2, null, s21, v5, s4                  // 0000000F86D8: D5207C02 00120A15
	s_mov_b32 s7, 0                                            // 0000000F86E0: BE870080
	s_nop 0                                                    // 0000000F86E4: BF800000
	s_nop 0                                                    // 0000000F86E8: BF800000
	s_nop 0                                                    // 0000000F86EC: BF800000
	s_nop 0                                                    // 0000000F86F0: BF800000
	s_nop 0                                                    // 0000000F86F4: BF800000
	s_nop 0                                                    // 0000000F86F8: BF800000
	s_nop 0                                                    // 0000000F86FC: BF800000
	global_load_b32 v5, v[1:2], off                            // 0000000F8700: DC520000 057C0001
	v_add_nc_u32_e32 v3, 0x80, v3                              // 0000000F8708: 4A0606FF 00000080
	.long 0xd7000401                                           // 0000000F8710: D7000401
	v_cndmask_b32_e32 v1, 0x4000, v1, vcc_lo                   // 0000000F8714: 020202FF 00004000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000F871C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, s4                    // 0000000F8720: D5207C02 00120480
	.long 0xd4490005                                           // 0000000F8728: D4490005
	v_cndmask_b32_e32 v1, 0x17f, v3, vcc_lo                    // 0000000F872C: 020206FF 0000017F
	s_or_b32 s7, s5, s7                                        // 0000000F8734: 8C070705
	s_waitcnt vmcnt(0)                                         // 0000000F8738: BF8903F7
	ds_store_b32 v4, v5 offset:16512                           // 0000000F873C: D8344080 00000504
	v_add_nc_u32_e32 v4, 0x280, v4                             // 0000000F8744: 4A0808FF 00000280
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000000F874C: 917E077E
	s_cbranch_execnz 65515                                     // 0000000F8750: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x100>
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000F8754: 8C7E187E
	s_load_b32 s24, s[0:1], 0x58                               // 0000000F8758: F4000600 F8000058
	s_waitcnt lgkmcnt(0)                                       // 0000000F8760: BF89FC07
	s_barrier                                                  // 0000000F8764: BFBD0000
	buffer_gl0_inv                                             // 0000000F8768: E0AC0000 00000000
	s_cmp_lt_i32 s24, 1                                        // 0000000F8770: BF048118
	s_cbranch_scc1 1504                                        // 0000000F8774: BFA205E0 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x18f8>
	s_add_i32 s0, s24, 63                                      // 0000000F8778: 8100BF18
	s_ashr_i32 s7, s6, 31                                      // 0000000F877C: 86079F06
	s_lshr_b32 s25, s0, 6                                      // 0000000F8780: 85198600
	s_lshl_b64 s[0:1], s[6:7], 2                               // 0000000F8784: 84808206
	s_add_i32 s30, s2, 0xbd0                                   // 0000000F8788: 811EFF02 00000BD0
	s_add_u32 s14, s14, s0                                     // 0000000F8790: 800E000E
	s_addc_u32 s15, s15, s1                                    // 0000000F8794: 820F010F
	s_lshl_b32 s4, s2, 7                                       // 0000000F8798: 84048702
	v_lshlrev_b32_e32 v3, 1, v47                               // 0000000F879C: 30065E81
	s_ashr_i32 s5, s4, 31                                      // 0000000F87A0: 86059F04
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000000F87A4: 30020082
	s_lshl_b64 s[4:5], s[4:5], 1                               // 0000000F87A8: 84848104
	v_lshlrev_b32_e32 v5, 6, v0                                // 0000000F87AC: 300A0086
	s_add_u32 s26, s26, s4                                     // 0000000F87B0: 801A041A
	s_addc_u32 s27, s27, s5                                    // 0000000F87B4: 821B051B
	s_lshl_b64 s[4:5], s[6:7], 1                               // 0000000F87B8: 84848106
	v_lshlrev_b32_e32 v50, 2, v47                              // 0000000F87BC: 30645E82
	s_add_u32 s4, s26, s4                                      // 0000000F87C0: 8004041A
	s_addc_u32 s5, s27, s5                                     // 0000000F87C4: 8205051B
	.long 0xd7000403                                           // 0000000F87C8: D7000403
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000000F87CC: 02020604
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F87D0: BF8700D1
	v_add_co_ci_u32_e64 v4, null, s5, 0, s4                    // 0000000F87D4: D5207C04 00110005
	.long 0xd700043c                                           // 0000000F87DC: D700043C
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000000F87E0: 02020208
	v_and_b32_e32 v5, 0x1f00, v5                               // 0000000F87E4: 360A0AFF 00001F00
	v_add_co_ci_u32_e64 v61, null, s9, 0, s4                   // 0000000F87EC: D5207C3D 00110009
	.long 0xd700043e                                           // 0000000F87F4: D700043E
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 0000000F87F8: 0202020A
	v_add_co_ci_u32_e64 v63, null, s11, 0, s4                  // 0000000F87FC: D5207C3F 0011000B
	s_add_u32 s4, s18, s28                                     // 0000000F8804: 80041C12
	s_addc_u32 s5, s19, s29                                    // 0000000F8808: 82051D13
	.long 0xd7000405                                           // 0000000F880C: D7000405
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000000F8810: 02020A04
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F8814: BF870001
	v_add_co_ci_u32_e64 v6, null, s5, 0, s4                    // 0000000F8818: D5207C06 00110005
	s_lshl_b64 s[4:5], s[2:3], 9                               // 0000000F8820: 84848902
	v_or_b32_e32 v55, 0x4a80, v50                              // 0000000F8824: 386E64FF 00004A80
	v_mov_b32_e32 v10, s5                                      // 0000000F882C: 7E140205
	v_or_b32_e32 v9, s4, v1                                    // 0000000F8830: 38120204
	.long 0xd7000407                                           // 0000000F8834: D7000407
	v_cndmask_b32_e32 v1, 0x2000, v5, vcc_lo                   // 0000000F8838: 02020AFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000F8840: BF870191
	v_add_co_ci_u32_e64 v8, null, 0, v6, s4                    // 0000000F8844: D5207C08 00120C80
	.long 0xd7000409                                           // 0000000F884C: D7000409
	v_cndmask_b32_e32 v1, s10, v9, vcc_lo                      // 0000000F8850: 0202120A
	.long 0xd7000733                                           // 0000000F8854: D7000733
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 0000000F8858: 02020210
	v_add_co_ci_u32_e64 v10, null, s11, v10, s4                // 0000000F885C: D5207C0A 0012140B
	v_add_co_ci_u32_e64 v52, null, s17, 0, s7                  // 0000000F8864: D5207C34 001D0011
	.long 0xd7000735                                           // 0000000F886C: D7000735
	v_cndmask_b32_e32 v1, s14, v50, vcc_lo                     // 0000000F8870: 0202640E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F8874: BF870001
	v_add_co_ci_u32_e64 v54, null, s15, 0, s7                  // 0000000F8878: D5207C36 001D000F
	s_movk_i32 s7, 0x7c                                        // 0000000F8880: B007007C
	.long 0xd700040b                                           // 0000000F8884: D700040B
	v_cndmask_b32_e32 v1, 0xc0000, v9, vcc_lo                  // 0000000F8888: 020212FF 000C0000
	.long 0xd44c0000                                           // 0000000F8890: D44C0000
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 0000000F8894: 020200C0
	v_add_nc_u32_e32 v48, 0x4f80, v1                           // 0000000F8898: 4A6002FF 00004F80
	v_add_nc_u32_e32 v49, 0x5080, v1                           // 0000000F88A0: 4A6202FF 00005080
	.long 0xd44c0001                                           // 0000000F88A8: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000F88AC: 020200FF 00000080
	v_mul_u32_u24_e32 v56, 0x204, v46                          // 0000000F88B4: 16705CFF 00000204
	v_or_b32_e32 v2, 0x4080, v50                               // 0000000F88BC: 380464FF 00004080
	v_mad_u32_u24 v57, v46, 20, v55                            // 0000000F88C4: D60B0039 04DD292E
	v_and_or_b32 v58, v0, s7, 0x5080                           // 0000000F88CC: D657003A 03FC0F00 00005080
	v_or_b32_e32 v59, 32, v46                                  // 0000000F88D8: 38765CA0
	v_add_nc_u32_e32 v64, 1, v46                               // 0000000F88DC: 4A805C81
	v_add_nc_u32_e32 v65, 33, v46                              // 0000000F88E0: 4A825CA1
	v_or_b32_e32 v66, 0xffffff80, v0                           // 0000000F88E4: 388400FF FFFFFF80
	v_add_co_ci_u32_e64 v12, null, 0, v10, s4                  // 0000000F88EC: D5207C0C 00121480
	s_mov_b32 s7, 0                                            // 0000000F88F4: BE870080
	s_mov_b32 s8, 0                                            // 0000000F88F8: BE880080
	s_branch 30                                                // 0000000F88FC: BFA0001E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x378>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000F8900: 8C7E057E
	.long 0xd7000405                                           // 0000000F8904: D7000405
	v_cndmask_b32_e32 v1, 0xc0000, v5, vcc_lo                  // 0000000F8908: 02020AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F8910: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s4                    // 0000000F8914: D5207C06 00120C80
	.long 0xd7000407                                           // 0000000F891C: D7000407
	v_cndmask_b32_e32 v1, 0xc0000, v7, vcc_lo                  // 0000000F8920: 02020EFF 000C0000
	v_add_co_ci_u32_e64 v8, null, 0, v8, s4                    // 0000000F8928: D5207C08 00121080
	.long 0xd7000409                                           // 0000000F8930: D7000409
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000F8934: 020212FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F893C: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v10, s4                  // 0000000F8940: D5207C0A 00121480
	.long 0xd700040b                                           // 0000000F8948: D700040B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000F894C: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s4                  // 0000000F8954: D5207C0C 00121880
	s_add_i32 s8, s8, 1                                        // 0000000F895C: 81088108
	s_waitcnt lgkmcnt(0)                                       // 0000000F8960: BF89FC07
	s_cmp_eq_u32 s8, s25                                       // 0000000F8964: BF061908
	s_barrier                                                  // 0000000F8968: BFBD0000
	buffer_gl0_inv                                             // 0000000F896C: E0AC0000 00000000
	s_cbranch_scc1 1376                                        // 0000000F8974: BFA20560 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x18f8>
	s_mul_i32 s4, s8, 0xc00                                    // 0000000F8978: 9604FF08 00000C00
	s_lshl_b32 s9, s8, 6                                       // 0000000F8980: 84098608
	s_add_i32 s4, s30, s4                                      // 0000000F8984: 8104041E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000F8988: BF870499
	s_ashr_i32 s5, s4, 31                                      // 0000000F898C: 86059F04
	s_lshl_b64 s[4:5], s[4:5], 2                               // 0000000F8990: 84848204
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F8994: BF870009
	s_add_u32 s4, s12, s4                                      // 0000000F8998: 8004040C
	s_addc_u32 s5, s13, s5                                     // 0000000F899C: 8205050D
	s_load_b32 s10, s[4:5], null                               // 0000000F89A0: F4000282 F8000000
	s_and_saveexec_b32 s5, s0                                  // 0000000F89A8: BE852000
	s_cbranch_execz 77                                         // 0000000F89AC: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4e4>
	v_or_b32_e32 v13, s9, v0                                   // 0000000F89B0: 381A0009
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F89B4: BF870091
	v_mad_u64_u32 v[13:14], null, v13, 48, s[2:3]              // 0000000F89B8: D6FE7C0D 0009610D
	v_ashrrev_i32_e32 v14, 31, v13                             // 0000000F89C0: 341C1A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F89C4: BF870091
	.long 0xd73c000d                                           // 0000000F89C8: D73C000D
	v_cndmask_b32_e32 v1, 2, v13, vcc_lo                       // 0000000F89CC: 02021A82
	.long 0xd700040d                                           // 0000000F89D0: D700040D
	v_cndmask_b32_e32 v1, s12, v13, vcc_lo                     // 0000000F89D4: 02021A0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F89D8: BF8700C1
	v_add_co_ci_u32_e64 v14, null, s13, v14, s4                // 0000000F89DC: D5207C0E 00121C0D
	global_load_b32 v13, v[13:14], off                         // 0000000F89E4: DC520000 0D7C000D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F89EC: BF890007
	v_sub_f32_e32 v14, s10, v13                                // 0000000F89F0: 081C1A0A
	v_dual_mul_f32 v16, 0x3fb8aa3b, v13 :: v_dual_mul_f32 v15, 0x3fb8aa3b, v14// 0000000F89F4: C8C61AFF 100E1CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000F8A00: BF8701A1
	v_fma_f32 v19, 0x3fb8aa3b, v13, -v16                       // 0000000F8A04: D6130013 84421AFF 3FB8AA3B
	v_rndne_f32_e32 v20, v16                                   // 0000000F8A10: 7E284710
	v_fma_f32 v17, 0x3fb8aa3b, v14, -v15                       // 0000000F8A14: D6130011 843E1CFF 3FB8AA3B
	v_rndne_f32_e32 v18, v15                                   // 0000000F8A20: 7E24470F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000F8A24: BF870113
	v_dual_fmac_f32 v19, 0x32a5705f, v13 :: v_dual_sub_f32 v16, v16, v20// 0000000F8A28: C80A1AFF 13102910 32A5705F
	v_sub_f32_e32 v15, v15, v18                                // 0000000F8A34: 081E250F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F8A38: BF870124
	v_fmac_f32_e32 v17, 0x32a5705f, v14                        // 0000000F8A3C: 56221CFF 32A5705F
	.long 0xd41b0004                                           // 0000000F8A44: D41B0004
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v14, vcc_lo              // 0000000F8A48: 02021CFF C2CE8ED0
	v_dual_add_f32 v16, v16, v19 :: v_dual_add_f32 v15, v15, v17// 0000000F8A50: C9082710 100E230F
	v_cvt_i32_f32_e32 v17, v18                                 // 0000000F8A58: 7E221112
	v_cvt_i32_f32_e32 v18, v20                                 // 0000000F8A5C: 7E241114
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000F8A60: BF870193
	v_exp_f32_e32 v16, v16                                     // 0000000F8A64: 7E204B10
	v_exp_f32_e32 v15, v15                                     // 0000000F8A68: 7E1E4B0F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000F8A6C: BF870296
	.long 0xd71c0010                                           // 0000000F8A70: D71C0010
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 0000000F8A74: 02022510
	.long 0xd71c000f                                           // 0000000F8A78: D71C000F
	v_cndmask_b32_e32 v1, v15, v17, vcc_lo                     // 0000000F8A7C: 0202230F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F8A80: BF8700A1
	v_cndmask_b32_e64 v15, 0, v15, s4                          // 0000000F8A84: D501000F 00121E80
	.long 0xd41b0004                                           // 0000000F8A8C: D41B0004
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v13, vcc_lo              // 0000000F8A90: 02021AFF C2CE8ED0
	v_cndmask_b32_e64 v16, 0, v16, s4                          // 0000000F8A98: D5010010 00122080
	.long 0xd41e0004                                           // 0000000F8AA0: D41E0004
	v_cndmask_b32_e32 v1, 0x42b17218, v14, vcc_lo              // 0000000F8AA4: 02021CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F8AAC: BF8700A1
	v_cndmask_b32_e64 v14, 0x7f800000, v15, s4                 // 0000000F8AB0: D501000E 00121EFF 7F800000
	.long 0xd41e0004                                           // 0000000F8ABC: D41E0004
	v_cndmask_b32_e32 v1, 0x42b17218, v13, vcc_lo              // 0000000F8AC0: 02021AFF 42B17218
	v_cndmask_b32_e64 v13, 0x7f800000, v16, s4                 // 0000000F8AC8: D501000D 001220FF 7F800000
	ds_store_b32 v48, v14                                      // 0000000F8AD4: D8340000 00000E30
	ds_store_b32 v49, v13                                      // 0000000F8ADC: D8340000 00000D31
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000F8AE4: 8C7E057E
	v_mov_b32_e32 v13, v0                                      // 0000000F8AE8: 7E1A0300
	s_mov_b32 s5, 0                                            // 0000000F8AEC: BE850080
	s_waitcnt lgkmcnt(0)                                       // 0000000F8AF0: BF89FC07
	s_barrier                                                  // 0000000F8AF4: BFBD0000
	buffer_gl0_inv                                             // 0000000F8AF8: E0AC0000 00000000
	v_lshrrev_b32_e32 v16, 7, v13                              // 0000000F8B00: 32201A87
	v_add_nc_u32_e32 v18, 0x80, v13                            // 0000000F8B04: 4A241AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8B0C: BF870092
	v_or_b32_e32 v14, s9, v16                                  // 0000000F8B10: 381C2009
	v_mad_u64_u32 v[14:15], null, v14, 48, s[2:3]              // 0000000F8B14: D6FE7C0E 0009610E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8B1C: BF870091
	.long 0xd73c000e                                           // 0000000F8B20: D73C000E
	v_cndmask_b32_e32 v1, 9, v14, vcc_lo                       // 0000000F8B24: 02021C89
	.long 0xd700040e                                           // 0000000F8B28: D700040E
	v_cndmask_b32_e32 v1, v51, v14, vcc_lo                     // 0000000F8B2C: 02021D33
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F8B30: BF870001
	v_add_co_ci_u32_e64 v15, null, v52, v15, s4                // 0000000F8B34: D5207C0F 00121F34
	.long 0xd4490004                                           // 0000000F8B3C: D4490004
	v_cndmask_b32_e32 v1, 0xf7f, v13, vcc_lo                   // 0000000F8B40: 02021AFF 00000F7F
	v_mov_b32_e32 v13, v18                                     // 0000000F8B48: 7E1A0312
	global_load_b32 v17, v[14:15], off                         // 0000000F8B4C: DC520000 117C000E
	v_mad_u64_u32 v[14:15], null, 0x204, v16, v[1:2]           // 0000000F8B54: D6FE7C0E 040620FF 00000204
	s_or_b32 s5, s4, s5                                        // 0000000F8B60: 8C050504
	s_waitcnt vmcnt(0)                                         // 0000000F8B64: BF8903F7
	ds_store_b32 v14, v17                                      // 0000000F8B68: D8340000 0000110E
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000000F8B70: 917E057E
	s_cbranch_execnz 65506                                     // 0000000F8B74: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x500>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000F8B78: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 0000000F8B7C: BF89FC07
	s_barrier                                                  // 0000000F8B80: BFBD0000
	buffer_gl0_inv                                             // 0000000F8B84: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 0000000F8B8C: BE852001
	s_cbranch_execz 102                                        // 0000000F8B90: BFA50066 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x72c>
	v_or_b32_e32 v13, s9, v46                                  // 0000000F8B94: 381A5C09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8B98: BF870091
	v_mad_u64_u32 v[13:14], null, v13, 48, s[2:3]              // 0000000F8B9C: D6FE7C0D 0009610D
	.long 0xd73c000d                                           // 0000000F8BA4: D73C000D
	v_cndmask_b32_e32 v1, 9, v13, vcc_lo                       // 0000000F8BA8: 02021A89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8BAC: BF870091
	.long 0xd700040d                                           // 0000000F8BB0: D700040D
	v_cndmask_b32_e32 v1, v53, v13, vcc_lo                     // 0000000F8BB4: 02021B35
	v_add_co_ci_u32_e64 v14, null, v54, v14, s4                // 0000000F8BB8: D5207C0E 00121D36
	s_movk_i32 s4, 0xf600                                      // 0000000F8BC0: B004F600
	global_load_b32 v14, v[13:14], off                         // 0000000F8BC4: DC520000 0E7C000D
	v_mov_b32_e32 v13, v56                                     // 0000000F8BCC: 7E1A0338
	v_add_nc_u32_e32 v15, s4, v50                              // 0000000F8BD0: 4A1E6404
	s_addk_i32 s4, 0x140                                       // 0000000F8BD4: B7840140
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8BD8: BF870099
	s_cmp_eq_u32 s4, 0                                         // 0000000F8BDC: BF068004
	v_add_nc_u32_e32 v29, 0x4800, v15                          // 0000000F8BE0: 4A3A1EFF 00004800
	ds_load_2addr_b32 v[15:16], v13 offset1:1                  // 0000000F8BE8: D8DC0100 0F00000D
	ds_load_2addr_b32 v[17:18], v29 offset0:160 offset1:165    // 0000000F8BF0: D8DCA5A0 1100001D
	ds_load_2addr_b32 v[19:20], v13 offset0:2 offset1:3        // 0000000F8BF8: D8DC0302 1300000D
	ds_load_2addr_b32 v[21:22], v29 offset0:170 offset1:175    // 0000000F8C00: D8DCAFAA 1500001D
	ds_load_2addr_b32 v[23:24], v13 offset0:4 offset1:5        // 0000000F8C08: D8DC0504 1700000D
	ds_load_2addr_b32 v[25:26], v13 offset0:6 offset1:7        // 0000000F8C10: D8DC0706 1900000D
	ds_load_2addr_b32 v[27:28], v29 offset0:180 offset1:185    // 0000000F8C18: D8DCB9B4 1B00001D
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000F8C20: BF890057
	v_fma_f32 v14, -v15, v17, v14                              // 0000000F8C24: D613000E 243A230F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F8C2C: BF8700C1
	v_fma_f32 v16, -v16, v18, v14                              // 0000000F8C30: D6130010 243A2510
	ds_load_2addr_b32 v[14:15], v29 offset0:190 offset1:195    // 0000000F8C38: D8DCC3BE 0E00001D
	s_waitcnt lgkmcnt(4)                                       // 0000000F8C40: BF89FC47
	v_fma_f32 v16, -v19, v21, v16                              // 0000000F8C44: D6130010 24422B13
	v_fma_f32 v20, -v20, v22, v16                              // 0000000F8C4C: D6130014 24422D14
	ds_load_2addr_b32 v[16:17], v13 offset0:8 offset1:9        // 0000000F8C54: D8DC0908 1000000D
	ds_load_2addr_b32 v[18:19], v29 offset0:200 offset1:205    // 0000000F8C5C: D8DCCDC8 1200001D
	s_waitcnt lgkmcnt(3)                                       // 0000000F8C64: BF89FC37
	v_fma_f32 v20, -v23, v27, v20                              // 0000000F8C68: D6130014 24523717
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F8C70: BF8700D1
	v_fma_f32 v24, -v24, v28, v20                              // 0000000F8C74: D6130018 24523918
	ds_load_2addr_b32 v[20:21], v13 offset0:10 offset1:11      // 0000000F8C7C: D8DC0B0A 1400000D
	ds_load_2addr_b32 v[22:23], v29 offset0:210 offset1:215    // 0000000F8C84: D8DCD7D2 1600001D
	s_waitcnt lgkmcnt(4)                                       // 0000000F8C8C: BF89FC47
	v_fma_f32 v14, -v25, v14, v24                              // 0000000F8C90: D613000E 24621D19
	v_fma_f32 v28, -v26, v15, v14                              // 0000000F8C98: D613001C 243A1F1A
	ds_load_2addr_b32 v[14:15], v13 offset0:12 offset1:13      // 0000000F8CA0: D8DC0D0C 0E00000D
	ds_load_2addr_b32 v[24:25], v13 offset0:14 offset1:15      // 0000000F8CA8: D8DC0F0E 1800000D
	ds_load_2addr_b32 v[26:27], v29 offset0:220 offset1:225    // 0000000F8CB0: D8DCE1DC 1A00001D
	v_add_nc_u32_e32 v13, 64, v13                              // 0000000F8CB8: 4A1A1AC0
	s_waitcnt lgkmcnt(5)                                       // 0000000F8CBC: BF89FC57
	v_fma_f32 v16, -v16, v18, v28                              // 0000000F8CC0: D6130010 24722510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F8CC8: BF8700C1
	v_fma_f32 v18, -v17, v19, v16                              // 0000000F8CCC: D6130012 24422711
	ds_load_2addr_b32 v[16:17], v29 offset0:230 offset1:235    // 0000000F8CD4: D8DCEBE6 1000001D
	s_waitcnt lgkmcnt(4)                                       // 0000000F8CDC: BF89FC47
	v_fma_f32 v18, -v20, v22, v18                              // 0000000F8CE0: D6130012 244A2D14
	v_fma_f32 v18, -v21, v23, v18                              // 0000000F8CE8: D6130012 244A2F15
	s_waitcnt lgkmcnt(1)                                       // 0000000F8CF0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8CF4: BF870091
	v_fma_f32 v14, -v14, v26, v18                              // 0000000F8CF8: D613000E 244A350E
	v_fma_f32 v14, -v15, v27, v14                              // 0000000F8D00: D613000E 243A370F
	s_waitcnt lgkmcnt(0)                                       // 0000000F8D08: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8D0C: BF870091
	v_fma_f32 v14, -v24, v16, v14                              // 0000000F8D10: D613000E 243A2118
	v_fma_f32 v14, -v25, v17, v14                              // 0000000F8D18: D613000E 243A2319
	s_cbranch_scc0 65451                                       // 0000000F8D20: BFA1FFAB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5d0>
	ds_store_b32 v57, v14                                      // 0000000F8D24: D8340000 00000E39
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000F8D2C: 8C7E057E
	v_mov_b32_e32 v13, v0                                      // 0000000F8D30: 7E1A0300
	s_or_b32 s11, s9, 32                                       // 0000000F8D34: 8C0BA009
	s_mov_b32 s5, 0                                            // 0000000F8D38: BE850080
	s_waitcnt lgkmcnt(0)                                       // 0000000F8D3C: BF89FC07
	s_barrier                                                  // 0000000F8D40: BFBD0000
	buffer_gl0_inv                                             // 0000000F8D44: E0AC0000 00000000
	s_nop 0                                                    // 0000000F8D4C: BF800000
	s_nop 0                                                    // 0000000F8D50: BF800000
	s_nop 0                                                    // 0000000F8D54: BF800000
	s_nop 0                                                    // 0000000F8D58: BF800000
	s_nop 0                                                    // 0000000F8D5C: BF800000
	s_nop 0                                                    // 0000000F8D60: BF800000
	s_nop 0                                                    // 0000000F8D64: BF800000
	s_nop 0                                                    // 0000000F8D68: BF800000
	s_nop 0                                                    // 0000000F8D6C: BF800000
	s_nop 0                                                    // 0000000F8D70: BF800000
	s_nop 0                                                    // 0000000F8D74: BF800000
	s_nop 0                                                    // 0000000F8D78: BF800000
	s_nop 0                                                    // 0000000F8D7C: BF800000
	v_lshrrev_b32_e32 v16, 7, v13                              // 0000000F8D80: 32201A87
	v_add_nc_u32_e32 v18, 0x80, v13                            // 0000000F8D84: 4A241AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8D8C: BF870092
	v_or_b32_e32 v14, s11, v16                                 // 0000000F8D90: 381C200B
	v_mad_u64_u32 v[14:15], null, v14, 48, s[2:3]              // 0000000F8D94: D6FE7C0E 0009610E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8D9C: BF870091
	.long 0xd73c000e                                           // 0000000F8DA0: D73C000E
	v_cndmask_b32_e32 v1, 9, v14, vcc_lo                       // 0000000F8DA4: 02021C89
	.long 0xd700040e                                           // 0000000F8DA8: D700040E
	v_cndmask_b32_e32 v1, v51, v14, vcc_lo                     // 0000000F8DAC: 02021D33
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F8DB0: BF870001
	v_add_co_ci_u32_e64 v15, null, v52, v15, s4                // 0000000F8DB4: D5207C0F 00121F34
	.long 0xd4490004                                           // 0000000F8DBC: D4490004
	v_cndmask_b32_e32 v1, 0xf7f, v13, vcc_lo                   // 0000000F8DC0: 02021AFF 00000F7F
	v_mov_b32_e32 v13, v18                                     // 0000000F8DC8: 7E1A0312
	global_load_b32 v17, v[14:15], off                         // 0000000F8DCC: DC520000 117C000E
	v_mad_u64_u32 v[14:15], null, 0x204, v16, v[1:2]           // 0000000F8DD4: D6FE7C0E 040620FF 00000204
	s_or_b32 s5, s4, s5                                        // 0000000F8DE0: 8C050504
	s_waitcnt vmcnt(0)                                         // 0000000F8DE4: BF8903F7
	ds_store_b32 v14, v17                                      // 0000000F8DE8: D8340000 0000110E
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000000F8DF0: 917E057E
	s_cbranch_execnz 65506                                     // 0000000F8DF4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x780>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000F8DF8: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 0000000F8DFC: BF89FC07
	s_barrier                                                  // 0000000F8E00: BFBD0000
	buffer_gl0_inv                                             // 0000000F8E04: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 0000000F8E0C: BE852001
	s_cbranch_execz 102                                        // 0000000F8E10: BFA50066 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x9ac>
	v_or_b32_e32 v13, s11, v46                                 // 0000000F8E14: 381A5C0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8E18: BF870091
	v_mad_u64_u32 v[13:14], null, v13, 48, s[2:3]              // 0000000F8E1C: D6FE7C0D 0009610D
	.long 0xd73c000d                                           // 0000000F8E24: D73C000D
	v_cndmask_b32_e32 v1, 9, v13, vcc_lo                       // 0000000F8E28: 02021A89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8E2C: BF870091
	.long 0xd700040d                                           // 0000000F8E30: D700040D
	v_cndmask_b32_e32 v1, v53, v13, vcc_lo                     // 0000000F8E34: 02021B35
	v_add_co_ci_u32_e64 v14, null, v54, v14, s4                // 0000000F8E38: D5207C0E 00121D36
	s_movk_i32 s4, 0xf600                                      // 0000000F8E40: B004F600
	global_load_b32 v14, v[13:14], off                         // 0000000F8E44: DC520000 0E7C000D
	v_mov_b32_e32 v13, v56                                     // 0000000F8E4C: 7E1A0338
	v_add_nc_u32_e32 v15, s4, v50                              // 0000000F8E50: 4A1E6404
	s_addk_i32 s4, 0x140                                       // 0000000F8E54: B7840140
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8E58: BF870099
	s_cmp_lg_u32 s4, 0                                         // 0000000F8E5C: BF078004
	v_add_nc_u32_e32 v29, 0x4800, v15                          // 0000000F8E60: 4A3A1EFF 00004800
	ds_load_2addr_b32 v[15:16], v13 offset1:1                  // 0000000F8E68: D8DC0100 0F00000D
	ds_load_2addr_b32 v[17:18], v29 offset0:160 offset1:165    // 0000000F8E70: D8DCA5A0 1100001D
	ds_load_2addr_b32 v[19:20], v13 offset0:2 offset1:3        // 0000000F8E78: D8DC0302 1300000D
	ds_load_2addr_b32 v[21:22], v29 offset0:170 offset1:175    // 0000000F8E80: D8DCAFAA 1500001D
	ds_load_2addr_b32 v[23:24], v13 offset0:4 offset1:5        // 0000000F8E88: D8DC0504 1700000D
	ds_load_2addr_b32 v[25:26], v13 offset0:6 offset1:7        // 0000000F8E90: D8DC0706 1900000D
	ds_load_2addr_b32 v[27:28], v29 offset0:180 offset1:185    // 0000000F8E98: D8DCB9B4 1B00001D
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000F8EA0: BF890057
	v_fma_f32 v14, -v15, v17, v14                              // 0000000F8EA4: D613000E 243A230F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F8EAC: BF8700C1
	v_fma_f32 v16, -v16, v18, v14                              // 0000000F8EB0: D6130010 243A2510
	ds_load_2addr_b32 v[14:15], v29 offset0:190 offset1:195    // 0000000F8EB8: D8DCC3BE 0E00001D
	s_waitcnt lgkmcnt(4)                                       // 0000000F8EC0: BF89FC47
	v_fma_f32 v16, -v19, v21, v16                              // 0000000F8EC4: D6130010 24422B13
	v_fma_f32 v20, -v20, v22, v16                              // 0000000F8ECC: D6130014 24422D14
	ds_load_2addr_b32 v[16:17], v13 offset0:8 offset1:9        // 0000000F8ED4: D8DC0908 1000000D
	ds_load_2addr_b32 v[18:19], v29 offset0:200 offset1:205    // 0000000F8EDC: D8DCCDC8 1200001D
	s_waitcnt lgkmcnt(3)                                       // 0000000F8EE4: BF89FC37
	v_fma_f32 v20, -v23, v27, v20                              // 0000000F8EE8: D6130014 24523717
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F8EF0: BF8700D1
	v_fma_f32 v24, -v24, v28, v20                              // 0000000F8EF4: D6130018 24523918
	ds_load_2addr_b32 v[20:21], v13 offset0:10 offset1:11      // 0000000F8EFC: D8DC0B0A 1400000D
	ds_load_2addr_b32 v[22:23], v29 offset0:210 offset1:215    // 0000000F8F04: D8DCD7D2 1600001D
	s_waitcnt lgkmcnt(4)                                       // 0000000F8F0C: BF89FC47
	v_fma_f32 v14, -v25, v14, v24                              // 0000000F8F10: D613000E 24621D19
	v_fma_f32 v28, -v26, v15, v14                              // 0000000F8F18: D613001C 243A1F1A
	ds_load_2addr_b32 v[14:15], v13 offset0:12 offset1:13      // 0000000F8F20: D8DC0D0C 0E00000D
	ds_load_2addr_b32 v[24:25], v13 offset0:14 offset1:15      // 0000000F8F28: D8DC0F0E 1800000D
	ds_load_2addr_b32 v[26:27], v29 offset0:220 offset1:225    // 0000000F8F30: D8DCE1DC 1A00001D
	v_add_nc_u32_e32 v13, 64, v13                              // 0000000F8F38: 4A1A1AC0
	s_waitcnt lgkmcnt(5)                                       // 0000000F8F3C: BF89FC57
	v_fma_f32 v16, -v16, v18, v28                              // 0000000F8F40: D6130010 24722510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F8F48: BF8700C1
	v_fma_f32 v18, -v17, v19, v16                              // 0000000F8F4C: D6130012 24422711
	ds_load_2addr_b32 v[16:17], v29 offset0:230 offset1:235    // 0000000F8F54: D8DCEBE6 1000001D
	s_waitcnt lgkmcnt(4)                                       // 0000000F8F5C: BF89FC47
	v_fma_f32 v18, -v20, v22, v18                              // 0000000F8F60: D6130012 244A2D14
	v_fma_f32 v18, -v21, v23, v18                              // 0000000F8F68: D6130012 244A2F15
	s_waitcnt lgkmcnt(1)                                       // 0000000F8F70: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8F74: BF870091
	v_fma_f32 v14, -v14, v26, v18                              // 0000000F8F78: D613000E 244A350E
	v_fma_f32 v14, -v15, v27, v14                              // 0000000F8F80: D613000E 243A370F
	s_waitcnt lgkmcnt(0)                                       // 0000000F8F88: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F8F8C: BF870091
	v_fma_f32 v14, -v24, v16, v14                              // 0000000F8F90: D613000E 243A2118
	v_fma_f32 v14, -v25, v17, v14                              // 0000000F8F98: D613000E 243A2319
	s_cbranch_scc1 65451                                       // 0000000F8FA0: BFA2FFAB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x850>
	ds_store_b32 v57, v14 offset:640                           // 0000000F8FA4: D8340280 00000E39
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000F8FAC: 8C7E057E
	v_mov_b32_e32 v13, v0                                      // 0000000F8FB0: 7E1A0300
	s_mov_b32 s5, 0                                            // 0000000F8FB4: BE850080
	s_waitcnt lgkmcnt(0)                                       // 0000000F8FB8: BF89FC07
	s_barrier                                                  // 0000000F8FBC: BFBD0000
	buffer_gl0_inv                                             // 0000000F8FC0: E0AC0000 00000000
	s_nop 0                                                    // 0000000F8FC8: BF800000
	s_nop 0                                                    // 0000000F8FCC: BF800000
	s_nop 0                                                    // 0000000F8FD0: BF800000
	s_nop 0                                                    // 0000000F8FD4: BF800000
	s_nop 0                                                    // 0000000F8FD8: BF800000
	s_nop 0                                                    // 0000000F8FDC: BF800000
	s_nop 0                                                    // 0000000F8FE0: BF800000
	s_nop 0                                                    // 0000000F8FE4: BF800000
	s_nop 0                                                    // 0000000F8FE8: BF800000
	s_nop 0                                                    // 0000000F8FEC: BF800000
	s_nop 0                                                    // 0000000F8FF0: BF800000
	s_nop 0                                                    // 0000000F8FF4: BF800000
	s_nop 0                                                    // 0000000F8FF8: BF800000
	s_nop 0                                                    // 0000000F8FFC: BF800000
	v_lshrrev_b32_e32 v16, 7, v13                              // 0000000F9000: 32201A87
	v_add_nc_u32_e32 v18, 0x80, v13                            // 0000000F9004: 4A241AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F900C: BF870092
	v_or_b32_e32 v14, s9, v16                                  // 0000000F9010: 381C2009
	v_mad_u64_u32 v[14:15], null, v14, 48, s[2:3]              // 0000000F9014: D6FE7C0E 0009610E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F901C: BF870091
	.long 0xd73c000e                                           // 0000000F9020: D73C000E
	v_cndmask_b32_e32 v1, 9, v14, vcc_lo                       // 0000000F9024: 02021C89
	.long 0xd700040e                                           // 0000000F9028: D700040E
	v_cndmask_b32_e32 v1, v60, v14, vcc_lo                     // 0000000F902C: 02021D3C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F9030: BF870001
	v_add_co_ci_u32_e64 v15, null, v61, v15, s4                // 0000000F9034: D5207C0F 00121F3D
	.long 0xd4490004                                           // 0000000F903C: D4490004
	v_cndmask_b32_e32 v1, 0xf7f, v13, vcc_lo                   // 0000000F9040: 02021AFF 00000F7F
	v_mov_b32_e32 v13, v18                                     // 0000000F9048: 7E1A0312
	global_load_b32 v17, v[14:15], off                         // 0000000F904C: DC520000 117C000E
	v_mad_u64_u32 v[14:15], null, 0x204, v16, v[1:2]           // 0000000F9054: D6FE7C0E 040620FF 00000204
	s_or_b32 s5, s4, s5                                        // 0000000F9060: 8C050504
	s_waitcnt vmcnt(0)                                         // 0000000F9064: BF8903F7
	ds_store_b32 v14, v17                                      // 0000000F9068: D8340000 0000110E
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000000F9070: 917E057E
	s_cbranch_execnz 65506                                     // 0000000F9074: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa00>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000F9078: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 0000000F907C: BF89FC07
	s_barrier                                                  // 0000000F9080: BFBD0000
	buffer_gl0_inv                                             // 0000000F9084: E0AC0000 00000000
	s_and_saveexec_b32 s14, s1                                 // 0000000F908C: BE8E2001
	s_cbranch_execz 118                                        // 0000000F9090: BFA50076 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc6c>
	v_or_b32_e32 v15, s9, v46                                  // 0000000F9094: 381E5C09
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F9098: BF870001
	.long 0xd4440004                                           // 0000000F909C: D4440004
	v_cndmask_b32_e32 v1, s24, v15, vcc_lo                     // 0000000F90A0: 02021E18
	s_and_b32 exec_lo, exec_lo, s4                             // 0000000F90A4: 8B7E047E
	s_cbranch_execz 112                                        // 0000000F90A8: BFA50070 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc6c>
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v13, v56           // 0000000F90AC: CA100080 100C0138
	s_movk_i32 s4, 0xf600                                      // 0000000F90B4: B004F600
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000F90B8: BF8704A9
	v_add_nc_u32_e32 v14, s4, v50                              // 0000000F90BC: 4A1C6404
	s_addk_i32 s4, 0x140                                       // 0000000F90C0: B7840140
	s_cmp_eq_u32 s4, 0                                         // 0000000F90C4: BF068004
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F90C8: BF870001
	v_add_nc_u32_e32 v14, 0x4800, v14                          // 0000000F90CC: 4A1C1CFF 00004800
	ds_load_2addr_b32 v[17:18], v13 offset1:1                  // 0000000F90D4: D8DC0100 1100000D
	ds_load_2addr_b32 v[19:20], v14 offset0:160 offset1:165    // 0000000F90DC: D8DCA5A0 1300000E
	ds_load_2addr_b32 v[21:22], v13 offset0:2 offset1:3        // 0000000F90E4: D8DC0302 1500000D
	ds_load_2addr_b32 v[23:24], v14 offset0:170 offset1:175    // 0000000F90EC: D8DCAFAA 1700000E
	ds_load_2addr_b32 v[25:26], v13 offset0:4 offset1:5        // 0000000F90F4: D8DC0504 1900000D
	ds_load_2addr_b32 v[27:28], v13 offset0:6 offset1:7        // 0000000F90FC: D8DC0706 1B00000D
	ds_load_2addr_b32 v[29:30], v14 offset0:180 offset1:185    // 0000000F9104: D8DCB9B4 1D00000E
	s_waitcnt lgkmcnt(5)                                       // 0000000F910C: BF89FC57
	v_fmac_f32_e32 v16, v17, v19                               // 0000000F9110: 56202711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F9114: BF8700C1
	v_fmac_f32_e32 v16, v18, v20                               // 0000000F9118: 56202912
	ds_load_2addr_b32 v[17:18], v14 offset0:190 offset1:195    // 0000000F911C: D8DCC3BE 1100000E
	s_waitcnt lgkmcnt(4)                                       // 0000000F9124: BF89FC47
	v_fmac_f32_e32 v16, v21, v23                               // 0000000F9128: 56202F15
	v_fmac_f32_e32 v16, v22, v24                               // 0000000F912C: 56203116
	ds_load_2addr_b32 v[19:20], v13 offset0:8 offset1:9        // 0000000F9130: D8DC0908 1300000D
	ds_load_2addr_b32 v[21:22], v14 offset0:200 offset1:205    // 0000000F9138: D8DCCDC8 1500000E
	s_waitcnt lgkmcnt(3)                                       // 0000000F9140: BF89FC37
	v_fmac_f32_e32 v16, v25, v29                               // 0000000F9144: 56203B19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F9148: BF8700D1
	v_fmac_f32_e32 v16, v26, v30                               // 0000000F914C: 56203D1A
	ds_load_2addr_b32 v[23:24], v13 offset0:10 offset1:11      // 0000000F9150: D8DC0B0A 1700000D
	ds_load_2addr_b32 v[25:26], v14 offset0:210 offset1:215    // 0000000F9158: D8DCD7D2 1900000E
	s_waitcnt lgkmcnt(4)                                       // 0000000F9160: BF89FC47
	v_fmac_f32_e32 v16, v27, v17                               // 0000000F9164: 5620231B
	v_fmac_f32_e32 v16, v28, v18                               // 0000000F9168: 5620251C
	ds_load_2addr_b32 v[17:18], v13 offset0:12 offset1:13      // 0000000F916C: D8DC0D0C 1100000D
	ds_load_2addr_b32 v[27:28], v13 offset0:14 offset1:15      // 0000000F9174: D8DC0F0E 1B00000D
	ds_load_2addr_b32 v[29:30], v14 offset0:220 offset1:225    // 0000000F917C: D8DCE1DC 1D00000E
	v_add_nc_u32_e32 v13, 64, v13                              // 0000000F9184: 4A1A1AC0
	s_waitcnt lgkmcnt(5)                                       // 0000000F9188: BF89FC57
	v_fmac_f32_e32 v16, v19, v21                               // 0000000F918C: 56202B13
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F9190: BF8700C1
	v_fmac_f32_e32 v16, v20, v22                               // 0000000F9194: 56202D14
	ds_load_2addr_b32 v[19:20], v14 offset0:230 offset1:235    // 0000000F9198: D8DCEBE6 1300000E
	s_waitcnt lgkmcnt(4)                                       // 0000000F91A0: BF89FC47
	v_fmac_f32_e32 v16, v23, v25                               // 0000000F91A4: 56203317
	v_fmac_f32_e32 v16, v24, v26                               // 0000000F91A8: 56203518
	s_waitcnt lgkmcnt(1)                                       // 0000000F91AC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F91B0: BF870091
	v_fmac_f32_e32 v16, v17, v29                               // 0000000F91B4: 56203B11
	v_fmac_f32_e32 v16, v18, v30                               // 0000000F91B8: 56203D12
	s_waitcnt lgkmcnt(0)                                       // 0000000F91BC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F91C0: BF870091
	v_fmac_f32_e32 v16, v27, v19                               // 0000000F91C4: 5620271B
	v_fmac_f32_e32 v16, v28, v20                               // 0000000F91C8: 5620291C
	s_cbranch_scc0 65466                                       // 0000000F91CC: BFA1FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xab8>
	ds_load_b32 v18, v58                                       // 0000000F91D0: D8D80000 1200003A
	v_mov_b32_e32 v17, v50                                     // 0000000F91D8: 7E220332
	v_dual_mov_b32 v14, v6 :: v_dual_mov_b32 v13, v5           // 0000000F91DC: CA100106 0E0C0105
	s_mov_b32 s15, 0                                           // 0000000F91E4: BE8F0080
	s_waitcnt lgkmcnt(0)                                       // 0000000F91E8: BF89FC07
	v_mul_f32_e32 v16, v16, v18                                // 0000000F91EC: 10202510
	v_mov_b32_e32 v18, v64                                     // 0000000F91F0: 7E240340
	global_load_b32 v19, v[13:14], off                         // 0000000F91F4: DC520000 137C000D
	ds_load_b32 v20, v17 offset:19072                          // 0000000F91FC: D8D84A80 14000011
	v_add_nc_u32_e32 v18, -1, v18                              // 0000000F9204: 4A2424C1
	.long 0xd700040d                                           // 0000000F9208: D700040D
	v_cndmask_b32_e32 v0, v13, v132, vcc_lo                    // 0000000F920C: 0201090D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000F9210: BF870191
	v_add_co_ci_u32_e64 v14, null, 0, v14, s4                  // 0000000F9214: D5207C0E 00121C80
	.long 0xd44a0005                                           // 0000000F921C: D44A0005
	v_cndmask_b32_e32 v1, 0, v18, vcc_lo                       // 0000000F9220: 02022480
	v_add_nc_u32_e32 v17, 20, v17                              // 0000000F9224: 4A222294
	s_or_b32 s15, s5, s15                                      // 0000000F9228: 8C0F0F05
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F922C: BF890007
	v_fmac_f32_e32 v16, v19, v20                               // 0000000F9230: 56202913
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000000F9234: 917E0F7E
	s_cbranch_execnz 65518                                     // 0000000F9238: BFA6FFEE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xbf4>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000000F923C: 8C7E0F7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F9240: BF870121
	v_bfe_u32 v17, v16, 16, 1                                  // 0000000F9244: D6100011 02052110
	v_mad_u64_u32 v[13:14], null, 0x3000, v15, v[3:4]          // 0000000F924C: D6FE7C0D 040E1EFF 00003000
	v_add3_u32 v15, v16, v17, 0x7fff                           // 0000000F9258: D655000F 03FE2310 00007FFF
	global_store_d16_hi_b16 v[13:14], v15, off                 // 0000000F9264: DC960000 007C0F0D
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000F926C: 8C7E0E7E
	v_mov_b32_e32 v13, v0                                      // 0000000F9270: 7E1A0300
	s_mov_b32 s5, 0                                            // 0000000F9274: BE850080
	s_waitcnt_vscnt null, 0x0                                  // 0000000F9278: BC7C0000
	s_barrier                                                  // 0000000F927C: BFBD0000
	buffer_gl0_inv                                             // 0000000F9280: E0AC0000 00000000
	s_nop 0                                                    // 0000000F9288: BF800000
	s_nop 0                                                    // 0000000F928C: BF800000
	s_nop 0                                                    // 0000000F9290: BF800000
	s_nop 0                                                    // 0000000F9294: BF800000
	s_nop 0                                                    // 0000000F9298: BF800000
	s_nop 0                                                    // 0000000F929C: BF800000
	s_nop 0                                                    // 0000000F92A0: BF800000
	s_nop 0                                                    // 0000000F92A4: BF800000
	s_nop 0                                                    // 0000000F92A8: BF800000
	s_nop 0                                                    // 0000000F92AC: BF800000
	s_nop 0                                                    // 0000000F92B0: BF800000
	s_nop 0                                                    // 0000000F92B4: BF800000
	s_nop 0                                                    // 0000000F92B8: BF800000
	s_nop 0                                                    // 0000000F92BC: BF800000
	v_lshrrev_b32_e32 v16, 7, v13                              // 0000000F92C0: 32201A87
	v_add_nc_u32_e32 v18, 0x80, v13                            // 0000000F92C4: 4A241AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F92CC: BF870092
	v_or_b32_e32 v14, s11, v16                                 // 0000000F92D0: 381C200B
	v_mad_u64_u32 v[14:15], null, v14, 48, s[2:3]              // 0000000F92D4: D6FE7C0E 0009610E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F92DC: BF870091
	.long 0xd73c000e                                           // 0000000F92E0: D73C000E
	v_cndmask_b32_e32 v1, 9, v14, vcc_lo                       // 0000000F92E4: 02021C89
	.long 0xd700040e                                           // 0000000F92E8: D700040E
	v_cndmask_b32_e32 v1, v60, v14, vcc_lo                     // 0000000F92EC: 02021D3C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F92F0: BF870001
	v_add_co_ci_u32_e64 v15, null, v61, v15, s4                // 0000000F92F4: D5207C0F 00121F3D
	.long 0xd4490004                                           // 0000000F92FC: D4490004
	v_cndmask_b32_e32 v1, 0xf7f, v13, vcc_lo                   // 0000000F9300: 02021AFF 00000F7F
	v_mov_b32_e32 v13, v18                                     // 0000000F9308: 7E1A0312
	global_load_b32 v17, v[14:15], off                         // 0000000F930C: DC520000 117C000E
	v_mad_u64_u32 v[14:15], null, 0x204, v16, v[1:2]           // 0000000F9314: D6FE7C0E 040620FF 00000204
	s_or_b32 s5, s4, s5                                        // 0000000F9320: 8C050504
	s_waitcnt vmcnt(0)                                         // 0000000F9324: BF8903F7
	ds_store_b32 v14, v17                                      // 0000000F9328: D8340000 0000110E
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000000F9330: 917E057E
	s_cbranch_execnz 65506                                     // 0000000F9334: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xcc0>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000F9338: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 0000000F933C: BF89FC07
	s_barrier                                                  // 0000000F9340: BFBD0000
	buffer_gl0_inv                                             // 0000000F9344: E0AC0000 00000000
	s_and_saveexec_b32 s11, s1                                 // 0000000F934C: BE8B2001
	s_cbranch_execz 118                                        // 0000000F9350: BFA50076 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xf2c>
	v_or_b32_e32 v15, s9, v59                                  // 0000000F9354: 381E7609
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F9358: BF870001
	.long 0xd4440004                                           // 0000000F935C: D4440004
	v_cndmask_b32_e32 v1, s24, v15, vcc_lo                     // 0000000F9360: 02021E18
	s_and_b32 exec_lo, exec_lo, s4                             // 0000000F9364: 8B7E047E
	s_cbranch_execz 112                                        // 0000000F9368: BFA50070 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xf2c>
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v13, v56           // 0000000F936C: CA100080 100C0138
	s_movk_i32 s4, 0xf600                                      // 0000000F9374: B004F600
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000F9378: BF8704A9
	v_add_nc_u32_e32 v14, s4, v50                              // 0000000F937C: 4A1C6404
	s_addk_i32 s4, 0x140                                       // 0000000F9380: B7840140
	s_cmp_lg_u32 s4, 0                                         // 0000000F9384: BF078004
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F9388: BF870001
	v_add_nc_u32_e32 v14, 0x4800, v14                          // 0000000F938C: 4A1C1CFF 00004800
	ds_load_2addr_b32 v[17:18], v13 offset1:1                  // 0000000F9394: D8DC0100 1100000D
	ds_load_2addr_b32 v[19:20], v14 offset0:160 offset1:165    // 0000000F939C: D8DCA5A0 1300000E
	ds_load_2addr_b32 v[21:22], v13 offset0:2 offset1:3        // 0000000F93A4: D8DC0302 1500000D
	ds_load_2addr_b32 v[23:24], v14 offset0:170 offset1:175    // 0000000F93AC: D8DCAFAA 1700000E
	ds_load_2addr_b32 v[25:26], v13 offset0:4 offset1:5        // 0000000F93B4: D8DC0504 1900000D
	ds_load_2addr_b32 v[27:28], v13 offset0:6 offset1:7        // 0000000F93BC: D8DC0706 1B00000D
	ds_load_2addr_b32 v[29:30], v14 offset0:180 offset1:185    // 0000000F93C4: D8DCB9B4 1D00000E
	s_waitcnt lgkmcnt(5)                                       // 0000000F93CC: BF89FC57
	v_fmac_f32_e32 v16, v17, v19                               // 0000000F93D0: 56202711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F93D4: BF8700C1
	v_fmac_f32_e32 v16, v18, v20                               // 0000000F93D8: 56202912
	ds_load_2addr_b32 v[17:18], v14 offset0:190 offset1:195    // 0000000F93DC: D8DCC3BE 1100000E
	s_waitcnt lgkmcnt(4)                                       // 0000000F93E4: BF89FC47
	v_fmac_f32_e32 v16, v21, v23                               // 0000000F93E8: 56202F15
	v_fmac_f32_e32 v16, v22, v24                               // 0000000F93EC: 56203116
	ds_load_2addr_b32 v[19:20], v13 offset0:8 offset1:9        // 0000000F93F0: D8DC0908 1300000D
	ds_load_2addr_b32 v[21:22], v14 offset0:200 offset1:205    // 0000000F93F8: D8DCCDC8 1500000E
	s_waitcnt lgkmcnt(3)                                       // 0000000F9400: BF89FC37
	v_fmac_f32_e32 v16, v25, v29                               // 0000000F9404: 56203B19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F9408: BF8700D1
	v_fmac_f32_e32 v16, v26, v30                               // 0000000F940C: 56203D1A
	ds_load_2addr_b32 v[23:24], v13 offset0:10 offset1:11      // 0000000F9410: D8DC0B0A 1700000D
	ds_load_2addr_b32 v[25:26], v14 offset0:210 offset1:215    // 0000000F9418: D8DCD7D2 1900000E
	s_waitcnt lgkmcnt(4)                                       // 0000000F9420: BF89FC47
	v_fmac_f32_e32 v16, v27, v17                               // 0000000F9424: 5620231B
	v_fmac_f32_e32 v16, v28, v18                               // 0000000F9428: 5620251C
	ds_load_2addr_b32 v[17:18], v13 offset0:12 offset1:13      // 0000000F942C: D8DC0D0C 1100000D
	ds_load_2addr_b32 v[27:28], v13 offset0:14 offset1:15      // 0000000F9434: D8DC0F0E 1B00000D
	ds_load_2addr_b32 v[29:30], v14 offset0:220 offset1:225    // 0000000F943C: D8DCE1DC 1D00000E
	v_add_nc_u32_e32 v13, 64, v13                              // 0000000F9444: 4A1A1AC0
	s_waitcnt lgkmcnt(5)                                       // 0000000F9448: BF89FC57
	v_fmac_f32_e32 v16, v19, v21                               // 0000000F944C: 56202B13
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F9450: BF8700C1
	v_fmac_f32_e32 v16, v20, v22                               // 0000000F9454: 56202D14
	ds_load_2addr_b32 v[19:20], v14 offset0:230 offset1:235    // 0000000F9458: D8DCEBE6 1300000E
	s_waitcnt lgkmcnt(4)                                       // 0000000F9460: BF89FC47
	v_fmac_f32_e32 v16, v23, v25                               // 0000000F9464: 56203317
	v_fmac_f32_e32 v16, v24, v26                               // 0000000F9468: 56203518
	s_waitcnt lgkmcnt(1)                                       // 0000000F946C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9470: BF870091
	v_fmac_f32_e32 v16, v17, v29                               // 0000000F9474: 56203B11
	v_fmac_f32_e32 v16, v18, v30                               // 0000000F9478: 56203D12
	s_waitcnt lgkmcnt(0)                                       // 0000000F947C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9480: BF870091
	v_fmac_f32_e32 v16, v27, v19                               // 0000000F9484: 5620271B
	v_fmac_f32_e32 v16, v28, v20                               // 0000000F9488: 5620291C
	s_cbranch_scc1 65466                                       // 0000000F948C: BFA2FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd78>
	ds_load_b32 v18, v58 offset:128                            // 0000000F9490: D8D80080 1200003A
	v_dual_mov_b32 v14, v8 :: v_dual_mov_b32 v13, v7           // 0000000F9498: CA100108 0E0C0107
	v_mov_b32_e32 v17, v50                                     // 0000000F94A0: 7E220332
	s_mov_b32 s14, 0                                           // 0000000F94A4: BE8E0080
	s_waitcnt lgkmcnt(0)                                       // 0000000F94A8: BF89FC07
	v_mul_f32_e32 v16, v16, v18                                // 0000000F94AC: 10202510
	v_mov_b32_e32 v18, v65                                     // 0000000F94B0: 7E240341
	global_load_b32 v19, v[13:14], off                         // 0000000F94B4: DC520000 137C000D
	ds_load_b32 v20, v17 offset:19072                          // 0000000F94BC: D8D84A80 14000011
	v_add_nc_u32_e32 v18, -1, v18                              // 0000000F94C4: 4A2424C1
	.long 0xd700040d                                           // 0000000F94C8: D700040D
	v_cndmask_b32_e32 v0, v13, v132, vcc_lo                    // 0000000F94CC: 0201090D
	v_add_nc_u32_e32 v17, 20, v17                              // 0000000F94D0: 4A222294
	v_add_co_ci_u32_e64 v14, null, 0, v14, s4                  // 0000000F94D4: D5207C0E 00121C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000F94DC: BF870004
	.long 0xd44a0005                                           // 0000000F94E0: D44A0005
	v_cndmask_b32_e32 v1, 0, v18, vcc_lo                       // 0000000F94E4: 02022480
	s_or_b32 s14, s5, s14                                      // 0000000F94E8: 8C0E0E05
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F94EC: BF890007
	v_fmac_f32_e32 v16, v19, v20                               // 0000000F94F0: 56202913
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000F94F4: 917E0E7E
	s_cbranch_execnz 65518                                     // 0000000F94F8: BFA6FFEE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xeb4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000F94FC: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000F9500: BF870121
	v_bfe_u32 v17, v16, 16, 1                                  // 0000000F9504: D6100011 02052110
	v_mad_u64_u32 v[13:14], null, 0x3000, v15, v[3:4]          // 0000000F950C: D6FE7C0D 040E1EFF 00003000
	v_add3_u32 v15, v16, v17, 0x7fff                           // 0000000F9518: D655000F 03FE2310 00007FFF
	global_store_d16_hi_b16 v[13:14], v15, off                 // 0000000F9524: DC960000 007C0F0D
	s_or_b32 exec_lo, exec_lo, s11                             // 0000000F952C: 8C7E0B7E
	s_waitcnt_vscnt null, 0x0                                  // 0000000F9530: BC7C0000
	s_barrier                                                  // 0000000F9534: BFBD0000
	buffer_gl0_inv                                             // 0000000F9538: E0AC0000 00000000
	s_and_saveexec_b32 s5, vcc_lo                              // 0000000F9540: BE85206A
	s_cbranch_execz 65                                         // 0000000F9544: BFA50041 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x104c>
	s_mul_f32 s4, s10, 0x3fb8aa3b                              // 0000000F9548: A204FF0A 3FB8AA3B
	v_mov_b32_e32 v14, v0                                      // 0000000F9550: 7E1C0300
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000F9554: BF8704CA
	s_xor_b32 s11, s4, 0x80000000                              // 0000000F9558: 8D0BFF04 80000000
	s_rndne_f32 s14, s4                                        // 0000000F9560: BE8E6304
	s_fmamk_f32 s11, s10, 0x3fb8aa3b, s11                      // 0000000F9564: A30B0B0A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000F956C: BF4EFF0A C2CE8ED0
	s_sub_f32 s4, s4, s14                                      // 0000000F9574: A0840E04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000F9578: BF870599
	s_fmamk_f32 s11, s10, 0x32a5705f, s11                      // 0000000F957C: A30B0B0A 32A5705F
	s_add_f32 s4, s4, s11                                      // 0000000F9584: A0040B04
	s_delay_alu instid0(SALU_CYCLE_3)                          // 0000000F9588: BF87000B
	v_exp_f32_e32 v13, s4                                      // 0000000F958C: 7E1A4A04
	s_cvt_i32_f32 s4, s14                                      // 0000000F9590: BE84660E
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000F9594: BF870585
	.long 0xd71c000d                                           // 0000000F9598: D71C000D
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 0000000F959C: 0200090D
	s_cselect_b32 s4, -1, 0                                    // 0000000F95A0: 980480C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000F95A4: BF4BFF0A 42B17218
	s_mov_b32 s10, 0                                           // 0000000F95AC: BE8A0080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F95B0: BF870001
	v_cndmask_b32_e64 v13, 0, v13, s4                          // 0000000F95B4: D501000D 00121A80
	s_cselect_b32 s4, -1, 0                                    // 0000000F95BC: 980480C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000F95C0: BF870481
	v_cndmask_b32_e64 v13, 0x7f800000, v13, s4                 // 0000000F95C4: D501000D 00121AFF 7F800000
	s_nop 0                                                    // 0000000F95D0: BF800000
	s_nop 0                                                    // 0000000F95D4: BF800000
	s_nop 0                                                    // 0000000F95D8: BF800000
	s_nop 0                                                    // 0000000F95DC: BF800000
	s_nop 0                                                    // 0000000F95E0: BF800000
	s_nop 0                                                    // 0000000F95E4: BF800000
	s_nop 0                                                    // 0000000F95E8: BF800000
	s_nop 0                                                    // 0000000F95EC: BF800000
	s_nop 0                                                    // 0000000F95F0: BF800000
	s_nop 0                                                    // 0000000F95F4: BF800000
	s_nop 0                                                    // 0000000F95F8: BF800000
	s_nop 0                                                    // 0000000F95FC: BF800000
	v_lshrrev_b32_e32 v15, 2, v14                              // 0000000F9600: 321E1C82
	.long 0xd4490004                                           // 0000000F9604: D4490004
	v_cndmask_b32_e32 v1, 0x17f, v14, vcc_lo                   // 0000000F9608: 02021CFF 0000017F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F9610: BF8700D2
	v_mad_u64_u32 v[15:16], null, v15, 20, v[2:3]              // 0000000F9614: D6FE7C0F 0409290F
	s_or_b32 s10, s4, s10                                      // 0000000F961C: 8C0A0A04
	ds_load_b32 v16, v15                                       // 0000000F9620: D8D80000 1000000F
	s_waitcnt lgkmcnt(0)                                       // 0000000F9628: BF89FC07
	v_dual_mul_f32 v16, v13, v16 :: v_dual_add_nc_u32 v17, 0x80, v14// 0000000F962C: C8E0210D 10101CFF 00000080
	v_mov_b32_e32 v14, v17                                     // 0000000F9638: 7E1C0311
	ds_store_b32 v15, v16                                      // 0000000F963C: D8340000 0000100F
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000F9644: 917E0A7E
	s_cbranch_execnz 65517                                     // 0000000F9648: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1000>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000F964C: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 0000000F9650: BF89FC07
	s_barrier                                                  // 0000000F9654: BFBD0000
	buffer_gl0_inv                                             // 0000000F9658: E0AC0000 00000000
	s_and_saveexec_b32 s10, s7                                 // 0000000F9660: BE8A2007
	s_cbranch_execz 30                                         // 0000000F9664: BFA5001E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e0>
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v14, v10           // 0000000F9668: CA100080 0F0E010A
	v_dual_mov_b32 v13, v9 :: v_dual_mov_b32 v16, 0            // 0000000F9670: CA100109 0D100080
	v_mov_b32_e32 v17, v1                                      // 0000000F9678: 7E220301
	s_mov_b32 s11, 0                                           // 0000000F967C: BE8B0080
	global_load_b32 v18, v[13:14], off                         // 0000000F9680: DC520000 127C000D
	ds_load_b32 v19, v16 offset:20352                          // 0000000F9688: D8D84F80 13000010
	v_add_nc_u32_e32 v15, -1, v15                              // 0000000F9690: 4A1E1EC1
	.long 0xd700040d                                           // 0000000F9694: D700040D
	v_cndmask_b32_e32 v1, 0x6000, v13, vcc_lo                  // 0000000F9698: 02021AFF 00006000
	v_add_nc_u32_e32 v16, 4, v16                               // 0000000F96A0: 4A202084
	v_add_co_ci_u32_e64 v14, null, 0, v14, s4                  // 0000000F96A4: D5207C0E 00121C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000F96AC: BF870004
	.long 0xd44a0005                                           // 0000000F96B0: D44A0005
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 0000000F96B4: 02021E80
	s_or_b32 s11, s5, s11                                      // 0000000F96B8: 8C0B0B05
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F96BC: BF890007
	v_mul_f32_e32 v18, v18, v19                                // 0000000F96C0: 10242712
	ds_store_b32 v17, v18                                      // 0000000F96C4: D8340000 00001211
	v_add_nc_u32_e32 v17, 0x204, v17                           // 0000000F96CC: 4A2222FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000F96D4: 917E0B7E
	s_cbranch_execnz 65513                                     // 0000000F96D8: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1080>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000000F96DC: 8C7E0B7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F96E0: BF870009
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000F96E4: 8C7E0A7E
	v_mov_b32_e32 v13, v0                                      // 0000000F96E8: 7E1A0300
	s_mov_b32 s5, 0                                            // 0000000F96EC: BE850080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000F96F0: BF870241
	v_add_nc_u32_e32 v14, 0x80, v13                            // 0000000F96F4: 4A1C1AFF 00000080
	v_add_nc_u32_e32 v15, 0x100, v13                           // 0000000F96FC: 4A1E1AFF 00000100
	v_lshrrev_b32_e32 v22, 7, v13                              // 0000000F9704: 322C1A87
	v_add_nc_u32_e32 v16, 0x180, v13                           // 0000000F9708: 4A201AFF 00000180
	v_lshrrev_b32_e32 v23, 7, v14                              // 0000000F9710: 322E1C87
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000F9714: BF870214
	v_lshrrev_b32_e32 v24, 7, v15                              // 0000000F9718: 32301E87
	v_or_b32_e32 v14, s9, v22                                  // 0000000F971C: 381C2C09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000F9720: BF870214
	v_lshrrev_b32_e32 v25, 7, v16                              // 0000000F9724: 32322087
	v_or_b32_e32 v16, s9, v23                                  // 0000000F9728: 38202E09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000F972C: BF870214
	v_or_b32_e32 v18, s9, v24                                  // 0000000F9730: 38243009
	v_mad_u64_u32 v[14:15], null, v14, 48, s[2:3]              // 0000000F9734: D6FE7C0E 0009610E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000F973C: BF870214
	v_or_b32_e32 v20, s9, v25                                  // 0000000F9740: 38283209
	v_mad_u64_u32 v[16:17], null, v16, 48, s[2:3]              // 0000000F9744: D6FE7C10 00096110
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000F974C: BF870194
	v_mad_u64_u32 v[18:19], null, v18, 48, s[2:3]              // 0000000F9750: D6FE7C12 00096112
	v_mad_u64_u32 v[20:21], null, v20, 48, s[2:3]              // 0000000F9758: D6FE7C14 00096114
	.long 0xd73c000e                                           // 0000000F9760: D73C000E
	v_cndmask_b32_e32 v1, 9, v14, vcc_lo                       // 0000000F9764: 02021C89
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000F9768: BF870214
	.long 0xd73c0010                                           // 0000000F976C: D73C0010
	v_cndmask_b32_e32 v1, 9, v16, vcc_lo                       // 0000000F9770: 02022089
	.long 0xd73c0012                                           // 0000000F9774: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 0000000F9778: 02022489
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000F977C: BF870214
	.long 0xd73c0014                                           // 0000000F9780: D73C0014
	v_cndmask_b32_e32 v1, 9, v20, vcc_lo                       // 0000000F9784: 02022889
	.long 0xd700040e                                           // 0000000F9788: D700040E
	v_cndmask_b32_e32 v1, v62, v14, vcc_lo                     // 0000000F978C: 02021D3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F9790: BF8700A1
	v_add_co_ci_u32_e64 v15, null, v63, v15, s4                // 0000000F9794: D5207C0F 00121F3F
	.long 0xd7000410                                           // 0000000F979C: D7000410
	v_cndmask_b32_e32 v1, v62, v16, vcc_lo                     // 0000000F97A0: 0202213E
	v_add_co_ci_u32_e64 v17, null, v63, v17, s4                // 0000000F97A4: D5207C11 0012233F
	.long 0xd7000412                                           // 0000000F97AC: D7000412
	v_cndmask_b32_e32 v1, v62, v18, vcc_lo                     // 0000000F97B0: 0202253E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F97B4: BF8700A1
	v_add_co_ci_u32_e64 v19, null, v63, v19, s4                // 0000000F97B8: D5207C13 0012273F
	.long 0xd7000414                                           // 0000000F97C0: D7000414
	v_cndmask_b32_e32 v1, v62, v20, vcc_lo                     // 0000000F97C4: 0202293E
	v_add_co_ci_u32_e64 v21, null, v63, v21, s4                // 0000000F97C8: D5207C15 00122B3F
	s_clause 0x3                                               // 0000000F97D0: BF850003
	global_load_b32 v26, v[14:15], off                         // 0000000F97D4: DC520000 1A7C000E
	global_load_b32 v27, v[16:17], off                         // 0000000F97DC: DC520000 1B7C0010
	global_load_b32 v19, v[18:19], off                         // 0000000F97E4: DC520000 137C0012
	global_load_b32 v20, v[20:21], off                         // 0000000F97EC: DC520000 147C0014
	v_lshlrev_b32_e32 v14, 2, v22                              // 0000000F97F4: 301C2C82
	v_lshlrev_b32_e32 v15, 2, v23                              // 0000000F97F8: 301E2E82
	v_lshlrev_b32_e32 v16, 2, v24                              // 0000000F97FC: 30203082
	v_lshlrev_b32_e32 v17, 2, v25                              // 0000000F9800: 30223282
	ds_load_b32 v21, v14 offset:20352                          // 0000000F9804: D8D84F80 1500000E
	ds_load_b32 v28, v15 offset:20352                          // 0000000F980C: D8D84F80 1C00000F
	ds_load_b32 v29, v16 offset:20352                          // 0000000F9814: D8D84F80 1D000010
	ds_load_b32 v30, v17 offset:20352                          // 0000000F981C: D8D84F80 1E000011
	v_mad_u64_u32 v[14:15], null, 0x204, v22, v[1:2]           // 0000000F9824: D6FE7C0E 04062CFF 00000204
	v_mad_u64_u32 v[15:16], null, 0x204, v23, v[1:2]           // 0000000F9830: D6FE7C0F 04062EFF 00000204
	.long 0xd4490004                                           // 0000000F983C: D4490004
	v_cndmask_b32_e32 v1, 0xdff, v13, vcc_lo                   // 0000000F9840: 02021AFF 00000DFF
	v_mad_u64_u32 v[16:17], null, 0x204, v24, v[1:2]           // 0000000F9848: D6FE7C10 040630FF 00000204
	v_mad_u64_u32 v[17:18], null, 0x204, v25, v[1:2]           // 0000000F9854: D6FE7C11 040632FF 00000204
	v_add_nc_u32_e32 v13, 0x200, v13                           // 0000000F9860: 4A1A1AFF 00000200
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000F9868: BF870004
	s_or_b32 s5, s4, s5                                        // 0000000F986C: 8C050504
	s_waitcnt vmcnt(2) lgkmcnt(2)                              // 0000000F9870: BF890827
	v_dual_mul_f32 v18, v26, v21 :: v_dual_mul_f32 v21, v27, v28// 0000000F9874: C8C62B1A 1214391B
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F987C: BF890007
	v_dual_mul_f32 v19, v19, v29 :: v_dual_mul_f32 v20, v20, v30// 0000000F9880: C8C63B13 13143D14
	ds_store_b32 v14, v18                                      // 0000000F9888: D8340000 0000120E
	ds_store_b32 v15, v21                                      // 0000000F9890: D8340000 0000150F
	ds_store_b32 v16, v19                                      // 0000000F9898: D8340000 00001310
	ds_store_b32 v17, v20                                      // 0000000F98A0: D8340000 00001411
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000000F98A8: 917E057E
	s_cbranch_execnz 65424                                     // 0000000F98AC: BFA6FF90 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10f0>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000F98B0: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 0000000F98B4: BF89FC07
	s_barrier                                                  // 0000000F98B8: BFBD0000
	buffer_gl0_inv                                             // 0000000F98BC: E0AC0000 00000000
	s_and_saveexec_b32 s5, vcc_lo                              // 0000000F98C4: BE85206A
	s_cbranch_execz 171                                        // 0000000F98C8: BFA500AB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1578>
	ds_load_2addr_b32 v[13:14], v55 offset1:5                  // 0000000F98CC: D8DC0500 0D000037
	ds_load_2addr_b32 v[15:16], v55 offset0:10 offset1:15      // 0000000F98D4: D8DC0F0A 0F000037
	ds_load_2addr_b32 v[17:18], v55 offset0:20 offset1:25      // 0000000F98DC: D8DC1914 11000037
	ds_load_2addr_b32 v[19:20], v55 offset0:30 offset1:35      // 0000000F98E4: D8DC231E 13000037
	ds_load_2addr_b32 v[21:22], v55 offset0:40 offset1:45      // 0000000F98EC: D8DC2D28 15000037
	ds_load_2addr_b32 v[23:24], v55 offset0:50 offset1:55      // 0000000F98F4: D8DC3732 17000037
	ds_load_2addr_b32 v[25:26], v55 offset0:60 offset1:65      // 0000000F98FC: D8DC413C 19000037
	ds_load_2addr_b32 v[27:28], v55 offset0:70 offset1:75      // 0000000F9904: D8DC4B46 1B000037
	ds_load_2addr_b32 v[29:30], v55 offset0:80 offset1:85      // 0000000F990C: D8DC5550 1D000037
	ds_load_2addr_b32 v[31:32], v55 offset0:90 offset1:95      // 0000000F9914: D8DC5F5A 1F000037
	ds_load_2addr_b32 v[33:34], v55 offset0:100 offset1:105    // 0000000F991C: D8DC6964 21000037
	ds_load_2addr_b32 v[35:36], v55 offset0:110 offset1:115    // 0000000F9924: D8DC736E 23000037
	ds_load_2addr_b32 v[37:38], v55 offset0:120 offset1:125    // 0000000F992C: D8DC7D78 25000037
	ds_load_2addr_b32 v[39:40], v55 offset0:130 offset1:135    // 0000000F9934: D8DC8782 27000037
	ds_load_2addr_b32 v[41:42], v55 offset0:140 offset1:145    // 0000000F993C: D8DC918C 29000037
	ds_load_2addr_b32 v[43:44], v55 offset0:150 offset1:155    // 0000000F9944: D8DC9B96 2B000037
	v_mov_b32_e32 v67, v0                                      // 0000000F994C: 7E860300
	s_mov_b32 s9, 0                                            // 0000000F9950: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000F9954: BF8701B1
	v_lshrrev_b32_e32 v68, 2, v67                              // 0000000F9958: 32888682
	v_and_b32_e32 v75, -4, v67                                 // 0000000F995C: 369686C4
	.long 0xd4490004                                           // 0000000F9960: D4490004
	v_cndmask_b32_e32 v1, 0x17f, v67, vcc_lo                   // 0000000F9964: 020286FF 0000017F
	v_mad_u64_u32 v[68:69], null, v68, 20, v[2:3]              // 0000000F996C: D6FE7C44 04092944
	ds_load_2addr_b32 v[69:70], v75 offset1:129                // 0000000F9974: D8DC8100 4500004B
	ds_load_b32 v76, v68                                       // 0000000F997C: D8D80000 4C000044
	s_or_b32 s9, s4, s9                                        // 0000000F9984: 8C090904
	s_waitcnt lgkmcnt(0)                                       // 0000000F9988: BF89FC07
	v_dual_fmac_f32 v76, v69, v13 :: v_dual_add_nc_u32 v71, 0x400, v75// 0000000F998C: C8201B45 4C4696FF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F9998: BF8700C1
	v_fmac_f32_e32 v76, v70, v14                               // 0000000F999C: 56981D46
	ds_load_2addr_b32 v[71:72], v71 offset0:2 offset1:131      // 0000000F99A0: D8DC8302 47000047
	s_waitcnt lgkmcnt(0)                                       // 0000000F99A8: BF89FC07
	v_fmac_f32_e32 v76, v71, v15                               // 0000000F99AC: 56981F47
	v_dual_fmac_f32 v76, v72, v16 :: v_dual_add_nc_u32 v73, 0x800, v75// 0000000F99B0: C8202148 4C4896FF 00000800
	ds_load_2addr_b32 v[73:74], v73 offset0:4 offset1:133      // 0000000F99BC: D8DC8504 49000049
	s_waitcnt lgkmcnt(0)                                       // 0000000F99C4: BF89FC07
	v_dual_fmac_f32 v76, v73, v17 :: v_dual_add_nc_u32 v69, 0xc00, v75// 0000000F99C8: C8202349 4C4496FF 00000C00
	ds_load_2addr_b32 v[69:70], v69 offset0:6 offset1:135      // 0000000F99D4: D8DC8706 45000045
	v_dual_fmac_f32 v76, v74, v18 :: v_dual_add_nc_u32 v71, 0x1000, v75// 0000000F99DC: C820254A 4C4696FF 00001000
	ds_load_2addr_b32 v[71:72], v71 offset0:8 offset1:137      // 0000000F99E8: D8DC8908 47000047
	s_waitcnt lgkmcnt(1)                                       // 0000000F99F0: BF89FC17
	v_fmac_f32_e32 v76, v69, v19                               // 0000000F99F4: 56982745
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F99F8: BF870001
	v_dual_fmac_f32 v76, v70, v20 :: v_dual_add_nc_u32 v73, 0x1400, v75// 0000000F99FC: C8202946 4C4896FF 00001400
	ds_load_2addr_b32 v[73:74], v73 offset0:10 offset1:139     // 0000000F9A08: D8DC8B0A 49000049
	s_waitcnt lgkmcnt(1)                                       // 0000000F9A10: BF89FC17
	v_dual_fmac_f32 v76, v71, v21 :: v_dual_add_nc_u32 v69, 0x1800, v75// 0000000F9A14: C8202B47 4C4496FF 00001800
	v_add_nc_u32_e32 v71, 0x1c00, v75                          // 0000000F9A20: 4A8E96FF 00001C00
	ds_load_2addr_b32 v[69:70], v69 offset0:12 offset1:141     // 0000000F9A28: D8DC8D0C 45000045
	v_fmac_f32_e32 v76, v72, v22                               // 0000000F9A30: 56982D48
	ds_load_2addr_b32 v[71:72], v71 offset0:14 offset1:143     // 0000000F9A34: D8DC8F0E 47000047
	s_waitcnt lgkmcnt(2)                                       // 0000000F9A3C: BF89FC27
	v_fmac_f32_e32 v76, v73, v23                               // 0000000F9A40: 56982F49
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F9A44: BF8700C1
	v_dual_fmac_f32 v76, v74, v24 :: v_dual_add_nc_u32 v73, 0x2000, v75// 0000000F9A48: C820314A 4C4896FF 00002000
	ds_load_2addr_b32 v[73:74], v73 offset0:16 offset1:145     // 0000000F9A54: D8DC9110 49000049
	s_waitcnt lgkmcnt(2)                                       // 0000000F9A5C: BF89FC27
	v_dual_fmac_f32 v76, v69, v25 :: v_dual_add_nc_u32 v69, 0x2400, v75// 0000000F9A60: C8203345 4C4496FF 00002400
	v_fmac_f32_e32 v76, v70, v26                               // 0000000F9A6C: 56983546
	ds_load_2addr_b32 v[69:70], v69 offset0:18 offset1:147     // 0000000F9A70: D8DC9312 45000045
	s_waitcnt lgkmcnt(2)                                       // 0000000F9A78: BF89FC27
	v_fmac_f32_e32 v76, v71, v27                               // 0000000F9A7C: 56983747
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F9A80: BF8700C1
	v_dual_fmac_f32 v76, v72, v28 :: v_dual_add_nc_u32 v71, 0x2800, v75// 0000000F9A84: C8203948 4C4696FF 00002800
	ds_load_2addr_b32 v[71:72], v71 offset0:20 offset1:149     // 0000000F9A90: D8DC9514 47000047
	s_waitcnt lgkmcnt(2)                                       // 0000000F9A98: BF89FC27
	v_dual_fmac_f32 v76, v73, v29 :: v_dual_add_nc_u32 v73, 0x2c00, v75// 0000000F9A9C: C8203B49 4C4896FF 00002C00
	v_fmac_f32_e32 v76, v74, v30                               // 0000000F9AA8: 56983D4A
	ds_load_2addr_b32 v[73:74], v73 offset0:22 offset1:151     // 0000000F9AAC: D8DC9716 49000049
	s_waitcnt lgkmcnt(2)                                       // 0000000F9AB4: BF89FC27
	v_fmac_f32_e32 v76, v69, v31                               // 0000000F9AB8: 56983F45
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F9ABC: BF8700C1
	v_dual_fmac_f32 v76, v70, v32 :: v_dual_add_nc_u32 v69, 0x3000, v75// 0000000F9AC0: C8204146 4C4496FF 00003000
	ds_load_2addr_b32 v[69:70], v69 offset0:24 offset1:153     // 0000000F9ACC: D8DC9918 45000045
	s_waitcnt lgkmcnt(2)                                       // 0000000F9AD4: BF89FC27
	v_dual_fmac_f32 v76, v71, v33 :: v_dual_add_nc_u32 v71, 0x3400, v75// 0000000F9AD8: C8204347 4C4696FF 00003400
	v_fmac_f32_e32 v76, v72, v34                               // 0000000F9AE4: 56984548
	ds_load_2addr_b32 v[71:72], v71 offset0:26 offset1:155     // 0000000F9AE8: D8DC9B1A 47000047
	s_waitcnt lgkmcnt(2)                                       // 0000000F9AF0: BF89FC27
	v_fmac_f32_e32 v76, v73, v35                               // 0000000F9AF4: 56984749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F9AF8: BF8700C1
	v_dual_fmac_f32 v76, v74, v36 :: v_dual_add_nc_u32 v73, 0x3800, v75// 0000000F9AFC: C820494A 4C4896FF 00003800
	ds_load_2addr_b32 v[73:74], v73 offset0:28 offset1:157     // 0000000F9B08: D8DC9D1C 49000049
	s_waitcnt lgkmcnt(2)                                       // 0000000F9B10: BF89FC27
	v_dual_fmac_f32 v76, v69, v37 :: v_dual_add_nc_u32 v69, 0x3c00, v75// 0000000F9B14: C8204B45 4C4496FF 00003C00
	v_fmac_f32_e32 v76, v70, v38                               // 0000000F9B20: 56984D46
	ds_load_2addr_b32 v[69:70], v69 offset0:30 offset1:159     // 0000000F9B24: D8DC9F1E 45000045
	s_waitcnt lgkmcnt(2)                                       // 0000000F9B2C: BF89FC27
	v_fmac_f32_e32 v76, v71, v39                               // 0000000F9B30: 56984F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F9B34: BF8700A1
	v_fmac_f32_e32 v76, v72, v40                               // 0000000F9B38: 56985148
	s_waitcnt lgkmcnt(1)                                       // 0000000F9B3C: BF89FC17
	v_fmac_f32_e32 v76, v73, v41                               // 0000000F9B40: 56985349
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F9B44: BF8700A1
	v_fmac_f32_e32 v76, v74, v42                               // 0000000F9B48: 5698554A
	s_waitcnt lgkmcnt(0)                                       // 0000000F9B4C: BF89FC07
	v_fmac_f32_e32 v76, v69, v43                               // 0000000F9B50: 56985745
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9B54: BF870091
	v_dual_fmac_f32 v76, v70, v44 :: v_dual_add_nc_u32 v69, 0x80, v67// 0000000F9B58: C8205946 4C4486FF 00000080
	v_mov_b32_e32 v67, v69                                     // 0000000F9B64: 7E860345
	ds_store_b32 v68, v76                                      // 0000000F9B68: D8340000 00004C44
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000000F9B70: 917E097E
	s_cbranch_execnz 65399                                     // 0000000F9B74: BFA6FF77 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1354>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000F9B78: 8C7E057E
	v_dual_mov_b32 v14, v12 :: v_dual_mov_b32 v13, v11         // 0000000F9B7C: CA10010C 0E0C010B
	v_dual_mov_b32 v15, v1 :: v_dual_mov_b32 v16, 0            // 0000000F9B84: CA100101 0F100080
	v_mov_b32_e32 v17, v66                                     // 0000000F9B8C: 7E220342
	s_mov_b32 s9, 0                                            // 0000000F9B90: BE890080
	s_waitcnt lgkmcnt(0)                                       // 0000000F9B94: BF89FC07
	s_barrier                                                  // 0000000F9B98: BFBD0000
	buffer_gl0_inv                                             // 0000000F9B9C: E0AC0000 00000000
	s_nop 0                                                    // 0000000F9BA4: BF800000
	s_nop 0                                                    // 0000000F9BA8: BF800000
	s_nop 0                                                    // 0000000F9BAC: BF800000
	s_nop 0                                                    // 0000000F9BB0: BF800000
	s_nop 0                                                    // 0000000F9BB4: BF800000
	s_nop 0                                                    // 0000000F9BB8: BF800000
	s_nop 0                                                    // 0000000F9BBC: BF800000
	global_load_b32 v18, v[13:14], off                         // 0000000F9BC0: DC520000 127C000D
	ds_load_b32 v19, v16 offset:20480                          // 0000000F9BC8: D8D85000 13000010
	v_add_nc_u32_e32 v17, 0x80, v17                            // 0000000F9BD0: 4A2222FF 00000080
	.long 0xd700040d                                           // 0000000F9BD8: D700040D
	v_cndmask_b32_e32 v1, 0x6000, v13, vcc_lo                  // 0000000F9BDC: 02021AFF 00006000
	v_add_nc_u32_e32 v16, 4, v16                               // 0000000F9BE4: 4A202084
	v_add_co_ci_u32_e64 v14, null, 0, v14, s4                  // 0000000F9BE8: D5207C0E 00121C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000F9BF0: BF890007
	v_mul_f32_e32 v18, v18, v19                                // 0000000F9BF4: 10242712
	.long 0xd4490005                                           // 0000000F9BF8: D4490005
	v_cndmask_b32_e32 v1, 0xf7f, v17, vcc_lo                   // 0000000F9BFC: 020222FF 00000F7F
	ds_store_b32 v15, v18                                      // 0000000F9C04: D8340000 0000120F
	v_add_nc_u32_e32 v15, 0x204, v15                           // 0000000F9C0C: 4A1E1EFF 00000204
	s_or_b32 s9, s5, s9                                        // 0000000F9C14: 8C090905
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000F9C18: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000000F9C1C: 917E097E
	s_cbranch_execnz 65511                                     // 0000000F9C20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000F9C24: 8C7E097E
	s_waitcnt lgkmcnt(0)                                       // 0000000F9C28: BF89FC07
	s_barrier                                                  // 0000000F9C2C: BFBD0000
	buffer_gl0_inv                                             // 0000000F9C30: E0AC0000 00000000
	s_and_saveexec_b32 s5, vcc_lo                              // 0000000F9C38: BE85206A
	s_cbranch_execz 64304                                      // 0000000F9C3C: BFA5FB30 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x300>
	v_add_nc_u32_e32 v43, 0x400, v55                           // 0000000F9C40: 4A566EFF 00000400
	ds_load_2addr_b32 v[25:26], v55 offset0:220 offset1:225    // 0000000F9C48: D8DCE1DC 19000037
	ds_load_2addr_b32 v[27:28], v55 offset0:230 offset1:235    // 0000000F9C50: D8DCEBE6 1B000037
	ds_load_2addr_b32 v[29:30], v55 offset0:240 offset1:245    // 0000000F9C58: D8DCF5F0 1D000037
	ds_load_2addr_b32 v[31:32], v55 offset0:250 offset1:255    // 0000000F9C60: D8DCFFFA 1F000037
	ds_load_2addr_b32 v[33:34], v43 offset0:4 offset1:9        // 0000000F9C68: D8DC0904 2100002B
	ds_load_2addr_b32 v[35:36], v43 offset0:14 offset1:19      // 0000000F9C70: D8DC130E 2300002B
	ds_load_2addr_b32 v[37:38], v43 offset0:24 offset1:29      // 0000000F9C78: D8DC1D18 2500002B
	ds_load_2addr_b32 v[39:40], v43 offset0:34 offset1:39      // 0000000F9C80: D8DC2722 2700002B
	ds_load_2addr_b32 v[41:42], v43 offset0:44 offset1:49      // 0000000F9C88: D8DC312C 2900002B
	ds_load_2addr_b32 v[43:44], v43 offset0:54 offset1:59      // 0000000F9C90: D8DC3B36 2B00002B
	ds_load_2addr_b32 v[13:14], v55 offset0:160 offset1:165    // 0000000F9C98: D8DCA5A0 0D000037
	ds_load_2addr_b32 v[15:16], v55 offset0:170 offset1:175    // 0000000F9CA0: D8DCAFAA 0F000037
	ds_load_2addr_b32 v[17:18], v55 offset0:180 offset1:185    // 0000000F9CA8: D8DCB9B4 11000037
	ds_load_2addr_b32 v[19:20], v55 offset0:190 offset1:195    // 0000000F9CB0: D8DCC3BE 13000037
	ds_load_2addr_b32 v[21:22], v55 offset0:200 offset1:205    // 0000000F9CB8: D8DCCDC8 15000037
	ds_load_2addr_b32 v[23:24], v55 offset0:210 offset1:215    // 0000000F9CC0: D8DCD7D2 17000037
	v_mov_b32_e32 v67, v0                                      // 0000000F9CC8: 7E860300
	s_mov_b32 s9, 0                                            // 0000000F9CCC: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000F9CD0: BF8701B1
	v_lshrrev_b32_e32 v68, 2, v67                              // 0000000F9CD4: 32888682
	v_and_b32_e32 v75, -4, v67                                 // 0000000F9CD8: 369686C4
	.long 0xd4490004                                           // 0000000F9CDC: D4490004
	v_cndmask_b32_e32 v1, 0x17f, v67, vcc_lo                   // 0000000F9CE0: 020286FF 0000017F
	v_mad_u64_u32 v[68:69], null, v68, 20, v[2:3]              // 0000000F9CE8: D6FE7C44 04092944
	ds_load_2addr_b32 v[69:70], v75 offset1:129                // 0000000F9CF0: D8DC8100 4500004B
	ds_load_b32 v76, v68                                       // 0000000F9CF8: D8D80000 4C000044
	s_or_b32 s9, s4, s9                                        // 0000000F9D00: 8C090904
	s_waitcnt lgkmcnt(0)                                       // 0000000F9D04: BF89FC07
	v_dual_fmac_f32 v76, v69, v13 :: v_dual_add_nc_u32 v71, 0x400, v75// 0000000F9D08: C8201B45 4C4696FF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F9D14: BF8700C1
	v_fmac_f32_e32 v76, v70, v14                               // 0000000F9D18: 56981D46
	ds_load_2addr_b32 v[71:72], v71 offset0:2 offset1:131      // 0000000F9D1C: D8DC8302 47000047
	s_waitcnt lgkmcnt(0)                                       // 0000000F9D24: BF89FC07
	v_fmac_f32_e32 v76, v71, v15                               // 0000000F9D28: 56981F47
	v_dual_fmac_f32 v76, v72, v16 :: v_dual_add_nc_u32 v73, 0x800, v75// 0000000F9D2C: C8202148 4C4896FF 00000800
	ds_load_2addr_b32 v[73:74], v73 offset0:4 offset1:133      // 0000000F9D38: D8DC8504 49000049
	s_waitcnt lgkmcnt(0)                                       // 0000000F9D40: BF89FC07
	v_dual_fmac_f32 v76, v73, v17 :: v_dual_add_nc_u32 v69, 0xc00, v75// 0000000F9D44: C8202349 4C4496FF 00000C00
	ds_load_2addr_b32 v[69:70], v69 offset0:6 offset1:135      // 0000000F9D50: D8DC8706 45000045
	v_dual_fmac_f32 v76, v74, v18 :: v_dual_add_nc_u32 v71, 0x1000, v75// 0000000F9D58: C820254A 4C4696FF 00001000
	ds_load_2addr_b32 v[71:72], v71 offset0:8 offset1:137      // 0000000F9D64: D8DC8908 47000047
	s_waitcnt lgkmcnt(1)                                       // 0000000F9D6C: BF89FC17
	v_fmac_f32_e32 v76, v69, v19                               // 0000000F9D70: 56982745
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000F9D74: BF870001
	v_dual_fmac_f32 v76, v70, v20 :: v_dual_add_nc_u32 v73, 0x1400, v75// 0000000F9D78: C8202946 4C4896FF 00001400
	ds_load_2addr_b32 v[73:74], v73 offset0:10 offset1:139     // 0000000F9D84: D8DC8B0A 49000049
	s_waitcnt lgkmcnt(1)                                       // 0000000F9D8C: BF89FC17
	v_dual_fmac_f32 v76, v71, v21 :: v_dual_add_nc_u32 v69, 0x1800, v75// 0000000F9D90: C8202B47 4C4496FF 00001800
	v_add_nc_u32_e32 v71, 0x1c00, v75                          // 0000000F9D9C: 4A8E96FF 00001C00
	ds_load_2addr_b32 v[69:70], v69 offset0:12 offset1:141     // 0000000F9DA4: D8DC8D0C 45000045
	v_fmac_f32_e32 v76, v72, v22                               // 0000000F9DAC: 56982D48
	ds_load_2addr_b32 v[71:72], v71 offset0:14 offset1:143     // 0000000F9DB0: D8DC8F0E 47000047
	s_waitcnt lgkmcnt(2)                                       // 0000000F9DB8: BF89FC27
	v_fmac_f32_e32 v76, v73, v23                               // 0000000F9DBC: 56982F49
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F9DC0: BF8700C1
	v_dual_fmac_f32 v76, v74, v24 :: v_dual_add_nc_u32 v73, 0x2000, v75// 0000000F9DC4: C820314A 4C4896FF 00002000
	ds_load_2addr_b32 v[73:74], v73 offset0:16 offset1:145     // 0000000F9DD0: D8DC9110 49000049
	s_waitcnt lgkmcnt(2)                                       // 0000000F9DD8: BF89FC27
	v_dual_fmac_f32 v76, v69, v25 :: v_dual_add_nc_u32 v69, 0x2400, v75// 0000000F9DDC: C8203345 4C4496FF 00002400
	v_fmac_f32_e32 v76, v70, v26                               // 0000000F9DE8: 56983546
	ds_load_2addr_b32 v[69:70], v69 offset0:18 offset1:147     // 0000000F9DEC: D8DC9312 45000045
	s_waitcnt lgkmcnt(2)                                       // 0000000F9DF4: BF89FC27
	v_fmac_f32_e32 v76, v71, v27                               // 0000000F9DF8: 56983747
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F9DFC: BF8700C1
	v_dual_fmac_f32 v76, v72, v28 :: v_dual_add_nc_u32 v71, 0x2800, v75// 0000000F9E00: C8203948 4C4696FF 00002800
	ds_load_2addr_b32 v[71:72], v71 offset0:20 offset1:149     // 0000000F9E0C: D8DC9514 47000047
	s_waitcnt lgkmcnt(2)                                       // 0000000F9E14: BF89FC27
	v_dual_fmac_f32 v76, v73, v29 :: v_dual_add_nc_u32 v73, 0x2c00, v75// 0000000F9E18: C8203B49 4C4896FF 00002C00
	v_fmac_f32_e32 v76, v74, v30                               // 0000000F9E24: 56983D4A
	ds_load_2addr_b32 v[73:74], v73 offset0:22 offset1:151     // 0000000F9E28: D8DC9716 49000049
	s_waitcnt lgkmcnt(2)                                       // 0000000F9E30: BF89FC27
	v_fmac_f32_e32 v76, v69, v31                               // 0000000F9E34: 56983F45
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F9E38: BF8700C1
	v_dual_fmac_f32 v76, v70, v32 :: v_dual_add_nc_u32 v69, 0x3000, v75// 0000000F9E3C: C8204146 4C4496FF 00003000
	ds_load_2addr_b32 v[69:70], v69 offset0:24 offset1:153     // 0000000F9E48: D8DC9918 45000045
	s_waitcnt lgkmcnt(2)                                       // 0000000F9E50: BF89FC27
	v_dual_fmac_f32 v76, v71, v33 :: v_dual_add_nc_u32 v71, 0x3400, v75// 0000000F9E54: C8204347 4C4696FF 00003400
	v_fmac_f32_e32 v76, v72, v34                               // 0000000F9E60: 56984548
	ds_load_2addr_b32 v[71:72], v71 offset0:26 offset1:155     // 0000000F9E64: D8DC9B1A 47000047
	s_waitcnt lgkmcnt(2)                                       // 0000000F9E6C: BF89FC27
	v_fmac_f32_e32 v76, v73, v35                               // 0000000F9E70: 56984749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000F9E74: BF8700C1
	v_dual_fmac_f32 v76, v74, v36 :: v_dual_add_nc_u32 v73, 0x3800, v75// 0000000F9E78: C820494A 4C4896FF 00003800
	ds_load_2addr_b32 v[73:74], v73 offset0:28 offset1:157     // 0000000F9E84: D8DC9D1C 49000049
	s_waitcnt lgkmcnt(2)                                       // 0000000F9E8C: BF89FC27
	v_dual_fmac_f32 v76, v69, v37 :: v_dual_add_nc_u32 v69, 0x3c00, v75// 0000000F9E90: C8204B45 4C4496FF 00003C00
	v_fmac_f32_e32 v76, v70, v38                               // 0000000F9E9C: 56984D46
	ds_load_2addr_b32 v[69:70], v69 offset0:30 offset1:159     // 0000000F9EA0: D8DC9F1E 45000045
	s_waitcnt lgkmcnt(2)                                       // 0000000F9EA8: BF89FC27
	v_fmac_f32_e32 v76, v71, v39                               // 0000000F9EAC: 56984F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F9EB0: BF8700A1
	v_fmac_f32_e32 v76, v72, v40                               // 0000000F9EB4: 56985148
	s_waitcnt lgkmcnt(1)                                       // 0000000F9EB8: BF89FC17
	v_fmac_f32_e32 v76, v73, v41                               // 0000000F9EBC: 56985349
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000F9EC0: BF8700A1
	v_fmac_f32_e32 v76, v74, v42                               // 0000000F9EC4: 5698554A
	s_waitcnt lgkmcnt(0)                                       // 0000000F9EC8: BF89FC07
	v_fmac_f32_e32 v76, v69, v43                               // 0000000F9ECC: 56985745
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9ED0: BF870091
	v_dual_fmac_f32 v76, v70, v44 :: v_dual_add_nc_u32 v69, 0x80, v67// 0000000F9ED4: C8205946 4C4486FF 00000080
	v_mov_b32_e32 v67, v69                                     // 0000000F9EE0: 7E860345
	ds_store_b32 v68, v76                                      // 0000000F9EE4: D8340000 00004C44
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 0000000F9EEC: 917E097E
	s_cbranch_execnz 65399                                     // 0000000F9EF0: BFA6FF77 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x16d0>
	s_branch 64130                                             // 0000000F9EF4: BFA0FA82 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x300>
	s_and_saveexec_b32 s0, vcc_lo                              // 0000000F9EF8: BE80206A
	s_cbranch_execz 52                                         // 0000000F9EFC: BFA50034 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19d0>
	s_ashr_i32 s7, s6, 31                                      // 0000000F9F00: 86079F06
	v_lshlrev_b32_e32 v0, 9, v46                               // 0000000F9F04: 30005C89
	s_lshl_b64 s[0:1], s[22:23], 2                             // 0000000F9F08: 84808216
	s_lshl_b64 s[2:3], s[6:7], 2                               // 0000000F9F0C: 84828206
	v_lshlrev_b32_e32 v1, 2, v47                               // 0000000F9F10: 30025E82
	s_add_u32 s0, s2, s0                                       // 0000000F9F14: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000F9F18: 82010103
	.long 0xd7000000                                           // 0000000F9F1C: D7000000
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000F9F20: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000F9F24: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 0000000F9F28: D5207C02 00010001
	s_mov_b32 s1, 0                                            // 0000000F9F30: BE810080
	.long 0xd7006a00                                           // 0000000F9F34: D7006A00
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000000F9F38: 02020300
	v_add_co_ci_u32_e64 v3, null, 0, v2, vcc_lo                // 0000000F9F3C: D5207C03 01AA0480
	v_mad_u32_u24 v2, v46, 20, v1                              // 0000000F9F44: D60B0002 0405292E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000F9F4C: BF870093
	.long 0xd7006a00                                           // 0000000F9F50: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 0000000F9F54: 02020014
	v_add_co_ci_u32_e64 v1, null, s21, v3, vcc_lo              // 0000000F9F58: D5207C01 01AA0615
	s_nop 0                                                    // 0000000F9F60: BF800000
	s_nop 0                                                    // 0000000F9F64: BF800000
	s_nop 0                                                    // 0000000F9F68: BF800000
	s_nop 0                                                    // 0000000F9F6C: BF800000
	s_nop 0                                                    // 0000000F9F70: BF800000
	s_nop 0                                                    // 0000000F9F74: BF800000
	s_nop 0                                                    // 0000000F9F78: BF800000
	s_nop 0                                                    // 0000000F9F7C: BF800000
	ds_load_b32 v3, v2 offset:16512                            // 0000000F9F80: D8D84080 03000002
	v_add_nc_u32_e32 v45, 0x80, v45                            // 0000000F9F88: 4A5A5AFF 00000080
	v_add_nc_u32_e32 v2, 0x280, v2                             // 0000000F9F90: 4A0404FF 00000280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000F9F98: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x17f, v45                        // 0000000F9F9C: 7C925AFF 0000017F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000F9FA4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000F9FA8: BF89FC07
	global_store_b32 v[0:1], v3, off                           // 0000000F9FAC: DC6A0000 007C0300
	.long 0xd7000000                                           // 0000000F9FB4: D7000000
	v_cndmask_b32_e32 v1, 0x4000, v0, vcc_lo                   // 0000000F9FB8: 020200FF 00004000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000F9FC0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000F9FC8: 917E017E
	s_cbranch_execnz 65516                                     // 0000000F9FCC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi32ELi32ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1980>
	s_endpgm                                                   // 0000000F9FD0: BFB00000
		...

