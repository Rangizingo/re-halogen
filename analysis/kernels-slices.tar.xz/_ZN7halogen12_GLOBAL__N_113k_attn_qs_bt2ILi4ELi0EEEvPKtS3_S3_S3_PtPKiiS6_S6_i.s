000000000019c500 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi4ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi4ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_clause 0x1                                               // 00000019C500: BF850001
	s_load_b128 s[12:15], s[0:1], 0x20                         // 00000019C504: F4080300 F8000020
	s_load_b128 s[16:19], s[0:1], 0x38                         // 00000019C50C: F4080400 F8000038
	s_mov_b32 s20, s3                                          // 00000019C514: BE940003
	s_ashr_i32 s3, s2, 31                                      // 00000019C518: 86039F02
	s_load_b32 s21, s[0:1], 0x48                               // 00000019C51C: F4000540 F8000048
	s_waitcnt lgkmcnt(0)                                       // 00000019C524: BF89FC07
	s_load_b32 s14, s[14:15], null                             // 00000019C528: F4000387 F8000000
	s_load_b256 s[4:11], s[0:1], null                          // 00000019C530: F40C0100 F8000000
	s_lshl_b64 s[0:1], s[2:3], 2                               // 00000019C538: 84808202
	s_waitcnt lgkmcnt(0)                                       // 00000019C53C: BF89FC07
	s_add_i32 s14, s14, s2                                     // 00000019C540: 810E020E
	s_add_u32 s0, s18, s0                                      // 00000019C544: 80000012
	s_addc_u32 s1, s19, s1                                     // 00000019C548: 82010113
	s_add_i32 s15, s14, 1                                      // 00000019C54C: 810F810E
	s_load_b32 s3, s[0:1], null                                // 00000019C550: F40000C0 F8000000
	s_ashr_i32 s0, s15, 31                                     // 00000019C558: 86009F0F
	s_mul_hi_i32 s1, s21, s2                                   // 00000019C55C: 97010215
	s_lshr_b32 s0, s0, 30                                      // 00000019C560: 85009E00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000019C564: BF870499
	s_add_i32 s15, s15, s0                                     // 00000019C568: 810F000F
	s_and_b32 s0, s15, -4                                      // 00000019C56C: 8B00C40F
	s_ashr_i32 s18, s15, 2                                     // 00000019C570: 8612820F
	s_sub_i32 s14, s14, s0                                     // 00000019C574: 818E000E
	s_mul_i32 s0, s21, s2                                      // 00000019C578: 96000215
	s_cmp_gt_i32 s14, -1                                       // 00000019C57C: BF02C10E
	s_mov_b32 s19, s18                                         // 00000019C580: BE930012
	s_cselect_b32 s15, -1, 0                                   // 00000019C584: 980F80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000019C588: BF870009
	s_and_b32 vcc_lo, exec_lo, s15                             // 00000019C58C: 8B6A0F7E
	s_cbranch_vccnz 15                                         // 00000019C590: BFA4000F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi4ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd0>
	s_lshl_b64 s[22:23], s[0:1], 2                             // 00000019C594: 84968200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000019C598: BF8704D9
	s_add_u32 s19, s16, s22                                    // 00000019C59C: 80131610
	s_addc_u32 s21, s17, s23                                   // 00000019C5A0: 82151711
	s_waitcnt lgkmcnt(0)                                       // 00000019C5A4: BF89FC07
	s_max_i32 s22, s3, 1                                       // 00000019C5A8: 8A168103
	s_mov_b32 s23, 0                                           // 00000019C5AC: BE970080
	s_lshl_b64 s[22:23], s[22:23], 2                           // 00000019C5B0: 84968216
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000019C5B4: BF870009
	s_add_u32 s19, s19, s22                                    // 00000019C5B8: 80131613
	s_addc_u32 s21, s21, s23                                   // 00000019C5BC: 82151715
	s_add_u32 s22, s19, -4                                     // 00000019C5C0: 8016C413
	s_addc_u32 s23, s21, -1                                    // 00000019C5C4: 8217C115
	s_load_b32 s19, s[22:23], null                             // 00000019C5C8: F40004CB F8000000
	v_cndmask_b32_e64 v1, 0, 1, s15                            // 00000019C5D0: D5010001 003D0280
	s_mov_b32 s23, exec_lo                                     // 00000019C5D8: BE97007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000019C5DC: BF8704B1
	v_readfirstlane_b32 s15, v1                                // 00000019C5E0: 7E1E0501
	s_waitcnt lgkmcnt(0)                                       // 00000019C5E4: BF89FC07
	s_add_i32 s21, s3, s15                                     // 00000019C5E8: 81150F03
	s_add_i32 s15, s21, 3                                      // 00000019C5EC: 810F8315
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000019C5F0: BF870499
	s_and_b32 s22, s15, -4                                     // 00000019C5F4: 8B16C40F
	.long 0xd4c4007e                                           // 00000019C5F8: D4C4007E
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 00000019C5FC: 02020016
	s_cbranch_execz 45                                         // 00000019C600: BFA5002D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi4ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1b8>
	v_dual_mov_b32 v4, v0 :: v_dual_lshlrev_b32 v3, 2, v0      // 00000019C604: CA220100 04020082
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000019C60C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019C610: BF8700A9
	s_add_u32 s0, s16, s0                                      // 00000019C614: 80000010
	s_addc_u32 s1, s17, s1                                     // 00000019C618: 82010111
	.long 0xd7000001                                           // 00000019C61C: D7000001
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 00000019C620: 02020600
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019C624: BF870001
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 00000019C628: D5207C02 00010001
	s_mov_b32 s1, 0                                            // 00000019C630: BE810080
	s_set_inst_prefetch_distance 0x1                           // 00000019C634: BF840001
	s_branch 18                                                // 00000019C638: BFA00012 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi4ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x184>
	s_nop 0                                                    // 00000019C63C: BF800000
	s_or_b32 exec_lo, exec_lo, s0                              // 00000019C640: 8C7E007E
	v_add_nc_u32_e32 v4, 64, v4                                // 00000019C644: 4A0808C0
	.long 0xd7000001                                           // 00000019C648: D7000001
	v_cndmask_b32_e32 v1, 0x100, v1, vcc_lo                    // 00000019C64C: 020202FF 00000100
	s_waitcnt vmcnt(0)                                         // 00000019C654: BF8903F7
	ds_store_b32 v3, v5 offset:1024                            // 00000019C658: D8340400 00000503
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 00000019C660: D5207C02 00020480
	v_cmp_le_i32_e32 vcc_lo, s22, v4                           // 00000019C668: 7C860816
	v_add_nc_u32_e32 v3, 0x100, v3                             // 00000019C66C: 4A0606FF 00000100
	s_or_b32 s1, vcc_lo, s1                                    // 00000019C674: 8C01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000019C678: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000019C67C: 917E017E
	s_cbranch_execz 13                                         // 00000019C680: BFA5000D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi4ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1b8>
	s_mov_b32 s0, exec_lo                                      // 00000019C684: BE80007E
	.long 0xd4c3007e                                           // 00000019C688: D4C3007E
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 00000019C68C: 02020803
	s_xor_b32 s0, exec_lo, s0                                  // 00000019C690: 8D00007E
	v_mov_b32_e32 v5, s18                                      // 00000019C694: 7E0A0212
	v_cmp_gt_i32_e32 vcc_lo, s21, v4                           // 00000019C698: 7C880815
	s_delay_alu instid0(VALU_DEP_2)                            // 00000019C69C: BF870002
	v_cndmask_b32_e32 v5, s19, v5, vcc_lo                      // 00000019C6A0: 020A0A13
	s_and_not1_saveexec_b32 s0, s0                             // 00000019C6A4: BE803000
	s_cbranch_execz 65509                                      // 00000019C6A8: BFA5FFE5 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi4ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	global_load_b32 v5, v[1:2], off                            // 00000019C6AC: DC520000 057C0001
	s_branch 65506                                             // 00000019C6B4: BFA0FFE2 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi4ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	s_set_inst_prefetch_distance 0x2                           // 00000019C6B8: BF840002
	s_or_b32 exec_lo, exec_lo, s23                             // 00000019C6BC: 8C7E177E
	v_lshrrev_b32_e32 v7, 5, v0                                // 00000019C6C0: 320E0085
	s_mov_b32 s1, exec_lo                                      // 00000019C6C4: BE81007E
	v_cmpx_gt_u32_e32 0x180, v0                                // 00000019C6C8: 7D9800FF 00000180
	s_cbranch_execz 48                                         // 00000019C6D0: BFA50030 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi4ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x294>
	s_delay_alu instid0(VALU_DEP_2)                            // 00000019C6D4: BF870002
	v_mul_u32_u24_e32 v1, 0x210, v7                            // 00000019C6D8: 16020EFF 00000210
	v_and_b32_e32 v2, 31, v0                                   // 00000019C6E0: 3604009F
	s_mul_i32 s16, s20, 0xc00                                  // 00000019C6E4: 9610FF14 00000C00
	s_mul_i32 s18, s2, 0x3000                                  // 00000019C6EC: 9612FF02 00003000
	s_ashr_i32 s17, s16, 31                                    // 00000019C6F4: 86119F10
	s_mul_hi_i32 s0, s2, 0x3000                                // 00000019C6F8: 9700FF02 00003000
	s_lshl_b64 s[16:17], s[16:17], 1                           // 00000019C700: 84908110
	v_lshl_add_u32 v4, v2, 4, v1                               // 00000019C704: D6460004 04050902
	v_lshlrev_b32_e32 v1, 4, v0                                // 00000019C70C: 30020084
	s_add_u32 s4, s4, s16                                      // 00000019C710: 80041004
	s_addc_u32 s5, s5, s17                                     // 00000019C714: 82051105
	s_add_u32 s4, s4, s18                                      // 00000019C718: 80041204
	s_addc_u32 s0, s5, s0                                      // 00000019C71C: 82000005
	.long 0xd7000401                                           // 00000019C720: D7000401
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000019C724: 02020204
	v_lshl_or_b32 v3, v0, 3, 0xfffffe00                        // 00000019C728: D6560003 03FD0700 FFFFFE00
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 00000019C734: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 00000019C73C: BE840080
	global_load_b128 v[8:11], v[1:2], off                      // 00000019C740: DC5E0000 087C0001
	v_add_nc_u32_e32 v3, 0x200, v3                             // 00000019C748: 4A0606FF 00000200
	.long 0xd7006a01                                           // 00000019C750: D7006A01
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 00000019C754: 020202FF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019C75C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000019C760: D5207C02 01AA0480
	.long 0xd4490000                                           // 00000019C768: D4490000
	v_cndmask_b32_e32 v1, 0x9ff, v3, vcc_lo                    // 00000019C76C: 020206FF 000009FF
	s_or_b32 s4, s0, s4                                        // 00000019C774: 8C040400
	s_waitcnt vmcnt(0)                                         // 00000019C778: BF8903F7
	ds_store_b128 v4, v[8:11] offset:9232                      // 00000019C77C: DB7C2410 00000804
	v_add_nc_u32_e32 v4, 0x420, v4                             // 00000019C784: 4A0808FF 00000420
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000019C78C: 917E047E
	s_cbranch_execnz 65515                                     // 00000019C790: BFA6FFEB <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi4ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x240>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000019C794: 8C7E017E
	v_lshlrev_b32_e32 v81, 7, v7                               // 00000019C798: 30A20E87
	s_ashr_i32 s0, s15, 2                                      // 00000019C79C: 8600820F
	s_mov_b32 s1, 0                                            // 00000019C7A0: BE810080
	s_cmp_gt_i32 s0, 0                                         // 00000019C7A4: BF028000
	s_waitcnt lgkmcnt(0)                                       // 00000019C7A8: BF89FC07
	s_barrier                                                  // 00000019C7AC: BFBD0000
	buffer_gl0_inv                                             // 00000019C7B0: E0AC0000 00000000
	s_cbranch_scc1 2                                           // 00000019C7B8: BFA20002 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi4ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x2c4>
	v_lshlrev_b32_e32 v8, 7, v7                                // 00000019C7BC: 30100E87
	s_branch 1                                                 // 00000019C7C0: BFA00001 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi4ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x2c8>
	s_mov_b32 s1, -1                                           // 00000019C7C4: BE8100C1
	v_dual_mov_b32 v38, 0 :: v_dual_and_b32 v73, 15, v0        // 00000019C7C8: CA240080 2648008F
	v_bfe_u32 v80, v0, 4, 1                                    // 00000019C7D0: D6100050 02050900
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000019C7D8: 916A017E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000019C7DC: BF870002
	v_mov_b32_e32 v37, v38                                     // 00000019C7E0: 7E4A0326
	v_mov_b32_e32 v36, v38                                     // 00000019C7E4: 7E480326
	v_mov_b32_e32 v35, v38                                     // 00000019C7E8: 7E460326
	v_mov_b32_e32 v34, v38                                     // 00000019C7EC: 7E440326
	v_mov_b32_e32 v33, v38                                     // 00000019C7F0: 7E420326
	v_mov_b32_e32 v46, v38                                     // 00000019C7F4: 7E5C0326
	v_mov_b32_e32 v45, v38                                     // 00000019C7F8: 7E5A0326
	v_mov_b32_e32 v44, v38                                     // 00000019C7FC: 7E580326
	v_mov_b32_e32 v43, v38                                     // 00000019C800: 7E560326
	v_mov_b32_e32 v42, v38                                     // 00000019C804: 7E540326
	v_mov_b32_e32 v41, v38                                     // 00000019C808: 7E520326
	v_mov_b32_e32 v54, v38                                     // 00000019C80C: 7E6C0326
	v_mov_b32_e32 v53, v38                                     // 00000019C810: 7E6A0326
	v_mov_b32_e32 v52, v38                                     // 00000019C814: 7E680326
	v_mov_b32_e32 v51, v38                                     // 00000019C818: 7E660326
	v_mov_b32_e32 v50, v38                                     // 00000019C81C: 7E640326
	v_mov_b32_e32 v49, v38                                     // 00000019C820: 7E620326
	v_mov_b32_e32 v62, v38                                     // 00000019C824: 7E7C0326
	v_mov_b32_e32 v61, v38                                     // 00000019C828: 7E7A0326
	v_mov_b32_e32 v60, v38                                     // 00000019C82C: 7E780326
	v_mov_b32_e32 v59, v38                                     // 00000019C830: 7E760326
	v_mov_b32_e32 v58, v38                                     // 00000019C834: 7E740326
	v_mov_b32_e32 v57, v38                                     // 00000019C838: 7E720326
	v_mov_b32_e32 v30, v38                                     // 00000019C83C: 7E3C0326
	v_mov_b32_e32 v29, v38                                     // 00000019C840: 7E3A0326
	v_mov_b32_e32 v28, v38                                     // 00000019C844: 7E380326
	v_mov_b32_e32 v27, v38                                     // 00000019C848: 7E360326
	v_mov_b32_e32 v26, v38                                     // 00000019C84C: 7E340326
	v_mov_b32_e32 v25, v38                                     // 00000019C850: 7E320326
	v_mov_b32_e32 v22, v38                                     // 00000019C854: 7E2C0326
	v_mov_b32_e32 v21, v38                                     // 00000019C858: 7E2A0326
	v_mov_b32_e32 v20, v38                                     // 00000019C85C: 7E280326
	v_mov_b32_e32 v19, v38                                     // 00000019C860: 7E260326
	v_mov_b32_e32 v18, v38                                     // 00000019C864: 7E240326
	v_mov_b32_e32 v17, v38                                     // 00000019C868: 7E220326
	v_mov_b32_e32 v14, v38                                     // 00000019C86C: 7E1C0326
	v_mov_b32_e32 v13, v38                                     // 00000019C870: 7E1A0326
	v_mov_b32_e32 v12, v38                                     // 00000019C874: 7E180326
	v_mov_b32_e32 v11, v38                                     // 00000019C878: 7E160326
	v_mov_b32_e32 v10, v38                                     // 00000019C87C: 7E140326
	v_mov_b32_e32 v9, v38                                      // 00000019C880: 7E120326
	v_mov_b32_e32 v6, v38                                      // 00000019C884: 7E0C0326
	v_mov_b32_e32 v5, v38                                      // 00000019C888: 7E0A0326
	v_mov_b32_e32 v4, v38                                      // 00000019C88C: 7E080326
	v_mov_b32_e32 v3, v38                                      // 00000019C890: 7E060326
	v_mov_b32_e32 v2, v38                                      // 00000019C894: 7E040326
	v_mov_b32_e32 v1, v38                                      // 00000019C898: 7E020326
	v_mov_b32_e32 v76, v38                                     // 00000019C89C: 7E980326
	v_mov_b32_e32 v75, v38                                     // 00000019C8A0: 7E960326
	v_mov_b32_e32 v78, v38                                     // 00000019C8A4: 7E9C0326
	v_mov_b32_e32 v77, v38                                     // 00000019C8A8: 7E9A0326
	v_mov_b32_e32 v79, v38                                     // 00000019C8AC: 7E9E0326
	v_mov_b32_e32 v74, v38                                     // 00000019C8B0: 7E940326
	s_cbranch_vccnz 522                                        // 00000019C8B4: BFA4020A <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi4ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xbe0>
	v_cmp_gt_u32_e32 vcc_lo, 12, v73                           // 00000019C8B8: 7C98928C
	s_ashr_i32 s21, s20, 31                                    // 00000019C8BC: 86159F14
	s_lshl2_add_u32 s1, s3, s14                                // 00000019C8C0: 87810E03
	v_dual_mov_b32 v65, 0 :: v_dual_lshlrev_b32 v0, 5, v0      // 00000019C8C4: CA220080 41000085
	v_dual_cndmask_b32 v2, 0, v73 :: v_dual_lshlrev_b32 v3, 10, v7// 00000019C8CC: CA629280 02020E8A
	s_lshl_b64 s[4:5], s[20:21], 11                            // 00000019C8D4: 84848B14
	v_dual_mov_b32 v74, 0 :: v_dual_lshlrev_b32 v1, 2, v73     // 00000019C8D8: CA220080 4A009282
	s_add_i32 s1, s1, 1                                        // 00000019C8E0: 81018101
	s_add_u32 s3, s6, s4                                       // 00000019C8E4: 80030406
	s_addc_u32 s4, s7, s5                                      // 00000019C8E8: 82040507
	v_dual_mov_b32 v69, v65 :: v_dual_and_b32 v0, 0x60, v0     // 00000019C8EC: CA240141 450000FF 00000060
	.long 0xd7000305                                           // 00000019C8F8: D7000305
	v_cndmask_b32_e32 v1, s3, v3, vcc_lo                       // 00000019C8FC: 02020603
	v_lshl_or_b32 v1, v80, 6, v1                               // 00000019C900: D6560001 04050D50
	v_add_co_ci_u32_e64 v6, null, s4, 0, s3                    // 00000019C908: D5207C06 000D0004
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019C910: BF870003
	.long 0xd7006a00                                           // 00000019C914: D7006A00
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 00000019C918: 02020105
	s_movk_i32 s3, 0x210                                       // 00000019C91C: B0030210
	v_dual_mov_b32 v67, v65 :: v_dual_lshlrev_b32 v4, 9, v7    // 00000019C920: CA220141 43040E89
	v_add_co_ci_u32_e64 v82, null, 0, v6, vcc_lo               // 00000019C928: D5207C52 01AA0C80
	v_xor_b32_e32 v5, 1, v7                                    // 00000019C930: 3A0A0E81
	v_dual_mov_b32 v71, v65 :: v_dual_lshlrev_b32 v6, 5, v80   // 00000019C934: CA220141 4706A085
	v_dual_mov_b32 v79, 0 :: v_dual_lshlrev_b32 v8, 1, v73     // 00000019C93C: CA220080 4F089281
	v_mad_u32_u24 v2, v2, s3, 0x2410                           // 00000019C944: D60B0002 03FC0702 00002410
	v_dual_mov_b32 v66, v65 :: v_dual_lshlrev_b32 v7, 8, v7    // 00000019C950: CA220141 42060E88
	s_lshl_b64 s[4:5], s[20:21], 8                             // 00000019C958: 84848814
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000019C95C: BF870249
	v_dual_mov_b32 v88, s5 :: v_dual_add_nc_u32 v1, 0x3cd0, v1 // 00000019C960: CA200005 580002FF 00003CD0
	v_or3_b32 v85, v4, v6, v8                                  // 00000019C96C: D6580055 04220D04
	v_lshl_or_b32 v86, v73, 5, v4                              // 00000019C974: D6560056 04110B49
	v_or3_b32 v87, s4, v73, v81                                // 00000019C97C: D6580057 05469204
	v_dual_mov_b32 v78, 0 :: v_dual_add_nc_u32 v83, v1, v3     // 00000019C984: CA200080 4E520701
	v_lshl_add_u32 v84, v5, 10, v1                             // 00000019C98C: D6460054 04051505
	v_dual_mov_b32 v68, v65 :: v_dual_and_b32 v89, 12, v73     // 00000019C994: CA240141 4458928C
	v_dual_mov_b32 v77, 0 :: v_dual_add_nc_u32 v90, v2, v7     // 00000019C99C: CA200080 4D5A0F02
	v_dual_mov_b32 v70, v65 :: v_dual_mov_b32 v75, 0           // 00000019C9A4: CA100141 464A0080
	v_dual_mov_b32 v72, v65 :: v_dual_mov_b32 v91, 0           // 00000019C9AC: CA100141 485A0080
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v1, 0              // 00000019C9B4: CA100080 4C000080
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v3, v74            // 00000019C9BC: CA100080 5C02014A
	v_dual_mov_b32 v2, v74 :: v_dual_mov_b32 v9, 0             // 00000019C9C4: CA10014A 02080080
	v_dual_mov_b32 v4, v74 :: v_dual_mov_b32 v17, 0            // 00000019C9CC: CA10014A 04100080
	v_mov_b32_e32 v5, v74                                      // 00000019C9D4: 7E0A034A
	v_dual_mov_b32 v6, v74 :: v_dual_mov_b32 v25, 0            // 00000019C9D8: CA10014A 06180080
	v_mov_b32_e32 v7, v74                                      // 00000019C9E0: 7E0E034A
	v_dual_mov_b32 v8, v74 :: v_dual_mov_b32 v57, 0            // 00000019C9E4: CA10014A 08380080
	v_dual_mov_b32 v10, v74 :: v_dual_mov_b32 v49, 0           // 00000019C9EC: CA10014A 0A300080
	v_mov_b32_e32 v11, v74                                     // 00000019C9F4: 7E16034A
	v_dual_mov_b32 v12, v74 :: v_dual_mov_b32 v41, 0           // 00000019C9F8: CA10014A 0C280080
	v_mov_b32_e32 v13, v74                                     // 00000019CA00: 7E1A034A
	v_dual_mov_b32 v14, v74 :: v_dual_mov_b32 v33, 0           // 00000019CA04: CA10014A 0E200080
	v_mov_b32_e32 v15, v74                                     // 00000019CA0C: 7E1E034A
	v_mov_b32_e32 v16, v74                                     // 00000019CA10: 7E20034A
	v_mov_b32_e32 v18, v74                                     // 00000019CA14: 7E24034A
	v_mov_b32_e32 v19, v74                                     // 00000019CA18: 7E26034A
	v_mov_b32_e32 v20, v74                                     // 00000019CA1C: 7E28034A
	v_mov_b32_e32 v21, v74                                     // 00000019CA20: 7E2A034A
	v_mov_b32_e32 v22, v74                                     // 00000019CA24: 7E2C034A
	v_mov_b32_e32 v23, v74                                     // 00000019CA28: 7E2E034A
	v_mov_b32_e32 v24, v74                                     // 00000019CA2C: 7E30034A
	v_mov_b32_e32 v26, v74                                     // 00000019CA30: 7E34034A
	v_mov_b32_e32 v27, v74                                     // 00000019CA34: 7E36034A
	v_mov_b32_e32 v28, v74                                     // 00000019CA38: 7E38034A
	v_mov_b32_e32 v29, v74                                     // 00000019CA3C: 7E3A034A
	v_mov_b32_e32 v30, v74                                     // 00000019CA40: 7E3C034A
	v_mov_b32_e32 v31, v74                                     // 00000019CA44: 7E3E034A
	v_mov_b32_e32 v32, v74                                     // 00000019CA48: 7E40034A
	v_mov_b32_e32 v58, v74                                     // 00000019CA4C: 7E74034A
	v_mov_b32_e32 v59, v74                                     // 00000019CA50: 7E76034A
	v_mov_b32_e32 v60, v74                                     // 00000019CA54: 7E78034A
	v_mov_b32_e32 v61, v74                                     // 00000019CA58: 7E7A034A
	v_mov_b32_e32 v62, v74                                     // 00000019CA5C: 7E7C034A
	v_mov_b32_e32 v63, v74                                     // 00000019CA60: 7E7E034A
	v_mov_b32_e32 v64, v74                                     // 00000019CA64: 7E80034A
	v_mov_b32_e32 v50, v74                                     // 00000019CA68: 7E64034A
	v_mov_b32_e32 v51, v74                                     // 00000019CA6C: 7E66034A
	v_mov_b32_e32 v52, v74                                     // 00000019CA70: 7E68034A
	v_mov_b32_e32 v53, v74                                     // 00000019CA74: 7E6A034A
	v_mov_b32_e32 v54, v74                                     // 00000019CA78: 7E6C034A
	v_mov_b32_e32 v55, v74                                     // 00000019CA7C: 7E6E034A
	v_mov_b32_e32 v56, v74                                     // 00000019CA80: 7E70034A
	v_mov_b32_e32 v42, v74                                     // 00000019CA84: 7E54034A
	v_mov_b32_e32 v43, v74                                     // 00000019CA88: 7E56034A
	v_mov_b32_e32 v44, v74                                     // 00000019CA8C: 7E58034A
	v_mov_b32_e32 v45, v74                                     // 00000019CA90: 7E5A034A
	v_mov_b32_e32 v46, v74                                     // 00000019CA94: 7E5C034A
	v_mov_b32_e32 v47, v74                                     // 00000019CA98: 7E5E034A
	v_mov_b32_e32 v48, v74                                     // 00000019CA9C: 7E60034A
	v_mov_b32_e32 v34, v74                                     // 00000019CAA0: 7E44034A
	v_mov_b32_e32 v35, v74                                     // 00000019CAA4: 7E46034A
	v_mov_b32_e32 v36, v74                                     // 00000019CAA8: 7E48034A
	v_mov_b32_e32 v37, v74                                     // 00000019CAAC: 7E4A034A
	v_mov_b32_e32 v38, v74                                     // 00000019CAB0: 7E4C034A
	v_mov_b32_e32 v39, v74                                     // 00000019CAB4: 7E4E034A
	v_mov_b32_e32 v40, v74                                     // 00000019CAB8: 7E50034A
	s_mov_b32 s3, 0                                            // 00000019CABC: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000019CAC0: BF870009
	v_dual_mov_b32 v158, s3 :: v_dual_add_nc_u32 v157, s3, v89 // 00000019CAC4: CA200003 9E9CB203
	ds_load_b128 v[93:96], v90                                 // 00000019CACC: DBFC0000 5D00005A
	ds_load_b128 v[97:100], v90 offset:16                      // 00000019CAD4: DBFC0010 6100005A
	ds_load_b128 v[101:104], v90 offset:32                     // 00000019CADC: DBFC0020 6500005A
	ds_load_b128 v[105:108], v90 offset:48                     // 00000019CAE4: DBFC0030 6900005A
	ds_load_b128 v[113:116], v90 offset:80                     // 00000019CAEC: DBFC0050 7100005A
	ds_load_b128 v[109:112], v90 offset:64                     // 00000019CAF4: DBFC0040 6D00005A
	ds_load_b128 v[121:124], v90 offset:112                    // 00000019CAFC: DBFC0070 7900005A
	ds_load_b128 v[117:120], v90 offset:96                     // 00000019CB04: DBFC0060 7500005A
	ds_load_b128 v[129:132], v90 offset:144                    // 00000019CB0C: DBFC0090 8100005A
	ds_load_b128 v[125:128], v90 offset:128                    // 00000019CB14: DBFC0080 7D00005A
	ds_load_b128 v[137:140], v90 offset:176                    // 00000019CB1C: DBFC00B0 8900005A
	ds_load_b128 v[133:136], v90 offset:160                    // 00000019CB24: DBFC00A0 8500005A
	ds_load_b128 v[145:148], v90 offset:208                    // 00000019CB2C: DBFC00D0 9100005A
	ds_load_b128 v[141:144], v90 offset:192                    // 00000019CB34: DBFC00C0 8D00005A
	ds_load_b128 v[153:156], v90 offset:240                    // 00000019CB3C: DBFC00F0 9900005A
	ds_load_b128 v[149:152], v90 offset:224                    // 00000019CB44: DBFC00E0 9500005A
	ds_load_b32 v157, v157 offset:1024                         // 00000019CB4C: D8D80400 9D00009D
	ds_load_b128 v[221:224], v158 offset:1024                  // 00000019CB54: DBFC0400 DD00009E
	s_add_i32 s0, s0, -1                                       // 00000019CB5C: 8100C100
	s_add_i32 s3, s3, 16                                       // 00000019CB60: 81039003
	s_waitcnt lgkmcnt(1)                                       // 00000019CB64: BF89FC17
	v_ashrrev_i32_e32 v158, 31, v157                           // 00000019CB68: 353D3A9F
	s_waitcnt lgkmcnt(0)                                       // 00000019CB6C: BF89FC07
	v_ashrrev_i32_e32 v227, 31, v221                           // 00000019CB70: 35C7BA9F
	v_dual_mov_b32 v226, v221 :: v_dual_mov_b32 v221, v223     // 00000019CB74: CA1001DD E2DC01DF
	v_ashrrev_i32_e32 v229, 31, v222                           // 00000019CB7C: 35CBBC9F
	.long 0xd73c009d                                           // 00000019CB80: D73C009D
	v_cndmask_b32_e32 v1, 12, v157, vcc_lo                     // 00000019CB84: 02033A8C
	v_mov_b32_e32 v228, v222                                   // 00000019CB88: 7FC803DE
	v_ashrrev_i32_e32 v222, 31, v223                           // 00000019CB8C: 35BDBE9F
	.long 0xd73c00e2                                           // 00000019CB90: D73C00E2
	v_cndmask_b32_e32 v1, 9, v226, vcc_lo                      // 00000019CB94: 0203C489
	v_ashrrev_i32_e32 v225, 31, v224                           // 00000019CB98: 35C3C09F
	.long 0xd7006ad5                                           // 00000019CB9C: D7006AD5
	v_cndmask_b32_e32 v1, v0, v157, vcc_lo                     // 00000019CBA0: 02033B00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019CBA4: BF870001
	v_add_co_ci_u32_e64 v214, null, v82, v158, vcc_lo          // 00000019CBA8: D5207CD6 01AB3D52
	.long 0xd73c00e4                                           // 00000019CBB0: D73C00E4
	v_cndmask_b32_e32 v1, 9, v228, vcc_lo                      // 00000019CBB4: 0203C889
	.long 0xd73c00dd                                           // 00000019CBB8: D73C00DD
	v_cndmask_b32_e32 v1, 9, v221, vcc_lo                      // 00000019CBBC: 0203BA89
	s_clause 0xf                                               // 00000019CBC0: BF85000F
	global_load_b128 v[161:164], v[213:214], off offset:16     // 00000019CBC4: DC5E0010 A17C00D5
	global_load_b128 v[157:160], v[213:214], off               // 00000019CBCC: DC5E0000 9D7C00D5
	global_load_b128 v[169:172], v[213:214], off offset:144    // 00000019CBD4: DC5E0090 A97C00D5
	global_load_b128 v[165:168], v[213:214], off offset:128    // 00000019CBDC: DC5E0080 A57C00D5
	global_load_b128 v[177:180], v[213:214], off offset:272    // 00000019CBE4: DC5E0110 B17C00D5
	global_load_b128 v[173:176], v[213:214], off offset:256    // 00000019CBEC: DC5E0100 AD7C00D5
	global_load_b128 v[185:188], v[213:214], off offset:400    // 00000019CBF4: DC5E0190 B97C00D5
	global_load_b128 v[181:184], v[213:214], off offset:384    // 00000019CBFC: DC5E0180 B57C00D5
	global_load_b128 v[193:196], v[213:214], off offset:528    // 00000019CC04: DC5E0210 C17C00D5
	global_load_b128 v[189:192], v[213:214], off offset:512    // 00000019CC0C: DC5E0200 BD7C00D5
	global_load_b128 v[201:204], v[213:214], off offset:656    // 00000019CC14: DC5E0290 C97C00D5
	global_load_b128 v[197:200], v[213:214], off offset:640    // 00000019CC1C: DC5E0280 C57C00D5
	global_load_b128 v[209:212], v[213:214], off offset:784    // 00000019CC24: DC5E0310 D17C00D5
	global_load_b128 v[205:208], v[213:214], off offset:768    // 00000019CC2C: DC5E0300 CD7C00D5
	global_load_b128 v[217:220], v[213:214], off offset:912    // 00000019CC34: DC5E0390 D97C00D5
	global_load_b128 v[213:216], v[213:214], off offset:896    // 00000019CC3C: DC5E0380 D57C00D5
	.long 0xd73c00df                                           // 00000019CC44: D73C00DF
	v_cndmask_b32_e32 v1, 9, v224, vcc_lo                      // 00000019CC48: 0203C089
	.long 0xd7006ae1                                           // 00000019CC4C: D7006AE1
	v_cndmask_b32_e32 v1, v226, v87, vcc_lo                    // 00000019CC50: 0202AFE2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019CC54: BF8700A1
	v_add_co_ci_u32_e64 v226, null, v227, v88, vcc_lo          // 00000019CC58: D5207CE2 01AAB1E3
	.long 0xd7006ae3                                           // 00000019CC60: D7006AE3
	v_cndmask_b32_e32 v1, v228, v87, vcc_lo                    // 00000019CC64: 0202AFE4
	v_add_co_ci_u32_e64 v228, null, v229, v88, vcc_lo          // 00000019CC68: D5207CE4 01AAB1E5
	.long 0xd7006add                                           // 00000019CC70: D7006ADD
	v_cndmask_b32_e32 v1, v221, v87, vcc_lo                    // 00000019CC74: 0202AFDD
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019CC78: BF870001
	v_add_co_ci_u32_e64 v222, null, v222, v88, vcc_lo          // 00000019CC7C: D5207CDE 01AAB1DE
	.long 0xd7006adf                                           // 00000019CC84: D7006ADF
	v_cndmask_b32_e32 v1, v223, v87, vcc_lo                    // 00000019CC88: 0202AFDF
	.long 0xd73c00e1                                           // 00000019CC8C: D73C00E1
	v_cndmask_b32_e32 v1, 3, v225, vcc_lo                      // 00000019CC90: 0203C283
	v_add_co_ci_u32_e64 v224, null, v224, v88, vcc_lo          // 00000019CC94: D5207CE0 01AAB1E0
	.long 0xd73c00e3                                           // 00000019CC9C: D73C00E3
	v_cndmask_b32_e32 v1, 3, v227, vcc_lo                      // 00000019CCA0: 0203C683
	.long 0xd73c00dd                                           // 00000019CCA4: D73C00DD
	v_cndmask_b32_e32 v1, 3, v221, vcc_lo                      // 00000019CCA8: 0203BA83
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019CCAC: BF8700A3
	.long 0xd73c00df                                           // 00000019CCB0: D73C00DF
	v_cndmask_b32_e32 v1, 3, v223, vcc_lo                      // 00000019CCB4: 0203BE83
	.long 0xd7006ae5                                           // 00000019CCB8: D7006AE5
	v_cndmask_b32_e32 v1, s8, v225, vcc_lo                     // 00000019CCBC: 0203C208
	v_add_co_ci_u32_e64 v230, null, s9, v226, vcc_lo           // 00000019CCC0: D5207CE6 01ABC409
	.long 0xd7006ae7                                           // 00000019CCC8: D7006AE7
	v_cndmask_b32_e32 v1, s8, v227, vcc_lo                     // 00000019CCCC: 0203C608
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019CCD0: BF8700A1
	v_add_co_ci_u32_e64 v232, null, s9, v228, vcc_lo           // 00000019CCD4: D5207CE8 01ABC809
	.long 0xd7006ae9                                           // 00000019CCDC: D7006AE9
	v_cndmask_b32_e32 v1, s8, v221, vcc_lo                     // 00000019CCE0: 0203BA08
	v_add_co_ci_u32_e64 v234, null, s9, v222, vcc_lo           // 00000019CCE4: D5207CEA 01ABBC09
	.long 0xd7006aeb                                           // 00000019CCEC: D7006AEB
	v_cndmask_b32_e32 v1, s8, v223, vcc_lo                     // 00000019CCF0: 0203BE08
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019CCF4: BF870001
	v_add_co_ci_u32_e64 v236, null, s9, v224, vcc_lo           // 00000019CCF8: D5207CEC 01ABC009
	v_cmp_gt_i32_e32 vcc_lo, s1, v73                           // 00000019CD00: 7C889201
	s_add_i32 s1, s1, -16                                      // 00000019CD04: 8101D001
	s_cmp_lg_u32 s0, 0                                         // 00000019CD08: BF078000
	s_waitcnt vmcnt(14)                                        // 00000019CD0C: BF893BF7
	v_wmma_f32_16x16x16_bf16 v[221:228], v[93:100], v[157:164], v[65:72]// 00000019CD10: CC4140DD 1D073B5D
	s_waitcnt vmcnt(12)                                        // 00000019CD18: BF8933F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019CD1C: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[221:228], v[101:108], v[165:172], v[221:228]// 00000019CD20: CC4140DD 1F774B65
	s_waitcnt vmcnt(10)                                        // 00000019CD28: BF892BF7
	v_wmma_f32_16x16x16_bf16 v[221:228], v[109:116], v[173:180], v[221:228]// 00000019CD2C: CC4140DD 1F775B6D
	s_waitcnt vmcnt(8)                                         // 00000019CD34: BF8923F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019CD38: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[221:228], v[117:124], v[181:188], v[221:228]// 00000019CD3C: CC4140DD 1F776B75
	s_waitcnt vmcnt(6)                                         // 00000019CD44: BF891BF7
	v_wmma_f32_16x16x16_bf16 v[221:228], v[125:132], v[189:196], v[221:228]// 00000019CD48: CC4140DD 1F777B7D
	s_waitcnt vmcnt(4)                                         // 00000019CD50: BF8913F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019CD54: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[221:228], v[133:140], v[197:204], v[221:228]// 00000019CD58: CC4140DD 1F778B85
	s_waitcnt vmcnt(2)                                         // 00000019CD60: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[221:228], v[141:148], v[205:212], v[221:228]// 00000019CD64: CC4140DD 1F779B8D
	s_waitcnt vmcnt(0)                                         // 00000019CD6C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019CD70: BF870001
	v_wmma_f32_16x16x16_bf16 v[221:228], v[149:156], v[213:220], v[221:228]// 00000019CD74: CC4140DD 1F77AB95
	ds_store_2addr_b32 v83, v221, v222 offset1:32              // 00000019CD7C: D8382000 00DEDD53
	ds_store_2addr_b32 v83, v223, v224 offset0:64 offset1:96   // 00000019CD84: D8386040 00E0DF53
	ds_store_2addr_b32 v83, v225, v226 offset0:128 offset1:160 // 00000019CD8C: D838A080 00E2E153
	ds_store_2addr_b32 v83, v227, v228 offset0:192 offset1:224 // 00000019CD94: D838E0C0 00E4E353
	s_waitcnt lgkmcnt(0)                                       // 00000019CD9C: BF89FC07
	s_barrier                                                  // 00000019CDA0: BFBD0000
	buffer_gl0_inv                                             // 00000019CDA4: E0AC0000 00000000
	ds_load_2addr_b32 v[93:94], v84 offset1:32                 // 00000019CDAC: D8DC2000 5D000054
	ds_load_2addr_b32 v[95:96], v84 offset0:64 offset1:96      // 00000019CDB4: D8DC6040 5F000054
	ds_load_2addr_b32 v[97:98], v84 offset0:128 offset1:160    // 00000019CDBC: D8DCA080 61000054
	ds_load_2addr_b32 v[99:100], v84 offset0:192 offset1:224   // 00000019CDC4: D8DCE0C0 63000054
	s_waitcnt lgkmcnt(3)                                       // 00000019CDCC: BF89FC37
	v_dual_add_f32 v93, v221, v93 :: v_dual_add_f32 v94, v222, v94// 00000019CDD0: C908BBDD 5D5EBDDE
	s_waitcnt lgkmcnt(2)                                       // 00000019CDD8: BF89FC27
	v_dual_add_f32 v95, v223, v95 :: v_dual_add_f32 v96, v224, v96// 00000019CDDC: C908BFDF 5F60C1E0
	s_waitcnt lgkmcnt(1)                                       // 00000019CDE4: BF89FC17
	v_dual_add_f32 v97, v225, v97 :: v_dual_add_f32 v98, v226, v98// 00000019CDE8: C908C3E1 6162C5E2
	s_waitcnt lgkmcnt(0)                                       // 00000019CDF0: BF89FC07
	v_dual_add_f32 v99, v227, v99 :: v_dual_add_f32 v100, v228, v100// 00000019CDF4: C908C7E3 6364C9E4
	v_dual_mul_f32 v93, 0x3d800000, v93 :: v_dual_mul_f32 v94, 0x3d800000, v94// 00000019CDFC: C8C6BAFF 5D5EBCFF 3D800000
	v_dual_mul_f32 v95, 0x3d800000, v95 :: v_dual_mul_f32 v96, 0x3d800000, v96// 00000019CE08: C8C6BEFF 5F60C0FF 3D800000
	v_dual_mul_f32 v97, 0x3d800000, v97 :: v_dual_mul_f32 v98, 0x3d800000, v98// 00000019CE14: C8C6C2FF 6162C4FF 3D800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019CE20: BF870214
	v_dual_mul_f32 v99, 0x3d800000, v99 :: v_dual_mul_f32 v100, 0x3d800000, v100// 00000019CE24: C8C6C6FF 6364C8FF 3D800000
	v_dual_cndmask_b32 v165, 0, v93 :: v_dual_cndmask_b32 v166, 0, v94// 00000019CE30: CA52BA80 A5A6BC80
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019CE38: BF870214
	v_dual_cndmask_b32 v167, 0, v95 :: v_dual_cndmask_b32 v168, 0, v96// 00000019CE3C: CA52BE80 A7A8C080
	v_dual_cndmask_b32 v169, 0, v97 :: v_dual_cndmask_b32 v170, 0, v98// 00000019CE44: CA52C280 A9AAC480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019CE4C: BF870214
	v_dual_cndmask_b32 v171, 0, v99 :: v_dual_cndmask_b32 v172, 0, v100// 00000019CE50: CA52C680 ABACC880
	v_add_f32_e32 v79, v79, v166                               // 00000019CE58: 069F4D4F
	v_bfe_u32 v93, v165, 16, 1                                 // 00000019CE5C: D610005D 020521A5
	v_bfe_u32 v94, v166, 16, 1                                 // 00000019CE64: D610005E 020521A6
	v_bfe_u32 v95, v167, 16, 1                                 // 00000019CE6C: D610005F 020521A7
	v_bfe_u32 v96, v168, 16, 1                                 // 00000019CE74: D6100060 020521A8
	v_bfe_u32 v97, v169, 16, 1                                 // 00000019CE7C: D6100061 020521A9
	v_bfe_u32 v98, v170, 16, 1                                 // 00000019CE84: D6100062 020521AA
	v_bfe_u32 v99, v171, 16, 1                                 // 00000019CE8C: D6100063 020521AB
	v_bfe_u32 v100, v172, 16, 1                                // 00000019CE94: D6100064 020521AC
	v_add3_u32 v93, v165, v93, 0x7fff                          // 00000019CE9C: D655005D 03FEBBA5 00007FFF
	v_add3_u32 v94, v166, v94, 0x7fff                          // 00000019CEA8: D655005E 03FEBDA6 00007FFF
	v_add3_u32 v95, v167, v95, 0x7fff                          // 00000019CEB4: D655005F 03FEBFA7 00007FFF
	v_add3_u32 v96, v168, v96, 0x7fff                          // 00000019CEC0: D6550060 03FEC1A8 00007FFF
	v_add3_u32 v97, v169, v97, 0x7fff                          // 00000019CECC: D6550061 03FEC3A9 00007FFF
	v_add3_u32 v98, v170, v98, 0x7fff                          // 00000019CED8: D6550062 03FEC5AA 00007FFF
	v_add3_u32 v99, v171, v99, 0x7fff                          // 00000019CEE4: D6550063 03FEC7AB 00007FFF
	v_add3_u32 v100, v172, v100, 0x7fff                        // 00000019CEF0: D6550064 03FEC9AC 00007FFF
	ds_store_b16_d16_hi v85, v93                               // 00000019CEFC: DA840000 00005D55
	ds_store_b16_d16_hi v85, v94 offset:64                     // 00000019CF04: DA840040 00005E55
	ds_store_b16_d16_hi v85, v95 offset:128                    // 00000019CF0C: DA840080 00005F55
	ds_store_b16_d16_hi v85, v96 offset:192                    // 00000019CF14: DA8400C0 00006055
	ds_store_b16_d16_hi v85, v97 offset:256                    // 00000019CF1C: DA840100 00006155
	ds_store_b16_d16_hi v85, v98 offset:320                    // 00000019CF24: DA840140 00006255
	ds_store_b16_d16_hi v85, v99 offset:384                    // 00000019CF2C: DA840180 00006355
	ds_store_b16_d16_hi v85, v100 offset:448                   // 00000019CF34: DA8401C0 00006455
	ds_load_b128 v[93:96], v86                                 // 00000019CF3C: DBFC0000 5D000056
	ds_load_b128 v[97:100], v86 offset:16                      // 00000019CF44: DBFC0010 61000056
	s_clause 0x1f                                              // 00000019CF4C: BF85001F
	global_load_b64 v[101:102], v[229:230], off                // 00000019CF50: DC560000 657C00E5
	global_load_b64 v[109:110], v[229:230], off offset:128     // 00000019CF58: DC560080 6D7C00E5
	global_load_b64 v[117:118], v[229:230], off offset:256     // 00000019CF60: DC560100 757C00E5
	global_load_b64 v[125:126], v[229:230], off offset:384     // 00000019CF68: DC560180 7D7C00E5
	global_load_b64 v[103:104], v[231:232], off                // 00000019CF70: DC560000 677C00E7
	global_load_b64 v[111:112], v[231:232], off offset:128     // 00000019CF78: DC560080 6F7C00E7
	global_load_b64 v[119:120], v[231:232], off offset:256     // 00000019CF80: DC560100 777C00E7
	global_load_b64 v[127:128], v[231:232], off offset:384     // 00000019CF88: DC560180 7F7C00E7
	global_load_b64 v[105:106], v[233:234], off                // 00000019CF90: DC560000 697C00E9
	global_load_b64 v[113:114], v[233:234], off offset:128     // 00000019CF98: DC560080 717C00E9
	global_load_b64 v[121:122], v[233:234], off offset:256     // 00000019CFA0: DC560100 797C00E9
	global_load_b64 v[129:130], v[233:234], off offset:384     // 00000019CFA8: DC560180 817C00E9
	global_load_b64 v[107:108], v[235:236], off                // 00000019CFB0: DC560000 6B7C00EB
	global_load_b64 v[115:116], v[235:236], off offset:128     // 00000019CFB8: DC560080 737C00EB
	global_load_b64 v[123:124], v[235:236], off offset:256     // 00000019CFC0: DC560100 7B7C00EB
	global_load_b64 v[131:132], v[235:236], off offset:384     // 00000019CFC8: DC560180 837C00EB
	global_load_b64 v[133:134], v[229:230], off offset:512     // 00000019CFD0: DC560200 857C00E5
	global_load_b64 v[141:142], v[229:230], off offset:640     // 00000019CFD8: DC560280 8D7C00E5
	global_load_b64 v[149:150], v[229:230], off offset:768     // 00000019CFE0: DC560300 957C00E5
	global_load_b64 v[157:158], v[229:230], off offset:896     // 00000019CFE8: DC560380 9D7C00E5
	global_load_b64 v[135:136], v[231:232], off offset:512     // 00000019CFF0: DC560200 877C00E7
	global_load_b64 v[143:144], v[231:232], off offset:640     // 00000019CFF8: DC560280 8F7C00E7
	global_load_b64 v[151:152], v[231:232], off offset:768     // 00000019D000: DC560300 977C00E7
	global_load_b64 v[159:160], v[231:232], off offset:896     // 00000019D008: DC560380 9F7C00E7
	global_load_b64 v[137:138], v[233:234], off offset:512     // 00000019D010: DC560200 897C00E9
	global_load_b64 v[145:146], v[233:234], off offset:640     // 00000019D018: DC560280 917C00E9
	global_load_b64 v[153:154], v[233:234], off offset:768     // 00000019D020: DC560300 997C00E9
	global_load_b64 v[161:162], v[233:234], off offset:896     // 00000019D028: DC560380 A17C00E9
	global_load_b64 v[139:140], v[235:236], off offset:512     // 00000019D030: DC560200 8B7C00EB
	global_load_b64 v[147:148], v[235:236], off offset:640     // 00000019D038: DC560280 937C00EB
	global_load_b64 v[155:156], v[235:236], off offset:768     // 00000019D040: DC560300 9B7C00EB
	global_load_b64 v[163:164], v[235:236], off offset:896     // 00000019D048: DC560380 A37C00EB
	v_dual_add_f32 v74, v74, v165 :: v_dual_add_f32 v77, v77, v167// 00000019D050: C9094B4A 4A4D4F4D
	v_dual_add_f32 v78, v78, v168 :: v_dual_add_f32 v75, v75, v169// 00000019D058: C909514E 4E4B534B
	v_dual_add_f32 v76, v76, v170 :: v_dual_add_f32 v91, v91, v171// 00000019D060: C909554C 4C5B575B
	v_add_f32_e32 v92, v92, v172                               // 00000019D068: 06B9595C
	s_waitcnt vmcnt(19) lgkmcnt(0)                             // 00000019D06C: BF894C07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[93:100], v[101:108], v[57:64]// 00000019D070: CC414039 1CE6CB5D
	s_waitcnt vmcnt(18)                                        // 00000019D078: BF894BF7
	v_wmma_f32_16x16x16_bf16 v[49:56], v[93:100], v[109:116], v[49:56]// 00000019D07C: CC414031 1CC6DB5D
	s_waitcnt vmcnt(17)                                        // 00000019D084: BF8947F7
	v_wmma_f32_16x16x16_bf16 v[41:48], v[93:100], v[117:124], v[41:48]// 00000019D088: CC414029 1CA6EB5D
	s_waitcnt vmcnt(16)                                        // 00000019D090: BF8943F7
	v_wmma_f32_16x16x16_bf16 v[33:40], v[93:100], v[125:132], v[33:40]// 00000019D094: CC414021 1C86FB5D
	s_waitcnt vmcnt(3)                                         // 00000019D09C: BF890FF7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[93:100], v[133:140], v[25:32]// 00000019D0A0: CC414019 1C670B5D
	s_waitcnt vmcnt(2)                                         // 00000019D0A8: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[17:24], v[93:100], v[141:148], v[17:24]// 00000019D0AC: CC414011 1C471B5D
	s_waitcnt vmcnt(1)                                         // 00000019D0B4: BF8907F7
	v_wmma_f32_16x16x16_bf16 v[9:16], v[93:100], v[149:156], v[9:16]// 00000019D0B8: CC414009 1C272B5D
	s_waitcnt vmcnt(0)                                         // 00000019D0C0: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[1:8], v[93:100], v[157:164], v[1:8]// 00000019D0C4: CC414001 1C073B5D
	s_barrier                                                  // 00000019D0CC: BFBD0000
	buffer_gl0_inv                                             // 00000019D0D0: E0AC0000 00000000
	s_cbranch_scc1 65145                                       // 00000019D0D8: BFA2FE79 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi4ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x5c0>
	v_mov_b32_e32 v8, v81                                      // 00000019D0DC: 7E100351
	s_mul_i32 s0, s20, 12                                      // 00000019D0E0: 96008C14
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019D0E4: BF870001
	v_or_b32_e32 v7, v8, v73                                   // 00000019D0E8: 380E9308
	v_or_b32_e32 v0, s0, v80                                   // 00000019D0EC: 3800A000
	v_mov_b32_dpp v83, v78 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D0F0: 7EA602FA FF09614E
	v_mov_b32_dpp v81, v77 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D0F8: 7EA202FA FF09614D
	v_mov_b32_dpp v85, v76 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D100: 7EAA02FA FF09614C
	v_mov_b32_dpp v84, v75 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D108: 7EA802FA FF09614B
	v_lshlrev_b32_e32 v0, 8, v0                                // 00000019D110: 30000088
	v_mov_b32_e32 v8, 0                                        // 00000019D114: 7E100280
	v_dual_add_f32 v78, v78, v83 :: v_dual_add_f32 v81, v77, v81// 00000019D118: C908A74E 4E50A34D
	v_add_f32_e32 v83, v76, v85                                // 00000019D120: 06A6AB4C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019D124: BF870214
	v_add_nc_u32_e32 v23, 0x400, v0                            // 00000019D128: 4A2E00FF 00000400
	v_mad_i64_i32 v[7:8], null, 0x1800, s2, v[7:8]             // 00000019D130: D6FF7C07 041C04FF 00001800
	v_ashrrev_i32_e32 v16, 31, v0                              // 00000019D13C: 3420009F
	v_add_nc_u32_e32 v31, 0x600, v0                            // 00000019D140: 4A3E00FF 00000600
	v_add_nc_u32_e32 v39, 0x800, v0                            // 00000019D148: 4A4E00FF 00000800
	v_ashrrev_i32_e32 v24, 31, v23                             // 00000019D150: 34302E9F
	v_or_b32_e32 v65, 0x200, v0                                // 00000019D154: 388200FF 00000200
	v_add_f32_dpp v78, v78, v78 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D15C: 069C9CFA FF09624E
	v_ashrrev_i32_e32 v32, 31, v31                             // 00000019D164: 34403E9F
	.long 0xd7006a0f                                           // 00000019D168: D7006A0F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 00000019D16C: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019D170: BF8700A1
	v_add_co_ci_u32_e64 v16, null, v8, v16, vcc_lo             // 00000019D174: D5207C10 01AA2108
	.long 0xd7006a17                                           // 00000019D17C: D7006A17
	v_cndmask_b32_e32 v1, v7, v23, vcc_lo                      // 00000019D180: 02022F07
	v_add_co_ci_u32_e64 v24, null, v8, v24, vcc_lo             // 00000019D184: D5207C18 01AA3108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000019D18C: BF870233
	.long 0xd73c000f                                           // 00000019D190: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 00000019D194: 02021E81
	v_add_nc_u32_e32 v0, 0xa00, v0                             // 00000019D198: 4A0000FF 00000A00
	v_ashrrev_i32_e32 v40, 31, v39                             // 00000019D1A0: 34504E9F
	.long 0xd73c0017                                           // 00000019D1A4: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 00000019D1A8: 02022E81
	v_ashrrev_i32_e32 v66, 31, v65                             // 00000019D1AC: 3484829F
	v_add_f32_dpp v78, v78, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D1B0: 069C9CFA FF09644E
	.long 0xd7006a45                                           // 00000019D1B8: D7006A45
	v_cndmask_b32_e32 v1, s10, v15, vcc_lo                     // 00000019D1BC: 02021E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019D1C0: BF8700A1
	v_add_co_ci_u32_e64 v70, null, s11, v16, vcc_lo            // 00000019D1C4: D5207C46 01AA200B
	.long 0xd7006a1f                                           // 00000019D1CC: D7006A1F
	v_cndmask_b32_e32 v1, v7, v31, vcc_lo                      // 00000019D1D0: 02023F07
	v_add_co_ci_u32_e64 v32, null, v8, v32, vcc_lo             // 00000019D1D4: D5207C20 01AA4108
	.long 0xd7006a37                                           // 00000019D1DC: D7006A37
	v_cndmask_b32_e32 v1, s10, v23, vcc_lo                     // 00000019D1E0: 02022E0A
	v_ashrrev_i32_e32 v48, 31, v0                              // 00000019D1E4: 3460009F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000019D1E8: BF8700B3
	.long 0xd73c001f                                           // 00000019D1EC: D73C001F
	v_cndmask_b32_e32 v1, 1, v31, vcc_lo                       // 00000019D1F0: 02023E81
	v_add_co_ci_u32_e64 v56, null, s11, v24, vcc_lo            // 00000019D1F4: D5207C38 01AA300B
	.long 0xd7006a27                                           // 00000019D1FC: D7006A27
	v_cndmask_b32_e32 v1, v7, v39, vcc_lo                      // 00000019D200: 02024F07
	v_add_co_ci_u32_e64 v40, null, v8, v40, vcc_lo             // 00000019D204: D5207C28 01AA5108
	.long 0xd7006a2f                                           // 00000019D20C: D7006A2F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 00000019D210: 02020107
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019D214: BF870001
	v_add_co_ci_u32_e64 v48, null, v8, v48, vcc_lo             // 00000019D218: D5207C30 01AA6108
	.long 0xd7006a3f                                           // 00000019D220: D7006A3F
	v_cndmask_b32_e32 v1, s10, v31, vcc_lo                     // 00000019D224: 02023E0A
	global_load_u16 v73, v[69:70], off offset:1024             // 00000019D228: DC4A0400 497C0045
	v_add_co_ci_u32_e64 v64, null, s11, v32, vcc_lo            // 00000019D230: D5207C40 01AA400B
	.long 0xd7006a07                                           // 00000019D238: D7006A07
	v_cndmask_b32_e32 v1, v7, v65, vcc_lo                      // 00000019D23C: 02028307
	s_clause 0x2                                               // 00000019D240: BF850002
	global_load_u16 v80, v[69:70], off                         // 00000019D244: DC4A0000 507C0045
	global_load_u16 v82, v[69:70], off offset:32               // 00000019D24C: DC4A0020 527C0045
	global_load_u16 v103, v[69:70], off offset:64              // 00000019D254: DC4A0040 677C0045
	v_add_co_ci_u32_e64 v8, null, v8, v66, vcc_lo              // 00000019D25C: D5207C08 01AA8508
	.long 0xd73c0027                                           // 00000019D264: D73C0027
	v_cndmask_b32_e32 v1, 1, v39, vcc_lo                       // 00000019D268: 02024E81
	.long 0xd73c002f                                           // 00000019D26C: D73C002F
	v_cndmask_b32_e32 v1, 1, v47, vcc_lo                       // 00000019D270: 02025E81
	v_add_f32_dpp v88, v78, v78 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D274: 06B09CFA FF09684E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000019D27C: BF8700C4
	.long 0xd73c0056                                           // 00000019D280: D73C0056
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000019D284: 02020E81
	v_mov_b32_dpp v8, v79 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D288: 7E1002FA FF09614F
	v_mov_b32_dpp v7, v74 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D290: 7E0E02FA FF09614A
	.long 0xd7006a43                                           // 00000019D298: D7006A43
	v_cndmask_b32_e32 v1, s10, v39, vcc_lo                     // 00000019D29C: 02024E0A
	v_add_co_ci_u32_e64 v68, null, s11, v40, vcc_lo            // 00000019D2A0: D5207C44 01AA500B
	.long 0xd7006a41                                           // 00000019D2A8: D7006A41
	v_cndmask_b32_e32 v1, s10, v47, vcc_lo                     // 00000019D2AC: 02025E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019D2B0: BF8700A1
	v_add_co_ci_u32_e64 v66, null, s11, v48, vcc_lo            // 00000019D2B4: D5207C42 01AA600B
	.long 0xd7006a47                                           // 00000019D2BC: D7006A47
	v_cndmask_b32_e32 v1, s10, v86, vcc_lo                     // 00000019D2C0: 0202AC0A
	v_add_co_ci_u32_e64 v72, null, s11, v87, vcc_lo            // 00000019D2C4: D5207C48 01AAAE0B
	s_clause 0x9                                               // 00000019D2CC: BF850009
	global_load_u16 v99, v[63:64], off                         // 00000019D2D0: DC4A0000 637C003F
	global_load_u16 v98, v[55:56], off                         // 00000019D2D8: DC4A0000 627C0037
	global_load_u16 v101, v[65:66], off                        // 00000019D2E0: DC4A0000 657C0041
	global_load_u16 v100, v[67:68], off                        // 00000019D2E8: DC4A0000 647C0043
	global_load_u16 v102, v[71:72], off offset:32              // 00000019D2F0: DC4A0020 667C0047
	global_load_u16 v94, v[63:64], off offset:32               // 00000019D2F8: DC4A0020 5E7C003F
	global_load_u16 v93, v[55:56], off offset:32               // 00000019D300: DC4A0020 5D7C0037
	global_load_u16 v96, v[65:66], off offset:32               // 00000019D308: DC4A0020 607C0041
	global_load_u16 v95, v[67:68], off offset:32               // 00000019D310: DC4A0020 5F7C0043
	global_load_u16 v97, v[71:72], off offset:64               // 00000019D318: DC4A0040 617C0047
	v_dual_add_f32 v8, v79, v8 :: v_dual_add_f32 v7, v74, v7   // 00000019D320: C908114F 08060F4A
	v_add_f32_dpp v81, v81, v81 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D328: 06A2A2FA FF096251
	v_add_f32_dpp v83, v83, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D330: 06A6A6FA FF096253
	v_div_scale_f32 v110, null, v88, v88, 1.0                  // 00000019D338: D6FC7C6E 03CAB158
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019D340: BF870004
	v_add_f32_dpp v8, v8, v8 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D344: 061010FA FF096208
	v_add_f32_dpp v7, v7, v7 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D34C: 060E0EFA FF096207
	v_add_f32_dpp v81, v81, v81 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D354: 06A2A2FA FF096451
	v_add_f32_dpp v83, v83, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D35C: 06A6A6FA FF096453
	v_rcp_f32_e32 v90, v110                                    // 00000019D364: 7EB4556E
	v_add_f32_dpp v8, v8, v8 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D368: 061010FA FF096408
	v_add_f32_dpp v7, v7, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D370: 060E0EFA FF096407
	v_add_f32_dpp v89, v81, v81 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D378: 06B2A2FA FF096851
	v_add_f32_dpp v81, v83, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D380: 06A2A6FA FF096853
	v_div_scale_f32 v113, s3, 1.0, v88, 1.0                    // 00000019D388: D6FC0371 03CAB0F2
	v_add_f32_dpp v107, v8, v8 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D390: 06D610FA FF096808
	v_add_f32_dpp v108, v7, v7 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D398: 06D80EFA FF096807
	.long 0xd7000507                                           // 00000019D3A0: D7000507
	v_cndmask_b32_e32 v1, s12, v15, vcc_lo                     // 00000019D3A4: 02021E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019D3A8: BF870211
	v_add_co_ci_u32_e64 v8, null, s13, v16, s5                 // 00000019D3AC: D5207C08 0016200D
	v_div_scale_f32 v118, null, v107, v107, 1.0                // 00000019D3B4: D6FC7C76 03CAD76B
	.long 0xd700050f                                           // 00000019D3BC: D700050F
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 00000019D3C0: 02022E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019D3C4: BF870191
	v_add_co_ci_u32_e64 v16, null, s13, v24, s5                // 00000019D3C8: D5207C10 0016300D
	v_rcp_f32_e32 v121, v118                                   // 00000019D3D0: 7EF25576
	.long 0xd7000517                                           // 00000019D3D4: D7000517
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 00000019D3D8: 02023E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019D3DC: BF8700A1
	v_add_co_ci_u32_e64 v24, null, s13, v32, s5                // 00000019D3E0: D5207C18 0016400D
	.long 0xd700051f                                           // 00000019D3E8: D700051F
	v_cndmask_b32_e32 v1, s12, v39, vcc_lo                     // 00000019D3EC: 02024E0C
	v_add_co_ci_u32_e64 v32, null, s13, v40, s5                // 00000019D3F0: D5207C20 0016500D
	.long 0xd7000527                                           // 00000019D3F8: D7000527
	v_cndmask_b32_e32 v1, s12, v47, vcc_lo                     // 00000019D3FC: 02025E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019D400: BF8700A1
	v_add_co_ci_u32_e64 v40, null, s13, v48, s5                // 00000019D404: D5207C28 0016600D
	.long 0xd700052f                                           // 00000019D40C: D700052F
	v_cndmask_b32_e32 v1, s12, v86, vcc_lo                     // 00000019D410: 0202AC0C
	v_add_co_ci_u32_e64 v48, null, s13, v87, s5                // 00000019D414: D5207C30 0016AE0D
	s_clause 0x1f                                              // 00000019D41C: BF85001F
	global_load_u16 v78, v[69:70], off offset:96               // 00000019D420: DC4A0060 4E7C0045
	global_load_u16 v86, v[69:70], off offset:128              // 00000019D428: DC4A0080 567C0045
	global_load_u16 v87, v[69:70], off offset:160              // 00000019D430: DC4A00A0 577C0045
	global_load_u16 v92, v[69:70], off offset:192              // 00000019D438: DC4A00C0 5C7C0045
	global_load_u16 v69, v[69:70], off offset:224              // 00000019D440: DC4A00E0 457C0045
	global_load_u16 v138, v[55:56], off offset:64              // 00000019D448: DC4A0040 8A7C0037
	global_load_u16 v133, v[55:56], off offset:96              // 00000019D450: DC4A0060 857C0037
	global_load_u16 v128, v[55:56], off offset:128             // 00000019D458: DC4A0080 807C0037
	global_load_u16 v124, v[55:56], off offset:160             // 00000019D460: DC4A00A0 7C7C0037
	global_load_u16 v104, v[55:56], off offset:192             // 00000019D468: DC4A00C0 687C0037
	global_load_u16 v137, v[63:64], off offset:64              // 00000019D470: DC4A0040 897C003F
	global_load_u16 v132, v[63:64], off offset:96              // 00000019D478: DC4A0060 847C003F
	global_load_u16 v127, v[63:64], off offset:128             // 00000019D480: DC4A0080 7F7C003F
	global_load_u16 v123, v[63:64], off offset:160             // 00000019D488: DC4A00A0 7B7C003F
	global_load_u16 v70, v[63:64], off offset:192              // 00000019D490: DC4A00C0 467C003F
	global_load_u16 v56, v[55:56], off offset:224              // 00000019D498: DC4A00E0 387C0037
	global_load_u16 v140, v[67:68], off offset:64              // 00000019D4A0: DC4A0040 8C7C0043
	global_load_u16 v135, v[67:68], off offset:96              // 00000019D4A8: DC4A0060 877C0043
	global_load_u16 v130, v[67:68], off offset:128             // 00000019D4B0: DC4A0080 827C0043
	global_load_u16 v126, v[67:68], off offset:160             // 00000019D4B8: DC4A00A0 7E7C0043
	global_load_u16 v106, v[67:68], off offset:192             // 00000019D4C0: DC4A00C0 6A7C0043
	global_load_u16 v55, v[63:64], off offset:224              // 00000019D4C8: DC4A00E0 377C003F
	global_load_u16 v139, v[65:66], off offset:64              // 00000019D4D0: DC4A0040 8B7C0041
	global_load_u16 v134, v[65:66], off offset:96              // 00000019D4D8: DC4A0060 867C0041
	global_load_u16 v129, v[65:66], off offset:128             // 00000019D4E0: DC4A0080 817C0041
	global_load_u16 v125, v[65:66], off offset:160             // 00000019D4E8: DC4A00A0 7D7C0041
	global_load_u16 v105, v[65:66], off offset:192             // 00000019D4F0: DC4A00C0 697C0041
	global_load_u16 v63, v[67:68], off offset:224              // 00000019D4F8: DC4A00E0 3F7C0043
	global_load_u16 v141, v[71:72], off offset:96              // 00000019D500: DC4A0060 8D7C0047
	global_load_u16 v136, v[71:72], off offset:128             // 00000019D508: DC4A0080 887C0047
	global_load_u16 v131, v[71:72], off offset:160             // 00000019D510: DC4A00A0 837C0047
	global_load_u16 v68, v[71:72], off offset:192              // 00000019D518: DC4A00C0 447C0047
	s_clause 0x1                                               // 00000019D520: BF850001
	global_load_u16 v67, v[71:72], off offset:224              // 00000019D524: DC4A00E0 437C0047
	global_load_u16 v64, v[65:66], off offset:224              // 00000019D52C: DC4A00E0 407C0041
	v_fma_f32 v66, -v118, v121, 1.0                            // 00000019D534: D6130042 23CAF376
	v_add_f32_e32 v84, v75, v84                                // 00000019D53C: 06A8A94B
	v_div_scale_f32 v117, null, v108, v108, 1.0                // 00000019D540: D6FC7C75 03CAD96C
	v_div_scale_f32 v119, vcc_lo, 1.0, v108, 1.0               // 00000019D548: D6FC6A77 03CAD8F2
	v_div_scale_f32 v120, s4, 1.0, v107, 1.0                   // 00000019D550: D6FC0478 03CAD6F2
	v_fmac_f32_e32 v121, v66, v121                             // 00000019D558: 56F2F342
	v_add_f32_dpp v84, v84, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D55C: 06A8A8FA FF096254
	v_rcp_f32_e32 v122, v117                                   // 00000019D564: 7EF45575
	v_div_scale_f32 v109, null, v89, v89, 1.0                  // 00000019D568: D6FC7C6D 03CAB359
	v_div_scale_f32 v115, null, v81, v81, 1.0                  // 00000019D570: D6FC7C73 03CAA351
	v_mul_f32_e32 v66, v120, v121                              // 00000019D578: 1084F378
	v_add_f32_dpp v84, v84, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D57C: 06A8A8FA FF096454
	v_div_scale_f32 v112, s2, 1.0, v89, 1.0                    // 00000019D584: D6FC0270 03CAB2F2
	v_rcp_f32_e32 v91, v109                                    // 00000019D58C: 7EB6556D
	v_div_scale_f32 v116, s1, 1.0, v81, 1.0                    // 00000019D590: D6FC0174 03CAA2F2
	v_fma_f32 v145, -v118, v66, v120                           // 00000019D598: D6130091 25E28576
	v_add_f32_dpp v83, v84, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000019D5A0: 06A6A8FA FF096854
	v_fma_f32 v65, -v117, v122, 1.0                            // 00000019D5A8: D6130041 23CAF575
	v_rcp_f32_e32 v84, v115                                    // 00000019D5B0: 7EA85573
	v_fma_f32 v72, -v110, v90, 1.0                             // 00000019D5B4: D6130048 23CAB56E
	v_fmac_f32_e32 v66, v145, v121                             // 00000019D5BC: 5684F391
	v_div_scale_f32 v111, null, v83, v83, 1.0                  // 00000019D5C0: D6FC7C6F 03CAA753
	v_fmac_f32_e32 v122, v65, v122                             // 00000019D5C8: 56F4F541
	v_div_scale_f32 v114, s0, 1.0, v83, 1.0                    // 00000019D5CC: D6FC0072 03CAA6F2
	v_fma_f32 v71, -v109, v91, 1.0                             // 00000019D5D4: D6130047 23CAB76D
	v_fma_f32 v118, -v118, v66, v120                           // 00000019D5DC: D6130076 25E28576
	v_rcp_f32_e32 v85, v111                                    // 00000019D5E4: 7EAA556F
	v_mul_f32_e32 v65, v119, v122                              // 00000019D5E8: 1082F577
	v_fma_f32 v143, -v115, v84, 1.0                            // 00000019D5EC: D613008F 23CAA973
	v_dual_fmac_f32 v91, v71, v91 :: v_dual_fmac_f32 v90, v72, v90// 00000019D5F4: C800B747 5B5AB548
	.long 0x7f003880                                           // 00000019D5FC: 7F003880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019D600: BF870194
	v_fma_f32 v144, -v117, v65, v119                           // 00000019D604: D6130090 25DE8375
	v_dual_fmac_f32 v84, v143, v84 :: v_dual_mul_f32 v71, v112, v91// 00000019D60C: C806A98F 5446B770
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019D614: BF870294
	v_mul_f32_e32 v72, v113, v90                               // 00000019D618: 1090B571
	v_fma_f32 v142, -v111, v85, 1.0                            // 00000019D61C: D613008E 23CAAB6F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019D624: BF870214
	v_fmac_f32_e32 v65, v144, v122                             // 00000019D628: 5682F590
	v_mul_f32_e32 v143, v116, v84                              // 00000019D62C: 111EA974
	v_fma_f32 v146, -v109, v71, v112                           // 00000019D630: D6130092 25C28F6D
	v_fma_f32 v147, -v110, v72, v113                           // 00000019D638: D6130093 25C6916E
	v_fmac_f32_e32 v85, v142, v85                              // 00000019D640: 56AAAB8E
	v_fma_f32 v117, -v117, v65, v119                           // 00000019D644: D6130075 25DE8375
	v_fma_f32 v144, -v115, v143, v116                          // 00000019D64C: D6130090 25D31F73
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019D654: BF870214
	v_dual_fmac_f32 v71, v146, v91 :: v_dual_fmac_f32 v72, v147, v90// 00000019D658: C800B792 4748B593
	v_mul_f32_e32 v142, v114, v85                              // 00000019D660: 111CAB72
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019D664: BF8701A4
	v_div_fmas_f32 v65, v117, v122, v65                        // 00000019D668: D6370041 0506F575
	s_mov_b32 vcc_lo, s4                                       // 00000019D670: BEEA0004
	v_fma_f32 v109, -v109, v71, v112                           // 00000019D674: D613006D 25C28F6D
	v_div_fmas_f32 v117, v118, v121, v66                       // 00000019D67C: D6370075 050AF376
	v_fma_f32 v148, -v111, v142, v114                          // 00000019D684: D6130094 25CB1D6F
	v_div_fixup_f32 v66, v65, v108, 1.0                        // 00000019D68C: D6270042 03CAD941
	v_fma_f32 v108, -v110, v72, v113                           // 00000019D694: D613006C 25C6916E
	.long 0x7f9e3980                                           // 00000019D69C: 7F9E3980
	v_div_fixup_f32 v65, v117, v107, 1.0                       // 00000019D6A0: D6270041 03CAD775
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000019D6A8: BF870234
	v_dual_fmac_f32 v142, v148, v85 :: v_dual_mul_f32 v57, v57, v66// 00000019D6AC: C806AB94 8E388539
	v_fmac_f32_e32 v143, v144, v84                             // 00000019D6B4: 571EA990
	.long 0x7f983980                                           // 00000019D6B8: 7F983980
	v_mul_f32_e32 v58, v58, v65                                // 00000019D6BC: 1074833A
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019D6C0: BF870004
	v_fma_f32 v107, -v111, v142, v114                          // 00000019D6C4: D613006B 25CB1D6F
	v_mul_f32_e32 v111, v49, v66                               // 00000019D6CC: 10DE8531
	v_fma_f32 v110, -v115, v143, v116                          // 00000019D6D0: D613006E 25D31F73
	.long 0x7f9a3980                                           // 00000019D6D8: 7F9A3980
	.long 0x7f963980                                           // 00000019D6DC: 7F963980
	.long 0x7f943980                                           // 00000019D6E0: 7F943980
	v_dual_mul_f32 v33, v33, v66 :: v_dual_mul_f32 v26, v26, v65// 00000019D6E4: C8C68521 211A831A
	v_mul_f32_e32 v25, v25, v66                                // 00000019D6EC: 10328519
	v_mul_f32_e32 v17, v17, v66                                // 00000019D6F0: 10228511
	v_mul_f32_e32 v9, v9, v66                                  // 00000019D6F4: 10128509
	v_dual_mul_f32 v1, v1, v66 :: v_dual_mul_f32 v18, v18, v65 // 00000019D6F8: C8C68501 01128312
	v_mul_f32_e32 v42, v42, v65                                // 00000019D700: 1054832A
	v_mul_f32_e32 v34, v34, v65                                // 00000019D704: 10448322
	v_mul_f32_e32 v10, v10, v65                                // 00000019D708: 1014830A
	v_mul_f32_e32 v2, v2, v65                                  // 00000019D70C: 10048302
	s_waitcnt vmcnt(47)                                        // 00000019D710: BF89BFF7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000019D714: 30929290
	s_waitcnt vmcnt(46)                                        // 00000019D718: BF89BBF7
	v_dual_mul_f32 v80, v50, v65 :: v_dual_lshlrev_b32 v49, 16, v80// 00000019D71C: C8E28332 5030A090
	s_waitcnt vmcnt(45)                                        // 00000019D724: BF89B7F7
	v_lshlrev_b32_e32 v50, 16, v82                             // 00000019D728: 3064A490
	s_waitcnt vmcnt(44)                                        // 00000019D72C: BF89B3F7
	v_lshlrev_b32_e32 v82, 16, v103                            // 00000019D730: 30A4CE90
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019D734: BF870001
	v_mul_f32_e32 v114, 0xbfb8aa3b, v82                        // 00000019D738: 10E4A4FF BFB8AA3B
	v_mul_f32_e32 v112, 0xbfb8aa3b, v73                        // 00000019D740: 10E092FF BFB8AA3B
	v_mul_f32_e32 v103, 0xbfb8aa3b, v49                        // 00000019D748: 10CE62FF BFB8AA3B
	v_mul_f32_e32 v113, 0xbfb8aa3b, v50                        // 00000019D750: 10E264FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000019D758: 7C3C62FF 42CE8ED0
	v_rndne_f32_e32 v152, v114                                 // 00000019D760: 7F304772
	v_fma_f32 v117, 0xbfb8aa3b, v73, -v112                     // 00000019D764: D6130075 85C292FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v49, -v103                     // 00000019D770: D6130073 859E62FF BFB8AA3B
	v_rndne_f32_e32 v116, v103                                 // 00000019D77C: 7EE84767
	s_waitcnt vmcnt(40)                                        // 00000019D780: BF89A3F7
	v_lshlrev_b32_e32 v100, 16, v100                           // 00000019D784: 30C8C890
	v_lshlrev_b32_e32 v98, 16, v98                             // 00000019D788: 30C4C490
	v_rndne_f32_e32 v118, v112                                 // 00000019D78C: 7EEC4770
	v_lshlrev_b32_e32 v101, 16, v101                           // 00000019D790: 30CACA90
	v_lshlrev_b32_e32 v99, 16, v99                             // 00000019D794: 30C6C690
	s_waitcnt vmcnt(37)                                        // 00000019D798: BF8997F7
	v_lshlrev_b32_e32 v93, 16, v93                             // 00000019D79C: 30BABA90
	v_dual_mul_f32 v121, 0xbfb8aa3b, v100 :: v_dual_lshlrev_b32 v102, 16, v102// 00000019D7A0: C8E2C8FF 7966CC90 BFB8AA3B
	v_mul_f32_e32 v119, 0xbfb8aa3b, v98                        // 00000019D7AC: 10EEC4FF BFB8AA3B
	v_fma_f32 v151, 0xbfb8aa3b, v82, -v114                     // 00000019D7B4: D6130097 85CAA4FF BFB8AA3B
	v_dual_fmac_f32 v115, 0xb2a5705f, v49 :: v_dual_sub_f32 v112, v112, v118// 00000019D7C0: C80A62FF 7370ED70 B2A5705F
	v_dual_fmac_f32 v117, 0xb2a5705f, v73 :: v_dual_sub_f32 v114, v114, v152// 00000019D7CC: C80A92FF 75733172 B2A5705F
	v_dual_sub_f32 v103, v103, v116 :: v_dual_mul_f32 v122, 0xbfb8aa3b, v101// 00000019D7D8: C946E967 677ACAFF BFB8AA3B
	v_mul_f32_e32 v120, 0xbfb8aa3b, v99                        // 00000019D7E4: 10F0C6FF BFB8AA3B
	v_fma_f32 v145, 0xbfb8aa3b, v50, -v113                     // 00000019D7EC: D6130091 85C664FF BFB8AA3B
	v_rndne_f32_e32 v146, v113                                 // 00000019D7F8: 7F244771
	v_dual_mul_f32 v147, 0xbfb8aa3b, v93 :: v_dual_mul_f32 v144, 0xbfb8aa3b, v102// 00000019D7FC: C8C6BAFF 9390CCFF BFB8AA3B
	v_fma_f32 v154, 0xbfb8aa3b, v98, -v119                     // 00000019D808: D613009A 85DEC4FF BFB8AA3B
	v_dual_add_f32 v112, v112, v117 :: v_dual_add_f32 v103, v103, v115// 00000019D814: C908EB70 7066E767
	v_fma_f32 v156, 0xbfb8aa3b, v99, -v120                     // 00000019D81C: D613009C 85E2C6FF BFB8AA3B
	v_fma_f32 v158, 0xbfb8aa3b, v100, -v121                    // 00000019D828: D613009E 85E6C8FF BFB8AA3B
	v_rndne_f32_e32 v163, v144                                 // 00000019D834: 7F464790
	v_fmac_f32_e32 v145, 0xb2a5705f, v50                       // 00000019D838: 572264FF B2A5705F
	v_sub_f32_e32 v113, v113, v146                             // 00000019D840: 08E32571
	v_fmac_f32_e32 v154, 0xb2a5705f, v98                       // 00000019D844: 5734C4FF B2A5705F
	v_exp_f32_e32 v103, v103                                   // 00000019D84C: 7ECE4B67
	s_waitcnt vmcnt(35)                                        // 00000019D850: BF898FF7
	v_lshlrev_b32_e32 v95, 16, v95                             // 00000019D854: 30BEBE90
	s_waitcnt vmcnt(34)                                        // 00000019D858: BF898BF7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000019D85C: 30C2C290
	v_lshlrev_b32_e32 v96, 16, v96                             // 00000019D860: 30C0C090
	v_cvt_i32_f32_e32 v116, v116                               // 00000019D864: 7EE81174
	v_rndne_f32_e32 v155, v119                                 // 00000019D868: 7F364777
	v_fma_f32 v160, 0xbfb8aa3b, v101, -v122                    // 00000019D86C: D61300A0 85EACAFF BFB8AA3B
	v_rndne_f32_e32 v161, v122                                 // 00000019D878: 7F42477A
	v_fma_f32 v162, 0xbfb8aa3b, v102, -v144                    // 00000019D87C: D61300A2 8642CCFF BFB8AA3B
	v_fmac_f32_e32 v156, 0xb2a5705f, v99                       // 00000019D888: 5738C6FF B2A5705F
	v_fmac_f32_e32 v158, 0xb2a5705f, v100                      // 00000019D890: 573CC8FF B2A5705F
	v_dual_sub_f32 v144, v144, v163 :: v_dual_add_f32 v113, v113, v145// 00000019D898: C9494790 90712371
	v_exp_f32_e32 v112, v112                                   // 00000019D8A0: 7EE04B70
	v_dual_mul_f32 v149, 0xbfb8aa3b, v95 :: v_dual_lshlrev_b32 v94, 16, v94// 00000019D8A4: C8E2BEFF 955EBC90 BFB8AA3B
	v_dual_mul_f32 v153, 0xbfb8aa3b, v97 :: v_dual_mul_f32 v150, 0xbfb8aa3b, v96// 00000019D8B0: C8C6C2FF 9996C0FF BFB8AA3B
	v_cvt_i32_f32_e32 v118, v118                               // 00000019D8BC: 7EEC1176
	v_rndne_f32_e32 v157, v120                                 // 00000019D8C0: 7F3A4778
	v_dual_fmac_f32 v151, 0xb2a5705f, v82 :: v_dual_fmac_f32 v160, 0xb2a5705f, v101// 00000019D8C4: C800A4FF 97A0CAFF B2A5705F
	v_dual_sub_f32 v115, v119, v155 :: v_dual_sub_f32 v122, v122, v161// 00000019D8D0: C94B3777 737B437A
	v_exp_f32_e32 v113, v113                                   // 00000019D8D8: 7EE24B71
	.long 0xd71c0067                                           // 00000019D8DC: D71C0067
	v_cndmask_b32_e32 v1, v103, v116, vcc_lo                   // 00000019D8E0: 0202E967
	v_mul_f32_e32 v148, 0xbfb8aa3b, v94                        // 00000019D8E4: 1128BCFF BFB8AA3B
	v_rndne_f32_e32 v159, v121                                 // 00000019D8EC: 7F3E4779
	v_cvt_i32_f32_e32 v146, v146                               // 00000019D8F0: 7F241192
	v_fma_f32 v164, 0xbfb8aa3b, v93, -v147                     // 00000019D8F4: D61300A4 864EBAFF BFB8AA3B
	v_fma_f32 v168, 0xbfb8aa3b, v95, -v149                     // 00000019D900: D61300A8 8656BEFF BFB8AA3B
	v_fma_f32 v170, 0xbfb8aa3b, v96, -v150                     // 00000019D90C: D61300AA 865AC0FF BFB8AA3B
	v_rndne_f32_e32 v171, v150                                 // 00000019D918: 7F564796
	v_dual_sub_f32 v119, v120, v157 :: v_dual_fmac_f32 v162, 0xb2a5705f, v102// 00000019D91C: C9413B78 77A2CCFF B2A5705F
	v_dual_add_f32 v122, v122, v160 :: v_dual_cndmask_b32 v103, 0, v103// 00000019D928: C913417A 7A66CE80
	.long 0xd71c0070                                           // 00000019D930: D71C0070
	v_cndmask_b32_e32 v1, v112, v118, vcc_lo                   // 00000019D934: 0202ED70
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000019D938: 7C3C92FF 42CE8ED0
	v_rndne_f32_e32 v165, v147                                 // 00000019D940: 7F4A4793
	v_fma_f32 v166, 0xbfb8aa3b, v94, -v148                     // 00000019D944: D61300A6 8652BCFF BFB8AA3B
	v_dual_sub_f32 v121, v121, v159 :: v_dual_fmac_f32 v164, 0xb2a5705f, v93// 00000019D950: C9413F79 79A4BAFF B2A5705F
	v_dual_fmac_f32 v168, 0xb2a5705f, v95 :: v_dual_add_f32 v115, v115, v154// 00000019D95C: C808BEFF A8733573 B2A5705F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000019D968: BF870002
	v_dual_fmac_f32 v170, 0xb2a5705f, v96 :: v_dual_add_f32 v121, v121, v158// 00000019D96C: C808C0FF AA793D79 B2A5705F
	v_dual_sub_f32 v150, v150, v171 :: v_dual_add_f32 v119, v119, v156// 00000019D978: C9495796 96773977
	.long 0xd71c0071                                           // 00000019D980: D71C0071
	v_cndmask_b32_e32 v1, v113, v146, vcc_lo                   // 00000019D984: 02032571
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 00000019D988: 02E0E080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v50                  // 00000019D98C: 7C3C64FF 42CE8ED0
	v_dual_sub_f32 v145, v147, v165 :: v_dual_fmac_f32 v166, 0xb2a5705f, v94// 00000019D994: C9414B93 91A6BCFF B2A5705F
	v_add_f32_e32 v144, v144, v162                             // 00000019D9A0: 07214590
	v_dual_add_f32 v150, v150, v170 :: v_dual_cndmask_b32 v113, 0, v113// 00000019D9A4: C9135596 9670E280
	v_exp_f32_e32 v115, v115                                   // 00000019D9AC: 7EE64B73
	v_exp_f32_e32 v119, v119                                   // 00000019D9B0: 7EEE4B77
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000019D9B4: 7C3662FF C2B17218
	v_cvt_i32_f32_e32 v117, v155                               // 00000019D9BC: 7EEA119B
	v_cvt_i32_f32_e32 v120, v157                               // 00000019D9C0: 7EF0119D
	v_add_f32_e32 v145, v145, v164                             // 00000019D9C4: 07234991
	v_exp_f32_e32 v144, v144                                   // 00000019D9C8: 7F204B90
	v_cndmask_b32_e32 v49, 0x7f800000, v103, vcc_lo            // 00000019D9CC: 0262CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000019D9D4: 7C3692FF C2B17218
	v_cvt_i32_f32_e32 v155, v159                               // 00000019D9DC: 7F36119F
	v_cvt_i32_f32_e32 v159, v163                               // 00000019D9E0: 7F3E11A3
	v_exp_f32_e32 v121, v121                                   // 00000019D9E4: 7EF24B79
	.long 0xd71c0073                                           // 00000019D9E8: D71C0073
	v_cndmask_b32_e32 v1, v115, v117, vcc_lo                   // 00000019D9EC: 0202EB73
	.long 0xd71c0075                                           // 00000019D9F0: D71C0075
	v_cndmask_b32_e32 v1, v119, v120, vcc_lo                   // 00000019D9F4: 0202F177
	v_cndmask_b32_e32 v73, 0x7f800000, v112, vcc_lo            // 00000019D9F8: 0292E0FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v98                  // 00000019DA00: 7C3CC4FF 42CE8ED0
	v_exp_f32_e32 v122, v122                                   // 00000019DA08: 7EF44B7A
	.long 0xd71c0078                                           // 00000019DA0C: D71C0078
	v_cndmask_b32_e32 v1, v144, v159, vcc_lo                   // 00000019DA10: 02033F90
	v_rndne_f32_e32 v167, v148                                 // 00000019DA14: 7F4E4794
	v_cvt_i32_f32_e32 v157, v161                               // 00000019DA18: 7F3A11A1
	v_cndmask_b32_e32 v103, 0, v115, vcc_lo                    // 00000019DA1C: 02CEE680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v99                  // 00000019DA20: 7C3CC6FF 42CE8ED0
	.long 0xd71c0076                                           // 00000019DA28: D71C0076
	v_cndmask_b32_e32 v1, v121, v155, vcc_lo                   // 00000019DA2C: 02033779
	v_rndne_f32_e32 v169, v149                                 // 00000019DA30: 7F524795
	v_sub_f32_e32 v148, v148, v167                             // 00000019DA34: 09294F94
	v_exp_f32_e32 v145, v145                                   // 00000019DA38: 7F224B91
	v_cndmask_b32_e32 v112, 0, v117, vcc_lo                    // 00000019DA3C: 02E0EA80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v100                 // 00000019DA40: 7C3CC8FF 42CE8ED0
	.long 0xd71c0077                                           // 00000019DA48: D71C0077
	v_cndmask_b32_e32 v1, v122, v157, vcc_lo                   // 00000019DA4C: 02033B7A
	v_dual_sub_f32 v149, v149, v169 :: v_dual_add_f32 v148, v148, v166// 00000019DA50: C9495395 95954D94
	v_cvt_i32_f32_e32 v147, v165                               // 00000019DA58: 7F2611A5
	v_cndmask_b32_e32 v115, 0, v118, vcc_lo                    // 00000019DA5C: 02E6EC80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v101                 // 00000019DA60: 7C3CCAFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019DA68: BF870004
	v_add_f32_e32 v149, v149, v168                             // 00000019DA6C: 072B5195
	v_exp_f32_e32 v148, v148                                   // 00000019DA70: 7F284B94
	v_exp_f32_e32 v116, v150                                   // 00000019DA74: 7EE84B96
	v_cvt_i32_f32_e32 v161, v167                               // 00000019DA78: 7F4211A7
	v_cndmask_b32_e32 v117, 0, v119, vcc_lo                    // 00000019DA7C: 02EAEE80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v102                 // 00000019DA80: 7C3CCCFF 42CE8ED0
	v_cvt_i32_f32_e32 v165, v171                               // 00000019DA88: 7F4A11AB
	v_exp_f32_e32 v149, v149                                   // 00000019DA8C: 7F2A4B95
	.long 0xd71c0079                                           // 00000019DA90: D71C0079
	v_cndmask_b32_e32 v1, v145, v147, vcc_lo                   // 00000019DA94: 02032791
	v_cvt_i32_f32_e32 v163, v169                               // 00000019DA98: 7F4611A9
	v_cndmask_b32_e32 v118, 0, v120, vcc_lo                    // 00000019DA9C: 02ECF080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v50                  // 00000019DAA0: 7C3664FF C2B17218
	.long 0xd71c007a                                           // 00000019DAA8: D71C007A
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 00000019DAAC: 02034394
	.long 0xd71c0074                                           // 00000019DAB0: D71C0074
	v_cndmask_b32_e32 v1, v116, v165, vcc_lo                   // 00000019DAB4: 02034B74
	v_add_f32_e32 v120, 1.0, v49                               // 00000019DAB8: 06F062F2
	.long 0xd41b0005                                           // 00000019DABC: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v94, vcc_lo              // 00000019DAC0: 0202BCFF C2B17218
	v_cndmask_b32_e32 v50, 0x7f800000, v113, vcc_lo            // 00000019DAC8: 0264E2FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v93                  // 00000019DAD0: 7C3CBAFF 42CE8ED0
	.long 0xd71c0090                                           // 00000019DAD8: D71C0090
	v_cndmask_b32_e32 v1, v149, v163, vcc_lo                   // 00000019DADC: 02034795
	v_cndmask_b32_e32 v113, 0, v121, vcc_lo                    // 00000019DAE0: 02E2F280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v94                  // 00000019DAE4: 7C3CBCFF 42CE8ED0
	v_div_scale_f32 v121, null, v120, v120, v57                // 00000019DAEC: D6FC7C79 04E6F178
	v_cndmask_b32_e32 v119, 0, v122, vcc_lo                    // 00000019DAF4: 02EEF480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v95                  // 00000019DAF8: 7C3CBEFF 42CE8ED0
	v_cndmask_b32_e32 v49, 0, v144, vcc_lo                     // 00000019DB00: 02632080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 00000019DB04: 7C3CC0FF 42CE8ED0
	v_cndmask_b32_e32 v116, 0, v116, vcc_lo                    // 00000019DB0C: 02E8E880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v98                  // 00000019DB10: 7C36C4FF C2B17218
	v_cndmask_b32_e32 v98, 0x7f800000, v103, vcc_lo            // 00000019DB18: 02C4CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v99                  // 00000019DB20: 7C36C6FF C2B17218
	v_rcp_f32_e32 v103, v121                                   // 00000019DB28: 7ECE5579
	v_cndmask_b32_e64 v94, 0x7f800000, v119, s5                // 00000019DB2C: D501005E 0016EEFF 7F800000
	.long 0xd41b0005                                           // 00000019DB38: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v95, vcc_lo              // 00000019DB3C: 0202BEFF C2B17218
	v_dual_add_f32 v98, 1.0, v98 :: v_dual_cndmask_b32 v99, 0x7f800000, v112// 00000019DB44: C912C4F2 6262E0FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v100                 // 00000019DB50: 7C36C8FF C2B17218
	v_dual_add_f32 v73, 1.0, v73 :: v_dual_cndmask_b32 v100, 0x7f800000, v115// 00000019DB58: C91292F2 4964E6FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019DB64: BF870121
	v_div_scale_f32 v122, null, v73, v73, v58                  // 00000019DB68: D6FC7C7A 04EA9349
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v101                 // 00000019DB70: 7C36CAFF C2B17218
	v_rcp_f32_e32 v112, v122                                   // 00000019DB78: 7EE0557A
	v_cndmask_b32_e32 v101, 0x7f800000, v117, vcc_lo           // 00000019DB7C: 02CAEAFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v102                 // 00000019DB84: 7C36CCFF C2B17218
	v_cndmask_b32_e32 v102, 0x7f800000, v118, vcc_lo           // 00000019DB8C: 02CCECFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v93                  // 00000019DB94: 7C36BAFF C2B17218
	v_div_scale_f32 v118, s4, v58, v73, v58                    // 00000019DB9C: D6FC0476 04EA933A
	v_cndmask_b32_e64 v95, 0x7f800000, v49, s5                 // 00000019DBA4: D501005F 001662FF 7F800000
	.long 0xd41b0005                                           // 00000019DBB0: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v96, vcc_lo              // 00000019DBB4: 0202C0FF C2B17218
	v_dual_add_f32 v102, 1.0, v102 :: v_dual_cndmask_b32 v93, 0x7f800000, v113// 00000019DBBC: C912CCF2 665CE2FF 7F800000
	v_div_scale_f32 v117, vcc_lo, v57, v120, v57               // 00000019DBC8: D6FC6A75 04E6F139
	v_add_f32_e32 v115, 1.0, v50                               // 00000019DBD0: 06E664F2
	v_fma_f32 v50, -v121, v103, 1.0                            // 00000019DBD4: D6130032 23CACF79
	v_fma_f32 v113, -v122, v112, 1.0                           // 00000019DBDC: D6130071 23CAE17A
	v_div_scale_f32 v119, null, v102, v102, v80                // 00000019DBE4: D6FC7C77 0542CD66
	v_cndmask_b32_e64 v96, 0x7f800000, v116, s5                // 00000019DBEC: D5010060 0016E8FF 7F800000
	v_dual_add_f32 v94, 1.0, v94 :: v_dual_add_f32 v95, 1.0, v95// 00000019DBF8: C908BCF2 5E5EBEF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019DC00: BF870214
	v_dual_fmac_f32 v103, v50, v103 :: v_dual_fmac_f32 v112, v113, v112// 00000019DC04: C800CF32 6770E171
	v_rcp_f32_e32 v146, v119                                   // 00000019DC0C: 7F245577
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019DC10: BF870111
	v_mul_f32_e32 v50, v117, v103                              // 00000019DC14: 1064CF75
	v_mul_f32_e32 v144, v118, v112                             // 00000019DC18: 1120E176
	v_div_scale_f32 v113, null, v115, v115, v111               // 00000019DC1C: D6FC7C71 05BEE773
	v_div_scale_f32 v116, s5, v111, v115, v111                 // 00000019DC24: D6FC0574 05BEE76F
	v_add_f32_e32 v93, 1.0, v93                                // 00000019DC2C: 06BABAF2
	v_fma_f32 v49, -v121, v50, v117                            // 00000019DC30: D6130031 25D66579
	v_fma_f32 v147, -v122, v144, v118                          // 00000019DC38: D6130093 25DB217A
	v_rcp_f32_e32 v145, v113                                   // 00000019DC40: 7F225571
	v_add_f32_e32 v99, 1.0, v99                                // 00000019DC44: 06C6C6F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019DC48: BF870193
	v_fmac_f32_e32 v50, v49, v103                              // 00000019DC4C: 5664CF31
	v_fmac_f32_e32 v144, v147, v112                            // 00000019DC50: 5720E193
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019DC54: BF870112
	v_fma_f32 v117, -v121, v50, v117                           // 00000019DC58: D6130075 25D66579
	v_fma_f32 v118, -v122, v144, v118                          // 00000019DC60: D6130076 25DB217A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019DC68: BF870225
	v_fma_f32 v49, -v113, v145, 1.0                            // 00000019DC6C: D6130031 23CB2371
	v_fma_f32 v121, -v119, v146, 1.0                           // 00000019DC74: D6130079 23CB2577
	v_div_fmas_f32 v103, v117, v103, v50                       // 00000019DC7C: D6370067 04CACF75
	s_mov_b32 vcc_lo, s4                                       // 00000019DC84: BEEA0004
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019DC88: BF870003
	v_fmac_f32_e32 v145, v49, v145                             // 00000019DC8C: 57232331
	v_div_fmas_f32 v112, v118, v112, v144                      // 00000019DC90: D6370070 0642E176
	s_mov_b32 vcc_lo, s2                                       // 00000019DC98: BEEA0002
	v_fmac_f32_e32 v146, v121, v146                            // 00000019DC9C: 57252579
	v_div_fmas_f32 v50, v109, v91, v71                         // 00000019DCA0: D6370032 051EB76D
	s_mov_b32 vcc_lo, s3                                       // 00000019DCA8: BEEA0003
	v_div_fixup_f32 v57, v103, v120, v57                       // 00000019DCAC: D6270039 04E6F167
	v_div_fmas_f32 v71, v108, v90, v72                         // 00000019DCB4: D6370047 0522B56C
	v_div_scale_f32 v72, s2, v80, v102, v80                    // 00000019DCBC: D6FC0248 0542CD50
	v_div_fixup_f32 v50, v50, v89, 1.0                         // 00000019DCC4: D6270032 03CAB332
	v_add_f32_e32 v90, 1.0, v100                               // 00000019DCCC: 06B4C8F2
	v_add_f32_e32 v96, 1.0, v96                                // 00000019DCD0: 06C0C0F2
	v_div_fixup_f32 v49, v71, v88, 1.0                         // 00000019DCD4: D6270031 03CAB147
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000019DCDC: BF870244
	v_dual_mul_f32 v88, v116, v145 :: v_dual_mul_f32 v59, v59, v50// 00000019DCE0: C8C72374 583A653B
	v_add_f32_e32 v71, 1.0, v101                               // 00000019DCE8: 068ECAF2
	v_mul_f32_e32 v103, v51, v50                               // 00000019DCEC: 10CE6533
	.long 0x7e9e39b9                                           // 00000019DCF0: 7E9E39B9
	v_fma_f32 v91, -v113, v88, v116                            // 00000019DCF4: D613005B 25D2B171
	v_mul_f32_e32 v89, v72, v146                               // 00000019DCFC: 10B32548
	v_div_scale_f32 v100, null, v98, v98, v59                  // 00000019DD00: D6FC7C64 04EEC562
	v_div_fixup_f32 v58, v112, v73, v58                        // 00000019DD08: D627003A 04EA9370
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019DD10: BF870214
	v_dual_fmac_f32 v88, v91, v145 :: v_dual_and_b32 v79, 1, v79// 00000019DD14: C825235B 584E9E81
	v_fma_f32 v101, -v119, v89, v72                            // 00000019DD1C: D6130065 2522B377
	v_mul_f32_e32 v60, v60, v49                                // 00000019DD24: 1078633C
	v_rcp_f32_e32 v91, v100                                    // 00000019DD28: 7EB65564
	.long 0x7e0039ba                                           // 00000019DD2C: 7E0039BA
	v_fma_f32 v109, -v113, v88, v116                           // 00000019DD30: D613006D 25D2B171
	v_fmac_f32_e32 v89, v101, v146                             // 00000019DD38: 56B32565
	v_div_scale_f32 v108, null, v99, v99, v60                  // 00000019DD3C: D6FC7C6C 04F2C763
	v_mul_f32_e32 v113, v52, v49                               // 00000019DD44: 10E26334
	v_div_scale_f32 v116, vcc_lo, v59, v98, v59                // 00000019DD48: D6FC6A74 04EEC53B
	v_div_scale_f32 v122, s4, v103, v93, v103                  // 00000019DD50: D6FC047A 059EBB67
	v_div_scale_f32 v117, null, v93, v93, v103                 // 00000019DD58: D6FC7C75 059EBB5D
	v_rcp_f32_e32 v101, v108                                   // 00000019DD60: 7ECA556C
	v_fma_f32 v51, -v100, v91, 1.0                             // 00000019DD64: D6130033 23CAB764
	v_fma_f32 v72, -v119, v89, v72                             // 00000019DD6C: D6130048 2522B377
	v_add3_u32 v57, v57, v79, 0x7fff                           // 00000019DD74: D6550039 03FE9F39 00007FFF
	v_rcp_f32_e32 v112, v117                                   // 00000019DD80: 7EE05575
	v_dual_mul_f32 v43, v43, v50 :: v_dual_mul_f32 v44, v44, v49// 00000019DD84: C8C6652B 2B2C632C
	v_dual_mul_f32 v36, v36, v49 :: v_dual_mul_f32 v35, v35, v50// 00000019DD8C: C8C66324 24226523
	v_mul_f32_e32 v28, v28, v49                                // 00000019DD94: 1038631C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000019DD98: BF870246
	v_fma_f32 v52, -v108, v101, 1.0                            // 00000019DD9C: D6130034 23CACB6C
	v_dual_mul_f32 v20, v20, v49 :: v_dual_mul_f32 v27, v27, v50// 00000019DDA4: C8C66314 141A651B
	v_dual_mul_f32 v12, v12, v49 :: v_dual_mul_f32 v19, v19, v50// 00000019DDAC: C8C6630C 0C126513
	v_mul_f32_e32 v4, v4, v49                                  // 00000019DDB4: 10086304
	v_fmac_f32_e32 v101, v52, v101                             // 00000019DDB8: 56CACB34
	v_fmac_f32_e32 v91, v51, v91                               // 00000019DDBC: 56B6B733
	v_div_scale_f32 v51, s3, v60, v99, v60                     // 00000019DDC0: D6FC0333 04F2C73C
	v_mul_f32_e32 v11, v11, v50                                // 00000019DDC8: 1016650B
	v_mul_f32_e32 v3, v3, v50                                  // 00000019DDCC: 10066503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019DDD0: BF870093
	v_mul_f32_e32 v118, v51, v101                              // 00000019DDD4: 10ECCB33
	v_fma_f32 v121, -v108, v118, v51                           // 00000019DDD8: D6130079 24CEED6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019DDE0: BF870121
	v_fmac_f32_e32 v118, v121, v101                            // 00000019DDE4: 56ECCB79
	v_mul_f32_e32 v52, v116, v91                               // 00000019DDE8: 1068B774
	v_fma_f32 v51, -v108, v118, v51                            // 00000019DDEC: D6130033 24CEED6C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019DDF4: BF870092
	v_fma_f32 v120, -v100, v52, v116                           // 00000019DDF8: D6130078 25D26964
	v_fmac_f32_e32 v52, v120, v91                              // 00000019DE00: 5668B778
	v_fma_f32 v120, -v117, v112, 1.0                           // 00000019DE04: D6130078 23CAE175
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019DE0C: BF870092
	v_fma_f32 v100, -v100, v52, v116                           // 00000019DE10: D6130064 25D26964
	v_div_fmas_f32 v91, v100, v91, v52                         // 00000019DE18: D637005B 04D2B764
	s_mov_b32 vcc_lo, s3                                       // 00000019DE20: BEEA0003
	v_div_fmas_f32 v100, v51, v101, v118                       // 00000019DE24: D6370064 05DACB33
	s_mov_b32 vcc_lo, s0                                       // 00000019DE2C: BEEA0000
	s_delay_alu instid0(VALU_DEP_2)                            // 00000019DE30: BF870002
	v_div_fixup_f32 v59, v91, v98, v59                         // 00000019DE34: D627003B 04EEC55B
	v_div_fmas_f32 v51, v107, v85, v142                        // 00000019DE3C: D6370033 063AAB6B
	s_mov_b32 vcc_lo, s1                                       // 00000019DE44: BEEA0001
	v_div_fixup_f32 v60, v100, v99, v60                        // 00000019DE48: D627003C 04F2C764
	v_div_fmas_f32 v84, v110, v84, v143                        // 00000019DE50: D6370054 063EA96E
	v_and_b32_e32 v85, 1, v0                                   // 00000019DE58: 36AA0081
	v_div_fixup_f32 v52, v51, v83, 1.0                         // 00000019DE5C: D6270034 03CAA733
	.long 0x7e9a39bb                                           // 00000019DE64: 7E9A39BB
	.long 0x7e0039bc                                           // 00000019DE68: 7E0039BC
	v_div_fixup_f32 v51, v84, v81, 1.0                         // 00000019DE6C: D6270033 03CAA354
	v_add3_u32 v58, v58, v85, 0x7fff                           // 00000019DE74: D655003A 03FEAB3A 00007FFF
	v_mul_f32_e32 v61, v61, v52                                // 00000019DE80: 107A693D
	s_clause 0x1                                               // 00000019DE84: BF850001
	global_store_d16_hi_b16 v[7:8], v57, off                   // 00000019DE88: DC960000 007C3907
	global_store_d16_hi_b16 v[7:8], v58, off offset:1024       // 00000019DE90: DC960400 007C3A07
	v_mul_f32_e32 v62, v62, v51                                // 00000019DE98: 107C673E
	v_div_scale_f32 v73, null, v94, v94, v113                  // 00000019DE9C: D6FC7C49 05C6BD5E
	v_div_scale_f32 v121, s6, v113, v94, v113                  // 00000019DEA4: D6FC0679 05C6BD71
	v_mul_f32_e32 v54, v54, v51                                // 00000019DEAC: 106C6736
	v_div_scale_f32 v85, null, v90, v90, v61                   // 00000019DEB0: D6FC7C55 04F6B55A
	v_mul_f32_e32 v53, v53, v52                                // 00000019DEB8: 106A6935
	v_rcp_f32_e32 v119, v73                                    // 00000019DEBC: 7EEE5549
	v_div_scale_f32 v99, vcc_lo, v61, v90, v61                 // 00000019DEC0: D6FC6A63 04F6B53D
	v_div_scale_f32 v116, null, v96, v96, v54                  // 00000019DEC8: D6FC7C74 04DAC160
	v_mul_f32_e32 v37, v37, v52                                // 00000019DED0: 104A6925
	v_div_scale_f32 v100, null, v95, v95, v53                  // 00000019DED4: D6FC7C64 04D6BF5F
	v_div_scale_f32 v110, s1, v53, v95, v53                    // 00000019DEDC: D6FC016E 04D6BF35
	v_dual_mul_f32 v22, v22, v51 :: v_dual_mul_f32 v29, v29, v52// 00000019DEE4: C8C66716 161C691D
	v_mul_f32_e32 v14, v14, v51                                // 00000019DEEC: 101C670E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000019DEF0: BF870314
	v_rcp_f32_e32 v107, v100                                   // 00000019DEF4: 7ED65564
	v_fma_f32 v144, -v73, v119, 1.0                            // 00000019DEF8: D6130090 23CAEF49
	v_mul_f32_e32 v21, v21, v52                                // 00000019DF00: 102A6915
	v_mul_f32_e32 v13, v13, v52                                // 00000019DF04: 101A690D
	v_dual_mul_f32 v5, v5, v52 :: v_dual_mul_f32 v6, v6, v51   // 00000019DF08: C8C66905 05066706
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019DF10: BF870094
	v_fmac_f32_e32 v119, v144, v119                            // 00000019DF14: 56EEEF90
	v_dual_fmac_f32 v112, v120, v112 :: v_dual_mul_f32 v81, v121, v119// 00000019DF18: C806E178 7050EF79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019DF20: BF870111
	v_mul_f32_e32 v83, v122, v112                              // 00000019DF24: 10A6E17A
	v_fma_f32 v84, -v73, v81, v121                             // 00000019DF28: D6130054 25E6A349
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019DF30: BF870092
	v_fma_f32 v79, -v117, v83, v122                            // 00000019DF34: D613004F 25EAA775
	v_fmac_f32_e32 v83, v79, v112                              // 00000019DF3C: 56A6E14F
	v_div_scale_f32 v79, null, v71, v71, v62                   // 00000019DF40: D6FC7C4F 04FA8F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019DF48: BF870291
	v_rcp_f32_e32 v91, v79                                     // 00000019DF4C: 7EB6554F
	v_fma_f32 v98, -v79, v91, 1.0                              // 00000019DF50: D6130062 23CAB74F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000019DF58: BF870131
	v_dual_fmac_f32 v91, v98, v91 :: v_dual_and_b32 v98, 1, v0 // 00000019DF5C: C824B762 5B620081
	v_fmac_f32_e32 v81, v84, v119                              // 00000019DF64: 56A2EF54
	v_rcp_f32_e32 v84, v85                                     // 00000019DF68: 7EA85555
	v_add3_u32 v60, v60, v98, 0x7fff                           // 00000019DF6C: D655003C 03FEC53C 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019DF78: BF870292
	v_fma_f32 v58, -v73, v81, v121                             // 00000019DF7C: D613003A 25E6A349
	v_fma_f32 v73, -v85, v84, 1.0                              // 00000019DF84: D6130049 23CAA955
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019DF8C: BF8700A1
	v_fmac_f32_e32 v84, v73, v84                               // 00000019DF90: 56A8A949
	v_div_scale_f32 v73, s0, v62, v71, v62                     // 00000019DF94: D6FC0049 04FA8F3E
	v_dual_mul_f32 v101, v99, v84 :: v_dual_mul_f32 v108, v73, v91// 00000019DF9C: C8C6A963 656CB749
	v_fma_f32 v57, -v117, v83, v122                            // 00000019DFA4: D6130039 25EAA775
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019DFAC: BF870092
	v_fma_f32 v117, -v79, v108, v73                            // 00000019DFB0: D6130075 2526D94F
	v_dual_fmac_f32 v108, v117, v91 :: v_dual_and_b32 v77, 1, v77// 00000019DFB8: C824B775 6C4C9A81
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019DFC0: BF870001
	v_add3_u32 v59, v59, v77, 0x7fff                           // 00000019DFC4: D655003B 03FE9B3B 00007FFF
	v_fma_f32 v77, -v85, v101, v99                             // 00000019DFD0: D613004D 258ECB55
	global_store_d16_hi_b16 v[15:16], v59, off                 // 00000019DFD8: DC960000 007C3B0F
	v_fma_f32 v59, -v100, v107, 1.0                            // 00000019DFE0: D613003B 23CAD764
	global_store_d16_hi_b16 v[23:24], v60, off                 // 00000019DFE8: DC960000 007C3C17
	v_fmac_f32_e32 v107, v59, v107                             // 00000019DFF0: 56D6D73B
	v_fmac_f32_e32 v101, v77, v84                              // 00000019DFF4: 56CAA94D
	v_fma_f32 v59, -v79, v108, v73                             // 00000019DFF8: D613003B 2526D94F
	v_rcp_f32_e32 v77, v116                                    // 00000019E000: 7E9A5574
	s_waitcnt vmcnt(23)                                        // 00000019E004: BF895FF7
	v_lshlrev_b32_e32 v79, 16, v137                            // 00000019E008: 309F1290
	v_mul_f32_e32 v41, v41, v66                                // 00000019E00C: 10528529
	v_fma_f32 v60, -v85, v101, v99                             // 00000019E010: D613003C 258ECB55
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000019E018: BF870141
	v_div_fmas_f32 v60, v60, v84, v101                         // 00000019E01C: D637003C 0596A93C
	s_mov_b32 vcc_lo, s0                                       // 00000019E024: BEEA0000
	v_div_fmas_f32 v59, v59, v91, v108                         // 00000019E028: D637003B 05B2B73B
	s_mov_b32 vcc_lo, s2                                       // 00000019E030: BEEA0002
	v_div_fixup_f32 v60, v60, v90, v61                         // 00000019E034: D627003C 04F6B53C
	v_div_fmas_f32 v72, v72, v146, v89                         // 00000019E03C: D6370048 05672548
	s_mov_b32 vcc_lo, s5                                       // 00000019E044: BEEA0005
	v_div_fixup_f32 v59, v59, v71, v62                         // 00000019E048: D627003B 04FA8F3B
	v_div_fmas_f32 v61, v109, v145, v88                        // 00000019E050: D637003D 0563236D
	.long 0x7e9839bc                                           // 00000019E058: 7E9839BC
	v_div_fixup_f32 v62, v72, v102, v80                        // 00000019E05C: D627003E 0542CD48
	s_mov_b32 vcc_lo, s4                                       // 00000019E064: BEEA0004
	.long 0x7e0039bb                                           // 00000019E068: 7E0039BB
	v_div_fixup_f32 v61, v61, v115, v111                       // 00000019E06C: D627003D 05BEE73D
	v_and_b32_e32 v72, 1, v76                                  // 00000019E074: 36909881
	.long 0x7e9639be                                           // 00000019E078: 7E9639BE
	v_div_fmas_f32 v57, v57, v112, v83                         // 00000019E07C: D6370039 054EE139
	v_and_b32_e32 v71, 1, v0                                   // 00000019E084: 368E0081
	.long 0x7e0039bd                                           // 00000019E088: 7E0039BD
	v_add3_u32 v60, v60, v72, 0x7fff                           // 00000019E08C: D655003C 03FE913C 00007FFF
	v_fma_f32 v72, 0xbfb8aa3b, v97, -v153                      // 00000019E098: D6130048 8666C2FF BFB8AA3B
	s_mov_b32 vcc_lo, s6                                       // 00000019E0A4: BEEA0006
	v_add3_u32 v59, v59, v71, 0x7fff                           // 00000019E0A8: D655003B 03FE8F3B 00007FFF
	v_div_fmas_f32 v58, v58, v119, v81                         // 00000019E0B4: D637003A 0546EF3A
	v_div_fixup_f32 v57, v57, v93, v103                        // 00000019E0BC: D6270039 059EBB39
	v_dual_fmac_f32 v72, 0xb2a5705f, v97 :: v_dual_and_b32 v73, 1, v75// 00000019E0C4: C824C2FF 48489681 B2A5705F
	v_and_b32_e32 v75, 1, v0                                   // 00000019E0D0: 36960081
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019E0D4: BF870004
	v_div_fixup_f32 v58, v58, v94, v113                        // 00000019E0D8: D627003A 05C6BD3A
	s_clause 0x1                                               // 00000019E0E0: BF850001
	global_store_d16_hi_b16 v[31:32], v60, off                 // 00000019E0E4: DC960000 007C3C1F
	global_store_d16_hi_b16 v[39:40], v59, off                 // 00000019E0EC: DC960000 007C3B27
	v_fma_f32 v60, -v116, v77, 1.0                             // 00000019E0F4: D613003C 23CA9B74
	v_add3_u32 v62, v62, v73, 0x7fff                           // 00000019E0FC: D655003E 03FE933E 00007FFF
	v_add3_u32 v61, v61, v75, 0x7fff                           // 00000019E108: D655003D 03FE973D 00007FFF
	s_clause 0x1                                               // 00000019E114: BF850001
	global_store_d16_hi_b16 v[7:8], v61, off offset:32         // 00000019E118: DC960020 007C3D07
	global_store_d16_hi_b16 v[47:48], v62, off offset:32       // 00000019E120: DC960020 007C3E2F
	v_add_f32_e32 v61, v114, v151                              // 00000019E128: 067B2F72
	.long 0x7e0039ba                                           // 00000019E12C: 7E0039BA
	.long 0x7e9439b9                                           // 00000019E130: 7E9439B9
	v_rndne_f32_e32 v73, v153                                  // 00000019E134: 7E924799
	v_fmac_f32_e32 v77, v60, v77                               // 00000019E138: 569A9B3C
	v_exp_f32_e32 v60, v61                                     // 00000019E13C: 7E784B3D
	v_div_scale_f32 v61, s0, v54, v96, v54                     // 00000019E140: D6FC003D 04DAC136
	v_and_b32_e32 v59, 1, v0                                   // 00000019E148: 36760081
	v_dual_sub_f32 v74, v153, v73 :: v_dual_and_b32 v71, 1, v74// 00000019E14C: C9649399 4A469481
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v82                  // 00000019E154: 7C3CA4FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019E15C: BF870004
	v_mul_f32_e32 v76, v61, v77                                // 00000019E160: 10989B3D
	v_mul_f32_e32 v62, v110, v107                              // 00000019E164: 107CD76E
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000019E168: D655003A 03FE773A 00007FFF
	v_cvt_i32_f32_e32 v59, v152                                // 00000019E174: 7E761198
	v_add_f32_e32 v72, v74, v72                                // 00000019E178: 0690914A
	v_add3_u32 v57, v57, v71, 0x7fff                           // 00000019E17C: D6550039 03FE8F39 00007FFF
	v_fma_f32 v75, -v100, v62, v110                            // 00000019E188: D613004B 25BA7D64
	v_mul_f32_e32 v80, 0xbfb8aa3b, v79                         // 00000019E190: 10A09EFF BFB8AA3B
	.long 0xd71c003b                                           // 00000019E198: D71C003B
	v_cndmask_b32_e32 v1, v60, v59, vcc_lo                     // 00000019E19C: 0202773C
	v_fma_f32 v60, -v116, v76, v61                             // 00000019E1A0: D613003C 24F69974
	v_exp_f32_e32 v71, v72                                     // 00000019E1A8: 7E8E4B48
	v_fmac_f32_e32 v62, v75, v107                              // 00000019E1AC: 567CD74B
	global_store_d16_hi_b16 v[15:16], v57, off offset:32       // 00000019E1B0: DC960020 007C390F
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 00000019E1B8: 02767680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v82                  // 00000019E1BC: 7C36A4FF C2B17218
	v_fmac_f32_e32 v76, v60, v77                               // 00000019E1C4: 56989B3C
	v_fma_f32 v72, -v100, v62, v110                            // 00000019E1C8: D6130048 25BA7D64
	v_cvt_i32_f32_e32 v60, v73                                 // 00000019E1D0: 7E781149
	global_store_d16_hi_b16 v[23:24], v58, off offset:32       // 00000019E1D4: DC960020 007C3A17
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 00000019E1DC: 027676FF 7F800000
	s_mov_b32 vcc_lo, s1                                       // 00000019E1E4: BEEA0001
	v_fma_f32 v61, -v116, v76, v61                             // 00000019E1E8: D613003D 24F69974
	v_div_fmas_f32 v62, v72, v107, v62                         // 00000019E1F0: D637003E 04FAD748
	.long 0xd71c003c                                           // 00000019E1F8: D71C003C
	v_cndmask_b32_e32 v1, v71, v60, vcc_lo                     // 00000019E1FC: 02027947
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000019E200: 7C3CC2FF 42CE8ED0
	.long 0x7f903980                                           // 00000019E208: 7F903980
	v_fma_f32 v82, 0xbfb8aa3b, v79, -v80                       // 00000019E20C: D6130052 85429EFF BFB8AA3B
	v_div_fixup_f32 v53, v62, v95, v53                         // 00000019E218: D6270035 04D6BF3E
	v_rndne_f32_e32 v83, v80                                   // 00000019E220: 7EA64750
	v_cndmask_b32_e32 v60, 0, v60, vcc_lo                      // 00000019E224: 02787880
	s_mov_b32 vcc_lo, s0                                       // 00000019E228: BEEA0000
	v_div_fmas_f32 v61, v61, v77, v76                          // 00000019E22C: D637003D 05329B3D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000019E234: 7C36C2FF C2B17218
	.long 0x7e9039b5                                           // 00000019E23C: 7E9039B5
	v_sub_f32_e32 v80, v80, v83                                // 00000019E240: 08A0A750
	v_fmac_f32_e32 v82, 0xb2a5705f, v79                        // 00000019E244: 56A49EFF B2A5705F
	v_div_fixup_f32 v54, v61, v96, v54                         // 00000019E24C: D6270036 04DAC13D
	v_dual_cndmask_b32 v60, 0x7f800000, v60 :: v_dual_lshlrev_b32 v61, 16, v138// 00000019E254: CA6278FF 3C3D1490 7F800000
	v_and_b32_e32 v72, 1, v72                                  // 00000019E260: 36909081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019E264: BF870214
	v_add_f32_e32 v80, v80, v82                                // 00000019E268: 06A0A550
	.long 0x7e0039b6                                           // 00000019E26C: 7E0039B6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000019E270: BF870234
	v_add_f32_e32 v60, 1.0, v60                                // 00000019E274: 067878F2
	v_mul_f32_e32 v62, 0xbfb8aa3b, v61                         // 00000019E278: 107C7AFF BFB8AA3B
	v_add3_u32 v53, v53, v72, 0x7fff                           // 00000019E280: D6550035 03FE9135 00007FFF
	v_and_b32_e32 v77, 1, v0                                   // 00000019E28C: 369A0081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019E290: BF870214
	v_div_scale_f32 v58, null, v60, v60, v42                   // 00000019E294: D6FC7C3A 04AA793C
	v_fma_f32 v75, 0xbfb8aa3b, v61, -v62                       // 00000019E29C: D613004B 84FA7AFF BFB8AA3B
	v_rndne_f32_e32 v76, v62                                   // 00000019E2A8: 7E98473E
	global_store_d16_hi_b16 v[31:32], v53, off offset:32       // 00000019E2AC: DC960020 007C351F
	v_add3_u32 v54, v54, v77, 0x7fff                           // 00000019E2B4: D6550036 03FE9B36 00007FFF
	v_rcp_f32_e32 v74, v58                                     // 00000019E2C0: 7E94553A
	v_sub_f32_e32 v62, v62, v76                                // 00000019E2C4: 087C993E
	v_cvt_i32_f32_e32 v76, v76                                 // 00000019E2C8: 7E98114C
	global_store_d16_hi_b16 v[39:40], v54, off offset:32       // 00000019E2CC: DC960020 007C3627
	v_fma_f32 v81, -v58, v74, 1.0                              // 00000019E2D4: D6130051 23CA953A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019E2DC: BF870091
	v_dual_add_f32 v59, 1.0, v59 :: v_dual_fmac_f32 v74, v81, v74// 00000019E2E0: C90076F2 3B4A9551
	v_div_scale_f32 v71, null, v59, v59, v41                   // 00000019E2E8: D6FC7C47 04A6773B
	v_div_scale_f32 v81, s0, v42, v60, v42                     // 00000019E2F0: D6FC0051 04AA792A
	v_fmac_f32_e32 v75, 0xb2a5705f, v61                        // 00000019E2F8: 56967AFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019E300: BF870113
	v_rcp_f32_e32 v57, v71                                     // 00000019E304: 7E725547
	v_mul_f32_e32 v84, v81, v74                                // 00000019E308: 10A89551
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019E30C: BF8701A2
	v_add_f32_e32 v62, v62, v75                                // 00000019E310: 067C973E
	.long 0xd41e0001                                           // 00000019E314: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v61, vcc_lo              // 00000019E318: 02027AFF 42CE8ED0
	v_fma_f32 v72, -v58, v84, v81                              // 00000019E320: D6130048 2546A93A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000019E328: BF870313
	v_exp_f32_e32 v62, v62                                     // 00000019E32C: 7E7C4B3E
	v_fma_f32 v73, -v71, v57, 1.0                              // 00000019E330: D6130049 23CA7347
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019E338: BF8701A2
	v_fmac_f32_e32 v84, v72, v74                               // 00000019E33C: 56A89548
	v_cvt_i32_f32_e32 v72, v83                                 // 00000019E340: 7E901153
	v_fmac_f32_e32 v57, v73, v57                               // 00000019E344: 56727349
	v_div_scale_f32 v73, vcc_lo, v41, v59, v41                 // 00000019E348: D6FC6A49 04A67729
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000019E350: BF8701B5
	.long 0xd71c003e                                           // 00000019E354: D71C003E
	v_cndmask_b32_e32 v1, v62, v76, vcc_lo                     // 00000019E358: 0202993E
	v_exp_f32_e32 v76, v80                                     // 00000019E35C: 7E984B50
	v_fma_f32 v58, -v58, v84, v81                              // 00000019E360: D613003A 2546A93A
	v_mul_f32_e32 v75, v73, v57                                // 00000019E368: 10967349
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019E36C: BF8701A3
	v_cndmask_b32_e64 v62, 0, v62, s1                          // 00000019E370: D501003E 00067C80
	.long 0xd41b0001                                           // 00000019E378: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v61, vcc_lo              // 00000019E37C: 02027AFF C2B17218
	v_fma_f32 v77, -v71, v75, v73                              // 00000019E384: D613004D 25269747
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019E38C: BF870292
	v_cndmask_b32_e64 v61, 0x7f800000, v62, s1                 // 00000019E390: D501003D 00067CFF 7F800000
	.long 0xd71c003e                                           // 00000019E39C: D71C003E
	v_cndmask_b32_e32 v1, v76, v72, vcc_lo                     // 00000019E3A0: 0202914C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019E3A4: BF870093
	v_fmac_f32_e32 v75, v77, v57                               // 00000019E3A8: 5696734D
	v_fma_f32 v71, -v71, v75, v73                              // 00000019E3AC: D6130047 25269747
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019E3B4: BF870121
	v_div_fmas_f32 v57, v71, v57, v75                          // 00000019E3B8: D6370039 052E7347
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v79                  // 00000019E3C0: 7C3C9EFF 42CE8ED0
	v_div_fixup_f32 v41, v57, v59, v41                         // 00000019E3C8: D6270029 04A67739
	v_cndmask_b32_e32 v62, 0, v62, vcc_lo                      // 00000019E3D0: 027C7C80
	s_mov_b32 vcc_lo, s0                                       // 00000019E3D4: BEEA0000
	.long 0x7f763980                                           // 00000019E3D8: 7F763980
	v_div_fmas_f32 v58, v58, v74, v84                          // 00000019E3DC: D637003A 0552953A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v79                  // 00000019E3E4: 7C369EFF C2B17218
	v_add_f32_e32 v61, 1.0, v61                                // 00000019E3EC: 067A7AF2
	.long 0x7e7639a9                                           // 00000019E3F0: 7E7639A9
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019E3F4: BF870224
	v_div_fixup_f32 v42, v58, v60, v42                         // 00000019E3F8: D627002A 04AA793A
	v_cndmask_b32_e32 v62, 0x7f800000, v62, vcc_lo             // 00000019E400: 027C7CFF 7F800000
	v_div_scale_f32 v71, null, v61, v61, v43                   // 00000019E408: D6FC7C47 04AE7B3D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019E410: BF870113
	.long 0x7e0039aa                                           // 00000019E414: 7E0039AA
	v_rcp_f32_e32 v53, v71                                     // 00000019E418: 7E6A5547
	s_waitcnt vmcnt(17)                                        // 00000019E41C: BF8947F7
	v_lshlrev_b32_e32 v60, 16, v140                            // 00000019E420: 30791890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019E424: BF870092
	v_dual_add_f32 v58, 1.0, v62 :: v_dual_and_b32 v75, 1, v0  // 00000019E428: C9247CF2 3A4A0081
	v_add3_u32 v42, v42, v75, 0x7fff                           // 00000019E430: D655002A 03FE972A 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019E43C: BF870095
	v_fma_f32 v62, -v71, v53, 1.0                              // 00000019E440: D613003E 23CA6B47
	v_fmac_f32_e32 v53, v62, v53                               // 00000019E448: 566A6B3E
	v_mul_f32_e32 v57, 0xbfb8aa3b, v60                         // 00000019E44C: 107278FF BFB8AA3B
	v_div_scale_f32 v54, null, v58, v58, v44                   // 00000019E454: D6FC7C36 04B2753A
	v_div_scale_f32 v62, vcc_lo, v43, v61, v43                 // 00000019E45C: D6FC6A3E 04AE7B2B
	.long 0xd41e0001                                           // 00000019E464: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v60, vcc_lo              // 00000019E468: 020278FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019E470: BF870214
	v_fma_f32 v73, 0xbfb8aa3b, v60, -v57                       // 00000019E474: D6130049 84E678FF BFB8AA3B
	v_rcp_f32_e32 v72, v54                                     // 00000019E480: 7E905536
	v_rndne_f32_e32 v74, v57                                   // 00000019E484: 7E944739
	s_waitcnt vmcnt(11)                                        // 00000019E488: BF892FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019E48C: BF870092
	v_dual_fmac_f32 v73, 0xb2a5705f, v60 :: v_dual_lshlrev_b32 v76, 16, v139// 00000019E490: C82278FF 494D1690 B2A5705F
	v_mul_f32_e32 v77, 0xbfb8aa3b, v76                         // 00000019E49C: 109A98FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019E4A4: BF8701A5
	v_fma_f32 v79, -v54, v72, 1.0                              // 00000019E4A8: D613004F 23CA9136
	v_sub_f32_e32 v57, v57, v74                                // 00000019E4B0: 08729539
	v_fma_f32 v80, 0xbfb8aa3b, v76, -v77                       // 00000019E4B4: D6130050 853698FF BFB8AA3B
	v_and_b32_e32 v59, 1, v59                                  // 00000019E4C0: 36767681
	v_rndne_f32_e32 v81, v77                                   // 00000019E4C4: 7EA2474D
	v_fmac_f32_e32 v72, v79, v72                               // 00000019E4C8: 5690914F
	v_div_scale_f32 v79, s0, v44, v58, v44                     // 00000019E4CC: D6FC004F 04B2752C
	v_dual_add_f32 v57, v57, v73 :: v_dual_fmac_f32 v80, 0xb2a5705f, v76// 00000019E4D4: C9009339 395098FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019E4E0: BF870224
	v_sub_f32_e32 v77, v77, v81                                // 00000019E4E4: 089AA34D
	v_add3_u32 v41, v41, v59, 0x7fff                           // 00000019E4E8: D6550029 03FE7729 00007FFF
	v_mul_f32_e32 v82, v79, v72                                // 00000019E4F4: 10A4914F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019E4F8: BF870004
	v_exp_f32_e32 v57, v57                                     // 00000019E4FC: 7E724B39
	v_cvt_i32_f32_e32 v74, v74                                 // 00000019E500: 7E94114A
	v_add_f32_e32 v77, v77, v80                                // 00000019E504: 069AA14D
	global_store_d16_hi_b16 v[7:8], v41, off offset:64         // 00000019E508: DC960040 007C2907
	v_fma_f32 v59, -v54, v82, v79                              // 00000019E510: D613003B 253EA536
	v_mul_f32_e32 v73, v62, v53                                // 00000019E518: 10926B3E
	global_store_d16_hi_b16 v[47:48], v42, off offset:64       // 00000019E51C: DC960040 007C2A2F
	v_fmac_f32_e32 v82, v59, v72                               // 00000019E524: 56A4913B
	v_fma_f32 v75, -v71, v73, v62                              // 00000019E528: D613004B 24FA9347
	.long 0xd71c0039                                           // 00000019E530: D71C0039
	v_cndmask_b32_e32 v1, v57, v74, vcc_lo                     // 00000019E534: 02029539
	v_exp_f32_e32 v74, v77                                     // 00000019E538: 7E944B4D
	v_cvt_i32_f32_e32 v59, v81                                 // 00000019E53C: 7E761151
	v_fma_f32 v54, -v54, v82, v79                              // 00000019E540: D6130036 253EA536
	v_fmac_f32_e32 v73, v75, v53                               // 00000019E548: 56926B4B
	v_cndmask_b32_e64 v57, 0, v57, s1                          // 00000019E54C: D5010039 00067280
	.long 0xd41b0001                                           // 00000019E554: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v60, vcc_lo              // 00000019E558: 020278FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019E560: BF870293
	v_fma_f32 v62, -v71, v73, v62                              // 00000019E564: D613003E 24FA9347
	.long 0xd71c003b                                           // 00000019E56C: D71C003B
	v_cndmask_b32_e32 v1, v74, v59, vcc_lo                     // 00000019E570: 0202774A
	s_waitcnt vmcnt(5)                                         // 00000019E574: BF8917F7
	v_lshlrev_b32_e32 v74, 16, v141                            // 00000019E578: 30951A90
	v_cndmask_b32_e64 v57, 0x7f800000, v57, s1                 // 00000019E57C: D5010039 000672FF 7F800000
	v_div_fmas_f32 v53, v62, v53, v73                          // 00000019E588: D6370035 05266B3E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v76                  // 00000019E590: 7C3C98FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019E598: BF870194
	v_mul_f32_e32 v75, 0xbfb8aa3b, v74                         // 00000019E59C: 109694FF BFB8AA3B
	v_div_fixup_f32 v43, v53, v61, v43                         // 00000019E5A4: D627002B 04AE7B35
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 00000019E5AC: 02767680
	s_mov_b32 vcc_lo, s0                                       // 00000019E5B0: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000019E5B4: BF8701B3
	v_fma_f32 v77, 0xbfb8aa3b, v74, -v75                       // 00000019E5B8: D613004D 852E94FF BFB8AA3B
	v_div_fmas_f32 v54, v54, v72, v82                          // 00000019E5C4: D6370036 054A9136
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v76                  // 00000019E5CC: 7C3698FF C2B17218
	v_fmac_f32_e32 v77, 0xb2a5705f, v74                        // 00000019E5D4: 569A94FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019E5DC: BF870003
	v_div_fixup_f32 v41, v54, v58, v44                         // 00000019E5E0: D6270029 04B27536
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 00000019E5E8: 027676FF 7F800000
	v_mul_f32_e32 v44, v46, v51                                // 00000019E5F0: 1058672E
	v_lshlrev_b32_e32 v58, 16, v78                             // 00000019E5F4: 30749C90
	v_rndne_f32_e32 v78, v75                                   // 00000019E5F8: 7E9C474B
	.long 0x7e0039a9                                           // 00000019E5FC: 7E0039A9
	v_add_f32_e32 v54, 1.0, v59                                // 00000019E600: 066C76F2
	.long 0x7e7639ab                                           // 00000019E604: 7E7639AB
	v_mul_f32_e32 v53, 0xbfb8aa3b, v58                         // 00000019E608: 106A74FF BFB8AA3B
	.long 0x7f763980                                           // 00000019E610: 7F763980
	v_sub_f32_e32 v75, v75, v78                                // 00000019E614: 08969D4B
	v_div_scale_f32 v42, null, v54, v54, v44                   // 00000019E618: D6FC7C2A 04B26D36
	.long 0xd41e0001                                           // 00000019E620: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v58, vcc_lo              // 00000019E624: 020274FF 42CE8ED0
	v_fma_f32 v71, 0xbfb8aa3b, v58, -v53                       // 00000019E62C: D6130047 84D674FF BFB8AA3B
	v_rndne_f32_e32 v72, v53                                   // 00000019E638: 7E904735
	v_and_b32_e32 v59, 1, v59                                  // 00000019E63C: 36767681
	v_rcp_f32_e32 v62, v42                                     // 00000019E640: 7E7C552A
	v_add_f32_e32 v75, v75, v77                                // 00000019E644: 06969B4B
	v_fmac_f32_e32 v71, 0xb2a5705f, v58                        // 00000019E648: 568E74FF B2A5705F
	v_sub_f32_e32 v53, v53, v72                                // 00000019E650: 086A9135
	v_cvt_i32_f32_e32 v72, v72                                 // 00000019E654: 7E901148
	v_add3_u32 v43, v43, v59, 0x7fff                           // 00000019E658: D655002B 03FE772B 00007FFF
	v_and_b32_e32 v73, 1, v0                                   // 00000019E664: 36920081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019E668: BF870294
	v_add_f32_e32 v53, v53, v71                                // 00000019E66C: 066A8F35
	v_fma_f32 v76, -v42, v62, 1.0                              // 00000019E670: D613004C 23CA7D2A
	v_mul_f32_e32 v45, v45, v52                                // 00000019E678: 105A692D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019E67C: BF870214
	v_add3_u32 v41, v41, v73, 0x7fff                           // 00000019E680: D6550029 03FE9329 00007FFF
	v_exp_f32_e32 v53, v53                                     // 00000019E68C: 7E6A4B35
	global_store_d16_hi_b16 v[15:16], v43, off offset:64       // 00000019E690: DC960040 007C2B0F
	v_fmac_f32_e32 v62, v76, v62                               // 00000019E698: 567C7D4C
	v_div_scale_f32 v76, s0, v44, v54, v44                     // 00000019E69C: D6FC004C 04B26D2C
	global_store_d16_hi_b16 v[23:24], v41, off offset:64       // 00000019E6A4: DC960040 007C2917
	v_mul_f32_e32 v79, v76, v62                                // 00000019E6AC: 109E7D4C
	.long 0xd71c0035                                           // 00000019E6B0: D71C0035
	v_cndmask_b32_e32 v1, v53, v72, vcc_lo                     // 00000019E6B4: 02029135
	v_exp_f32_e32 v72, v75                                     // 00000019E6B8: 7E904B4B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019E6BC: BF870112
	v_fma_f32 v59, -v42, v79, v76                              // 00000019E6C0: D613003B 25329F2A
	v_cndmask_b32_e64 v53, 0, v53, s1                          // 00000019E6C8: D5010035 00066A80
	.long 0xd41b0001                                           // 00000019E6D0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v58, vcc_lo              // 00000019E6D4: 020274FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019E6DC: BF8701A3
	v_fmac_f32_e32 v79, v59, v62                               // 00000019E6E0: 569E7D3B
	v_cvt_i32_f32_e32 v59, v78                                 // 00000019E6E4: 7E76114E
	v_cndmask_b32_e64 v53, 0x7f800000, v53, s1                 // 00000019E6E8: D5010035 00066AFF 7F800000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019E6F4: BF870003
	v_fma_f32 v42, -v42, v79, v76                              // 00000019E6F8: D613002A 25329F2A
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 00000019E700: BF870185
	.long 0xd71c003a                                           // 00000019E704: D71C003A
	v_cndmask_b32_e32 v1, v72, v59, vcc_lo                     // 00000019E708: 02027748
	v_dual_add_f32 v57, 1.0, v57 :: v_dual_lshlrev_b32 v72, 16, v132// 00000019E70C: C92272F2 39490890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019E714: BF870091
	v_div_scale_f32 v60, null, v57, v57, v45                   // 00000019E718: D6FC7C3C 04B67339
	v_rcp_f32_e32 v46, v60                                     // 00000019E720: 7E5C553C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019E724: BF870095
	v_fma_f32 v61, -v60, v46, 1.0                              // 00000019E728: D613003D 23CA5D3C
	v_fmac_f32_e32 v46, v61, v46                               // 00000019E730: 565C5D3D
	v_div_scale_f32 v61, vcc_lo, v45, v57, v45                 // 00000019E734: D6FC6A3D 04B6732D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019E73C: BF870091
	v_mul_f32_e32 v71, v61, v46                                // 00000019E740: 108E5D3D
	v_fma_f32 v73, -v60, v71, v61                              // 00000019E744: D6130049 24F68F3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019E74C: BF870121
	v_fmac_f32_e32 v71, v73, v46                               // 00000019E750: 568E5D49
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000019E754: 109290FF BFB8AA3B
	v_fma_f32 v60, -v60, v71, v61                              // 00000019E75C: D613003C 24F68F3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019E764: BF8701A2
	v_fma_f32 v75, 0xbfb8aa3b, v72, -v73                       // 00000019E768: D613004B 852690FF BFB8AA3B
	v_rndne_f32_e32 v76, v73                                   // 00000019E774: 7E984749
	v_div_fmas_f32 v46, v60, v46, v71                          // 00000019E778: D637002E 051E5D3C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v74                  // 00000019E780: 7C3C94FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019E788: BF870214
	v_fmac_f32_e32 v75, 0xb2a5705f, v72                        // 00000019E78C: 569690FF B2A5705F
	v_dual_sub_f32 v73, v73, v76 :: v_dual_cndmask_b32 v58, 0, v58// 00000019E794: C9529949 493A7480
	s_mov_b32 vcc_lo, s0                                       // 00000019E79C: BEEA0000
	v_div_fixup_f32 v45, v46, v57, v45                         // 00000019E7A0: D627002D 04B6732E
	v_div_fmas_f32 v42, v42, v62, v79                          // 00000019E7A8: D637002A 053E7D2A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v74                  // 00000019E7B0: 7C3694FF C2B17218
	.long 0x7f723980                                           // 00000019E7B8: 7F723980
	v_add_f32_e32 v73, v73, v75                                // 00000019E7BC: 06929749
	.long 0x7e7239ad                                           // 00000019E7C0: 7E7239AD
	v_div_fixup_f32 v42, v42, v54, v44                         // 00000019E7C4: D627002A 04B26D2A
	v_cndmask_b32_e32 v58, 0x7f800000, v58, vcc_lo             // 00000019E7CC: 027474FF 7F800000
	v_lshlrev_b32_e32 v54, 16, v133                            // 00000019E7D4: 306D0A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019E7D8: BF870214
	v_and_b32_e32 v57, 1, v57                                  // 00000019E7DC: 36727281
	.long 0x7e0039aa                                           // 00000019E7E0: 7E0039AA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019E7E4: BF870214
	v_add_f32_e32 v44, 1.0, v58                                // 00000019E7E8: 065874F2
	v_mul_f32_e32 v46, 0xbfb8aa3b, v54                         // 00000019E7EC: 105C6CFF BFB8AA3B
	.long 0xd41e0001                                           // 00000019E7F4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v54, vcc_lo              // 00000019E7F8: 02026CFF 42CE8ED0
	v_add3_u32 v45, v45, v57, 0x7fff                           // 00000019E800: D655002D 03FE732D 00007FFF
	v_and_b32_e32 v71, 1, v0                                   // 00000019E80C: 368E0081
	v_div_scale_f32 v41, null, v44, v44, v34                   // 00000019E810: D6FC7C29 048A592C
	v_fma_f32 v61, 0xbfb8aa3b, v54, -v46                       // 00000019E818: D613003D 84BA6CFF BFB8AA3B
	v_rndne_f32_e32 v62, v46                                   // 00000019E824: 7E7C472E
	global_store_d16_hi_b16 v[31:32], v45, off offset:64       // 00000019E828: DC960040 007C2D1F
	v_add3_u32 v42, v42, v71, 0x7fff                           // 00000019E830: D655002A 03FE8F2A 00007FFF
	v_rcp_f32_e32 v60, v41                                     // 00000019E83C: 7E785529
	v_fmac_f32_e32 v61, 0xb2a5705f, v54                        // 00000019E840: 567A6CFF B2A5705F
	v_sub_f32_e32 v46, v46, v62                                // 00000019E848: 085C7D2E
	v_cvt_i32_f32_e32 v62, v62                                 // 00000019E84C: 7E7C113E
	v_lshlrev_b32_e32 v45, 16, v135                            // 00000019E850: 305B0E90
	global_store_d16_hi_b16 v[39:40], v42, off offset:64       // 00000019E854: DC960040 007C2A27
	v_add_f32_e32 v46, v46, v61                                // 00000019E85C: 065C7B2E
	v_fma_f32 v74, -v41, v60, 1.0                              // 00000019E860: D613004A 23CA7929
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019E868: BF870092
	v_exp_f32_e32 v46, v46                                     // 00000019E86C: 7E5C4B2E
	v_fmac_f32_e32 v60, v74, v60                               // 00000019E870: 5678794A
	v_div_scale_f32 v74, s0, v34, v44, v34                     // 00000019E874: D6FC004A 048A5922
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019E87C: BF870291
	v_mul_f32_e32 v77, v74, v60                                // 00000019E880: 109A794A
	.long 0xd71c002e                                           // 00000019E884: D71C002E
	v_cndmask_b32_e32 v1, v46, v62, vcc_lo                     // 00000019E888: 02027D2E
	v_exp_f32_e32 v62, v73                                     // 00000019E88C: 7E7C4B49
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019E890: BF870112
	v_fma_f32 v57, -v41, v77, v74                              // 00000019E894: D6130039 252A9B29
	v_cndmask_b32_e64 v46, 0, v46, s1                          // 00000019E89C: D501002E 00065C80
	.long 0xd41b0001                                           // 00000019E8A4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v54, vcc_lo              // 00000019E8A8: 02026CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019E8B0: BF8701A3
	v_fmac_f32_e32 v77, v57, v60                               // 00000019E8B4: 569A7939
	v_cvt_i32_f32_e32 v57, v76                                 // 00000019E8B8: 7E72114C
	v_cndmask_b32_e64 v46, 0x7f800000, v46, s1                 // 00000019E8BC: D501002E 00065CFF 7F800000
	.long 0xd41e0001                                           // 00000019E8C8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v45, vcc_lo              // 00000019E8CC: 02025AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019E8D4: BF870004
	v_fma_f32 v41, -v41, v77, v74                              // 00000019E8D8: D6130029 252A9B29
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 00000019E8E0: BF870205
	.long 0xd71c0036                                           // 00000019E8E4: D71C0036
	v_cndmask_b32_e32 v1, v62, v57, vcc_lo                     // 00000019E8E8: 0202733E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019E8EC: BF870124
	v_dual_add_f32 v53, 1.0, v53 :: v_dual_add_f32 v46, 1.0, v46// 00000019E8F0: C9086AF2 352E5CF2
	v_lshlrev_b32_e32 v62, 16, v134                            // 00000019E8F8: 307D0C90
	v_div_scale_f32 v59, null, v53, v53, v33                   // 00000019E8FC: D6FC7C3B 04866B35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019E904: BF870113
	v_div_scale_f32 v57, null, v46, v46, v35                   // 00000019E908: D6FC7C39 048E5D2E
	v_rcp_f32_e32 v43, v59                                     // 00000019E910: 7E56553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019E914: BF870095
	v_fma_f32 v58, -v59, v43, 1.0                              // 00000019E918: D613003A 23CA573B
	v_fmac_f32_e32 v43, v58, v43                               // 00000019E920: 5656573A
	v_div_scale_f32 v58, vcc_lo, v33, v53, v33                 // 00000019E924: D6FC6A3A 04866B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019E92C: BF870091
	v_mul_f32_e32 v61, v58, v43                                // 00000019E930: 107A573A
	v_fma_f32 v71, -v59, v61, v58                              // 00000019E934: D6130047 24EA7B3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019E93C: BF870121
	v_fmac_f32_e32 v61, v71, v43                               // 00000019E940: 567A5747
	v_mul_f32_e32 v71, 0xbfb8aa3b, v62                         // 00000019E944: 108E7CFF BFB8AA3B
	v_fma_f32 v58, -v59, v61, v58                              // 00000019E94C: D613003A 24EA7B3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019E954: BF8701A2
	v_fma_f32 v73, 0xbfb8aa3b, v62, -v71                       // 00000019E958: D6130049 851E7CFF BFB8AA3B
	v_rndne_f32_e32 v74, v71                                   // 00000019E964: 7E944747
	v_div_fmas_f32 v43, v58, v43, v61                          // 00000019E968: D637002B 04F6573A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000019E970: 7C3C90FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019E978: BF870214
	v_fmac_f32_e32 v73, 0xb2a5705f, v62                        // 00000019E97C: 56927CFF B2A5705F
	v_sub_f32_e32 v71, v71, v74                                // 00000019E984: 088E9547
	v_cndmask_b32_e32 v54, 0, v54, vcc_lo                      // 00000019E988: 026C6C80
	s_mov_b32 vcc_lo, s0                                       // 00000019E98C: BEEA0000
	v_div_fixup_f32 v33, v43, v53, v33                         // 00000019E990: D6270021 04866B2B
	v_div_fmas_f32 v41, v41, v60, v77                          // 00000019E998: D6370029 05367929
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000019E9A0: 7C3690FF C2B17218
	v_mul_f32_e32 v43, 0xbfb8aa3b, v45                         // 00000019E9A8: 10565AFF BFB8AA3B
	.long 0x7f6a3980                                           // 00000019E9B0: 7F6A3980
	.long 0x7e6a39a1                                           // 00000019E9B4: 7E6A39A1
	v_div_fixup_f32 v34, v41, v44, v34                         // 00000019E9B8: D6270022 048A5929
	v_cndmask_b32_e32 v54, 0x7f800000, v54, vcc_lo             // 00000019E9C0: 026C6CFF 7F800000
	v_rcp_f32_e32 v41, v57                                     // 00000019E9C8: 7E525539
	v_fma_f32 v59, 0xbfb8aa3b, v45, -v43                       // 00000019E9CC: D613003B 84AE5AFF BFB8AA3B
	v_rndne_f32_e32 v60, v43                                   // 00000019E9D8: 7E78472B
	.long 0x7e0039a2                                           // 00000019E9DC: 7E0039A2
	v_dual_add_f32 v44, 1.0, v54 :: v_dual_and_b32 v53, 1, v53 // 00000019E9E0: C9246CF2 2C346A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019E9E8: BF870214
	v_fmac_f32_e32 v59, 0xb2a5705f, v45                        // 00000019E9EC: 56765AFF B2A5705F
	v_sub_f32_e32 v43, v43, v60                                // 00000019E9F4: 0856792B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019E9F8: BF870214
	v_and_b32_e32 v61, 1, v0                                   // 00000019E9FC: 367A0081
	v_div_scale_f32 v42, null, v44, v44, v36                   // 00000019EA00: D6FC7C2A 0492592C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019EA08: BF870005
	v_fma_f32 v54, -v57, v41, 1.0                              // 00000019EA0C: D6130036 23CA5339
	v_cvt_i32_f32_e32 v60, v60                                 // 00000019EA14: 7E78113C
	v_add_f32_e32 v43, v43, v59                                // 00000019EA18: 0656772B
	v_add3_u32 v34, v34, v61, 0x7fff                           // 00000019EA1C: D6550022 03FE7B22 00007FFF
	v_rcp_f32_e32 v58, v42                                     // 00000019EA28: 7E74552A
	v_fmac_f32_e32 v41, v54, v41                               // 00000019EA2C: 56525336
	v_div_scale_f32 v54, vcc_lo, v35, v46, v35                 // 00000019EA30: D6FC6A36 048E5D23
	v_exp_f32_e32 v43, v43                                     // 00000019EA38: 7E564B2B
	v_add_f32_e32 v71, v71, v73                                // 00000019EA3C: 068E9347
	v_add3_u32 v33, v33, v53, 0x7fff                           // 00000019EA40: D6550021 03FE6B21 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000019EA4C: BF870313
	v_mul_f32_e32 v59, v54, v41                                // 00000019EA50: 10765336
	v_fma_f32 v72, -v42, v58, 1.0                              // 00000019EA54: D6130048 23CA752A
	global_store_d16_hi_b16 v[7:8], v33, off offset:96         // 00000019EA5C: DC960060 007C2107
	v_fma_f32 v61, -v57, v59, v54                              // 00000019EA64: D613003D 24DA7739
	.long 0xd71c002b                                           // 00000019EA6C: D71C002B
	v_cndmask_b32_e32 v1, v43, v60, vcc_lo                     // 00000019EA70: 0202792B
	v_exp_f32_e32 v60, v71                                     // 00000019EA74: 7E784B47
	v_fmac_f32_e32 v58, v72, v58                               // 00000019EA78: 56747548
	v_div_scale_f32 v72, s0, v36, v44, v36                     // 00000019EA7C: D6FC0048 04925924
	v_fmac_f32_e32 v59, v61, v41                               // 00000019EA84: 5676533D
	v_cndmask_b32_e64 v43, 0, v43, s1                          // 00000019EA88: D501002B 00065680
	.long 0xd41b0001                                           // 00000019EA90: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v45, vcc_lo              // 00000019EA94: 02025AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v34, off offset:96       // 00000019EA9C: DC960060 007C222F
	v_mul_f32_e32 v75, v72, v58                                // 00000019EAA4: 10967548
	v_fma_f32 v54, -v57, v59, v54                              // 00000019EAA8: D6130036 24DA7739
	v_cndmask_b32_e64 v43, 0x7f800000, v43, s1                 // 00000019EAB0: D501002B 000656FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019EABC: BF870193
	v_fma_f32 v53, -v42, v75, v72                              // 00000019EAC0: D6130035 2522972A
	v_div_fmas_f32 v41, v54, v41, v59                          // 00000019EAC8: D6370029 04EE5336
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v62                  // 00000019EAD0: 7C3C7CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019EAD8: BF870214
	v_add_f32_e32 v43, 1.0, v43                                // 00000019EADC: 065656F2
	v_fmac_f32_e32 v75, v53, v58                               // 00000019EAE0: 56967535
	v_cvt_i32_f32_e32 v53, v74                                 // 00000019EAE4: 7E6A114A
	v_div_fixup_f32 v35, v41, v46, v35                         // 00000019EAE8: D6270023 048E5D29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019EAF0: BF870193
	v_fma_f32 v42, -v42, v75, v72                              // 00000019EAF4: D613002A 2522972A
	.long 0xd71c002d                                           // 00000019EAFC: D71C002D
	v_cndmask_b32_e32 v1, v60, v53, vcc_lo                     // 00000019EB00: 02026B3C
	v_div_scale_f32 v53, null, v43, v43, v37                   // 00000019EB04: D6FC7C35 0496572B
	s_waitcnt vmcnt(4)                                         // 00000019EB0C: BF8913F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019EB10: BF8700A2
	v_dual_cndmask_b32 v45, 0, v45 :: v_dual_lshlrev_b32 v60, 16, v136// 00000019EB14: CA625A80 2D3D1090
	s_mov_b32 vcc_lo, s0                                       // 00000019EB1C: BEEA0000
	v_mul_f32_e32 v61, 0xbfb8aa3b, v60                         // 00000019EB20: 107A78FF BFB8AA3B
	v_div_fmas_f32 v42, v42, v58, v75                          // 00000019EB28: D637002A 052E752A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v62                  // 00000019EB30: 7C367CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019EB38: BF870193
	v_fma_f32 v71, 0xbfb8aa3b, v60, -v61                       // 00000019EB3C: D6130047 84F678FF BFB8AA3B
	v_div_fixup_f32 v33, v42, v44, v36                         // 00000019EB48: D6270021 0492592A
	v_dual_cndmask_b32 v45, 0x7f800000, v45 :: v_dual_mul_f32 v36, v38, v51// 00000019EB50: CA465AFF 2D246726 7F800000
	v_lshlrev_b32_e32 v44, 16, v86                             // 00000019EB5C: 3058AC90
	v_rcp_f32_e32 v38, v53                                     // 00000019EB60: 7E4C5535
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019EB64: BF870193
	.long 0x7e0039a1                                           // 00000019EB68: 7E0039A1
	v_add_f32_e32 v42, 1.0, v45                                // 00000019EB6C: 06545AF2
	v_rndne_f32_e32 v72, v61                                   // 00000019EB70: 7E90473D
	v_mul_f32_e32 v41, 0xbfb8aa3b, v44                         // 00000019EB74: 105258FF BFB8AA3B
	.long 0x7e5a39a3                                           // 00000019EB7C: 7E5A39A3
	.long 0x7f5a3980                                           // 00000019EB80: 7F5A3980
	v_div_scale_f32 v34, null, v42, v42, v36                   // 00000019EB84: D6FC7C22 0492552A
	v_and_b32_e32 v59, 1, v0                                   // 00000019EB8C: 36760081
	v_fma_f32 v57, 0xbfb8aa3b, v44, -v41                       // 00000019EB90: D6130039 84A658FF BFB8AA3B
	v_rndne_f32_e32 v58, v41                                   // 00000019EB9C: 7E744729
	v_fma_f32 v46, -v53, v38, 1.0                              // 00000019EBA0: D613002E 23CA4D35
	v_rcp_f32_e32 v54, v34                                     // 00000019EBA8: 7E6C5522
	v_fmac_f32_e32 v71, 0xb2a5705f, v60                        // 00000019EBAC: 568E78FF B2A5705F
	v_fmac_f32_e32 v57, 0xb2a5705f, v44                        // 00000019EBB4: 567258FF B2A5705F
	v_sub_f32_e32 v41, v41, v58                                // 00000019EBBC: 08527529
	v_fmac_f32_e32 v38, v46, v38                               // 00000019EBC0: 564C4D2E
	v_div_scale_f32 v46, vcc_lo, v37, v43, v37                 // 00000019EBC4: D6FC6A2E 04965725
	v_sub_f32_e32 v61, v61, v72                                // 00000019EBCC: 087A913D
	v_and_b32_e32 v45, 1, v45                                  // 00000019EBD0: 365A5A81
	v_add_f32_e32 v41, v41, v57                                // 00000019EBD4: 06527329
	v_add3_u32 v33, v33, v59, 0x7fff                           // 00000019EBD8: D6550021 03FE7721 00007FFF
	v_fma_f32 v62, -v34, v54, 1.0                              // 00000019EBE4: D613003E 23CA6D22
	v_mul_f32_e32 v57, v46, v38                                // 00000019EBEC: 10724D2E
	v_cvt_i32_f32_e32 v58, v58                                 // 00000019EBF0: 7E74113A
	v_exp_f32_e32 v41, v41                                     // 00000019EBF4: 7E524B29
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000019EBF8: BF870253
	v_dual_add_f32 v61, v61, v71 :: v_dual_fmac_f32 v54, v62, v54// 00000019EBFC: C9008F3D 3D366D3E
	v_div_scale_f32 v62, s0, v36, v42, v36                     // 00000019EC04: D6FC003E 04925524
	v_fma_f32 v59, -v53, v57, v46                              // 00000019EC0C: D613003B 24BA7335
	v_add3_u32 v35, v35, v45, 0x7fff                           // 00000019EC14: D6550023 03FE5B23 00007FFF
	.long 0xd41e0001                                           // 00000019EC20: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v44, vcc_lo              // 00000019EC24: 020258FF 42CE8ED0
	v_mul_f32_e32 v73, v62, v54                                // 00000019EC2C: 10926D3E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019EC30: BF870294
	v_fmac_f32_e32 v57, v59, v38                               // 00000019EC34: 56724D3B
	.long 0xd71c0029                                           // 00000019EC38: D71C0029
	v_cndmask_b32_e32 v1, v41, v58, vcc_lo                     // 00000019EC3C: 02027529
	v_exp_f32_e32 v58, v61                                     // 00000019EC40: 7E744B3D
	global_store_d16_hi_b16 v[15:16], v35, off offset:96       // 00000019EC44: DC960060 007C230F
	v_fma_f32 v45, -v34, v73, v62                              // 00000019EC4C: D613002D 24FA9322
	v_fma_f32 v46, -v53, v57, v46                              // 00000019EC54: D613002E 24BA7335
	v_cndmask_b32_e64 v41, 0, v41, s1                          // 00000019EC5C: D5010029 00065280
	.long 0xd41b0001                                           // 00000019EC64: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v44, vcc_lo              // 00000019EC68: 020258FF C2B17218
	global_store_d16_hi_b16 v[23:24], v33, off offset:96       // 00000019EC70: DC960060 007C2117
	v_fmac_f32_e32 v73, v45, v54                               // 00000019EC78: 56926D2D
	v_cvt_i32_f32_e32 v45, v72                                 // 00000019EC7C: 7E5A1148
	v_div_fmas_f32 v38, v46, v38, v57                          // 00000019EC80: D6370026 04E64D2E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v60                  // 00000019EC88: 7C3C78FF 42CE8ED0
	v_cndmask_b32_e64 v41, 0x7f800000, v41, s1                 // 00000019EC90: D5010029 000652FF 7F800000
	v_fma_f32 v34, -v34, v73, v62                              // 00000019EC9C: D6130022 24FA9322
	.long 0xd71c002c                                           // 00000019ECA4: D71C002C
	v_cndmask_b32_e32 v1, v58, v45, vcc_lo                     // 00000019ECA8: 02025B3A
	v_div_fixup_f32 v37, v38, v43, v37                         // 00000019ECAC: D6270025 04965726
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019ECB4: BF870224
	v_dual_add_f32 v41, 1.0, v41 :: v_dual_lshlrev_b32 v58, 16, v127// 00000019ECB8: C92252F2 293AFE90
	.long 0x7f563980                                           // 00000019ECC0: 7F563980
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo                      // 00000019ECC4: 02585880
	s_mov_b32 vcc_lo, s0                                       // 00000019ECC8: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019ECCC: BF870003
	v_mul_f32_e32 v59, 0xbfb8aa3b, v58                         // 00000019ECD0: 107674FF BFB8AA3B
	v_div_fmas_f32 v34, v34, v54, v73                          // 00000019ECD8: D6370022 05266D22
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v60                  // 00000019ECE0: 7C3678FF C2B17218
	v_div_scale_f32 v45, null, v41, v41, v25                   // 00000019ECE8: D6FC7C2D 04665329
	.long 0x7e5639a5                                           // 00000019ECF0: 7E5639A5
	v_fma_f32 v61, 0xbfb8aa3b, v58, -v59                       // 00000019ECF4: D613003D 84EE74FF BFB8AA3B
	v_div_fixup_f32 v34, v34, v42, v36                         // 00000019ED00: D6270022 04925522
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo             // 00000019ED08: 025858FF 7F800000
	v_lshlrev_b32_e32 v42, 16, v128                            // 00000019ED10: 30550090
	v_rcp_f32_e32 v35, v45                                     // 00000019ED14: 7E46552D
	v_rndne_f32_e32 v62, v59                                   // 00000019ED18: 7E7C473B
	.long 0x7e0039a2                                           // 00000019ED1C: 7E0039A2
	v_add_f32_e32 v36, 1.0, v44                                // 00000019ED20: 064858F2
	v_mul_f32_e32 v38, 0xbfb8aa3b, v42                         // 00000019ED24: 104C54FF BFB8AA3B
	v_fmac_f32_e32 v61, 0xb2a5705f, v58                        // 00000019ED2C: 567A74FF B2A5705F
	v_sub_f32_e32 v59, v59, v62                                // 00000019ED34: 08767D3B
	v_and_b32_e32 v57, 1, v0                                   // 00000019ED38: 36720081
	v_div_scale_f32 v33, null, v36, v36, v26                   // 00000019ED3C: D6FC7C21 046A4924
	v_fma_f32 v53, 0xbfb8aa3b, v42, -v38                       // 00000019ED44: D6130035 849A54FF BFB8AA3B
	v_rndne_f32_e32 v54, v38                                   // 00000019ED50: 7E6C4726
	v_fma_f32 v44, -v45, v35, 1.0                              // 00000019ED54: D613002C 23CA472D
	v_and_b32_e32 v43, 1, v43                                  // 00000019ED5C: 36565681
	v_rcp_f32_e32 v46, v33                                     // 00000019ED60: 7E5C5521
	v_fmac_f32_e32 v53, 0xb2a5705f, v42                        // 00000019ED64: 566A54FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000019ED6C: BF870243
	v_dual_sub_f32 v38, v38, v54 :: v_dual_fmac_f32 v35, v44, v35// 00000019ED70: C9406D26 2622472C
	v_div_scale_f32 v44, vcc_lo, v25, v41, v25                 // 00000019ED78: D6FC6A2C 04665319
	v_add3_u32 v34, v34, v57, 0x7fff                           // 00000019ED80: D6550022 03FE7322 00007FFF
	v_cvt_i32_f32_e32 v54, v54                                 // 00000019ED8C: 7E6C1136
	v_add_f32_e32 v38, v38, v53                                // 00000019ED90: 064C6B26
	v_add_f32_e32 v59, v59, v61                                // 00000019ED94: 06767B3B
	v_mul_f32_e32 v53, v44, v35                                // 00000019ED98: 106A472C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019ED9C: BF870005
	v_fma_f32 v60, -v33, v46, 1.0                              // 00000019EDA0: D613003C 23CA5D21
	v_add3_u32 v37, v37, v43, 0x7fff                           // 00000019EDA8: D6550025 03FE5725 00007FFF
	v_exp_f32_e32 v38, v38                                     // 00000019EDB4: 7E4C4B26
	.long 0xd41e0001                                           // 00000019EDB8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v42, vcc_lo              // 00000019EDBC: 020254FF 42CE8ED0
	v_fma_f32 v57, -v45, v53, v44                              // 00000019EDC4: D6130039 24B26B2D
	v_fmac_f32_e32 v46, v60, v46                               // 00000019EDCC: 565C5D3C
	v_div_scale_f32 v60, s0, v26, v36, v26                     // 00000019EDD0: D6FC003C 046A491A
	global_store_d16_hi_b16 v[31:32], v37, off offset:96       // 00000019EDD8: DC960060 007C251F
	v_lshlrev_b32_e32 v37, 16, v130                            // 00000019EDE0: 304B0490
	v_fmac_f32_e32 v53, v57, v35                               // 00000019EDE4: 566A4739
	global_store_d16_hi_b16 v[39:40], v34, off offset:96       // 00000019EDE8: DC960060 007C2227
	v_mul_f32_e32 v71, v60, v46                                // 00000019EDF0: 108E5D3C
	.long 0xd71c0026                                           // 00000019EDF4: D71C0026
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 00000019EDF8: 02026D26
	v_exp_f32_e32 v54, v59                                     // 00000019EDFC: 7E6C4B3B
	v_fma_f32 v44, -v45, v53, v44                              // 00000019EE00: D613002C 24B26B2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019EE08: BF870193
	v_fma_f32 v43, -v33, v71, v60                              // 00000019EE0C: D613002B 24F28F21
	v_cndmask_b32_e64 v38, 0, v38, s1                          // 00000019EE14: D5010026 00064C80
	.long 0xd41b0001                                           // 00000019EE1C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v42, vcc_lo              // 00000019EE20: 020254FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019EE28: BF870004
	v_div_fmas_f32 v35, v44, v35, v53                          // 00000019EE2C: D6370023 04D6472C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v58                  // 00000019EE34: 7C3C74FF 42CE8ED0
	v_fmac_f32_e32 v71, v43, v46                               // 00000019EE3C: 568E5D2B
	v_cvt_i32_f32_e32 v43, v62                                 // 00000019EE40: 7E56113E
	v_cndmask_b32_e64 v38, 0x7f800000, v38, s1                 // 00000019EE44: D5010026 00064CFF 7F800000
	v_div_fixup_f32 v25, v35, v41, v25                         // 00000019EE50: D6270019 04665323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v37                         // 00000019EE58: 10464AFF BFB8AA3B
	v_fma_f32 v33, -v33, v71, v60                              // 00000019EE60: D6130021 24F28F21
	.long 0xd71c002a                                           // 00000019EE68: D71C002A
	v_cndmask_b32_e32 v1, v54, v43, vcc_lo                     // 00000019EE6C: 02025736
	v_add_f32_e32 v38, 1.0, v38                                // 00000019EE70: 064C4CF2
	v_lshlrev_b32_e32 v54, 16, v129                            // 00000019EE74: 306D0290
	v_fma_f32 v45, 0xbfb8aa3b, v37, -v35                       // 00000019EE78: D613002D 848E4AFF BFB8AA3B
	.long 0x7e523999                                           // 00000019EE84: 7E523999
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000019EE88: 02545480
	s_mov_b32 vcc_lo, s0                                       // 00000019EE8C: BEEA0000
	v_div_scale_f32 v43, null, v38, v38, v27                   // 00000019EE90: D6FC7C2B 046E4D26
	v_div_fmas_f32 v33, v33, v46, v71                          // 00000019EE98: D6370021 051E5D21
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v58                  // 00000019EEA0: 7C3674FF C2B17218
	v_rndne_f32_e32 v46, v35                                   // 00000019EEA8: 7E5C4723
	v_fmac_f32_e32 v45, 0xb2a5705f, v37                        // 00000019EEAC: 565A4AFF B2A5705F
	v_mul_f32_e32 v57, 0xbfb8aa3b, v54                         // 00000019EEB4: 10726CFF BFB8AA3B
	v_div_fixup_f32 v26, v33, v36, v26                         // 00000019EEBC: D627001A 046A4921
	v_cndmask_b32_e32 v42, 0x7f800000, v42, vcc_lo             // 00000019EEC4: 025454FF 7F800000
	v_rcp_f32_e32 v33, v43                                     // 00000019EECC: 7E42552B
	v_sub_f32_e32 v35, v35, v46                                // 00000019EED0: 08465D23
	v_fma_f32 v59, 0xbfb8aa3b, v54, -v57                       // 00000019EED4: D613003B 84E66CFF BFB8AA3B
	.long 0x7e00399a                                           // 00000019EEE0: 7E00399A
	v_add_f32_e32 v36, 1.0, v42                                // 00000019EEE4: 064854F2
	v_rndne_f32_e32 v60, v57                                   // 00000019EEE8: 7E784739
	v_add_f32_e32 v35, v35, v45                                // 00000019EEEC: 06465B23
	.long 0x7f523980                                           // 00000019EEF0: 7F523980
	v_and_b32_e32 v53, 1, v0                                   // 00000019EEF4: 366A0081
	v_div_scale_f32 v34, null, v36, v36, v28                   // 00000019EEF8: D6FC7C22 04724924
	v_fma_f32 v42, -v43, v33, 1.0                              // 00000019EF00: D613002A 23CA432B
	v_exp_f32_e32 v35, v35                                     // 00000019EF08: 7E464B23
	v_fmac_f32_e32 v59, 0xb2a5705f, v54                        // 00000019EF0C: 56766CFF B2A5705F
	v_sub_f32_e32 v57, v57, v60                                // 00000019EF14: 08727939
	v_rcp_f32_e32 v44, v34                                     // 00000019EF18: 7E585522
	v_fmac_f32_e32 v33, v42, v33                               // 00000019EF1C: 5642432A
	v_div_scale_f32 v42, vcc_lo, v27, v38, v27                 // 00000019EF20: D6FC6A2A 046E4D1B
	v_and_b32_e32 v41, 1, v41                                  // 00000019EF28: 36525281
	v_add3_u32 v26, v26, v53, 0x7fff                           // 00000019EF2C: D655001A 03FE6B1A 00007FFF
	v_cvt_i32_f32_e32 v46, v46                                 // 00000019EF38: 7E5C112E
	v_add_f32_e32 v57, v57, v59                                // 00000019EF3C: 06727739
	v_mul_f32_e32 v45, v42, v33                                // 00000019EF40: 105A432A
	v_add3_u32 v25, v25, v41, 0x7fff                           // 00000019EF44: D6550019 03FE5319 00007FFF
	.long 0xd41e0001                                           // 00000019EF50: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v37, vcc_lo              // 00000019EF54: 02024AFF 42CE8ED0
	v_fma_f32 v58, -v34, v44, 1.0                              // 00000019EF5C: D613003A 23CA5922
	.long 0xd71c0023                                           // 00000019EF64: D71C0023
	v_cndmask_b32_e32 v1, v35, v46, vcc_lo                     // 00000019EF68: 02025D23
	v_fma_f32 v53, -v43, v45, v42                              // 00000019EF6C: D6130035 24AA5B2B
	v_exp_f32_e32 v46, v57                                     // 00000019EF74: 7E5C4B39
	global_store_d16_hi_b16 v[7:8], v25, off offset:128        // 00000019EF78: DC960080 007C1907
	v_fmac_f32_e32 v44, v58, v44                               // 00000019EF80: 5658593A
	v_div_scale_f32 v58, s0, v28, v36, v28                     // 00000019EF84: D6FC003A 0472491C
	v_fmac_f32_e32 v45, v53, v33                               // 00000019EF8C: 565A4335
	v_cndmask_b32_e64 v35, 0, v35, s1                          // 00000019EF90: D5010023 00064680
	.long 0xd41b0001                                           // 00000019EF98: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v37, vcc_lo              // 00000019EF9C: 02024AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v26, off offset:128      // 00000019EFA4: DC960080 007C1A2F
	v_mul_f32_e32 v61, v58, v44                                // 00000019EFAC: 107A593A
	v_fma_f32 v42, -v43, v45, v42                              // 00000019EFB0: D613002A 24AA5B2B
	v_cndmask_b32_e64 v35, 0x7f800000, v35, s1                 // 00000019EFB8: D5010023 000646FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019EFC4: BF870193
	v_fma_f32 v41, -v34, v61, v58                              // 00000019EFC8: D6130029 24EA7B22
	v_div_fmas_f32 v33, v42, v33, v45                          // 00000019EFD0: D6370021 04B6432A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v54                  // 00000019EFD8: 7C3C6CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019EFE0: BF870214
	v_add_f32_e32 v35, 1.0, v35                                // 00000019EFE4: 064646F2
	v_fmac_f32_e32 v61, v41, v44                               // 00000019EFE8: 567A5929
	v_cvt_i32_f32_e32 v41, v60                                 // 00000019EFEC: 7E52113C
	v_div_fixup_f32 v27, v33, v38, v27                         // 00000019EFF0: D627001B 046E4D21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019EFF8: BF870193
	v_fma_f32 v34, -v34, v61, v58                              // 00000019EFFC: D6130022 24EA7B22
	.long 0xd71c0025                                           // 00000019F004: D71C0025
	v_cndmask_b32_e32 v1, v46, v41, vcc_lo                     // 00000019F008: 0202532E
	v_div_scale_f32 v41, null, v35, v35, v29                   // 00000019F00C: D6FC7C29 04764723
	s_waitcnt vmcnt(3)                                         // 00000019F014: BF890FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019F018: BF8700A2
	v_dual_cndmask_b32 v37, 0, v37 :: v_dual_lshlrev_b32 v46, 16, v131// 00000019F01C: CA624A80 252F0690
	s_mov_b32 vcc_lo, s0                                       // 00000019F024: BEEA0000
	v_mul_f32_e32 v53, 0xbfb8aa3b, v46                         // 00000019F028: 106A5CFF BFB8AA3B
	v_div_fmas_f32 v34, v34, v44, v61                          // 00000019F030: D6370022 04F65922
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v54                  // 00000019F038: 7C366CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019F040: BF870193
	v_fma_f32 v57, 0xbfb8aa3b, v46, -v53                       // 00000019F044: D6130039 84D65CFF BFB8AA3B
	v_div_fixup_f32 v25, v34, v36, v28                         // 00000019F050: D6270019 04724922
	v_dual_cndmask_b32 v37, 0x7f800000, v37 :: v_dual_mul_f32 v28, v30, v51// 00000019F058: CA464AFF 251C671E 7F800000
	v_lshlrev_b32_e32 v36, 16, v87                             // 00000019F064: 3048AE90
	v_rcp_f32_e32 v30, v41                                     // 00000019F068: 7E3C5529
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019F06C: BF870193
	.long 0x7e003999                                           // 00000019F070: 7E003999
	v_add_f32_e32 v34, 1.0, v37                                // 00000019F074: 06444AF2
	v_rndne_f32_e32 v58, v53                                   // 00000019F078: 7E744735
	v_mul_f32_e32 v33, 0xbfb8aa3b, v36                         // 00000019F07C: 104248FF BFB8AA3B
	.long 0x7e4a399b                                           // 00000019F084: 7E4A399B
	.long 0x7f4a3980                                           // 00000019F088: 7F4A3980
	v_div_scale_f32 v26, null, v34, v34, v28                   // 00000019F08C: D6FC7C1A 04724522
	v_and_b32_e32 v45, 1, v0                                   // 00000019F094: 365A0081
	v_fma_f32 v43, 0xbfb8aa3b, v36, -v33                       // 00000019F098: D613002B 848648FF BFB8AA3B
	v_rndne_f32_e32 v44, v33                                   // 00000019F0A4: 7E584721
	v_fma_f32 v38, -v41, v30, 1.0                              // 00000019F0A8: D6130026 23CA3D29
	v_rcp_f32_e32 v42, v26                                     // 00000019F0B0: 7E54551A
	v_fmac_f32_e32 v57, 0xb2a5705f, v46                        // 00000019F0B4: 56725CFF B2A5705F
	v_fmac_f32_e32 v43, 0xb2a5705f, v36                        // 00000019F0BC: 565648FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000019F0C4: BF870243
	v_dual_sub_f32 v33, v33, v44 :: v_dual_fmac_f32 v30, v38, v30// 00000019F0C8: C9405921 211E3D26
	v_div_scale_f32 v38, vcc_lo, v29, v35, v29                 // 00000019F0D0: D6FC6A26 0476471D
	v_sub_f32_e32 v53, v53, v58                                // 00000019F0D8: 086A7535
	v_and_b32_e32 v37, 1, v37                                  // 00000019F0DC: 364A4A81
	v_add_f32_e32 v33, v33, v43                                // 00000019F0E0: 06425721
	v_add3_u32 v25, v25, v45, 0x7fff                           // 00000019F0E4: D6550019 03FE5B19 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000019F0F0: BF8701C5
	v_fma_f32 v54, -v26, v42, 1.0                              // 00000019F0F4: D6130036 23CA551A
	v_mul_f32_e32 v43, v38, v30                                // 00000019F0FC: 10563D26
	v_cvt_i32_f32_e32 v44, v44                                 // 00000019F100: 7E58112C
	v_exp_f32_e32 v33, v33                                     // 00000019F104: 7E424B21
	v_dual_add_f32 v53, v53, v57 :: v_dual_fmac_f32 v42, v54, v42// 00000019F108: C9007335 352A5536
	v_div_scale_f32 v54, s0, v28, v34, v28                     // 00000019F110: D6FC0036 0472451C
	v_fma_f32 v45, -v41, v43, v38                              // 00000019F118: D613002D 249A5729
	v_add3_u32 v27, v27, v37, 0x7fff                           // 00000019F120: D655001B 03FE4B1B 00007FFF
	.long 0xd41e0001                                           // 00000019F12C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v36, vcc_lo              // 00000019F130: 020248FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019F138: BF870214
	v_mul_f32_e32 v59, v54, v42                                // 00000019F13C: 10765536
	v_fmac_f32_e32 v43, v45, v30                               // 00000019F140: 56563D2D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019F144: BF870005
	.long 0xd71c0021                                           // 00000019F148: D71C0021
	v_cndmask_b32_e32 v1, v33, v44, vcc_lo                     // 00000019F14C: 02025921
	v_exp_f32_e32 v44, v53                                     // 00000019F150: 7E584B35
	global_store_d16_hi_b16 v[15:16], v27, off offset:128      // 00000019F154: DC960080 007C1B0F
	v_fma_f32 v37, -v26, v59, v54                              // 00000019F15C: D6130025 24DA771A
	v_fma_f32 v38, -v41, v43, v38                              // 00000019F164: D6130026 249A5729
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 00000019F16C: D5010021 00064280
	.long 0xd41b0001                                           // 00000019F174: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v36, vcc_lo              // 00000019F178: 020248FF C2B17218
	global_store_d16_hi_b16 v[23:24], v25, off offset:128      // 00000019F180: DC960080 007C1917
	v_fmac_f32_e32 v59, v37, v42                               // 00000019F188: 56765525
	v_cvt_i32_f32_e32 v37, v58                                 // 00000019F18C: 7E4A113A
	v_div_fmas_f32 v30, v38, v30, v43                          // 00000019F190: D637001E 04AE3D26
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v46                  // 00000019F198: 7C3C5CFF 42CE8ED0
	v_cndmask_b32_e64 v33, 0x7f800000, v33, s1                 // 00000019F1A0: D5010021 000642FF 7F800000
	v_fma_f32 v26, -v26, v59, v54                              // 00000019F1AC: D613001A 24DA771A
	.long 0xd71c0024                                           // 00000019F1B4: D71C0024
	v_cndmask_b32_e32 v1, v44, v37, vcc_lo                     // 00000019F1B8: 02024B2C
	v_div_fixup_f32 v29, v30, v35, v29                         // 00000019F1BC: D627001D 0476471E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019F1C4: BF870224
	v_dual_add_f32 v33, 1.0, v33 :: v_dual_lshlrev_b32 v44, 16, v123// 00000019F1C8: C92242F2 212CF690
	.long 0x7f463980                                           // 00000019F1D0: 7F463980
	v_cndmask_b32_e32 v36, 0, v36, vcc_lo                      // 00000019F1D4: 02484880
	s_mov_b32 vcc_lo, s0                                       // 00000019F1D8: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019F1DC: BF870003
	v_mul_f32_e32 v45, 0xbfb8aa3b, v44                         // 00000019F1E0: 105A58FF BFB8AA3B
	v_div_fmas_f32 v26, v26, v42, v59                          // 00000019F1E8: D637001A 04EE551A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v46                  // 00000019F1F0: 7C365CFF C2B17218
	v_div_scale_f32 v37, null, v33, v33, v17                   // 00000019F1F8: D6FC7C25 04464321
	.long 0x7e46399d                                           // 00000019F200: 7E46399D
	v_fma_f32 v53, 0xbfb8aa3b, v44, -v45                       // 00000019F204: D6130035 84B658FF BFB8AA3B
	v_div_fixup_f32 v26, v26, v34, v28                         // 00000019F210: D627001A 0472451A
	v_cndmask_b32_e32 v36, 0x7f800000, v36, vcc_lo             // 00000019F218: 024848FF 7F800000
	v_lshlrev_b32_e32 v34, 16, v124                            // 00000019F220: 3044F890
	v_rcp_f32_e32 v27, v37                                     // 00000019F224: 7E365525
	v_rndne_f32_e32 v54, v45                                   // 00000019F228: 7E6C472D
	.long 0x7e00399a                                           // 00000019F22C: 7E00399A
	v_add_f32_e32 v28, 1.0, v36                                // 00000019F230: 063848F2
	v_mul_f32_e32 v30, 0xbfb8aa3b, v34                         // 00000019F234: 103C44FF BFB8AA3B
	v_fmac_f32_e32 v53, 0xb2a5705f, v44                        // 00000019F23C: 566A58FF B2A5705F
	v_sub_f32_e32 v45, v45, v54                                // 00000019F244: 085A6D2D
	v_and_b32_e32 v43, 1, v0                                   // 00000019F248: 36560081
	v_div_scale_f32 v25, null, v28, v28, v18                   // 00000019F24C: D6FC7C19 044A391C
	v_fma_f32 v41, 0xbfb8aa3b, v34, -v30                       // 00000019F254: D6130029 847A44FF BFB8AA3B
	v_rndne_f32_e32 v42, v30                                   // 00000019F260: 7E54471E
	v_fma_f32 v36, -v37, v27, 1.0                              // 00000019F264: D6130024 23CA3725
	v_and_b32_e32 v35, 1, v35                                  // 00000019F26C: 36464681
	v_rcp_f32_e32 v38, v25                                     // 00000019F270: 7E4C5519
	v_fmac_f32_e32 v41, 0xb2a5705f, v34                        // 00000019F274: 565244FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000019F27C: BF870243
	v_dual_sub_f32 v30, v30, v42 :: v_dual_fmac_f32 v27, v36, v27// 00000019F280: C940551E 1E1A3724
	v_div_scale_f32 v36, vcc_lo, v17, v33, v17                 // 00000019F288: D6FC6A24 04464311
	v_add3_u32 v26, v26, v43, 0x7fff                           // 00000019F290: D655001A 03FE571A 00007FFF
	v_cvt_i32_f32_e32 v42, v42                                 // 00000019F29C: 7E54112A
	v_add_f32_e32 v30, v30, v41                                // 00000019F2A0: 063C531E
	v_add_f32_e32 v45, v45, v53                                // 00000019F2A4: 065A6B2D
	v_mul_f32_e32 v41, v36, v27                                // 00000019F2A8: 10523724
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019F2AC: BF870005
	v_fma_f32 v46, -v25, v38, 1.0                              // 00000019F2B0: D613002E 23CA4D19
	v_add3_u32 v29, v29, v35, 0x7fff                           // 00000019F2B8: D655001D 03FE471D 00007FFF
	v_exp_f32_e32 v30, v30                                     // 00000019F2C4: 7E3C4B1E
	.long 0xd41e0001                                           // 00000019F2C8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v34, vcc_lo              // 00000019F2CC: 020244FF 42CE8ED0
	v_fma_f32 v43, -v37, v41, v36                              // 00000019F2D4: D613002B 24925325
	v_fmac_f32_e32 v38, v46, v38                               // 00000019F2DC: 564C4D2E
	v_div_scale_f32 v46, s0, v18, v28, v18                     // 00000019F2E0: D6FC002E 044A3912
	s_clause 0x1                                               // 00000019F2E8: BF850001
	global_store_d16_hi_b16 v[31:32], v29, off offset:128      // 00000019F2EC: DC960080 007C1D1F
	global_store_d16_hi_b16 v[39:40], v26, off offset:128      // 00000019F2F4: DC960080 007C1A27
	v_dual_fmac_f32 v41, v43, v27 :: v_dual_lshlrev_b32 v26, 16, v126// 00000019F2FC: C822372B 291AFC90
	v_mul_f32_e32 v57, v46, v38                                // 00000019F304: 10724D2E
	.long 0xd71c001e                                           // 00000019F308: D71C001E
	v_cndmask_b32_e32 v1, v30, v42, vcc_lo                     // 00000019F30C: 0202551E
	v_exp_f32_e32 v42, v45                                     // 00000019F310: 7E544B2D
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019F314: BF870003
	v_fma_f32 v36, -v37, v41, v36                              // 00000019F318: D6130024 24925325
	.long 0x7f3a3980                                           // 00000019F320: 7F3A3980
	v_fma_f32 v35, -v25, v57, v46                              // 00000019F324: D6130023 24BA7319
	v_cndmask_b32_e64 v30, 0, v30, s1                          // 00000019F32C: D501001E 00063C80
	.long 0xd41b0001                                           // 00000019F334: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v34, vcc_lo              // 00000019F338: 020244FF C2B17218
	v_div_fmas_f32 v27, v36, v27, v41                          // 00000019F340: D637001B 04A63724
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v44                  // 00000019F348: 7C3C58FF 42CE8ED0
	v_fmac_f32_e32 v57, v35, v38                               // 00000019F350: 56724D23
	v_cvt_i32_f32_e32 v35, v54                                 // 00000019F354: 7E461136
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 00000019F358: D501001E 00063CFF 7F800000
	v_div_fixup_f32 v17, v27, v33, v17                         // 00000019F364: D6270011 0446431B
	v_mul_f32_e32 v33, 0xbfb8aa3b, v26                         // 00000019F36C: 104234FF BFB8AA3B
	v_fma_f32 v25, -v25, v57, v46                              // 00000019F374: D6130019 24BA7319
	.long 0xd71c0022                                           // 00000019F37C: D71C0022
	v_cndmask_b32_e32 v1, v42, v35, vcc_lo                     // 00000019F380: 0202472A
	v_add_f32_e32 v30, 1.0, v30                                // 00000019F384: 063C3CF2
	.long 0xd41e0001                                           // 00000019F388: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v26, vcc_lo              // 00000019F38C: 020234FF 42CE8ED0
	v_fma_f32 v41, 0xbfb8aa3b, v26, -v33                       // 00000019F394: D6130029 848634FF BFB8AA3B
	v_rndne_f32_e32 v42, v33                                   // 00000019F3A0: 7E544721
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000019F3A4: 02444480
	s_mov_b32 vcc_lo, s0                                       // 00000019F3A8: BEEA0000
	v_div_scale_f32 v35, null, v30, v30, v19                   // 00000019F3AC: D6FC7C23 044E3D1E
	v_div_fmas_f32 v25, v25, v38, v57                          // 00000019F3B4: D6370019 04E64D19
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v44                  // 00000019F3BC: 7C3658FF C2B17218
	v_dual_fmac_f32 v41, 0xb2a5705f, v26 :: v_dual_lshlrev_b32 v38, 16, v125// 00000019F3C4: C82234FF 2926FA90 B2A5705F
	v_sub_f32_e32 v33, v33, v42                                // 00000019F3D0: 08425521
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019F3D4: BF870004
	v_div_fixup_f32 v18, v25, v28, v18                         // 00000019F3D8: D6270012 044A3919
	v_cndmask_b32_e32 v34, 0x7f800000, v34, vcc_lo             // 00000019F3E0: 024444FF 7F800000
	v_rcp_f32_e32 v25, v35                                     // 00000019F3E8: 7E325523
	v_mul_f32_e32 v43, 0xbfb8aa3b, v38                         // 00000019F3EC: 10564CFF BFB8AA3B
	v_add_f32_e32 v33, v33, v41                                // 00000019F3F4: 06425321
	.long 0x7e003992                                           // 00000019F3F8: 7E003992
	v_add_f32_e32 v28, 1.0, v34                                // 00000019F3FC: 063844F2
	v_cvt_i32_f32_e32 v42, v42                                 // 00000019F400: 7E54112A
	v_fma_f32 v46, 0xbfb8aa3b, v38, -v43                       // 00000019F404: D613002E 84AE4CFF BFB8AA3B
	v_rndne_f32_e32 v53, v43                                   // 00000019F410: 7E6A472B
	v_exp_f32_e32 v33, v33                                     // 00000019F414: 7E424B21
	v_div_scale_f32 v27, null, v28, v28, v20                   // 00000019F418: D6FC7C1B 0452391C
	v_fma_f32 v34, -v35, v25, 1.0                              // 00000019F420: D6130022 23CA3323
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019F428: BF870223
	v_dual_fmac_f32 v46, 0xb2a5705f, v38 :: v_dual_sub_f32 v43, v43, v53// 00000019F42C: C80A4CFF 2E2A6B2B B2A5705F
	v_div_scale_f32 v41, s0, v20, v28, v20                     // 00000019F438: D6FC0029 04523914
	v_rcp_f32_e32 v36, v27                                     // 00000019F440: 7E48551B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019F444: BF870003
	v_fmac_f32_e32 v25, v34, v25                               // 00000019F448: 56323322
	v_div_scale_f32 v34, vcc_lo, v19, v30, v19                 // 00000019F44C: D6FC6A22 044E3D13
	v_and_b32_e32 v37, 1, v0                                   // 00000019F454: 364A0081
	v_add_f32_e32 v43, v43, v46                                // 00000019F458: 06565D2B
	.long 0xd71c0021                                           // 00000019F45C: D71C0021
	v_cndmask_b32_e32 v1, v33, v42, vcc_lo                     // 00000019F460: 02025521
	.long 0x7e3a3991                                           // 00000019F464: 7E3A3991
	v_mul_f32_e32 v45, v34, v25                                // 00000019F468: 105A3322
	v_add3_u32 v18, v18, v37, 0x7fff                           // 00000019F46C: D6550012 03FE4B12 00007FFF
	v_exp_f32_e32 v37, v43                                     // 00000019F478: 7E4A4B2B
	v_fma_f32 v44, -v27, v36, 1.0                              // 00000019F47C: D613002C 23CA491B
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 00000019F484: D5010021 00064280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019F48C: BF870122
	v_dual_fmac_f32 v36, v44, v36 :: v_dual_and_b32 v29, 1, v29// 00000019F490: C824492C 241C3A81
	v_fma_f32 v44, -v35, v45, v34                              // 00000019F498: D613002C 248A5B23
	v_add3_u32 v17, v17, v29, 0x7fff                           // 00000019F4A0: D6550011 03FE3B11 00007FFF
	v_lshlrev_b32_e32 v29, 16, v92                             // 00000019F4AC: 303AB890
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019F4B0: BF870003
	v_dual_mul_f32 v54, v41, v36 :: v_dual_fmac_f32 v45, v44, v25// 00000019F4B4: C8C04929 362C332C
	s_clause 0x1                                               // 00000019F4BC: BF850001
	global_store_d16_hi_b16 v[7:8], v17, off offset:160        // 00000019F4C0: DC9600A0 007C1107
	global_store_d16_hi_b16 v[47:48], v18, off offset:160      // 00000019F4C8: DC9600A0 007C122F
	v_fma_f32 v44, -v27, v54, v41                              // 00000019F4D0: D613002C 24A66D1B
	v_fma_f32 v34, -v35, v45, v34                              // 00000019F4D8: D6130022 248A5B23
	v_cvt_i32_f32_e32 v35, v53                                 // 00000019F4E0: 7E461135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019F4E4: BF870193
	v_fmac_f32_e32 v54, v44, v36                               // 00000019F4E8: 566C492C
	v_div_fmas_f32 v25, v34, v25, v45                          // 00000019F4EC: D6370019 04B63322
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v26                  // 00000019F4F4: 7C3634FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019F4FC: BF870004
	.long 0xd71c0022                                           // 00000019F500: D71C0022
	v_cndmask_b32_e32 v1, v37, v35, vcc_lo                     // 00000019F504: 02024725
	v_mul_f32_e32 v35, 0xbfb8aa3b, v29                         // 00000019F508: 10463AFF BFB8AA3B
	v_fma_f32 v27, -v27, v54, v41                              // 00000019F510: D613001B 24A66D1B
	v_div_fixup_f32 v17, v25, v30, v19                         // 00000019F518: D6270011 044E3D19
	v_cndmask_b32_e32 v26, 0x7f800000, v33, vcc_lo             // 00000019F520: 023442FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 00000019F528: 7C3C4CFF 42CE8ED0
	.long 0x7f3c3980                                           // 00000019F530: 7F3C3980
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019F534: BF870214
	.long 0x7e3c3991                                           // 00000019F538: 7E3C3991
	v_add_f32_e32 v26, 1.0, v26                                // 00000019F53C: 063434F2
	v_cndmask_b32_e32 v33, 0, v34, vcc_lo                      // 00000019F540: 02424480
	s_mov_b32 vcc_lo, s0                                       // 00000019F544: BEEA0000
	v_div_fmas_f32 v27, v27, v36, v54                          // 00000019F548: D637001B 04DA491B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 00000019F550: 7C364CFF C2B17218
	v_rndne_f32_e32 v36, v35                                   // 00000019F558: 7E484723
	s_waitcnt vmcnt(2)                                         // 00000019F55C: BF890BF7
	v_lshlrev_b32_e32 v38, 16, v68                             // 00000019F560: 304C8890
	v_and_b32_e32 v30, 1, v30                                  // 00000019F564: 363C3C81
	v_div_fixup_f32 v20, v27, v28, v20                         // 00000019F568: D6270014 0452391B
	v_cndmask_b32_e32 v33, 0x7f800000, v33, vcc_lo             // 00000019F570: 024242FF 7F800000
	v_div_scale_f32 v27, null, v26, v26, v21                   // 00000019F578: D6FC7C1B 0456351A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019F580: BF870214
	v_add3_u32 v17, v17, v30, 0x7fff                           // 00000019F584: D6550011 03FE3D11 00007FFF
	.long 0x7e003994                                           // 00000019F590: 7E003994
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019F594: BF870214
	v_add_f32_e32 v28, 1.0, v33                                // 00000019F598: 063842F2
	v_rcp_f32_e32 v19, v27                                     // 00000019F59C: 7E26551B
	global_store_d16_hi_b16 v[15:16], v17, off offset:160      // 00000019F5A0: DC9600A0 007C110F
	v_and_b32_e32 v33, 1, v0                                   // 00000019F5A8: 36420081
	v_div_scale_f32 v25, null, v28, v28, v22                   // 00000019F5AC: D6FC7C19 045A391C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019F5B4: BF870112
	v_add3_u32 v20, v20, v33, 0x7fff                           // 00000019F5B8: D6550014 03FE4314 00007FFF
	v_rcp_f32_e32 v34, v25                                     // 00000019F5C4: 7E445519
	v_fma_f32 v18, -v27, v19, 1.0                              // 00000019F5C8: D6130012 23CA271B
	v_fma_f32 v33, 0xbfb8aa3b, v29, -v35                       // 00000019F5D0: D6130021 848E3AFF BFB8AA3B
	v_sub_f32_e32 v35, v35, v36                                // 00000019F5DC: 08464923
	v_cvt_i32_f32_e32 v36, v36                                 // 00000019F5E0: 7E481124
	global_store_d16_hi_b16 v[23:24], v20, off offset:160      // 00000019F5E4: DC9600A0 007C1417
	v_fmac_f32_e32 v19, v18, v19                               // 00000019F5EC: 56262712
	v_div_scale_f32 v18, vcc_lo, v21, v26, v21                 // 00000019F5F0: D6FC6A12 04563515
	v_fmac_f32_e32 v33, 0xb2a5705f, v29                        // 00000019F5F8: 56423AFF B2A5705F
	v_fma_f32 v37, -v25, v34, 1.0                              // 00000019F600: D6130025 23CA4519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019F608: BF870193
	v_mul_f32_e32 v41, v18, v19                                // 00000019F60C: 10522712
	v_add_f32_e32 v33, v35, v33                                // 00000019F610: 06424323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v38                         // 00000019F614: 10464CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019F61C: BF870004
	v_fmac_f32_e32 v34, v37, v34                               // 00000019F620: 56444525
	v_div_scale_f32 v37, s0, v22, v28, v22                     // 00000019F624: D6FC0025 045A3916
	v_fma_f32 v30, -v27, v41, v18                              // 00000019F62C: D613001E 244A531B
	v_exp_f32_e32 v33, v33                                     // 00000019F634: 7E424B21
	v_fma_f32 v43, 0xbfb8aa3b, v38, -v35                       // 00000019F638: D613002B 848E4CFF BFB8AA3B
	v_rndne_f32_e32 v44, v35                                   // 00000019F644: 7E584723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019F648: BF870193
	v_dual_mul_f32 v42, v37, v34 :: v_dual_fmac_f32 v41, v30, v19// 00000019F64C: C8C04525 2A28271E
	v_fmac_f32_e32 v43, 0xb2a5705f, v38                        // 00000019F654: 56564CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019F65C: BF870193
	v_sub_f32_e32 v35, v35, v44                                // 00000019F660: 08465923
	v_fma_f32 v30, -v25, v42, v37                              // 00000019F664: D613001E 24965519
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000019F66C: BF870294
	v_fma_f32 v17, -v27, v41, v18                              // 00000019F670: D6130011 244A531B
	.long 0xd71c0012                                           // 00000019F678: D71C0012
	v_cndmask_b32_e32 v1, v33, v36, vcc_lo                     // 00000019F67C: 02024921
	v_cvt_i32_f32_e32 v20, v44                                 // 00000019F680: 7E28112C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019F684: BF870214
	v_dual_add_f32 v27, v35, v43 :: v_dual_fmac_f32 v42, v30, v34// 00000019F688: C9005723 1B2A451E
	v_div_fmas_f32 v17, v17, v19, v41                          // 00000019F690: D6370011 04A62711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 00000019F698: 7C3C3AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019F6A0: BF870213
	v_fma_f32 v19, -v25, v42, v37                              // 00000019F6A4: D6130013 24965519
	v_exp_f32_e32 v25, v27                                     // 00000019F6AC: 7E324B1B
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000019F6B0: 02242480
	s_mov_b32 vcc_lo, s0                                       // 00000019F6B4: BEEA0000
	v_div_fixup_f32 v17, v17, v26, v21                         // 00000019F6B8: D6270011 04563511
	v_div_fmas_f32 v19, v19, v34, v42                          // 00000019F6C0: D6370013 04AA4513
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 00000019F6C8: 7C363AFF C2B17218
	.long 0x7f2a3980                                           // 00000019F6D0: 7F2A3980
	v_lshlrev_b32_e32 v34, 16, v70                             // 00000019F6D4: 30448C90
	.long 0x7e2a3991                                           // 00000019F6D8: 7E2A3991
	v_div_fixup_f32 v19, v19, v28, v22                         // 00000019F6DC: D6270013 045A3913
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 00000019F6E4: 022424FF 7F800000
	.long 0xd71c0014                                           // 00000019F6EC: D71C0014
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 00000019F6F0: 02022919
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 00000019F6F4: 7C3C4CFF 42CE8ED0
	v_lshlrev_b32_e32 v25, 16, v104                            // 00000019F6FC: 3032D090
	.long 0x7e003993                                           // 00000019F700: 7E003993
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_and_b32 v21, 1, v21 // 00000019F704: C92424F2 12142A81
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 00000019F70C: 02282880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 00000019F710: 7C364CFF C2B17218
	v_mul_f32_e32 v27, 0xbfb8aa3b, v25                         // 00000019F718: 103632FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000019F720: BF870234
	v_div_scale_f32 v22, null, v18, v18, v9                    // 00000019F724: D6FC7C16 04262512
	v_dual_mul_f32 v37, 0xbfb8aa3b, v34 :: v_dual_and_b32 v28, 1, v0// 00000019F72C: C8E444FF 251C0081 BFB8AA3B
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 00000019F738: 022828FF 7F800000
	v_fma_f32 v29, 0xbfb8aa3b, v25, -v27                       // 00000019F740: D613001D 846E32FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000019F74C: BF8701B4
	v_rcp_f32_e32 v26, v22                                     // 00000019F750: 7E345516
	v_rndne_f32_e32 v30, v27                                   // 00000019F754: 7E3C471B
	v_add3_u32 v17, v17, v21, 0x7fff                           // 00000019F758: D6550011 03FE2B11 00007FFF
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_fmac_f32 v29, 0xb2a5705f, v25// 00000019F764: C90028F2 141C32FF B2A5705F
	v_add3_u32 v19, v19, v28, 0x7fff                           // 00000019F770: D6550013 03FE3913 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019F77C: BF870224
	v_sub_f32_e32 v27, v27, v30                                // 00000019F780: 08363D1B
	v_rndne_f32_e32 v28, v37                                   // 00000019F784: 7E384725
	v_div_scale_f32 v33, null, v20, v20, v10                   // 00000019F788: D6FC7C21 042A2914
	v_cvt_i32_f32_e32 v30, v30                                 // 00000019F790: 7E3C111E
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019F794: BF870005
	v_fma_f32 v35, -v22, v26, 1.0                              // 00000019F798: D6130023 23CA3516
	v_add_f32_e32 v21, v27, v29                                // 00000019F7A0: 062A3B1B
	v_fma_f32 v27, 0xbfb8aa3b, v34, -v37                       // 00000019F7A4: D613001B 849644FF BFB8AA3B
	v_rcp_f32_e32 v36, v33                                     // 00000019F7B0: 7E485521
	v_div_scale_f32 v29, vcc_lo, v9, v18, v9                   // 00000019F7B4: D6FC6A1D 04262509
	v_fmac_f32_e32 v26, v35, v26                               // 00000019F7BC: 56343523
	v_exp_f32_e32 v21, v21                                     // 00000019F7C0: 7E2A4B15
	v_fmac_f32_e32 v27, 0xb2a5705f, v34                        // 00000019F7C4: 563644FF B2A5705F
	v_sub_f32_e32 v37, v37, v28                                // 00000019F7CC: 084A3925
	global_store_d16_hi_b16 v[31:32], v17, off offset:160      // 00000019F7D0: DC9600A0 007C111F
	v_mul_f32_e32 v38, v29, v26                                // 00000019F7D8: 104C351D
	.long 0xd41e0001                                           // 00000019F7DC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 00000019F7E0: 020232FF 42CE8ED0
	v_cvt_i32_f32_e32 v28, v28                                 // 00000019F7E8: 7E38111C
	v_fma_f32 v35, -v33, v36, 1.0                              // 00000019F7EC: D6130023 23CA4921
	v_add_f32_e32 v27, v37, v27                                // 00000019F7F4: 06363725
	global_store_d16_hi_b16 v[39:40], v19, off offset:160      // 00000019F7F8: DC9600A0 007C1327
	.long 0xd71c0011                                           // 00000019F800: D71C0011
	v_cndmask_b32_e32 v1, v21, v30, vcc_lo                     // 00000019F804: 02023D15
	v_fma_f32 v21, -v22, v38, v29                              // 00000019F808: D6130015 24764D16
	v_fmac_f32_e32 v36, v35, v36                               // 00000019F810: 56484923
	v_div_scale_f32 v35, s0, v10, v20, v10                     // 00000019F814: D6FC0023 042A290A
	v_exp_f32_e32 v27, v27                                     // 00000019F81C: 7E364B1B
	v_cndmask_b32_e64 v17, 0, v17, s1                          // 00000019F820: D5010011 00062280
	v_fmac_f32_e32 v38, v21, v26                               // 00000019F828: 564C3515
	.long 0xd41b0001                                           // 00000019F82C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v25, vcc_lo              // 00000019F830: 020232FF C2B17218
	v_dual_mul_f32 v30, v35, v36 :: v_dual_lshlrev_b32 v19, 16, v106// 00000019F838: C8E24923 1E12D490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019F840: BF870193
	v_fma_f32 v22, -v22, v38, v29                              // 00000019F844: D6130016 24764D16
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s1                 // 00000019F84C: D5010011 000622FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019F858: BF870213
	v_fma_f32 v21, -v33, v30, v35                              // 00000019F85C: D6130015 248E3D21
	.long 0xd41e0001                                           // 00000019F864: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v19, vcc_lo              // 00000019F868: 020226FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019F870: BF870224
	v_div_fmas_f32 v22, v22, v26, v38                          // 00000019F874: D6370016 049A3516
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 00000019F87C: 7C3C44FF 42CE8ED0
	v_fmac_f32_e32 v30, v21, v36                               // 00000019F884: 563C4915
	.long 0xd71c0015                                           // 00000019F888: D71C0015
	v_cndmask_b32_e32 v1, v27, v28, vcc_lo                     // 00000019F88C: 0202391B
	v_add_f32_e32 v17, 1.0, v17                                // 00000019F890: 062222F2
	v_div_fixup_f32 v9, v22, v18, v9                           // 00000019F894: D6270009 04262516
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019F89C: BF870214
	v_fma_f32 v25, -v33, v30, v35                              // 00000019F8A0: D6130019 248E3D21
	v_cndmask_b32_e32 v21, 0, v21, vcc_lo                      // 00000019F8A8: 022A2A80
	s_mov_b32 vcc_lo, s0                                       // 00000019F8AC: BEEA0000
	v_div_scale_f32 v26, null, v17, v17, v11                   // 00000019F8B0: D6FC7C1A 042E2311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000019F8B8: BF870233
	v_div_fmas_f32 v25, v25, v36, v30                          // 00000019F8BC: D6370019 047A4919
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 00000019F8C4: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v34, 16, v105                            // 00000019F8CC: 3044D290
	v_rcp_f32_e32 v27, v26                                     // 00000019F8D0: 7E36551A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019F8D4: BF870003
	v_div_fixup_f32 v10, v25, v20, v10                         // 00000019F8D8: D627000A 042A2919
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 00000019F8E0: 022A2AFF 7F800000
	v_mul_f32_e32 v25, 0xbfb8aa3b, v19                         // 00000019F8E8: 103226FF BFB8AA3B
	v_div_scale_f32 v33, vcc_lo, v11, v17, v11                 // 00000019F8F0: D6FC6A21 042E230B
	v_mul_f32_e32 v36, 0xbfb8aa3b, v34                         // 00000019F8F8: 104844FF BFB8AA3B
	.long 0x7e00398a                                           // 00000019F900: 7E00398A
	v_add_f32_e32 v18, 1.0, v21                                // 00000019F904: 06242AF2
	v_fma_f32 v29, 0xbfb8aa3b, v19, -v25                       // 00000019F908: D613001D 846626FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019F914: BF870005
	v_fma_f32 v21, -v26, v27, 1.0                              // 00000019F918: D6130015 23CA371A
	v_rndne_f32_e32 v30, v25                                   // 00000019F920: 7E3C4719
	v_and_b32_e32 v28, 1, v0                                   // 00000019F924: 36380081
	v_div_scale_f32 v22, null, v18, v18, v12                   // 00000019F928: D6FC7C16 04322512
	v_fmac_f32_e32 v29, 0xb2a5705f, v19                        // 00000019F930: 563A26FF B2A5705F
	v_fmac_f32_e32 v27, v21, v27                               // 00000019F938: 56363715
	v_sub_f32_e32 v25, v25, v30                                // 00000019F93C: 08323D19
	.long 0x7e283989                                           // 00000019F940: 7E283989
	v_rcp_f32_e32 v21, v22                                     // 00000019F944: 7E2A5516
	.long 0x7f283980                                           // 00000019F948: 7F283980
	v_mul_f32_e32 v35, v33, v27                                // 00000019F94C: 10463721
	v_add_f32_e32 v25, v25, v29                                // 00000019F950: 06323B19
	v_fma_f32 v37, 0xbfb8aa3b, v34, -v36                       // 00000019F954: D6130025 849244FF BFB8AA3B
	v_rndne_f32_e32 v38, v36                                   // 00000019F960: 7E4C4724
	v_add3_u32 v10, v10, v28, 0x7fff                           // 00000019F964: D655000A 03FE390A 00007FFF
	v_and_b32_e32 v20, 1, v20                                  // 00000019F970: 36282881
	v_fma_f32 v29, -v26, v35, v33                              // 00000019F974: D613001D 2486471A
	v_exp_f32_e32 v25, v25                                     // 00000019F97C: 7E324B19
	v_fma_f32 v28, -v22, v21, 1.0                              // 00000019F980: D613001C 23CA2B16
	v_fmac_f32_e32 v37, 0xb2a5705f, v34                        // 00000019F988: 564A44FF B2A5705F
	v_sub_f32_e32 v36, v36, v38                                // 00000019F990: 08484D24
	v_add3_u32 v9, v9, v20, 0x7fff                             // 00000019F994: D6550009 03FE2909 00007FFF
	v_cvt_i32_f32_e32 v20, v30                                 // 00000019F9A0: 7E28111E
	v_fmac_f32_e32 v21, v28, v21                               // 00000019F9A4: 562A2B1C
	v_div_scale_f32 v28, s0, v12, v18, v12                     // 00000019F9A8: D6FC001C 0432250C
	v_dual_fmac_f32 v35, v29, v27 :: v_dual_add_f32 v30, v36, v37// 00000019F9B0: C808371D 231E4B24
	global_store_d16_hi_b16 v[7:8], v9, off offset:192         // 00000019F9B8: DC9600C0 007C0907
	.long 0xd71c0009                                           // 00000019F9C0: D71C0009
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 00000019F9C4: 02022919
	v_mul_f32_e32 v29, v28, v21                                // 00000019F9C8: 103A2B1C
	v_fma_f32 v20, -v26, v35, v33                              // 00000019F9CC: D6130014 2486471A
	v_exp_f32_e32 v26, v30                                     // 00000019F9D4: 7E344B1E
	global_store_d16_hi_b16 v[47:48], v10, off offset:192      // 00000019F9D8: DC9600C0 007C0A2F
	v_cndmask_b32_e64 v9, 0, v9, s1                            // 00000019F9E0: D5010009 00061280
	v_fma_f32 v25, -v22, v29, v28                              // 00000019F9E8: D6130019 24723B16
	v_div_fmas_f32 v20, v20, v27, v35                          // 00000019F9F0: D6370014 048E3714
	v_cvt_i32_f32_e32 v27, v38                                 // 00000019F9F8: 7E361126
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v19                  // 00000019F9FC: 7C3626FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019FA04: BF870214
	v_fmac_f32_e32 v29, v25, v21                               // 00000019FA08: 563A2B19
	v_div_fixup_f32 v11, v20, v17, v11                         // 00000019FA0C: D627000B 042E2314
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019FA14: BF870004
	.long 0xd71c0011                                           // 00000019FA18: D71C0011
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000019FA1C: 0202371A
	v_cndmask_b32_e32 v9, 0x7f800000, v9, vcc_lo               // 00000019FA20: 021212FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 00000019FA28: 7C3C44FF 42CE8ED0
	v_fma_f32 v19, -v22, v29, v28                              // 00000019FA30: D6130013 24723B16
	s_waitcnt vmcnt(1)                                         // 00000019FA38: BF8907F7
	v_lshlrev_b32_e32 v25, 16, v67                             // 00000019FA3C: 30328690
	.long 0x7e2c398b                                           // 00000019FA40: 7E2C398B
	v_add_f32_e32 v9, 1.0, v9                                  // 00000019FA44: 061212F2
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000019FA48: 02222280
	s_mov_b32 vcc_lo, s0                                       // 00000019FA4C: BEEA0000
	v_mul_f32_e32 v30, 0xbfb8aa3b, v25                         // 00000019FA50: 103C32FF BFB8AA3B
	v_div_fmas_f32 v19, v19, v21, v29                          // 00000019FA58: D6370013 04762B13
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 00000019FA60: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v21, 16, v69                             // 00000019FA68: 302A8A90
	v_div_scale_f32 v20, null, v9, v9, v13                     // 00000019FA6C: D6FC7C14 04361309
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v30                       // 00000019FA74: D6130022 847A32FF BFB8AA3B
	v_div_fixup_f32 v12, v19, v18, v12                         // 00000019FA80: D627000C 04322513
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 00000019FA88: 022222FF 7F800000
	v_mul_f32_e32 v19, 0xbfb8aa3b, v21                         // 00000019FA90: 10262AFF BFB8AA3B
	v_rcp_f32_e32 v18, v20                                     // 00000019FA98: 7E245514
	v_rndne_f32_e32 v35, v30                                   // 00000019FA9C: 7E46471E
	v_fmac_f32_e32 v34, 0xb2a5705f, v25                        // 00000019FAA0: 564432FF B2A5705F
	v_add_f32_e32 v17, 1.0, v17                                // 00000019FAA8: 062222F2
	v_fma_f32 v27, 0xbfb8aa3b, v21, -v19                       // 00000019FAAC: D613001B 844E2AFF BFB8AA3B
	v_rndne_f32_e32 v28, v19                                   // 00000019FAB8: 7E384713
	.long 0xd41e0001                                           // 00000019FABC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v21, vcc_lo              // 00000019FAC0: 02022AFF 42CE8ED0
	.long 0x7e00398c                                           // 00000019FAC8: 7E00398C
	v_div_scale_f32 v26, null, v17, v17, v14                   // 00000019FACC: D6FC7C1A 043A2311
	v_fmac_f32_e32 v27, 0xb2a5705f, v21                        // 00000019FAD4: 56362AFF B2A5705F
	v_sub_f32_e32 v19, v19, v28                                // 00000019FADC: 08263913
	v_fma_f32 v29, -v20, v18, 1.0                              // 00000019FAE0: D613001D 23CA2514
	v_cvt_i32_f32_e32 v28, v28                                 // 00000019FAE8: 7E38111C
	v_rcp_f32_e32 v33, v26                                     // 00000019FAEC: 7E42551A
	.long 0x7f2c3980                                           // 00000019FAF0: 7F2C3980
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000019FAF4: BF8701B3
	v_dual_add_f32 v19, v19, v27 :: v_dual_fmac_f32 v18, v29, v18// 00000019FAF8: C9003713 1312251D
	v_div_scale_f32 v27, vcc_lo, v13, v9, v13                  // 00000019FB00: D6FC6A1B 0436130D
	v_dual_sub_f32 v29, v30, v35 :: v_dual_and_b32 v36, 1, v0  // 00000019FB08: C964471E 1D240081
	v_exp_f32_e32 v19, v19                                     // 00000019FB10: 7E264B13
	v_and_b32_e32 v22, 1, v22                                  // 00000019FB14: 362C2C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000019FB18: BF870313
	v_mul_f32_e32 v37, v27, v18                                // 00000019FB1C: 104A251B
	v_fma_f32 v30, -v26, v33, 1.0                              // 00000019FB20: D613001E 23CA431A
	v_add_f32_e32 v29, v29, v34                                // 00000019FB28: 063A451D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019FB2C: BF870214
	v_add3_u32 v10, v11, v22, 0x7fff                           // 00000019FB30: D655000A 03FE2D0B 00007FFF
	v_fma_f32 v34, -v20, v37, v27                              // 00000019FB3C: D6130022 246E4B14
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019FB44: BF870004
	v_fmac_f32_e32 v33, v30, v33                               // 00000019FB48: 5642431E
	v_div_scale_f32 v30, s0, v14, v17, v14                     // 00000019FB4C: D6FC001E 043A230E
	v_exp_f32_e32 v29, v29                                     // 00000019FB54: 7E3A4B1D
	.long 0xd71c0013                                           // 00000019FB58: D71C0013
	v_cndmask_b32_e32 v1, v19, v28, vcc_lo                     // 00000019FB5C: 02023913
	v_fmac_f32_e32 v37, v34, v18                               // 00000019FB60: 564A2522
	v_cvt_i32_f32_e32 v34, v35                                 // 00000019FB64: 7E441123
	v_mul_f32_e32 v28, v30, v33                                // 00000019FB68: 1038431E
	v_add3_u32 v11, v12, v36, 0x7fff                           // 00000019FB6C: D655000B 03FE490C 00007FFF
	v_cndmask_b32_e64 v19, 0, v19, s1                          // 00000019FB78: D5010013 00062680
	.long 0xd41b0001                                           // 00000019FB80: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v21, vcc_lo              // 00000019FB84: 02022AFF C2B17218
	v_fma_f32 v20, -v20, v37, v27                              // 00000019FB8C: D6130014 246E4B14
	v_fma_f32 v35, -v26, v28, v30                              // 00000019FB94: D6130023 247A391A
	.long 0xd71c001b                                           // 00000019FB9C: D71C001B
	v_cndmask_b32_e32 v1, v29, v34, vcc_lo                     // 00000019FBA0: 0202451D
	global_store_d16_hi_b16 v[15:16], v10, off offset:192      // 00000019FBA4: DC9600C0 007C0A0F
	v_cndmask_b32_e64 v19, 0x7f800000, v19, s1                 // 00000019FBAC: D5010013 000626FF 7F800000
	.long 0xd41e0001                                           // 00000019FBB8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 00000019FBBC: 020232FF 42CE8ED0
	v_fmac_f32_e32 v28, v35, v33                               // 00000019FBC4: 56384323
	v_div_fmas_f32 v18, v20, v18, v37                          // 00000019FBC8: D6370012 04962514
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000019FBD0: 7C3632FF C2B17218
	v_add_f32_e32 v19, 1.0, v19                                // 00000019FBD8: 062626F2
	v_cndmask_b32_e64 v21, 0, v27, s1                          // 00000019FBDC: D5010015 00063680
	v_fma_f32 v20, -v26, v28, v30                              // 00000019FBE4: D6130014 247A391A
	v_div_fixup_f32 v9, v18, v9, v13                           // 00000019FBEC: D6270009 04361312
	global_store_d16_hi_b16 v[23:24], v11, off offset:192      // 00000019FBF4: DC9600C0 007C0B17
	v_div_scale_f32 v26, null, v19, v19, v1                    // 00000019FBFC: D6FC7C1A 04062713
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 00000019FC04: 022A2AFF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 00000019FC0C: BEEA0000
	v_lshlrev_b32_e32 v18, 16, v56                             // 00000019FC10: 30247090
	v_div_fmas_f32 v20, v20, v33, v28                          // 00000019FC14: D6370014 04724314
	v_rcp_f32_e32 v25, v26                                     // 00000019FC1C: 7E32551A
	v_add_f32_e32 v21, 1.0, v21                                // 00000019FC20: 062A2AF2
	v_lshlrev_b32_e32 v29, 16, v55                             // 00000019FC24: 303A6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019FC28: BF870223
	v_div_fixup_f32 v12, v20, v17, v14                         // 00000019FC2C: D627000C 043A2314
	.long 0x7e223989                                           // 00000019FC34: 7E223989
	v_div_scale_f32 v14, null, v21, v21, v2                    // 00000019FC38: D6FC7C0E 040A2B15
	.long 0x7f223980                                           // 00000019FC40: 7F223980
	v_mul_f32_e32 v30, 0xbfb8aa3b, v29                         // 00000019FC44: 103C3AFF BFB8AA3B
	.long 0x7e00398c                                           // 00000019FC4C: 7E00398C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000019FC50: BF8701B5
	v_fma_f32 v10, -v26, v25, 1.0                              // 00000019FC54: D613000A 23CA331A
	v_rcp_f32_e32 v13, v14                                     // 00000019FC5C: 7E1A550E
	v_and_b32_e32 v17, 1, v17                                  // 00000019FC60: 36222281
	v_and_b32_e32 v11, 1, v0                                   // 00000019FC64: 36160081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019FC68: BF870223
	v_fmac_f32_e32 v25, v10, v25                               // 00000019FC6C: 5632330A
	v_div_scale_f32 v10, vcc_lo, v1, v19, v1                   // 00000019FC70: D6FC6A0A 04062701
	v_add3_u32 v9, v9, v17, 0x7fff                             // 00000019FC78: D6550009 03FE2309 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019FC84: BF870224
	v_add3_u32 v11, v12, v11, 0x7fff                           // 00000019FC88: D655000B 03FE170C 00007FFF
	v_mul_f32_e32 v12, 0xbfb8aa3b, v18                         // 00000019FC94: 101824FF BFB8AA3B
	v_mul_f32_e32 v20, v10, v25                                // 00000019FC9C: 1028330A
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000019FCA0: BF870005
	v_fma_f32 v22, -v14, v13, 1.0                              // 00000019FCA4: D6130016 23CA1B0E
	s_clause 0x1                                               // 00000019FCAC: BF850001
	global_store_d16_hi_b16 v[31:32], v9, off offset:192       // 00000019FCB0: DC9600C0 007C091F
	global_store_d16_hi_b16 v[39:40], v11, off offset:192      // 00000019FCB8: DC9600C0 007C0B27
	v_fma_f32 v27, 0xbfb8aa3b, v18, -v12                       // 00000019FCC0: D613001B 843224FF BFB8AA3B
	v_fma_f32 v17, -v26, v20, v10                              // 00000019FCCC: D6130011 242A291A
	v_fmac_f32_e32 v13, v22, v13                               // 00000019FCD4: 561A1B16
	v_div_scale_f32 v22, s0, v2, v21, v2                       // 00000019FCD8: D6FC0016 040A2B02
	v_rndne_f32_e32 v28, v12                                   // 00000019FCE0: 7E38470C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019FCE4: BF870114
	v_dual_fmac_f32 v27, 0xb2a5705f, v18 :: v_dual_fmac_f32 v20, v17, v25// 00000019FCE8: C80024FF 1B143311 B2A5705F
	v_dual_mul_f32 v17, v22, v13 :: v_dual_sub_f32 v12, v12, v28// 00000019FCF4: C8CA1B16 110C390C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000019FCFC: BF8701A2
	v_fma_f32 v9, -v26, v20, v10                               // 00000019FD00: D6130009 242A291A
	v_fma_f32 v26, 0xbfb8aa3b, v29, -v30                       // 00000019FD08: D613001A 847A3AFF BFB8AA3B
	v_fma_f32 v10, -v14, v17, v22                              // 00000019FD14: D613000A 245A230E
	s_delay_alu instid0(VALU_DEP_4)                            // 00000019FD1C: BF870004
	v_add_f32_e32 v12, v12, v27                                // 00000019FD20: 0618370C
	v_rndne_f32_e32 v27, v30                                   // 00000019FD24: 7E36471E
	v_div_fmas_f32 v9, v9, v25, v20                            // 00000019FD28: D6370009 04523309
	v_fmac_f32_e32 v26, 0xb2a5705f, v29                        // 00000019FD30: 56343AFF B2A5705F
	v_fmac_f32_e32 v17, v10, v13                               // 00000019FD38: 56221B0A
	v_exp_f32_e32 v10, v12                                     // 00000019FD3C: 7E144B0C
	v_sub_f32_e32 v12, v30, v27                                // 00000019FD40: 0818371E
	v_lshlrev_b32_e32 v20, 16, v63                             // 00000019FD44: 30287E90
	v_cvt_i32_f32_e32 v25, v28                                 // 00000019FD48: 7E32111C
	v_fma_f32 v14, -v14, v17, v22                              // 00000019FD4C: D613000E 245A230E
	s_waitcnt vmcnt(0)                                         // 00000019FD54: BF8903F7
	v_lshlrev_b32_e32 v22, 16, v64                             // 00000019FD58: 302C8090
	v_add_f32_e32 v12, v12, v26                                // 00000019FD5C: 0618350C
	v_mul_f32_e32 v26, 0xbfb8aa3b, v20                         // 00000019FD60: 103428FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v18                  // 00000019FD68: 7C3C24FF 42CE8ED0
	v_cvt_i32_f32_e32 v27, v27                                 // 00000019FD70: 7E36111B
	v_mul_f32_e32 v28, 0xbfb8aa3b, v22                         // 00000019FD74: 10382CFF BFB8AA3B
	.long 0xd71c000a                                           // 00000019FD7C: D71C000A
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 00000019FD80: 0202330A
	v_fma_f32 v25, 0xbfb8aa3b, v20, -v26                       // 00000019FD84: D6130019 846A28FF BFB8AA3B
	v_rndne_f32_e32 v30, v26                                   // 00000019FD90: 7E3C471A
	v_exp_f32_e32 v12, v12                                     // 00000019FD94: 7E184B0C
	v_fma_f32 v33, 0xbfb8aa3b, v22, -v28                       // 00000019FD98: D6130021 84722CFF BFB8AA3B
	v_rndne_f32_e32 v34, v28                                   // 00000019FDA4: 7E44471C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019FDA8: BF870223
	v_dual_fmac_f32 v25, 0xb2a5705f, v20 :: v_dual_sub_f32 v26, v26, v30// 00000019FDAC: C80A28FF 191A3D1A B2A5705F
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000019FDB8: 02141480
	v_fmac_f32_e32 v33, 0xb2a5705f, v22                        // 00000019FDBC: 56422CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 00000019FDC4: BF8702B4
	v_sub_f32_e32 v28, v28, v34                                // 00000019FDC8: 0838451C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v18                  // 00000019FDCC: 7C3624FF C2B17218
	v_add_f32_e32 v25, v26, v25                                // 00000019FDD4: 0632331A
	.long 0xd71c000c                                           // 00000019FDD8: D71C000C
	v_cndmask_b32_e32 v1, v12, v27, vcc_lo                     // 00000019FDDC: 0202370C
	v_cvt_i32_f32_e32 v27, v34                                 // 00000019FDE0: 7E361122
	v_add_f32_e32 v26, v28, v33                                // 00000019FDE4: 0634431C
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo             // 00000019FDE8: 021414FF 7F800000
	v_exp_f32_e32 v18, v25                                     // 00000019FDF0: 7E244B19
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 00000019FDF4: 7C3C3AFF 42CE8ED0
	v_div_fixup_f32 v1, v9, v19, v1                            // 00000019FDFC: D6270001 04062709
	v_exp_f32_e32 v25, v26                                     // 00000019FE04: 7E324B1A
	v_cvt_i32_f32_e32 v26, v30                                 // 00000019FE08: 7E34111E
	v_add_f32_e32 v10, 1.0, v10                                // 00000019FE0C: 061414F2
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 00000019FE10: 02181880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 00000019FE14: 7C363AFF C2B17218
	.long 0x7e443981                                           // 00000019FE1C: 7E443981
	.long 0x7f443980                                           // 00000019FE20: 7F443980
	.long 0xd71c0012                                           // 00000019FE24: D71C0012
	v_cndmask_b32_e32 v1, v18, v26, vcc_lo                     // 00000019FE28: 02023512
	v_div_scale_f32 v26, null, v10, v10, v3                    // 00000019FE2C: D6FC7C1A 040E150A
	v_cndmask_b32_e32 v12, 0x7f800000, v12, vcc_lo             // 00000019FE34: 021818FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v20                  // 00000019FE3C: 7C3C28FF 42CE8ED0
	.long 0xd71c0019                                           // 00000019FE44: D71C0019
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 00000019FE48: 02023719
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019FE4C: BF870194
	v_rcp_f32_e32 v27, v26                                     // 00000019FE50: 7E36551A
	v_add_f32_e32 v12, 1.0, v12                                // 00000019FE54: 061818F2
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000019FE58: 02242480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v22                  // 00000019FE5C: 7C3C2CFF 42CE8ED0
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000019FE64: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v20                  // 00000019FE68: 7C3628FF C2B17218
	v_div_scale_f32 v20, null, v12, v12, v4                    // 00000019FE70: D6FC7C14 0412190C
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 00000019FE78: 022424FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v22                  // 00000019FE80: 7C362CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019FE88: BF870113
	v_rcp_f32_e32 v28, v20                                     // 00000019FE8C: 7E385514
	v_add_f32_e32 v18, 1.0, v18                                // 00000019FE90: 062424F2
	v_cndmask_b32_e32 v22, 0x7f800000, v25, vcc_lo             // 00000019FE94: 022C32FF 7F800000
	v_fma_f32 v25, -v26, v27, 1.0                              // 00000019FE9C: D6130019 23CA371A
	s_mov_b32 vcc_lo, s0                                       // 00000019FEA4: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019FEA8: BF870193
	v_div_scale_f32 v29, null, v18, v18, v5                    // 00000019FEAC: D6FC7C1D 04162512
	v_add_f32_e32 v22, 1.0, v22                                // 00000019FEB4: 062C2CF2
	v_div_fmas_f32 v13, v14, v13, v17                          // 00000019FEB8: D637000D 04461B0E
	v_fmac_f32_e32 v27, v25, v27                               // 00000019FEC0: 56363719
	v_div_scale_f32 v17, vcc_lo, v3, v10, v3                   // 00000019FEC4: D6FC6A11 040E1503
	v_rcp_f32_e32 v14, v29                                     // 00000019FECC: 7E1C551D
	v_div_scale_f32 v25, null, v22, v22, v6                    // 00000019FED0: D6FC7C19 041A2D16
	v_fma_f32 v30, -v20, v28, 1.0                              // 00000019FED8: D613001E 23CA3914
	v_div_fixup_f32 v2, v13, v21, v2                           // 00000019FEE0: D6270002 040A2B0D
	v_mul_f32_e32 v11, v17, v27                                // 00000019FEE8: 10163711
	v_div_scale_f32 v21, s0, v4, v12, v4                       // 00000019FEEC: D6FC0015 04121904
	v_rcp_f32_e32 v13, v25                                     // 00000019FEF4: 7E1A5519
	v_fmac_f32_e32 v28, v30, v28                               // 00000019FEF8: 5638391E
	.long 0x7e003982                                           // 00000019FEFC: 7E003982
	v_fma_f32 v9, -v26, v11, v17                               // 00000019FF00: D6130009 2446171A
	v_fma_f32 v30, -v29, v14, 1.0                              // 00000019FF08: D613001E 23CA1D1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000019FF10: BF870114
	v_mul_f32_e32 v19, v21, v28                                // 00000019FF14: 10263915
	v_dual_fmac_f32 v11, v9, v27 :: v_dual_fmac_f32 v14, v30, v14// 00000019FF18: C8003709 0B0E1D1E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000019FF20: BF870225
	v_fma_f32 v33, -v25, v13, 1.0                              // 00000019FF24: D6130021 23CA1B19
	v_div_scale_f32 v30, s1, v5, v18, v5                       // 00000019FF2C: D6FC011E 04162505
	v_fma_f32 v9, -v20, v19, v21                               // 00000019FF34: D6130009 24562714
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000019FF3C: BF870214
	v_fma_f32 v17, -v26, v11, v17                              // 00000019FF40: D6130011 2446171A
	v_fmac_f32_e32 v13, v33, v13                               // 00000019FF48: 561A1B21
	v_div_scale_f32 v33, s2, v6, v22, v6                       // 00000019FF4C: D6FC0221 041A2D06
	v_mul_f32_e32 v35, v30, v14                                // 00000019FF54: 10461D1E
	v_fmac_f32_e32 v19, v9, v28                                // 00000019FF58: 56263909
	v_div_fmas_f32 v11, v17, v27, v11                          // 00000019FF5C: D637000B 042E3711
	s_mov_b32 vcc_lo, s0                                       // 00000019FF64: BEEA0000
	v_mul_f32_e32 v26, v33, v13                                // 00000019FF68: 10341B21
	v_fma_f32 v9, -v29, v35, v30                               // 00000019FF6C: D6130009 247A471D
	v_fma_f32 v17, -v20, v19, v21                              // 00000019FF74: D6130011 24562714
	v_div_fixup_f32 v3, v11, v10, v3                           // 00000019FF7C: D6270003 040E150B
	v_and_b32_e32 v11, 1, v34                                  // 00000019FF84: 36164481
	v_fma_f32 v20, -v25, v26, v33                              // 00000019FF88: D6130014 24863519
	v_fmac_f32_e32 v35, v9, v14                                // 00000019FF90: 56461D09
	v_div_fmas_f32 v9, v17, v28, v19                           // 00000019FF94: D6370009 044E3911
	s_mov_b32 vcc_lo, s1                                       // 00000019FF9C: BEEA0001
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019FFA0: BF870193
	v_dual_fmac_f32 v26, v20, v13 :: v_dual_and_b32 v17, 1, v0 // 00000019FFA4: C8241B14 1A100081
	v_fma_f32 v10, -v29, v35, v30                              // 00000019FFAC: D613000A 247A471D
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019FFB4: BF870003
	v_div_fixup_f32 v4, v9, v12, v4                            // 00000019FFB8: D6270004 04121909
	.long 0x7f183980                                           // 00000019FFC0: 7F183980
	v_add3_u32 v1, v1, v11, 0x7fff                             // 00000019FFC4: D6550001 03FE1701 00007FFF
	v_fma_f32 v9, -v25, v26, v33                               // 00000019FFD0: D6130009 24863519
	v_div_fmas_f32 v10, v10, v14, v35                          // 00000019FFD8: D637000A 048E1D0A
	s_mov_b32 vcc_lo, s2                                       // 00000019FFE0: BEEA0002
	.long 0x7e003984                                           // 00000019FFE4: 7E003984
	v_add3_u32 v2, v2, v17, 0x7fff                             // 00000019FFE8: D6550002 03FE2302 00007FFF
	v_div_fmas_f32 v9, v9, v13, v26                            // 00000019FFF4: D6370009 046A1B09
	v_div_fixup_f32 v5, v10, v18, v5                           // 00000019FFFC: D6270005 0416250A
	.long 0x7e143983                                           // 0000001A0004: 7E143983
	.long 0x7f143980                                           // 0000001A0008: 7F143980
	global_store_d16_hi_b16 v[7:8], v1, off offset:224         // 0000001A000C: DC9600E0 007C0107
	v_div_fixup_f32 v6, v9, v22, v6                            // 0000001A0014: D6270006 041A2D09
	.long 0x7e183985                                           // 0000001A001C: 7E183985
	v_and_b32_e32 v9, 1, v0                                    // 0000001A0020: 36120081
	v_and_b32_e32 v10, 1, v10                                  // 0000001A0024: 36141481
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A0028: BF870214
	.long 0x7e003986                                           // 0000001A002C: 7E003986
	v_and_b32_e32 v11, 1, v12                                  // 0000001A0030: 36161881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A0034: BF870223
	v_add3_u32 v1, v3, v10, 0x7fff                             // 0000001A0038: D6550001 03FE1503 00007FFF
	v_add3_u32 v3, v4, v9, 0x7fff                              // 0000001A0044: D6550003 03FE1304 00007FFF
	v_and_b32_e32 v0, 1, v0                                    // 0000001A0050: 36000081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A0054: BF870114
	v_add3_u32 v4, v5, v11, 0x7fff                             // 0000001A0058: D6550004 03FE1705 00007FFF
	v_add3_u32 v0, v6, v0, 0x7fff                              // 0000001A0064: D6550000 03FE0106 00007FFF
	s_clause 0x4                                               // 0000001A0070: BF850004
	global_store_d16_hi_b16 v[47:48], v2, off offset:224       // 0000001A0074: DC9600E0 007C022F
	global_store_d16_hi_b16 v[15:16], v1, off offset:224       // 0000001A007C: DC9600E0 007C010F
	global_store_d16_hi_b16 v[23:24], v3, off offset:224       // 0000001A0084: DC9600E0 007C0317
	global_store_d16_hi_b16 v[31:32], v4, off offset:224       // 0000001A008C: DC9600E0 007C041F
	global_store_d16_hi_b16 v[39:40], v0, off offset:224       // 0000001A0094: DC9600E0 007C0027
	s_nop 0                                                    // 0000001A009C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001A00A0: BFB60003
	s_endpgm                                                   // 0000001A00A4: BFB00000
		...

