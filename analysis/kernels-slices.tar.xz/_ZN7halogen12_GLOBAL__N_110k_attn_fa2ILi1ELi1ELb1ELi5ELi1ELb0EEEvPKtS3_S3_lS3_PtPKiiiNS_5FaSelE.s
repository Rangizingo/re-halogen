000000000003c300 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 00000003C300: BF850001
	s_load_b256 s[12:19], s[0:1], 0x30                         // 00000003C304: F40C0300 F8000030
	s_load_b128 s[4:7], s[0:1], 0x50                           // 00000003C30C: F4080100 F8000050
	v_and_b32_e32 v131, 31, v0                                 // 00000003C314: 3706009F
	v_lshrrev_b32_e32 v156, 5, v0                              // 00000003C318: 33380085
	s_mov_b32 s26, s3                                          // 00000003C31C: BE9A0003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003C320: BF870112
	.long 0xd44c0003                                           // 00000003C324: D44C0003
	v_cndmask_b32_e32 v1, 16, v131, vcc_lo                     // 00000003C328: 02030690
	v_lshlrev_b32_e32 v132, 6, v156                            // 00000003C32C: 31093886
	s_waitcnt lgkmcnt(0)                                       // 00000003C330: BF89FC07
	s_load_b32 s30, s[12:13], null                             // 00000003C334: F4000786 F8000000
	s_and_saveexec_b32 s8, s3                                  // 00000003C33C: BE882003
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003C340: BF870001
	v_lshl_add_u32 v1, v131, 2, v132                           // 00000003C344: D6460001 06110583
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 00000003C34C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:156 offset1:162// 00000003C358: D83CA29C 00030201
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003C360: 8C7E087E
	v_mul_u32_u24_e32 v1, 0xab, v0                             // 00000003C364: 160200FF 000000AB
	.long 0x7f043880                                           // 00000003C36C: 7F043880
	v_dual_mov_b32 v141, 0 :: v_dual_and_b32 v154, 15, v0      // 00000003C370: CA240080 8D9A008F
	s_cmp_eq_u64 s[18:19], 0                                   // 00000003C378: BF108012
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000003C37C: BF8704B3
	.long 0x7e043981                                           // 00000003C380: 7E043981
	v_mov_b32_e32 v142, 0                                      // 00000003C384: 7F1C0280
	s_cselect_b32 s24, -1, 0                                   // 00000003C388: 981880C1
	s_and_b32 vcc_lo, exec_lo, s24                             // 00000003C38C: 8B6A187E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C390: BF870092
	v_add_lshl_u32 v155, s2, v2, 4                             // 00000003C394: D647009B 02120402
	v_or_b32_e32 v129, v155, v154                              // 00000003C39C: 3903359B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003C3A0: BF870001
	v_ashrrev_i32_e32 v130, 31, v129                           // 00000003C3A4: 3505029F
	s_cbranch_vccnz 10                                         // 00000003C3A8: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xd4>
	v_mad_i64_i32 v[1:2], null, s7, v129, 0                    // 00000003C3AC: D6FF7C01 02030207
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C3B4: BF870091
	.long 0xd73c0001                                           // 00000003C3B8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000003C3BC: 02020282
	.long 0xd7006a8d                                           // 00000003C3C0: D7006A8D
	v_cndmask_b32_e32 v1, s18, v1, vcc_lo                      // 00000003C3C4: 02020212
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003C3C8: BF870001
	v_add_co_ci_u32_e64 v142, null, s19, v2, vcc_lo            // 00000003C3CC: D5207C8E 01AA0413
	s_clause 0x2                                               // 00000003C3D4: BF850002
	s_load_b64 s[18:19], s[0:1], 0x38                          // 00000003C3D8: F4040480 F8000038
	s_load_b128 s[20:23], s[0:1], 0x20                         // 00000003C3E0: F4080500 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 00000003C3E8: F40C0200 F8000000
	v_mov_b32_e32 v158, 0                                      // 00000003C3F0: 7F3C0280
	s_xor_b32 s0, s24, -1                                      // 00000003C3F4: 8D00C118
	s_waitcnt lgkmcnt(0)                                       // 00000003C3F8: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s18, v129                         // 00000003C3FC: 7C890212
	s_and_b32 s28, s0, vcc_lo                                  // 00000003C400: 8B1C6A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003C404: BF870009
	s_and_saveexec_b32 s0, s28                                 // 00000003C408: BE80201C
	s_cbranch_execz 9                                          // 00000003C40C: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x134>
	.long 0xd73c0001                                           // 00000003C410: D73C0001
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 00000003C414: 02030282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C418: BF870091
	.long 0xd7006a01                                           // 00000003C41C: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000003C420: 02020204
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000003C424: D5207C02 01AA0405
	global_load_b32 v158, v[1:2], off                          // 00000003C42C: DC520000 9E7C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 00000003C434: 8C7E007E
	s_cmp_eq_u64 s[16:17], 0                                   // 00000003C438: BF108010
	s_mov_b64 s[24:25], 0                                      // 00000003C43C: BE980180
	s_cbranch_scc1 10                                          // 00000003C440: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c>
	s_ashr_i32 s0, s6, 31                                      // 00000003C444: 86009F06
	s_mul_hi_u32 s1, s6, s2                                    // 00000003C448: 96810206
	s_mul_i32 s0, s0, s2                                       // 00000003C44C: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003C450: BF8704A9
	s_add_i32 s1, s1, s0                                       // 00000003C454: 81010001
	s_mul_i32 s0, s6, s2                                       // 00000003C458: 96000206
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000003C45C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003C460: BF870009
	s_add_u32 s24, s16, s0                                     // 00000003C464: 80180010
	s_addc_u32 s25, s17, s1                                    // 00000003C468: 82190111
	.long 0xd7050001                                           // 00000003C46C: D7050001
	v_cndmask_b32_e32 v0, v156, v150, vcc_lo                   // 00000003C470: 02012D9C
	s_lshl_b32 s0, s2, 4                                       // 00000003C474: 84008402
	s_add_i32 s1, s18, -1                                      // 00000003C478: 8101C112
	s_or_b32 s0, s0, 15                                        // 00000003C47C: 8C008F00
	v_lshrrev_b32_e32 v157, 4, v131                            // 00000003C480: 333B0684
	.long 0xd7390001                                           // 00000003C484: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 00000003C488: 02020288
	s_min_i32 s0, s0, s1                                       // 00000003C48C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000003C490: BF870499
	s_add_i32 s0, s30, s0                                      // 00000003C494: 8100001E
	s_cmp_lt_i32 s0, -15                                       // 00000003C498: BF04CF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C49C: BF870091
	.long 0xd7050001                                           // 00000003C4A0: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 00000003C4A4: 02011901
	.long 0xd7040001                                           // 00000003C4A8: D7040001
	v_cndmask_b32_e32 v1, v156, v1, vcc_lo                     // 00000003C4AC: 0202039C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C4B0: BF870091
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 00000003C4B4: CA240080 480002FF 000000FF
	v_mov_b32_e32 v71, v72                                     // 00000003C4C0: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 00000003C4C4: 7E8A0348
	v_mov_b32_e32 v68, v72                                     // 00000003C4C8: 7E880348
	v_mov_b32_e32 v67, v72                                     // 00000003C4CC: 7E860348
	v_mad_u64_u32 v[138:139], null, s26, 12, v[1:2]            // 00000003C4D0: D6FE7C8A 0405181A
	v_mov_b32_e32 v70, v72                                     // 00000003C4D8: 7E8C0348
	v_mov_b32_e32 v66, v72                                     // 00000003C4DC: 7E840348
	v_mov_b32_e32 v65, v72                                     // 00000003C4E0: 7E820348
	v_mov_b32_e32 v80, v72                                     // 00000003C4E4: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 00000003C4E8: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 00000003C4EC: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 00000003C4F0: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 00000003C4F4: CA220148 4C011488
	v_mov_b32_e32 v75, v72                                     // 00000003C4FC: 7E960348
	v_mov_b32_e32 v74, v72                                     // 00000003C500: 7E940348
	v_mov_b32_e32 v73, v72                                     // 00000003C504: 7E920348
	s_delay_alu instid0(VALU_DEP_4)                            // 00000003C508: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000003C50C: 3404029F
	v_mov_b32_e32 v88, v72                                     // 00000003C510: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 00000003C514: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 00000003C518: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 00000003C51C: 7EAA0348
	.long 0xd73c008b                                           // 00000003C520: D73C008B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000003C524: 02020281
	v_mov_b32_e32 v84, v72                                     // 00000003C528: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 00000003C52C: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 00000003C530: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 00000003C534: 7EA20348
	v_mov_b32_e32 v96, v72                                     // 00000003C538: 7EC00348
	v_mov_b32_e32 v95, v72                                     // 00000003C53C: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 00000003C540: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 00000003C544: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 00000003C548: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 00000003C54C: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 00000003C550: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 00000003C554: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 00000003C558: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 00000003C55C: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 00000003C560: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 00000003C564: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 00000003C568: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 00000003C56C: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 00000003C570: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 00000003C574: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 00000003C578: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 00000003C57C: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 00000003C580: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 00000003C584: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 00000003C588: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 00000003C58C: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 00000003C590: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 00000003C594: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 00000003C598: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 00000003C59C: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 00000003C5A0: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 00000003C5A4: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 00000003C5A8: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 00000003C5AC: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 00000003C5B0: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 00000003C5B4: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 00000003C5B8: 7F000348
	v_mov_b32_e32 v127, v72                                    // 00000003C5BC: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 00000003C5C0: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 00000003C5C4: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 00000003C5C8: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 00000003C5CC: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 00000003C5D0: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 00000003C5D4: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 00000003C5D8: 7E800348
	v_mov_b32_e32 v63, v72                                     // 00000003C5DC: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 00000003C5E0: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 00000003C5E4: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 00000003C5E8: 7E780348
	v_mov_b32_e32 v59, v72                                     // 00000003C5EC: 7E760348
	v_mov_b32_e32 v58, v72                                     // 00000003C5F0: 7E740348
	v_mov_b32_e32 v57, v72                                     // 00000003C5F4: 7E720348
	v_mov_b32_e32 v56, v72                                     // 00000003C5F8: 7E700348
	v_mov_b32_e32 v55, v72                                     // 00000003C5FC: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 00000003C600: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 00000003C604: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 00000003C608: 7E680348
	v_mov_b32_e32 v51, v72                                     // 00000003C60C: 7E660348
	v_mov_b32_e32 v50, v72                                     // 00000003C610: 7E640348
	v_mov_b32_e32 v49, v72                                     // 00000003C614: 7E620348
	v_mov_b32_e32 v48, v72                                     // 00000003C618: 7E600348
	v_mov_b32_e32 v47, v72                                     // 00000003C61C: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 00000003C620: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 00000003C624: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 00000003C628: 7E580348
	v_mov_b32_e32 v43, v72                                     // 00000003C62C: 7E560348
	v_mov_b32_e32 v42, v72                                     // 00000003C630: 7E540348
	v_mov_b32_e32 v41, v72                                     // 00000003C634: 7E520348
	v_mov_b32_e32 v40, v72                                     // 00000003C638: 7E500348
	v_mov_b32_e32 v39, v72                                     // 00000003C63C: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 00000003C640: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 00000003C644: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 00000003C648: 7E480348
	v_mov_b32_e32 v35, v72                                     // 00000003C64C: 7E460348
	v_mov_b32_e32 v34, v72                                     // 00000003C650: 7E440348
	v_mov_b32_e32 v33, v72                                     // 00000003C654: 7E420348
	v_mov_b32_e32 v32, v72                                     // 00000003C658: 7E400348
	v_mov_b32_e32 v31, v72                                     // 00000003C65C: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 00000003C660: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 00000003C664: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 00000003C668: 7E380348
	v_mov_b32_e32 v27, v72                                     // 00000003C66C: 7E360348
	v_mov_b32_e32 v26, v72                                     // 00000003C670: 7E340348
	v_mov_b32_e32 v25, v72                                     // 00000003C674: 7E320348
	v_mov_b32_e32 v24, v72                                     // 00000003C678: 7E300348
	v_mov_b32_e32 v23, v72                                     // 00000003C67C: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 00000003C680: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 00000003C684: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 00000003C688: 7E280348
	v_mov_b32_e32 v19, v72                                     // 00000003C68C: 7E260348
	v_mov_b32_e32 v18, v72                                     // 00000003C690: 7E240348
	v_mov_b32_e32 v17, v72                                     // 00000003C694: 7E220348
	v_mov_b32_e32 v16, v72                                     // 00000003C698: 7E200348
	v_mov_b32_e32 v15, v72                                     // 00000003C69C: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 00000003C6A0: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 00000003C6A4: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 00000003C6A8: 7E180348
	v_mov_b32_e32 v11, v72                                     // 00000003C6AC: 7E160348
	v_mov_b32_e32 v10, v72                                     // 00000003C6B0: 7E140348
	v_mov_b32_e32 v9, v72                                      // 00000003C6B4: 7E120348
	v_mov_b32_e32 v8, v72                                      // 00000003C6B8: 7E100348
	v_mov_b32_e32 v7, v72                                      // 00000003C6BC: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 00000003C6C0: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 00000003C6C4: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 00000003C6C8: 7E080348
	v_mov_b32_e32 v3, v72                                      // 00000003C6CC: 7E060348
	v_mov_b32_e32 v2, v72                                      // 00000003C6D0: 7E040348
	v_mov_b32_e32 v1, v72                                      // 00000003C6D4: 7E020348
	s_cbranch_scc1 2562                                        // 00000003C6D8: BFA20A02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2be4>
	v_mad_i64_i32 v[1:2], null, 0x3000, v129, s[8:9]           // 00000003C6DC: D6FF7C01 002302FF 00003000
	s_ashr_i32 s1, s0, 31                                      // 00000003C6E8: 86019F00
	v_lshlrev_b32_e32 v4, 2, v131                              // 00000003C6EC: 30090682
	s_lshr_b32 s1, s1, 28                                      // 00000003C6F0: 85019C01
	v_add_nc_u32_e32 v160, s30, v155                           // 00000003C6F4: 4B41361E
	s_add_i32 s0, s0, s1                                       // 00000003C6F8: 81000100
	s_movk_i32 s1, 0x440                                       // 00000003C6FC: B0010440
	s_ashr_i32 s16, s0, 4                                      // 00000003C700: 86108400
	.long 0xd7006a8f                                           // 00000003C704: D7006A8F
	v_cndmask_b32_e32 v1, v1, v139, vcc_lo                     // 00000003C708: 02031701
	v_add3_u32 v1, v129, s30, 1                                // 00000003C70C: D6550001 02043D81
	v_add_co_ci_u32_e64 v144, null, v2, v140, vcc_lo           // 00000003C714: D5207C90 01AB1902
	v_mad_u32_u24 v3, v156, s1, 0x1800                         // 00000003C71C: D60B0003 03FC039C 00001800
	s_cmp_eq_u64 s[24:25], 0                                   // 00000003C728: BF108018
	s_delay_alu instid0(VALU_DEP_3)                            // 00000003C72C: BF870003
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000003C730: 3404029F
	v_mov_b32_e32 v129, 0                                      // 00000003C734: 7F020280
	s_cselect_b32 s17, -1, 0                                   // 00000003C738: 981180C1
	v_mad_u32_u24 v5, 0x44, v157, v3                           // 00000003C73C: D60B0005 040F3AFF 00000044
	v_mad_u32_u24 v165, 0x44, v131, v3                         // 00000003C748: D60B00A5 040F06FF 00000044
	v_lshrrev_b32_e32 v2, 30, v2                               // 00000003C754: 3204049E
	v_dual_mov_b32 v8, v129 :: v_dual_lshlrev_b32 v3, 4, v0    // 00000003C758: CA220181 08020084
	s_cmp_lg_u64 s[24:25], 0                                   // 00000003C760: BF118018
	v_lshl_add_u32 v161, v154, 2, v5                           // 00000003C764: D64600A1 0415059A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000003C76C: BF870003
	v_add_nc_u32_e32 v1, v1, v2                                // 00000003C770: 4A020501
	v_add_nc_u32_e32 v2, v4, v132                              // 00000003C774: 4A050904
	s_cselect_b32 s29, -1, 0                                   // 00000003C778: 981D80C1
	s_ashr_i32 s27, s26, 31                                    // 00000003C77C: 861B9F1A
	s_add_i32 s19, s19, -1                                     // 00000003C780: 8113C113
	v_ashrrev_i32_e32 v162, 2, v1                              // 00000003C784: 35440282
	v_lshlrev_b32_e32 v1, 9, v156                              // 00000003C788: 30033889
	s_lshl_b64 s[4:5], s[26:27], 9                             // 00000003C78C: 8484891A
	v_dual_mov_b32 v6, v129 :: v_dual_add_nc_u32 v5, 0x9f00, v132// 00000003C790: CA200181 060508FF 00009F00
	s_add_u32 s2, s10, s4                                      // 00000003C79C: 8002040A
	s_delay_alu instid0(VALU_DEP_2)                            // 00000003C7A0: BF870002
	v_lshl_add_u32 v166, v131, 5, v1                           // 00000003C7A4: D64600A6 04050B83
	v_lshl_or_b32 v170, v154, 5, v1                            // 00000003C7AC: D65600AA 04050B9A
	v_dual_mov_b32 v12, v129 :: v_dual_and_b32 v1, 0x1f0, v3   // 00000003C7B4: CA240181 0C0006FF 000001F0
	v_dual_mov_b32 v3, v129 :: v_dual_add_nc_u32 v164, 0x9c00, v2// 00000003C7C0: CA200181 03A404FF 00009C00
	v_dual_mov_b32 v10, v129 :: v_dual_add_nc_u32 v167, 0xa200, v2// 00000003C7CC: CA200181 0AA604FF 0000A200
	v_mul_u32_u24_e32 v2, 0x210, v156                          // 00000003C7D8: 160538FF 00000210
	s_addc_u32 s1, s11, s5                                     // 00000003C7E0: 8201050B
	s_movk_i32 s6, 0x210                                       // 00000003C7E4: B0060210
	.long 0xd70002ac                                           // 00000003C7E8: D70002AC
	v_cndmask_b32_e32 v1, s2, v1, vcc_lo                       // 00000003C7EC: 02020202
	.long 0xd44c0000                                           // 00000003C7F0: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 00000003C7F4: 020200FF 00000200
	v_mad_u32_u24 v159, v154, s6, 0x7b00                       // 00000003C7FC: D60B009F 03FC0D9A 00007B00
	v_dual_mov_b32 v9, 0 :: v_dual_add_nc_u32 v168, v5, v4     // 00000003C808: CA200080 09A80905
	v_lshl_or_b32 v169, v157, 2, v5                            // 00000003C810: D65600A9 0415059D
	v_mad_u32_u24 v171, v154, 48, 0x4b00                       // 00000003C818: D60B00AB 03FD619A 00004B00
	v_add_co_ci_u32_e64 v173, null, s1, 0, s2                  // 00000003C824: D5207CAD 00090001
	v_lshl_or_b32 v174, v154, 1, 0x4b00                        // 00000003C82C: D65600AE 03FD039A 00004B00
	v_dual_mov_b32 v14, v129 :: v_dual_add_nc_u32 v175, 0xfffffe80, v0// 00000003C838: CA200181 0EAE00FF FFFFFE80
	v_lshl_add_u32 v176, v131, 4, v2                           // 00000003C844: D64600B0 04090983
	v_lshrrev_b32_e32 v0, 1, v0                                // 00000003C84C: 32000081
	v_mov_b32_e32 v1, 0                                        // 00000003C850: 7E020280
	v_dual_mov_b32 v4, v129 :: v_dual_add_nc_u32 v163, v160, v131// 00000003C854: CA200181 04A307A0
	v_mov_b32_e32 v2, v129                                     // 00000003C85C: 7E040381
	v_mov_b32_e32 v5, v129                                     // 00000003C860: 7E0A0381
	v_mov_b32_e32 v7, v129                                     // 00000003C864: 7E0E0381
	v_mov_b32_e32 v11, v129                                    // 00000003C868: 7E160381
	v_mov_b32_e32 v13, v129                                    // 00000003C86C: 7E1A0381
	v_mov_b32_e32 v15, v129                                    // 00000003C870: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v17, 0          // 00000003C874: CA100181 10100080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v25, 0          // 00000003C87C: CA100181 12180080
	v_mov_b32_e32 v19, v129                                    // 00000003C884: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v33, 0          // 00000003C888: CA100181 14200080
	v_mov_b32_e32 v21, v129                                    // 00000003C890: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v41, 0          // 00000003C894: CA100181 16280080
	v_mov_b32_e32 v23, v129                                    // 00000003C89C: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v49, 0          // 00000003C8A0: CA100181 18300080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v57, 0          // 00000003C8A8: CA100181 1A380080
	v_mov_b32_e32 v27, v129                                    // 00000003C8B0: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v121, 0         // 00000003C8B4: CA100181 1C780080
	v_mov_b32_e32 v29, v129                                    // 00000003C8BC: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v113, 0         // 00000003C8C0: CA100181 1E700080
	v_mov_b32_e32 v31, v129                                    // 00000003C8C8: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v105, 0         // 00000003C8CC: CA100181 20680080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v97, 0          // 00000003C8D4: CA100181 22600080
	v_mov_b32_e32 v35, v129                                    // 00000003C8DC: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v89, 0          // 00000003C8E0: CA100181 24580080
	v_mov_b32_e32 v37, v129                                    // 00000003C8E8: 7E4A0381
	v_dual_mov_b32 v38, v129 :: v_dual_mov_b32 v81, 0          // 00000003C8EC: CA100181 26500080
	v_mov_b32_e32 v39, v129                                    // 00000003C8F4: 7E4E0381
	v_dual_mov_b32 v40, v129 :: v_dual_mov_b32 v73, 0          // 00000003C8F8: CA100181 28480080
	v_dual_mov_b32 v42, v129 :: v_dual_mov_b32 v65, 0          // 00000003C900: CA100181 2A400080
	v_mov_b32_e32 v43, v129                                    // 00000003C908: 7E560381
	v_dual_mov_b32 v44, v129 :: v_dual_mov_b32 v177, v156      // 00000003C90C: CA100181 2CB0019C
	v_mov_b32_e32 v45, v129                                    // 00000003C914: 7E5A0381
	v_dual_mov_b32 v46, v129 :: v_dual_mov_b32 v145, 0         // 00000003C918: CA100181 2E900080
	v_mov_b32_e32 v47, v129                                    // 00000003C920: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 00000003C924: 7E600381
	v_mov_b32_e32 v50, v129                                    // 00000003C928: 7E640381
	v_mov_b32_e32 v51, v129                                    // 00000003C92C: 7E660381
	v_mov_b32_e32 v52, v129                                    // 00000003C930: 7E680381
	v_mov_b32_e32 v53, v129                                    // 00000003C934: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 00000003C938: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 00000003C93C: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 00000003C940: 7E700381
	v_mov_b32_e32 v58, v129                                    // 00000003C944: 7E740381
	v_mov_b32_e32 v59, v129                                    // 00000003C948: 7E760381
	v_mov_b32_e32 v60, v129                                    // 00000003C94C: 7E780381
	v_mov_b32_e32 v61, v129                                    // 00000003C950: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 00000003C954: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 00000003C958: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 00000003C95C: 7E800381
	v_mov_b32_e32 v122, v129                                   // 00000003C960: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 00000003C964: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 00000003C968: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 00000003C96C: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 00000003C970: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 00000003C974: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 00000003C978: 7F000381
	v_mov_b32_e32 v114, v129                                   // 00000003C97C: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 00000003C980: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 00000003C984: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 00000003C988: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 00000003C98C: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 00000003C990: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 00000003C994: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 00000003C998: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 00000003C99C: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 00000003C9A0: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 00000003C9A4: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 00000003C9A8: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 00000003C9AC: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 00000003C9B0: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 00000003C9B4: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 00000003C9B8: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 00000003C9BC: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 00000003C9C0: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 00000003C9C4: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 00000003C9C8: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 00000003C9CC: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 00000003C9D0: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 00000003C9D4: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 00000003C9D8: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 00000003C9DC: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 00000003C9E0: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 00000003C9E4: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 00000003C9E8: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 00000003C9EC: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 00000003C9F0: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 00000003C9F4: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 00000003C9F8: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 00000003C9FC: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 00000003CA00: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 00000003CA04: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 00000003CA08: 7E940381
	v_mov_b32_e32 v75, v129                                    // 00000003CA0C: 7E960381
	v_mov_b32_e32 v76, v129                                    // 00000003CA10: 7E980381
	v_mov_b32_e32 v77, v129                                    // 00000003CA14: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 00000003CA18: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 00000003CA1C: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 00000003CA20: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 00000003CA24: 7E840381
	v_mov_b32_e32 v67, v129                                    // 00000003CA28: 7E860381
	v_mov_b32_e32 v68, v129                                    // 00000003CA2C: 7E880381
	v_mov_b32_e32 v69, v129                                    // 00000003CA30: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 00000003CA34: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 00000003CA38: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 00000003CA3C: 7E900381
	s_add_u32 s11, s12, s4                                     // 00000003CA40: 800B040C
	s_addc_u32 s12, s13, s5                                    // 00000003CA44: 820C050D
	s_mov_b32 s13, 0                                           // 00000003CA48: BE8D0080
	s_branch 117                                               // 00000003CA4C: BFA00075 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x924>
	ds_load_b128 v[146:149], v171                              // 00000003CA50: DBFC0000 920000AB
	ds_load_b128 v[150:153], v171 offset:16                    // 00000003CA58: DBFC0010 960000AB
	s_waitcnt lgkmcnt(0)                                       // 00000003CA60: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[146:153], v[121:128]// 00000003CA64: CC414079 1DE72582
	ds_load_b128 v[150:153], v171 offset:784                   // 00000003CA6C: DBFC0310 960000AB
	ds_load_b128 v[146:149], v171 offset:768                   // 00000003CA74: DBFC0300 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000003CA7C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[146:153], v[113:120]// 00000003CA80: CC414071 1DC72582
	ds_load_b128 v[150:153], v171 offset:1552                  // 00000003CA88: DBFC0610 960000AB
	ds_load_b128 v[146:149], v171 offset:1536                  // 00000003CA90: DBFC0600 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000003CA98: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[146:153], v[105:112]// 00000003CA9C: CC414069 1DA72582
	ds_load_b128 v[150:153], v171 offset:2320                  // 00000003CAA4: DBFC0910 960000AB
	ds_load_b128 v[146:149], v171 offset:2304                  // 00000003CAAC: DBFC0900 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000003CAB4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[146:153], v[97:104]// 00000003CAB8: CC414061 1D872582
	ds_load_b128 v[150:153], v171 offset:3088                  // 00000003CAC0: DBFC0C10 960000AB
	ds_load_b128 v[146:149], v171 offset:3072                  // 00000003CAC8: DBFC0C00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000003CAD0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[146:153], v[89:96]// 00000003CAD4: CC414059 1D672582
	ds_load_b128 v[150:153], v171 offset:3856                  // 00000003CADC: DBFC0F10 960000AB
	ds_load_b128 v[146:149], v171 offset:3840                  // 00000003CAE4: DBFC0F00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000003CAEC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[146:153], v[81:88]// 00000003CAF0: CC414051 1D472582
	ds_load_b128 v[150:153], v171 offset:4624                  // 00000003CAF8: DBFC1210 960000AB
	ds_load_b128 v[146:149], v171 offset:4608                  // 00000003CB00: DBFC1200 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000003CB08: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[146:153], v[73:80]// 00000003CB0C: CC414049 1D272582
	ds_load_b128 v[150:153], v171 offset:5392                  // 00000003CB14: DBFC1510 960000AB
	ds_load_b128 v[146:149], v171 offset:5376                  // 00000003CB1C: DBFC1500 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000003CB24: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[146:153], v[65:72]// 00000003CB28: CC414041 1D072582
	ds_load_b128 v[150:153], v171 offset:6160                  // 00000003CB30: DBFC1810 960000AB
	ds_load_b128 v[146:149], v171 offset:6144                  // 00000003CB38: DBFC1800 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000003CB40: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[146:153], v[57:64]// 00000003CB44: CC414039 1CE72582
	ds_load_b128 v[150:153], v171 offset:6928                  // 00000003CB4C: DBFC1B10 960000AB
	ds_load_b128 v[146:149], v171 offset:6912                  // 00000003CB54: DBFC1B00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000003CB5C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[146:153], v[49:56]// 00000003CB60: CC414031 1CC72582
	ds_load_b128 v[150:153], v171 offset:7696                  // 00000003CB68: DBFC1E10 960000AB
	ds_load_b128 v[146:149], v171 offset:7680                  // 00000003CB70: DBFC1E00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000003CB78: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[146:153], v[41:48]// 00000003CB7C: CC414029 1CA72582
	ds_load_b128 v[150:153], v171 offset:8464                  // 00000003CB84: DBFC2110 960000AB
	ds_load_b128 v[146:149], v171 offset:8448                  // 00000003CB8C: DBFC2100 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000003CB94: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[146:153], v[33:40]// 00000003CB98: CC414021 1C872582
	ds_load_b128 v[150:153], v171 offset:9232                  // 00000003CBA0: DBFC2410 960000AB
	ds_load_b128 v[146:149], v171 offset:9216                  // 00000003CBA8: DBFC2400 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000003CBB0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[146:153], v[25:32]// 00000003CBB4: CC414019 1C672582
	ds_load_b128 v[150:153], v171 offset:10000                 // 00000003CBBC: DBFC2710 960000AB
	ds_load_b128 v[146:149], v171 offset:9984                  // 00000003CBC4: DBFC2700 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000003CBCC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[146:153], v[17:24]// 00000003CBD0: CC414011 1C472582
	ds_load_b128 v[150:153], v171 offset:10768                 // 00000003CBD8: DBFC2A10 960000AB
	ds_load_b128 v[146:149], v171 offset:10752                 // 00000003CBE0: DBFC2A00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000003CBE8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[146:153], v[9:16]// 00000003CBEC: CC414009 1C272582
	ds_load_b128 v[150:153], v171 offset:11536                 // 00000003CBF4: DBFC2D10 960000AB
	ds_load_b128 v[146:149], v171 offset:11520                 // 00000003CBFC: DBFC2D00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000003CC04: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[146:153], v[1:8]// 00000003CC08: CC414001 1C072582
	v_add_nc_u32_e32 v177, 16, v177                            // 00000003CC10: 4B636290
	s_add_i32 s1, s13, 1                                       // 00000003CC14: 8101810D
	s_cmp_eq_u32 s13, s16                                      // 00000003CC18: BF06100D
	s_mov_b32 s13, s1                                          // 00000003CC1C: BE8D0001
	s_cbranch_scc1 2224                                        // 00000003CC20: BFA208B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2be4>
	s_and_not1_b32 vcc_lo, exec_lo, s29                        // 00000003CC24: 916A1D7E
	s_mov_b32 s1, s17                                          // 00000003CC28: BE810011
	s_cbranch_vccnz 13                                         // 00000003CC2C: BFA4000D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x964>
	s_lshr_b32 s1, s13, 3                                      // 00000003CC30: 8501830D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000003CC34: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 00000003CC38: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 00000003CC40: 7F040201
	global_load_b32 v130, v130, s[24:25]                       // 00000003CC44: DC520000 82180082
	s_waitcnt vmcnt(0)                                         // 00000003CC4C: BF8903F7
	v_lshrrev_b32_e32 v130, s13, v130                          // 00000003CC50: 3305040D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CC54: BF870091
	v_and_b32_e32 v130, 1, v130                                // 00000003CC58: 37050481
	.long 0xd44a0001                                           // 00000003CC5C: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000003CC60: 02030481
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003CC64: BF870001
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000003CC68: 916A017E
	s_cbranch_vccnz 65512                                      // 00000003CC6C: BFA4FFE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x910>
	s_lshl_b32 s2, s13, 4                                      // 00000003CC70: 8402840D
	s_waitcnt vmcnt(0)                                         // 00000003CC74: BF8903F7
	s_barrier                                                  // 00000003CC78: BFBD0000
	buffer_gl0_inv                                             // 00000003CC7C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000003CC84: BE812000
	s_cbranch_execz 117                                        // 00000003CC88: BFA50075 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb60>
	v_dual_mov_b32 v130, v177 :: v_dual_mov_b32 v131, v176     // 00000003CC8C: CA1001B1 828201B0
	v_mov_b32_e32 v132, v175                                   // 00000003CC94: 7F0803AF
	s_mov_b32 s4, 0                                            // 00000003CC98: BE840080
	s_nop 0                                                    // 00000003CC9C: BF800000
	s_nop 0                                                    // 00000003CCA0: BF800000
	s_nop 0                                                    // 00000003CCA4: BF800000
	s_nop 0                                                    // 00000003CCA8: BF800000
	s_nop 0                                                    // 00000003CCAC: BF800000
	s_nop 0                                                    // 00000003CCB0: BF800000
	s_nop 0                                                    // 00000003CCB4: BF800000
	s_nop 0                                                    // 00000003CCB8: BF800000
	s_nop 0                                                    // 00000003CCBC: BF800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003CCC0: BF870112
	v_min_i32_e32 v133, s19, v130                              // 00000003CCC4: 230B0413
	v_add_nc_u32_e32 v132, 0x180, v132                         // 00000003CCC8: 4B0908FF 00000180
	v_add_nc_u32_e32 v130, 12, v130                            // 00000003CCD0: 4B05048C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000003CCD4: BF8701B3
	v_ashrrev_i32_e32 v135, 31, v133                           // 00000003CCD8: 350F0A9F
	.long 0xd72c0088                                           // 00000003CCDC: D72C0088
	v_cndmask_b32_e32 v1, s15, v133, vcc_lo                    // 00000003CCE0: 02030A0F
	v_mad_u64_u32 v[133:134], null, s14, v133, 0               // 00000003CCE4: D6FE7C85 02030A0E
	.long 0xd72c0087                                           // 00000003CCEC: D72C0087
	v_cndmask_b32_e32 v1, s14, v135, vcc_lo                    // 00000003CCF0: 02030E0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CCF4: BF870091
	v_add3_u32 v134, v134, v135, v136                          // 00000003CCF8: D6550086 06230F86
	.long 0xd73c0085                                           // 00000003CD00: D73C0085
	v_cndmask_b32_e32 v1, 1, v133, vcc_lo                      // 00000003CD04: 02030A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CD08: BF870091
	.long 0xd7006a85                                           // 00000003CD0C: D7006A85
	v_cndmask_b32_e32 v1, v172, v133, vcc_lo                   // 00000003CD10: 02030BAC
	v_add_co_ci_u32_e64 v134, null, v173, v134, vcc_lo         // 00000003CD14: D5207C86 01AB0DAD
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v132                        // 00000003CD1C: 7C9308FF 0000007F
	global_load_b128 v[133:136], v[133:134], off               // 00000003CD24: DC5E0000 857C0085
	s_or_b32 s4, vcc_lo, s4                                    // 00000003CD2C: 8C04046A
	s_waitcnt vmcnt(0)                                         // 00000003CD30: BF8903F7
	ds_store_b128 v131, v[133:136] offset:31488                // 00000003CD34: DB7C7B00 00008583
	v_add_nc_u32_e32 v131, 0x18c0, v131                        // 00000003CD3C: 4B0706FF 000018C0
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000003CD44: 917E047E
	s_cbranch_execnz 65501                                     // 00000003CD48: BFA6FFDD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000003CD4C: 8C7E047E
	v_or_b32_e32 v130, s2, v154                                // 00000003CD50: 39053402
	s_mov_b32 s4, 0                                            // 00000003CD54: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CD58: BF870091
	v_min_i32_e32 v130, s19, v130                              // 00000003CD5C: 23050413
	v_ashrrev_i32_e32 v132, 31, v130                           // 00000003CD60: 3509049F
	.long 0xd72c0085                                           // 00000003CD64: D72C0085
	v_cndmask_b32_e32 v1, s15, v130, vcc_lo                    // 00000003CD68: 0203040F
	v_mad_u64_u32 v[130:131], null, s14, v130, 0               // 00000003CD6C: D6FE7C82 0203040E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CD74: BF870093
	.long 0xd72c0084                                           // 00000003CD78: D72C0084
	v_cndmask_b32_e32 v1, s14, v132, vcc_lo                    // 00000003CD7C: 0203080E
	v_add3_u32 v131, v131, v132, v133                          // 00000003CD80: D6550083 06170983
	v_mov_b32_e32 v133, v175                                   // 00000003CD88: 7F0A03AF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003CD8C: BF870122
	.long 0xd73c0083                                           // 00000003CD90: D73C0083
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000003CD94: 02030481
	v_mov_b32_e32 v130, v0                                     // 00000003CD98: 7F040300
	.long 0xd7006a83                                           // 00000003CD9C: D7006A83
	v_cndmask_b32_e32 v1, s11, v131, vcc_lo                    // 00000003CDA0: 0203060B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003CDA4: BF870001
	v_add_co_ci_u32_e64 v132, null, s12, v132, vcc_lo          // 00000003CDA8: D5207C84 01AB080C
	s_set_inst_prefetch_distance 0x1                           // 00000003CDB0: BF840001
	s_nop 0                                                    // 00000003CDB4: BF800000
	s_nop 0                                                    // 00000003CDB8: BF800000
	s_nop 0                                                    // 00000003CDBC: BF800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000003CDC0: BF8701B3
	v_and_b32_e32 v146, 0xf8, v130                             // 00000003CDC4: 372504FF 000000F8
	v_add_nc_u32_e32 v133, 0x180, v133                         // 00000003CDCC: 4B0B0AFF 00000180
	v_add_nc_u32_e32 v130, 0xc0, v130                          // 00000003CDD4: 4B0504FF 000000C0
	v_lshlrev_b32_e32 v134, 1, v146                            // 00000003CDDC: 310D2481
	v_mad_u32_u24 v146, v146, 48, v174                         // 00000003CDE0: D60B0092 06B96192
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CDE8: BF870092
	.long 0xd7006a86                                           // 00000003CDEC: D7006A86
	v_cndmask_b32_e32 v1, v131, v134, vcc_lo                   // 00000003CDF0: 02030D83
	v_add_co_ci_u32_e64 v135, null, 0, v132, vcc_lo            // 00000003CDF4: D5207C87 01AB0880
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v133                        // 00000003CDFC: 7C930AFF 0000007F
	global_load_b128 v[134:137], v[134:135], off               // 00000003CE04: DC5E0000 867C0086
	s_waitcnt vmcnt(0)                                         // 00000003CE0C: BF8903F7
	ds_store_b16 v146, v134                                    // 00000003CE10: D87C0000 00008692
	ds_store_b16_d16_hi v146, v134 offset:48                   // 00000003CE18: DA840030 00008692
	ds_store_b16 v146, v135 offset:96                          // 00000003CE20: D87C0060 00008792
	ds_store_b16_d16_hi v146, v135 offset:144                  // 00000003CE28: DA840090 00008792
	ds_store_b16 v146, v136 offset:192                         // 00000003CE30: D87C00C0 00008892
	ds_store_b16_d16_hi v146, v136 offset:240                  // 00000003CE38: DA8400F0 00008892
	ds_store_b16 v146, v137 offset:288                         // 00000003CE40: D87C0120 00008992
	ds_store_b16_d16_hi v146, v137 offset:336                  // 00000003CE48: DA840150 00008992
	s_or_b32 s4, vcc_lo, s4                                    // 00000003CE50: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003CE54: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000003CE58: 917E047E
	s_cbranch_execnz 65496                                     // 00000003CE5C: BFA6FFD8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac0>
	s_set_inst_prefetch_distance 0x2                           // 00000003CE60: BF840002
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003CE64: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 00000003CE68: BF89FC07
	s_barrier                                                  // 00000003CE6C: BFBD0000
	buffer_gl0_inv                                             // 00000003CE70: E0AC0000 00000000
	s_clause 0x3                                               // 00000003CE78: BF850003
	global_load_b128 v[150:153], v[143:144], off offset:16     // 00000003CE7C: DC5E0010 967C008F
	global_load_b128 v[146:149], v[143:144], off               // 00000003CE84: DC5E0000 927C008F
	global_load_b128 v[182:185], v[143:144], off offset:48     // 00000003CE8C: DC5E0030 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:32     // 00000003CE94: DC5E0020 B27C008F
	ds_load_b128 v[186:189], v159                              // 00000003CE9C: DBFC0000 BA00009F
	ds_load_b128 v[190:193], v159 offset:16                    // 00000003CEA4: DBFC0010 BE00009F
	v_mov_b32_e32 v136, v129                                   // 00000003CEAC: 7F100381
	v_mov_b32_e32 v130, v129                                   // 00000003CEB0: 7F040381
	v_mov_b32_e32 v131, v129                                   // 00000003CEB4: 7F060381
	v_mov_b32_e32 v132, v129                                   // 00000003CEB8: 7F080381
	v_mov_b32_e32 v133, v129                                   // 00000003CEBC: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 00000003CEC0: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 00000003CEC4: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 00000003CEC8: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003CECC: BF870212
	v_mov_b32_e32 v136, v135                                   // 00000003CED0: 7F100387
	v_mov_b32_e32 v135, v134                                   // 00000003CED4: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 00000003CED8: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 00000003CEDC: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 00000003CEE0: 7F080383
	v_mov_b32_e32 v131, v130                                   // 00000003CEE4: 7F060382
	v_mov_b32_e32 v130, v129                                   // 00000003CEE8: 7F040381
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000003CEEC: BF890807
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003CEF0: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 00000003CEF4: CC414082 1E0B7592
	s_clause 0x1                                               // 00000003CEFC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:80     // 00000003CF00: DC5E0050 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:64     // 00000003CF08: DC5E0040 927C008F
	ds_load_b128 v[186:189], v159 offset:32                    // 00000003CF10: DBFC0020 BA00009F
	ds_load_b128 v[190:193], v159 offset:48                    // 00000003CF18: DBFC0030 BE00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000003CF20: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 00000003CF24: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000003CF2C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:112    // 00000003CF30: DC5E0070 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:96     // 00000003CF38: DC5E0060 B27C008F
	ds_load_b128 v[190:193], v159 offset:80                    // 00000003CF40: DBFC0050 BE00009F
	ds_load_b128 v[186:189], v159 offset:64                    // 00000003CF48: DBFC0040 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000003CF50: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 00000003CF54: CC414082 1E0B7592
	s_clause 0x1                                               // 00000003CF5C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:144    // 00000003CF60: DC5E0090 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:128    // 00000003CF68: DC5E0080 927C008F
	ds_load_b128 v[190:193], v159 offset:112                   // 00000003CF70: DBFC0070 BE00009F
	ds_load_b128 v[186:189], v159 offset:96                    // 00000003CF78: DBFC0060 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000003CF80: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 00000003CF84: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000003CF8C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:176    // 00000003CF90: DC5E00B0 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:160    // 00000003CF98: DC5E00A0 B27C008F
	ds_load_b128 v[190:193], v159 offset:144                   // 00000003CFA0: DBFC0090 BE00009F
	ds_load_b128 v[186:189], v159 offset:128                   // 00000003CFA8: DBFC0080 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000003CFB0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 00000003CFB4: CC414082 1E0B7592
	s_clause 0x1                                               // 00000003CFBC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:208    // 00000003CFC0: DC5E00D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:192    // 00000003CFC8: DC5E00C0 927C008F
	ds_load_b128 v[190:193], v159 offset:176                   // 00000003CFD0: DBFC00B0 BE00009F
	ds_load_b128 v[186:189], v159 offset:160                   // 00000003CFD8: DBFC00A0 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000003CFE0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 00000003CFE4: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000003CFEC: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:240    // 00000003CFF0: DC5E00F0 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:224    // 00000003CFF8: DC5E00E0 B27C008F
	ds_load_b128 v[190:193], v159 offset:208                   // 00000003D000: DBFC00D0 BE00009F
	ds_load_b128 v[186:189], v159 offset:192                   // 00000003D008: DBFC00C0 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000003D010: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 00000003D014: CC414082 1E0B7592
	s_clause 0x1                                               // 00000003D01C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:272    // 00000003D020: DC5E0110 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:256    // 00000003D028: DC5E0100 927C008F
	ds_load_b128 v[190:193], v159 offset:240                   // 00000003D030: DBFC00F0 BE00009F
	ds_load_b128 v[186:189], v159 offset:224                   // 00000003D038: DBFC00E0 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000003D040: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 00000003D044: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000003D04C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:304    // 00000003D050: DC5E0130 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:288    // 00000003D058: DC5E0120 B27C008F
	ds_load_b128 v[190:193], v159 offset:272                   // 00000003D060: DBFC0110 BE00009F
	ds_load_b128 v[186:189], v159 offset:256                   // 00000003D068: DBFC0100 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000003D070: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 00000003D074: CC414082 1E0B7592
	s_clause 0x1                                               // 00000003D07C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:336    // 00000003D080: DC5E0150 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:320    // 00000003D088: DC5E0140 927C008F
	ds_load_b128 v[190:193], v159 offset:304                   // 00000003D090: DBFC0130 BE00009F
	ds_load_b128 v[186:189], v159 offset:288                   // 00000003D098: DBFC0120 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000003D0A0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 00000003D0A4: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000003D0AC: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:368    // 00000003D0B0: DC5E0170 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:352    // 00000003D0B8: DC5E0160 B27C008F
	ds_load_b128 v[190:193], v159 offset:336                   // 00000003D0C0: DBFC0150 BE00009F
	ds_load_b128 v[186:189], v159 offset:320                   // 00000003D0C8: DBFC0140 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000003D0D0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 00000003D0D4: CC414082 1E0B7592
	s_clause 0x1                                               // 00000003D0DC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:400    // 00000003D0E0: DC5E0190 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:384    // 00000003D0E8: DC5E0180 927C008F
	ds_load_b128 v[190:193], v159 offset:368                   // 00000003D0F0: DBFC0170 BE00009F
	ds_load_b128 v[186:189], v159 offset:352                   // 00000003D0F8: DBFC0160 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000003D100: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 00000003D104: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000003D10C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:432    // 00000003D110: DC5E01B0 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:416    // 00000003D118: DC5E01A0 B27C008F
	ds_load_b128 v[190:193], v159 offset:400                   // 00000003D120: DBFC0190 BE00009F
	ds_load_b128 v[186:189], v159 offset:384                   // 00000003D128: DBFC0180 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000003D130: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 00000003D134: CC414082 1E0B7592
	ds_load_b128 v[150:153], v159 offset:432                   // 00000003D13C: DBFC01B0 9600009F
	ds_load_b128 v[146:149], v159 offset:416                   // 00000003D144: DBFC01A0 9200009F
	s_clause 0x1                                               // 00000003D14C: BF850001
	global_load_b128 v[190:193], v[143:144], off offset:464    // 00000003D150: DC5E01D0 BE7C008F
	global_load_b128 v[186:189], v[143:144], off offset:448    // 00000003D158: DC5E01C0 BA7C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000003D160: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[146:153], v[130:137]// 00000003D164: CC414082 1E0B25B2
	s_clause 0x1                                               // 00000003D16C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:496    // 00000003D170: DC5E01F0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:480    // 00000003D178: DC5E01E0 927C008F
	ds_load_b128 v[182:185], v159 offset:464                   // 00000003D180: DBFC01D0 B600009F
	ds_load_b128 v[178:181], v159 offset:448                   // 00000003D188: DBFC01C0 B200009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000003D190: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[186:193], v[178:185], v[130:137]// 00000003D194: CC414082 1E0B65BA
	ds_load_b128 v[182:185], v159 offset:496                   // 00000003D19C: DBFC01F0 B600009F
	ds_load_b128 v[178:181], v159 offset:480                   // 00000003D1A4: DBFC01E0 B200009F
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000003D1AC: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[178:185], v[130:137]// 00000003D1B0: CC414082 1E0B6592
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003D1B8: BF870111
	v_dual_mul_f32 v130, 0x3db8aa3b, v130 :: v_dual_mul_f32 v131, 0x3db8aa3b, v131// 00000003D1BC: C8C704FF 828306FF 3DB8AA3B
	v_mul_f32_e32 v146, 0x3db8aa3b, v133                       // 00000003D1C8: 11250AFF 3DB8AA3B
	v_mov_b32_e32 v133, 0xffff                                 // 00000003D1D0: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000003D1D8: BF870004
	v_mul_f32_e32 v132, 0x3db8aa3b, v132                       // 00000003D1DC: 110908FF 3DB8AA3B
	v_dual_mul_f32 v134, 0x3db8aa3b, v134 :: v_dual_mul_f32 v135, 0x3db8aa3b, v135// 00000003D1E4: C8C70CFF 86870EFF 3DB8AA3B
	v_dual_mul_f32 v136, 0x3db8aa3b, v136 :: v_dual_mul_f32 v137, 0x3db8aa3b, v137// 00000003D1F0: C8C710FF 888912FF 3DB8AA3B
	ds_store_2addr_b32 v161, v130, v131 offset1:34             // 00000003D1FC: D8382200 008382A1
	ds_store_2addr_b32 v161, v132, v146 offset0:68 offset1:102 // 00000003D204: D8386644 009284A1
	ds_store_2addr_b32 v161, v134, v135 offset0:136 offset1:170// 00000003D20C: D838AA88 008786A1
	ds_store_2addr_b32 v161, v136, v137 offset0:204 offset1:238// 00000003D214: D838EECC 008988A1
	s_and_saveexec_b32 s4, s28                                 // 00000003D21C: BE84201C
	s_cbranch_execz 363                                        // 00000003D220: BFA5016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14d0>
	s_lshl_b32 s5, s13, 2                                      // 00000003D224: 8405820D
	s_mov_b32 s6, exec_lo                                      // 00000003D228: BE86007E
	.long 0xd4c1007e                                           // 00000003D22C: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 00000003D230: 02033D91
	s_cbranch_execz 48                                         // 00000003D234: BFA50030 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xff8>
	v_ashrrev_i32_e32 v146, 31, v145                           // 00000003D238: 3525229F
	s_mov_b32 s7, 0                                            // 00000003D23C: BE870080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D240: BF870091
	.long 0xd73c0082                                           // 00000003D244: D73C0082
	v_cndmask_b32_e32 v1, 2, v145, vcc_lo                      // 00000003D248: 02032282
	.long 0xd7006a82                                           // 00000003D24C: D7006A82
	v_cndmask_b32_e32 v1, v141, v130, vcc_lo                   // 00000003D250: 0203058D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D254: BF870001
	v_add_co_ci_u32_e64 v131, null, v142, v131, vcc_lo         // 00000003D258: D5207C83 01AB078E
	s_branch 15                                                // 00000003D260: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xfa0>
	s_nop 0                                                    // 00000003D264: BF800000
	s_nop 0                                                    // 00000003D268: BF800000
	s_nop 0                                                    // 00000003D26C: BF800000
	s_nop 0                                                    // 00000003D270: BF800000
	s_nop 0                                                    // 00000003D274: BF800000
	s_nop 0                                                    // 00000003D278: BF800000
	s_nop 0                                                    // 00000003D27C: BF800000
	s_or_b32 exec_lo, exec_lo, s9                              // 00000003D280: 8C7E097E
	v_mov_b32_e32 v133, v145                                   // 00000003D284: 7F0A0391
	v_mov_b32_e32 v145, v132                                   // 00000003D288: 7F220384
	s_and_b32 s1, exec_lo, s8                                  // 00000003D28C: 8B01087E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000003D290: BF870499
	s_or_b32 s7, s1, s7                                        // 00000003D294: 8C070701
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 00000003D298: 917E077E
	s_cbranch_execz 20                                         // 00000003D29C: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xff0>
	global_load_b32 v132, v[130:131], off                      // 00000003D2A0: DC520000 847C0082
	s_or_b32 s8, s8, exec_lo                                   // 00000003D2A8: 8C087E08
	s_waitcnt vmcnt(0)                                         // 00000003D2AC: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s5, v132                          // 00000003D2B0: 7C890805
	s_and_saveexec_b32 s9, vcc_lo                              // 00000003D2B4: BE89206A
	s_cbranch_execz 65521                                      // 00000003D2B8: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	v_dual_mov_b32 v145, v158 :: v_dual_add_nc_u32 v132, 1, v145// 00000003D2BC: CA20019E 91852281
	.long 0xd7000182                                           // 00000003D2C4: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 00000003D2C8: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000003D2CC: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 00000003D2D0: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v158, v132                        // 00000003D2D8: 7C95099E
	s_and_not1_b32 s1, s8, exec_lo                             // 00000003D2DC: 91017E08
	s_and_b32 s8, vcc_lo, exec_lo                              // 00000003D2E0: 8B087E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D2E4: BF870009
	s_or_b32 s8, s1, s8                                        // 00000003D2E8: 8C080801
	s_branch 65508                                             // 00000003D2EC: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	s_or_b32 exec_lo, exec_lo, s7                              // 00000003D2F0: 8C7E077E
	v_mov_b32_e32 v145, v133                                   // 00000003D2F4: 7F220385
	s_or_b32 exec_lo, exec_lo, s6                              // 00000003D2F8: 8C7E067E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D2FC: BF870001
	v_dual_mov_b32 v133, 15 :: v_dual_mov_b32 v130, v145       // 00000003D300: CA10008F 85820191
	s_mov_b32 s1, exec_lo                                      // 00000003D308: BE81007E
	.long 0xd4c1007e                                           // 00000003D30C: D4C1007E
	v_cndmask_b32_e32 v1, s5, v162, vcc_lo                     // 00000003D310: 02034405
	s_cbranch_execz 62                                         // 00000003D314: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1110>
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v145        // 00000003D318: CA100080 85820191
	s_mov_b32 s6, exec_lo                                      // 00000003D320: BE86007E
	.long 0xd4c1007e                                           // 00000003D324: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 00000003D328: 02033D91
	s_cbranch_execz 54                                         // 00000003D32C: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1108>
	v_mov_b32_e32 v130, v145                                   // 00000003D330: 7F040391
	s_mov_b32 s8, 0                                            // 00000003D334: BE880080
	s_set_inst_prefetch_distance 0x1                           // 00000003D338: BF840001
	s_branch 10                                                // 00000003D33C: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1068>
	s_or_b32 exec_lo, exec_lo, s26                             // 00000003D340: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000003D344: BF870499
	s_and_b32 s26, exec_lo, s10                                // 00000003D348: 8B1A0A7E
	s_or_b32 s8, s26, s8                                       // 00000003D34C: 8C08081A
	s_and_not1_b32 s7, s7, exec_lo                             // 00000003D350: 91077E07
	s_and_b32 s26, s9, exec_lo                                 // 00000003D354: 8B1A7E09
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D358: BF870009
	s_or_b32 s7, s7, s26                                       // 00000003D35C: 8C071A07
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 00000003D360: 917E087E
	s_cbranch_execz 28                                         // 00000003D364: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10d8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000003D368: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 00000003D36C: 7F060382
	s_or_b32 s9, s9, exec_lo                                   // 00000003D370: 8C097E09
	s_or_b32 s10, s10, exec_lo                                 // 00000003D374: 8C0A7E0A
	s_mov_b32 s26, exec_lo                                     // 00000003D378: BE9A007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000003D37C: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D380: BF870091
	.long 0xd73c0084                                           // 00000003D384: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000003D388: 02030682
	.long 0xd7006a84                                           // 00000003D38C: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 00000003D390: 0203098D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D394: BF870001
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 00000003D398: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 00000003D3A0: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 00000003D3A8: BF8903F7
	.long 0xd4c4007e                                           // 00000003D3AC: D4C4007E
	v_cndmask_b32_e32 v1, s5, v132, vcc_lo                     // 00000003D3B0: 02030805
	s_cbranch_execz 65506                                      // 00000003D3B4: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000003D3B8: 4B050681
	s_and_not1_b32 s10, s10, exec_lo                           // 00000003D3BC: 910A7E0A
	s_and_not1_b32 s9, s9, exec_lo                             // 00000003D3C0: 91097E09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003D3C4: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000003D3C8: 7C95059E
	s_and_b32 s27, vcc_lo, exec_lo                             // 00000003D3CC: 8B1B7E6A
	s_or_b32 s10, s10, s27                                     // 00000003D3D0: 8C0A1B0A
	s_branch 65498                                             // 00000003D3D4: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	s_set_inst_prefetch_distance 0x2                           // 00000003D3D8: BF840002
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003D3DC: 8C7E087E
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v158        // 00000003D3E0: CA100080 8582019E
	s_and_saveexec_b32 s8, s7                                  // 00000003D3E8: BE882007
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D3EC: BF870009
	s_xor_b32 s7, exec_lo, s8                                  // 00000003D3F0: 8D07087E
	v_cmp_eq_u32_e32 vcc_lo, s5, v132                          // 00000003D3F4: 7C950805
	v_mov_b32_e32 v130, v131                                   // 00000003D3F8: 7F040383
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 00000003D3FC: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s7                              // 00000003D404: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D408: BF870009
	s_or_b32 exec_lo, exec_lo, s6                              // 00000003D40C: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D410: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003D414: 8C7E017E
	s_or_b32 s6, s5, 1                                         // 00000003D418: 8C068105
	s_mov_b32 s1, exec_lo                                      // 00000003D41C: BE81007E
	.long 0xd4c6007e                                           // 00000003D420: D4C6007E
	v_cndmask_b32_e32 v1, s6, v162, vcc_lo                     // 00000003D424: 02034406
	s_xor_b32 s1, exec_lo, s1                                  // 00000003D428: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 00000003D42C: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 00000003D434: BE813001
	s_cbranch_execz 70                                         // 00000003D438: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1254>
	s_mov_b32 s7, exec_lo                                      // 00000003D43C: BE87007E
	.long 0xd4c1007e                                           // 00000003D440: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 00000003D444: 02033D82
	s_cbranch_execz 64                                         // 00000003D448: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x124c>
	s_mov_b32 s9, 0                                            // 00000003D44C: BE890080
	s_set_inst_prefetch_distance 0x1                           // 00000003D450: BF840001
	s_branch 20                                                // 00000003D454: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11a8>
	s_nop 0                                                    // 00000003D458: BF800000
	s_nop 0                                                    // 00000003D45C: BF800000
	s_nop 0                                                    // 00000003D460: BF800000
	s_nop 0                                                    // 00000003D464: BF800000
	s_nop 0                                                    // 00000003D468: BF800000
	s_nop 0                                                    // 00000003D46C: BF800000
	s_nop 0                                                    // 00000003D470: BF800000
	s_nop 0                                                    // 00000003D474: BF800000
	s_nop 0                                                    // 00000003D478: BF800000
	s_nop 0                                                    // 00000003D47C: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 00000003D480: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000003D484: BF870499
	s_and_b32 s27, exec_lo, s26                                // 00000003D488: 8B1B1A7E
	s_or_b32 s9, s27, s9                                       // 00000003D48C: 8C09091B
	s_and_not1_b32 s8, s8, exec_lo                             // 00000003D490: 91087E08
	s_and_b32 s27, s10, exec_lo                                // 00000003D494: 8B1B7E0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D498: BF870009
	s_or_b32 s8, s8, s27                                       // 00000003D49C: 8C081B08
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 00000003D4A0: 917E097E
	s_cbranch_execz 27                                         // 00000003D4A4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1214>
	v_mov_b32_e32 v131, v130                                   // 00000003D4A8: 7F060382
	s_or_b32 s10, s10, exec_lo                                 // 00000003D4AC: 8C0A7E0A
	s_or_b32 s26, s26, exec_lo                                 // 00000003D4B0: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 00000003D4B4: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D4B8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000003D4BC: 3509069F
	.long 0xd73c0086                                           // 00000003D4C0: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000003D4C4: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D4C8: BF870091
	.long 0xd7006a86                                           // 00000003D4CC: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 00000003D4D0: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 00000003D4D4: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 00000003D4DC: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 00000003D4E4: BF8903F7
	.long 0xd4c6007e                                           // 00000003D4E8: D4C6007E
	v_cndmask_b32_e32 v1, s5, v132, vcc_lo                     // 00000003D4EC: 02030805
	s_cbranch_execz 65507                                      // 00000003D4F0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000003D4F4: 4B050681
	s_and_not1_b32 s26, s26, exec_lo                           // 00000003D4F8: 911A7E1A
	s_and_not1_b32 s10, s10, exec_lo                           // 00000003D4FC: 910A7E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003D500: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000003D504: 7C95059E
	s_and_b32 s30, vcc_lo, exec_lo                             // 00000003D508: 8B1E7E6A
	s_or_b32 s26, s26, s30                                     // 00000003D50C: 8C1A1E1A
	s_branch 65499                                             // 00000003D510: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	s_set_inst_prefetch_distance 0x2                           // 00000003D514: BF840002
	s_or_b32 exec_lo, exec_lo, s9                              // 00000003D518: 8C7E097E
	v_mov_b32_e32 v130, v158                                   // 00000003D51C: 7F04039E
	s_and_saveexec_b32 s9, s8                                  // 00000003D520: BE892008
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D524: BF870009
	s_xor_b32 s8, exec_lo, s9                                  // 00000003D528: 8D08097E
	v_cmp_eq_u32_e32 vcc_lo, s6, v132                          // 00000003D52C: 7C950806
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 00000003D530: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D53C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 00000003D540: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 00000003D544: 7F040383
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003D548: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D54C: BF870009
	s_or_b32 exec_lo, exec_lo, s7                              // 00000003D550: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D554: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003D558: 8C7E017E
	s_or_b32 s6, s5, 2                                         // 00000003D55C: 8C068205
	s_mov_b32 s1, exec_lo                                      // 00000003D560: BE81007E
	.long 0xd4c6007e                                           // 00000003D564: D4C6007E
	v_cndmask_b32_e32 v1, s6, v162, vcc_lo                     // 00000003D568: 02034406
	s_xor_b32 s1, exec_lo, s1                                  // 00000003D56C: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 00000003D570: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 00000003D578: BE813001
	s_cbranch_execz 69                                         // 00000003D57C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1394>
	s_mov_b32 s7, exec_lo                                      // 00000003D580: BE87007E
	.long 0xd4c1007e                                           // 00000003D584: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 00000003D588: 02033D82
	s_cbranch_execz 63                                         // 00000003D58C: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x138c>
	s_mov_b32 s9, 0                                            // 00000003D590: BE890080
	s_set_inst_prefetch_distance 0x1                           // 00000003D594: BF840001
	s_branch 19                                                // 00000003D598: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12e8>
	s_nop 0                                                    // 00000003D59C: BF800000
	s_nop 0                                                    // 00000003D5A0: BF800000
	s_nop 0                                                    // 00000003D5A4: BF800000
	s_nop 0                                                    // 00000003D5A8: BF800000
	s_nop 0                                                    // 00000003D5AC: BF800000
	s_nop 0                                                    // 00000003D5B0: BF800000
	s_nop 0                                                    // 00000003D5B4: BF800000
	s_nop 0                                                    // 00000003D5B8: BF800000
	s_nop 0                                                    // 00000003D5BC: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 00000003D5C0: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000003D5C4: BF870499
	s_and_b32 s27, exec_lo, s26                                // 00000003D5C8: 8B1B1A7E
	s_or_b32 s9, s27, s9                                       // 00000003D5CC: 8C09091B
	s_and_not1_b32 s8, s8, exec_lo                             // 00000003D5D0: 91087E08
	s_and_b32 s27, s10, exec_lo                                // 00000003D5D4: 8B1B7E0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D5D8: BF870009
	s_or_b32 s8, s8, s27                                       // 00000003D5DC: 8C081B08
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 00000003D5E0: 917E097E
	s_cbranch_execz 27                                         // 00000003D5E4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1354>
	v_mov_b32_e32 v131, v130                                   // 00000003D5E8: 7F060382
	s_or_b32 s10, s10, exec_lo                                 // 00000003D5EC: 8C0A7E0A
	s_or_b32 s26, s26, exec_lo                                 // 00000003D5F0: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 00000003D5F4: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D5F8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000003D5FC: 3509069F
	.long 0xd73c0086                                           // 00000003D600: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000003D604: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D608: BF870091
	.long 0xd7006a86                                           // 00000003D60C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 00000003D610: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 00000003D614: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 00000003D61C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 00000003D624: BF8903F7
	.long 0xd4c4007e                                           // 00000003D628: D4C4007E
	v_cndmask_b32_e32 v1, s6, v132, vcc_lo                     // 00000003D62C: 02030806
	s_cbranch_execz 65507                                      // 00000003D630: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12c0>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000003D634: 4B050681
	s_and_not1_b32 s26, s26, exec_lo                           // 00000003D638: 911A7E1A
	s_and_not1_b32 s10, s10, exec_lo                           // 00000003D63C: 910A7E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003D640: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000003D644: 7C95059E
	s_and_b32 s30, vcc_lo, exec_lo                             // 00000003D648: 8B1E7E6A
	s_or_b32 s26, s26, s30                                     // 00000003D64C: 8C1A1E1A
	s_branch 65499                                             // 00000003D650: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12c0>
	s_set_inst_prefetch_distance 0x2                           // 00000003D654: BF840002
	s_or_b32 exec_lo, exec_lo, s9                              // 00000003D658: 8C7E097E
	v_mov_b32_e32 v130, v158                                   // 00000003D65C: 7F04039E
	s_and_saveexec_b32 s9, s8                                  // 00000003D660: BE892008
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D664: BF870009
	s_xor_b32 s8, exec_lo, s9                                  // 00000003D668: 8D08097E
	v_cmp_eq_u32_e32 vcc_lo, s6, v132                          // 00000003D66C: 7C950806
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 00000003D670: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D67C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 00000003D680: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 00000003D684: 7F040383
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003D688: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D68C: BF870009
	s_or_b32 exec_lo, exec_lo, s7                              // 00000003D690: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D694: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003D698: 8C7E017E
	s_or_b32 s5, s5, 3                                         // 00000003D69C: 8C058305
	s_mov_b32 s1, exec_lo                                      // 00000003D6A0: BE81007E
	.long 0xd4c6007e                                           // 00000003D6A4: D4C6007E
	v_cndmask_b32_e32 v1, s5, v162, vcc_lo                     // 00000003D6A8: 02034405
	s_xor_b32 s1, exec_lo, s1                                  // 00000003D6AC: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 00000003D6B0: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 00000003D6B8: BE813001
	s_cbranch_execz 66                                         // 00000003D6BC: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c8>
	s_mov_b32 s6, exec_lo                                      // 00000003D6C0: BE86007E
	.long 0xd4c1007e                                           // 00000003D6C4: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 00000003D6C8: 02033D82
	s_cbranch_execz 60                                         // 00000003D6CC: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	s_mov_b32 s8, 0                                            // 00000003D6D0: BE880080
	s_set_inst_prefetch_distance 0x1                           // 00000003D6D4: BF840001
	s_branch 19                                                // 00000003D6D8: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1428>
	s_nop 0                                                    // 00000003D6DC: BF800000
	s_nop 0                                                    // 00000003D6E0: BF800000
	s_nop 0                                                    // 00000003D6E4: BF800000
	s_nop 0                                                    // 00000003D6E8: BF800000
	s_nop 0                                                    // 00000003D6EC: BF800000
	s_nop 0                                                    // 00000003D6F0: BF800000
	s_nop 0                                                    // 00000003D6F4: BF800000
	s_nop 0                                                    // 00000003D6F8: BF800000
	s_nop 0                                                    // 00000003D6FC: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 00000003D700: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000003D704: BF870499
	s_and_b32 s26, exec_lo, s10                                // 00000003D708: 8B1A0A7E
	s_or_b32 s8, s26, s8                                       // 00000003D70C: 8C08081A
	s_and_not1_b32 s7, s7, exec_lo                             // 00000003D710: 91077E07
	s_and_b32 s26, s9, exec_lo                                 // 00000003D714: 8B1A7E09
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D718: BF870009
	s_or_b32 s7, s7, s26                                       // 00000003D71C: 8C071A07
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 00000003D720: 917E087E
	s_cbranch_execz 26                                         // 00000003D724: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1490>
	v_ashrrev_i32_e32 v131, 31, v130                           // 00000003D728: 3507049F
	s_or_b32 s9, s9, exec_lo                                   // 00000003D72C: 8C097E09
	s_or_b32 s10, s10, exec_lo                                 // 00000003D730: 8C0A7E0A
	s_mov_b32 s26, exec_lo                                     // 00000003D734: BE9A007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D738: BF870091
	.long 0xd73c0083                                           // 00000003D73C: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 00000003D740: 02030482
	.long 0xd7006a83                                           // 00000003D744: D7006A83
	v_cndmask_b32_e32 v1, v141, v131, vcc_lo                   // 00000003D748: 0203078D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D74C: BF870001
	v_add_co_ci_u32_e64 v132, null, v142, v132, vcc_lo         // 00000003D750: D5207C84 01AB098E
	global_load_b32 v131, v[131:132], off                      // 00000003D758: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 00000003D760: BF8903F7
	.long 0xd4c4007e                                           // 00000003D764: D4C4007E
	v_cndmask_b32_e32 v1, s5, v131, vcc_lo                     // 00000003D768: 02030605
	s_cbranch_execz 65508                                      // 00000003D76C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	v_add_nc_u32_e32 v130, 1, v130                             // 00000003D770: 4B050481
	s_and_not1_b32 s10, s10, exec_lo                           // 00000003D774: 910A7E0A
	s_and_not1_b32 s9, s9, exec_lo                             // 00000003D778: 91097E09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003D77C: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000003D780: 7C95059E
	s_and_b32 s27, vcc_lo, exec_lo                             // 00000003D784: 8B1B7E6A
	s_or_b32 s10, s10, s27                                     // 00000003D788: 8C0A1B0A
	s_branch 65500                                             // 00000003D78C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	s_set_inst_prefetch_distance 0x2                           // 00000003D790: BF840002
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003D794: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003D798: BE882007
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D79C: BF870009
	s_xor_b32 s7, exec_lo, s8                                  // 00000003D7A0: 8D07087E
	v_cmp_eq_u32_e32 vcc_lo, s5, v131                          // 00000003D7A4: 7C950605
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 00000003D7A8: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D7B4: BF870001
	v_or_b32_e32 v133, v130, v133                              // 00000003D7B8: 390B0B82
	s_or_b32 exec_lo, exec_lo, s7                              // 00000003D7BC: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D7C0: BF870009
	s_or_b32 exec_lo, exec_lo, s6                              // 00000003D7C4: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D7C8: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003D7CC: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000003D7D0: BF8704C9
	s_or_b32 exec_lo, exec_lo, s4                              // 00000003D7D4: 8C7E047E
	v_cmp_eq_u32_e32 vcc_lo, 0xffff, v133                      // 00000003D7D8: 7C950AFF 0000FFFF
	s_cmp_eq_u32 vcc_lo, -1                                    // 00000003D7E0: BF06C16A
	s_cselect_b32 s1, -1, 0                                    // 00000003D7E4: 980180C1
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 00000003D7E8: D5010082 00050280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D7F0: BF870001
	v_readfirstlane_b32 s1, v130                               // 00000003D7F4: 7E020582
	s_bitcmp0_b32 s1, 0                                        // 00000003D7F8: BF0C8001
	s_mov_b32 s1, 0                                            // 00000003D7FC: BE810080
	s_cbranch_scc1 8                                           // 00000003D800: BFA20008 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1524>
	s_or_b32 s1, s2, 15                                        // 00000003D804: 8C018F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003D808: BF8700A9
	v_cmp_le_i32_e32 vcc_lo, s1, v160                          // 00000003D80C: 7C874001
	v_cndmask_b32_e64 v130, 0, 1, vcc_lo                       // 00000003D810: D5010082 01A90280
	v_readfirstlane_b32 s1, v130                               // 00000003D818: 7E020582
	s_bitcmp1_b32 s1, 0                                        // 00000003D81C: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 00000003D820: 980180C1
	s_and_saveexec_b32 s26, s3                                 // 00000003D824: BE9A2003
	s_cbranch_execz 1272                                       // 00000003D828: BFA504F8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x290c>
	ds_load_b32 v130, v164                                     // 00000003D82C: D8D80000 820000A4
	s_xor_b32 s1, s1, -1                                       // 00000003D834: 8D01C101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D838: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000003D83C: 916A017E
	s_mov_b32 s1, -1                                           // 00000003D840: BE8100C1
	s_cbranch_vccnz 798                                        // 00000003D844: BFA4031E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21c0>
	v_and_b32_e32 v131, 1, v133                                // 00000003D848: 37070A81
	v_cmp_le_i32_e32 vcc_lo, s2, v163                          // 00000003D84C: 7C874602
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000003D850: BF8704C2
	.long 0xd44a0001                                           // 00000003D854: D44A0001
	v_cndmask_b32_e32 v1, 1, v131, vcc_lo                      // 00000003D858: 02030681
	s_waitcnt lgkmcnt(0)                                       // 00000003D85C: BF89FC07
	v_mov_b32_e32 v131, v130                                   // 00000003D860: 7F060382
	s_and_b32 s37, vcc_lo, s1                                  // 00000003D864: 8B25016A
	s_and_saveexec_b32 s1, s37                                 // 00000003D868: BE812025
	s_cbranch_execz 7                                          // 00000003D86C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x158c>
	ds_load_b32 v131, v165                                     // 00000003D870: D8D80000 830000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003D878: BF89FC07
	v_dual_max_f32 v132, v130, v130 :: v_dual_max_f32 v131, v131, v131// 00000003D87C: CA950582 84830783
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D884: BF870001
	v_max_f32_e32 v131, v132, v131                             // 00000003D888: 21070784
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003D88C: 8C7E017E
	v_and_b32_e32 v132, 2, v133                                // 00000003D890: 37090A82
	v_cmp_lt_i32_e32 vcc_lo, s2, v163                          // 00000003D894: 7C834602
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003D898: BF8704A2
	.long 0xd44d0001                                           // 00000003D89C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003D8A0: 02030880
	s_and_b32 s36, vcc_lo, s1                                  // 00000003D8A4: 8B24016A
	s_and_saveexec_b32 s1, s36                                 // 00000003D8A8: BE812024
	s_cbranch_execz 7                                          // 00000003D8AC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15cc>
	ds_load_b32 v132, v165 offset:4                            // 00000003D8B0: D8D80004 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003D8B8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000003D8BC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D8C4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000003D8C8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003D8CC: 8C7E017E
	v_and_b32_e32 v132, 4, v133                                // 00000003D8D0: 37090A84
	s_or_b32 s1, s2, 2                                         // 00000003D8D4: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003D8D8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000003D8DC: 7C874601
	.long 0xd44d0001                                           // 00000003D8E0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003D8E4: 02030880
	s_and_b32 s34, vcc_lo, s1                                  // 00000003D8E8: 8B22016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D8EC: BF870009
	s_and_saveexec_b32 s1, s34                                 // 00000003D8F0: BE812022
	s_cbranch_execz 7                                          // 00000003D8F4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1614>
	ds_load_b32 v132, v165 offset:8                            // 00000003D8F8: D8D80008 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003D900: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000003D904: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D90C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000003D910: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003D914: 8C7E017E
	v_and_b32_e32 v132, 8, v133                                // 00000003D918: 37090A88
	s_or_b32 s1, s2, 3                                         // 00000003D91C: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003D920: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000003D924: 7C874601
	.long 0xd44d0001                                           // 00000003D928: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003D92C: 02030880
	s_and_b32 s35, vcc_lo, s1                                  // 00000003D930: 8B23016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D934: BF870009
	s_and_saveexec_b32 s1, s35                                 // 00000003D938: BE812023
	s_cbranch_execz 7                                          // 00000003D93C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x165c>
	ds_load_b32 v132, v165 offset:12                           // 00000003D940: D8D8000C 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003D948: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000003D94C: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D954: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000003D958: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003D95C: 8C7E017E
	v_and_b32_e32 v132, 16, v133                               // 00000003D960: 37090A90
	s_or_b32 s1, s2, 4                                         // 00000003D964: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003D968: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000003D96C: 7C874601
	.long 0xd44d0001                                           // 00000003D970: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003D974: 02030880
	s_and_b32 s31, vcc_lo, s1                                  // 00000003D978: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D97C: BF870009
	s_and_saveexec_b32 s1, s31                                 // 00000003D980: BE81201F
	s_cbranch_execz 7                                          // 00000003D984: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16a4>
	ds_load_b32 v132, v165 offset:16                           // 00000003D988: D8D80010 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003D990: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000003D994: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D99C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000003D9A0: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003D9A4: 8C7E017E
	v_and_b32_e32 v132, 32, v133                               // 00000003D9A8: 37090AA0
	s_or_b32 s1, s2, 5                                         // 00000003D9AC: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003D9B0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000003D9B4: 7C874601
	.long 0xd44d0001                                           // 00000003D9B8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003D9BC: 02030880
	s_and_b32 s33, vcc_lo, s1                                  // 00000003D9C0: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D9C4: BF870009
	s_and_saveexec_b32 s1, s33                                 // 00000003D9C8: BE812021
	s_cbranch_execz 7                                          // 00000003D9CC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16ec>
	ds_load_b32 v132, v165 offset:20                           // 00000003D9D0: D8D80014 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003D9D8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000003D9DC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D9E4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000003D9E8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003D9EC: 8C7E017E
	v_and_b32_e32 v132, 64, v133                               // 00000003D9F0: 37090AC0
	s_or_b32 s1, s2, 6                                         // 00000003D9F4: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003D9F8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000003D9FC: 7C874601
	.long 0xd44d0001                                           // 00000003DA00: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003DA04: 02030880
	s_and_b32 s27, vcc_lo, s1                                  // 00000003DA08: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003DA0C: BF870009
	s_and_saveexec_b32 s1, s27                                 // 00000003DA10: BE81201B
	s_cbranch_execz 7                                          // 00000003DA14: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1734>
	ds_load_b32 v132, v165 offset:24                           // 00000003DA18: D8D80018 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DA20: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000003DA24: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003DA2C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000003DA30: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003DA34: 8C7E017E
	v_and_b32_e32 v132, 0x80, v133                             // 00000003DA38: 37090AFF 00000080
	s_or_b32 s1, s2, 7                                         // 00000003DA40: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003DA44: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000003DA48: 7C874601
	.long 0xd44d0001                                           // 00000003DA4C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003DA50: 02030880
	s_and_b32 s30, vcc_lo, s1                                  // 00000003DA54: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003DA58: BF870009
	s_and_saveexec_b32 s1, s30                                 // 00000003DA5C: BE81201E
	s_cbranch_execz 7                                          // 00000003DA60: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1780>
	ds_load_b32 v132, v165 offset:28                           // 00000003DA64: D8D8001C 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DA6C: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000003DA70: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003DA78: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000003DA7C: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003DA80: 8C7E017E
	v_and_b32_e32 v132, 0x100, v133                            // 00000003DA84: 37090AFF 00000100
	s_or_b32 s1, s2, 8                                         // 00000003DA8C: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003DA90: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000003DA94: 7C874601
	.long 0xd44d0001                                           // 00000003DA98: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003DA9C: 02030880
	s_and_b32 s9, vcc_lo, s1                                   // 00000003DAA0: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003DAA4: BF870009
	s_and_saveexec_b32 s1, s9                                  // 00000003DAA8: BE812009
	s_cbranch_execz 7                                          // 00000003DAAC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17cc>
	ds_load_b32 v132, v165 offset:32                           // 00000003DAB0: D8D80020 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DAB8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000003DABC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003DAC4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000003DAC8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003DACC: 8C7E017E
	v_and_b32_e32 v132, 0x200, v133                            // 00000003DAD0: 37090AFF 00000200
	s_or_b32 s1, s2, 9                                         // 00000003DAD8: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003DADC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000003DAE0: 7C874601
	.long 0xd44d0001                                           // 00000003DAE4: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003DAE8: 02030880
	s_and_b32 s10, vcc_lo, s1                                  // 00000003DAEC: 8B0A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003DAF0: BF870009
	s_and_saveexec_b32 s1, s10                                 // 00000003DAF4: BE81200A
	s_cbranch_execz 7                                          // 00000003DAF8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1818>
	ds_load_b32 v132, v165 offset:36                           // 00000003DAFC: D8D80024 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DB04: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000003DB08: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003DB10: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000003DB14: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003DB18: 8C7E017E
	v_and_b32_e32 v132, 0x400, v133                            // 00000003DB1C: 37090AFF 00000400
	s_or_b32 s1, s2, 10                                        // 00000003DB24: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003DB28: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000003DB2C: 7C874601
	.long 0xd44d0001                                           // 00000003DB30: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003DB34: 02030880
	s_and_b32 s7, vcc_lo, s1                                   // 00000003DB38: 8B07016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003DB3C: BF870009
	s_and_saveexec_b32 s1, s7                                  // 00000003DB40: BE812007
	s_cbranch_execz 7                                          // 00000003DB44: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1864>
	ds_load_b32 v132, v165 offset:40                           // 00000003DB48: D8D80028 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DB50: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000003DB54: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003DB5C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000003DB60: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003DB64: 8C7E017E
	v_and_b32_e32 v132, 0x800, v133                            // 00000003DB68: 37090AFF 00000800
	s_or_b32 s1, s2, 11                                        // 00000003DB70: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003DB74: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000003DB78: 7C874601
	.long 0xd44d0001                                           // 00000003DB7C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003DB80: 02030880
	s_and_b32 s8, vcc_lo, s1                                   // 00000003DB84: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003DB88: BF870009
	s_and_saveexec_b32 s1, s8                                  // 00000003DB8C: BE812008
	s_cbranch_execz 7                                          // 00000003DB90: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18b0>
	ds_load_b32 v132, v165 offset:44                           // 00000003DB94: D8D8002C 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DB9C: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000003DBA0: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003DBA8: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000003DBAC: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003DBB0: 8C7E017E
	v_and_b32_e32 v132, 0x1000, v133                           // 00000003DBB4: 37090AFF 00001000
	s_or_b32 s1, s2, 12                                        // 00000003DBBC: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003DBC0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000003DBC4: 7C874601
	.long 0xd44d0001                                           // 00000003DBC8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003DBCC: 02030880
	s_and_b32 s5, vcc_lo, s1                                   // 00000003DBD0: 8B05016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003DBD4: BF870009
	s_and_saveexec_b32 s1, s5                                  // 00000003DBD8: BE812005
	s_cbranch_execz 7                                          // 00000003DBDC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18fc>
	ds_load_b32 v132, v165 offset:48                           // 00000003DBE0: D8D80030 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DBE8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000003DBEC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003DBF4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000003DBF8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003DBFC: 8C7E017E
	v_and_b32_e32 v132, 0x2000, v133                           // 00000003DC00: 37090AFF 00002000
	s_or_b32 s1, s2, 13                                        // 00000003DC08: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003DC0C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000003DC10: 7C874601
	.long 0xd44d0001                                           // 00000003DC14: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003DC18: 02030880
	s_and_b32 s6, vcc_lo, s1                                   // 00000003DC1C: 8B06016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003DC20: BF870009
	s_and_saveexec_b32 s1, s6                                  // 00000003DC24: BE812006
	s_cbranch_execz 7                                          // 00000003DC28: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1948>
	ds_load_b32 v132, v165 offset:52                           // 00000003DC2C: D8D80034 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DC34: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000003DC38: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003DC40: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000003DC44: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003DC48: 8C7E017E
	v_and_b32_e32 v132, 0x4000, v133                           // 00000003DC4C: 37090AFF 00004000
	s_or_b32 s1, s2, 14                                        // 00000003DC54: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003DC58: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000003DC5C: 7C874601
	.long 0xd44d0001                                           // 00000003DC60: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003DC64: 02030880
	s_and_b32 s4, vcc_lo, s1                                   // 00000003DC68: 8B04016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003DC6C: BF870009
	s_and_saveexec_b32 s1, s4                                  // 00000003DC70: BE812004
	s_cbranch_execz 7                                          // 00000003DC74: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1994>
	ds_load_b32 v132, v165 offset:56                           // 00000003DC78: D8D80038 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DC80: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000003DC84: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003DC8C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000003DC90: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003DC94: 8C7E017E
	v_and_b32_e32 v132, 0x8000, v133                           // 00000003DC98: 37090AFF 00008000
	s_or_b32 s2, s2, 15                                        // 00000003DCA0: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003DCA4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v163                          // 00000003DCA8: 7C874602
	.long 0xd44d0001                                           // 00000003DCAC: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000003DCB0: 02030880
	s_and_b32 s1, vcc_lo, s1                                   // 00000003DCB4: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003DCB8: BF870009
	s_and_saveexec_b32 s2, s1                                  // 00000003DCBC: BE822001
	s_cbranch_execz 7                                          // 00000003DCC0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19e0>
	ds_load_b32 v132, v165 offset:60                           // 00000003DCC4: D8D8003C 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DCCC: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000003DCD0: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003DCD8: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000003DCDC: 21070983
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003DCE0: 8C7E027E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v133, 0           // 00000003DCE4: CA100080 84840080
	s_and_saveexec_b32 s2, s37                                 // 00000003DCEC: BE822025
	s_cbranch_execz 18                                         // 00000003DCF0: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a3c>
	ds_load_b32 v133, v165                                     // 00000003DCF4: D8D80000 850000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DCFC: BF89FC07
	v_sub_f32_e32 v133, v133, v131                             // 00000003DD00: 090B0785
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003DD04: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v133                  // 00000003DD08: 7C290AFF C2FC0000
	v_cndmask_b32_e64 v134, 0, 0x42800000, vcc_lo              // 00000003DD10: D5010086 01A9FE80 42800000
	v_add_f32_e32 v133, v133, v134                             // 00000003DD1C: 070B0D85
	v_cndmask_b32_e64 v134, 0, 0xffffffc0, vcc_lo              // 00000003DD20: D5010086 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003DD2C: BF870292
	v_exp_f32_e32 v133, v133                                   // 00000003DD30: 7F0A4B85
	.long 0xd71c0085                                           // 00000003DD34: D71C0085
	v_cndmask_b32_e32 v1, v133, v134, vcc_lo                   // 00000003DD38: 02030D85
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003DD3C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003DD40: BF870091
	v_bfe_u32 v134, v133, 16, 1                                // 00000003DD44: D6100086 02052185
	v_add3_u32 v134, v133, v134, 0x7fff                        // 00000003DD4C: D6550086 03FF0D85 00007FFF
	ds_store_b16_d16_hi v166, v134                             // 00000003DD58: DA840000 000086A6
	s_and_saveexec_b32 s2, s36                                 // 00000003DD60: BE822024
	s_cbranch_execz 18                                         // 00000003DD64: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ab0>
	ds_load_b32 v132, v165 offset:4                            // 00000003DD68: D8D80004 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DD70: BF89FC07
	v_sub_f32_e32 v132, v132, v131                             // 00000003DD74: 09090784
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003DD78: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v132                  // 00000003DD7C: 7C2908FF C2FC0000
	v_cndmask_b32_e64 v134, 0, 0x42800000, vcc_lo              // 00000003DD84: D5010086 01A9FE80 42800000
	v_add_f32_e32 v132, v132, v134                             // 00000003DD90: 07090D84
	v_cndmask_b32_e64 v134, 0, 0xffffffc0, vcc_lo              // 00000003DD94: D5010086 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003DDA0: BF870292
	v_exp_f32_e32 v132, v132                                   // 00000003DDA4: 7F084B84
	.long 0xd71c0084                                           // 00000003DDA8: D71C0084
	v_cndmask_b32_e32 v1, v132, v134, vcc_lo                   // 00000003DDAC: 02030D84
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003DDB0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003DDB4: BF870121
	v_bfe_u32 v134, v132, 16, 1                                // 00000003DDB8: D6100086 02052184
	v_mov_b32_e32 v135, 0                                      // 00000003DDC0: 7F0E0280
	v_add3_u32 v136, v132, v134, 0x7fff                        // 00000003DDC4: D6550088 03FF0D84 00007FFF
	v_mov_b32_e32 v134, 0                                      // 00000003DDD0: 7F0C0280
	ds_store_b16_d16_hi v166, v136 offset:2                    // 00000003DDD4: DA840002 000088A6
	s_and_saveexec_b32 s2, s34                                 // 00000003DDDC: BE822022
	s_cbranch_execz 18                                         // 00000003DDE0: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b2c>
	ds_load_b32 v135, v165 offset:8                            // 00000003DDE4: D8D80008 870000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DDEC: BF89FC07
	v_sub_f32_e32 v135, v135, v131                             // 00000003DDF0: 090F0787
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003DDF4: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v135                  // 00000003DDF8: 7C290EFF C2FC0000
	v_cndmask_b32_e64 v136, 0, 0x42800000, vcc_lo              // 00000003DE00: D5010088 01A9FE80 42800000
	v_add_f32_e32 v135, v135, v136                             // 00000003DE0C: 070F1187
	v_cndmask_b32_e64 v136, 0, 0xffffffc0, vcc_lo              // 00000003DE10: D5010088 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003DE1C: BF870292
	v_exp_f32_e32 v135, v135                                   // 00000003DE20: 7F0E4B87
	.long 0xd71c0087                                           // 00000003DE24: D71C0087
	v_cndmask_b32_e32 v1, v135, v136, vcc_lo                   // 00000003DE28: 02031187
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003DE2C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003DE30: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 00000003DE34: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 00000003DE3C: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v166, v136 offset:4                    // 00000003DE48: DA840004 000088A6
	s_and_saveexec_b32 s2, s35                                 // 00000003DE50: BE822023
	s_cbranch_execz 18                                         // 00000003DE54: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ba0>
	ds_load_b32 v134, v165 offset:12                           // 00000003DE58: D8D8000C 860000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DE60: BF89FC07
	v_sub_f32_e32 v134, v134, v131                             // 00000003DE64: 090D0786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003DE68: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v134                  // 00000003DE6C: 7C290CFF C2FC0000
	v_cndmask_b32_e64 v136, 0, 0x42800000, vcc_lo              // 00000003DE74: D5010088 01A9FE80 42800000
	v_add_f32_e32 v134, v134, v136                             // 00000003DE80: 070D1186
	v_cndmask_b32_e64 v136, 0, 0xffffffc0, vcc_lo              // 00000003DE84: D5010088 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003DE90: BF870292
	v_exp_f32_e32 v134, v134                                   // 00000003DE94: 7F0C4B86
	.long 0xd71c0086                                           // 00000003DE98: D71C0086
	v_cndmask_b32_e32 v1, v134, v136, vcc_lo                   // 00000003DE9C: 02031186
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003DEA0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003DEA4: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 00000003DEA8: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 00000003DEB0: 7F120280
	v_add3_u32 v146, v134, v136, 0x7fff                        // 00000003DEB4: D6550092 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 00000003DEC0: 7F100280
	ds_store_b16_d16_hi v166, v146 offset:6                    // 00000003DEC4: DA840006 000092A6
	s_and_saveexec_b32 s2, s31                                 // 00000003DECC: BE82201F
	s_cbranch_execz 18                                         // 00000003DED0: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c1c>
	ds_load_b32 v137, v165 offset:16                           // 00000003DED4: D8D80010 890000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DEDC: BF89FC07
	v_sub_f32_e32 v137, v137, v131                             // 00000003DEE0: 09130789
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003DEE4: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v137                  // 00000003DEE8: 7C2912FF C2FC0000
	v_cndmask_b32_e64 v146, 0, 0x42800000, vcc_lo              // 00000003DEF0: D5010092 01A9FE80 42800000
	v_add_f32_e32 v137, v137, v146                             // 00000003DEFC: 07132589
	v_cndmask_b32_e64 v146, 0, 0xffffffc0, vcc_lo              // 00000003DF00: D5010092 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003DF0C: BF870292
	v_exp_f32_e32 v137, v137                                   // 00000003DF10: 7F124B89
	.long 0xd71c0089                                           // 00000003DF14: D71C0089
	v_cndmask_b32_e32 v1, v137, v146, vcc_lo                   // 00000003DF18: 02032589
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003DF1C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003DF20: BF870091
	v_bfe_u32 v146, v137, 16, 1                                // 00000003DF24: D6100092 02052189
	v_add3_u32 v146, v137, v146, 0x7fff                        // 00000003DF2C: D6550092 03FF2589 00007FFF
	ds_store_b16_d16_hi v166, v146 offset:8                    // 00000003DF38: DA840008 000092A6
	s_and_saveexec_b32 s2, s33                                 // 00000003DF40: BE822021
	s_cbranch_execz 18                                         // 00000003DF44: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c90>
	ds_load_b32 v136, v165 offset:20                           // 00000003DF48: D8D80014 880000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DF50: BF89FC07
	v_sub_f32_e32 v136, v136, v131                             // 00000003DF54: 09110788
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003DF58: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v136                  // 00000003DF5C: 7C2910FF C2FC0000
	v_cndmask_b32_e64 v146, 0, 0x42800000, vcc_lo              // 00000003DF64: D5010092 01A9FE80 42800000
	v_add_f32_e32 v136, v136, v146                             // 00000003DF70: 07112588
	v_cndmask_b32_e64 v146, 0, 0xffffffc0, vcc_lo              // 00000003DF74: D5010092 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003DF80: BF870292
	v_exp_f32_e32 v136, v136                                   // 00000003DF84: 7F104B88
	.long 0xd71c0088                                           // 00000003DF88: D71C0088
	v_cndmask_b32_e32 v1, v136, v146, vcc_lo                   // 00000003DF8C: 02032588
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003DF90: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003DF94: BF870121
	v_bfe_u32 v146, v136, 16, 1                                // 00000003DF98: D6100092 02052188
	v_mov_b32_e32 v147, 0                                      // 00000003DFA0: 7F260280
	v_add3_u32 v148, v136, v146, 0x7fff                        // 00000003DFA4: D6550094 03FF2588 00007FFF
	v_mov_b32_e32 v146, 0                                      // 00000003DFB0: 7F240280
	ds_store_b16_d16_hi v166, v148 offset:10                   // 00000003DFB4: DA84000A 000094A6
	s_and_saveexec_b32 s2, s27                                 // 00000003DFBC: BE82201B
	s_cbranch_execz 18                                         // 00000003DFC0: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d0c>
	ds_load_b32 v147, v165 offset:24                           // 00000003DFC4: D8D80018 930000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003DFCC: BF89FC07
	v_sub_f32_e32 v147, v147, v131                             // 00000003DFD0: 09270793
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003DFD4: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v147                  // 00000003DFD8: 7C2926FF C2FC0000
	v_cndmask_b32_e64 v148, 0, 0x42800000, vcc_lo              // 00000003DFE0: D5010094 01A9FE80 42800000
	v_add_f32_e32 v147, v147, v148                             // 00000003DFEC: 07272993
	v_cndmask_b32_e64 v148, 0, 0xffffffc0, vcc_lo              // 00000003DFF0: D5010094 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003DFFC: BF870292
	v_exp_f32_e32 v147, v147                                   // 00000003E000: 7F264B93
	.long 0xd71c0093                                           // 00000003E004: D71C0093
	v_cndmask_b32_e32 v1, v147, v148, vcc_lo                   // 00000003E008: 02032993
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003E00C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E010: BF870091
	v_bfe_u32 v148, v147, 16, 1                                // 00000003E014: D6100094 02052193
	v_add3_u32 v148, v147, v148, 0x7fff                        // 00000003E01C: D6550094 03FF2993 00007FFF
	ds_store_b16_d16_hi v166, v148 offset:12                   // 00000003E028: DA84000C 000094A6
	s_and_saveexec_b32 s2, s30                                 // 00000003E030: BE82201E
	s_cbranch_execz 18                                         // 00000003E034: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d80>
	ds_load_b32 v146, v165 offset:28                           // 00000003E038: D8D8001C 920000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003E040: BF89FC07
	v_sub_f32_e32 v146, v146, v131                             // 00000003E044: 09250792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003E048: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v146                  // 00000003E04C: 7C2924FF C2FC0000
	v_cndmask_b32_e64 v148, 0, 0x42800000, vcc_lo              // 00000003E054: D5010094 01A9FE80 42800000
	v_add_f32_e32 v146, v146, v148                             // 00000003E060: 07252992
	v_cndmask_b32_e64 v148, 0, 0xffffffc0, vcc_lo              // 00000003E064: D5010094 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003E070: BF870292
	v_exp_f32_e32 v146, v146                                   // 00000003E074: 7F244B92
	.long 0xd71c0092                                           // 00000003E078: D71C0092
	v_cndmask_b32_e32 v1, v146, v148, vcc_lo                   // 00000003E07C: 02032992
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003E080: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003E084: BF870121
	v_bfe_u32 v148, v146, 16, 1                                // 00000003E088: D6100094 02052192
	v_mov_b32_e32 v149, 0                                      // 00000003E090: 7F2A0280
	v_add3_u32 v150, v146, v148, 0x7fff                        // 00000003E094: D6550096 03FF2992 00007FFF
	v_mov_b32_e32 v148, 0                                      // 00000003E0A0: 7F280280
	ds_store_b16_d16_hi v166, v150 offset:14                   // 00000003E0A4: DA84000E 000096A6
	s_and_saveexec_b32 s2, s9                                  // 00000003E0AC: BE822009
	s_cbranch_execz 18                                         // 00000003E0B0: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1dfc>
	ds_load_b32 v149, v165 offset:32                           // 00000003E0B4: D8D80020 950000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003E0BC: BF89FC07
	v_sub_f32_e32 v149, v149, v131                             // 00000003E0C0: 092B0795
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003E0C4: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v149                  // 00000003E0C8: 7C292AFF C2FC0000
	v_cndmask_b32_e64 v150, 0, 0x42800000, vcc_lo              // 00000003E0D0: D5010096 01A9FE80 42800000
	v_add_f32_e32 v149, v149, v150                             // 00000003E0DC: 072B2D95
	v_cndmask_b32_e64 v150, 0, 0xffffffc0, vcc_lo              // 00000003E0E0: D5010096 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003E0EC: BF870292
	v_exp_f32_e32 v149, v149                                   // 00000003E0F0: 7F2A4B95
	.long 0xd71c0095                                           // 00000003E0F4: D71C0095
	v_cndmask_b32_e32 v1, v149, v150, vcc_lo                   // 00000003E0F8: 02032D95
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003E0FC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E100: BF870091
	v_bfe_u32 v150, v149, 16, 1                                // 00000003E104: D6100096 02052195
	v_add3_u32 v150, v149, v150, 0x7fff                        // 00000003E10C: D6550096 03FF2D95 00007FFF
	ds_store_b16_d16_hi v166, v150 offset:16                   // 00000003E118: DA840010 000096A6
	s_and_saveexec_b32 s2, s10                                 // 00000003E120: BE82200A
	s_cbranch_execz 18                                         // 00000003E124: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e70>
	ds_load_b32 v148, v165 offset:36                           // 00000003E128: D8D80024 940000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003E130: BF89FC07
	v_sub_f32_e32 v148, v148, v131                             // 00000003E134: 09290794
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003E138: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v148                  // 00000003E13C: 7C2928FF C2FC0000
	v_cndmask_b32_e64 v150, 0, 0x42800000, vcc_lo              // 00000003E144: D5010096 01A9FE80 42800000
	v_add_f32_e32 v148, v148, v150                             // 00000003E150: 07292D94
	v_cndmask_b32_e64 v150, 0, 0xffffffc0, vcc_lo              // 00000003E154: D5010096 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003E160: BF870292
	v_exp_f32_e32 v148, v148                                   // 00000003E164: 7F284B94
	.long 0xd71c0094                                           // 00000003E168: D71C0094
	v_cndmask_b32_e32 v1, v148, v150, vcc_lo                   // 00000003E16C: 02032D94
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003E170: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003E174: BF870121
	v_bfe_u32 v150, v148, 16, 1                                // 00000003E178: D6100096 02052194
	v_mov_b32_e32 v151, 0                                      // 00000003E180: 7F2E0280
	v_add3_u32 v152, v148, v150, 0x7fff                        // 00000003E184: D6550098 03FF2D94 00007FFF
	v_mov_b32_e32 v150, 0                                      // 00000003E190: 7F2C0280
	ds_store_b16_d16_hi v166, v152 offset:18                   // 00000003E194: DA840012 000098A6
	s_and_saveexec_b32 s2, s7                                  // 00000003E19C: BE822007
	s_cbranch_execz 18                                         // 00000003E1A0: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1eec>
	ds_load_b32 v151, v165 offset:40                           // 00000003E1A4: D8D80028 970000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003E1AC: BF89FC07
	v_sub_f32_e32 v151, v151, v131                             // 00000003E1B0: 092F0797
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003E1B4: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v151                  // 00000003E1B8: 7C292EFF C2FC0000
	v_cndmask_b32_e64 v152, 0, 0x42800000, vcc_lo              // 00000003E1C0: D5010098 01A9FE80 42800000
	v_add_f32_e32 v151, v151, v152                             // 00000003E1CC: 072F3197
	v_cndmask_b32_e64 v152, 0, 0xffffffc0, vcc_lo              // 00000003E1D0: D5010098 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003E1DC: BF870292
	v_exp_f32_e32 v151, v151                                   // 00000003E1E0: 7F2E4B97
	.long 0xd71c0097                                           // 00000003E1E4: D71C0097
	v_cndmask_b32_e32 v1, v151, v152, vcc_lo                   // 00000003E1E8: 02033197
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003E1EC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E1F0: BF870091
	v_bfe_u32 v152, v151, 16, 1                                // 00000003E1F4: D6100098 02052197
	v_add3_u32 v152, v151, v152, 0x7fff                        // 00000003E1FC: D6550098 03FF3197 00007FFF
	ds_store_b16_d16_hi v166, v152 offset:20                   // 00000003E208: DA840014 000098A6
	s_and_saveexec_b32 s2, s8                                  // 00000003E210: BE822008
	s_cbranch_execz 18                                         // 00000003E214: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f60>
	ds_load_b32 v150, v165 offset:44                           // 00000003E218: D8D8002C 960000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003E220: BF89FC07
	v_sub_f32_e32 v150, v150, v131                             // 00000003E224: 092D0796
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003E228: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v150                  // 00000003E22C: 7C292CFF C2FC0000
	v_cndmask_b32_e64 v152, 0, 0x42800000, vcc_lo              // 00000003E234: D5010098 01A9FE80 42800000
	v_add_f32_e32 v150, v150, v152                             // 00000003E240: 072D3196
	v_cndmask_b32_e64 v152, 0, 0xffffffc0, vcc_lo              // 00000003E244: D5010098 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003E250: BF870292
	v_exp_f32_e32 v150, v150                                   // 00000003E254: 7F2C4B96
	.long 0xd71c0096                                           // 00000003E258: D71C0096
	v_cndmask_b32_e32 v1, v150, v152, vcc_lo                   // 00000003E25C: 02033196
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003E260: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003E264: BF870121
	v_bfe_u32 v152, v150, 16, 1                                // 00000003E268: D6100098 02052196
	v_mov_b32_e32 v153, 0                                      // 00000003E270: 7F320280
	v_add3_u32 v178, v150, v152, 0x7fff                        // 00000003E274: D65500B2 03FF3196 00007FFF
	v_mov_b32_e32 v152, 0                                      // 00000003E280: 7F300280
	ds_store_b16_d16_hi v166, v178 offset:22                   // 00000003E284: DA840016 0000B2A6
	s_and_saveexec_b32 s2, s5                                  // 00000003E28C: BE822005
	s_cbranch_execz 18                                         // 00000003E290: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1fdc>
	ds_load_b32 v153, v165 offset:48                           // 00000003E294: D8D80030 990000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003E29C: BF89FC07
	v_sub_f32_e32 v153, v153, v131                             // 00000003E2A0: 09330799
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003E2A4: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v153                  // 00000003E2A8: 7C2932FF C2FC0000
	v_cndmask_b32_e64 v178, 0, 0x42800000, vcc_lo              // 00000003E2B0: D50100B2 01A9FE80 42800000
	v_add_f32_e32 v153, v153, v178                             // 00000003E2BC: 07336599
	v_cndmask_b32_e64 v178, 0, 0xffffffc0, vcc_lo              // 00000003E2C0: D50100B2 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003E2CC: BF870292
	v_exp_f32_e32 v153, v153                                   // 00000003E2D0: 7F324B99
	.long 0xd71c0099                                           // 00000003E2D4: D71C0099
	v_cndmask_b32_e32 v1, v153, v178, vcc_lo                   // 00000003E2D8: 02036599
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003E2DC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E2E0: BF870091
	v_bfe_u32 v178, v153, 16, 1                                // 00000003E2E4: D61000B2 02052199
	v_add3_u32 v178, v153, v178, 0x7fff                        // 00000003E2EC: D65500B2 03FF6599 00007FFF
	ds_store_b16_d16_hi v166, v178 offset:24                   // 00000003E2F8: DA840018 0000B2A6
	s_and_saveexec_b32 s2, s6                                  // 00000003E300: BE822006
	s_cbranch_execz 18                                         // 00000003E304: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2050>
	ds_load_b32 v152, v165 offset:52                           // 00000003E308: D8D80034 980000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003E310: BF89FC07
	v_sub_f32_e32 v152, v152, v131                             // 00000003E314: 09310798
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003E318: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v152                  // 00000003E31C: 7C2930FF C2FC0000
	v_cndmask_b32_e64 v178, 0, 0x42800000, vcc_lo              // 00000003E324: D50100B2 01A9FE80 42800000
	v_add_f32_e32 v152, v152, v178                             // 00000003E330: 07316598
	v_cndmask_b32_e64 v178, 0, 0xffffffc0, vcc_lo              // 00000003E334: D50100B2 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003E340: BF870292
	v_exp_f32_e32 v152, v152                                   // 00000003E344: 7F304B98
	.long 0xd71c0098                                           // 00000003E348: D71C0098
	v_cndmask_b32_e32 v1, v152, v178, vcc_lo                   // 00000003E34C: 02036598
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003E350: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003E354: BF870121
	v_bfe_u32 v178, v152, 16, 1                                // 00000003E358: D61000B2 02052198
	v_mov_b32_e32 v179, 0                                      // 00000003E360: 7F660280
	v_add3_u32 v180, v152, v178, 0x7fff                        // 00000003E364: D65500B4 03FF6598 00007FFF
	v_mov_b32_e32 v178, 0                                      // 00000003E370: 7F640280
	ds_store_b16_d16_hi v166, v180 offset:26                   // 00000003E374: DA84001A 0000B4A6
	s_and_saveexec_b32 s2, s4                                  // 00000003E37C: BE822004
	s_cbranch_execz 18                                         // 00000003E380: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x20cc>
	ds_load_b32 v179, v165 offset:56                           // 00000003E384: D8D80038 B30000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003E38C: BF89FC07
	v_sub_f32_e32 v179, v179, v131                             // 00000003E390: 096707B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003E394: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v179                  // 00000003E398: 7C2966FF C2FC0000
	v_cndmask_b32_e64 v180, 0, 0x42800000, vcc_lo              // 00000003E3A0: D50100B4 01A9FE80 42800000
	v_add_f32_e32 v179, v179, v180                             // 00000003E3AC: 076769B3
	v_cndmask_b32_e64 v180, 0, 0xffffffc0, vcc_lo              // 00000003E3B0: D50100B4 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003E3BC: BF870292
	v_exp_f32_e32 v179, v179                                   // 00000003E3C0: 7F664BB3
	.long 0xd71c00b3                                           // 00000003E3C4: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 00000003E3C8: 020369B3
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003E3CC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E3D0: BF870091
	v_bfe_u32 v180, v179, 16, 1                                // 00000003E3D4: D61000B4 020521B3
	v_add3_u32 v180, v179, v180, 0x7fff                        // 00000003E3DC: D65500B4 03FF69B3 00007FFF
	ds_store_b16_d16_hi v166, v180 offset:28                   // 00000003E3E8: DA84001C 0000B4A6
	s_and_saveexec_b32 s2, s1                                  // 00000003E3F0: BE822001
	s_cbranch_execz 18                                         // 00000003E3F4: BFA50012 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2140>
	ds_load_b32 v178, v165 offset:60                           // 00000003E3F8: D8D8003C B20000A5
	s_waitcnt lgkmcnt(0)                                       // 00000003E400: BF89FC07
	v_sub_f32_e32 v178, v178, v131                             // 00000003E404: 096507B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003E408: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v178                  // 00000003E40C: 7C2964FF C2FC0000
	v_cndmask_b32_e64 v180, 0, 0x42800000, vcc_lo              // 00000003E414: D50100B4 01A9FE80 42800000
	v_add_f32_e32 v178, v178, v180                             // 00000003E420: 076569B2
	v_cndmask_b32_e64 v180, 0, 0xffffffc0, vcc_lo              // 00000003E424: D50100B4 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003E430: BF870292
	v_exp_f32_e32 v178, v178                                   // 00000003E434: 7F644BB2
	.long 0xd71c00b2                                           // 00000003E438: D71C00B2
	v_cndmask_b32_e32 v1, v178, v180, vcc_lo                   // 00000003E43C: 020369B2
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003E440: 8C7E027E
	v_add_f32_e32 v132, v133, v132                             // 00000003E444: 07090985
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003E448: BF870122
	v_bfe_u32 v133, v178, 16, 1                                // 00000003E44C: D6100085 020521B2
	s_mov_b32 s1, 0                                            // 00000003E454: BE810080
	v_add_f32_e32 v132, v132, v135                             // 00000003E458: 07090F84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003E45C: BF870112
	v_add3_u32 v133, v178, v133, 0x7fff                        // 00000003E460: D6550085 03FF0BB2 00007FFF
	v_add_f32_e32 v132, v132, v134                             // 00000003E46C: 07090D84
	ds_store_b16_d16_hi v166, v133 offset:30                   // 00000003E470: DA84001E 000085A6
	v_add_f32_e32 v132, v132, v137                             // 00000003E478: 07091384
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E47C: BF870091
	v_add_f32_e32 v132, v132, v136                             // 00000003E480: 07091184
	v_add_f32_e32 v132, v132, v147                             // 00000003E484: 07092784
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E488: BF870091
	v_add_f32_e32 v132, v132, v146                             // 00000003E48C: 07092584
	v_add_f32_e32 v132, v132, v149                             // 00000003E490: 07092B84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E494: BF870091
	v_add_f32_e32 v132, v132, v148                             // 00000003E498: 07092984
	v_add_f32_e32 v132, v132, v151                             // 00000003E49C: 07092F84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E4A0: BF870091
	v_add_f32_e32 v132, v132, v150                             // 00000003E4A4: 07092D84
	v_add_f32_e32 v132, v132, v153                             // 00000003E4A8: 07093384
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E4AC: BF870091
	v_add_f32_e32 v132, v132, v152                             // 00000003E4B0: 07093184
	v_add_f32_e32 v132, v132, v179                             // 00000003E4B4: 07096784
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003E4B8: BF870001
	v_add_f32_e32 v132, v132, v178                             // 00000003E4BC: 07096584
	s_and_b32 vcc_lo, exec_lo, s1                              // 00000003E4C0: 8B6A017E
	s_cbranch_vccz 433                                         // 00000003E4C4: BFA301B1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x288c>
	ds_load_2addr_b32 v[132:133], v165 offset1:1               // 00000003E4C8: D8DC0100 840000A5
	ds_load_2addr_b32 v[134:135], v165 offset0:2 offset1:3     // 00000003E4D0: D8DC0302 860000A5
	ds_load_2addr_b32 v[136:137], v165 offset0:4 offset1:5     // 00000003E4D8: D8DC0504 880000A5
	ds_load_2addr_b32 v[146:147], v165 offset0:6 offset1:7     // 00000003E4E0: D8DC0706 920000A5
	ds_load_2addr_b32 v[148:149], v165 offset0:8 offset1:9     // 00000003E4E8: D8DC0908 940000A5
	ds_load_2addr_b32 v[150:151], v165 offset0:10 offset1:11   // 00000003E4F0: D8DC0B0A 960000A5
	ds_load_2addr_b32 v[152:153], v165 offset0:12 offset1:13   // 00000003E4F8: D8DC0D0C 980000A5
	ds_load_2addr_b32 v[178:179], v165 offset0:14 offset1:15   // 00000003E500: D8DC0F0E B20000A5
	.long 0xd59c40b4                                           // 00000003E508: D59C40B4
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 00000003E50C: 02010080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003E510: BF870001
	.long 0xd59c48b6                                           // 00000003E514: D59C48B6
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                   // 00000003E518: 020101B4
	.long 0xd59c48b5                                           // 00000003E51C: D59C48B5
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                   // 00000003E520: 020101B4
	.long 0xd59c48b8                                           // 00000003E524: D59C48B8
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                   // 00000003E528: 020101B4
	.long 0xd59c48b7                                           // 00000003E52C: D59C48B7
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                   // 00000003E530: 020101B4
	s_waitcnt lgkmcnt(7)                                       // 00000003E534: BF89FC77
	v_max3_f32 v131, v130, v132, v133                          // 00000003E538: D61C0083 06170982
	s_waitcnt lgkmcnt(6)                                       // 00000003E540: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003E544: BF8700A1
	v_max3_f32 v131, v131, v134, v135                          // 00000003E548: D61C0083 061F0D83
	s_waitcnt lgkmcnt(5)                                       // 00000003E550: BF89FC57
	v_max3_f32 v131, v131, v136, v137                          // 00000003E554: D61C0083 06271183
	s_waitcnt lgkmcnt(4)                                       // 00000003E55C: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003E560: BF8700A1
	v_max3_f32 v131, v131, v146, v147                          // 00000003E564: D61C0083 064F2583
	s_waitcnt lgkmcnt(3)                                       // 00000003E56C: BF89FC37
	v_max3_f32 v131, v131, v148, v149                          // 00000003E570: D61C0083 06572983
	s_waitcnt lgkmcnt(2)                                       // 00000003E578: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003E57C: BF8700A1
	v_max3_f32 v131, v131, v150, v151                          // 00000003E580: D61C0083 065F2D83
	s_waitcnt lgkmcnt(1)                                       // 00000003E588: BF89FC17
	v_max3_f32 v131, v131, v152, v153                          // 00000003E58C: D61C0083 06673183
	s_waitcnt lgkmcnt(0)                                       // 00000003E594: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E598: BF870091
	v_max3_f32 v131, v131, v178, v179                          // 00000003E59C: D61C0083 06CF6583
	v_sub_f32_e32 v132, v132, v131                             // 00000003E5A4: 09090784
	v_sub_f32_e32 v149, v149, v131                             // 00000003E5A8: 092B0795
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003E5AC: BF870112
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v132                  // 00000003E5B0: 7C2908FF C2FC0000
	.long 0xd4140009                                           // 00000003E5B8: D4140009
	v_cndmask_b32_e32 v1, 0xc2fc0000, v149, vcc_lo             // 00000003E5BC: 02032AFF C2FC0000
	v_cndmask_b32_e64 v185, 0, 0x42800000, vcc_lo              // 00000003E5C4: D50100B9 01A9FE80 42800000
	v_sub_f32_e32 v133, v133, v131                             // 00000003E5D0: 090B0785
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003E5D4: BF870223
	v_cndmask_b32_e64 v193, 0, 0x42800000, s9                  // 00000003E5D8: D50100C1 0025FE80 42800000
	v_sub_f32_e32 v136, v136, v131                             // 00000003E5E4: 09110788
	v_add_f32_e32 v132, v132, v185                             // 00000003E5E8: 07097384
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003E5EC: BF870214
	.long 0xd4140001                                           // 00000003E5F0: D4140001
	v_cndmask_b32_e32 v1, 0xc2fc0000, v133, vcc_lo             // 00000003E5F4: 02030AFF C2FC0000
	v_add_f32_e32 v149, v149, v193                             // 00000003E5FC: 072B8395
	s_delay_alu instid0(VALU_DEP_4)                            // 00000003E600: BF870004
	.long 0xd4140006                                           // 00000003E604: D4140006
	v_cndmask_b32_e32 v1, 0xc2fc0000, v136, vcc_lo             // 00000003E608: 020310FF C2FC0000
	v_cndmask_b32_e64 v185, 0, 0xffffffc0, vcc_lo              // 00000003E610: D50100B9 01A9FE80 FFFFFFC0
	v_exp_f32_e32 v132, v132                                   // 00000003E61C: 7F084B84
	v_cndmask_b32_e64 v186, 0, 0x42800000, s1                  // 00000003E620: D50100BA 0005FE80 42800000
	v_exp_f32_e32 v149, v149                                   // 00000003E62C: 7F2A4B95
	v_cndmask_b32_e64 v190, 0, 0x42800000, s6                  // 00000003E630: D50100BE 0019FE80 42800000
	v_sub_f32_e32 v137, v137, v131                             // 00000003E63C: 09130789
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003E640: BF870223
	v_add_f32_e32 v133, v133, v186                             // 00000003E644: 070B7585
	v_cndmask_b32_e64 v186, 0, 0xffffffc0, s1                  // 00000003E648: D50100BA 0005FE80 FFFFFFC0
	v_add_f32_e32 v136, v136, v190                             // 00000003E654: 07117D88
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000003E658: BF870314
	.long 0xd4140005                                           // 00000003E65C: D4140005
	v_cndmask_b32_e32 v1, 0xc2fc0000, v137, vcc_lo             // 00000003E660: 020312FF C2FC0000
	.long 0xd71c0084                                           // 00000003E668: D71C0084
	v_cndmask_b32_e32 v1, v132, v185, vcc_lo                   // 00000003E66C: 02037384
	v_exp_f32_e32 v133, v133                                   // 00000003E670: 7F0A4B85
	v_cndmask_b32_e64 v190, 0, 0xffffffc0, s6                  // 00000003E674: D50100BE 0019FE80 FFFFFFC0
	v_exp_f32_e32 v136, v136                                   // 00000003E680: 7F104B88
	v_cndmask_b32_e64 v189, 0, 0x42800000, s5                  // 00000003E684: D50100BD 0015FE80 42800000
	v_sub_f32_e32 v134, v134, v131                             // 00000003E690: 090D0786
	.long 0xd59c08b5                                           // 00000003E694: D59C08B5
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000003E698: 02010184
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000003E69C: BF870193
	v_add_f32_e32 v137, v137, v189                             // 00000003E6A0: 07137B89
	.long 0xd4140004                                           // 00000003E6A4: D4140004
	v_cndmask_b32_e32 v1, 0xc2fc0000, v134, vcc_lo             // 00000003E6A8: 02030CFF C2FC0000
	s_delay_alu instid0(TRANS32_DEP_2)                         // 00000003E6B0: BF870006
	.long 0xd71c0085                                           // 00000003E6B4: D71C0085
	v_cndmask_b32_e32 v1, v133, v186, vcc_lo                   // 00000003E6B8: 02037585
	v_sub_f32_e32 v146, v146, v131                             // 00000003E6BC: 09250792
	v_cndmask_b32_e64 v189, 0, 0xffffffc0, s5                  // 00000003E6C0: D50100BD 0015FE80 FFFFFFC0
	v_exp_f32_e32 v137, v137                                   // 00000003E6CC: 7F124B89
	v_cndmask_b32_e64 v188, 0, 0x42800000, s4                  // 00000003E6D0: D50100BC 0011FE80 42800000
	v_sub_f32_e32 v135, v135, v131                             // 00000003E6DC: 090F0787
	v_add_f32_e32 v185, v132, v133                             // 00000003E6E0: 07730B84
	.long 0xd4140008                                           // 00000003E6E4: D4140008
	v_cndmask_b32_e32 v1, 0xc2fc0000, v146, vcc_lo             // 00000003E6E8: 020324FF C2FC0000
	.long 0xd59c08b4                                           // 00000003E6F0: D59C08B4
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 00000003E6F4: 02010185
	v_add_f32_e32 v134, v134, v188                             // 00000003E6F8: 070D7986
	.long 0xd4140002                                           // 00000003E6FC: D4140002
	v_cndmask_b32_e32 v1, 0xc2fc0000, v135, vcc_lo             // 00000003E700: 02030EFF C2FC0000
	v_cndmask_b32_e64 v188, 0, 0xffffffc0, s4                  // 00000003E708: D50100BC 0011FE80 FFFFFFC0
	v_cndmask_b32_e64 v192, 0, 0x42800000, s8                  // 00000003E714: D50100C0 0021FE80 42800000
	v_sub_f32_e32 v147, v147, v131                             // 00000003E720: 09270793
	v_exp_f32_e32 v134, v134                                   // 00000003E724: 7F0C4B86
	v_cndmask_b32_e64 v187, 0, 0x42800000, s2                  // 00000003E728: D50100BB 0009FE80 42800000
	v_and_b32_e32 v186, 1, v180                                // 00000003E734: 37756881
	v_add_f32_e32 v146, v146, v192                             // 00000003E738: 07258192
	.long 0xd4140007                                           // 00000003E73C: D4140007
	v_cndmask_b32_e32 v1, 0xc2fc0000, v147, vcc_lo             // 00000003E740: 020326FF C2FC0000
	v_cndmask_b32_e64 v192, 0, 0xffffffc0, s8                  // 00000003E748: D50100C0 0021FE80 FFFFFFC0
	v_add_f32_e32 v135, v135, v187                             // 00000003E754: 070F7787
	v_cndmask_b32_e64 v187, 0, 0xffffffc0, s2                  // 00000003E758: D50100BB 0009FE80 FFFFFFC0
	v_exp_f32_e32 v146, v146                                   // 00000003E764: 7F244B92
	v_cndmask_b32_e64 v191, 0, 0x42800000, s7                  // 00000003E768: D50100BF 001DFE80 42800000
	.long 0xd71c0086                                           // 00000003E774: D71C0086
	v_cndmask_b32_e32 v1, v134, v188, vcc_lo                   // 00000003E778: 02037986
	v_exp_f32_e32 v135, v135                                   // 00000003E77C: 7F0E4B87
	v_sub_f32_e32 v148, v148, v131                             // 00000003E780: 09290794
	.long 0xd71c0089                                           // 00000003E784: D71C0089
	v_cndmask_b32_e32 v1, v137, v189, vcc_lo                   // 00000003E788: 02037B89
	.long 0xd71c0088                                           // 00000003E78C: D71C0088
	v_cndmask_b32_e32 v1, v136, v190, vcc_lo                   // 00000003E790: 02037D88
	.long 0xd59c08b6                                           // 00000003E794: D59C08B6
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 00000003E798: 02010186
	v_add_f32_e32 v147, v147, v191                             // 00000003E79C: 07277F93
	v_add_f32_e32 v185, v185, v134                             // 00000003E7A0: 07730DB9
	.long 0xd71c0092                                           // 00000003E7A4: D71C0092
	v_cndmask_b32_e32 v1, v146, v192, vcc_lo                   // 00000003E7A8: 02038192
	v_cndmask_b32_e64 v191, 0, 0xffffffc0, s7                  // 00000003E7AC: D50100BF 001DFE80 FFFFFFC0
	v_and_b32_e32 v182, 1, v182                                // 00000003E7B8: 376D6C81
	v_exp_f32_e32 v147, v147                                   // 00000003E7BC: 7F264B93
	.long 0xd71c0087                                           // 00000003E7C0: D71C0087
	v_cndmask_b32_e32 v1, v135, v187, vcc_lo                   // 00000003E7C4: 02037787
	.long 0xd59c08b8                                           // 00000003E7C8: D59C08B8
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                   // 00000003E7CC: 02010192
	v_and_b32_e32 v181, 1, v181                                // 00000003E7D0: 376B6A81
	.long 0xd414000a                                           // 00000003E7D4: D414000A
	v_cndmask_b32_e32 v1, 0xc2fc0000, v148, vcc_lo             // 00000003E7D8: 020328FF C2FC0000
	.long 0xd59c08b7                                           // 00000003E7E0: D59C08B7
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 00000003E7E4: 02010188
	.long 0xd59c08b4                                           // 00000003E7E8: D59C08B4
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 00000003E7EC: 02010187
	v_dual_add_f32 v185, v185, v135 :: v_dual_and_b32 v184, 1, v184// 00000003E7F0: C9250FB9 B9B97081
	v_add3_u32 v132, v132, v181, 0x7fff                        // 00000003E7F8: D6550084 03FF6B84 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003E804: BF870215
	.long 0xd71c0093                                           // 00000003E808: D71C0093
	v_cndmask_b32_e32 v1, v147, v191, vcc_lo                   // 00000003E80C: 02037F93
	v_and_b32_e32 v187, 1, v180                                // 00000003E810: 37776881
	.long 0xd59c08b4                                           // 00000003E814: D59C08B4
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 00000003E818: 02010189
	v_add_f32_e32 v181, v185, v136                             // 00000003E81C: 076B11B9
	v_cndmask_b32_e64 v194, 0, 0x42800000, s10                 // 00000003E820: D50100C2 0029FE80 42800000
	v_and_b32_e32 v183, 1, v183                                // 00000003E82C: 376F6E81
	v_add3_u32 v182, v134, v182, 0x7fff                        // 00000003E830: D65500B6 03FF6D86 00007FFF
	v_and_b32_e32 v185, 1, v180                                // 00000003E83C: 37736881
	.long 0xd59c08b4                                           // 00000003E840: D59C08B4
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 00000003E844: 02010193
	v_dual_add_f32 v181, v181, v137 :: v_dual_add_f32 v148, v148, v194// 00000003E848: C90913B5 B5958594
	v_add3_u32 v136, v136, v183, 0x7fff                        // 00000003E850: D6550088 03FF6F88 00007FFF
	v_add3_u32 v183, v146, v184, 0x7fff                        // 00000003E85C: D65500B7 03FF7192 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000003E868: BF870004
	v_and_b32_e32 v184, 1, v180                                // 00000003E86C: 37716881
	v_add3_u32 v134, v135, v187, 0x7fff                        // 00000003E870: D6550086 03FF7787 00007FFF
	v_add3_u32 v135, v137, v185, 0x7fff                        // 00000003E87C: D6550087 03FF7389 00007FFF
	v_dual_add_f32 v137, v181, v146 :: v_dual_sub_f32 v146, v150, v131// 00000003E888: C90B25B5 89930796
	v_sub_f32_e32 v150, v151, v131                             // 00000003E890: 092D0797
	v_cndmask_b32_e64 v151, 0, 0xffffffc0, s9                  // 00000003E894: D5010097 0025FE80 FFFFFFC0
	v_exp_f32_e32 v148, v148                                   // 00000003E8A0: 7F284B94
	.long 0xd59c0887                                           // 00000003E8A4: D59C0887
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 00000003E8A8: 02010188
	v_add3_u32 v136, v147, v184, 0x7fff                        // 00000003E8AC: D6550088 03FF7193 00007FFF
	.long 0xd4140001                                           // 00000003E8B8: D4140001
	v_cndmask_b32_e32 v1, 0xc2fc0000, v150, vcc_lo             // 00000003E8BC: 02032CFF C2FC0000
	.long 0xd59c0888                                           // 00000003E8C4: D59C0888
	v_cndmask_b32_e32 v0, v183, v128, vcc_lo                   // 00000003E8C8: 020101B7
	v_cndmask_b32_e64 v184, 0, 0xffffffc0, s10                 // 00000003E8CC: D50100B8 0029FE80 FFFFFFC0
	.long 0xd71c0095                                           // 00000003E8D8: D71C0095
	v_cndmask_b32_e32 v1, v149, v151, vcc_lo                   // 00000003E8DC: 02032F95
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v146                  // 00000003E8E0: 7C2924FF C2FC0000
	v_cndmask_b32_e64 v183, 0, 0x42800000, s1                  // 00000003E8E8: D50100B7 0005FE80 42800000
	.long 0xd59c0886                                           // 00000003E8F4: D59C0886
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                   // 00000003E8F8: 020101B6
	.long 0xd71c0094                                           // 00000003E8FC: D71C0094
	v_cndmask_b32_e32 v1, v148, v184, vcc_lo                   // 00000003E900: 02037194
	.long 0xd59c08b4                                           // 00000003E904: D59C08B4
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                   // 00000003E908: 02010195
	v_cndmask_b32_e64 v181, 0, 0x42800000, vcc_lo              // 00000003E90C: D50100B5 01A9FE80 42800000
	v_add_f32_e32 v150, v150, v183                             // 00000003E918: 072D6F96
	v_add3_u32 v133, v133, v186, 0x7fff                        // 00000003E91C: D6550085 03FF7585 00007FFF
	.long 0xd59c0885                                           // 00000003E928: D59C0885
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000003E92C: 02010184
	v_dual_add_f32 v137, v137, v147 :: v_dual_and_b32 v182, 1, v180// 00000003E930: C9252789 89B76881
	s_delay_alu instid0(VALU_DEP_4)                            // 00000003E938: BF870004
	v_exp_f32_e32 v147, v150                                   // 00000003E93C: 7F264B96
	.long 0xd59c0896                                           // 00000003E940: D59C0896
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                   // 00000003E944: 02010194
	.long 0xd59c4896                                           // 00000003E948: D59C4896
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                   // 00000003E94C: 020101B4
	v_add_f32_e32 v146, v146, v181                             // 00000003E950: 07256B92
	v_cndmask_b32_e64 v181, 0, 0xffffffc0, s1                  // 00000003E954: D50100B5 0005FE80 FFFFFFC0
	v_cndmask_b32_e64 v151, 0, 0xffffffc0, vcc_lo              // 00000003E960: D5010097 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003E96C: BF870214
	v_dual_add_f32 v137, v137, v148 :: v_dual_and_b32 v150, 1, v150// 00000003E970: C9252989 89972C81
	v_exp_f32_e32 v146, v146                                   // 00000003E978: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 00000003E97C: BF870186
	.long 0xd71c0093                                           // 00000003E980: D71C0093
	v_cndmask_b32_e32 v1, v147, v181, vcc_lo                   // 00000003E984: 02036B93
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000003E988: BF870252
	v_add3_u32 v132, v148, v150, 0x7fff                        // 00000003E98C: D6550084 03FF2D94 00007FFF
	v_sub_f32_e32 v150, v152, v131                             // 00000003E998: 092D0798
	v_sub_f32_e32 v148, v153, v131                             // 00000003E99C: 09290799
	v_dual_add_f32 v137, v137, v149 :: v_dual_sub_f32 v152, v178, v131// 00000003E9A0: C90B2B89 899907B2
	.long 0xd59c08b4                                           // 00000003E9A8: D59C08B4
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 00000003E9AC: 02010193
	.long 0xd4140001                                           // 00000003E9B0: D4140001
	v_cndmask_b32_e32 v1, 0xc2fc0000, v150, vcc_lo             // 00000003E9B4: 02032CFF C2FC0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003E9BC: BF870294
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v148                  // 00000003E9C0: 7C2928FF C2FC0000
	.long 0xd71c0097                                           // 00000003E9C8: D71C0097
	v_cndmask_b32_e32 v1, v146, v151, vcc_lo                   // 00000003E9CC: 02032F92
	.long 0xd4140002                                           // 00000003E9D0: D4140002
	v_cndmask_b32_e32 v1, 0xc2fc0000, v152, vcc_lo             // 00000003E9D4: 020330FF C2FC0000
	v_add3_u32 v146, v149, v182, 0x7fff                        // 00000003E9DC: D6550092 03FF6D95 00007FFF
	v_cndmask_b32_e64 v178, 0, 0x42800000, s1                  // 00000003E9E8: D50100B2 0005FE80 42800000
	v_sub_f32_e32 v179, v179, v131                             // 00000003E9F4: 096707B3
	v_cndmask_b32_e64 v153, 0, 0x42800000, vcc_lo              // 00000003E9F8: D5010099 01A9FE80 42800000
	v_add_f32_e32 v137, v137, v151                             // 00000003EA04: 07132F89
	v_cndmask_b32_e64 v181, 0, 0x42800000, s2                  // 00000003EA08: D50100B5 0009FE80 42800000
	v_add_f32_e32 v150, v150, v178                             // 00000003EA14: 072D6596
	.long 0xd4140004                                           // 00000003EA18: D4140004
	v_cndmask_b32_e32 v1, 0xc2fc0000, v179, vcc_lo             // 00000003EA1C: 020366FF C2FC0000
	v_add_f32_e32 v148, v148, v153                             // 00000003EA24: 07293394
	.long 0xd59c0895                                           // 00000003EA28: D59C0895
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                   // 00000003EA2C: 02010197
	.long 0xd59c4895                                           // 00000003EA30: D59C4895
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                   // 00000003EA34: 020101B4
	v_exp_f32_e32 v150, v150                                   // 00000003EA38: 7F2C4B96
	v_cndmask_b32_e64 v153, 0, 0x42800000, s4                  // 00000003EA3C: D5010099 0011FE80 42800000
	v_and_b32_e32 v178, 1, v180                                // 00000003EA48: 37656881
	v_exp_f32_e32 v148, v148                                   // 00000003EA4C: 7F284B94
	v_dual_add_f32 v152, v152, v181 :: v_dual_add_f32 v137, v137, v147// 00000003EA50: C9096B98 98892789
	s_delay_alu instid0(VALU_DEP_3)                            // 00000003EA58: BF870003
	v_add_f32_e32 v153, v179, v153                             // 00000003EA5C: 073333B3
	v_and_b32_e32 v149, 1, v149                                // 00000003EA60: 372B2A81
	v_cndmask_b32_e64 v179, 0, 0xffffffc0, vcc_lo              // 00000003EA64: D50100B3 01A9FE80 FFFFFFC0
	v_cndmask_b32_e64 v181, 0, 0xffffffc0, s1                  // 00000003EA70: D50100B5 0005FE80 FFFFFFC0
	v_exp_f32_e32 v152, v152                                   // 00000003EA7C: 7F304B98
	v_exp_f32_e32 v153, v153                                   // 00000003EA80: 7F324B99
	v_add3_u32 v151, v151, v149, 0x7fff                        // 00000003EA84: D6550097 03FF2B97 00007FFF
	s_delay_alu instid0(TRANS32_DEP_3)                         // 00000003EA90: BF870007
	.long 0xd71c0094                                           // 00000003EA94: D71C0094
	v_cndmask_b32_e32 v1, v148, v179, vcc_lo                   // 00000003EA98: 02036794
	.long 0xd71c0095                                           // 00000003EA9C: D71C0095
	v_cndmask_b32_e32 v1, v150, v181, vcc_lo                   // 00000003EAA0: 02036B96
	v_cndmask_b32_e64 v150, 0, 0xffffffc0, s4                  // 00000003EAA4: D5010096 0011FE80 FFFFFFC0
	v_cndmask_b32_e64 v182, 0, 0xffffffc0, s2                  // 00000003EAB0: D50100B6 0009FE80 FFFFFFC0
	.long 0xd59c48b3                                           // 00000003EABC: D59C48B3
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                   // 00000003EAC0: 020101B4
	.long 0xd59c08b4                                           // 00000003EAC4: D59C08B4
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                   // 00000003EAC8: 02010194
	.long 0xd59c08b3                                           // 00000003EACC: D59C08B3
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                   // 00000003EAD0: 02010195
	v_add3_u32 v147, v147, v178, 0x7fff                        // 00000003EAD4: D6550093 03FF6593 00007FFF
	.long 0xd71c0096                                           // 00000003EAE0: D71C0096
	v_cndmask_b32_e32 v1, v153, v150, vcc_lo                   // 00000003EAE4: 02032D99
	.long 0xd71c0098                                           // 00000003EAE8: D71C0098
	v_cndmask_b32_e32 v1, v152, v182, vcc_lo                   // 00000003EAEC: 02036D98
	v_and_b32_e32 v181, 1, v180                                // 00000003EAF0: 376B6881
	.long 0xd59c4899                                           // 00000003EAF4: D59C4899
	v_cndmask_b32_e32 v0, v180, v128, vcc_lo                   // 00000003EAF8: 020101B4
	v_and_b32_e32 v179, 1, v179                                // 00000003EAFC: 37676681
	.long 0xd59c08b4                                           // 00000003EB00: D59C08B4
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                   // 00000003EB04: 02010196
	v_add_f32_e32 v137, v137, v149                             // 00000003EB08: 07132B89
	.long 0xd59c0899                                           // 00000003EB0C: D59C0899
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                   // 00000003EB10: 02010198
	.long 0xd59c0892                                           // 00000003EB14: D59C0892
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000003EB18: 02010184
	v_add3_u32 v179, v149, v179, 0x7fff                        // 00000003EB1C: D65500B3 03FF6795 00007FFF
	v_and_b32_e32 v178, 1, v180                                // 00000003EB28: 37656881
	v_add_f32_e32 v137, v137, v148                             // 00000003EB2C: 07132989
	v_and_b32_e32 v153, 1, v153                                // 00000003EB30: 37333281
	v_add3_u32 v148, v148, v181, 0x7fff                        // 00000003EB34: D6550094 03FF6B94 00007FFF
	.long 0xd59c0894                                           // 00000003EB40: D59C0894
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 00000003EB44: 020101B3
	v_add3_u32 v149, v150, v178, 0x7fff                        // 00000003EB48: D6550095 03FF6596 00007FFF
	v_add_f32_e32 v137, v137, v152                             // 00000003EB54: 07133189
	v_add3_u32 v153, v152, v153, 0x7fff                        // 00000003EB58: D6550099 03FF3398 00007FFF
	.long 0xd59c0893                                           // 00000003EB64: D59C0893
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                   // 00000003EB68: 02010197
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000003EB6C: BF870193
	v_add_f32_e32 v132, v137, v150                             // 00000003EB70: 07092D89
	.long 0xd59c0895                                           // 00000003EB74: D59C0895
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                   // 00000003EB78: 02010199
	ds_store_b128 v166, v[133:136]                             // 00000003EB7C: DB7C0000 000085A6
	ds_store_b128 v166, v[146:149] offset:16                   // 00000003EB84: DB7C0010 000092A6
	v_mov_b32_e32 v133, 0                                      // 00000003EB8C: 7F0A0280
	s_mov_b32 s1, exec_lo                                      // 00000003EB90: BE81007E
	s_waitcnt lgkmcnt(0)                                       // 00000003EB94: BF89FC07
	v_cmpx_lt_f32_e32 0xefa18f08, v130                         // 00000003EB98: 7D2304FF EFA18F08
	s_cbranch_execz 15                                         // 00000003EBA0: BFA5000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x28e0>
	v_sub_f32_e32 v130, v130, v131                             // 00000003EBA4: 09050782
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003EBA8: BF8700A1
	v_cmp_gt_f32_e32 vcc_lo, 0xc2fc0000, v130                  // 00000003EBAC: 7C2904FF C2FC0000
	v_cndmask_b32_e64 v133, 0, 0x42800000, vcc_lo              // 00000003EBB4: D5010085 01A9FE80 42800000
	v_add_f32_e32 v130, v130, v133                             // 00000003EBC0: 07050B82
	v_cndmask_b32_e64 v133, 0, 0xffffffc0, vcc_lo              // 00000003EBC4: D5010085 01A9FE80 FFFFFFC0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003EBD0: BF870292
	v_exp_f32_e32 v130, v130                                   // 00000003EBD4: 7F044B82
	.long 0xd71c0085                                           // 00000003EBD8: D71C0085
	v_cndmask_b32_e32 v1, v130, v133, vcc_lo                   // 00000003EBDC: 02030B82
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003EBE0: 8C7E017E
	ds_load_b32 v130, v167                                     // 00000003EBE4: D8D80000 820000A7
	s_waitcnt lgkmcnt(0)                                       // 00000003EBEC: BF89FC07
	v_fmac_f32_e32 v132, v133, v130                            // 00000003EBF0: 57090585
	ds_store_b32 v164, v131                                    // 00000003EBF4: D8340000 000083A4
	ds_store_b32 v167, v132                                    // 00000003EBFC: D8340000 000084A7
	ds_store_b32 v168, v133                                    // 00000003EC04: D8340000 000085A8
	s_or_b32 exec_lo, exec_lo, s26                             // 00000003EC0C: 8C7E1A7E
	ds_load_2addr_b32 v[152:153], v169 offset1:2               // 00000003EC10: D8DC0200 980000A9
	ds_load_2addr_b32 v[150:151], v169 offset0:4 offset1:6     // 00000003EC18: D8DC0604 960000A9
	ds_load_2addr_b32 v[148:149], v169 offset0:8 offset1:10    // 00000003EC20: D8DC0A08 940000A9
	ds_load_2addr_b32 v[146:147], v169 offset0:12 offset1:14   // 00000003EC28: D8DC0E0C 920000A9
	s_waitcnt lgkmcnt(3)                                       // 00000003EC30: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v152                         // 00000003EC34: 7C2530F2
	.long 0xd4120001                                           // 00000003EC38: D4120001
	v_cndmask_b32_e32 v1, 1.0, v153, vcc_lo                    // 00000003EC3C: 020332F2
	s_waitcnt lgkmcnt(2)                                       // 00000003EC40: BF89FC27
	.long 0xd4120002                                           // 00000003EC44: D4120002
	v_cndmask_b32_e32 v1, 1.0, v150, vcc_lo                    // 00000003EC48: 02032CF2
	.long 0xd4120004                                           // 00000003EC4C: D4120004
	v_cndmask_b32_e32 v1, 1.0, v151, vcc_lo                    // 00000003EC50: 02032EF2
	s_and_b32 s1, vcc_lo, s1                                   // 00000003EC54: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 00000003EC58: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v148                         // 00000003EC5C: 7C2528F2
	s_and_b32 s2, s1, s2                                       // 00000003EC60: 8B020201
	.long 0xd4120001                                           // 00000003EC64: D4120001
	v_cndmask_b32_e32 v1, 1.0, v149, vcc_lo                    // 00000003EC68: 02032AF2
	s_and_b32 s4, s2, s4                                       // 00000003EC6C: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 00000003EC70: BF89FC07
	.long 0xd4120002                                           // 00000003EC74: D4120002
	v_cndmask_b32_e32 v1, 1.0, v146, vcc_lo                    // 00000003EC78: 020324F2
	s_and_b32 s4, s4, vcc_lo                                   // 00000003EC7C: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v147                         // 00000003EC80: 7C2526F2
	s_and_b32 s1, s4, s1                                       // 00000003EC84: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000003EC88: BF870499
	s_and_b32 s1, s1, s2                                       // 00000003EC8C: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 00000003EC90: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003EC94: BF870099
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 00000003EC98: D5010082 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v130                           // 00000003ECA0: 7C9B0480
	ds_load_b128 v[130:133], v170                              // 00000003ECA4: DBFC0000 820000AA
	ds_load_b128 v[134:137], v170 offset:16                    // 00000003ECAC: DBFC0010 860000AA
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 00000003ECB4: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 00000003ECB8: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003ECBC: BF870099
	v_cndmask_b32_e64 v178, 0, 1, s1                           // 00000003ECC0: D50100B2 00050280
	v_readfirstlane_b32 s1, v178                               // 00000003ECC8: 7E0205B2
	s_bitcmp1_b32 s1, 0                                        // 00000003ECCC: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 00000003ECD0: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003ECD4: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 00000003ECD8: 8B6A017E
	s_cbranch_vccnz 63324                                      // 00000003ECDC: BFA4F75C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x750>
	v_dual_mul_f32 v121, v152, v121 :: v_dual_mul_f32 v122, v153, v122// 00000003ECE0: C8C6F398 797AF599
	v_dual_mul_f32 v123, v150, v123 :: v_dual_mul_f32 v124, v151, v124// 00000003ECE8: C8C6F796 7B7CF997
	v_dual_mul_f32 v125, v148, v125 :: v_dual_mul_f32 v126, v149, v126// 00000003ECF0: C8C6FB94 7D7EFD95
	v_dual_mul_f32 v127, v146, v127 :: v_dual_mul_f32 v128, v147, v128// 00000003ECF8: C8C6FF92 7F810193
	v_dual_mul_f32 v113, v152, v113 :: v_dual_mul_f32 v114, v153, v114// 00000003ED00: C8C6E398 7172E599
	v_dual_mul_f32 v115, v150, v115 :: v_dual_mul_f32 v116, v151, v116// 00000003ED08: C8C6E796 7374E997
	v_dual_mul_f32 v117, v148, v117 :: v_dual_mul_f32 v118, v149, v118// 00000003ED10: C8C6EB94 7576ED95
	v_dual_mul_f32 v119, v146, v119 :: v_dual_mul_f32 v120, v147, v120// 00000003ED18: C8C6EF92 7778F193
	v_dual_mul_f32 v105, v152, v105 :: v_dual_mul_f32 v106, v153, v106// 00000003ED20: C8C6D398 696AD599
	v_dual_mul_f32 v107, v150, v107 :: v_dual_mul_f32 v108, v151, v108// 00000003ED28: C8C6D796 6B6CD997
	v_dual_mul_f32 v109, v148, v109 :: v_dual_mul_f32 v110, v149, v110// 00000003ED30: C8C6DB94 6D6EDD95
	v_dual_mul_f32 v111, v146, v111 :: v_dual_mul_f32 v112, v147, v112// 00000003ED38: C8C6DF92 6F70E193
	v_dual_mul_f32 v97, v152, v97 :: v_dual_mul_f32 v98, v153, v98// 00000003ED40: C8C6C398 6162C599
	v_dual_mul_f32 v99, v150, v99 :: v_dual_mul_f32 v100, v151, v100// 00000003ED48: C8C6C796 6364C997
	v_dual_mul_f32 v101, v148, v101 :: v_dual_mul_f32 v102, v149, v102// 00000003ED50: C8C6CB94 6566CD95
	v_dual_mul_f32 v103, v146, v103 :: v_dual_mul_f32 v104, v147, v104// 00000003ED58: C8C6CF92 6768D193
	v_dual_mul_f32 v89, v152, v89 :: v_dual_mul_f32 v90, v153, v90// 00000003ED60: C8C6B398 595AB599
	v_dual_mul_f32 v91, v150, v91 :: v_dual_mul_f32 v92, v151, v92// 00000003ED68: C8C6B796 5B5CB997
	v_dual_mul_f32 v93, v148, v93 :: v_dual_mul_f32 v94, v149, v94// 00000003ED70: C8C6BB94 5D5EBD95
	v_dual_mul_f32 v95, v146, v95 :: v_dual_mul_f32 v96, v147, v96// 00000003ED78: C8C6BF92 5F60C193
	v_dual_mul_f32 v81, v152, v81 :: v_dual_mul_f32 v82, v153, v82// 00000003ED80: C8C6A398 5152A599
	v_dual_mul_f32 v83, v150, v83 :: v_dual_mul_f32 v84, v151, v84// 00000003ED88: C8C6A796 5354A997
	v_dual_mul_f32 v85, v148, v85 :: v_dual_mul_f32 v86, v149, v86// 00000003ED90: C8C6AB94 5556AD95
	v_dual_mul_f32 v87, v146, v87 :: v_dual_mul_f32 v88, v147, v88// 00000003ED98: C8C6AF92 5758B193
	v_dual_mul_f32 v73, v152, v73 :: v_dual_mul_f32 v74, v153, v74// 00000003EDA0: C8C69398 494A9599
	v_dual_mul_f32 v75, v150, v75 :: v_dual_mul_f32 v76, v151, v76// 00000003EDA8: C8C69796 4B4C9997
	v_dual_mul_f32 v77, v148, v77 :: v_dual_mul_f32 v78, v149, v78// 00000003EDB0: C8C69B94 4D4E9D95
	v_dual_mul_f32 v79, v146, v79 :: v_dual_mul_f32 v80, v147, v80// 00000003EDB8: C8C69F92 4F50A193
	v_dual_mul_f32 v65, v152, v65 :: v_dual_mul_f32 v66, v153, v66// 00000003EDC0: C8C68398 41428599
	v_dual_mul_f32 v67, v150, v67 :: v_dual_mul_f32 v68, v151, v68// 00000003EDC8: C8C68796 43448997
	v_dual_mul_f32 v69, v148, v69 :: v_dual_mul_f32 v70, v149, v70// 00000003EDD0: C8C68B94 45468D95
	v_dual_mul_f32 v71, v146, v71 :: v_dual_mul_f32 v72, v147, v72// 00000003EDD8: C8C68F92 47489193
	v_dual_mul_f32 v57, v152, v57 :: v_dual_mul_f32 v58, v153, v58// 00000003EDE0: C8C67398 393A7599
	v_dual_mul_f32 v59, v150, v59 :: v_dual_mul_f32 v60, v151, v60// 00000003EDE8: C8C67796 3B3C7997
	v_dual_mul_f32 v61, v148, v61 :: v_dual_mul_f32 v62, v149, v62// 00000003EDF0: C8C67B94 3D3E7D95
	v_dual_mul_f32 v63, v146, v63 :: v_dual_mul_f32 v64, v147, v64// 00000003EDF8: C8C67F92 3F408193
	v_dual_mul_f32 v49, v152, v49 :: v_dual_mul_f32 v50, v153, v50// 00000003EE00: C8C66398 31326599
	v_dual_mul_f32 v51, v150, v51 :: v_dual_mul_f32 v52, v151, v52// 00000003EE08: C8C66796 33346997
	v_dual_mul_f32 v53, v148, v53 :: v_dual_mul_f32 v54, v149, v54// 00000003EE10: C8C66B94 35366D95
	v_dual_mul_f32 v55, v146, v55 :: v_dual_mul_f32 v56, v147, v56// 00000003EE18: C8C66F92 37387193
	v_dual_mul_f32 v41, v152, v41 :: v_dual_mul_f32 v42, v153, v42// 00000003EE20: C8C65398 292A5599
	v_dual_mul_f32 v43, v150, v43 :: v_dual_mul_f32 v44, v151, v44// 00000003EE28: C8C65796 2B2C5997
	v_dual_mul_f32 v45, v148, v45 :: v_dual_mul_f32 v46, v149, v46// 00000003EE30: C8C65B94 2D2E5D95
	v_dual_mul_f32 v47, v146, v47 :: v_dual_mul_f32 v48, v147, v48// 00000003EE38: C8C65F92 2F306193
	v_dual_mul_f32 v33, v152, v33 :: v_dual_mul_f32 v34, v153, v34// 00000003EE40: C8C64398 21224599
	v_dual_mul_f32 v35, v150, v35 :: v_dual_mul_f32 v36, v151, v36// 00000003EE48: C8C64796 23244997
	v_dual_mul_f32 v37, v148, v37 :: v_dual_mul_f32 v38, v149, v38// 00000003EE50: C8C64B94 25264D95
	v_dual_mul_f32 v39, v146, v39 :: v_dual_mul_f32 v40, v147, v40// 00000003EE58: C8C64F92 27285193
	v_dual_mul_f32 v25, v152, v25 :: v_dual_mul_f32 v26, v153, v26// 00000003EE60: C8C63398 191A3599
	v_dual_mul_f32 v27, v150, v27 :: v_dual_mul_f32 v28, v151, v28// 00000003EE68: C8C63796 1B1C3997
	v_dual_mul_f32 v29, v148, v29 :: v_dual_mul_f32 v30, v149, v30// 00000003EE70: C8C63B94 1D1E3D95
	v_dual_mul_f32 v31, v146, v31 :: v_dual_mul_f32 v32, v147, v32// 00000003EE78: C8C63F92 1F204193
	v_dual_mul_f32 v17, v152, v17 :: v_dual_mul_f32 v18, v153, v18// 00000003EE80: C8C62398 11122599
	v_dual_mul_f32 v19, v150, v19 :: v_dual_mul_f32 v20, v151, v20// 00000003EE88: C8C62796 13142997
	v_dual_mul_f32 v21, v148, v21 :: v_dual_mul_f32 v22, v149, v22// 00000003EE90: C8C62B94 15162D95
	v_dual_mul_f32 v23, v146, v23 :: v_dual_mul_f32 v24, v147, v24// 00000003EE98: C8C62F92 17183193
	v_dual_mul_f32 v9, v152, v9 :: v_dual_mul_f32 v10, v153, v10// 00000003EEA0: C8C61398 090A1599
	v_dual_mul_f32 v11, v150, v11 :: v_dual_mul_f32 v12, v151, v12// 00000003EEA8: C8C61796 0B0C1997
	v_dual_mul_f32 v13, v148, v13 :: v_dual_mul_f32 v14, v149, v14// 00000003EEB0: C8C61B94 0D0E1D95
	v_dual_mul_f32 v15, v146, v15 :: v_dual_mul_f32 v16, v147, v16// 00000003EEB8: C8C61F92 0F102193
	v_dual_mul_f32 v1, v152, v1 :: v_dual_mul_f32 v2, v153, v2 // 00000003EEC0: C8C60398 01020599
	v_dual_mul_f32 v3, v150, v3 :: v_dual_mul_f32 v4, v151, v4 // 00000003EEC8: C8C60796 03040997
	v_dual_mul_f32 v5, v148, v5 :: v_dual_mul_f32 v6, v149, v6 // 00000003EED0: C8C60B94 05060D95
	v_dual_mul_f32 v7, v146, v7 :: v_dual_mul_f32 v8, v147, v8 // 00000003EED8: C8C60F92 07081193
	s_branch 63195                                             // 00000003EEE0: BFA0F6DB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x750>
	v_lshlrev_b32_e32 v0, 2, v157                              // 00000003EEE4: 30013A82
	.long 0xd700008b                                           // 00000003EEE8: D700008B
	v_cndmask_b32_e32 v1, s22, v139, vcc_lo                    // 00000003EEEC: 02031616
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000003EEF0: BF870191
	v_add_co_ci_u32_e64 v140, null, s23, v140, s0              // 00000003EEF4: D5207C8C 00031817
	v_lshl_or_b32 v0, v156, 6, v0                              // 00000003EEFC: D6560000 04010D9C
	v_lshlrev_b32_e32 v147, 1, v154                            // 00000003EF04: 31273481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000003EF08: BF870152
	v_add_nc_u32_e32 v133, 0xa000, v0                          // 00000003EF0C: 4B0A00FF 0000A000
	ds_load_2addr_b32 v[141:142], v133 offset0:128 offset1:130 // 00000003EF14: D8DC8280 8D000085
	s_waitcnt lgkmcnt(0)                                       // 00000003EF1C: BF89FC07
	v_div_scale_f32 v143, null, v141, v141, 1.0                // 00000003EF20: D6FC7C8F 03CB1B8D
	v_div_scale_f32 v145, vcc_lo, 1.0, v141, 1.0               // 00000003EF28: D6FC6A91 03CB1AF2
	v_rcp_f32_e32 v144, v143                                   // 00000003EF30: 7F20558F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000003EF34: BF870005
	v_fma_f32 v0, -v143, v144, 1.0                             // 00000003EF38: D6130000 23CB218F
	v_lshlrev_b32_e32 v129, 9, v138                            // 00000003EF40: 31031489
	ds_load_2addr_b32 v[137:138], v133 offset0:132 offset1:134 // 00000003EF44: D8DC8684 89000085
	ds_load_2addr_b32 v[135:136], v133 offset0:136 offset1:138 // 00000003EF4C: D8DC8A88 87000085
	ds_load_2addr_b32 v[133:134], v133 offset0:140 offset1:142 // 00000003EF54: D8DC8E8C 85000085
	v_fmac_f32_e32 v144, v0, v144                              // 00000003EF5C: 57212100
	v_ashrrev_i32_e32 v130, 31, v129                           // 00000003EF60: 3505029F
	v_or_b32_e32 v0, v155, v157                                // 00000003EF64: 38013B9B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000003EF68: BF870193
	v_mul_f32_e32 v146, v145, v144                             // 00000003EF6C: 11252191
	.long 0xd73c0083                                           // 00000003EF70: D73C0083
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 00000003EF74: 02030281
	.long 0xd7000081                                           // 00000003EF78: D7000081
	v_cndmask_b32_e32 v1, v139, v147, vcc_lo                   // 00000003EF7C: 0203278B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003EF80: BF870211
	v_add_co_ci_u32_e64 v130, null, 0, v140, s0                // 00000003EF84: D5207C82 00031880
	v_fma_f32 v148, -v143, v146, v145                          // 00000003EF8C: D6130094 2647258F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003EF94: BF870094
	.long 0xd7000083                                           // 00000003EF98: D7000083
	v_cndmask_b32_e32 v1, s20, v131, vcc_lo                    // 00000003EF9C: 02030614
	v_add_co_ci_u32_e64 v132, null, s21, v132, s0              // 00000003EFA0: D5207C84 00030815
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003EFA8: BF870123
	v_fmac_f32_e32 v146, v148, v144                            // 00000003EFAC: 57252194
	.long 0xd4440000                                           // 00000003EFB0: D4440000
	v_cndmask_b32_e32 v1, s18, v0, vcc_lo                      // 00000003EFB4: 02020012
	v_fma_f32 v139, -v143, v146, v145                          // 00000003EFB8: D613008B 2647258F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003EFC0: BF8700A1
	v_div_fmas_f32 v139, v139, v144, v146                      // 00000003EFC4: D637008B 064B218B
	.long 0xd7006a83                                           // 00000003EFCC: D7006A83
	v_cndmask_b32_e32 v1, v131, v147, vcc_lo                   // 00000003EFD0: 02032783
	v_add_co_ci_u32_e64 v132, null, 0, v132, vcc_lo            // 00000003EFD4: D5207C84 01AB0880
	s_delay_alu instid0(VALU_DEP_3)                            // 00000003EFDC: BF870003
	v_div_fixup_f32 v139, v139, v141, 1.0                      // 00000003EFE0: D627008B 03CB1B8B
	s_and_saveexec_b32 s1, s0                                  // 00000003EFE8: BE812000
	s_cbranch_execz 70                                         // 00000003EFEC: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2e08>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003EFF0: BF870112
	v_mad_i64_i32 v[140:141], null, 0x6000, v0, v[131:132]     // 00000003EFF4: D6FF7C8C 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 00000003F000: 10F2F38B
	global_load_u16 v140, v[140:141], off offset:512           // 00000003F004: DC4A0200 8C7C008C
	s_waitcnt vmcnt(0)                                         // 00000003F00C: BF8903F7
	v_lshlrev_b32_e32 v140, 16, v140                           // 00000003F010: 31191890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F014: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v140                       // 00000003F018: 111B18FF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v140, -v141                    // 00000003F020: D613008F 863718FF BFB8AA3B
	v_rndne_f32_e32 v144, v141                                 // 00000003F02C: 7F20478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003F030: BF870112
	v_fmamk_f32 v143, v140, 0xb2a5705f, v143                   // 00000003F034: 591F1F8C B2A5705F
	v_sub_f32_e32 v141, v141, v144                             // 00000003F03C: 091B218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000003F040: BF8701B1
	v_add_f32_e32 v141, v141, v143                             // 00000003F044: 071B1F8D
	v_cvt_i32_f32_e32 v143, v144                               // 00000003F048: 7F1E1190
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v140                 // 00000003F04C: 7C3D18FF 42CE8ED0
	v_exp_f32_e32 v141, v141                                   // 00000003F054: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F058: BF870095
	.long 0xd71c008d                                           // 00000003F05C: D71C008D
	v_cndmask_b32_e32 v1, v141, v143, vcc_lo                   // 00000003F060: 02031F8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 00000003F064: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v140                 // 00000003F068: 7C3718FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F070: BF870092
	v_cndmask_b32_e32 v140, 0x7f800000, v141, vcc_lo           // 00000003F074: 03191AFF 7F800000
	v_add_f32_e32 v140, 1.0, v140                              // 00000003F07C: 071918F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F080: BF870091
	v_div_scale_f32 v141, null, v140, v140, v121               // 00000003F084: D6FC7C8D 05E7198C
	v_rcp_f32_e32 v143, v141                                   // 00000003F08C: 7F1E558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F090: BF870095
	v_fma_f32 v144, -v141, v143, 1.0                           // 00000003F094: D6130090 23CB1F8D
	v_fmac_f32_e32 v143, v144, v143                            // 00000003F09C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v140, v121             // 00000003F0A0: D6FC6A90 05E71979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F0A8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000003F0AC: 11231F90
	v_fma_f32 v146, -v141, v145, v144                          // 00000003F0B0: D6130092 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F0B8: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000003F0BC: 57231F92
	v_fma_f32 v141, -v141, v145, v144                          // 00000003F0C0: D613008D 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F0C8: BF870091
	v_div_fmas_f32 v141, v141, v143, v145                      // 00000003F0CC: D637008D 06471F8D
	v_div_fixup_f32 v121, v141, v140, v121                     // 00000003F0D4: D6270079 05E7198D
	v_mad_i64_i32 v[140:141], null, 0x3000, v0, v[129:130]     // 00000003F0DC: D6FF7C8C 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F0E8: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 00000003F0EC: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 00000003F0F4: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[140:141], v121, off              // 00000003F100: DC960000 007C798C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000003F108: 8C7E017E
	v_div_scale_f32 v121, null, v142, v142, 1.0                // 00000003F10C: D6FC7C79 03CB1D8E
	v_div_scale_f32 v143, vcc_lo, 1.0, v142, 1.0               // 00000003F114: D6FC6A8F 03CB1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003F11C: BF870292
	v_rcp_f32_e32 v140, v121                                   // 00000003F120: 7F185579
	v_fma_f32 v141, -v121, v140, 1.0                           // 00000003F124: D613008D 23CB1979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F12C: BF870091
	v_fmac_f32_e32 v140, v141, v140                            // 00000003F130: 5719198D
	v_mul_f32_e32 v141, v143, v140                             // 00000003F134: 111B198F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F138: BF870091
	v_fma_f32 v144, -v121, v141, v143                          // 00000003F13C: D6130090 263F1B79
	v_fmac_f32_e32 v141, v144, v140                            // 00000003F144: 571B1990
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F148: BF870091
	v_fma_f32 v121, -v121, v141, v143                          // 00000003F14C: D6130079 263F1B79
	v_div_fmas_f32 v140, v121, v140, v141                      // 00000003F154: D637008C 06371979
	v_or_b32_e32 v121, 2, v0                                   // 00000003F15C: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003F160: BF870112
	v_div_fixup_f32 v140, v140, v142, 1.0                      // 00000003F164: D627008C 03CB1D8C
	.long 0xd4440001                                           // 00000003F16C: D4440001
	v_cndmask_b32_e32 v1, s18, v121, vcc_lo                    // 00000003F170: 0202F212
	s_and_saveexec_b32 s2, s1                                  // 00000003F174: BE822001
	s_cbranch_execz 69                                         // 00000003F178: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2f90>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 00000003F17C: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 00000003F188: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 00000003F18C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000003F194: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000003F198: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F19C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000003F1A0: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000003F1A8: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000003F1B4: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003F1B8: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000003F1BC: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000003F1C0: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000003F1C8: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003F1D0: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000003F1D4: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000003F1D8: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000003F1DC: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F1E0: BF870095
	.long 0xd71c008e                                           // 00000003F1E4: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000003F1E8: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000003F1EC: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000003F1F0: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F1F8: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000003F1FC: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000003F204: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F208: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 00000003F20C: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000003F214: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F218: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000003F21C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000003F224: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 00000003F228: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F230: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000003F234: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000003F238: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F240: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000003F244: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000003F248: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F250: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000003F254: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 00000003F25C: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 00000003F264: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F270: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 00000003F274: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 00000003F27C: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 00000003F288: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 00000003F290: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 00000003F294: BF89FC27
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 00000003F298: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 00000003F2A0: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003F2A8: BF870292
	v_rcp_f32_e32 v141, v122                                   // 00000003F2AC: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 00000003F2B0: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F2B8: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000003F2BC: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000003F2C0: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F2C4: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 00000003F2C8: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 00000003F2D0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F2D4: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 00000003F2D8: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 00000003F2E0: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 00000003F2E8: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003F2EC: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 00000003F2F0: D6270089 03CB138D
	.long 0xd4440002                                           // 00000003F2F8: D4440002
	v_cndmask_b32_e32 v1, s18, v122, vcc_lo                    // 00000003F2FC: 0202F412
	s_and_saveexec_b32 s3, s2                                  // 00000003F300: BE832002
	s_cbranch_execz 69                                         // 00000003F304: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x311c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 00000003F308: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 00000003F314: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 00000003F318: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000003F320: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000003F324: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F328: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000003F32C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000003F334: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000003F340: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003F344: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000003F348: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000003F34C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000003F354: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003F35C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000003F360: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000003F364: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000003F368: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F36C: BF870095
	.long 0xd71c008e                                           // 00000003F370: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000003F374: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000003F378: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000003F37C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F384: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000003F388: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000003F390: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F394: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 00000003F398: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000003F3A0: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F3A4: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000003F3A8: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000003F3B0: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 00000003F3B4: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F3BC: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000003F3C0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000003F3C4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F3CC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000003F3D0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000003F3D4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F3DC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000003F3E0: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 00000003F3E8: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 00000003F3F0: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F3FC: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 00000003F400: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 00000003F408: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 00000003F414: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003F41C: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 00000003F420: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 00000003F428: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003F430: BF870292
	v_rcp_f32_e32 v141, v123                                   // 00000003F434: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 00000003F438: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F440: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000003F444: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000003F448: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F44C: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 00000003F450: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 00000003F458: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F45C: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 00000003F460: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 00000003F468: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 00000003F470: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003F474: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 00000003F478: D627008A 03CB158D
	.long 0xd4440003                                           // 00000003F480: D4440003
	v_cndmask_b32_e32 v1, s18, v123, vcc_lo                    // 00000003F484: 0202F612
	s_and_saveexec_b32 s4, s3                                  // 00000003F488: BE842003
	s_cbranch_execz 69                                         // 00000003F48C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32a4>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 00000003F490: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 00000003F49C: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 00000003F4A0: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000003F4A8: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000003F4AC: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F4B0: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000003F4B4: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000003F4BC: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000003F4C8: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003F4CC: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000003F4D0: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000003F4D4: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000003F4DC: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003F4E4: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000003F4E8: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000003F4EC: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000003F4F0: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F4F4: BF870095
	.long 0xd71c008e                                           // 00000003F4F8: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000003F4FC: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000003F500: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000003F504: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F50C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000003F510: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000003F518: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F51C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 00000003F520: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 00000003F528: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F52C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000003F530: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000003F538: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 00000003F53C: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F544: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000003F548: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000003F54C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F554: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000003F558: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000003F55C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F564: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000003F568: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 00000003F570: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 00000003F578: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F584: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 00000003F588: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 00000003F590: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 00000003F59C: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000003F5A4: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 00000003F5A8: BF89FC17
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 00000003F5AC: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 00000003F5B4: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003F5BC: BF870292
	v_rcp_f32_e32 v141, v124                                   // 00000003F5C0: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 00000003F5C4: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F5CC: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000003F5D0: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000003F5D4: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F5D8: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 00000003F5DC: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 00000003F5E4: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F5E8: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 00000003F5EC: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 00000003F5F4: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 00000003F5FC: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003F600: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 00000003F604: D6270087 03CB0F8D
	.long 0xd4440004                                           // 00000003F60C: D4440004
	v_cndmask_b32_e32 v1, s18, v124, vcc_lo                    // 00000003F610: 0202F812
	s_and_saveexec_b32 s5, s4                                  // 00000003F614: BE852004
	s_cbranch_execz 69                                         // 00000003F618: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3430>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 00000003F61C: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 00000003F628: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 00000003F62C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000003F634: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000003F638: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F63C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000003F640: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000003F648: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000003F654: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003F658: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000003F65C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000003F660: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000003F668: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003F670: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000003F674: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000003F678: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000003F67C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F680: BF870095
	.long 0xd71c008e                                           // 00000003F684: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000003F688: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000003F68C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000003F690: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F698: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000003F69C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000003F6A4: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F6A8: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 00000003F6AC: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 00000003F6B4: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F6B8: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000003F6BC: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000003F6C4: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 00000003F6C8: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F6D0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000003F6D4: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000003F6D8: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F6E0: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000003F6E4: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000003F6E8: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F6F0: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000003F6F4: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 00000003F6FC: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 00000003F704: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F710: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 00000003F714: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 00000003F71C: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 00000003F728: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 00000003F730: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 00000003F734: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 00000003F73C: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003F744: BF870292
	v_rcp_f32_e32 v141, v125                                   // 00000003F748: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 00000003F74C: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F754: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000003F758: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000003F75C: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F760: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 00000003F764: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 00000003F76C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F770: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 00000003F774: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 00000003F77C: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 00000003F784: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003F788: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 00000003F78C: D6270088 03CB118D
	.long 0xd4440005                                           // 00000003F794: D4440005
	v_cndmask_b32_e32 v1, s18, v125, vcc_lo                    // 00000003F798: 0202FA12
	s_and_saveexec_b32 s6, s5                                  // 00000003F79C: BE862005
	s_cbranch_execz 69                                         // 00000003F7A0: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35b8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 00000003F7A4: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 00000003F7B0: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 00000003F7B4: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000003F7BC: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000003F7C0: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F7C4: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000003F7C8: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000003F7D0: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000003F7DC: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003F7E0: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000003F7E4: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000003F7E8: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000003F7F0: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003F7F8: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000003F7FC: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000003F800: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000003F804: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F808: BF870095
	.long 0xd71c008e                                           // 00000003F80C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000003F810: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000003F814: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000003F818: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F820: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000003F824: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000003F82C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F830: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 00000003F834: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000003F83C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F840: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000003F844: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000003F84C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 00000003F850: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F858: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000003F85C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000003F860: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F868: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000003F86C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000003F870: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F878: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000003F87C: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 00000003F884: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 00000003F88C: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F898: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 00000003F89C: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 00000003F8A4: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 00000003F8B0: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 00000003F8B8: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000003F8BC: BF89FC07
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 00000003F8C0: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 00000003F8C8: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003F8D0: BF870292
	v_rcp_f32_e32 v141, v126                                   // 00000003F8D4: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 00000003F8D8: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F8E0: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000003F8E4: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000003F8E8: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F8EC: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 00000003F8F0: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 00000003F8F8: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F8FC: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 00000003F900: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 00000003F908: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 00000003F910: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003F914: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 00000003F918: D6270085 03CB0B8D
	.long 0xd4440006                                           // 00000003F920: D4440006
	v_cndmask_b32_e32 v1, s18, v126, vcc_lo                    // 00000003F924: 0202FC12
	s_and_saveexec_b32 s7, s6                                  // 00000003F928: BE872006
	s_cbranch_execz 69                                         // 00000003F92C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3744>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 00000003F930: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 00000003F93C: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 00000003F940: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000003F948: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000003F94C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F950: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000003F954: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000003F95C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000003F968: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003F96C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000003F970: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000003F974: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000003F97C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003F984: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000003F988: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000003F98C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000003F990: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F994: BF870095
	.long 0xd71c008e                                           // 00000003F998: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000003F99C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000003F9A0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000003F9A4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F9AC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000003F9B0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000003F9B8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F9BC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 00000003F9C0: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000003F9C8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F9CC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000003F9D0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000003F9D8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 00000003F9DC: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F9E4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000003F9E8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000003F9EC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F9F4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000003F9F8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000003F9FC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003FA04: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000003FA08: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 00000003FA10: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 00000003FA18: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003FA24: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 00000003FA28: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 00000003FA30: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 00000003FA3C: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 00000003FA44: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 00000003FA48: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 00000003FA50: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003FA58: BF870292
	v_rcp_f32_e32 v141, v127                                   // 00000003FA5C: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 00000003FA60: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003FA68: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000003FA6C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000003FA70: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003FA74: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 00000003FA78: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 00000003FA80: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003FA84: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 00000003FA88: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 00000003FA90: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 00000003FA98: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003FA9C: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 00000003FAA0: D6270086 03CB0D8D
	.long 0xd4440007                                           // 00000003FAA8: D4440007
	v_cndmask_b32_e32 v1, s18, v127, vcc_lo                    // 00000003FAAC: 0202FE12
	s_and_saveexec_b32 s8, s7                                  // 00000003FAB0: BE882007
	s_cbranch_execnz 363                                       // 00000003FAB4: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d64>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FAB8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003FABC: BE882000
	s_cbranch_execnz 432                                       // 00000003FAC0: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e84>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FAC4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000003FAC8: BE882001
	s_cbranch_execnz 501                                       // 00000003FACC: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fa4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FAD0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003FAD4: BE882002
	s_cbranch_execnz 570                                       // 00000003FAD8: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FADC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003FAE0: BE882003
	s_cbranch_execnz 639                                       // 00000003FAE4: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FAE8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003FAEC: BE882004
	s_cbranch_execnz 708                                       // 00000003FAF0: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4304>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FAF4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003FAF8: BE882005
	s_cbranch_execnz 777                                       // 00000003FAFC: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4424>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FB00: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003FB04: BE882006
	s_cbranch_execnz 846                                       // 00000003FB08: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4544>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FB0C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003FB10: BE882007
	s_cbranch_execnz 915                                       // 00000003FB14: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4664>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FB18: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003FB1C: BE882000
	s_cbranch_execnz 984                                       // 00000003FB20: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4784>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FB24: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000003FB28: BE882001
	s_cbranch_execnz 1053                                      // 00000003FB2C: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x48a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FB30: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003FB34: BE882002
	s_cbranch_execnz 1122                                      // 00000003FB38: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x49c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FB3C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003FB40: BE882003
	s_cbranch_execnz 1191                                      // 00000003FB44: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4ae4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FB48: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003FB4C: BE882004
	s_cbranch_execnz 1260                                      // 00000003FB50: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4c04>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FB54: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003FB58: BE882005
	s_cbranch_execnz 1329                                      // 00000003FB5C: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4d24>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FB60: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003FB64: BE882006
	s_cbranch_execnz 1398                                      // 00000003FB68: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4e44>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FB6C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003FB70: BE882007
	s_cbranch_execnz 1467                                      // 00000003FB74: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4f64>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FB78: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003FB7C: BE882000
	s_cbranch_execnz 1536                                      // 00000003FB80: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5084>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FB84: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000003FB88: BE882001
	s_cbranch_execnz 1605                                      // 00000003FB8C: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x51a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FB90: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003FB94: BE882002
	s_cbranch_execnz 1674                                      // 00000003FB98: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x52c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FB9C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003FBA0: BE882003
	s_cbranch_execnz 1743                                      // 00000003FBA4: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x53e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FBA8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003FBAC: BE882004
	s_cbranch_execnz 1812                                      // 00000003FBB0: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5504>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FBB4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003FBB8: BE882005
	s_cbranch_execnz 1881                                      // 00000003FBBC: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5624>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FBC0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003FBC4: BE882006
	s_cbranch_execnz 1950                                      // 00000003FBC8: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5744>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FBCC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003FBD0: BE882007
	s_cbranch_execnz 2019                                      // 00000003FBD4: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5864>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FBD8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003FBDC: BE882000
	s_cbranch_execnz 2088                                      // 00000003FBE0: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5984>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FBE4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000003FBE8: BE882001
	s_cbranch_execnz 2157                                      // 00000003FBEC: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5aa4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FBF0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003FBF4: BE882002
	s_cbranch_execnz 2226                                      // 00000003FBF8: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5bc4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FBFC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003FC00: BE882003
	s_cbranch_execnz 2295                                      // 00000003FC04: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5ce4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FC08: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003FC0C: BE882004
	s_cbranch_execnz 2364                                      // 00000003FC10: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5e04>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FC14: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003FC18: BE882005
	s_cbranch_execnz 2433                                      // 00000003FC1C: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5f24>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FC20: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003FC24: BE882006
	s_cbranch_execnz 2502                                      // 00000003FC28: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6044>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FC2C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003FC30: BE882007
	s_cbranch_execnz 2571                                      // 00000003FC34: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6164>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FC38: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003FC3C: BE882000
	s_cbranch_execnz 2640                                      // 00000003FC40: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6284>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FC44: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000003FC48: BE882001
	s_cbranch_execnz 2709                                      // 00000003FC4C: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x63a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FC50: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003FC54: BE882002
	s_cbranch_execnz 2778                                      // 00000003FC58: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x64c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FC5C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003FC60: BE882003
	s_cbranch_execnz 2847                                      // 00000003FC64: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x65e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FC68: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003FC6C: BE882004
	s_cbranch_execnz 2916                                      // 00000003FC70: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6704>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FC74: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003FC78: BE882005
	s_cbranch_execnz 2985                                      // 00000003FC7C: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6824>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FC80: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003FC84: BE882006
	s_cbranch_execnz 3054                                      // 00000003FC88: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6944>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FC8C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003FC90: BE882007
	s_cbranch_execnz 3123                                      // 00000003FC94: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6a64>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FC98: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003FC9C: BE882000
	s_cbranch_execnz 3192                                      // 00000003FCA0: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6b84>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FCA4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000003FCA8: BE882001
	s_cbranch_execnz 3261                                      // 00000003FCAC: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6ca4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FCB0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003FCB4: BE882002
	s_cbranch_execnz 3330                                      // 00000003FCB8: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6dc4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FCBC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003FCC0: BE882003
	s_cbranch_execnz 3399                                      // 00000003FCC4: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6ee4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FCC8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003FCCC: BE882004
	s_cbranch_execnz 3468                                      // 00000003FCD0: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7004>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FCD4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003FCD8: BE882005
	s_cbranch_execnz 3537                                      // 00000003FCDC: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7124>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FCE0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003FCE4: BE882006
	s_cbranch_execnz 3606                                      // 00000003FCE8: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7244>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FCEC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003FCF0: BE882007
	s_cbranch_execnz 3675                                      // 00000003FCF4: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7364>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FCF8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003FCFC: BE882000
	s_cbranch_execnz 3744                                      // 00000003FD00: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7484>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FD04: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000003FD08: BE882001
	s_cbranch_execnz 3813                                      // 00000003FD0C: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x75a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FD10: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003FD14: BE882002
	s_cbranch_execnz 3882                                      // 00000003FD18: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x76c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FD1C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003FD20: BE882003
	s_cbranch_execnz 3951                                      // 00000003FD24: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x77e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FD28: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003FD2C: BE882004
	s_cbranch_execnz 4020                                      // 00000003FD30: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7904>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FD34: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003FD38: BE882005
	s_cbranch_execnz 4089                                      // 00000003FD3C: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7a24>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FD40: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003FD44: BE882006
	s_cbranch_execnz 4158                                      // 00000003FD48: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7b44>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FD4C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003FD50: BE882007
	s_cbranch_execnz 4227                                      // 00000003FD54: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7c64>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FD58: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003FD5C: BE882000
	s_cbranch_execnz 4296                                      // 00000003FD60: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7d84>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FD64: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000003FD68: BE882001
	s_cbranch_execnz 4365                                      // 00000003FD6C: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7ea4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FD70: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003FD74: BE882002
	s_cbranch_execnz 4434                                      // 00000003FD78: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7fc4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FD7C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003FD80: BE882003
	s_cbranch_execnz 4503                                      // 00000003FD84: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x80e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FD88: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003FD8C: BE882004
	s_cbranch_execnz 4572                                      // 00000003FD90: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8204>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FD94: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003FD98: BE882005
	s_cbranch_execnz 4641                                      // 00000003FD9C: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8324>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FDA0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003FDA4: BE882006
	s_cbranch_execnz 4710                                      // 00000003FDA8: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8444>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FDAC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003FDB0: BE882007
	s_cbranch_execnz 4779                                      // 00000003FDB4: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8564>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FDB8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003FDBC: BE882000
	s_cbranch_execnz 4848                                      // 00000003FDC0: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8684>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FDC4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000003FDC8: BE882001
	s_cbranch_execnz 4917                                      // 00000003FDCC: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x87a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FDD0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003FDD4: BE882002
	s_cbranch_execnz 4986                                      // 00000003FDD8: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x88c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FDDC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003FDE0: BE882003
	s_cbranch_execnz 5055                                      // 00000003FDE4: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x89e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FDE8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003FDEC: BE882004
	s_cbranch_execnz 5124                                      // 00000003FDF0: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b04>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FDF4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003FDF8: BE882005
	s_cbranch_execnz 5193                                      // 00000003FDFC: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8c24>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FE00: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003FE04: BE882006
	s_cbranch_execnz 5262                                      // 00000003FE08: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8d44>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FE0C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003FE10: BE882007
	s_cbranch_execnz 5331                                      // 00000003FE14: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8e64>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FE18: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003FE1C: BE882000
	s_cbranch_execnz 5400                                      // 00000003FE20: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8f84>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FE24: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000003FE28: BE882001
	s_cbranch_execnz 5469                                      // 00000003FE2C: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x90a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FE30: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003FE34: BE882002
	s_cbranch_execnz 5538                                      // 00000003FE38: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x91c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FE3C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003FE40: BE882003
	s_cbranch_execnz 5607                                      // 00000003FE44: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x92e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FE48: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003FE4C: BE882004
	s_cbranch_execnz 5676                                      // 00000003FE50: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9404>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FE54: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003FE58: BE882005
	s_cbranch_execnz 5745                                      // 00000003FE5C: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9524>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FE60: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003FE64: BE882006
	s_cbranch_execnz 5814                                      // 00000003FE68: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9644>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FE6C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003FE70: BE882007
	s_cbranch_execnz 5883                                      // 00000003FE74: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9764>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FE78: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003FE7C: BE882000
	s_cbranch_execnz 5952                                      // 00000003FE80: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9884>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FE84: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000003FE88: BE882001
	s_cbranch_execnz 6021                                      // 00000003FE8C: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x99a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FE90: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003FE94: BE882002
	s_cbranch_execnz 6090                                      // 00000003FE98: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9ac4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FE9C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003FEA0: BE882003
	s_cbranch_execnz 6159                                      // 00000003FEA4: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9be4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FEA8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003FEAC: BE882004
	s_cbranch_execnz 6228                                      // 00000003FEB0: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9d04>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FEB4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003FEB8: BE882005
	s_cbranch_execnz 6297                                      // 00000003FEBC: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9e24>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FEC0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003FEC4: BE882006
	s_cbranch_execnz 6366                                      // 00000003FEC8: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9f44>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FECC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003FED0: BE882007
	s_cbranch_execnz 6435                                      // 00000003FED4: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa064>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FED8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003FEDC: BE882000
	s_cbranch_execnz 6504                                      // 00000003FEE0: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa184>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FEE4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000003FEE8: BE882001
	s_cbranch_execnz 6573                                      // 00000003FEEC: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa2a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FEF0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003FEF4: BE882002
	s_cbranch_execnz 6642                                      // 00000003FEF8: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa3c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FEFC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003FF00: BE882003
	s_cbranch_execnz 6711                                      // 00000003FF04: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa4e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FF08: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003FF0C: BE882004
	s_cbranch_execnz 6780                                      // 00000003FF10: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa604>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FF14: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003FF18: BE882005
	s_cbranch_execnz 6849                                      // 00000003FF1C: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa724>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FF20: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003FF24: BE882006
	s_cbranch_execnz 6918                                      // 00000003FF28: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa844>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FF2C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003FF30: BE882007
	s_cbranch_execnz 6987                                      // 00000003FF34: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa964>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FF38: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003FF3C: BE882000
	s_cbranch_execnz 7056                                      // 00000003FF40: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaa84>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FF44: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000003FF48: BE882001
	s_cbranch_execnz 7125                                      // 00000003FF4C: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaba4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FF50: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003FF54: BE882002
	s_cbranch_execnz 7194                                      // 00000003FF58: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xacc4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FF5C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003FF60: BE882003
	s_cbranch_execnz 7263                                      // 00000003FF64: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xade4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FF68: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003FF6C: BE882004
	s_cbranch_execnz 7332                                      // 00000003FF70: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaf04>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FF74: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003FF78: BE882005
	s_cbranch_execnz 7401                                      // 00000003FF7C: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb024>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FF80: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003FF84: BE882006
	s_cbranch_execnz 7470                                      // 00000003FF88: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb144>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FF8C: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003FF90: BE882007
	s_cbranch_execnz 7539                                      // 00000003FF94: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb264>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FF98: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003FF9C: BE882000
	s_cbranch_execnz 7608                                      // 00000003FFA0: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb384>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FFA4: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000003FFA8: BE882001
	s_cbranch_execnz 7677                                      // 00000003FFAC: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb4a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FFB0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000003FFB4: BE882002
	s_cbranch_execnz 7746                                      // 00000003FFB8: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb5c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FFBC: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000003FFC0: BE882003
	s_cbranch_execnz 7815                                      // 00000003FFC4: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb6e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FFC8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000003FFCC: BE882004
	s_cbranch_execnz 7884                                      // 00000003FFD0: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb804>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FFD4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000003FFD8: BE882005
	s_cbranch_execnz 7953                                      // 00000003FFDC: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb924>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FFE0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000003FFE4: BE882006
	s_cbranch_execnz 8022                                      // 00000003FFE8: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xba44>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FFEC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000003FFF0: BE882007
	s_cbranch_execnz 8091                                      // 00000003FFF4: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbb64>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000003FFF8: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000003FFFC: BE882000
	s_cbranch_execnz 8160                                      // 000000040000: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbc84>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000040004: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 000000040008: BE802001
	s_cbranch_execnz 8229                                      // 00000004000C: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbda4>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000040010: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 000000040014: BE802002
	s_cbranch_execnz 8298                                      // 000000040018: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbec4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000004001C: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 000000040020: BE802003
	s_cbranch_execnz 8367                                      // 000000040024: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbfe4>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000040028: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000004002C: BE802004
	s_cbranch_execnz 8436                                      // 000000040030: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc104>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000040034: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000040038: BE802005
	s_cbranch_execnz 8505                                      // 00000004003C: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc224>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000040040: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000040044: BE802006
	s_cbranch_execnz 8574                                      // 000000040048: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc344>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000004004C: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000040050: BE802007
	s_cbranch_execnz 8643                                      // 000000040054: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc464>
	s_nop 0                                                    // 000000040058: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000004005C: BFB60003
	s_endpgm                                                   // 000000040060: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 000000040064: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 000000040070: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 000000040074: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000004007C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000040080: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040084: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000040088: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000040090: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000004009C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000400A0: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000400A4: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000400A8: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000400B0: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000400B8: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000400BC: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000400C0: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000400C4: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000400C8: BF870095
	.long 0xd71c008e                                           // 0000000400CC: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000400D0: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000400D4: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000400D8: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000400E0: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000400E4: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000400EC: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000400F0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 0000000400F4: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000400FC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040100: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000040104: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000004010C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 000000040110: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040118: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000004011C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000040120: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040128: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000004012C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000040130: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040138: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000004013C: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 000000040144: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 00000004014C: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040158: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 00000004015C: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 000000040164: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 000000040170: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 000000040178: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004017C: BE882000
	s_cbranch_execz 65104                                      // 000000040180: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37c4>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 000000040184: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 000000040190: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 000000040194: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 00000004019C: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 0000000401A0: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000401A4: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 0000000401A8: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 0000000401B0: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 0000000401BC: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000401C0: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 0000000401C4: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 0000000401C8: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 0000000401D0: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000401D8: BF870121
	v_add_f32_e32 v141, v141, v142                             // 0000000401DC: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 0000000401E0: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 0000000401E4: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000401E8: BF870095
	.long 0xd71c008d                                           // 0000000401EC: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 0000000401F0: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 0000000401F4: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 0000000401F8: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040200: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 000000040204: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 00000004020C: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040210: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 000000040214: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 00000004021C: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040220: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 000000040224: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 00000004022C: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 000000040230: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040238: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 00000004023C: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 000000040240: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040248: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 00000004024C: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 000000040250: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040258: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 00000004025C: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 000000040264: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 00000004026C: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040278: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 00000004027C: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 000000040284: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 000000040290: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 000000040298: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004029C: BE882001
	s_cbranch_execz 65035                                      // 0000000402A0: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37d0>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 0000000402A4: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 0000000402B0: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 0000000402B4: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 0000000402BC: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000402C0: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000402C4: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 0000000402C8: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 0000000402D0: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 0000000402DC: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000402E0: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 0000000402E4: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000402E8: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 0000000402F0: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000402F8: BF870121
	v_add_f32_e32 v128, v128, v141                             // 0000000402FC: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 000000040300: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 000000040304: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040308: BF870095
	.long 0xd71c0080                                           // 00000004030C: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 000000040310: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 000000040314: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000040318: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040320: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 000000040324: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000004032C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040330: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 000000040334: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 00000004033C: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040340: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 000000040344: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 00000004034C: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 000000040350: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040358: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 00000004035C: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 000000040360: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040368: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 00000004036C: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 000000040370: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040378: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 00000004037C: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 000000040384: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 00000004038C: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040398: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 00000004039C: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 0000000403A4: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 0000000403B0: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000403B8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000403BC: BE882002
	s_cbranch_execz 64966                                      // 0000000403C0: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37dc>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 0000000403C4: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000403D0: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000403D8: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000403DC: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000403E0: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000403E4: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 0000000403EC: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 0000000403F8: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000403FC: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 000000040400: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 000000040408: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000004040C: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 000000040410: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 000000040414: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000040418: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 000000040420: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040424: BF870095
	.long 0xd71c0072                                           // 000000040428: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 00000004042C: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000040430: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000040434: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004043C: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 000000040440: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000004044C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040450: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000040454: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 00000004045C: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040460: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 000000040464: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 00000004046C: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 000000040470: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040478: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 00000004047C: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 000000040480: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040488: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 00000004048C: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 000000040490: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040498: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 00000004049C: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000404A4: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 0000000404AC: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000404B8: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 0000000404BC: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 0000000404C4: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000404D0: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000404D8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000404DC: BE882003
	s_cbranch_execz 64897                                      // 0000000404E0: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37e8>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 0000000404E4: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000404F0: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000404F8: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000404FC: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040500: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000040504: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000004050C: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 000000040518: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004051C: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 000000040520: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000040524: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000004052C: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000040534: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000040538: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 00000004053C: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 000000040540: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040544: BF870095
	.long 0xd71c0072                                           // 000000040548: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000004054C: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000040550: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000040554: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004055C: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 000000040560: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000004056C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040570: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000040574: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000004057C: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040580: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 000000040584: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 00000004058C: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 000000040590: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040598: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 00000004059C: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 0000000405A0: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000405A8: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 0000000405AC: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 0000000405B0: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000405B8: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 0000000405BC: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000405C4: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 0000000405CC: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000405D8: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000405DC: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000405E4: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000405F0: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000405F8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000405FC: BE882004
	s_cbranch_execz 64828                                      // 000000040600: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37f4>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 000000040604: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000040610: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000040618: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000004061C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040620: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000040624: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000004062C: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000040638: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004063C: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000040640: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000040644: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000004064C: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000040654: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000040658: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000004065C: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000040660: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040664: BF870095
	.long 0xd71c0072                                           // 000000040668: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000004066C: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000040670: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000040674: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004067C: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 000000040680: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000004068C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040690: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000040694: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000004069C: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000406A0: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000406A4: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000406AC: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000406B0: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000406B8: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 0000000406BC: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 0000000406C0: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000406C8: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 0000000406CC: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 0000000406D0: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000406D8: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 0000000406DC: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000406E4: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 0000000406EC: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000406F8: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000406FC: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 000000040704: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000040710: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000040718: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004071C: BE882005
	s_cbranch_execz 64759                                      // 000000040720: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3800>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 000000040724: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000040730: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000040738: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000004073C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040740: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000040744: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000004074C: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000040758: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004075C: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000040760: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000040764: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000004076C: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000040774: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000040778: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000004077C: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000040780: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040784: BF870095
	.long 0xd71c0072                                           // 000000040788: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000004078C: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000040790: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000040794: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004079C: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000000407A0: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 0000000407A8: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000407B0: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000407B4: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000407BC: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000407C0: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000407C4: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000407CC: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000407D0: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000407D8: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000407DC: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 0000000407E0: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000407E8: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 0000000407EC: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 0000000407F0: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000407F8: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000407FC: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000040804: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 00000004080C: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040818: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000004081C: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 000000040824: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000040830: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000040838: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004083C: BE882006
	s_cbranch_execz 64690                                      // 000000040840: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x380c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 000000040844: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000040850: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000040858: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000004085C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040860: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000040864: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000004086C: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000040878: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004087C: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000040880: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000040884: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000004088C: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000040894: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000040898: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000004089C: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000408A0: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000408A4: BF870095
	.long 0xd71c0072                                           // 0000000408A8: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000408AC: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000408B0: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000408B4: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000408BC: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 0000000408C0: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000408CC: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000408D0: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000408D4: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000408DC: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000408E0: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000408E4: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000408EC: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000408F0: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000408F8: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000408FC: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 000000040900: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040908: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 00000004090C: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 000000040910: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040918: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 00000004091C: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000040924: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 00000004092C: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040938: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000004093C: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 000000040944: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000040950: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000040958: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004095C: BE882007
	s_cbranch_execz 64621                                      // 000000040960: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3818>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 000000040964: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 000000040970: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000040978: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000004097C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040980: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000040984: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000004098C: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000040998: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004099C: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000409A0: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000409A4: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000409AC: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000409B4: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000409B8: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000409BC: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000409C0: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000409C4: BF870095
	.long 0xd71c0072                                           // 0000000409C8: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000409CC: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000409D0: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000409D4: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000409DC: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 0000000409E0: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000409EC: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000409F0: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000409F4: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000409FC: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040A00: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 000000040A04: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 000000040A0C: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 000000040A10: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040A18: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 000000040A1C: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 000000040A20: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040A28: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 000000040A2C: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 000000040A30: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040A38: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 000000040A3C: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000040A44: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 000000040A4C: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040A58: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000040A5C: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 000000040A64: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 000000040A70: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000040A78: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000040A7C: BE882000
	s_cbranch_execz 64552                                      // 000000040A80: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3824>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 000000040A84: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 000000040A90: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 000000040A94: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 000000040A9C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000040AA0: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040AA4: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000040AA8: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000040AB0: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000040ABC: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000040AC0: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000040AC4: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000040AC8: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000040AD0: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000040AD8: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000040ADC: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000040AE0: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 000000040AE4: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040AE8: BF870095
	.long 0xd71c0072                                           // 000000040AEC: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000040AF0: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 000000040AF4: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000040AF8: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040B00: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 000000040B04: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000040B0C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040B10: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 000000040B14: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 000000040B1C: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040B20: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 000000040B24: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 000000040B2C: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 000000040B30: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040B38: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 000000040B3C: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 000000040B40: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040B48: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 000000040B4C: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 000000040B50: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040B58: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 000000040B5C: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 000000040B64: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 000000040B6C: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040B78: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 000000040B7C: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 000000040B84: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 000000040B90: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 000000040B98: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000040B9C: BE882001
	s_cbranch_execz 64483                                      // 000000040BA0: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3830>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 000000040BA4: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 000000040BB0: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 000000040BB4: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 000000040BBC: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000040BC0: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000040BC4: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 000000040BC8: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000040BD0: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 000000040BD8: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 000000040BE4: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000040BE8: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 000000040BEC: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 000000040BF4: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000040BF8: BF870121
	v_add_f32_e32 v113, v113, v114                             // 000000040BFC: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 000000040C00: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 000000040C04: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040C08: BF870095
	.long 0xd71c0071                                           // 000000040C0C: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 000000040C10: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 000000040C14: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000040C18: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040C20: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 000000040C24: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000040C2C: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040C30: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 000000040C34: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 000000040C3C: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040C40: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 000000040C44: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 000000040C4C: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 000000040C50: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040C58: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 000000040C5C: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 000000040C60: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040C68: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 000000040C6C: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 000000040C70: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040C78: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 000000040C7C: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 000000040C84: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 000000040C8C: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040C98: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 000000040C9C: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 000000040CA4: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 000000040CB0: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 000000040CB8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000040CBC: BE882002
	s_cbranch_execz 64414                                      // 000000040CC0: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x383c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 000000040CC4: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000040CD0: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000040CD8: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000040CDC: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040CE0: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000040CE4: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 000000040CEC: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 000000040CF8: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000040CFC: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 000000040D00: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000040D04: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 000000040D0C: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000040D14: BF870121
	v_add_f32_e32 v106, v106, v113                             // 000000040D18: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 000000040D1C: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 000000040D20: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040D24: BF870095
	.long 0xd71c006a                                           // 000000040D28: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 000000040D2C: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000040D30: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000040D34: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040D3C: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 000000040D40: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000040D4C: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040D50: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000040D54: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 000000040D5C: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040D60: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 000000040D64: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 000000040D6C: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 000000040D70: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040D78: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 000000040D7C: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 000000040D80: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040D88: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 000000040D8C: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 000000040D90: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040D98: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 000000040D9C: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000040DA4: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 000000040DAC: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040DB8: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 000000040DBC: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 000000040DC4: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000040DD0: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000040DD8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000040DDC: BE882003
	s_cbranch_execz 64345                                      // 000000040DE0: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3848>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 000000040DE4: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000040DF0: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000040DF8: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000040DFC: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040E00: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000040E04: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000040E0C: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 000000040E18: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040E1C: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 000000040E20: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 000000040E2C: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 000000040E30: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000040E34: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000040E3C: BF870293
	v_exp_f32_e32 v106, v106                                   // 000000040E40: 7ED44B6A
	.long 0xd71c006a                                           // 000000040E44: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000040E48: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000040E4C: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000040E50: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000040E54: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 000000040E5C: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040E68: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 000000040E6C: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000040E70: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000040E78: BF870291
	v_rcp_f32_e32 v108, v107                                   // 000000040E7C: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 000000040E80: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000040E88: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 000000040E8C: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 000000040E90: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 000000040E98: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040E9C: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 000000040EA0: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 000000040EA8: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040EAC: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 000000040EB0: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 000000040EB8: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000040EC0: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000040EC4: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 000000040ECC: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 000000040ED8: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000040EE0: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000040EE4: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000040EF0: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000040EF8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000040EFC: BE882004
	s_cbranch_execz 64276                                      // 000000040F00: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3854>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 000000040F04: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000040F10: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000040F18: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000040F1C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040F20: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000040F24: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000040F2C: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000040F38: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000040F3C: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000040F40: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000040F44: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000040F4C: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000040F54: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000040F58: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000040F5C: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000040F60: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040F64: BF870095
	.long 0xd71c006a                                           // 000000040F68: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000040F6C: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000040F70: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000040F74: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040F7C: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 000000040F80: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000040F8C: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040F90: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000040F94: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000040F9C: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040FA0: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000040FA4: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000040FAC: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000040FB0: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040FB8: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 000000040FBC: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 000000040FC0: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040FC8: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 000000040FCC: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 000000040FD0: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040FD8: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 000000040FDC: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000040FE4: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 000000040FEC: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040FF8: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000040FFC: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000041004: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000041010: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000041018: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004101C: BE882005
	s_cbranch_execz 64207                                      // 000000041020: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3860>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 000000041024: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000041030: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000041038: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000004103C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041040: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000041044: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000004104C: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000041058: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004105C: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000041060: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000041064: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000004106C: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000041074: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000041078: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000004107C: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000041080: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041084: BF870095
	.long 0xd71c006a                                           // 000000041088: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000004108C: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000041090: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000041094: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004109C: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 0000000410A0: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 0000000410A8: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000410B0: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000410B4: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000410BC: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000410C0: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000410C4: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000410CC: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000410D0: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000410D8: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000410DC: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 0000000410E0: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000410E8: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 0000000410EC: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 0000000410F0: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000410F8: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000410FC: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000041104: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 00000004110C: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041118: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000004111C: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000041124: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000041130: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000041138: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004113C: BE882006
	s_cbranch_execz 64138                                      // 000000041140: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x386c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 000000041144: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000041150: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000041158: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000004115C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041160: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000041164: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000004116C: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000041178: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004117C: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000041180: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000041184: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000004118C: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000041194: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000041198: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000004119C: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000411A0: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000411A4: BF870095
	.long 0xd71c006a                                           // 0000000411A8: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000411AC: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000411B0: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000411B4: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000411BC: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 0000000411C0: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000411CC: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000411D0: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000411D4: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000411DC: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000411E0: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000411E4: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000411EC: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000411F0: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000411F8: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000411FC: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 000000041200: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041208: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 00000004120C: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 000000041210: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041218: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 00000004121C: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000041224: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 00000004122C: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041238: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000004123C: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000041244: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000041250: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000041258: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004125C: BE882007
	s_cbranch_execz 64069                                      // 000000041260: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3878>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 000000041264: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000041270: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000041278: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000004127C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041280: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000041284: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000004128C: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000041298: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004129C: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000412A0: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000412A4: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000412AC: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000412B4: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000412B8: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000412BC: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000412C0: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000412C4: BF870095
	.long 0xd71c006a                                           // 0000000412C8: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000412CC: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000412D0: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000412D4: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000412DC: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 0000000412E0: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000412EC: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000412F0: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000412F4: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000412FC: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041300: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000041304: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000004130C: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000041310: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041318: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 00000004131C: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 000000041320: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041328: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 00000004132C: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 000000041330: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041338: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 00000004133C: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000041344: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 00000004134C: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041358: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000004135C: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000041364: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000041370: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000041378: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004137C: BE882000
	s_cbranch_execz 64000                                      // 000000041380: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3884>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 000000041384: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 000000041390: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 000000041394: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 00000004139C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000413A0: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000413A4: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000413A8: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000413B0: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000413BC: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000413C0: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000413C4: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000413C8: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000413D0: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000413D8: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000413DC: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000413E0: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000413E4: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000413E8: BF870095
	.long 0xd71c006a                                           // 0000000413EC: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000413F0: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000413F4: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000413F8: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041400: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 000000041404: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000004140C: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041410: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 000000041414: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 00000004141C: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041420: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 000000041424: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 00000004142C: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 000000041430: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041438: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 00000004143C: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 000000041440: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041448: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 00000004144C: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 000000041450: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041458: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 00000004145C: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 000000041464: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 00000004146C: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041478: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 00000004147C: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 000000041484: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 000000041490: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 000000041498: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004149C: BE882001
	s_cbranch_execz 63931                                      // 0000000414A0: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3890>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 0000000414A4: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 0000000414B0: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 0000000414B4: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 0000000414BC: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000414C0: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000414C4: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 0000000414C8: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000414D0: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 0000000414D8: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000000414E4: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000414E8: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 0000000414EC: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 0000000414F4: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000414F8: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000000414FC: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 000000041500: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 000000041504: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041508: BF870095
	.long 0xd71c0069                                           // 00000004150C: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 000000041510: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 000000041514: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000041518: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041520: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 000000041524: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000004152C: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041530: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 000000041534: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 00000004153C: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041540: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 000000041544: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 00000004154C: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 000000041550: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041558: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 00000004155C: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 000000041560: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041568: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 00000004156C: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 000000041570: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041578: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 00000004157C: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 000000041584: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 00000004158C: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041598: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 00000004159C: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 0000000415A4: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 0000000415B0: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000415B8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000415BC: BE882002
	s_cbranch_execz 63862                                      // 0000000415C0: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x389c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 0000000415C4: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000415D0: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000415D8: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000415DC: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000415E0: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000415E4: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 0000000415EC: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 0000000415F8: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000415FC: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 000000041600: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000041604: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 00000004160C: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000041614: BF870121
	v_add_f32_e32 v98, v98, v105                               // 000000041618: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 00000004161C: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 000000041620: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041624: BF870095
	.long 0xd71c0062                                           // 000000041628: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 00000004162C: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000041630: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000041634: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004163C: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 000000041640: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000004164C: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041650: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000041654: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 00000004165C: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041660: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 000000041664: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 00000004166C: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 000000041670: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041678: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 00000004167C: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 000000041680: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041688: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 00000004168C: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 000000041690: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041698: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 00000004169C: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000416A4: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 0000000416AC: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000416B8: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 0000000416BC: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 0000000416C4: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000416D0: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000416D8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000416DC: BE882003
	s_cbranch_execz 63793                                      // 0000000416E0: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38a8>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 0000000416E4: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000416F0: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000416F8: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000416FC: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041700: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000041704: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000004170C: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 000000041718: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004171C: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 000000041720: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 00000004172C: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 000000041730: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000041734: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004173C: BF870293
	v_exp_f32_e32 v98, v98                                     // 000000041740: 7EC44B62
	.long 0xd71c0062                                           // 000000041744: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000041748: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004174C: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000041750: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000041754: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 00000004175C: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041768: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 00000004176C: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000041770: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000041778: BF870291
	v_rcp_f32_e32 v100, v99                                    // 00000004177C: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 000000041780: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000041788: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 00000004178C: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 000000041790: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 000000041798: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004179C: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 0000000417A0: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 0000000417A8: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000417AC: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 0000000417B0: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 0000000417B8: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000417C0: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000417C4: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 0000000417CC: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000417D8: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000417E0: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000417E4: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000417F0: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000417F8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000417FC: BE882004
	s_cbranch_execz 63724                                      // 000000041800: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38b4>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 000000041804: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000041810: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000041818: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000004181C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041820: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000041824: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000004182C: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000041838: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004183C: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000041840: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000041844: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000004184C: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000041854: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000041858: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000004185C: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000041860: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041864: BF870095
	.long 0xd71c0062                                           // 000000041868: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000004186C: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000041870: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000041874: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004187C: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 000000041880: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000004188C: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041890: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000041894: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 00000004189C: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000418A0: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000418A4: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000418AC: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000418B0: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000418B8: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 0000000418BC: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 0000000418C0: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000418C8: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 0000000418CC: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 0000000418D0: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000418D8: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 0000000418DC: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000418E4: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 0000000418EC: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000418F8: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000418FC: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000041904: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000041910: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000041918: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004191C: BE882005
	s_cbranch_execz 63655                                      // 000000041920: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38c0>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 000000041924: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000041930: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000041938: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000004193C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041940: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000041944: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000004194C: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000041958: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004195C: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000041960: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000041964: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000004196C: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000041974: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000041978: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000004197C: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000041980: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041984: BF870095
	.long 0xd71c0062                                           // 000000041988: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000004198C: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000041990: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000041994: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004199C: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000000419A0: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 0000000419A8: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000419B0: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000419B4: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000419BC: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000419C0: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000419C4: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000419CC: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000419D0: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000419D8: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000419DC: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 0000000419E0: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000419E8: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 0000000419EC: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 0000000419F0: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000419F8: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000419FC: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000041A04: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 000000041A0C: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041A18: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000041A1C: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000041A24: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000041A30: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000041A38: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000041A3C: BE882006
	s_cbranch_execz 63586                                      // 000000041A40: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38cc>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 000000041A44: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000041A50: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000041A58: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000041A5C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041A60: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000041A64: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000041A6C: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000041A78: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000041A7C: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000041A80: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000041A84: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000041A8C: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000041A94: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000041A98: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000041A9C: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000041AA0: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041AA4: BF870095
	.long 0xd71c0062                                           // 000000041AA8: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000041AAC: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000041AB0: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000041AB4: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041ABC: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 000000041AC0: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000041ACC: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041AD0: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000041AD4: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000041ADC: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041AE0: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 000000041AE4: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000041AEC: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000041AF0: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041AF8: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 000000041AFC: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 000000041B00: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041B08: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 000000041B0C: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 000000041B10: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041B18: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 000000041B1C: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000041B24: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 000000041B2C: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041B38: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000041B3C: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000041B44: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000041B50: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000041B58: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000041B5C: BE882007
	s_cbranch_execz 63517                                      // 000000041B60: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38d8>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 000000041B64: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 000000041B70: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000041B78: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000041B7C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041B80: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000041B84: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000041B8C: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000041B98: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000041B9C: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000041BA0: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000041BA4: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000041BAC: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000041BB4: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000041BB8: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000041BBC: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000041BC0: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041BC4: BF870095
	.long 0xd71c0062                                           // 000000041BC8: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000041BCC: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000041BD0: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000041BD4: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041BDC: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 000000041BE0: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000041BEC: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041BF0: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000041BF4: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000041BFC: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041C00: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 000000041C04: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000041C0C: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000041C10: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041C18: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 000000041C1C: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 000000041C20: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041C28: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 000000041C2C: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 000000041C30: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041C38: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 000000041C3C: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000041C44: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 000000041C4C: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041C58: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000041C5C: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000041C64: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000041C70: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000041C78: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000041C7C: BE882000
	s_cbranch_execz 63448                                      // 000000041C80: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38e4>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 000000041C84: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 000000041C90: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 000000041C94: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 000000041C9C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000041CA0: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041CA4: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000041CA8: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000041CB0: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000041CBC: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000041CC0: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000041CC4: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000041CC8: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000041CD0: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000041CD8: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000041CDC: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000041CE0: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000041CE4: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041CE8: BF870095
	.long 0xd71c0062                                           // 000000041CEC: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000041CF0: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000041CF4: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000041CF8: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041D00: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 000000041D04: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000041D0C: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041D10: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 000000041D14: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 000000041D1C: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041D20: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 000000041D24: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 000000041D2C: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 000000041D30: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041D38: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 000000041D3C: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 000000041D40: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041D48: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 000000041D4C: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 000000041D50: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041D58: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 000000041D5C: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 000000041D64: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 000000041D6C: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041D78: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 000000041D7C: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 000000041D84: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 000000041D90: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 000000041D98: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000041D9C: BE882001
	s_cbranch_execz 63379                                      // 000000041DA0: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38f0>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 000000041DA4: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 000000041DB0: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 000000041DB4: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 000000041DBC: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000041DC0: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000041DC4: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 000000041DC8: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000041DD0: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 000000041DD8: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 000000041DE4: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000041DE8: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 000000041DEC: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 000000041DF4: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000041DF8: BF870121
	v_add_f32_e32 v97, v97, v98                                // 000000041DFC: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 000000041E00: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 000000041E04: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041E08: BF870095
	.long 0xd71c0061                                           // 000000041E0C: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 000000041E10: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 000000041E14: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000041E18: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041E20: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 000000041E24: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000041E2C: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041E30: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 000000041E34: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 000000041E3C: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041E40: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 000000041E44: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 000000041E4C: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 000000041E50: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041E58: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 000000041E5C: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 000000041E60: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041E68: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 000000041E6C: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 000000041E70: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041E78: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 000000041E7C: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 000000041E84: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 000000041E8C: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041E98: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 000000041E9C: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 000000041EA4: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 000000041EB0: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 000000041EB8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000041EBC: BE882002
	s_cbranch_execz 63310                                      // 000000041EC0: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38fc>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 000000041EC4: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000041ED0: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000041ED8: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000041EDC: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041EE0: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000041EE4: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 000000041EEC: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 000000041EF8: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000041EFC: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 000000041F00: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000041F04: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 000000041F0C: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000041F14: BF870121
	v_add_f32_e32 v90, v90, v97                                // 000000041F18: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 000000041F1C: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 000000041F20: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041F24: BF870095
	.long 0xd71c005a                                           // 000000041F28: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 000000041F2C: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000041F30: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000041F34: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041F3C: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 000000041F40: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000041F4C: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041F50: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000041F54: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 000000041F5C: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041F60: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 000000041F64: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 000000041F6C: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 000000041F70: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041F78: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 000000041F7C: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 000000041F80: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041F88: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 000000041F8C: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 000000041F90: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041F98: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 000000041F9C: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000041FA4: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 000000041FAC: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041FB8: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 000000041FBC: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 000000041FC4: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000041FD0: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000041FD8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000041FDC: BE882003
	s_cbranch_execz 63241                                      // 000000041FE0: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3908>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 000000041FE4: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000041FF0: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000041FF8: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000041FFC: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042000: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000042004: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000004200C: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 000000042018: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004201C: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 000000042020: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 00000004202C: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 000000042030: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000042034: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004203C: BF870293
	v_exp_f32_e32 v90, v90                                     // 000000042040: 7EB44B5A
	.long 0xd71c005a                                           // 000000042044: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000042048: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004204C: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000042050: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000042054: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 00000004205C: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042068: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 00000004206C: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000042070: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000042078: BF870291
	v_rcp_f32_e32 v92, v91                                     // 00000004207C: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 000000042080: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000042088: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 00000004208C: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 000000042090: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 000000042098: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004209C: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 0000000420A0: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 0000000420A8: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000420AC: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 0000000420B0: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 0000000420B8: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000420C0: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000420C4: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 0000000420CC: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000420D8: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000420E0: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000420E4: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000420F0: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000420F8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000420FC: BE882004
	s_cbranch_execz 63172                                      // 000000042100: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3914>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 000000042104: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000042110: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000042118: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000004211C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042120: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000042124: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000004212C: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000042138: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004213C: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000042140: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000042144: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000004214C: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042154: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000042158: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000004215C: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000042160: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042164: BF870095
	.long 0xd71c005a                                           // 000000042168: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000004216C: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000042170: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000042174: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004217C: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 000000042180: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000004218C: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042190: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000042194: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000004219C: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000421A0: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000421A4: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000421AC: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000421B0: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000421B8: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 0000000421BC: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 0000000421C0: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000421C8: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 0000000421CC: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 0000000421D0: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000421D8: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 0000000421DC: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000421E4: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 0000000421EC: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000421F8: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000421FC: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000042204: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000042210: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000042218: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004221C: BE882005
	s_cbranch_execz 63103                                      // 000000042220: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3920>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 000000042224: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000042230: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000042238: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000004223C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042240: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000042244: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000004224C: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000042258: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004225C: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000042260: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000042264: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000004226C: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042274: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000042278: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000004227C: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000042280: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042284: BF870095
	.long 0xd71c005a                                           // 000000042288: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000004228C: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000042290: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000042294: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004229C: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000000422A0: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 0000000422A8: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000422B0: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000422B4: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000422BC: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000422C0: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000422C4: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000422CC: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000422D0: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000422D8: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000422DC: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 0000000422E0: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000422E8: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 0000000422EC: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 0000000422F0: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000422F8: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000422FC: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000042304: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 00000004230C: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042318: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000004231C: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000042324: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000042330: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000042338: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004233C: BE882006
	s_cbranch_execz 63034                                      // 000000042340: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x392c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 000000042344: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000042350: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000042358: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000004235C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042360: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000042364: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000004236C: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000042378: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004237C: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000042380: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000042384: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000004238C: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042394: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000042398: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000004239C: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000423A0: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000423A4: BF870095
	.long 0xd71c005a                                           // 0000000423A8: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000423AC: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000423B0: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000423B4: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000423BC: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 0000000423C0: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000423CC: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000423D0: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000423D4: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000423DC: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000423E0: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000423E4: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000423EC: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000423F0: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000423F8: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000423FC: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 000000042400: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042408: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 00000004240C: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 000000042410: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042418: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 00000004241C: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000042424: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 00000004242C: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042438: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000004243C: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000042444: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000042450: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000042458: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004245C: BE882007
	s_cbranch_execz 62965                                      // 000000042460: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3938>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 000000042464: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000042470: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000042478: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000004247C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042480: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000042484: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000004248C: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000042498: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004249C: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000424A0: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000424A4: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000424AC: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000424B4: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000424B8: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000424BC: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000424C0: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000424C4: BF870095
	.long 0xd71c005a                                           // 0000000424C8: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000424CC: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000424D0: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000424D4: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000424DC: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 0000000424E0: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000424EC: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000424F0: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000424F4: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000424FC: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042500: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000042504: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000004250C: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000042510: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042518: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 00000004251C: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 000000042520: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042528: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 00000004252C: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 000000042530: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042538: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 00000004253C: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000042544: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 00000004254C: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042558: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000004255C: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000042564: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000042570: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000042578: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004257C: BE882000
	s_cbranch_execz 62896                                      // 000000042580: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3944>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 000000042584: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 000000042590: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 000000042594: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 00000004259C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000425A0: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000425A4: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000425A8: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000425B0: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000425BC: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000425C0: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000425C4: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000425C8: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000425D0: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000425D8: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000425DC: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000425E0: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000425E4: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000425E8: BF870095
	.long 0xd71c005a                                           // 0000000425EC: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000425F0: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000425F4: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000425F8: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042600: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 000000042604: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000004260C: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042610: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 000000042614: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 00000004261C: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042620: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 000000042624: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 00000004262C: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 000000042630: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042638: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 00000004263C: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 000000042640: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042648: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 00000004264C: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 000000042650: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042658: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 00000004265C: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 000000042664: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 00000004266C: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042678: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 00000004267C: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 000000042684: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 000000042690: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 000000042698: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004269C: BE882001
	s_cbranch_execz 62827                                      // 0000000426A0: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3950>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 0000000426A4: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 0000000426B0: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 0000000426B4: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 0000000426BC: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000426C0: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000426C4: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 0000000426C8: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000426D0: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 0000000426D8: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000000426E4: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000426E8: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 0000000426EC: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 0000000426F4: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000426F8: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000000426FC: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 000000042700: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 000000042704: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042708: BF870095
	.long 0xd71c0059                                           // 00000004270C: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 000000042710: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 000000042714: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000042718: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042720: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 000000042724: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000004272C: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042730: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 000000042734: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 00000004273C: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042740: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 000000042744: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 00000004274C: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 000000042750: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042758: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 00000004275C: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 000000042760: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042768: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 00000004276C: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 000000042770: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042778: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 00000004277C: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 000000042784: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 00000004278C: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042798: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 00000004279C: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 0000000427A4: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 0000000427B0: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000427B8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000427BC: BE882002
	s_cbranch_execz 62758                                      // 0000000427C0: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x395c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 0000000427C4: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000427D0: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000427D8: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000427DC: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000427E0: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000427E4: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 0000000427EC: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 0000000427F8: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000427FC: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 000000042800: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000042804: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 00000004280C: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042814: BF870121
	v_add_f32_e32 v82, v82, v89                                // 000000042818: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 00000004281C: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 000000042820: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042824: BF870095
	.long 0xd71c0052                                           // 000000042828: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 00000004282C: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000042830: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000042834: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004283C: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 000000042840: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000004284C: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042850: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000042854: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 00000004285C: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042860: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 000000042864: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 00000004286C: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 000000042870: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042878: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 00000004287C: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 000000042880: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042888: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 00000004288C: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 000000042890: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042898: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 00000004289C: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000428A4: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 0000000428AC: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000428B8: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 0000000428BC: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 0000000428C4: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000428D0: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000428D8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000428DC: BE882003
	s_cbranch_execz 62689                                      // 0000000428E0: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3968>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 0000000428E4: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000428F0: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000428F8: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000428FC: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042900: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000042904: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000004290C: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 000000042918: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004291C: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 000000042920: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 00000004292C: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 000000042930: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000042934: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004293C: BF870293
	v_exp_f32_e32 v82, v82                                     // 000000042940: 7EA44B52
	.long 0xd71c0052                                           // 000000042944: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000042948: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004294C: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000042950: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000042954: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 00000004295C: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042968: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 00000004296C: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000042970: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000042978: BF870291
	v_rcp_f32_e32 v84, v83                                     // 00000004297C: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 000000042980: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000042988: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 00000004298C: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 000000042990: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 000000042998: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004299C: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 0000000429A0: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 0000000429A8: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000429AC: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 0000000429B0: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 0000000429B8: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000429C0: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000429C4: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 0000000429CC: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000429D8: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000429E0: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000429E4: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000429F0: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000429F8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000429FC: BE882004
	s_cbranch_execz 62620                                      // 000000042A00: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3974>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 000000042A04: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000042A10: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000042A18: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000042A1C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042A20: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000042A24: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000042A2C: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000042A38: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000042A3C: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000042A40: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000042A44: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000042A4C: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042A54: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000042A58: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000042A5C: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000042A60: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042A64: BF870095
	.long 0xd71c0052                                           // 000000042A68: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000042A6C: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000042A70: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000042A74: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042A7C: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 000000042A80: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000042A8C: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042A90: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000042A94: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000042A9C: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042AA0: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 000000042AA4: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000042AAC: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000042AB0: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042AB8: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 000000042ABC: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 000000042AC0: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042AC8: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 000000042ACC: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 000000042AD0: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042AD8: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 000000042ADC: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000042AE4: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 000000042AEC: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042AF8: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000042AFC: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000042B04: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000042B10: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000042B18: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000042B1C: BE882005
	s_cbranch_execz 62551                                      // 000000042B20: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3980>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 000000042B24: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000042B30: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000042B38: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000042B3C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042B40: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000042B44: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000042B4C: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000042B58: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000042B5C: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000042B60: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000042B64: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000042B6C: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042B74: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000042B78: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000042B7C: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000042B80: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042B84: BF870095
	.long 0xd71c0052                                           // 000000042B88: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000042B8C: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000042B90: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000042B94: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042B9C: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 000000042BA0: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 000000042BA8: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042BB0: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000042BB4: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000042BBC: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042BC0: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 000000042BC4: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000042BCC: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000042BD0: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042BD8: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 000000042BDC: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 000000042BE0: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042BE8: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 000000042BEC: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 000000042BF0: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042BF8: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 000000042BFC: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000042C04: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 000000042C0C: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042C18: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000042C1C: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000042C24: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000042C30: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000042C38: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000042C3C: BE882006
	s_cbranch_execz 62482                                      // 000000042C40: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x398c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 000000042C44: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000042C50: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000042C58: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000042C5C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042C60: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000042C64: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000042C6C: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000042C78: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000042C7C: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000042C80: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000042C84: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000042C8C: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042C94: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000042C98: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000042C9C: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000042CA0: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042CA4: BF870095
	.long 0xd71c0052                                           // 000000042CA8: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000042CAC: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000042CB0: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000042CB4: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042CBC: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 000000042CC0: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000042CCC: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042CD0: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000042CD4: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000042CDC: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042CE0: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 000000042CE4: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000042CEC: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000042CF0: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042CF8: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 000000042CFC: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 000000042D00: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042D08: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 000000042D0C: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 000000042D10: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042D18: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 000000042D1C: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000042D24: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 000000042D2C: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042D38: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000042D3C: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000042D44: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000042D50: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000042D58: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000042D5C: BE882007
	s_cbranch_execz 62413                                      // 000000042D60: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3998>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 000000042D64: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000042D70: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000042D78: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000042D7C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042D80: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000042D84: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000042D8C: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000042D98: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000042D9C: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000042DA0: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000042DA4: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000042DAC: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042DB4: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000042DB8: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000042DBC: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000042DC0: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042DC4: BF870095
	.long 0xd71c0052                                           // 000000042DC8: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000042DCC: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000042DD0: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000042DD4: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042DDC: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 000000042DE0: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000042DEC: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042DF0: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000042DF4: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000042DFC: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042E00: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 000000042E04: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000042E0C: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000042E10: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042E18: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 000000042E1C: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 000000042E20: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042E28: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 000000042E2C: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 000000042E30: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042E38: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 000000042E3C: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000042E44: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 000000042E4C: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042E58: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000042E5C: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000042E64: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000042E70: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000042E78: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000042E7C: BE882000
	s_cbranch_execz 62344                                      // 000000042E80: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39a4>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 000000042E84: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 000000042E90: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 000000042E94: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000042E9C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000042EA0: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042EA4: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000042EA8: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000042EB0: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000042EBC: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000042EC0: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000042EC4: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000042EC8: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000042ED0: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042ED8: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000042EDC: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000042EE0: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000042EE4: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042EE8: BF870095
	.long 0xd71c0052                                           // 000000042EEC: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000042EF0: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000042EF4: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000042EF8: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042F00: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 000000042F04: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000042F0C: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042F10: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 000000042F14: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 000000042F1C: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042F20: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 000000042F24: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 000000042F2C: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 000000042F30: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042F38: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 000000042F3C: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 000000042F40: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042F48: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 000000042F4C: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 000000042F50: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042F58: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 000000042F5C: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 000000042F64: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 000000042F6C: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042F78: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 000000042F7C: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 000000042F84: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 000000042F90: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 000000042F98: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000042F9C: BE882001
	s_cbranch_execz 62275                                      // 000000042FA0: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39b0>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 000000042FA4: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 000000042FB0: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 000000042FB4: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 000000042FBC: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000042FC0: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042FC4: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 000000042FC8: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000042FD0: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 000000042FD8: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 000000042FE4: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000042FE8: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 000000042FEC: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 000000042FF4: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042FF8: BF870121
	v_add_f32_e32 v81, v81, v82                                // 000000042FFC: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 000000043000: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 000000043004: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043008: BF870095
	.long 0xd71c0051                                           // 00000004300C: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 000000043010: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 000000043014: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000043018: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043020: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 000000043024: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000004302C: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043030: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 000000043034: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 00000004303C: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043040: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 000000043044: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 00000004304C: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 000000043050: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043058: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 00000004305C: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 000000043060: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043068: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 00000004306C: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 000000043070: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043078: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 00000004307C: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 000000043084: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 00000004308C: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043098: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 00000004309C: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 0000000430A4: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 0000000430B0: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000430B8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000430BC: BE882002
	s_cbranch_execz 62206                                      // 0000000430C0: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39bc>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 0000000430C4: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000430D0: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000430D8: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000430DC: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000430E0: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000430E4: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 0000000430EC: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 0000000430F8: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000430FC: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 000000043100: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000043104: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 00000004310C: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000043114: BF870121
	v_add_f32_e32 v74, v74, v81                                // 000000043118: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 00000004311C: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 000000043120: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043124: BF870095
	.long 0xd71c004a                                           // 000000043128: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 00000004312C: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000043130: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000043134: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004313C: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 000000043140: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000004314C: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043150: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000043154: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 00000004315C: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043160: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 000000043164: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 00000004316C: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 000000043170: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043178: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 00000004317C: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 000000043180: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043188: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 00000004318C: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 000000043190: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043198: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 00000004319C: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000431A4: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 0000000431AC: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000431B8: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 0000000431BC: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 0000000431C4: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000431D0: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000431D8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000431DC: BE882003
	s_cbranch_execz 62137                                      // 0000000431E0: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39c8>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 0000000431E4: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000431F0: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000431F8: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000431FC: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043200: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000043204: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000004320C: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 000000043218: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004321C: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 000000043220: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 00000004322C: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 000000043230: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000043234: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004323C: BF870293
	v_exp_f32_e32 v74, v74                                     // 000000043240: 7E944B4A
	.long 0xd71c004a                                           // 000000043244: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000043248: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004324C: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000043250: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000043254: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 00000004325C: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043268: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 00000004326C: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000043270: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000043278: BF870291
	v_rcp_f32_e32 v76, v75                                     // 00000004327C: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 000000043280: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000043288: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 00000004328C: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 000000043290: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 000000043298: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004329C: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 0000000432A0: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 0000000432A8: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000432AC: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 0000000432B0: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 0000000432B8: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000432C0: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000432C4: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 0000000432CC: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000432D8: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000432E0: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000432E4: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000432F0: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000432F8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000432FC: BE882004
	s_cbranch_execz 62068                                      // 000000043300: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39d4>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 000000043304: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000043310: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000043318: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000004331C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043320: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000043324: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000004332C: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000043338: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004333C: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000043340: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000043344: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000004334C: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000043354: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000043358: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000004335C: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000043360: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043364: BF870095
	.long 0xd71c004a                                           // 000000043368: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000004336C: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000043370: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000043374: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004337C: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 000000043380: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000004338C: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043390: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000043394: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 00000004339C: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000433A0: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000433A4: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000433AC: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000433B0: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000433B8: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 0000000433BC: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 0000000433C0: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000433C8: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 0000000433CC: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 0000000433D0: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000433D8: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 0000000433DC: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000433E4: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 0000000433EC: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000433F8: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000433FC: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000043404: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000043410: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000043418: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004341C: BE882005
	s_cbranch_execz 61999                                      // 000000043420: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39e0>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 000000043424: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000043430: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000043438: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000004343C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043440: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000043444: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000004344C: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000043458: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004345C: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000043460: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000043464: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000004346C: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000043474: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000043478: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000004347C: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000043480: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043484: BF870095
	.long 0xd71c004a                                           // 000000043488: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000004348C: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000043490: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000043494: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004349C: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000000434A0: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 0000000434A8: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000434B0: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000434B4: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000434BC: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000434C0: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000434C4: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000434CC: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000434D0: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000434D8: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000434DC: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 0000000434E0: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000434E8: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 0000000434EC: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 0000000434F0: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000434F8: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000434FC: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000043504: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 00000004350C: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043518: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 00000004351C: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000043524: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000043530: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000043538: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004353C: BE882006
	s_cbranch_execz 61930                                      // 000000043540: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39ec>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 000000043544: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000043550: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000043558: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000004355C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043560: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000043564: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000004356C: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000043578: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004357C: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000043580: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000043584: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000004358C: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000043594: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000043598: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000004359C: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000435A0: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000435A4: BF870095
	.long 0xd71c004a                                           // 0000000435A8: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000435AC: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000435B0: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000435B4: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000435BC: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 0000000435C0: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000435CC: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000435D0: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000435D4: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000435DC: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000435E0: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000435E4: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000435EC: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000435F0: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000435F8: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000435FC: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 000000043600: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043608: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 00000004360C: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 000000043610: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043618: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 00000004361C: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000043624: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 00000004362C: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043638: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 00000004363C: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000043644: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000043650: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000043658: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004365C: BE882007
	s_cbranch_execz 61861                                      // 000000043660: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39f8>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 000000043664: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000043670: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000043678: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000004367C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043680: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000043684: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000004368C: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000043698: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004369C: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000436A0: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000436A4: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000436AC: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000436B4: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000436B8: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000436BC: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000436C0: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000436C4: BF870095
	.long 0xd71c004a                                           // 0000000436C8: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000436CC: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000436D0: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000436D4: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000436DC: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 0000000436E0: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000436EC: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000436F0: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000436F4: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000436FC: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043700: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000043704: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 00000004370C: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000043710: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043718: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 00000004371C: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 000000043720: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043728: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 00000004372C: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 000000043730: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043738: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 00000004373C: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000043744: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 00000004374C: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043758: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 00000004375C: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000043764: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000043770: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000043778: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004377C: BE882000
	s_cbranch_execz 61792                                      // 000000043780: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a04>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 000000043784: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 000000043790: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 000000043794: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000004379C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000437A0: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000437A4: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000437A8: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000437B0: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000437BC: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000437C0: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000437C4: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000437C8: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000437D0: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000437D8: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000437DC: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000437E0: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000437E4: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000437E8: BF870095
	.long 0xd71c004a                                           // 0000000437EC: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000437F0: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000437F4: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000437F8: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043800: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 000000043804: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000004380C: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043810: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 000000043814: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 00000004381C: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043820: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 000000043824: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 00000004382C: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 000000043830: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043838: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 00000004383C: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 000000043840: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043848: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 00000004384C: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 000000043850: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043858: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 00000004385C: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 000000043864: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 00000004386C: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043878: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 00000004387C: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 000000043884: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 000000043890: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 000000043898: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004389C: BE882001
	s_cbranch_execz 61723                                      // 0000000438A0: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a10>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 0000000438A4: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 0000000438B0: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 0000000438B4: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 0000000438BC: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000438C0: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000438C4: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 0000000438C8: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000438D0: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 0000000438D8: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000000438E4: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000438E8: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 0000000438EC: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 0000000438F4: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000438F8: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000000438FC: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 000000043900: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 000000043904: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043908: BF870095
	.long 0xd71c0049                                           // 00000004390C: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 000000043910: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 000000043914: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000043918: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043920: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 000000043924: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000004392C: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043930: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 000000043934: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 00000004393C: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043940: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 000000043944: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 00000004394C: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 000000043950: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043958: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 00000004395C: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 000000043960: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043968: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 00000004396C: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 000000043970: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043978: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 00000004397C: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 000000043984: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 00000004398C: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043998: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 00000004399C: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 0000000439A4: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 0000000439B0: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000439B8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000439BC: BE882002
	s_cbranch_execz 61654                                      // 0000000439C0: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a1c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 0000000439C4: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000439D0: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000439D8: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000439DC: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000439E0: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000439E4: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 0000000439EC: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 0000000439F8: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000439FC: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 000000043A00: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000043A04: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 000000043A0C: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000043A14: BF870121
	v_add_f32_e32 v66, v66, v73                                // 000000043A18: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 000000043A1C: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 000000043A20: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043A24: BF870095
	.long 0xd71c0042                                           // 000000043A28: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 000000043A2C: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000043A30: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000043A34: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043A3C: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 000000043A40: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000043A4C: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043A50: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000043A54: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 000000043A5C: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043A60: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 000000043A64: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 000000043A6C: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 000000043A70: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043A78: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 000000043A7C: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 000000043A80: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043A88: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 000000043A8C: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 000000043A90: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043A98: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 000000043A9C: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000043AA4: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 000000043AAC: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043AB8: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 000000043ABC: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 000000043AC4: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000043AD0: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000043AD8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000043ADC: BE882003
	s_cbranch_execz 61585                                      // 000000043AE0: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a28>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 000000043AE4: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000043AF0: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000043AF8: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000043AFC: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043B00: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000043B04: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000043B0C: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 000000043B18: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043B1C: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 000000043B20: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 000000043B2C: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 000000043B30: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000043B34: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000043B3C: BF870293
	v_exp_f32_e32 v66, v66                                     // 000000043B40: 7E844B42
	.long 0xd71c0042                                           // 000000043B44: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000043B48: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000043B4C: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000043B50: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000043B54: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 000000043B5C: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043B68: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 000000043B6C: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000043B70: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000043B78: BF870291
	v_rcp_f32_e32 v68, v67                                     // 000000043B7C: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 000000043B80: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000043B88: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 000000043B8C: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 000000043B90: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 000000043B98: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043B9C: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 000000043BA0: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 000000043BA8: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043BAC: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 000000043BB0: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 000000043BB8: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000043BC0: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000043BC4: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 000000043BCC: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 000000043BD8: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 000000043BE0: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000043BE4: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000043BF0: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000043BF8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000043BFC: BE882004
	s_cbranch_execz 61516                                      // 000000043C00: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a34>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 000000043C04: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000043C10: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000043C18: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000043C1C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043C20: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000043C24: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000043C2C: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000043C38: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000043C3C: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000043C40: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000043C44: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000043C4C: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000043C54: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000043C58: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000043C5C: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000043C60: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043C64: BF870095
	.long 0xd71c0042                                           // 000000043C68: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000043C6C: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000043C70: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000043C74: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043C7C: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 000000043C80: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000043C8C: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043C90: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000043C94: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000043C9C: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043CA0: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000043CA4: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000043CAC: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000043CB0: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043CB8: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 000000043CBC: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 000000043CC0: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043CC8: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 000000043CCC: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 000000043CD0: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043CD8: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 000000043CDC: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000043CE4: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 000000043CEC: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043CF8: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000043CFC: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000043D04: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000043D10: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000043D18: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000043D1C: BE882005
	s_cbranch_execz 61447                                      // 000000043D20: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a40>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 000000043D24: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000043D30: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000043D38: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000043D3C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043D40: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000043D44: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000043D4C: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000043D58: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000043D5C: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000043D60: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000043D64: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000043D6C: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000043D74: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000043D78: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000043D7C: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000043D80: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043D84: BF870095
	.long 0xd71c0042                                           // 000000043D88: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000043D8C: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000043D90: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000043D94: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043D9C: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000043DA0: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 000000043DA8: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043DB0: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000043DB4: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000043DBC: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043DC0: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000043DC4: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000043DCC: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000043DD0: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043DD8: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000043DDC: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 000000043DE0: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043DE8: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 000000043DEC: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 000000043DF0: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043DF8: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000043DFC: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000043E04: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 000000043E0C: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043E18: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000043E1C: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000043E24: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000043E30: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000043E38: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000043E3C: BE882006
	s_cbranch_execz 61378                                      // 000000043E40: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a4c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 000000043E44: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000043E50: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000043E58: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000043E5C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043E60: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000043E64: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000043E6C: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000043E78: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000043E7C: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000043E80: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000043E84: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000043E8C: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000043E94: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000043E98: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000043E9C: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000043EA0: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043EA4: BF870095
	.long 0xd71c0042                                           // 000000043EA8: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000043EAC: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000043EB0: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000043EB4: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043EBC: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 000000043EC0: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000043ECC: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043ED0: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000043ED4: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000043EDC: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043EE0: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000043EE4: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000043EEC: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000043EF0: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043EF8: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000043EFC: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000043F00: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043F08: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 000000043F0C: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 000000043F10: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043F18: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000043F1C: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000043F24: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 000000043F2C: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043F38: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000043F3C: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000043F44: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000043F50: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000043F58: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000043F5C: BE882007
	s_cbranch_execz 61309                                      // 000000043F60: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a58>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 000000043F64: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000043F70: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000043F78: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000043F7C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043F80: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000043F84: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000043F8C: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000043F98: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000043F9C: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000043FA0: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000043FA4: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000043FAC: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000043FB4: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000043FB8: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000043FBC: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000043FC0: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043FC4: BF870095
	.long 0xd71c0042                                           // 000000043FC8: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000043FCC: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000043FD0: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000043FD4: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043FDC: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 000000043FE0: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000043FEC: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043FF0: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000043FF4: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000043FFC: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044000: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000044004: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 00000004400C: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000044010: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044018: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 00000004401C: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000044020: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044028: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 00000004402C: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 000000044030: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044038: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 00000004403C: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000044044: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 00000004404C: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044058: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 00000004405C: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000044064: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000044070: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000044078: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004407C: BE882000
	s_cbranch_execz 61240                                      // 000000044080: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a64>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 000000044084: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 000000044090: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 000000044094: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 00000004409C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000440A0: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000440A4: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000440A8: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000440B0: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000440BC: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000440C0: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000440C4: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000440C8: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000440D0: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000440D8: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000440DC: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000440E0: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000440E4: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000440E8: BF870095
	.long 0xd71c0042                                           // 0000000440EC: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000440F0: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000440F4: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000440F8: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044100: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000044104: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000004410C: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044110: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 000000044114: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 00000004411C: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044120: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 000000044124: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 00000004412C: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 000000044130: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044138: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 00000004413C: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 000000044140: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044148: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 00000004414C: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 000000044150: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044158: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 00000004415C: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 000000044164: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 00000004416C: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044178: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 00000004417C: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 000000044184: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 000000044190: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 000000044198: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004419C: BE882001
	s_cbranch_execz 61171                                      // 0000000441A0: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a70>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 0000000441A4: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 0000000441B0: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 0000000441B4: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 0000000441BC: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000441C0: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000441C4: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 0000000441C8: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000441D0: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 0000000441D8: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 0000000441E4: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000441E8: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 0000000441EC: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 0000000441F4: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000441F8: BF870121
	v_add_f32_e32 v65, v65, v66                                // 0000000441FC: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000044200: 7E841143
	v_exp_f32_e32 v65, v65                                     // 000000044204: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044208: BF870095
	.long 0xd71c0041                                           // 00000004420C: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000044210: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 000000044214: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000044218: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044220: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 000000044224: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000004422C: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044230: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 000000044234: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 00000004423C: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044240: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 000000044244: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 00000004424C: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 000000044250: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044258: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 00000004425C: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 000000044260: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044268: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 00000004426C: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 000000044270: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044278: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 00000004427C: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 000000044284: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 00000004428C: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044298: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 00000004429C: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 0000000442A4: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 0000000442B0: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000442B8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000442BC: BE882002
	s_cbranch_execz 61102                                      // 0000000442C0: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a7c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 0000000442C4: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000442D0: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000442D8: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000442DC: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000442E0: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000442E4: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 0000000442EC: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 0000000442F8: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000442FC: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 000000044300: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000044304: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 00000004430C: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000044314: BF870121
	v_add_f32_e32 v58, v58, v65                                // 000000044318: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 00000004431C: 7E821142
	v_exp_f32_e32 v58, v58                                     // 000000044320: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044324: BF870095
	.long 0xd71c003a                                           // 000000044328: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 00000004432C: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000044330: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000044334: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004433C: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 000000044340: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000004434C: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044350: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000044354: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 00000004435C: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044360: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 000000044364: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 00000004436C: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 000000044370: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044378: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 00000004437C: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 000000044380: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044388: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 00000004438C: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 000000044390: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044398: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 00000004439C: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000443A4: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 0000000443AC: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000443B8: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 0000000443BC: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 0000000443C4: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000443D0: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000443D8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000443DC: BE882003
	s_cbranch_execz 61033                                      // 0000000443E0: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a88>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 0000000443E4: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000443F0: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000443F8: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000443FC: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044400: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000044404: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000004440C: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 000000044418: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004441C: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 000000044420: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 00000004442C: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 000000044430: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000044434: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004443C: BF870293
	v_exp_f32_e32 v58, v58                                     // 000000044440: 7E744B3A
	.long 0xd71c003a                                           // 000000044444: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000044448: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004444C: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000044450: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000044454: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 00000004445C: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044468: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 00000004446C: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000044470: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000044478: BF870291
	v_rcp_f32_e32 v60, v59                                     // 00000004447C: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 000000044480: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000044488: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 00000004448C: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 000000044490: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 000000044498: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004449C: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 0000000444A0: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 0000000444A8: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000444AC: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 0000000444B0: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 0000000444B8: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000444C0: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000444C4: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 0000000444CC: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000444D8: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000444E0: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000444E4: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000444F0: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000444F8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000444FC: BE882004
	s_cbranch_execz 60964                                      // 000000044500: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a94>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 000000044504: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000044510: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000044518: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000004451C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044520: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000044524: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000004452C: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000044538: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004453C: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000044540: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000044544: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000004454C: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000044554: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000044558: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000004455C: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000044560: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044564: BF870095
	.long 0xd71c003a                                           // 000000044568: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000004456C: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000044570: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000044574: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004457C: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 000000044580: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000004458C: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044590: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000044594: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000004459C: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000445A0: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000445A4: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000445AC: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000445B0: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000445B8: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 0000000445BC: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 0000000445C0: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000445C8: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 0000000445CC: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 0000000445D0: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000445D8: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 0000000445DC: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000445E4: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 0000000445EC: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000445F8: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000445FC: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000044604: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000044610: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000044618: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004461C: BE882005
	s_cbranch_execz 60895                                      // 000000044620: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3aa0>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 000000044624: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000044630: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000044638: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000004463C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044640: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000044644: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000004464C: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000044658: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004465C: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000044660: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000044664: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000004466C: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000044674: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000044678: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000004467C: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000044680: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044684: BF870095
	.long 0xd71c003a                                           // 000000044688: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000004468C: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000044690: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000044694: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004469C: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000000446A0: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 0000000446A8: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000446B0: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000446B4: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000446BC: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000446C0: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000446C4: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000446CC: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000446D0: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000446D8: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000446DC: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 0000000446E0: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000446E8: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 0000000446EC: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 0000000446F0: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000446F8: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000446FC: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000044704: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 00000004470C: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044718: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000004471C: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000044724: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000044730: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000044738: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004473C: BE882006
	s_cbranch_execz 60826                                      // 000000044740: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3aac>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 000000044744: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000044750: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000044758: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000004475C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044760: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000044764: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000004476C: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000044778: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004477C: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000044780: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000044784: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000004478C: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000044794: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000044798: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000004479C: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000447A0: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000447A4: BF870095
	.long 0xd71c003a                                           // 0000000447A8: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000447AC: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000447B0: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000447B4: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000447BC: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 0000000447C0: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000447CC: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000447D0: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000447D4: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000447DC: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000447E0: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000447E4: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000447EC: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000447F0: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000447F8: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000447FC: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 000000044800: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044808: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 00000004480C: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 000000044810: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044818: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 00000004481C: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000044824: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 00000004482C: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044838: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000004483C: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000044844: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000044850: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000044858: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004485C: BE882007
	s_cbranch_execz 60757                                      // 000000044860: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ab8>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 000000044864: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000044870: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000044878: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000004487C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044880: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000044884: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000004488C: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000044898: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004489C: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000448A0: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000448A4: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000448AC: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000448B4: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000448B8: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000448BC: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000448C0: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000448C4: BF870095
	.long 0xd71c003a                                           // 0000000448C8: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000448CC: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000448D0: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000448D4: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000448DC: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 0000000448E0: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000448EC: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000448F0: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000448F4: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000448FC: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044900: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000044904: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000004490C: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000044910: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044918: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 00000004491C: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 000000044920: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044928: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 00000004492C: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 000000044930: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044938: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 00000004493C: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000044944: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 00000004494C: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044958: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000004495C: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000044964: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000044970: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000044978: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004497C: BE882000
	s_cbranch_execz 60688                                      // 000000044980: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ac4>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 000000044984: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 000000044990: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 000000044994: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 00000004499C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000449A0: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000449A4: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000449A8: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000449B0: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000449BC: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000449C0: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000449C4: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000449C8: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000449D0: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000449D8: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000449DC: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000449E0: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000449E4: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000449E8: BF870095
	.long 0xd71c003a                                           // 0000000449EC: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000449F0: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000449F4: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000449F8: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044A00: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 000000044A04: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000044A0C: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044A10: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 000000044A14: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 000000044A1C: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044A20: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 000000044A24: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 000000044A2C: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 000000044A30: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044A38: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 000000044A3C: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 000000044A40: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044A48: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 000000044A4C: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 000000044A50: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044A58: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 000000044A5C: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 000000044A64: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 000000044A6C: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044A78: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 000000044A7C: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 000000044A84: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 000000044A90: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 000000044A98: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000044A9C: BE882001
	s_cbranch_execz 60619                                      // 000000044AA0: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ad0>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 000000044AA4: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 000000044AB0: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 000000044AB4: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 000000044ABC: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000044AC0: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000044AC4: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 000000044AC8: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000044AD0: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 000000044AD8: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 000000044AE4: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000044AE8: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 000000044AEC: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 000000044AF4: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000044AF8: BF870121
	v_add_f32_e32 v57, v57, v58                                // 000000044AFC: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 000000044B00: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 000000044B04: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044B08: BF870095
	.long 0xd71c0039                                           // 000000044B0C: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 000000044B10: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 000000044B14: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000044B18: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044B20: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 000000044B24: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000044B2C: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044B30: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 000000044B34: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 000000044B3C: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044B40: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 000000044B44: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 000000044B4C: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 000000044B50: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044B58: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 000000044B5C: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 000000044B60: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044B68: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 000000044B6C: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 000000044B70: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044B78: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 000000044B7C: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 000000044B84: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 000000044B8C: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044B98: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 000000044B9C: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 000000044BA4: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 000000044BB0: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 000000044BB8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000044BBC: BE882002
	s_cbranch_execz 60550                                      // 000000044BC0: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3adc>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 000000044BC4: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000044BD0: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000044BD8: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000044BDC: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044BE0: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000044BE4: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 000000044BEC: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 000000044BF8: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000044BFC: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 000000044C00: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000044C04: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 000000044C0C: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000044C14: BF870121
	v_add_f32_e32 v50, v50, v57                                // 000000044C18: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 000000044C1C: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 000000044C20: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044C24: BF870095
	.long 0xd71c0032                                           // 000000044C28: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 000000044C2C: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000044C30: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000044C34: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044C3C: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 000000044C40: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000044C4C: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044C50: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000044C54: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 000000044C5C: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044C60: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 000000044C64: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 000000044C6C: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 000000044C70: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044C78: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 000000044C7C: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 000000044C80: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044C88: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 000000044C8C: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 000000044C90: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044C98: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 000000044C9C: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000044CA4: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 000000044CAC: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044CB8: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 000000044CBC: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 000000044CC4: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000044CD0: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000044CD8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000044CDC: BE882003
	s_cbranch_execz 60481                                      // 000000044CE0: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ae8>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 000000044CE4: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000044CF0: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000044CF8: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000044CFC: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044D00: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000044D04: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000044D0C: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 000000044D18: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044D1C: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 000000044D20: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 000000044D2C: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 000000044D30: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000044D34: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000044D3C: BF870293
	v_exp_f32_e32 v50, v50                                     // 000000044D40: 7E644B32
	.long 0xd71c0032                                           // 000000044D44: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000044D48: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000044D4C: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000044D50: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000044D54: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 000000044D5C: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044D68: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 000000044D6C: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000044D70: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000044D78: BF870291
	v_rcp_f32_e32 v52, v51                                     // 000000044D7C: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 000000044D80: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000044D88: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 000000044D8C: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 000000044D90: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 000000044D98: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044D9C: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 000000044DA0: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 000000044DA8: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044DAC: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 000000044DB0: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 000000044DB8: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000044DC0: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000044DC4: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 000000044DCC: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 000000044DD8: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 000000044DE0: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000044DE4: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000044DF0: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000044DF8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000044DFC: BE882004
	s_cbranch_execz 60412                                      // 000000044E00: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3af4>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 000000044E04: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000044E10: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000044E18: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000044E1C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044E20: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000044E24: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000044E2C: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000044E38: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000044E3C: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000044E40: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000044E44: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000044E4C: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000044E54: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000044E58: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000044E5C: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000044E60: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044E64: BF870095
	.long 0xd71c0032                                           // 000000044E68: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000044E6C: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000044E70: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000044E74: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044E7C: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 000000044E80: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000044E8C: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044E90: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000044E94: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000044E9C: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044EA0: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000044EA4: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000044EAC: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000044EB0: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044EB8: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 000000044EBC: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 000000044EC0: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044EC8: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 000000044ECC: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 000000044ED0: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044ED8: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 000000044EDC: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000044EE4: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 000000044EEC: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044EF8: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000044EFC: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000044F04: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000044F10: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000044F18: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000044F1C: BE882005
	s_cbranch_execz 60343                                      // 000000044F20: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b00>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 000000044F24: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000044F30: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000044F38: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000044F3C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044F40: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000044F44: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000044F4C: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000044F58: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000044F5C: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000044F60: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000044F64: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000044F6C: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000044F74: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000044F78: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000044F7C: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000044F80: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044F84: BF870095
	.long 0xd71c0032                                           // 000000044F88: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000044F8C: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000044F90: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000044F94: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044F9C: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 000000044FA0: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 000000044FA8: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044FB0: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000044FB4: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000044FBC: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044FC0: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000044FC4: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000044FCC: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000044FD0: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044FD8: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000044FDC: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 000000044FE0: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044FE8: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 000000044FEC: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 000000044FF0: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044FF8: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000044FFC: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000045004: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 00000004500C: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045018: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 00000004501C: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000045024: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000045030: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000045038: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004503C: BE882006
	s_cbranch_execz 60274                                      // 000000045040: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b0c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 000000045044: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000045050: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000045058: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000004505C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045060: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000045064: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000004506C: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000045078: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004507C: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000045080: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000045084: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000004508C: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000045094: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000045098: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000004509C: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000450A0: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000450A4: BF870095
	.long 0xd71c0032                                           // 0000000450A8: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000450AC: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000450B0: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000450B4: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000450BC: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 0000000450C0: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000450CC: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000450D0: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000450D4: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000450DC: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000450E0: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000450E4: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000450EC: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000450F0: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000450F8: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000450FC: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 000000045100: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045108: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 00000004510C: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 000000045110: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045118: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 00000004511C: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000045124: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 00000004512C: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045138: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 00000004513C: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000045144: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000045150: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000045158: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004515C: BE882007
	s_cbranch_execz 60205                                      // 000000045160: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b18>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 000000045164: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000045170: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000045178: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000004517C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045180: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000045184: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000004518C: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000045198: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004519C: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000451A0: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000451A4: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000451AC: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000451B4: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000451B8: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000451BC: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000451C0: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000451C4: BF870095
	.long 0xd71c0032                                           // 0000000451C8: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000451CC: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000451D0: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000451D4: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000451DC: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 0000000451E0: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000451EC: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000451F0: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000451F4: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000451FC: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045200: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000045204: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 00000004520C: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000045210: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045218: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 00000004521C: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 000000045220: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045228: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 00000004522C: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 000000045230: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045238: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 00000004523C: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000045244: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 00000004524C: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045258: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 00000004525C: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000045264: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000045270: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000045278: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004527C: BE882000
	s_cbranch_execz 60136                                      // 000000045280: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b24>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 000000045284: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 000000045290: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 000000045294: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 00000004529C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000452A0: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000452A4: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000452A8: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000452B0: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000452BC: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000452C0: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000452C4: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000452C8: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000452D0: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000452D8: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000452DC: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000452E0: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000452E4: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000452E8: BF870095
	.long 0xd71c0032                                           // 0000000452EC: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000452F0: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000452F4: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000452F8: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045300: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 000000045304: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000004530C: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045310: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 000000045314: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 00000004531C: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045320: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 000000045324: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 00000004532C: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 000000045330: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045338: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 00000004533C: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 000000045340: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045348: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 00000004534C: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 000000045350: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045358: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 00000004535C: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 000000045364: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 00000004536C: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045378: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 00000004537C: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 000000045384: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 000000045390: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 000000045398: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004539C: BE882001
	s_cbranch_execz 60067                                      // 0000000453A0: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b30>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 0000000453A4: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 0000000453B0: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 0000000453B4: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 0000000453BC: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000453C0: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000453C4: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 0000000453C8: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000453D0: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 0000000453D8: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 0000000453E4: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000453E8: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 0000000453EC: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 0000000453F4: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000453F8: BF870121
	v_add_f32_e32 v49, v49, v50                                // 0000000453FC: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 000000045400: 7E641133
	v_exp_f32_e32 v49, v49                                     // 000000045404: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045408: BF870095
	.long 0xd71c0031                                           // 00000004540C: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 000000045410: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 000000045414: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000045418: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045420: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 000000045424: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000004542C: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045430: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 000000045434: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 00000004543C: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045440: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 000000045444: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 00000004544C: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 000000045450: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045458: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 00000004545C: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 000000045460: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045468: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 00000004546C: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 000000045470: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045478: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 00000004547C: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 000000045484: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 00000004548C: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045498: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 00000004549C: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 0000000454A4: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 0000000454B0: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000454B8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000454BC: BE882002
	s_cbranch_execz 59998                                      // 0000000454C0: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b3c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 0000000454C4: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000454D0: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000454D8: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000454DC: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000454E0: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000454E4: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 0000000454EC: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 0000000454F8: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000454FC: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 000000045500: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000045504: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 00000004550C: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000045514: BF870121
	v_add_f32_e32 v42, v42, v49                                // 000000045518: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 00000004551C: 7E621132
	v_exp_f32_e32 v42, v42                                     // 000000045520: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045524: BF870095
	.long 0xd71c002a                                           // 000000045528: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 00000004552C: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000045530: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000045534: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004553C: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 000000045540: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000004554C: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045550: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000045554: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 00000004555C: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045560: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 000000045564: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 00000004556C: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 000000045570: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045578: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 00000004557C: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 000000045580: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045588: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 00000004558C: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 000000045590: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045598: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 00000004559C: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000455A4: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 0000000455AC: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000455B8: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 0000000455BC: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 0000000455C4: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000455D0: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000455D8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000455DC: BE882003
	s_cbranch_execz 59929                                      // 0000000455E0: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b48>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 0000000455E4: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000455F0: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000455F8: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000455FC: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045600: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000045604: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000004560C: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 000000045618: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004561C: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 000000045620: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 00000004562C: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 000000045630: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000045634: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004563C: BF870293
	v_exp_f32_e32 v42, v42                                     // 000000045640: 7E544B2A
	.long 0xd71c002a                                           // 000000045644: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000045648: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004564C: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000045650: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000045654: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 00000004565C: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045668: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 00000004566C: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000045670: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000045678: BF870291
	v_rcp_f32_e32 v44, v43                                     // 00000004567C: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 000000045680: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000045688: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 00000004568C: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 000000045690: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 000000045698: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004569C: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 0000000456A0: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 0000000456A8: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000456AC: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 0000000456B0: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 0000000456B8: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000456C0: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000456C4: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 0000000456CC: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000456D8: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000456E0: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000456E4: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000456F0: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000456F8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000456FC: BE882004
	s_cbranch_execz 59860                                      // 000000045700: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b54>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 000000045704: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000045710: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000045718: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000004571C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045720: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000045724: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000004572C: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000045738: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004573C: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000045740: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000045744: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000004574C: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000045754: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000045758: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000004575C: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000045760: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045764: BF870095
	.long 0xd71c002a                                           // 000000045768: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000004576C: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000045770: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000045774: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004577C: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 000000045780: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000004578C: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045790: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000045794: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000004579C: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000457A0: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000457A4: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000457AC: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000457B0: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000457B8: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 0000000457BC: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 0000000457C0: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000457C8: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 0000000457CC: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 0000000457D0: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000457D8: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 0000000457DC: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000457E4: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 0000000457EC: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000457F8: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000457FC: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000045804: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000045810: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000045818: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004581C: BE882005
	s_cbranch_execz 59791                                      // 000000045820: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b60>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 000000045824: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000045830: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000045838: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000004583C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045840: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000045844: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000004584C: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000045858: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004585C: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000045860: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000045864: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000004586C: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000045874: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000045878: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000004587C: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000045880: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045884: BF870095
	.long 0xd71c002a                                           // 000000045888: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000004588C: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000045890: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000045894: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004589C: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000000458A0: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 0000000458A8: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000458B0: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000458B4: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000458BC: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000458C0: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000458C4: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000458CC: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000458D0: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000458D8: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000458DC: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 0000000458E0: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000458E8: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 0000000458EC: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 0000000458F0: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000458F8: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000458FC: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000045904: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 00000004590C: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045918: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000004591C: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000045924: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000045930: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000045938: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004593C: BE882006
	s_cbranch_execz 59722                                      // 000000045940: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b6c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 000000045944: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000045950: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000045958: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000004595C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045960: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000045964: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000004596C: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000045978: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004597C: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000045980: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000045984: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000004598C: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000045994: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000045998: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000004599C: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000459A0: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000459A4: BF870095
	.long 0xd71c002a                                           // 0000000459A8: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000459AC: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000459B0: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000459B4: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000459BC: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 0000000459C0: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000459CC: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000459D0: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000459D4: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000459DC: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000459E0: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000459E4: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000459EC: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000459F0: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000459F8: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000459FC: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 000000045A00: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045A08: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 000000045A0C: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 000000045A10: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045A18: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 000000045A1C: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000045A24: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 000000045A2C: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045A38: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000045A3C: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000045A44: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000045A50: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000045A58: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000045A5C: BE882007
	s_cbranch_execz 59653                                      // 000000045A60: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b78>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 000000045A64: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000045A70: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000045A78: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000045A7C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045A80: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000045A84: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000045A8C: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000045A98: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000045A9C: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000045AA0: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000045AA4: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000045AAC: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000045AB4: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000045AB8: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000045ABC: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000045AC0: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045AC4: BF870095
	.long 0xd71c002a                                           // 000000045AC8: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000045ACC: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000045AD0: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000045AD4: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045ADC: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 000000045AE0: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000045AEC: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045AF0: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000045AF4: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000045AFC: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045B00: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 000000045B04: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000045B0C: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000045B10: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045B18: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 000000045B1C: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 000000045B20: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045B28: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 000000045B2C: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 000000045B30: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045B38: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 000000045B3C: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000045B44: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 000000045B4C: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045B58: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000045B5C: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000045B64: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000045B70: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000045B78: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000045B7C: BE882000
	s_cbranch_execz 59584                                      // 000000045B80: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b84>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 000000045B84: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 000000045B90: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 000000045B94: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 000000045B9C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000045BA0: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045BA4: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000045BA8: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000045BB0: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000045BBC: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000045BC0: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000045BC4: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000045BC8: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000045BD0: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000045BD8: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000045BDC: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000045BE0: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000045BE4: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045BE8: BF870095
	.long 0xd71c002a                                           // 000000045BEC: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000045BF0: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000045BF4: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000045BF8: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045C00: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 000000045C04: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000045C0C: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045C10: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 000000045C14: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 000000045C1C: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045C20: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 000000045C24: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 000000045C2C: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 000000045C30: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045C38: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 000000045C3C: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 000000045C40: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045C48: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 000000045C4C: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 000000045C50: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045C58: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 000000045C5C: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 000000045C64: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 000000045C6C: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045C78: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 000000045C7C: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 000000045C84: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 000000045C90: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 000000045C98: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000045C9C: BE882001
	s_cbranch_execz 59515                                      // 000000045CA0: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b90>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 000000045CA4: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 000000045CB0: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 000000045CB4: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 000000045CBC: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000045CC0: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000045CC4: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 000000045CC8: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000045CD0: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 000000045CD8: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 000000045CE4: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000045CE8: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 000000045CEC: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 000000045CF4: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000045CF8: BF870121
	v_add_f32_e32 v41, v41, v42                                // 000000045CFC: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 000000045D00: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 000000045D04: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045D08: BF870095
	.long 0xd71c0029                                           // 000000045D0C: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 000000045D10: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 000000045D14: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000045D18: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045D20: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 000000045D24: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000045D2C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045D30: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 000000045D34: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 000000045D3C: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045D40: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 000000045D44: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 000000045D4C: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 000000045D50: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045D58: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 000000045D5C: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 000000045D60: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045D68: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 000000045D6C: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 000000045D70: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045D78: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 000000045D7C: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 000000045D84: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 000000045D8C: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045D98: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 000000045D9C: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 000000045DA4: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 000000045DB0: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 000000045DB8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000045DBC: BE882002
	s_cbranch_execz 59446                                      // 000000045DC0: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b9c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 000000045DC4: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000045DD0: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000045DD8: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000045DDC: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045DE0: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000045DE4: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 000000045DEC: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 000000045DF8: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000045DFC: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 000000045E00: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000045E04: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 000000045E0C: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000045E14: BF870121
	v_add_f32_e32 v34, v34, v41                                // 000000045E18: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 000000045E1C: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 000000045E20: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045E24: BF870095
	.long 0xd71c0022                                           // 000000045E28: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 000000045E2C: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000045E30: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000045E34: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045E3C: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 000000045E40: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000045E4C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045E50: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000045E54: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 000000045E5C: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045E60: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 000000045E64: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 000000045E6C: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 000000045E70: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045E78: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 000000045E7C: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 000000045E80: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045E88: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 000000045E8C: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 000000045E90: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045E98: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 000000045E9C: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000045EA4: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 000000045EAC: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045EB8: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 000000045EBC: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 000000045EC4: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000045ED0: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000045ED8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000045EDC: BE882003
	s_cbranch_execz 59377                                      // 000000045EE0: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ba8>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 000000045EE4: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000045EF0: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000045EF8: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000045EFC: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045F00: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000045F04: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000045F0C: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 000000045F18: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045F1C: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 000000045F20: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 000000045F2C: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 000000045F30: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000045F34: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000045F3C: BF870293
	v_exp_f32_e32 v34, v34                                     // 000000045F40: 7E444B22
	.long 0xd71c0022                                           // 000000045F44: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000045F48: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000045F4C: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000045F50: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000045F54: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 000000045F5C: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045F68: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 000000045F6C: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000045F70: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000045F78: BF870291
	v_rcp_f32_e32 v36, v35                                     // 000000045F7C: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 000000045F80: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000045F88: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 000000045F8C: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 000000045F90: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 000000045F98: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045F9C: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 000000045FA0: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 000000045FA8: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045FAC: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 000000045FB0: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 000000045FB8: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000045FC0: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000045FC4: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 000000045FCC: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 000000045FD8: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 000000045FE0: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000045FE4: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000045FF0: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000045FF8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000045FFC: BE882004
	s_cbranch_execz 59308                                      // 000000046000: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bb4>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 000000046004: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000046010: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000046018: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000004601C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046020: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000046024: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000004602C: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000046038: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004603C: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000046040: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000046044: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000004604C: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000046054: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000046058: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000004605C: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000046060: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046064: BF870095
	.long 0xd71c0022                                           // 000000046068: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000004606C: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000046070: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000046074: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004607C: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 000000046080: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000004608C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046090: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000046094: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000004609C: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000460A0: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000460A4: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000460AC: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000460B0: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000460B8: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 0000000460BC: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 0000000460C0: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000460C8: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 0000000460CC: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 0000000460D0: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000460D8: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 0000000460DC: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000460E4: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 0000000460EC: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000460F8: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000460FC: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000046104: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000046110: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000046118: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004611C: BE882005
	s_cbranch_execz 59239                                      // 000000046120: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bc0>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 000000046124: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000046130: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000046138: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000004613C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046140: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000046144: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000004614C: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000046158: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004615C: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000046160: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000046164: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000004616C: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000046174: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000046178: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000004617C: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000046180: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046184: BF870095
	.long 0xd71c0022                                           // 000000046188: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000004618C: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000046190: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000046194: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004619C: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000000461A0: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 0000000461A8: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000461B0: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000461B4: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000461BC: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000461C0: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000461C4: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000461CC: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000461D0: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000461D8: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000461DC: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 0000000461E0: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000461E8: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 0000000461EC: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 0000000461F0: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000461F8: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000461FC: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000046204: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 00000004620C: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046218: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 00000004621C: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000046224: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000046230: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000046238: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004623C: BE882006
	s_cbranch_execz 59170                                      // 000000046240: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bcc>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 000000046244: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000046250: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000046258: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000004625C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046260: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000046264: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000004626C: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000046278: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004627C: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000046280: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000046284: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000004628C: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000046294: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000046298: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000004629C: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000462A0: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000462A4: BF870095
	.long 0xd71c0022                                           // 0000000462A8: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000462AC: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000462B0: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000462B4: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000462BC: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 0000000462C0: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000462CC: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000462D0: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000462D4: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000462DC: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000462E0: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000462E4: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000462EC: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000462F0: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000462F8: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000462FC: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 000000046300: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046308: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 00000004630C: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 000000046310: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046318: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 00000004631C: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000046324: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 00000004632C: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046338: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 00000004633C: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000046344: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000046350: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000046358: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004635C: BE882007
	s_cbranch_execz 59101                                      // 000000046360: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bd8>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 000000046364: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000046370: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000046378: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000004637C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046380: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000046384: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000004638C: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000046398: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004639C: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000463A0: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000463A4: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000463AC: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000463B4: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000463B8: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000463BC: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000463C0: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000463C4: BF870095
	.long 0xd71c0022                                           // 0000000463C8: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000463CC: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000463D0: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000463D4: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000463DC: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 0000000463E0: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000463EC: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000463F0: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000463F4: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000463FC: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046400: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000046404: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000004640C: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000046410: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046418: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 00000004641C: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 000000046420: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046428: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 00000004642C: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 000000046430: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046438: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 00000004643C: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000046444: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 00000004644C: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046458: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 00000004645C: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000046464: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000046470: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000046478: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004647C: BE882000
	s_cbranch_execz 59032                                      // 000000046480: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3be4>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 000000046484: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 000000046490: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 000000046494: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 00000004649C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000464A0: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000464A4: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000464A8: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000464B0: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000464BC: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000464C0: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000464C4: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000464C8: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000464D0: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000464D8: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000464DC: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000464E0: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000464E4: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000464E8: BF870095
	.long 0xd71c0022                                           // 0000000464EC: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000464F0: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000464F4: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000464F8: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046500: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 000000046504: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000004650C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046510: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 000000046514: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 00000004651C: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046520: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 000000046524: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 00000004652C: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 000000046530: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046538: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 00000004653C: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 000000046540: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046548: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 00000004654C: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 000000046550: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046558: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 00000004655C: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 000000046564: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 00000004656C: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046578: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 00000004657C: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 000000046584: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 000000046590: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 000000046598: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004659C: BE882001
	s_cbranch_execz 58963                                      // 0000000465A0: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bf0>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 0000000465A4: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 0000000465B0: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 0000000465B4: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 0000000465BC: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000465C0: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000465C4: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 0000000465C8: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000465D0: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 0000000465D8: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 0000000465E4: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000465E8: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 0000000465EC: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 0000000465F4: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000465F8: BF870121
	v_add_f32_e32 v33, v33, v34                                // 0000000465FC: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 000000046600: 7E441123
	v_exp_f32_e32 v33, v33                                     // 000000046604: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046608: BF870095
	.long 0xd71c0021                                           // 00000004660C: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 000000046610: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 000000046614: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000046618: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046620: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 000000046624: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000004662C: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046630: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 000000046634: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 00000004663C: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046640: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 000000046644: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 00000004664C: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 000000046650: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046658: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 00000004665C: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 000000046660: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046668: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 00000004666C: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 000000046670: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046678: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 00000004667C: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 000000046684: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 00000004668C: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046698: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 00000004669C: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 0000000466A4: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 0000000466B0: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000466B8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000466BC: BE882002
	s_cbranch_execz 58894                                      // 0000000466C0: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3bfc>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 0000000466C4: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000466D0: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000466D8: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000466DC: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000466E0: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000466E4: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 0000000466EC: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 0000000466F8: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000466FC: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 000000046700: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000046704: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 00000004670C: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000046714: BF870121
	v_add_f32_e32 v26, v26, v33                                // 000000046718: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 00000004671C: 7E421122
	v_exp_f32_e32 v26, v26                                     // 000000046720: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046724: BF870095
	.long 0xd71c001a                                           // 000000046728: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 00000004672C: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000046730: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000046734: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004673C: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 000000046740: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000004674C: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046750: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000046754: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 00000004675C: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046760: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 000000046764: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 00000004676C: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 000000046770: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046778: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 00000004677C: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 000000046780: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046788: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 00000004678C: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 000000046790: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046798: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 00000004679C: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000467A4: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 0000000467AC: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000467B8: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 0000000467BC: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 0000000467C4: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000467D0: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000467D8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000467DC: BE882003
	s_cbranch_execz 58825                                      // 0000000467E0: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c08>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 0000000467E4: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000467F0: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000467F8: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000467FC: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046800: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000046804: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000004680C: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 000000046818: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004681C: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 000000046820: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 00000004682C: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 000000046830: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000046834: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004683C: BF870293
	v_exp_f32_e32 v26, v26                                     // 000000046840: 7E344B1A
	.long 0xd71c001a                                           // 000000046844: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000046848: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004684C: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000046850: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000046854: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 00000004685C: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046868: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 00000004686C: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000046870: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000046878: BF870291
	v_rcp_f32_e32 v28, v27                                     // 00000004687C: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 000000046880: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000046888: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 00000004688C: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 000000046890: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 000000046898: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004689C: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 0000000468A0: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 0000000468A8: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000468AC: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 0000000468B0: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 0000000468B8: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000468C0: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000468C4: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 0000000468CC: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000468D8: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000468E0: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000468E4: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000468F0: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000468F8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000468FC: BE882004
	s_cbranch_execz 58756                                      // 000000046900: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c14>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 000000046904: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000046910: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000046918: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000004691C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046920: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000046924: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000004692C: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000046938: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004693C: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000046940: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000046944: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 00000004694C: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000046954: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000046958: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000004695C: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000046960: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046964: BF870095
	.long 0xd71c001a                                           // 000000046968: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000004696C: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000046970: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000046974: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004697C: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 000000046980: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 00000004698C: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046990: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000046994: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 00000004699C: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000469A0: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000469A4: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000469AC: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000469B0: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000469B8: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 0000000469BC: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 0000000469C0: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000469C8: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 0000000469CC: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 0000000469D0: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000469D8: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 0000000469DC: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000469E4: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 0000000469EC: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000469F8: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000469FC: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000046A04: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000046A10: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000046A18: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000046A1C: BE882005
	s_cbranch_execz 58687                                      // 000000046A20: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c20>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 000000046A24: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000046A30: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000046A38: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000046A3C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046A40: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000046A44: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000046A4C: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000046A58: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000046A5C: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000046A60: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000046A64: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000046A6C: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000046A74: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000046A78: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000046A7C: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000046A80: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046A84: BF870095
	.long 0xd71c001a                                           // 000000046A88: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000046A8C: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000046A90: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000046A94: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046A9C: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 000000046AA0: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 000000046AA8: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046AB0: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000046AB4: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000046ABC: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046AC0: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 000000046AC4: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000046ACC: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000046AD0: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046AD8: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 000000046ADC: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 000000046AE0: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046AE8: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 000000046AEC: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 000000046AF0: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046AF8: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 000000046AFC: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000046B04: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 000000046B0C: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046B18: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000046B1C: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000046B24: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000046B30: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000046B38: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000046B3C: BE882006
	s_cbranch_execz 58618                                      // 000000046B40: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c2c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 000000046B44: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000046B50: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000046B58: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000046B5C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046B60: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000046B64: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000046B6C: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000046B78: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000046B7C: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000046B80: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000046B84: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000046B8C: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000046B94: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000046B98: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000046B9C: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000046BA0: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046BA4: BF870095
	.long 0xd71c001a                                           // 000000046BA8: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000046BAC: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000046BB0: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000046BB4: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046BBC: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 000000046BC0: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000046BCC: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046BD0: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000046BD4: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000046BDC: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046BE0: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 000000046BE4: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000046BEC: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000046BF0: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046BF8: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 000000046BFC: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 000000046C00: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046C08: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 000000046C0C: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 000000046C10: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046C18: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 000000046C1C: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000046C24: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 000000046C2C: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046C38: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000046C3C: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000046C44: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000046C50: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000046C58: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000046C5C: BE882007
	s_cbranch_execz 58549                                      // 000000046C60: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c38>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 000000046C64: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000046C70: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000046C78: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000046C7C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046C80: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000046C84: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000046C8C: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000046C98: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000046C9C: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000046CA0: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000046CA4: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000046CAC: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000046CB4: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000046CB8: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000046CBC: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000046CC0: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046CC4: BF870095
	.long 0xd71c001a                                           // 000000046CC8: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000046CCC: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000046CD0: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000046CD4: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046CDC: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 000000046CE0: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000046CEC: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046CF0: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000046CF4: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000046CFC: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046D00: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 000000046D04: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000046D0C: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000046D10: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046D18: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 000000046D1C: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 000000046D20: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046D28: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 000000046D2C: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 000000046D30: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046D38: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 000000046D3C: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000046D44: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 000000046D4C: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046D58: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000046D5C: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000046D64: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000046D70: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000046D78: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000046D7C: BE882000
	s_cbranch_execz 58480                                      // 000000046D80: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c44>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 000000046D84: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 000000046D90: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 000000046D94: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 000000046D9C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000046DA0: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046DA4: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000046DA8: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000046DB0: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000046DBC: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000046DC0: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000046DC4: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000046DC8: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000046DD0: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000046DD8: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000046DDC: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000046DE0: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000046DE4: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046DE8: BF870095
	.long 0xd71c001a                                           // 000000046DEC: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000046DF0: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000046DF4: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000046DF8: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046E00: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 000000046E04: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000046E0C: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046E10: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 000000046E14: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 000000046E1C: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046E20: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 000000046E24: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 000000046E2C: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 000000046E30: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046E38: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 000000046E3C: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 000000046E40: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046E48: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 000000046E4C: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 000000046E50: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046E58: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 000000046E5C: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 000000046E64: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 000000046E6C: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046E78: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 000000046E7C: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 000000046E84: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 000000046E90: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 000000046E98: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000046E9C: BE882001
	s_cbranch_execz 58411                                      // 000000046EA0: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c50>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 000000046EA4: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 000000046EB0: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 000000046EB4: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 000000046EBC: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000046EC0: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000046EC4: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 000000046EC8: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000046ED0: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 000000046ED8: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 000000046EE4: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000046EE8: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 000000046EEC: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 000000046EF4: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000046EF8: BF870121
	v_add_f32_e32 v25, v25, v26                                // 000000046EFC: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 000000046F00: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 000000046F04: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046F08: BF870095
	.long 0xd71c0019                                           // 000000046F0C: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000046F10: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 000000046F14: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000046F18: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046F20: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 000000046F24: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000046F2C: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046F30: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 000000046F34: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 000000046F3C: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046F40: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 000000046F44: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 000000046F4C: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 000000046F50: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046F58: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 000000046F5C: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 000000046F60: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046F68: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 000000046F6C: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 000000046F70: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046F78: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 000000046F7C: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 000000046F84: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 000000046F8C: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046F98: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 000000046F9C: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 000000046FA4: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 000000046FB0: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 000000046FB8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000046FBC: BE882002
	s_cbranch_execz 58342                                      // 000000046FC0: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c5c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 000000046FC4: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000046FD0: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000046FD8: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000046FDC: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000046FE0: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000046FE4: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 000000046FEC: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 000000046FF8: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000046FFC: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 000000047000: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000047004: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 00000004700C: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047014: BF870121
	v_add_f32_e32 v18, v18, v25                                // 000000047018: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 00000004701C: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 000000047020: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047024: BF870095
	.long 0xd71c0012                                           // 000000047028: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 00000004702C: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000047030: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000047034: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004703C: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 000000047040: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000004704C: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047050: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000047054: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 00000004705C: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047060: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 000000047064: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 00000004706C: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 000000047070: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047078: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 00000004707C: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 000000047080: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047088: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 00000004708C: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 000000047090: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047098: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 00000004709C: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000470A4: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 0000000470AC: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000470B8: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 0000000470BC: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 0000000470C4: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000470D0: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000470D8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000470DC: BE882003
	s_cbranch_execz 58273                                      // 0000000470E0: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c68>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 0000000470E4: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000470F0: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000470F8: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000470FC: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047100: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000047104: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000004710C: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 000000047118: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004711C: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 000000047120: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 00000004712C: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 000000047130: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000047134: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004713C: BF870293
	v_exp_f32_e32 v18, v18                                     // 000000047140: 7E244B12
	.long 0xd71c0012                                           // 000000047144: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000047148: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004714C: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000047150: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000047154: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 00000004715C: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047168: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 00000004716C: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000047170: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000047178: BF870291
	v_rcp_f32_e32 v20, v19                                     // 00000004717C: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 000000047180: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000047188: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 00000004718C: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 000000047190: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 000000047198: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004719C: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 0000000471A0: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 0000000471A8: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000471AC: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 0000000471B0: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 0000000471B8: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000471C0: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000471C4: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 0000000471CC: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000471D8: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000471E0: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000471E4: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000471F0: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000471F8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000471FC: BE882004
	s_cbranch_execz 58204                                      // 000000047200: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c74>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 000000047204: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000047210: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000047218: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000004721C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047220: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000047224: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000004722C: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000047238: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004723C: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000047240: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000047244: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000004724C: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047254: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000047258: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000004725C: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000047260: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047264: BF870095
	.long 0xd71c0012                                           // 000000047268: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000004726C: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000047270: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000047274: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004727C: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 000000047280: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000004728C: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047290: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000047294: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000004729C: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000472A0: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000472A4: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000472AC: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000472B0: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000472B8: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 0000000472BC: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 0000000472C0: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000472C8: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 0000000472CC: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 0000000472D0: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000472D8: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 0000000472DC: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000472E4: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 0000000472EC: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000472F8: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000472FC: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000047304: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000047310: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000047318: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004731C: BE882005
	s_cbranch_execz 58135                                      // 000000047320: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c80>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 000000047324: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000047330: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000047338: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000004733C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047340: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000047344: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000004734C: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000047358: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004735C: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000047360: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000047364: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000004736C: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047374: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000047378: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000004737C: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000047380: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047384: BF870095
	.long 0xd71c0012                                           // 000000047388: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000004738C: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000047390: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000047394: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004739C: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000000473A0: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 0000000473A8: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000473B0: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000473B4: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000473BC: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000473C0: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000473C4: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000473CC: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000473D0: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000473D8: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000473DC: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 0000000473E0: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000473E8: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 0000000473EC: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 0000000473F0: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000473F8: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000473FC: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000047404: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 00000004740C: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047418: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 00000004741C: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000047424: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000047430: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000047438: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004743C: BE882006
	s_cbranch_execz 58066                                      // 000000047440: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c8c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 000000047444: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000047450: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000047458: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000004745C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047460: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000047464: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000004746C: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000047478: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004747C: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000047480: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000047484: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000004748C: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047494: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000047498: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000004749C: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000474A0: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000474A4: BF870095
	.long 0xd71c0012                                           // 0000000474A8: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000474AC: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000474B0: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000474B4: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000474BC: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 0000000474C0: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000474CC: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000474D0: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000474D4: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000474DC: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000474E0: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000474E4: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000474EC: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000474F0: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000474F8: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000474FC: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 000000047500: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047508: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 00000004750C: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 000000047510: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047518: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 00000004751C: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000047524: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 00000004752C: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047538: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 00000004753C: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000047544: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000047550: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000047558: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004755C: BE882007
	s_cbranch_execz 57997                                      // 000000047560: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c98>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 000000047564: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000047570: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000047578: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000004757C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047580: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000047584: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000004758C: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000047598: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004759C: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000475A0: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000475A4: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000475AC: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000475B4: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000475B8: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000475BC: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000475C0: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000475C4: BF870095
	.long 0xd71c0012                                           // 0000000475C8: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000475CC: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000475D0: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000475D4: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000475DC: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 0000000475E0: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000475EC: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000475F0: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000475F4: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000475FC: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047600: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000047604: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000004760C: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000047610: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047618: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 00000004761C: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 000000047620: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047628: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 00000004762C: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 000000047630: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047638: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 00000004763C: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000047644: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 00000004764C: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047658: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 00000004765C: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000047664: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000047670: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000047678: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004767C: BE882000
	s_cbranch_execz 57928                                      // 000000047680: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ca4>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 000000047684: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 000000047690: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 000000047694: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000004769C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000476A0: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000476A4: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000476A8: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000476B0: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000476BC: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000476C0: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000476C4: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000476C8: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000476D0: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000476D8: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000476DC: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000476E0: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000476E4: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000476E8: BF870095
	.long 0xd71c0012                                           // 0000000476EC: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000476F0: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000476F4: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000476F8: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047700: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 000000047704: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000004770C: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047710: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 000000047714: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 00000004771C: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047720: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 000000047724: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000004772C: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 000000047730: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047738: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 00000004773C: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 000000047740: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047748: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 00000004774C: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 000000047750: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047758: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 00000004775C: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 000000047764: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 00000004776C: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047778: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 00000004777C: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 000000047784: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 000000047790: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 000000047798: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004779C: BE882001
	s_cbranch_execz 57859                                      // 0000000477A0: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cb0>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 0000000477A4: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 0000000477B0: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 0000000477B4: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 0000000477BC: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000477C0: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000477C4: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 0000000477C8: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000477D0: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 0000000477D8: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 0000000477E4: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000477E8: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 0000000477EC: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 0000000477F4: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000477F8: BF870121
	v_add_f32_e32 v17, v17, v18                                // 0000000477FC: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 000000047800: 7E241113
	v_exp_f32_e32 v17, v17                                     // 000000047804: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047808: BF870095
	.long 0xd71c0011                                           // 00000004780C: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000047810: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000047814: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000047818: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047820: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 000000047824: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000004782C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047830: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 000000047834: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 00000004783C: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047840: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 000000047844: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 00000004784C: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 000000047850: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047858: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 00000004785C: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 000000047860: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047868: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 00000004786C: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 000000047870: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047878: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 00000004787C: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 000000047884: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 00000004788C: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047898: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 00000004789C: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 0000000478A4: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 0000000478B0: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000478B8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000478BC: BE882002
	s_cbranch_execz 57790                                      // 0000000478C0: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cbc>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 0000000478C4: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000478D0: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000478D8: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000478DC: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000478E0: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000478E4: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 0000000478EC: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 0000000478F8: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000478FC: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 000000047900: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000047904: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 00000004790C: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047914: BF870121
	v_add_f32_e32 v10, v10, v17                                // 000000047918: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 00000004791C: 7E221112
	v_exp_f32_e32 v10, v10                                     // 000000047920: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047924: BF870095
	.long 0xd71c000a                                           // 000000047928: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 00000004792C: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000047930: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000047934: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004793C: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 000000047940: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000004794C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047950: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000047954: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 00000004795C: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047960: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 000000047964: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 00000004796C: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 000000047970: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047978: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 00000004797C: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 000000047980: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047988: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 00000004798C: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 000000047990: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047998: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 00000004799C: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000479A4: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 0000000479AC: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000479B8: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 0000000479BC: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 0000000479C4: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000479D0: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000479D8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000479DC: BE882003
	s_cbranch_execz 57721                                      // 0000000479E0: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cc8>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 0000000479E4: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000479F0: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000479F8: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000479FC: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047A00: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000047A04: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000047A0C: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 000000047A18: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047A1C: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 000000047A20: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 000000047A2C: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 000000047A30: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000047A34: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000047A3C: BF870293
	v_exp_f32_e32 v10, v10                                     // 000000047A40: 7E144B0A
	.long 0xd71c000a                                           // 000000047A44: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000047A48: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047A4C: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000047A50: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000047A54: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 000000047A5C: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047A68: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 000000047A6C: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000047A70: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000047A78: BF870291
	v_rcp_f32_e32 v12, v11                                     // 000000047A7C: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 000000047A80: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000047A88: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 000000047A8C: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 000000047A90: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 000000047A98: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047A9C: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 000000047AA0: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 000000047AA8: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047AAC: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 000000047AB0: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 000000047AB8: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047AC0: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000047AC4: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 000000047ACC: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 000000047AD8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000047AE0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000047AE4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000047AF0: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000047AF8: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000047AFC: BE882004
	s_cbranch_execz 57652                                      // 000000047B00: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cd4>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 000000047B04: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000047B10: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000047B18: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000047B1C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047B20: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000047B24: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000047B2C: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000047B38: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000047B3C: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000047B40: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000047B44: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000047B4C: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047B54: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000047B58: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000047B5C: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000047B60: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047B64: BF870095
	.long 0xd71c000a                                           // 000000047B68: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000047B6C: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000047B70: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000047B74: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047B7C: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 000000047B80: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000047B8C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047B90: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000047B94: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000047B9C: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047BA0: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000047BA4: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000047BAC: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000047BB0: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047BB8: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 000000047BBC: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 000000047BC0: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047BC8: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 000000047BCC: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 000000047BD0: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047BD8: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 000000047BDC: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000047BE4: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 000000047BEC: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047BF8: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000047BFC: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000047C04: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000047C10: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000047C18: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000047C1C: BE882005
	s_cbranch_execz 57583                                      // 000000047C20: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ce0>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 000000047C24: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000047C30: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000047C38: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000047C3C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047C40: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000047C44: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000047C4C: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000047C58: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000047C5C: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000047C60: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000047C64: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000047C6C: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047C74: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000047C78: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000047C7C: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000047C80: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047C84: BF870095
	.long 0xd71c000a                                           // 000000047C88: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000047C8C: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000047C90: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000047C94: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047C9C: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 000000047CA0: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 000000047CA8: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047CB0: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000047CB4: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000047CBC: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047CC0: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000047CC4: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000047CCC: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000047CD0: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047CD8: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000047CDC: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 000000047CE0: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047CE8: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 000000047CEC: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 000000047CF0: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047CF8: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000047CFC: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000047D04: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 000000047D0C: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047D18: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000047D1C: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000047D24: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000047D30: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000047D38: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000047D3C: BE882006
	s_cbranch_execz 57514                                      // 000000047D40: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cec>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 000000047D44: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000047D50: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000047D58: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000047D5C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047D60: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000047D64: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000047D6C: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000047D78: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000047D7C: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000047D80: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000047D84: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000047D8C: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047D94: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000047D98: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000047D9C: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000047DA0: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047DA4: BF870095
	.long 0xd71c000a                                           // 000000047DA8: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000047DAC: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000047DB0: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000047DB4: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047DBC: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 000000047DC0: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000047DCC: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047DD0: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000047DD4: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000047DDC: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047DE0: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000047DE4: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000047DEC: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000047DF0: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047DF8: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000047DFC: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 000000047E00: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047E08: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 000000047E0C: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 000000047E10: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047E18: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000047E1C: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000047E24: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 000000047E2C: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047E38: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000047E3C: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000047E44: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000047E50: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000047E58: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000047E5C: BE882007
	s_cbranch_execz 57445                                      // 000000047E60: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cf8>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 000000047E64: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000047E70: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000047E78: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000047E7C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047E80: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000047E84: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000047E8C: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000047E98: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000047E9C: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000047EA0: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000047EA4: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000047EAC: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047EB4: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000047EB8: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000047EBC: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000047EC0: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047EC4: BF870095
	.long 0xd71c000a                                           // 000000047EC8: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000047ECC: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000047ED0: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000047ED4: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047EDC: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 000000047EE0: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000047EEC: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047EF0: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000047EF4: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000047EFC: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047F00: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000047F04: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000047F0C: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000047F10: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047F18: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000047F1C: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 000000047F20: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047F28: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 000000047F2C: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 000000047F30: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047F38: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000047F3C: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000047F44: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 000000047F4C: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047F58: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000047F5C: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000047F64: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000047F70: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000047F78: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000047F7C: BE882000
	s_cbranch_execz 57376                                      // 000000047F80: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d04>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 000000047F84: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 000000047F90: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 000000047F94: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000047F9C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000047FA0: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047FA4: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000047FA8: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000047FB0: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000047FBC: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000047FC0: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000047FC4: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000047FC8: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000047FD0: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000047FD8: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000047FDC: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000047FE0: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000047FE4: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000047FE8: BF870095
	.long 0xd71c000a                                           // 000000047FEC: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000047FF0: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000047FF4: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000047FF8: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048000: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 000000048004: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000004800C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048010: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 000000048014: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 00000004801C: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048020: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 000000048024: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 00000004802C: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 000000048030: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048038: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 00000004803C: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 000000048040: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048048: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 00000004804C: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 000000048050: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048058: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 00000004805C: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 000000048064: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 00000004806C: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048078: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 00000004807C: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 000000048084: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 000000048090: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 000000048098: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 00000004809C: BE802001
	s_cbranch_execz 57307                                      // 0000000480A0: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d10>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 0000000480A4: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000480B0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000480B8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000480BC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000480C0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000480C4: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 0000000480CC: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 0000000480D8: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000480DC: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 0000000480E0: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 0000000480E4: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000480EC: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000480F4: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 0000000480F8: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 0000000480FC: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 000000048100: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048104: BF870095
	.long 0xd71c0001                                           // 000000048108: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 00000004810C: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000048110: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000048114: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004811C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 000000048120: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000004812C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048130: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000048134: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 00000004813C: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048140: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 000000048144: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 00000004814C: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 000000048150: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048158: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 00000004815C: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 000000048160: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048168: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 00000004816C: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 000000048170: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048178: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 00000004817C: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000048184: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 00000004818C: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048198: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 00000004819C: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 0000000481A4: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000481B0: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000481B8: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 0000000481BC: BE802002
	s_cbranch_execz 57238                                      // 0000000481C0: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d1c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 0000000481C4: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000481D0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000481D8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000481DC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000481E0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000481E4: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000481EC: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 0000000481F8: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000481FC: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 000000048200: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000048204: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000004820C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000048214: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000048218: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 00000004821C: 7E041109
	v_exp_f32_e32 v1, v1                                       // 000000048220: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048224: BF870095
	.long 0xd71c0001                                           // 000000048228: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000004822C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000048230: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000048234: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004823C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 000000048240: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000004824C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048250: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000048254: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000004825C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048260: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 000000048264: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 00000004826C: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 000000048270: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048278: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 00000004827C: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 000000048280: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048288: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 00000004828C: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 000000048290: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048298: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 00000004829C: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000482A4: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 0000000482AC: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000482B8: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000482BC: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000482C4: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000482D0: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000482D8: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 0000000482DC: BE802003
	s_cbranch_execz 57169                                      // 0000000482E0: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d28>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 0000000482E4: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000482F0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000482F8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000482FC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048300: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000048304: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000004830C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000048318: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004831C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000048320: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000048324: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000004832C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000048334: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000048338: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000004833C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000048340: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048344: BF870095
	.long 0xd71c0001                                           // 000000048348: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000004834C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000048350: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000048354: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004835C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 000000048360: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000004836C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048370: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000048374: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000004837C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048380: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000048384: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000004838C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000048390: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048398: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 00000004839C: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 0000000483A0: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000483A8: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 0000000483AC: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 0000000483B0: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000483B8: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 0000000483BC: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000483C4: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 0000000483CC: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000483D8: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000483DC: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000483E4: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000483F0: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000483F8: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000000483FC: BE802004
	s_cbranch_execz 57100                                      // 000000048400: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d34>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 000000048404: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000048410: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000048418: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000004841C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048420: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000048424: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000004842C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000048438: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004843C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000048440: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000048444: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000004844C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000048454: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000048458: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000004845C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000048460: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048464: BF870095
	.long 0xd71c0001                                           // 000000048468: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000004846C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000048470: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000048474: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004847C: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 000000048480: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 000000048488: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048490: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000048494: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000004849C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000484A0: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000484A4: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000484AC: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000484B0: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000484B8: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000484BC: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 0000000484C0: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000484C8: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 0000000484CC: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000484D0: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000484D8: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000484DC: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000484E4: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 0000000484EC: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000484F8: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000484FC: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000048504: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000048510: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000048518: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000004851C: BE802005
	s_cbranch_execz 57031                                      // 000000048520: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d40>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 000000048524: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000048530: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000048538: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000004853C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048540: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000048544: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000004854C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000048558: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004855C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000048560: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000048564: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000004856C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000048574: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000048578: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000004857C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000048580: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048584: BF870095
	.long 0xd71c0001                                           // 000000048588: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000004858C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000048590: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000048594: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004859C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 0000000485A0: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000485AC: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000485B0: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000485B4: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000485BC: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000485C0: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000485C4: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000485CC: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000485D0: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000485D8: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000485DC: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000485E0: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000485E8: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000485EC: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000485F0: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000485F8: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000485FC: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000048604: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 00000004860C: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048618: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000004861C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000048624: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000048630: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000048638: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000004863C: BE802006
	s_cbranch_execz 56962                                      // 000000048640: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d4c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 000000048644: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000048650: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000048658: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000004865C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048660: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000048664: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000004866C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000048678: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004867C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000048680: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000048684: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000004868C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000048694: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000048698: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000004869C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000486A0: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000486A4: BF870095
	.long 0xd71c0001                                           // 0000000486A8: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000486AC: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000486B0: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000486B4: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000486BC: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 0000000486C0: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000486CC: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000486D0: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000486D4: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000486DC: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000486E0: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000486E4: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000486EC: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000486F0: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000486F8: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000486FC: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 000000048700: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048708: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000004870C: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 000000048710: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048718: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000004871C: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000048724: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 00000004872C: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048738: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000004873C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000048744: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000048750: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000048758: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000004875C: BE802007
	s_cbranch_execz 56893                                      // 000000048760: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi1ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d58>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 000000048764: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000048770: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000048778: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000004877C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048780: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000048784: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000004878C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000048798: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004879C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000487A0: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000487A4: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000487AC: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000487B4: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000487B8: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000487BC: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000487C0: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000487C4: BF870095
	.long 0xd71c0001                                           // 0000000487C8: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000487CC: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000487D0: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000487D4: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000487DC: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 0000000487E0: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000487EC: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000487F0: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000487F4: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000487FC: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048800: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000048804: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000004880C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000048810: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048818: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000004881C: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 000000048820: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048828: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000004882C: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 000000048830: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048838: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000004883C: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000048844: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 00000004884C: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048858: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000004885C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000048864: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000048870: DC9601E0 007C0200
	s_nop 0                                                    // 000000048878: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000004887C: BFB60003
	s_endpgm                                                   // 000000048880: BFB00000
		...

