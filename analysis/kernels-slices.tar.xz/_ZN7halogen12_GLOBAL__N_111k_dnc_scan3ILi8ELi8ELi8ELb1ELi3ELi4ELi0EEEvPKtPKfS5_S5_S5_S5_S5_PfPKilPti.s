000000000008a400 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 00000008A400: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 00000008A404: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000008A40C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 00000008A414: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 00000008A418: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000008A41C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 00000008A420: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000008A428: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000008A42C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 00000008A430: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 00000008A434: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000008A43C: 84928214
	s_add_u32 s25, s16, s18                                    // 00000008A440: 80191210
	s_addc_u32 s28, s17, s19                                   // 00000008A444: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 00000008A448: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000008A44C: BF870009
	s_add_u32 s25, s25, s20                                    // 00000008A450: 80191419
	s_addc_u32 s30, s28, s21                                   // 00000008A454: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 00000008A458: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000008A45C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 00000008A464: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000008A46C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 00000008A470: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 00000008A474: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000008A478: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000008A47C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 00000008A480: 821E191E
	.long 0xd7001f02                                           // 00000008A484: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 00000008A488: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000008A48C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 00000008A494: BE9E0080
	s_nop 0                                                    // 00000008A498: BF800000
	s_nop 0                                                    // 00000008A49C: BF800000
	s_nop 0                                                    // 00000008A4A0: BF800000
	s_nop 0                                                    // 00000008A4A4: BF800000
	s_nop 0                                                    // 00000008A4A8: BF800000
	s_nop 0                                                    // 00000008A4AC: BF800000
	s_nop 0                                                    // 00000008A4B0: BF800000
	s_nop 0                                                    // 00000008A4B4: BF800000
	s_nop 0                                                    // 00000008A4B8: BF800000
	s_nop 0                                                    // 00000008A4BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 00000008A4C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 00000008A4C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008A4CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 00000008A4D0: 300C1089
	.long 0xd7006a06                                           // 00000008A4D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000008A4D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008A4DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 00000008A4E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000008A4E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 00000008A4F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 00000008A4F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 00000008A4FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 00000008A508: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000008A50C: BF8903F7
	ds_store_b32 v6, v9                                        // 00000008A510: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 00000008A518: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000008A51C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 00000008A520: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 00000008A524: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 00000008A52C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 00000008A534: 32040084
	s_mov_b32 s0, 0                                            // 00000008A538: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000008A53C: BF89FC07
	s_barrier                                                  // 00000008A540: BFBD0000
	buffer_gl0_inv                                             // 00000008A544: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000008A54C: BF02801E
	s_cbranch_scc1 12                                          // 00000008A550: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 00000008A554: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000008A55C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 00000008A564: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 00000008A568: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 00000008A570: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000008A574: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000008A578: 916A007E
	s_cbranch_vccz 2                                           // 00000008A57C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2632                                              // 00000008A580: BFA00A48 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2aa4>
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000008A584: 304E0A82
	s_add_i32 s0, s30, 63                                      // 00000008A588: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000008A58C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 00000008A594: 85218600
	s_add_u32 s34, s10, s24                                    // 00000008A598: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000008A59C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 00000008A5A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 00000008A5A4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 00000008A5AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 00000008A5B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000008A5B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 00000008A5B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 00000008A5BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 00000008A5C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 00000008A5C4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 00000008A5C8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 00000008A5D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 00000008A5D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 00000008A5DC: B00A0204
	.long 0xd7000b2c                                           // 00000008A5E0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 00000008A5E4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000008A5E8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 00000008A5EC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 00000008A5F4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 00000008A600: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 00000008A604: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 00000008A610: 3816500A
	.long 0xd7000a05                                           // 00000008A614: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 00000008A618: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000008A61C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 00000008A620: D5207C06 00290001
	.long 0xd7000107                                           // 00000008A628: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 00000008A62C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008A630: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 00000008A634: D5207C08 0006180D
	.long 0xd7000109                                           // 00000008A63C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 00000008A640: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 00000008A644: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 00000008A64C: 84848E02
	.long 0xd700010b                                           // 00000008A650: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 00000008A654: 02021606
	s_add_u32 s4, s14, s4                                      // 00000008A658: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 00000008A65C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 00000008A664: 8205050F
	.long 0xd700010d                                           // 00000008A668: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 00000008A66C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008A670: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 00000008A674: D5207C0E 00050005
	.long 0xd700010f                                           // 00000008A67C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 00000008A680: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 00000008A688: D5207C10 00061880
	.long 0xd7000111                                           // 00000008A690: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 00000008A694: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008A69C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 00000008A6A0: D5207C12 00061880
	.long 0xd7000113                                           // 00000008A6A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 00000008A6AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 00000008A6B4: D5207C14 00061880
	.long 0xd7000115                                           // 00000008A6BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 00000008A6C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008A6C8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 00000008A6CC: D5207C16 00061880
	.long 0xd7000117                                           // 00000008A6D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 00000008A6D8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 00000008A6E0: D5207C18 00061880
	.long 0xd7000119                                           // 00000008A6E8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 00000008A6EC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008A6F4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 00000008A6F8: D5207C1A 00061880
	.long 0xd700011b                                           // 00000008A700: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 00000008A704: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 00000008A70C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 00000008A714: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000008A718: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 00000008A720: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 00000008A724: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 00000008A72C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 00000008A734: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 00000008A73C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 00000008A744: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 00000008A74C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 00000008A754: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 00000008A75C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 00000008A764: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 00000008A76C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 00000008A774: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 00000008A77C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 00000008A784: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 00000008A78C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 00000008A794: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 00000008A79C: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 00000008A7A0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 00000008A7A4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000008A7AC: BF870499
	s_add_i32 s6, s31, s1                                      // 00000008A7B0: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 00000008A7B4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000008A7B8: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 00000008A7BC: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 00000008A7C0: 84078605
	s_add_u32 s10, s8, s10                                     // 00000008A7C4: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 00000008A7C8: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 00000008A7CC: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 00000008A7D4: BE84206A
	s_cbranch_execz 77                                         // 00000008A7D8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510>
	v_or_b32_e32 v29, s7, v0                                   // 00000008A7DC: 383A0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008A7E0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 00000008A7E4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 00000008A7EC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008A7F0: BF870091
	.long 0xd73c001d                                           // 00000008A7F4: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 00000008A7F8: 02023A82
	.long 0xd700011d                                           // 00000008A7FC: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 00000008A800: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000008A804: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 00000008A808: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 00000008A810: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000008A818: BF890007
	v_sub_f32_e32 v30, s6, v29                                 // 00000008A81C: 083C3A06
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 00000008A820: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000008A82C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 00000008A830: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 00000008A83C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 00000008A840: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 00000008A84C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000008A850: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 00000008A854: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 00000008A860: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008A864: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 00000008A868: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 00000008A870: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 00000008A874: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 00000008A87C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 00000008A884: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 00000008A888: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000008A88C: BF870193
	v_exp_f32_e32 v32, v32                                     // 00000008A890: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 00000008A894: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000008A898: BF870296
	.long 0xd71c0020                                           // 00000008A89C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 00000008A8A0: 02024520
	.long 0xd71c001f                                           // 00000008A8A4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 00000008A8A8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008A8AC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 00000008A8B0: D501001F 00063E80
	.long 0xd41b0001                                           // 00000008A8B8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 00000008A8BC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 00000008A8C4: D5010020 00064080
	.long 0xd41e0001                                           // 00000008A8CC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 00000008A8D0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008A8D8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 00000008A8DC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 00000008A8E8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 00000008A8EC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 00000008A8F4: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 00000008A900: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 00000008A908: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008A910: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 00000008A914: CA100108 1E1C0107
	s_mov_b32 s10, 0                                           // 00000008A91C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000008A920: BF89FC07
	s_barrier                                                  // 00000008A924: BFBD0000
	buffer_gl0_inv                                             // 00000008A928: E0AC0000 00000000
	s_branch 15                                                // 00000008A930: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008A934: 8C7E047E
	.long 0xd700011d                                           // 00000008A938: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 00000008A93C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008A944: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000008A948: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 00000008A950: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000008A954: BF08B70A
	s_mov_b32 s10, s1                                          // 00000008A958: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 00000008A95C: BF89FC07
	s_barrier                                                  // 00000008A960: BFBD0000
	buffer_gl0_inv                                             // 00000008A964: E0AC0000 00000000
	s_cbranch_scc1 706                                         // 00000008A96C: BFA202C2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 00000008A970: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 00000008A978: CA100128 21220126
	s_mov_b32 s11, 0                                           // 00000008A980: BE8B0080
	s_nop 0                                                    // 00000008A984: BF800000
	s_nop 0                                                    // 00000008A988: BF800000
	s_nop 0                                                    // 00000008A98C: BF800000
	s_nop 0                                                    // 00000008A990: BF800000
	s_nop 0                                                    // 00000008A994: BF800000
	s_nop 0                                                    // 00000008A998: BF800000
	s_nop 0                                                    // 00000008A99C: BF800000
	s_nop 0                                                    // 00000008A9A0: BF800000
	s_nop 0                                                    // 00000008A9A4: BF800000
	s_nop 0                                                    // 00000008A9A8: BF800000
	s_nop 0                                                    // 00000008A9AC: BF800000
	s_nop 0                                                    // 00000008A9B0: BF800000
	s_nop 0                                                    // 00000008A9B4: BF800000
	s_nop 0                                                    // 00000008A9B8: BF800000
	s_nop 0                                                    // 00000008A9BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 00000008A9C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 00000008A9C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 00000008A9D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 00000008A9D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000008A9DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 00000008A9E0: D5207C20 00064080
	.long 0xd4490004                                           // 00000008A9E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 00000008A9EC: 020244FF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000008A9F4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000008A9F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 00000008A9FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 00000008AA04: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000008AA0C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000008AA10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000008AA14: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000008AA18: BF89FC07
	s_barrier                                                  // 00000008AA1C: BFBD0000
	buffer_gl0_inv                                             // 00000008AA20: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000008AA28: BE842000
	s_cbranch_execz 65473                                      // 00000008AA2C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 00000008AA30: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 00000008AA38: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 00000008AA40: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 00000008AA48: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 00000008AA50: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 00000008AA58: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 00000008AA60: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 00000008AA68: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v46 offset0:14 offset1:15      // 00000008AA70: D8DC0F0E 4800002E
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 00000008AA78: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 00000008AA80: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 00000008AA88: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 00000008AA90: D8DCFFEE 50000001
	v_or3_b32 v70, s10, s7, v2                                 // 00000008AA98: D6580046 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AAA0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 00000008AAA4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 00000008AAAC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 00000008AAB0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AAB4: BF870091
	.long 0xd7000146                                           // 00000008AAB8: D7000146
	v_cndmask_b32_e32 v1, v44, v70, vcc_lo                     // 00000008AABC: 02028D2C
	v_add_co_ci_u32_e64 v71, null, v45, v71, s1                // 00000008AAC0: D5207C47 00068F2D
	global_load_b32 v70, v[70:71], off                         // 00000008AAC8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 00000008AAD0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 00000008AAD4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008AADC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 00000008AAE0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 00000008AAE8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 00000008AAEC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 00000008AAF4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:10 offset1:11      // 00000008AAFC: D8DC0B0A 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:12 offset1:13      // 00000008AB04: D8DC0D0C 4600002E
	v_fma_f32 v33, -v34, v65, v33                              // 00000008AB0C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 00000008AB14: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AB18: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 00000008AB1C: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 00000008AB24: D6130021 24868724
	s_waitcnt lgkmcnt(8)                                       // 00000008AB2C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AB30: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 00000008AB34: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 00000008AB3C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 00000008AB44: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AB48: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 00000008AB4C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 00000008AB54: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 00000008AB5C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008AB60: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000008AB64: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 00000008AB6C: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 00000008AB74: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 00000008AB7C: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 00000008AB84: D8DC1716 3C00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:16 offset1:33      // 00000008AB8C: D8DC2110 40000030
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 00000008AB94: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:84 offset1:101     // 00000008AB9C: D8DC6554 44000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 00000008ABA4: D8DC8776 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 00000008ABAC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 00000008ABB4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008ABB8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 00000008ABBC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 00000008ABC4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008ABCC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 00000008ABD0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 00000008ABD8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 00000008ABE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008ABE4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 00000008ABE8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 00000008ABF0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 00000008ABF8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008ABFC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 00000008AC00: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 00000008AC08: D8DC1918 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 00000008AC10: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 00000008AC18: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 00000008AC20: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:152 offset1:169    // 00000008AC28: D8DCA998 48000030
	ds_load_2addr_b32 v[76:77], v48 offset0:186 offset1:203    // 00000008AC30: D8DCCBBA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:220 offset1:237    // 00000008AC38: D8DCEDDC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:126 offset1:143    // 00000008AC40: D8DC8F7E 50000031
	v_fma_f32 v33, -v34, v67, v33                              // 00000008AC48: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 00000008AC50: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AC54: BF870091
	v_fma_f32 v33, -v35, v68, v33                              // 00000008AC58: D6130021 24868923
	v_fma_f32 v33, -v36, v69, v33                              // 00000008AC60: D6130021 24868B24
	s_waitcnt lgkmcnt(8)                                       // 00000008AC68: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AC6C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000008AC70: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000008AC78: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000008AC80: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AC84: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 00000008AC88: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 00000008AC90: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 00000008AC98: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008AC9C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000008ACA0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 00000008ACA8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 00000008ACB0: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 00000008ACB8: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 00000008ACC0: D8DC2726 3C00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 00000008ACC8: D8DC3120 42000032
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 00000008ACD0: D8DC5342 44000032
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 00000008ACD8: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 00000008ACE0: D8DC9786 4A000032
	v_fma_f32 v62, -v63, v77, v62                              // 00000008ACE8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000008ACF0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008ACF4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000008ACF8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000008AD00: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000008AD08: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AD0C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 00000008AD10: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 00000008AD18: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 00000008AD20: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AD24: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 00000008AD28: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 00000008AD30: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 00000008AD38: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008AD3C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 00000008AD40: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 00000008AD48: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 00000008AD50: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:44 offset1:45      // 00000008AD58: D8DC2D2C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:46 offset1:47      // 00000008AD60: D8DC2F2E 4200002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 00000008AD68: D8DCB9A8 46000032
	ds_load_2addr_b32 v[76:77], v50 offset0:202 offset1:219    // 00000008AD70: D8DCDBCA 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:236 offset1:253    // 00000008AD78: D8DCFDEC 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:14 offset1:31      // 00000008AD80: D8DC1F0E 50000033
	v_fma_f32 v33, -v34, v69, v33                              // 00000008AD88: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 00000008AD90: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AD94: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000008AD98: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000008ADA0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000008ADA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008ADAC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000008ADB0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000008ADB8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000008ADC0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008ADC4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 00000008ADC8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 00000008ADD0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 00000008ADD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008ADDC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000008ADE0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 00000008ADE8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 00000008ADF0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 00000008ADF8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 00000008AE00: D8DC3736 3C00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:48 offset1:65      // 00000008AE08: D8DC4130 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:82 offset1:99      // 00000008AE10: D8DC6352 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 00000008AE18: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 00000008AE20: D8DCA796 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 00000008AE28: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000008AE30: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AE34: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000008AE38: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000008AE40: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000008AE48: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AE4C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 00000008AE50: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 00000008AE58: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 00000008AE60: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AE64: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 00000008AE68: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000008AE70: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000008AE78: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008AE7C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 00000008AE80: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 00000008AE88: D8DC3938 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:58 offset1:59      // 00000008AE90: D8DC3B3A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:60 offset1:61      // 00000008AE98: D8DC3D3C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:62 offset1:63      // 00000008AEA0: D8DC3F3E 4200002E
	ds_load_2addr_b32 v[68:69], v51 offset0:184 offset1:201    // 00000008AEA8: D8DCC9B8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:218 offset1:235    // 00000008AEB0: D8DCEBDA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:124 offset1:141    // 00000008AEB8: D8DC8D7C 4E000034
	ds_load_2addr_b32 v[80:81], v53 offset0:30 offset1:47      // 00000008AEC0: D8DC2F1E 50000035
	v_fma_f32 v33, -v34, v71, v33                              // 00000008AEC8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 00000008AED0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AED4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000008AED8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000008AEE0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000008AEE8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AEEC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000008AEF0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000008AEF8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000008AF00: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AF04: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 00000008AF08: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000008AF10: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000008AF18: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008AF1C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000008AF20: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 00000008AF28: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 00000008AF30: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 00000008AF38: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 00000008AF40: D8DC4746 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:64 offset1:81      // 00000008AF48: D8DC5140 44000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 00000008AF50: D8DC7362 46000035
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 00000008AF58: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 00000008AF60: D8DCB7A6 4A000035
	v_fma_f32 v62, -v63, v77, v62                              // 00000008AF68: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000008AF70: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AF74: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000008AF78: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000008AF80: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000008AF88: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AF8C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 00000008AF90: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 00000008AF98: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 00000008AFA0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008AFA4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 00000008AFA8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000008AFB0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000008AFB8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008AFBC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 00000008AFC0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 00000008AFC8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 00000008AFD0: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 00000008AFD8: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:78 offset1:79      // 00000008AFE0: D8DC4F4E 4200002E
	ds_load_2addr_b32 v[68:69], v53 offset0:200 offset1:217    // 00000008AFE8: D8DCD9C8 44000035
	ds_load_2addr_b32 v[76:77], v53 offset0:234 offset1:251    // 00000008AFF0: D8DCFBEA 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:12 offset1:29      // 00000008AFF8: D8DC1D0C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:46 offset1:63      // 00000008B000: D8DC3F2E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 00000008B008: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 00000008B010: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B014: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000008B018: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000008B020: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000008B028: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B02C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000008B030: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000008B038: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000008B040: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B044: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 00000008B048: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000008B050: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000008B058: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008B05C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000008B060: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 00000008B068: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 00000008B070: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 00000008B078: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 00000008B080: D8DC5756 3C00002E
	ds_load_2addr_b32 v[68:69], v54 offset0:80 offset1:97      // 00000008B088: D8DC6150 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 00000008B090: D8DC8372 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 00000008B098: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 00000008B0A0: D8DCC7B6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 00000008B0A8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000008B0B0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B0B4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000008B0B8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000008B0C0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000008B0C8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B0CC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 00000008B0D0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 00000008B0D8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 00000008B0E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B0E4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 00000008B0E8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000008B0F0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000008B0F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008B0FC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 00000008B100: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 00000008B108: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 00000008B110: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:92 offset1:93      // 00000008B118: D8DC5D5C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:94 offset1:95      // 00000008B120: D8DC5F5E 4200002E
	ds_load_2addr_b32 v[68:69], v54 offset0:216 offset1:233    // 00000008B128: D8DCE9D8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:122 offset1:139    // 00000008B130: D8DC8B7A 4C000037
	ds_load_2addr_b32 v[78:79], v56 offset0:28 offset1:45      // 00000008B138: D8DC2D1C 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:62 offset1:79      // 00000008B140: D8DC4F3E 50000038
	v_fma_f32 v33, -v34, v71, v33                              // 00000008B148: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 00000008B150: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B154: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000008B158: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000008B160: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000008B168: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B16C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000008B170: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000008B178: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000008B180: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B184: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 00000008B188: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000008B190: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000008B198: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008B19C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000008B1A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 00000008B1A8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 00000008B1B0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 00000008B1B8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 00000008B1C0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:96 offset1:113     // 00000008B1C8: D8DC7160 44000038
	ds_load_2addr_b32 v[70:71], v56 offset0:130 offset1:147    // 00000008B1D0: D8DC9382 46000038
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 00000008B1D8: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 00000008B1E0: D8DCD7C6 4A000038
	v_fma_f32 v62, -v63, v77, v62                              // 00000008B1E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000008B1F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B1F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000008B1F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000008B200: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000008B208: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B20C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 00000008B210: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 00000008B218: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 00000008B220: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B224: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 00000008B228: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000008B230: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000008B238: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008B23C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 00000008B240: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 00000008B248: D8DC6968 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:106 offset1:107    // 00000008B250: D8DC6B6A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:108 offset1:109    // 00000008B258: D8DC6D6C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:110 offset1:111    // 00000008B260: D8DC6F6E 4200002E
	ds_load_2addr_b32 v[68:69], v56 offset0:232 offset1:249    // 00000008B268: D8DCF9E8 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:10 offset1:27      // 00000008B270: D8DC1B0A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:44 offset1:61      // 00000008B278: D8DC3D2C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:78 offset1:95      // 00000008B280: D8DC5F4E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 00000008B288: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 00000008B290: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B294: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000008B298: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000008B2A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000008B2A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B2AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000008B2B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000008B2B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000008B2C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B2C4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 00000008B2C8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000008B2D0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000008B2D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008B2DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000008B2E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 00000008B2E8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 00000008B2F0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 00000008B2F8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 00000008B300: D8DC7776 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 00000008B308: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 00000008B310: D8DCA392 46000039
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 00000008B318: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 00000008B320: D8DCE7D6 4A000039
	v_fma_f32 v62, -v63, v77, v62                              // 00000008B328: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000008B330: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B334: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000008B338: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000008B340: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000008B348: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B34C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 00000008B350: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 00000008B358: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 00000008B360: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B364: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 00000008B368: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000008B370: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000008B378: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008B37C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 00000008B380: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 00000008B388: D8DC7978 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 00000008B390: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 00000008B398: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:126 offset1:127    // 00000008B3A0: D8DC7F7E 4200002E
	ds_load_2addr_b32 v[68:69], v58 offset0:120 offset1:137    // 00000008B3A8: D8DC8978 4400003A
	ds_load_2addr_b32 v[76:77], v59 offset0:26 offset1:43      // 00000008B3B0: D8DC2B1A 4C00003B
	ds_load_2addr_b32 v[78:79], v59 offset0:60 offset1:77      // 00000008B3B8: D8DC4D3C 4E00003B
	ds_load_2addr_b32 v[80:81], v59 offset0:94 offset1:111     // 00000008B3C0: D8DC6F5E 5000003B
	v_fma_f32 v33, -v34, v71, v33                              // 00000008B3C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 00000008B3D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B3D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000008B3D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000008B3E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000008B3E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B3EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000008B3F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000008B3F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000008B400: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B404: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 00000008B408: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000008B410: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000008B418: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B41C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 00000008B420: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 00000008B428: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 00000008B430: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B434: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 00000008B438: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 00000008B440: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 00000008B448: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008B44C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 00000008B450: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s10, v[4:5]            // 00000008B458: D6FE7C1F 041014FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 00000008B464: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 00000008B46C: D8340000 0000201F
	s_branch 64815                                             // 00000008B474: BFA0FD2F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_mov_b32_e32 v30, v14                                     // 00000008B478: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 00000008B47C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 00000008B484: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 00000008B488: 7E46032B
	s_mov_b32 s10, 0                                           // 00000008B48C: BE8A0080
	s_branch 21                                                // 00000008B490: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000008B494: 8C7E0B7E
	.long 0xd700011f                                           // 00000008B498: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 00000008B49C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008B4A4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 00000008B4A8: D5207C20 00064080
	.long 0xd700011d                                           // 00000008B4B0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 00000008B4B4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 00000008B4BC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000008B4C0: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 00000008B4C8: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000008B4CC: BF08B70A
	s_mov_b32 s10, s1                                          // 00000008B4D0: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 00000008B4D4: BC7C0000
	s_barrier                                                  // 00000008B4D8: BFBD0000
	buffer_gl0_inv                                             // 00000008B4DC: E0AC0000 00000000
	s_cbranch_scc1 627                                         // 00000008B4E4: BFA20273 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ab4>
	s_delay_alu instid0(VALU_DEP_2)                            // 00000008B4E8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 00000008B4EC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 00000008B4F4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 00000008B4F8: 7E780326
	s_mov_b32 s11, 0                                           // 00000008B4FC: BE8B0080
	global_load_b32 v61, v[33:34], off                         // 00000008B500: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 00000008B508: 4A7878FF 00000080
	.long 0xd7000121                                           // 00000008B510: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 00000008B514: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000008B51C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 00000008B520: D5207C22 00064480
	.long 0xd4490004                                           // 00000008B528: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 00000008B52C: 020278FF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000008B534: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000008B538: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 00000008B53C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 00000008B544: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000008B54C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000008B550: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000008B554: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000008B558: BF89FC07
	s_barrier                                                  // 00000008B55C: BFBD0000
	buffer_gl0_inv                                             // 00000008B560: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 00000008B568: BE8B2000
	s_cbranch_execz 65481                                      // 00000008B56C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s10, v2                                  // 00000008B570: 3842040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008B574: BF870091
	v_or_b32_e32 v36, s7, v33                                  // 00000008B578: 38484207
	.long 0xd4440001                                           // 00000008B57C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 00000008B580: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 00000008B584: 8B7E017E
	s_cbranch_execz 65474                                      // 00000008B588: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 00000008B58C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 00000008B594: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:2 offset1:3        // 00000008B59C: D8DC0302 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 00000008B5A4: D8DC3322 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:4 offset1:5        // 00000008B5AC: D8DC0504 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:6 offset1:7        // 00000008B5B4: D8DC0706 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 00000008B5BC: D8DC5544 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:102 offset1:119     // 00000008B5C4: D8DC7766 4A000001
	s_mov_b32 s12, 0                                           // 00000008B5CC: BE8C0080
	s_waitcnt lgkmcnt(6)                                       // 00000008B5D0: BF89FC67
	v_fma_f32 v76, v60, v62, 0                                 // 00000008B5D4: D613004C 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B5DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000008B5E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000008B5E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000008B5E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B5EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000008B5F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000008B5F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000008B5F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B5FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000008B600: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000008B604: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000008B608: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008B60C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000008B610: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:8 offset1:9        // 00000008B614: D8DC0908 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 00000008B61C: D8DC9988 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:10 offset1:11      // 00000008B624: D8DC0B0A 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:170 offset1:187     // 00000008B62C: D8DCBBAA 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:12 offset1:13      // 00000008B634: D8DC0D0C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:14 offset1:15      // 00000008B63C: D8DC0F0E 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 00000008B644: D8DCDDCC 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:238 offset1:255     // 00000008B64C: D8DCFFEE 4A000001
	s_waitcnt lgkmcnt(6)                                       // 00000008B654: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000008B658: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B65C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000008B660: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000008B664: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000008B668: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B66C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000008B670: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000008B674: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000008B678: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B67C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000008B680: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000008B684: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000008B688: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008B68C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000008B690: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:16 offset1:17      // 00000008B694: D8DC1110 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:16 offset1:33      // 00000008B69C: D8DC2110 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:18 offset1:19      // 00000008B6A4: D8DC1312 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 00000008B6AC: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:20 offset1:21      // 00000008B6B4: D8DC1514 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:22 offset1:23      // 00000008B6BC: D8DC1716 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:84 offset1:101     // 00000008B6C4: D8DC6554 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 00000008B6CC: D8DC8776 4A000030
	s_waitcnt lgkmcnt(6)                                       // 00000008B6D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000008B6D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B6DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000008B6E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000008B6E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000008B6E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B6EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000008B6F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000008B6F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000008B6F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B6FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000008B700: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000008B704: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000008B708: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008B70C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000008B710: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 00000008B714: D8DC1918 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:152 offset1:169    // 00000008B71C: D8DCA998 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:26 offset1:27      // 00000008B724: D8DC1B1A 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:186 offset1:203    // 00000008B72C: D8DCCBBA 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:28 offset1:29      // 00000008B734: D8DC1D1C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 00000008B73C: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:220 offset1:237    // 00000008B744: D8DCEDDC 48000030
	ds_load_2addr_b32 v[74:75], v49 offset0:126 offset1:143    // 00000008B74C: D8DC8F7E 4A000031
	s_waitcnt lgkmcnt(6)                                       // 00000008B754: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000008B758: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B75C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000008B760: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000008B764: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000008B768: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B76C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000008B770: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000008B774: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000008B778: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B77C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000008B780: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000008B784: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000008B788: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008B78C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000008B790: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:32 offset1:33      // 00000008B794: D8DC2120 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:32 offset1:49      // 00000008B79C: D8DC3120 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 00000008B7A4: D8DC2322 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:66 offset1:83      // 00000008B7AC: D8DC5342 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:36 offset1:37      // 00000008B7B4: D8DC2524 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:38 offset1:39      // 00000008B7BC: D8DC2726 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 00000008B7C4: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 00000008B7CC: D8DC9786 4A000032
	s_waitcnt lgkmcnt(6)                                       // 00000008B7D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000008B7D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B7DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000008B7E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000008B7E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000008B7E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B7EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000008B7F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000008B7F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000008B7F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B7FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000008B800: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000008B804: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000008B808: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008B80C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000008B810: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:40 offset1:41      // 00000008B814: D8DC2928 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:168 offset1:185    // 00000008B81C: D8DCB9A8 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:42 offset1:43      // 00000008B824: D8DC2B2A 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:202 offset1:219    // 00000008B82C: D8DCDBCA 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:44 offset1:45      // 00000008B834: D8DC2D2C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:46 offset1:47      // 00000008B83C: D8DC2F2E 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:236 offset1:253    // 00000008B844: D8DCFDEC 48000032
	ds_load_2addr_b32 v[74:75], v51 offset0:14 offset1:31      // 00000008B84C: D8DC1F0E 4A000033
	s_waitcnt lgkmcnt(6)                                       // 00000008B854: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000008B858: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B85C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000008B860: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000008B864: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000008B868: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B86C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000008B870: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000008B874: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000008B878: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B87C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000008B880: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000008B884: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000008B888: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008B88C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000008B890: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 00000008B894: D8DC3130 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:48 offset1:65      // 00000008B89C: D8DC4130 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:50 offset1:51      // 00000008B8A4: D8DC3332 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:82 offset1:99      // 00000008B8AC: D8DC6352 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:52 offset1:53      // 00000008B8B4: D8DC3534 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:54 offset1:55      // 00000008B8BC: D8DC3736 4600002E
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 00000008B8C4: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 00000008B8CC: D8DCA796 4A000033
	s_waitcnt lgkmcnt(6)                                       // 00000008B8D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000008B8D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B8DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000008B8E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000008B8E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000008B8E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B8EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000008B8F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000008B8F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000008B8F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B8FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000008B900: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000008B904: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000008B908: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008B90C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000008B910: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:56 offset1:57      // 00000008B914: D8DC3938 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:184 offset1:201    // 00000008B91C: D8DCC9B8 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:58 offset1:59      // 00000008B924: D8DC3B3A 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:218 offset1:235    // 00000008B92C: D8DCEBDA 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:60 offset1:61      // 00000008B934: D8DC3D3C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:62 offset1:63      // 00000008B93C: D8DC3F3E 4600002E
	ds_load_2addr_b32 v[72:73], v52 offset0:124 offset1:141    // 00000008B944: D8DC8D7C 48000034
	ds_load_2addr_b32 v[74:75], v53 offset0:30 offset1:47      // 00000008B94C: D8DC2F1E 4A000035
	s_waitcnt lgkmcnt(6)                                       // 00000008B954: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000008B958: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B95C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000008B960: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000008B964: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000008B968: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B96C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000008B970: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000008B974: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000008B978: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B97C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000008B980: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000008B984: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000008B988: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008B98C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000008B990: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:64 offset1:65      // 00000008B994: D8DC4140 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:64 offset1:81      // 00000008B99C: D8DC5140 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:66 offset1:67      // 00000008B9A4: D8DC4342 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:98 offset1:115     // 00000008B9AC: D8DC7362 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:68 offset1:69      // 00000008B9B4: D8DC4544 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:70 offset1:71      // 00000008B9BC: D8DC4746 4600002E
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 00000008B9C4: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 00000008B9CC: D8DCB7A6 4A000035
	s_waitcnt lgkmcnt(6)                                       // 00000008B9D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000008B9D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B9DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000008B9E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000008B9E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000008B9E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B9EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000008B9F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000008B9F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000008B9F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008B9FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000008BA00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000008BA04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000008BA08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008BA0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000008BA10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 00000008BA14: D8DC4948 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:200 offset1:217    // 00000008BA1C: D8DCD9C8 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:74 offset1:75      // 00000008BA24: D8DC4B4A 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:234 offset1:251    // 00000008BA2C: D8DCFBEA 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:76 offset1:77      // 00000008BA34: D8DC4D4C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:78 offset1:79      // 00000008BA3C: D8DC4F4E 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:12 offset1:29      // 00000008BA44: D8DC1D0C 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:46 offset1:63      // 00000008BA4C: D8DC3F2E 4A000036
	s_waitcnt lgkmcnt(6)                                       // 00000008BA54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000008BA58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BA5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000008BA60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000008BA64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000008BA68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BA6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000008BA70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000008BA74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000008BA78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BA7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000008BA80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000008BA84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000008BA88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008BA8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000008BA90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:80 offset1:81      // 00000008BA94: D8DC5150 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:80 offset1:97      // 00000008BA9C: D8DC6150 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 00000008BAA4: D8DC5352 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:114 offset1:131    // 00000008BAAC: D8DC8372 42000036
	ds_load_2addr_b32 v[68:69], v46 offset0:84 offset1:85      // 00000008BAB4: D8DC5554 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:86 offset1:87      // 00000008BABC: D8DC5756 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 00000008BAC4: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 00000008BACC: D8DCC7B6 4A000036
	s_waitcnt lgkmcnt(6)                                       // 00000008BAD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000008BAD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BADC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000008BAE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000008BAE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000008BAE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BAEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000008BAF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000008BAF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000008BAF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BAFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000008BB00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000008BB04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000008BB08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008BB0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000008BB10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:88 offset1:89      // 00000008BB14: D8DC5958 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:216 offset1:233    // 00000008BB1C: D8DCE9D8 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:90 offset1:91      // 00000008BB24: D8DC5B5A 4000002E
	ds_load_2addr_b32 v[66:67], v55 offset0:122 offset1:139    // 00000008BB2C: D8DC8B7A 42000037
	ds_load_2addr_b32 v[68:69], v46 offset0:92 offset1:93      // 00000008BB34: D8DC5D5C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:94 offset1:95      // 00000008BB3C: D8DC5F5E 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:28 offset1:45      // 00000008BB44: D8DC2D1C 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:62 offset1:79      // 00000008BB4C: D8DC4F3E 4A000038
	s_waitcnt lgkmcnt(6)                                       // 00000008BB54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000008BB58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BB5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000008BB60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000008BB64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000008BB68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BB6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000008BB70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000008BB74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000008BB78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BB7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000008BB80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000008BB84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000008BB88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008BB8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000008BB90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 00000008BB94: D8DC6160 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:96 offset1:113     // 00000008BB9C: D8DC7160 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:98 offset1:99      // 00000008BBA4: D8DC6362 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:130 offset1:147    // 00000008BBAC: D8DC9382 42000038
	ds_load_2addr_b32 v[68:69], v46 offset0:100 offset1:101    // 00000008BBB4: D8DC6564 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:102 offset1:103    // 00000008BBBC: D8DC6766 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 00000008BBC4: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 00000008BBCC: D8DCD7C6 4A000038
	s_waitcnt lgkmcnt(6)                                       // 00000008BBD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000008BBD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BBDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000008BBE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000008BBE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000008BBE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BBEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000008BBF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000008BBF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000008BBF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BBFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000008BC00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000008BC04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000008BC08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008BC0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000008BC10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:104 offset1:105    // 00000008BC14: D8DC6968 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:232 offset1:249    // 00000008BC1C: D8DCF9E8 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 00000008BC24: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:10 offset1:27      // 00000008BC2C: D8DC1B0A 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:108 offset1:109    // 00000008BC34: D8DC6D6C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:110 offset1:111    // 00000008BC3C: D8DC6F6E 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:44 offset1:61      // 00000008BC44: D8DC3D2C 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:78 offset1:95      // 00000008BC4C: D8DC5F4E 4A000039
	s_waitcnt lgkmcnt(6)                                       // 00000008BC54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000008BC58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BC5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000008BC60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000008BC64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000008BC68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BC6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000008BC70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000008BC74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000008BC78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BC7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000008BC80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000008BC84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000008BC88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008BC8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000008BC90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:112 offset1:113    // 00000008BC94: D8DC7170 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:112 offset1:129    // 00000008BC9C: D8DC8170 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:114 offset1:115    // 00000008BCA4: D8DC7372 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:146 offset1:163    // 00000008BCAC: D8DCA392 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:116 offset1:117    // 00000008BCB4: D8DC7574 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:118 offset1:119    // 00000008BCBC: D8DC7776 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 00000008BCC4: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 00000008BCCC: D8DCE7D6 4A000039
	s_waitcnt lgkmcnt(6)                                       // 00000008BCD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000008BCD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BCDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000008BCE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000008BCE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000008BCE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BCEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000008BCF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000008BCF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000008BCF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008BCFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000008BD00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000008BD04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000008BD08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008BD0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000008BD10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 00000008BD14: D8DC7978 3C00002E
	ds_load_2addr_b32 v[62:63], v58 offset0:120 offset1:137    // 00000008BD1C: D8DC8978 3E00003A
	ds_load_2addr_b32 v[64:65], v46 offset0:122 offset1:123    // 00000008BD24: D8DC7B7A 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:26 offset1:43      // 00000008BD2C: D8DC2B1A 4200003B
	ds_load_2addr_b32 v[68:69], v46 offset0:124 offset1:125    // 00000008BD34: D8DC7D7C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:126 offset1:127    // 00000008BD3C: D8DC7F7E 4600002E
	ds_load_2addr_b32 v[72:73], v59 offset0:60 offset1:77      // 00000008BD44: D8DC4D3C 4800003B
	ds_load_2addr_b32 v[74:75], v59 offset0:94 offset1:111     // 00000008BD4C: D8DC6F5E 4A00003B
	v_lshlrev_b32_e32 v33, 2, v33                              // 00000008BD54: 30424282
	s_waitcnt lgkmcnt(6)                                       // 00000008BD58: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000008BD5C: 56987D3C
	ds_load_b32 v60, v33 offset:17440                          // 00000008BD60: D8D84420 3C000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 00000008BD68: CA10011E 2220011D
	v_mov_b32_e32 v62, v35                                     // 00000008BD70: 7E7C0323
	v_fmac_f32_e32 v76, v61, v63                               // 00000008BD74: 56987F3D
	v_mov_b32_e32 v61, v1                                      // 00000008BD78: 7E7A0301
	s_waitcnt lgkmcnt(5)                                       // 00000008BD7C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008BD80: BF870092
	v_fmac_f32_e32 v76, v64, v66                               // 00000008BD84: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 00000008BD88: 56988741
	s_waitcnt lgkmcnt(2)                                       // 00000008BD8C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008BD90: BF870091
	v_fmac_f32_e32 v76, v68, v72                               // 00000008BD94: 56989144
	v_fmac_f32_e32 v76, v69, v73                               // 00000008BD98: 56989345
	s_waitcnt lgkmcnt(1)                                       // 00000008BD9C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008BDA0: BF870091
	v_fmac_f32_e32 v76, v70, v74                               // 00000008BDA4: 56989546
	v_fmac_f32_e32 v76, v71, v75                               // 00000008BDA8: 56989747
	s_waitcnt lgkmcnt(0)                                       // 00000008BDAC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008BDB0: BF870001
	v_mul_f32_e32 v60, v76, v60                                // 00000008BDB4: 1078794C
	s_set_inst_prefetch_distance 0x1                           // 00000008BDB8: BF840001
	s_nop 0                                                    // 00000008BDBC: BF800000
	global_load_b32 v64, v[33:34], off                         // 00000008BDC0: DC520000 407C0021
	ds_load_b32 v65, v61 offset:8704                           // 00000008BDC8: D8D82200 4100003D
	v_add_nc_u32_e32 v62, -1, v62                              // 00000008BDD0: 4A7C7CC1
	.long 0xd7000121                                           // 00000008BDD4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 00000008BDD8: 02010921
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008BDDC: BF870001
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 00000008BDE0: D5207C22 00064480
	v_add_nc_u32_e32 v61, 0x44, v61                            // 00000008BDE8: 4A7A7AFF 00000044
	s_waitcnt lgkmcnt(0)                                       // 00000008BDF0: BF89FC07
	v_cvt_f16_f32_e32 v63, v65                                 // 00000008BDF4: 7E7E1541
	.long 0xd4130204                                           // 00000008BDF8: D4130204
	v_cndmask_b32_e32 v1, 0x38800006, v65, vcc_lo              // 00000008BDFC: 020282FF 38800006
	.long 0xd416020d                                           // 00000008BE04: D416020D
	v_cndmask_b32_e32 v1, 0x477fe000, v65, vcc_lo              // 00000008BE08: 020282FF 477FE000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000008BE10: BF870003
	v_cvt_f32_f16_e32 v66, v63                                 // 00000008BE14: 7E84173F
	s_and_b32 s4, s4, s13                                      // 00000008BE18: 8B040D04
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000008BE1C: BF870481
	v_cndmask_b32_e64 v65, v65, v66, s4                        // 00000008BE20: D5010041 00128541
	s_waitcnt vmcnt(0)                                         // 00000008BE28: BF8903F7
	.long 0x7f7e1540                                           // 00000008BE2C: 7F7E1540
	.long 0xd413020e                                           // 00000008BE30: D413020E
	v_cndmask_b32_e32 v1, 0x38800006, v64, vcc_lo              // 00000008BE34: 020280FF 38800006
	.long 0xd416020f                                           // 00000008BE3C: D416020F
	v_cndmask_b32_e32 v1, 0x477fe000, v64, vcc_lo              // 00000008BE40: 020280FF 477FE000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000008BE48: BF870003
	v_cvt_f32_f16_e32 v63, v191/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000008BE4C: 7E7E17BF
	s_and_b32 s4, s14, s15                                     // 00000008BE50: 8B040F0E
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000008BE54: BF870481
	v_cndmask_b32_e64 v63, v64, v63, s4                        // 00000008BE58: D501003F 00127F40
	.long 0xd44a0004                                           // 00000008BE60: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 00000008BE64: 02027C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000008BE68: BF8704A2
	v_fmac_f32_e32 v60, v63, v65                               // 00000008BE6C: 5678833F
	s_or_b32 s12, s4, s12                                      // 00000008BE70: 8C0C0C04
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 00000008BE74: 917E0C7E
	s_cbranch_execnz 65489                                     // 00000008BE78: BFA6FFD1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19c0>
	s_set_inst_prefetch_distance 0x2                           // 00000008BE7C: BF840002
	s_or_b32 exec_lo, exec_lo, s12                             // 00000008BE80: 8C7E0C7E
	v_bfe_u32 v61, v60, 16, 1                                  // 00000008BE84: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 00000008BE8C: D6FE7C21 041648FF 00003000
	s_delay_alu instid0(VALU_DEP_2)                            // 00000008BE98: BF870002
	v_add3_u32 v36, v60, v61, 0x7fff                           // 00000008BE9C: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 00000008BEA8: DC960000 007C2421
	s_branch 64888                                             // 00000008BEB0: BFA0FD78 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 00000008BEB4: A201FF06 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 00000008BEBC: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000008BEC0: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 00000008BEC4: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 00000008BECC: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 00000008BED0: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 00000008BED8: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 00000008BEE0: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000008BEE4: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 00000008BEE8: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 00000008BEF0: A0010401
	s_mov_b32 s4, 0                                            // 00000008BEF4: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 00000008BEF8: BF87000A
	v_exp_f32_e32 v29, s1                                      // 00000008BEFC: 7E3A4A01
	s_cvt_i32_f32 s1, s7                                       // 00000008BF00: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 00000008BF04: BF870585
	.long 0xd71c001d                                           // 00000008BF08: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 00000008BF0C: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 00000008BF10: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 00000008BF14: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000008BF1C: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 00000008BF20: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 00000008BF28: 980180C1
	v_mov_b32_e32 v29, v37                                     // 00000008BF2C: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 00000008BF30: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 00000008BF3C: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 00000008BF44: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008BF4C: BF870001
	.long 0xd4490001                                           // 00000008BF50: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 00000008BF54: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 00000008BF5C: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 00000008BF60: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 00000008BF64: 1040411E
	ds_store_b32 v29, v32                                      // 00000008BF68: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 00000008BF70: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000008BF78: 917E047E
	s_cbranch_execnz 65519                                     // 00000008BF7C: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b3c>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008BF80: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 00000008BF84: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 00000008BF8C: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 00000008BF94: 7E420326
	s_mov_b32 s6, 0                                            // 00000008BF98: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000008BF9C: BF89FC07
	s_barrier                                                  // 00000008BFA0: BFBD0000
	buffer_gl0_inv                                             // 00000008BFA4: E0AC0000 00000000
	s_nop 0                                                    // 00000008BFAC: BF800000
	s_nop 0                                                    // 00000008BFB0: BF800000
	s_nop 0                                                    // 00000008BFB4: BF800000
	s_nop 0                                                    // 00000008BFB8: BF800000
	s_nop 0                                                    // 00000008BFBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000008BFC0: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 00000008BFC8: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000008BFD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000008BFD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008BFDC: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 00000008BFE4: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000008BFE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000008BFF0: BF870004
	.long 0xd4490004                                           // 00000008BFF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000008BFF8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000008C000: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000008C004: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000008C008: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 00000008C00C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 00000008C014: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000008C01C: 917E067E
	s_cbranch_execnz 65511                                     // 00000008C020: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1bc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000008C024: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000008C028: BF89FC07
	s_barrier                                                  // 00000008C02C: BFBD0000
	buffer_gl0_inv                                             // 00000008C030: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 00000008C038: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 00000008C040: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 00000008C048: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 00000008C050: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 00000008C058: 7E780300
	s_mov_b32 s4, 0                                            // 00000008C05C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000008C060: BF840001
	s_nop 0                                                    // 00000008C064: BF800000
	s_nop 0                                                    // 00000008C068: BF800000
	s_nop 0                                                    // 00000008C06C: BF800000
	s_nop 0                                                    // 00000008C070: BF800000
	s_nop 0                                                    // 00000008C074: BF800000
	s_nop 0                                                    // 00000008C078: BF800000
	s_nop 0                                                    // 00000008C07C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008C080: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000008C084: 327A7884
	.long 0xd4490001                                           // 00000008C088: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000008C08C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000008C094: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000008C098: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000008C0A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000008C0A8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000008C0B0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000008C0B8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000008C0C0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000008C0C8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000008C0D0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000008C0D8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000008C0E0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000008C0E4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000008C0F0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000008C0F4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000008C0F8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000008C100: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000008C104: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000008C108: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000008C10C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008C110: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000008C114: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000008C118: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000008C11C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008C120: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000008C124: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000008C130: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000008C138: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000008C140: 917E047E
	s_cbranch_execnz 65486                                     // 00000008C144: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c80>
	s_set_inst_prefetch_distance 0x2                           // 00000008C148: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008C14C: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 00000008C150: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000008C158: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000008C160: 7E420326
	s_mov_b32 s6, 0                                            // 00000008C164: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000008C168: BF89FC07
	s_barrier                                                  // 00000008C16C: BFBD0000
	buffer_gl0_inv                                             // 00000008C170: E0AC0000 00000000
	s_nop 0                                                    // 00000008C178: BF800000
	s_nop 0                                                    // 00000008C17C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000008C180: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 00000008C188: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000008C190: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000008C198: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008C19C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000008C1A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000008C1A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000008C1B0: BF870004
	.long 0xd4490004                                           // 00000008C1B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000008C1B8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000008C1C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000008C1C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000008C1C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008C1CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000008C1D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000008C1DC: 917E067E
	s_cbranch_execnz 65511                                     // 00000008C1E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d80>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000008C1E4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000008C1E8: BF89FC07
	s_barrier                                                  // 00000008C1EC: BFBD0000
	buffer_gl0_inv                                             // 00000008C1F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 00000008C1F8: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 00000008C200: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 00000008C208: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 00000008C210: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 00000008C218: 7E780300
	s_mov_b32 s4, 0                                            // 00000008C21C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000008C220: BF840001
	s_nop 0                                                    // 00000008C224: BF800000
	s_nop 0                                                    // 00000008C228: BF800000
	s_nop 0                                                    // 00000008C22C: BF800000
	s_nop 0                                                    // 00000008C230: BF800000
	s_nop 0                                                    // 00000008C234: BF800000
	s_nop 0                                                    // 00000008C238: BF800000
	s_nop 0                                                    // 00000008C23C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008C240: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000008C244: 327A7884
	.long 0xd4490001                                           // 00000008C248: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000008C24C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000008C254: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000008C258: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000008C264: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000008C268: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000008C270: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000008C278: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000008C280: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000008C288: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000008C290: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000008C298: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000008C2A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000008C2A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000008C2B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000008C2B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000008C2B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000008C2C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000008C2C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000008C2C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000008C2CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008C2D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000008C2D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000008C2D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000008C2DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008C2E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000008C2E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000008C2F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000008C2F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000008C300: 917E047E
	s_cbranch_execnz 65486                                     // 00000008C304: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e40>
	s_set_inst_prefetch_distance 0x2                           // 00000008C308: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008C30C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 00000008C310: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000008C318: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000008C320: 7E420326
	s_mov_b32 s6, 0                                            // 00000008C324: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000008C328: BF89FC07
	s_barrier                                                  // 00000008C32C: BFBD0000
	buffer_gl0_inv                                             // 00000008C330: E0AC0000 00000000
	s_nop 0                                                    // 00000008C338: BF800000
	s_nop 0                                                    // 00000008C33C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000008C340: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 00000008C348: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000008C350: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000008C358: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008C35C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000008C364: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000008C368: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000008C370: BF870004
	.long 0xd4490004                                           // 00000008C374: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000008C378: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000008C380: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000008C384: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000008C388: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008C38C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000008C394: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000008C39C: 917E067E
	s_cbranch_execnz 65511                                     // 00000008C3A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f40>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000008C3A4: 8C7E067E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 00000008C3A8: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 00000008C3B0: BF89FC07
	s_barrier                                                  // 00000008C3B4: BFBD0000
	buffer_gl0_inv                                             // 00000008C3B8: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 00000008C3C0: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 00000008C3C4: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 00000008C3CC: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 00000008C3D4: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 00000008C3DC: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 00000008C3E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000008C3E8: BF840001
	s_nop 0                                                    // 00000008C3EC: BF800000
	s_nop 0                                                    // 00000008C3F0: BF800000
	s_nop 0                                                    // 00000008C3F4: BF800000
	s_nop 0                                                    // 00000008C3F8: BF800000
	s_nop 0                                                    // 00000008C3FC: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 00000008C400: 327C7A84
	.long 0xd4490001                                           // 00000008C404: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000008C408: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000008C410: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000008C414: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000008C418: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000008C424: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000008C428: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000008C430: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000008C438: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000008C440: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000008C448: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000008C450: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000008C458: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000008C460: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000008C464: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000008C468: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000008C46C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000008C478: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000008C480: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000008C484: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000008C488: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000008C48C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008C490: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000008C494: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000008C498: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000008C49C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008C4A0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 00000008C4A4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 00000008C4B0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 00000008C4B8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000008C4C0: 917E047E
	s_cbranch_execnz 65486                                     // 00000008C4C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2000>
	s_set_inst_prefetch_distance 0x2                           // 00000008C4C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008C4CC: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 00000008C4D0: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000008C4D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000008C4E0: 7E420326
	s_mov_b32 s6, 0                                            // 00000008C4E4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000008C4E8: BF89FC07
	s_barrier                                                  // 00000008C4EC: BFBD0000
	buffer_gl0_inv                                             // 00000008C4F0: E0AC0000 00000000
	s_nop 0                                                    // 00000008C4F8: BF800000
	s_nop 0                                                    // 00000008C4FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000008C500: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 00000008C508: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000008C510: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000008C518: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008C51C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000008C524: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000008C528: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000008C530: BF870004
	.long 0xd4490004                                           // 00000008C534: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000008C538: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000008C540: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000008C544: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000008C548: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008C54C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000008C554: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000008C55C: 917E067E
	s_cbranch_execnz 65511                                     // 00000008C560: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2100>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000008C564: 8C7E067E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 00000008C568: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 00000008C570: BF89FC07
	s_barrier                                                  // 00000008C574: BFBD0000
	buffer_gl0_inv                                             // 00000008C578: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 00000008C580: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 00000008C588: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 00000008C590: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 00000008C598: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 00000008C5A0: 7E780300
	s_mov_b32 s4, 0                                            // 00000008C5A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000008C5A8: BF840001
	s_nop 0                                                    // 00000008C5AC: BF800000
	s_nop 0                                                    // 00000008C5B0: BF800000
	s_nop 0                                                    // 00000008C5B4: BF800000
	s_nop 0                                                    // 00000008C5B8: BF800000
	s_nop 0                                                    // 00000008C5BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008C5C0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000008C5C4: 327A7884
	.long 0xd4490001                                           // 00000008C5C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000008C5CC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000008C5D4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000008C5D8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000008C5E4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000008C5E8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000008C5F0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000008C5F8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000008C600: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000008C608: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000008C610: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000008C618: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000008C620: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000008C624: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000008C630: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000008C634: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000008C638: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000008C640: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000008C644: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000008C648: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000008C64C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008C650: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000008C654: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000008C658: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000008C65C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008C660: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000008C664: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000008C670: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000008C678: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000008C680: 917E047E
	s_cbranch_execnz 65486                                     // 00000008C684: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x21c0>
	s_set_inst_prefetch_distance 0x2                           // 00000008C688: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008C68C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 00000008C690: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000008C698: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000008C6A0: 7E420326
	s_mov_b32 s6, 0                                            // 00000008C6A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000008C6A8: BF89FC07
	s_barrier                                                  // 00000008C6AC: BFBD0000
	buffer_gl0_inv                                             // 00000008C6B0: E0AC0000 00000000
	s_nop 0                                                    // 00000008C6B8: BF800000
	s_nop 0                                                    // 00000008C6BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000008C6C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 00000008C6C8: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000008C6D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000008C6D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008C6DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000008C6E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000008C6E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000008C6F0: BF870004
	.long 0xd4490004                                           // 00000008C6F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000008C6F8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000008C700: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000008C704: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000008C708: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008C70C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000008C714: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000008C71C: 917E067E
	s_cbranch_execnz 65511                                     // 00000008C720: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x22c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000008C724: 8C7E067E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 00000008C728: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 00000008C730: BF89FC07
	s_barrier                                                  // 00000008C734: BFBD0000
	buffer_gl0_inv                                             // 00000008C738: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 00000008C740: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 00000008C744: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 00000008C74C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 00000008C754: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 00000008C75C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 00000008C764: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000008C768: BF840001
	s_nop 0                                                    // 00000008C76C: BF800000
	s_nop 0                                                    // 00000008C770: BF800000
	s_nop 0                                                    // 00000008C774: BF800000
	s_nop 0                                                    // 00000008C778: BF800000
	s_nop 0                                                    // 00000008C77C: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 00000008C780: 327C7884
	.long 0xd4490001                                           // 00000008C784: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000008C788: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000008C790: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000008C794: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000008C798: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000008C7A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000008C7A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000008C7B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000008C7B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000008C7C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000008C7C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000008C7D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000008C7D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000008C7E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000008C7E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000008C7E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000008C7EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000008C7F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000008C800: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000008C804: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000008C808: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000008C80C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008C810: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000008C814: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000008C818: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000008C81C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008C820: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 00000008C824: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 00000008C830: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 00000008C834: BF870002
	v_mov_b32_e32 v60, v63                                     // 00000008C838: 7E78033F
	ds_store_b32 v62, v70                                      // 00000008C83C: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000008C844: 917E047E
	s_cbranch_execnz 65485                                     // 00000008C848: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2380>
	s_set_inst_prefetch_distance 0x2                           // 00000008C84C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008C850: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 00000008C854: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000008C85C: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000008C864: 7E420326
	s_mov_b32 s6, 0                                            // 00000008C868: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000008C86C: BF89FC07
	s_barrier                                                  // 00000008C870: BFBD0000
	buffer_gl0_inv                                             // 00000008C874: E0AC0000 00000000
	s_nop 0                                                    // 00000008C87C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000008C880: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 00000008C888: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000008C890: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000008C898: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008C89C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000008C8A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000008C8A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000008C8B0: BF870004
	.long 0xd4490004                                           // 00000008C8B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000008C8B8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000008C8C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000008C8C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000008C8C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008C8CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000008C8D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000008C8DC: 917E067E
	s_cbranch_execnz 65511                                     // 00000008C8E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2480>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000008C8E4: 8C7E067E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 00000008C8E8: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 00000008C8F0: BF89FC07
	s_barrier                                                  // 00000008C8F4: BFBD0000
	buffer_gl0_inv                                             // 00000008C8F8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 00000008C900: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 00000008C908: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 00000008C910: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 00000008C918: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 00000008C920: 7E7A0300
	s_mov_b32 s4, 0                                            // 00000008C924: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000008C928: BF840001
	s_nop 0                                                    // 00000008C92C: BF800000
	s_nop 0                                                    // 00000008C930: BF800000
	s_nop 0                                                    // 00000008C934: BF800000
	s_nop 0                                                    // 00000008C938: BF800000
	s_nop 0                                                    // 00000008C93C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008C940: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 00000008C944: 327C7A84
	.long 0xd4490001                                           // 00000008C948: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000008C94C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000008C954: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000008C958: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000008C964: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000008C968: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000008C970: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000008C978: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000008C980: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000008C988: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000008C990: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000008C998: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000008C9A0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000008C9A4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000008C9A8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000008C9AC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000008C9B8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000008C9C0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000008C9C4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000008C9C8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000008C9CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008C9D0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000008C9D4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000008C9D8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000008C9DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008C9E0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 00000008C9E4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 00000008C9F0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 00000008C9F8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000008CA00: 917E047E
	s_cbranch_execnz 65486                                     // 00000008CA04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2540>
	s_set_inst_prefetch_distance 0x2                           // 00000008CA08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008CA0C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 00000008CA10: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000008CA18: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000008CA20: 7E420326
	s_mov_b32 s6, 0                                            // 00000008CA24: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000008CA28: BF89FC07
	s_barrier                                                  // 00000008CA2C: BFBD0000
	buffer_gl0_inv                                             // 00000008CA30: E0AC0000 00000000
	s_nop 0                                                    // 00000008CA38: BF800000
	s_nop 0                                                    // 00000008CA3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000008CA40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 00000008CA48: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000008CA50: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000008CA58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008CA5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000008CA64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000008CA68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000008CA70: BF870004
	.long 0xd4490004                                           // 00000008CA74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000008CA78: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000008CA80: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000008CA84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000008CA88: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008CA8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000008CA94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000008CA9C: 917E067E
	s_cbranch_execnz 65511                                     // 00000008CAA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2640>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000008CAA4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000008CAA8: BF89FC07
	s_barrier                                                  // 00000008CAAC: BFBD0000
	buffer_gl0_inv                                             // 00000008CAB0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 00000008CAB8: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 00000008CAC0: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 00000008CAC8: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 00000008CAD0: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 00000008CAD8: 7E7A0300
	s_mov_b32 s4, 0                                            // 00000008CADC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000008CAE0: BF840001
	s_nop 0                                                    // 00000008CAE4: BF800000
	s_nop 0                                                    // 00000008CAE8: BF800000
	s_nop 0                                                    // 00000008CAEC: BF800000
	s_nop 0                                                    // 00000008CAF0: BF800000
	s_nop 0                                                    // 00000008CAF4: BF800000
	s_nop 0                                                    // 00000008CAF8: BF800000
	s_nop 0                                                    // 00000008CAFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008CB00: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 00000008CB04: 327C7A84
	.long 0xd4490001                                           // 00000008CB08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000008CB0C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000008CB14: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000008CB18: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000008CB24: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000008CB28: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000008CB30: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000008CB38: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000008CB40: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000008CB48: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000008CB50: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000008CB58: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000008CB60: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000008CB64: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000008CB68: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000008CB6C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000008CB78: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000008CB80: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000008CB84: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000008CB88: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000008CB8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008CB90: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000008CB94: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000008CB98: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000008CB9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008CBA0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 00000008CBA4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 00000008CBB0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 00000008CBB8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000008CBC0: 917E047E
	s_cbranch_execnz 65486                                     // 00000008CBC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2700>
	s_set_inst_prefetch_distance 0x2                           // 00000008CBC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008CBCC: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 00000008CBD0: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000008CBD8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000008CBE0: 7E420326
	s_mov_b32 s6, 0                                            // 00000008CBE4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000008CBE8: BF89FC07
	s_barrier                                                  // 00000008CBEC: BFBD0000
	buffer_gl0_inv                                             // 00000008CBF0: E0AC0000 00000000
	s_nop 0                                                    // 00000008CBF8: BF800000
	s_nop 0                                                    // 00000008CBFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000008CC00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 00000008CC08: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000008CC10: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000008CC18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008CC1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000008CC24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000008CC28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000008CC30: BF870004
	.long 0xd4490004                                           // 00000008CC34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000008CC38: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000008CC40: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000008CC44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000008CC48: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008CC4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000008CC54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000008CC5C: 917E067E
	s_cbranch_execnz 65511                                     // 00000008CC60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2800>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000008CC64: 8C7E067E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 00000008CC68: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 00000008CC70: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 00000008CC78: BF89FC07
	s_barrier                                                  // 00000008CC7C: BFBD0000
	buffer_gl0_inv                                             // 00000008CC80: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 00000008CC88: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 00000008CC90: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 00000008CC98: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 00000008CCA0: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 00000008CCA8: 7E780300
	s_mov_b32 s4, 0                                            // 00000008CCAC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000008CCB0: BF840001
	s_nop 0                                                    // 00000008CCB4: BF800000
	s_nop 0                                                    // 00000008CCB8: BF800000
	s_nop 0                                                    // 00000008CCBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008CCC0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000008CCC4: 327A7884
	.long 0xd4490001                                           // 00000008CCC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000008CCCC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000008CCD4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000008CCD8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000008CCE4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000008CCE8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000008CCF0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000008CCF8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000008CD00: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000008CD08: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000008CD10: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000008CD18: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000008CD20: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000008CD24: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000008CD30: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000008CD34: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000008CD38: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000008CD40: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000008CD44: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000008CD48: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000008CD4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008CD50: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000008CD54: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000008CD58: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000008CD5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008CD60: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000008CD64: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000008CD70: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000008CD78: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000008CD80: 917E047E
	s_cbranch_execnz 65486                                     // 00000008CD84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x28c0>
	s_set_inst_prefetch_distance 0x2                           // 00000008CD88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008CD8C: 8C7E047E
	.long 0xd7000107                                           // 00000008CD90: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 00000008CD94: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008CD9C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 00000008CDA0: D5207C08 00061080
	.long 0xd7000109                                           // 00000008CDA8: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 00000008CDAC: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 00000008CDB4: D5207C0A 00061480
	.long 0xd700010d                                           // 00000008CDBC: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 00000008CDC0: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008CDC8: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 00000008CDCC: D5207C0E 00061C80
	.long 0xd700010b                                           // 00000008CDD4: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 00000008CDD8: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 00000008CDE0: D5207C0C 00061880
	.long 0xd700010f                                           // 00000008CDE8: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 00000008CDEC: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008CDF4: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 00000008CDF8: D5207C10 00062080
	.long 0xd7000111                                           // 00000008CE00: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 00000008CE04: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 00000008CE0C: D5207C12 00062480
	.long 0xd7000113                                           // 00000008CE14: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 00000008CE18: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008CE20: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 00000008CE24: D5207C14 00062880
	.long 0xd7000115                                           // 00000008CE2C: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 00000008CE30: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 00000008CE38: D5207C16 00062C80
	.long 0xd7000117                                           // 00000008CE40: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 00000008CE44: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008CE4C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 00000008CE50: D5207C18 00063080
	.long 0xd7000119                                           // 00000008CE58: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 00000008CE5C: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 00000008CE64: D5207C1A 00063480
	.long 0xd700011b                                           // 00000008CE6C: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 00000008CE70: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008CE78: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 00000008CE7C: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 00000008CE84: 81058105
	s_waitcnt lgkmcnt(0)                                       // 00000008CE88: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 00000008CE8C: BF062105
	s_barrier                                                  // 00000008CE90: BFBD0000
	buffer_gl0_inv                                             // 00000008CE94: E0AC0000 00000000
	s_cbranch_scc0 63041                                       // 00000008CE9C: BFA1F641 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a4>
	v_mov_b32_e32 v4, v38                                      // 00000008CEA0: 7E080326
	s_add_u32 s0, s28, s20                                     // 00000008CEA4: 8000141C
	.long 0xd73c0000                                           // 00000008CEA8: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000008CEAC: 02020489
	s_addc_u32 s1, s29, s21                                    // 00000008CEB0: 8201151D
	s_add_u32 s2, s24, s18                                     // 00000008CEB4: 80021218
	s_addc_u32 s3, s25, s19                                    // 00000008CEB8: 82031319
	s_add_u32 s0, s2, s0                                       // 00000008CEBC: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000008CEC0: 82010103
	.long 0xd7006a00                                           // 00000008CEC4: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000008CEC8: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000008CECC: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000008CED0: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 00000008CED8: BE810080
	.long 0xd7006a00                                           // 00000008CEDC: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 00000008CEE0: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000008CEE4: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008CEEC: BF870092
	.long 0xd7006a00                                           // 00000008CEF0: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000008CEF4: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000008CEF8: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 00000008CF00: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 00000008CF08: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 00000008CF10: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000008CF18: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000008CF1C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 00000008CF24: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000008CF28: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 00000008CF2C: DC6A0000 007C0200
	.long 0xd7000000                                           // 00000008CF34: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 00000008CF38: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000008CF40: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000008CF48: 917E017E
	s_cbranch_execnz 65516                                     // 00000008CF4C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b00>
	s_endpgm                                                   // 00000008CF50: BFB00000
		...

