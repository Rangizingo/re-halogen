000000000021ca00 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi():
	s_mov_b32 s12, s3                                          // 00000021CA00: BE8C0003
	s_clause 0x1                                               // 00000021CA04: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 00000021CA08: F40C0100 F8000000
	s_load_b32 s3, s[0:1], 0x20                                // 00000021CA10: F40000C0 F8000020
	v_and_b32_e32 v1, 0x7f, v0                                 // 00000021CA18: 360200FF 0000007F
	s_ashr_i32 s13, s12, 31                                    // 00000021CA20: 860D9F0C
	s_mov_b32 s1, 0                                            // 00000021CA24: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000021CA28: BF8700B1
	v_dual_mov_b32 v5, v0 :: v_dual_lshlrev_b32 v2, 1, v1      // 00000021CA2C: CA220100 05020281
	v_lshlrev_b32_e32 v3, 2, v1                                // 00000021CA34: 30060282
	s_waitcnt lgkmcnt(0)                                       // 00000021CA38: BF89FC07
	.long 0xd7000003                                           // 00000021CA3C: D7000003
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 00000021CA40: 02020606
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021CA44: BF870001
	v_add_co_ci_u32_e64 v4, null, s7, 0, s0                    // 00000021CA48: D5207C04 00010007
	s_lshl_b32 s0, s2, 6                                       // 00000021CA50: 84008602
	s_set_inst_prefetch_distance 0x1                           // 00000021CA54: BF840001
	s_branch 24                                                // 00000021CA58: BFA00018 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xbc>
	s_nop 0                                                    // 00000021CA5C: BF800000
	s_nop 0                                                    // 00000021CA60: BF800000
	s_nop 0                                                    // 00000021CA64: BF800000
	s_nop 0                                                    // 00000021CA68: BF800000
	s_nop 0                                                    // 00000021CA6C: BF800000
	s_nop 0                                                    // 00000021CA70: BF800000
	s_nop 0                                                    // 00000021CA74: BF800000
	s_nop 0                                                    // 00000021CA78: BF800000
	s_nop 0                                                    // 00000021CA7C: BF800000
	s_or_b32 exec_lo, exec_lo, s6                              // 00000021CA80: 8C7E067E
	v_add_nc_u32_e32 v8, 0x100, v5                             // 00000021CA84: 4A100AFF 00000100
	v_mad_u64_u32 v[6:7], null, 0x120, v6, v[2:3]              // 00000021CA8C: D6FE7C06 040A0CFF 00000120
	v_cmp_lt_u32_e32 vcc_lo, 0x1eff, v5                        // 00000021CA98: 7C920AFF 00001EFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000021CAA0: BF870003
	v_mov_b32_e32 v5, v8                                       // 00000021CAA4: 7E0A0308
	s_or_b32 s1, vcc_lo, s1                                    // 00000021CAA8: 8C01016A
	ds_store_b16 v6, v1                                        // 00000021CAAC: D87C0000 00000106
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000021CAB4: 917E017E
	s_cbranch_execz 23                                         // 00000021CAB8: BFA50017 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x118>
	v_lshrrev_b32_e32 v6, 7, v5                                // 00000021CABC: 320C0A87
	.long 0x7e023880                                           // 00000021CAC0: 7E023880
	s_mov_b32 s6, exec_lo                                      // 00000021CAC4: BE86007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021CAC8: BF870092
	v_or_b32_e32 v7, s0, v6                                    // 00000021CACC: 380E0C00
	.long 0xd4c4007e                                           // 00000021CAD0: D4C4007E
	v_cndmask_b32_e32 v1, s3, v7, vcc_lo                       // 00000021CAD4: 02020E03
	s_cbranch_execz 65513                                      // 00000021CAD8: BFA5FFE9 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x80>
	v_mad_i64_i32 v[7:8], null, v7, 48, s[12:13]               // 00000021CADC: D6FF7C07 00316107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021CAE4: BF870091
	.long 0xd73c0007                                           // 00000021CAE8: D73C0007
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 00000021CAEC: 02020E89
	.long 0xd7006a07                                           // 00000021CAF0: D7006A07
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 00000021CAF4: 02020F03
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021CAF8: BF870001
	v_add_co_ci_u32_e64 v8, null, v4, v8, vcc_lo               // 00000021CAFC: D5207C08 01AA1104
	global_load_b32 v1, v[7:8], off                            // 00000021CB04: DC520000 017C0007
	s_waitcnt vmcnt(0)                                         // 00000021CB0C: BF8903F7
	v_cvt_f16_f32_e32 v1, v1                                   // 00000021CB10: 7E021501
	s_branch 65498                                             // 00000021CB14: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x80>
	s_set_inst_prefetch_distance 0x2                           // 00000021CB18: BF840002
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CB1C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000021CB20: BF870009
	s_mov_b32 s1, exec_lo                                      // 00000021CB24: BE81007E
	v_cmpx_gt_u32_e32 64, v0                                   // 00000021CB28: 7D9800C0
	s_cbranch_execz 17                                         // 00000021CB2C: BFA50011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x174>
	v_or_b32_e32 v1, s0, v0                                    // 00000021CB30: 38020000
	s_lshl_b64 s[6:7], s[12:13], 2                             // 00000021CB34: 8486820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021CB38: BF870091
	v_mad_i64_i32 v[1:2], null, 0xc0, v1, s[8:9]               // 00000021CB3C: D6FF7C01 002202FF 000000C0
	.long 0xd7006a01                                           // 00000021CB48: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 00000021CB4C: 02000D01
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021CB50: BF870001
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 00000021CB54: D5207C02 01AA0407
	global_load_b32 v1, v[1:2], off                            // 00000021CB5C: DC520000 017C0001
	v_lshlrev_b32_e32 v2, 2, v0                                // 00000021CB64: 30040082
	s_waitcnt vmcnt(0)                                         // 00000021CB68: BF8903F7
	ds_store_b32 v2, v1 offset:18432                           // 00000021CB6C: D8344800 00000102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CB74: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 00000021CB78: BF89FC07
	s_barrier                                                  // 00000021CB7C: BFBD0000
	buffer_gl0_inv                                             // 00000021CB80: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 00000021CB88: BE81007E
	v_cmpx_gt_u32_e32 0x200, v0                                // 00000021CB8C: 7D9800FF 00000200
	s_cbranch_execz 1644                                       // 00000021CB94: BFA5066C <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1b48>
	v_and_b32_e32 v1, 15, v0                                   // 00000021CB98: 3602008F
	v_bfe_u32 v28, v0, 5, 2                                    // 00000021CB9C: D610001C 02090B00
	s_mul_i32 s1, s2, 48                                       // 00000021CBA4: 9601B002
	s_mul_hi_u32 s2, s2, 48                                    // 00000021CBA8: 9682B002
	s_add_u32 s6, s1, s12                                      // 00000021CBAC: 80060C01
	v_mul_u32_u24_e32 v2, 0x120, v1                            // 00000021CBB0: 160402FF 00000120
	v_lshl_or_b32 v29, v28, 4, v1                              // 00000021CBB8: D656001D 0405091C
	v_mul_u32_u24_e32 v3, 0x1200, v28                          // 00000021CBC0: 160638FF 00001200
	s_addc_u32 s7, s2, s13                                     // 00000021CBC8: 82070D02
	v_lshrrev_b32_e32 v34, 5, v0                               // 00000021CBCC: 32440085
	s_lshl_b64 s[6:7], s[6:7], 14                              // 00000021CBD0: 84868E06
	v_or_b32_e32 v30, s0, v1                                   // 00000021CBD4: 383C0200
	v_bfe_u32 v31, v0, 4, 1                                    // 00000021CBD8: D610001F 02050900
	v_lshl_or_b32 v32, v29, 2, 0x4800                          // 00000021CBE0: D6560020 03FD051D 00004800
	v_add_nc_u32_e32 v33, v2, v3                               // 00000021CBEC: 4A420702
	v_mov_b32_e32 v1, 0                                        // 00000021CBF0: 7E020280
	s_add_u32 s2, s10, s6                                      // 00000021CBF4: 8002060A
	s_addc_u32 s6, s11, s7                                     // 00000021CBF8: 8206070B
	s_mov_b32 s7, 0                                            // 00000021CBFC: BE870080
	s_branch 19                                                // 00000021CC00: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x250>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021CC04: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 00000021CC08: D6560000 04750D03
	v_cmp_lt_u32_e32 vcc_lo, 7, v34                            // 00000021CC10: 7C924487
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000021CC14: BF8700B2
	.long 0xd73c0003                                           // 00000021CC18: D73C0003
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021CC1C: 02020082
	v_add_nc_u32_e32 v0, 8, v34                                // 00000021CC20: 4A004488
	s_or_b32 s7, vcc_lo, s7                                    // 00000021CC24: 8C07076A
	v_mov_b32_e32 v34, v0                                      // 00000021CC28: 7E440300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021CC2C: BF870093
	.long 0xd7000003                                           // 00000021CC30: D7000003
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 00000021CC34: 02020602
	v_add_co_ci_u32_e64 v4, null, s6, v4, s0                   // 00000021CC38: D5207C04 00020806
	global_store_b32 v[3:4], v2, off                           // 00000021CC40: DC6A0000 007C0203
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 00000021CC48: 917E077E
	s_cbranch_execz 1598                                       // 00000021CC4C: BFA5063E <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1b48>
	v_lshrrev_b32_e32 v0, 2, v34                               // 00000021CC50: 32004482
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 00000021CC54: CA100080 09080080
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v5, 0               // 00000021CC5C: CA100080 06040080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000021CC64: BF870003
	v_cmp_lt_u32_e32 vcc_lo, v0, v28                           // 00000021CC68: 7C923900
	.long 0xd44e0000                                           // 00000021CC6C: D44E0000
	v_cndmask_b32_e32 v1, v0, v28, vcc_lo                      // 00000021CC70: 02023900
	v_dual_mov_b32 v7, 0 :: v_dual_lshlrev_b32 v0, 4, v0       // 00000021CC74: CA220080 07000084
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v3, 0               // 00000021CC7C: CA100080 04020080
	v_mov_b32_e32 v2, 0                                        // 00000021CC84: 7E040280
	s_and_saveexec_b32 s8, s0                                  // 00000021CC88: BE882000
	s_cbranch_execz 1173                                       // 00000021CC8C: BFA50495 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x14e4>
	v_add_nc_u32_e32 v4, v0, v30                               // 00000021CC90: 4A083D00
	.long 0x7f143880                                           // 00000021CC94: 7F143880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000021CC98: BF8701A2
	v_mad_i64_i32 v[2:3], null, v4, 48, s[12:13]               // 00000021CC9C: D6FF7C02 00316104
	.long 0xd4440000                                           // 00000021CCA4: D4440000
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 00000021CCA8: 02020803
	.long 0x7e14398a                                           // 00000021CCAC: 7E14398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021CCB0: BF870093
	.long 0xd73c0002                                           // 00000021CCB4: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000021CCB8: 02020489
	.long 0xd700011a                                           // 00000021CCBC: D700011A
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000021CCC0: 02020404
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021CCC4: BF870001
	v_add_co_ci_u32_e64 v27, null, s5, v3, s1                  // 00000021CCC8: D5207C1B 00060605
	s_and_saveexec_b32 s1, s0                                  // 00000021CCD0: BE812000
	s_cbranch_execz 4                                          // 00000021CCD4: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x2e8>
	global_load_b32 v2, v[26:27], off                          // 00000021CCD8: DC520000 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021CCE0: BF8903F7
	v_cvt_f16_f32_e32 v10, v2                                  // 00000021CCE4: 7E141502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CCE8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021CCEC: BE812000
	s_cbranch_execz 4                                          // 00000021CCF0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x304>
	global_load_b32 v2, v[26:27], off offset:4                 // 00000021CCF4: DC520004 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021CCFC: BF8903F7
	.long 0x7f141502                                           // 00000021CD00: 7F141502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CD04: 8C7E017E
	.long 0x7f163880                                           // 00000021CD08: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021CD0C: BF870001
	.long 0x7e16398b                                           // 00000021CD10: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 00000021CD14: BE812000
	s_cbranch_execz 4                                          // 00000021CD18: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x32c>
	global_load_b32 v2, v[26:27], off offset:8                 // 00000021CD1C: DC520008 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021CD24: BF8903F7
	v_cvt_f16_f32_e32 v11, v2                                  // 00000021CD28: 7E161502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CD2C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021CD30: BE812000
	s_cbranch_execz 4                                          // 00000021CD34: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x348>
	global_load_b32 v2, v[26:27], off offset:12                // 00000021CD38: DC52000C 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021CD40: BF8903F7
	.long 0x7f161502                                           // 00000021CD44: 7F161502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CD48: 8C7E017E
	.long 0x7f183880                                           // 00000021CD4C: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021CD50: BF870001
	.long 0x7e18398c                                           // 00000021CD54: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 00000021CD58: BE812000
	s_cbranch_execz 4                                          // 00000021CD5C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x370>
	global_load_b32 v2, v[26:27], off offset:16                // 00000021CD60: DC520010 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021CD68: BF8903F7
	v_cvt_f16_f32_e32 v12, v2                                  // 00000021CD6C: 7E181502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CD70: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021CD74: BE812000
	s_cbranch_execz 4                                          // 00000021CD78: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x38c>
	global_load_b32 v2, v[26:27], off offset:20                // 00000021CD7C: DC520014 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021CD84: BF8903F7
	.long 0x7f181502                                           // 00000021CD88: 7F181502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CD8C: 8C7E017E
	.long 0x7f1a3880                                           // 00000021CD90: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021CD94: BF870001
	.long 0x7e1a398d                                           // 00000021CD98: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 00000021CD9C: BE812000
	s_cbranch_execz 4                                          // 00000021CDA0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x3b4>
	global_load_b32 v2, v[26:27], off offset:24                // 00000021CDA4: DC520018 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021CDAC: BF8903F7
	v_cvt_f16_f32_e32 v13, v2                                  // 00000021CDB0: 7E1A1502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CDB4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021CDB8: BE812000
	s_cbranch_execz 4                                          // 00000021CDBC: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x3d0>
	global_load_b32 v2, v[26:27], off offset:28                // 00000021CDC0: DC52001C 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021CDC8: BF8903F7
	.long 0x7f1a1502                                           // 00000021CDCC: 7F1A1502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CDD0: 8C7E017E
	.long 0x7f1c3880                                           // 00000021CDD4: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021CDD8: BF870001
	.long 0x7e1c398e                                           // 00000021CDDC: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000021CDE0: BE812000
	s_cbranch_execz 4                                          // 00000021CDE4: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x3f8>
	global_load_b32 v2, v[26:27], off offset:32                // 00000021CDE8: DC520020 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021CDF0: BF8903F7
	v_cvt_f16_f32_e32 v14, v2                                  // 00000021CDF4: 7E1C1502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CDF8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021CDFC: BE812000
	s_cbranch_execz 4                                          // 00000021CE00: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x414>
	global_load_b32 v2, v[26:27], off offset:36                // 00000021CE04: DC520024 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021CE0C: BF8903F7
	.long 0x7f1c1502                                           // 00000021CE10: 7F1C1502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CE14: 8C7E017E
	.long 0x7f1e3880                                           // 00000021CE18: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021CE1C: BF870001
	.long 0x7e1e398f                                           // 00000021CE20: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 00000021CE24: BE812000
	s_cbranch_execz 4                                          // 00000021CE28: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x43c>
	global_load_b32 v2, v[26:27], off offset:40                // 00000021CE2C: DC520028 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021CE34: BF8903F7
	v_cvt_f16_f32_e32 v15, v2                                  // 00000021CE38: 7E1E1502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CE3C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021CE40: BE812000
	s_cbranch_execz 4                                          // 00000021CE44: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x458>
	global_load_b32 v2, v[26:27], off offset:44                // 00000021CE48: DC52002C 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021CE50: BF8903F7
	.long 0x7f1e1502                                           // 00000021CE54: 7F1E1502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CE58: 8C7E017E
	.long 0x7f203880                                           // 00000021CE5C: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021CE60: BF870001
	.long 0x7e203990                                           // 00000021CE64: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 00000021CE68: BE812000
	s_cbranch_execz 4                                          // 00000021CE6C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x480>
	global_load_b32 v2, v[26:27], off offset:48                // 00000021CE70: DC520030 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021CE78: BF8903F7
	v_cvt_f16_f32_e32 v16, v2                                  // 00000021CE7C: 7E201502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CE80: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021CE84: BE812000
	s_cbranch_execz 4                                          // 00000021CE88: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x49c>
	global_load_b32 v2, v[26:27], off offset:52                // 00000021CE8C: DC520034 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021CE94: BF8903F7
	.long 0x7f201502                                           // 00000021CE98: 7F201502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CE9C: 8C7E017E
	.long 0x7f223880                                           // 00000021CEA0: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021CEA4: BF870001
	.long 0x7e223991                                           // 00000021CEA8: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 00000021CEAC: BE812000
	s_cbranch_execz 4                                          // 00000021CEB0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x4c4>
	global_load_b32 v2, v[26:27], off offset:56                // 00000021CEB4: DC520038 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021CEBC: BF8903F7
	v_cvt_f16_f32_e32 v17, v2                                  // 00000021CEC0: 7E221502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CEC4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021CEC8: BE812000
	s_cbranch_execz 4                                          // 00000021CECC: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x4e0>
	global_load_b32 v2, v[26:27], off offset:60                // 00000021CED0: DC52003C 027C001A
	s_waitcnt vmcnt(0)                                         // 00000021CED8: BF8903F7
	.long 0x7f221502                                           // 00000021CEDC: 7F221502
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CEE0: 8C7E017E
	ds_load_b128 v[35:38], v33                                 // 00000021CEE4: DBFC0000 23000021
	ds_load_b128 v[39:42], v33 offset:16                       // 00000021CEEC: DBFC0010 27000021
	v_mov_b32_e32 v8, v1                                       // 00000021CEF4: 7E100301
	v_mov_b32_e32 v2, v1                                       // 00000021CEF8: 7E040301
	v_mov_b32_e32 v3, v1                                       // 00000021CEFC: 7E060301
	v_mov_b32_e32 v4, v1                                       // 00000021CF00: 7E080301
	v_mov_b32_e32 v5, v1                                       // 00000021CF04: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 00000021CF08: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000021CF0C: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 00000021CF10: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000021CF14: BF870212
	v_mov_b32_e32 v8, v7                                       // 00000021CF18: 7E100307
	v_mov_b32_e32 v7, v6                                       // 00000021CF1C: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 00000021CF20: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 00000021CF24: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 00000021CF28: 7E080303
	v_mov_b32_e32 v3, v2                                       // 00000021CF2C: 7E060302
	v_mov_b32_e32 v2, v1                                       // 00000021CF30: 7E040301
	.long 0x7f243880                                           // 00000021CF34: 7F243880
	s_waitcnt lgkmcnt(0)                                       // 00000021CF38: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021CF3C: BF870112
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 00000021CF40: CC404002 1C0A470A
	.long 0x7e243992                                           // 00000021CF48: 7E243992
	s_and_saveexec_b32 s1, s0                                  // 00000021CF4C: BE812000
	s_cbranch_execz 4                                          // 00000021CF50: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x564>
	global_load_b32 v10, v[26:27], off offset:64               // 00000021CF54: DC520040 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021CF5C: BF8903F7
	v_cvt_f16_f32_e32 v18, v10                                 // 00000021CF60: 7E24150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CF64: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021CF68: BE812000
	s_cbranch_execz 4                                          // 00000021CF6C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x580>
	global_load_b32 v10, v[26:27], off offset:68               // 00000021CF70: DC520044 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021CF78: BF8903F7
	.long 0x7f24150a                                           // 00000021CF7C: 7F24150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CF80: 8C7E017E
	.long 0x7f263880                                           // 00000021CF84: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021CF88: BF870001
	.long 0x7e263993                                           // 00000021CF8C: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000021CF90: BE812000
	s_cbranch_execz 4                                          // 00000021CF94: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x5a8>
	global_load_b32 v10, v[26:27], off offset:72               // 00000021CF98: DC520048 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021CFA0: BF8903F7
	v_cvt_f16_f32_e32 v19, v10                                 // 00000021CFA4: 7E26150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CFA8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021CFAC: BE812000
	s_cbranch_execz 4                                          // 00000021CFB0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x5c4>
	global_load_b32 v10, v[26:27], off offset:76               // 00000021CFB4: DC52004C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021CFBC: BF8903F7
	.long 0x7f26150a                                           // 00000021CFC0: 7F26150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CFC4: 8C7E017E
	.long 0x7f283880                                           // 00000021CFC8: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021CFCC: BF870001
	.long 0x7e283994                                           // 00000021CFD0: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000021CFD4: BE812000
	s_cbranch_execz 4                                          // 00000021CFD8: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x5ec>
	global_load_b32 v10, v[26:27], off offset:80               // 00000021CFDC: DC520050 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021CFE4: BF8903F7
	v_cvt_f16_f32_e32 v20, v10                                 // 00000021CFE8: 7E28150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021CFEC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021CFF0: BE812000
	s_cbranch_execz 4                                          // 00000021CFF4: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x608>
	global_load_b32 v10, v[26:27], off offset:84               // 00000021CFF8: DC520054 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D000: BF8903F7
	.long 0x7f28150a                                           // 00000021D004: 7F28150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D008: 8C7E017E
	.long 0x7f2a3880                                           // 00000021D00C: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D010: BF870001
	.long 0x7e2a3995                                           // 00000021D014: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000021D018: BE812000
	s_cbranch_execz 4                                          // 00000021D01C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x630>
	global_load_b32 v10, v[26:27], off offset:88               // 00000021D020: DC520058 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D028: BF8903F7
	v_cvt_f16_f32_e32 v21, v10                                 // 00000021D02C: 7E2A150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D030: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D034: BE812000
	s_cbranch_execz 4                                          // 00000021D038: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x64c>
	global_load_b32 v10, v[26:27], off offset:92               // 00000021D03C: DC52005C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D044: BF8903F7
	.long 0x7f2a150a                                           // 00000021D048: 7F2A150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D04C: 8C7E017E
	.long 0x7f2c3880                                           // 00000021D050: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D054: BF870001
	.long 0x7e2c3996                                           // 00000021D058: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000021D05C: BE812000
	s_cbranch_execz 4                                          // 00000021D060: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x674>
	global_load_b32 v10, v[26:27], off offset:96               // 00000021D064: DC520060 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D06C: BF8903F7
	v_cvt_f16_f32_e32 v22, v10                                 // 00000021D070: 7E2C150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D074: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D078: BE812000
	s_cbranch_execz 4                                          // 00000021D07C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x690>
	global_load_b32 v10, v[26:27], off offset:100              // 00000021D080: DC520064 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D088: BF8903F7
	.long 0x7f2c150a                                           // 00000021D08C: 7F2C150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D090: 8C7E017E
	.long 0x7f2e3880                                           // 00000021D094: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D098: BF870001
	.long 0x7e2e3997                                           // 00000021D09C: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000021D0A0: BE812000
	s_cbranch_execz 4                                          // 00000021D0A4: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x6b8>
	global_load_b32 v10, v[26:27], off offset:104              // 00000021D0A8: DC520068 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D0B0: BF8903F7
	v_cvt_f16_f32_e32 v23, v10                                 // 00000021D0B4: 7E2E150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D0B8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D0BC: BE812000
	s_cbranch_execz 4                                          // 00000021D0C0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x6d4>
	global_load_b32 v10, v[26:27], off offset:108              // 00000021D0C4: DC52006C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D0CC: BF8903F7
	.long 0x7f2e150a                                           // 00000021D0D0: 7F2E150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D0D4: 8C7E017E
	.long 0x7f303880                                           // 00000021D0D8: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D0DC: BF870001
	.long 0x7e303998                                           // 00000021D0E0: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000021D0E4: BE812000
	s_cbranch_execz 4                                          // 00000021D0E8: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x6fc>
	global_load_b32 v10, v[26:27], off offset:112              // 00000021D0EC: DC520070 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D0F4: BF8903F7
	v_cvt_f16_f32_e32 v24, v10                                 // 00000021D0F8: 7E30150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D0FC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D100: BE812000
	s_cbranch_execz 4                                          // 00000021D104: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x718>
	global_load_b32 v10, v[26:27], off offset:116              // 00000021D108: DC520074 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D110: BF8903F7
	.long 0x7f30150a                                           // 00000021D114: 7F30150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D118: 8C7E017E
	.long 0x7f323880                                           // 00000021D11C: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D120: BF870001
	.long 0x7e323999                                           // 00000021D124: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000021D128: BE812000
	s_cbranch_execz 4                                          // 00000021D12C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x740>
	global_load_b32 v10, v[26:27], off offset:120              // 00000021D130: DC520078 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D138: BF8903F7
	v_cvt_f16_f32_e32 v25, v10                                 // 00000021D13C: 7E32150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D140: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D144: BE812000
	s_cbranch_execz 4                                          // 00000021D148: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x75c>
	global_load_b32 v10, v[26:27], off offset:124              // 00000021D14C: DC52007C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D154: BF8903F7
	.long 0x7f32150a                                           // 00000021D158: 7F32150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D15C: 8C7E017E
	ds_load_b128 v[35:38], v33 offset:32                       // 00000021D160: DBFC0020 23000021
	ds_load_b128 v[39:42], v33 offset:48                       // 00000021D168: DBFC0030 27000021
	.long 0x7f143880                                           // 00000021D170: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D174: BF870001
	.long 0x7e14398a                                           // 00000021D178: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 00000021D17C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 00000021D180: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 00000021D188: BE812000
	s_cbranch_execz 4                                          // 00000021D18C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x7a0>
	global_load_b32 v11, v[26:27], off offset:128              // 00000021D190: DC520080 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D198: BF8903F7
	v_cvt_f16_f32_e32 v10, v11                                 // 00000021D19C: 7E14150B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D1A0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D1A4: BE812000
	s_cbranch_execz 4                                          // 00000021D1A8: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x7bc>
	global_load_b32 v11, v[26:27], off offset:132              // 00000021D1AC: DC520084 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D1B4: BF8903F7
	.long 0x7f14150b                                           // 00000021D1B8: 7F14150B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D1BC: 8C7E017E
	.long 0x7f163880                                           // 00000021D1C0: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D1C4: BF870001
	.long 0x7e16398b                                           // 00000021D1C8: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 00000021D1CC: BE812000
	s_cbranch_execz 4                                          // 00000021D1D0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x7e4>
	global_load_b32 v12, v[26:27], off offset:136              // 00000021D1D4: DC520088 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D1DC: BF8903F7
	v_cvt_f16_f32_e32 v11, v12                                 // 00000021D1E0: 7E16150C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D1E4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D1E8: BE812000
	s_cbranch_execz 4                                          // 00000021D1EC: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x800>
	global_load_b32 v12, v[26:27], off offset:140              // 00000021D1F0: DC52008C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D1F8: BF8903F7
	.long 0x7f16150c                                           // 00000021D1FC: 7F16150C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D200: 8C7E017E
	.long 0x7f183880                                           // 00000021D204: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D208: BF870001
	.long 0x7e18398c                                           // 00000021D20C: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 00000021D210: BE812000
	s_cbranch_execz 4                                          // 00000021D214: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x828>
	global_load_b32 v13, v[26:27], off offset:144              // 00000021D218: DC520090 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D220: BF8903F7
	v_cvt_f16_f32_e32 v12, v13                                 // 00000021D224: 7E18150D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D228: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D22C: BE812000
	s_cbranch_execz 4                                          // 00000021D230: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x844>
	global_load_b32 v13, v[26:27], off offset:148              // 00000021D234: DC520094 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D23C: BF8903F7
	.long 0x7f18150d                                           // 00000021D240: 7F18150D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D244: 8C7E017E
	.long 0x7f1a3880                                           // 00000021D248: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D24C: BF870001
	.long 0x7e1a398d                                           // 00000021D250: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 00000021D254: BE812000
	s_cbranch_execz 4                                          // 00000021D258: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x86c>
	global_load_b32 v14, v[26:27], off offset:152              // 00000021D25C: DC520098 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D264: BF8903F7
	v_cvt_f16_f32_e32 v13, v14                                 // 00000021D268: 7E1A150E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D26C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D270: BE812000
	s_cbranch_execz 4                                          // 00000021D274: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x888>
	global_load_b32 v14, v[26:27], off offset:156              // 00000021D278: DC52009C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D280: BF8903F7
	.long 0x7f1a150e                                           // 00000021D284: 7F1A150E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D288: 8C7E017E
	.long 0x7f1c3880                                           // 00000021D28C: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D290: BF870001
	.long 0x7e1c398e                                           // 00000021D294: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000021D298: BE812000
	s_cbranch_execz 4                                          // 00000021D29C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x8b0>
	global_load_b32 v15, v[26:27], off offset:160              // 00000021D2A0: DC5200A0 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D2A8: BF8903F7
	v_cvt_f16_f32_e32 v14, v15                                 // 00000021D2AC: 7E1C150F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D2B0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D2B4: BE812000
	s_cbranch_execz 4                                          // 00000021D2B8: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x8cc>
	global_load_b32 v15, v[26:27], off offset:164              // 00000021D2BC: DC5200A4 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D2C4: BF8903F7
	.long 0x7f1c150f                                           // 00000021D2C8: 7F1C150F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D2CC: 8C7E017E
	.long 0x7f1e3880                                           // 00000021D2D0: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D2D4: BF870001
	.long 0x7e1e398f                                           // 00000021D2D8: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 00000021D2DC: BE812000
	s_cbranch_execz 4                                          // 00000021D2E0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x8f4>
	global_load_b32 v16, v[26:27], off offset:168              // 00000021D2E4: DC5200A8 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021D2EC: BF8903F7
	v_cvt_f16_f32_e32 v15, v16                                 // 00000021D2F0: 7E1E1510
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D2F4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D2F8: BE812000
	s_cbranch_execz 4                                          // 00000021D2FC: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x910>
	global_load_b32 v16, v[26:27], off offset:172              // 00000021D300: DC5200AC 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021D308: BF8903F7
	.long 0x7f1e1510                                           // 00000021D30C: 7F1E1510
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D310: 8C7E017E
	.long 0x7f203880                                           // 00000021D314: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D318: BF870001
	.long 0x7e203990                                           // 00000021D31C: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 00000021D320: BE812000
	s_cbranch_execz 4                                          // 00000021D324: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x938>
	global_load_b32 v17, v[26:27], off offset:176              // 00000021D328: DC5200B0 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021D330: BF8903F7
	v_cvt_f16_f32_e32 v16, v17                                 // 00000021D334: 7E201511
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D338: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D33C: BE812000
	s_cbranch_execz 4                                          // 00000021D340: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x954>
	global_load_b32 v17, v[26:27], off offset:180              // 00000021D344: DC5200B4 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021D34C: BF8903F7
	.long 0x7f201511                                           // 00000021D350: 7F201511
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D354: 8C7E017E
	.long 0x7f223880                                           // 00000021D358: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D35C: BF870001
	.long 0x7e223991                                           // 00000021D360: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 00000021D364: BE812000
	s_cbranch_execz 4                                          // 00000021D368: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x97c>
	global_load_b32 v18, v[26:27], off offset:184              // 00000021D36C: DC5200B8 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021D374: BF8903F7
	v_cvt_f16_f32_e32 v17, v18                                 // 00000021D378: 7E221512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D37C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D380: BE812000
	s_cbranch_execz 4                                          // 00000021D384: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x998>
	global_load_b32 v18, v[26:27], off offset:188              // 00000021D388: DC5200BC 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021D390: BF8903F7
	.long 0x7f221512                                           // 00000021D394: 7F221512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D398: 8C7E017E
	ds_load_b128 v[35:38], v33 offset:64                       // 00000021D39C: DBFC0040 23000021
	ds_load_b128 v[39:42], v33 offset:80                       // 00000021D3A4: DBFC0050 27000021
	.long 0x7f243880                                           // 00000021D3AC: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D3B0: BF870001
	.long 0x7e243992                                           // 00000021D3B4: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 00000021D3B8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 00000021D3BC: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 00000021D3C4: BE812000
	s_cbranch_execz 4                                          // 00000021D3C8: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x9dc>
	global_load_b32 v10, v[26:27], off offset:192              // 00000021D3CC: DC5200C0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D3D4: BF8903F7
	v_cvt_f16_f32_e32 v18, v10                                 // 00000021D3D8: 7E24150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D3DC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D3E0: BE812000
	s_cbranch_execz 4                                          // 00000021D3E4: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x9f8>
	global_load_b32 v10, v[26:27], off offset:196              // 00000021D3E8: DC5200C4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D3F0: BF8903F7
	.long 0x7f24150a                                           // 00000021D3F4: 7F24150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D3F8: 8C7E017E
	.long 0x7f263880                                           // 00000021D3FC: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D400: BF870001
	.long 0x7e263993                                           // 00000021D404: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000021D408: BE812000
	s_cbranch_execz 4                                          // 00000021D40C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xa20>
	global_load_b32 v10, v[26:27], off offset:200              // 00000021D410: DC5200C8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D418: BF8903F7
	v_cvt_f16_f32_e32 v19, v10                                 // 00000021D41C: 7E26150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D420: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D424: BE812000
	s_cbranch_execz 4                                          // 00000021D428: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xa3c>
	global_load_b32 v10, v[26:27], off offset:204              // 00000021D42C: DC5200CC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D434: BF8903F7
	.long 0x7f26150a                                           // 00000021D438: 7F26150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D43C: 8C7E017E
	.long 0x7f283880                                           // 00000021D440: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D444: BF870001
	.long 0x7e283994                                           // 00000021D448: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000021D44C: BE812000
	s_cbranch_execz 4                                          // 00000021D450: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xa64>
	global_load_b32 v10, v[26:27], off offset:208              // 00000021D454: DC5200D0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D45C: BF8903F7
	v_cvt_f16_f32_e32 v20, v10                                 // 00000021D460: 7E28150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D464: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D468: BE812000
	s_cbranch_execz 4                                          // 00000021D46C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xa80>
	global_load_b32 v10, v[26:27], off offset:212              // 00000021D470: DC5200D4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D478: BF8903F7
	.long 0x7f28150a                                           // 00000021D47C: 7F28150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D480: 8C7E017E
	.long 0x7f2a3880                                           // 00000021D484: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D488: BF870001
	.long 0x7e2a3995                                           // 00000021D48C: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000021D490: BE812000
	s_cbranch_execz 4                                          // 00000021D494: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xaa8>
	global_load_b32 v10, v[26:27], off offset:216              // 00000021D498: DC5200D8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D4A0: BF8903F7
	v_cvt_f16_f32_e32 v21, v10                                 // 00000021D4A4: 7E2A150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D4A8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D4AC: BE812000
	s_cbranch_execz 4                                          // 00000021D4B0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xac4>
	global_load_b32 v10, v[26:27], off offset:220              // 00000021D4B4: DC5200DC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D4BC: BF8903F7
	.long 0x7f2a150a                                           // 00000021D4C0: 7F2A150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D4C4: 8C7E017E
	.long 0x7f2c3880                                           // 00000021D4C8: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D4CC: BF870001
	.long 0x7e2c3996                                           // 00000021D4D0: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000021D4D4: BE812000
	s_cbranch_execz 4                                          // 00000021D4D8: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xaec>
	global_load_b32 v10, v[26:27], off offset:224              // 00000021D4DC: DC5200E0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D4E4: BF8903F7
	v_cvt_f16_f32_e32 v22, v10                                 // 00000021D4E8: 7E2C150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D4EC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D4F0: BE812000
	s_cbranch_execz 4                                          // 00000021D4F4: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xb08>
	global_load_b32 v10, v[26:27], off offset:228              // 00000021D4F8: DC5200E4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D500: BF8903F7
	.long 0x7f2c150a                                           // 00000021D504: 7F2C150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D508: 8C7E017E
	.long 0x7f2e3880                                           // 00000021D50C: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D510: BF870001
	.long 0x7e2e3997                                           // 00000021D514: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000021D518: BE812000
	s_cbranch_execz 4                                          // 00000021D51C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xb30>
	global_load_b32 v10, v[26:27], off offset:232              // 00000021D520: DC5200E8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D528: BF8903F7
	v_cvt_f16_f32_e32 v23, v10                                 // 00000021D52C: 7E2E150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D530: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D534: BE812000
	s_cbranch_execz 4                                          // 00000021D538: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xb4c>
	global_load_b32 v10, v[26:27], off offset:236              // 00000021D53C: DC5200EC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D544: BF8903F7
	.long 0x7f2e150a                                           // 00000021D548: 7F2E150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D54C: 8C7E017E
	.long 0x7f303880                                           // 00000021D550: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D554: BF870001
	.long 0x7e303998                                           // 00000021D558: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000021D55C: BE812000
	s_cbranch_execz 4                                          // 00000021D560: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xb74>
	global_load_b32 v10, v[26:27], off offset:240              // 00000021D564: DC5200F0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D56C: BF8903F7
	v_cvt_f16_f32_e32 v24, v10                                 // 00000021D570: 7E30150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D574: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D578: BE812000
	s_cbranch_execz 4                                          // 00000021D57C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xb90>
	global_load_b32 v10, v[26:27], off offset:244              // 00000021D580: DC5200F4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D588: BF8903F7
	.long 0x7f30150a                                           // 00000021D58C: 7F30150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D590: 8C7E017E
	.long 0x7f323880                                           // 00000021D594: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D598: BF870001
	.long 0x7e323999                                           // 00000021D59C: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000021D5A0: BE812000
	s_cbranch_execz 4                                          // 00000021D5A4: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xbb8>
	global_load_b32 v10, v[26:27], off offset:248              // 00000021D5A8: DC5200F8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D5B0: BF8903F7
	v_cvt_f16_f32_e32 v25, v10                                 // 00000021D5B4: 7E32150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D5B8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D5BC: BE812000
	s_cbranch_execz 4                                          // 00000021D5C0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xbd4>
	global_load_b32 v10, v[26:27], off offset:252              // 00000021D5C4: DC5200FC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D5CC: BF8903F7
	.long 0x7f32150a                                           // 00000021D5D0: 7F32150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D5D4: 8C7E017E
	ds_load_b128 v[35:38], v33 offset:96                       // 00000021D5D8: DBFC0060 23000021
	ds_load_b128 v[39:42], v33 offset:112                      // 00000021D5E0: DBFC0070 27000021
	.long 0x7f143880                                           // 00000021D5E8: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D5EC: BF870001
	.long 0x7e14398a                                           // 00000021D5F0: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 00000021D5F4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 00000021D5F8: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 00000021D600: BE812000
	s_cbranch_execz 4                                          // 00000021D604: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xc18>
	global_load_b32 v11, v[26:27], off offset:256              // 00000021D608: DC520100 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D610: BF8903F7
	v_cvt_f16_f32_e32 v10, v11                                 // 00000021D614: 7E14150B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D618: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D61C: BE812000
	s_cbranch_execz 4                                          // 00000021D620: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xc34>
	global_load_b32 v11, v[26:27], off offset:260              // 00000021D624: DC520104 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D62C: BF8903F7
	.long 0x7f14150b                                           // 00000021D630: 7F14150B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D634: 8C7E017E
	.long 0x7f163880                                           // 00000021D638: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D63C: BF870001
	.long 0x7e16398b                                           // 00000021D640: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 00000021D644: BE812000
	s_cbranch_execz 4                                          // 00000021D648: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xc5c>
	global_load_b32 v12, v[26:27], off offset:264              // 00000021D64C: DC520108 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D654: BF8903F7
	v_cvt_f16_f32_e32 v11, v12                                 // 00000021D658: 7E16150C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D65C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D660: BE812000
	s_cbranch_execz 4                                          // 00000021D664: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xc78>
	global_load_b32 v12, v[26:27], off offset:268              // 00000021D668: DC52010C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D670: BF8903F7
	.long 0x7f16150c                                           // 00000021D674: 7F16150C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D678: 8C7E017E
	.long 0x7f183880                                           // 00000021D67C: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D680: BF870001
	.long 0x7e18398c                                           // 00000021D684: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 00000021D688: BE812000
	s_cbranch_execz 4                                          // 00000021D68C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xca0>
	global_load_b32 v13, v[26:27], off offset:272              // 00000021D690: DC520110 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D698: BF8903F7
	v_cvt_f16_f32_e32 v12, v13                                 // 00000021D69C: 7E18150D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D6A0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D6A4: BE812000
	s_cbranch_execz 4                                          // 00000021D6A8: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xcbc>
	global_load_b32 v13, v[26:27], off offset:276              // 00000021D6AC: DC520114 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D6B4: BF8903F7
	.long 0x7f18150d                                           // 00000021D6B8: 7F18150D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D6BC: 8C7E017E
	.long 0x7f1a3880                                           // 00000021D6C0: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D6C4: BF870001
	.long 0x7e1a398d                                           // 00000021D6C8: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 00000021D6CC: BE812000
	s_cbranch_execz 4                                          // 00000021D6D0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xce4>
	global_load_b32 v14, v[26:27], off offset:280              // 00000021D6D4: DC520118 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D6DC: BF8903F7
	v_cvt_f16_f32_e32 v13, v14                                 // 00000021D6E0: 7E1A150E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D6E4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D6E8: BE812000
	s_cbranch_execz 4                                          // 00000021D6EC: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xd00>
	global_load_b32 v14, v[26:27], off offset:284              // 00000021D6F0: DC52011C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D6F8: BF8903F7
	.long 0x7f1a150e                                           // 00000021D6FC: 7F1A150E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D700: 8C7E017E
	.long 0x7f1c3880                                           // 00000021D704: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D708: BF870001
	.long 0x7e1c398e                                           // 00000021D70C: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000021D710: BE812000
	s_cbranch_execz 4                                          // 00000021D714: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xd28>
	global_load_b32 v15, v[26:27], off offset:288              // 00000021D718: DC520120 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D720: BF8903F7
	v_cvt_f16_f32_e32 v14, v15                                 // 00000021D724: 7E1C150F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D728: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D72C: BE812000
	s_cbranch_execz 4                                          // 00000021D730: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xd44>
	global_load_b32 v15, v[26:27], off offset:292              // 00000021D734: DC520124 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D73C: BF8903F7
	.long 0x7f1c150f                                           // 00000021D740: 7F1C150F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D744: 8C7E017E
	.long 0x7f1e3880                                           // 00000021D748: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D74C: BF870001
	.long 0x7e1e398f                                           // 00000021D750: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 00000021D754: BE812000
	s_cbranch_execz 4                                          // 00000021D758: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xd6c>
	global_load_b32 v16, v[26:27], off offset:296              // 00000021D75C: DC520128 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021D764: BF8903F7
	v_cvt_f16_f32_e32 v15, v16                                 // 00000021D768: 7E1E1510
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D76C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D770: BE812000
	s_cbranch_execz 4                                          // 00000021D774: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xd88>
	global_load_b32 v16, v[26:27], off offset:300              // 00000021D778: DC52012C 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021D780: BF8903F7
	.long 0x7f1e1510                                           // 00000021D784: 7F1E1510
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D788: 8C7E017E
	.long 0x7f203880                                           // 00000021D78C: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D790: BF870001
	.long 0x7e203990                                           // 00000021D794: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 00000021D798: BE812000
	s_cbranch_execz 4                                          // 00000021D79C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xdb0>
	global_load_b32 v17, v[26:27], off offset:304              // 00000021D7A0: DC520130 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021D7A8: BF8903F7
	v_cvt_f16_f32_e32 v16, v17                                 // 00000021D7AC: 7E201511
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D7B0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D7B4: BE812000
	s_cbranch_execz 4                                          // 00000021D7B8: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xdcc>
	global_load_b32 v17, v[26:27], off offset:308              // 00000021D7BC: DC520134 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021D7C4: BF8903F7
	.long 0x7f201511                                           // 00000021D7C8: 7F201511
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D7CC: 8C7E017E
	.long 0x7f223880                                           // 00000021D7D0: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D7D4: BF870001
	.long 0x7e223991                                           // 00000021D7D8: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 00000021D7DC: BE812000
	s_cbranch_execz 4                                          // 00000021D7E0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xdf4>
	global_load_b32 v18, v[26:27], off offset:312              // 00000021D7E4: DC520138 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021D7EC: BF8903F7
	v_cvt_f16_f32_e32 v17, v18                                 // 00000021D7F0: 7E221512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D7F4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D7F8: BE812000
	s_cbranch_execz 4                                          // 00000021D7FC: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xe10>
	global_load_b32 v18, v[26:27], off offset:316              // 00000021D800: DC52013C 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021D808: BF8903F7
	.long 0x7f221512                                           // 00000021D80C: 7F221512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D810: 8C7E017E
	ds_load_b128 v[35:38], v33 offset:128                      // 00000021D814: DBFC0080 23000021
	ds_load_b128 v[39:42], v33 offset:144                      // 00000021D81C: DBFC0090 27000021
	.long 0x7f243880                                           // 00000021D824: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D828: BF870001
	.long 0x7e243992                                           // 00000021D82C: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 00000021D830: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 00000021D834: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 00000021D83C: BE812000
	s_cbranch_execz 4                                          // 00000021D840: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xe54>
	global_load_b32 v10, v[26:27], off offset:320              // 00000021D844: DC520140 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D84C: BF8903F7
	v_cvt_f16_f32_e32 v18, v10                                 // 00000021D850: 7E24150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D854: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D858: BE812000
	s_cbranch_execz 4                                          // 00000021D85C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xe70>
	global_load_b32 v10, v[26:27], off offset:324              // 00000021D860: DC520144 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D868: BF8903F7
	.long 0x7f24150a                                           // 00000021D86C: 7F24150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D870: 8C7E017E
	.long 0x7f263880                                           // 00000021D874: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D878: BF870001
	.long 0x7e263993                                           // 00000021D87C: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000021D880: BE812000
	s_cbranch_execz 4                                          // 00000021D884: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xe98>
	global_load_b32 v10, v[26:27], off offset:328              // 00000021D888: DC520148 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D890: BF8903F7
	v_cvt_f16_f32_e32 v19, v10                                 // 00000021D894: 7E26150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D898: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D89C: BE812000
	s_cbranch_execz 4                                          // 00000021D8A0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xeb4>
	global_load_b32 v10, v[26:27], off offset:332              // 00000021D8A4: DC52014C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D8AC: BF8903F7
	.long 0x7f26150a                                           // 00000021D8B0: 7F26150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D8B4: 8C7E017E
	.long 0x7f283880                                           // 00000021D8B8: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D8BC: BF870001
	.long 0x7e283994                                           // 00000021D8C0: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000021D8C4: BE812000
	s_cbranch_execz 4                                          // 00000021D8C8: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xedc>
	global_load_b32 v10, v[26:27], off offset:336              // 00000021D8CC: DC520150 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D8D4: BF8903F7
	v_cvt_f16_f32_e32 v20, v10                                 // 00000021D8D8: 7E28150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D8DC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D8E0: BE812000
	s_cbranch_execz 4                                          // 00000021D8E4: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xef8>
	global_load_b32 v10, v[26:27], off offset:340              // 00000021D8E8: DC520154 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D8F0: BF8903F7
	.long 0x7f28150a                                           // 00000021D8F4: 7F28150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D8F8: 8C7E017E
	.long 0x7f2a3880                                           // 00000021D8FC: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D900: BF870001
	.long 0x7e2a3995                                           // 00000021D904: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000021D908: BE812000
	s_cbranch_execz 4                                          // 00000021D90C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xf20>
	global_load_b32 v10, v[26:27], off offset:344              // 00000021D910: DC520158 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D918: BF8903F7
	v_cvt_f16_f32_e32 v21, v10                                 // 00000021D91C: 7E2A150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D920: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D924: BE812000
	s_cbranch_execz 4                                          // 00000021D928: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xf3c>
	global_load_b32 v10, v[26:27], off offset:348              // 00000021D92C: DC52015C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D934: BF8903F7
	.long 0x7f2a150a                                           // 00000021D938: 7F2A150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D93C: 8C7E017E
	.long 0x7f2c3880                                           // 00000021D940: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D944: BF870001
	.long 0x7e2c3996                                           // 00000021D948: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000021D94C: BE812000
	s_cbranch_execz 4                                          // 00000021D950: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xf64>
	global_load_b32 v10, v[26:27], off offset:352              // 00000021D954: DC520160 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D95C: BF8903F7
	v_cvt_f16_f32_e32 v22, v10                                 // 00000021D960: 7E2C150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D964: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D968: BE812000
	s_cbranch_execz 4                                          // 00000021D96C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xf80>
	global_load_b32 v10, v[26:27], off offset:356              // 00000021D970: DC520164 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D978: BF8903F7
	.long 0x7f2c150a                                           // 00000021D97C: 7F2C150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D980: 8C7E017E
	.long 0x7f2e3880                                           // 00000021D984: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D988: BF870001
	.long 0x7e2e3997                                           // 00000021D98C: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000021D990: BE812000
	s_cbranch_execz 4                                          // 00000021D994: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xfa8>
	global_load_b32 v10, v[26:27], off offset:360              // 00000021D998: DC520168 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D9A0: BF8903F7
	v_cvt_f16_f32_e32 v23, v10                                 // 00000021D9A4: 7E2E150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D9A8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D9AC: BE812000
	s_cbranch_execz 4                                          // 00000021D9B0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xfc4>
	global_load_b32 v10, v[26:27], off offset:364              // 00000021D9B4: DC52016C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D9BC: BF8903F7
	.long 0x7f2e150a                                           // 00000021D9C0: 7F2E150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D9C4: 8C7E017E
	.long 0x7f303880                                           // 00000021D9C8: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021D9CC: BF870001
	.long 0x7e303998                                           // 00000021D9D0: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000021D9D4: BE812000
	s_cbranch_execz 4                                          // 00000021D9D8: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0xfec>
	global_load_b32 v10, v[26:27], off offset:368              // 00000021D9DC: DC520170 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021D9E4: BF8903F7
	v_cvt_f16_f32_e32 v24, v10                                 // 00000021D9E8: 7E30150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021D9EC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021D9F0: BE812000
	s_cbranch_execz 4                                          // 00000021D9F4: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1008>
	global_load_b32 v10, v[26:27], off offset:372              // 00000021D9F8: DC520174 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DA00: BF8903F7
	.long 0x7f30150a                                           // 00000021DA04: 7F30150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DA08: 8C7E017E
	.long 0x7f323880                                           // 00000021DA0C: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DA10: BF870001
	.long 0x7e323999                                           // 00000021DA14: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000021DA18: BE812000
	s_cbranch_execz 4                                          // 00000021DA1C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1030>
	global_load_b32 v10, v[26:27], off offset:376              // 00000021DA20: DC520178 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DA28: BF8903F7
	v_cvt_f16_f32_e32 v25, v10                                 // 00000021DA2C: 7E32150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DA30: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DA34: BE812000
	s_cbranch_execz 4                                          // 00000021DA38: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x104c>
	global_load_b32 v10, v[26:27], off offset:380              // 00000021DA3C: DC52017C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DA44: BF8903F7
	.long 0x7f32150a                                           // 00000021DA48: 7F32150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DA4C: 8C7E017E
	ds_load_b128 v[35:38], v33 offset:160                      // 00000021DA50: DBFC00A0 23000021
	ds_load_b128 v[39:42], v33 offset:176                      // 00000021DA58: DBFC00B0 27000021
	.long 0x7f143880                                           // 00000021DA60: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DA64: BF870001
	.long 0x7e14398a                                           // 00000021DA68: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 00000021DA6C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 00000021DA70: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 00000021DA78: BE812000
	s_cbranch_execz 4                                          // 00000021DA7C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1090>
	global_load_b32 v11, v[26:27], off offset:384              // 00000021DA80: DC520180 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DA88: BF8903F7
	v_cvt_f16_f32_e32 v10, v11                                 // 00000021DA8C: 7E14150B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DA90: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DA94: BE812000
	s_cbranch_execz 4                                          // 00000021DA98: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x10ac>
	global_load_b32 v11, v[26:27], off offset:388              // 00000021DA9C: DC520184 0B7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DAA4: BF8903F7
	.long 0x7f14150b                                           // 00000021DAA8: 7F14150B
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DAAC: 8C7E017E
	.long 0x7f163880                                           // 00000021DAB0: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DAB4: BF870001
	.long 0x7e16398b                                           // 00000021DAB8: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 00000021DABC: BE812000
	s_cbranch_execz 4                                          // 00000021DAC0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x10d4>
	global_load_b32 v12, v[26:27], off offset:392              // 00000021DAC4: DC520188 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DACC: BF8903F7
	v_cvt_f16_f32_e32 v11, v12                                 // 00000021DAD0: 7E16150C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DAD4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DAD8: BE812000
	s_cbranch_execz 4                                          // 00000021DADC: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x10f0>
	global_load_b32 v12, v[26:27], off offset:396              // 00000021DAE0: DC52018C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DAE8: BF8903F7
	.long 0x7f16150c                                           // 00000021DAEC: 7F16150C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DAF0: 8C7E017E
	.long 0x7f183880                                           // 00000021DAF4: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DAF8: BF870001
	.long 0x7e18398c                                           // 00000021DAFC: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 00000021DB00: BE812000
	s_cbranch_execz 4                                          // 00000021DB04: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1118>
	global_load_b32 v13, v[26:27], off offset:400              // 00000021DB08: DC520190 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DB10: BF8903F7
	v_cvt_f16_f32_e32 v12, v13                                 // 00000021DB14: 7E18150D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DB18: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DB1C: BE812000
	s_cbranch_execz 4                                          // 00000021DB20: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1134>
	global_load_b32 v13, v[26:27], off offset:404              // 00000021DB24: DC520194 0D7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DB2C: BF8903F7
	.long 0x7f18150d                                           // 00000021DB30: 7F18150D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DB34: 8C7E017E
	.long 0x7f1a3880                                           // 00000021DB38: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DB3C: BF870001
	.long 0x7e1a398d                                           // 00000021DB40: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 00000021DB44: BE812000
	s_cbranch_execz 4                                          // 00000021DB48: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x115c>
	global_load_b32 v14, v[26:27], off offset:408              // 00000021DB4C: DC520198 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DB54: BF8903F7
	v_cvt_f16_f32_e32 v13, v14                                 // 00000021DB58: 7E1A150E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DB5C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DB60: BE812000
	s_cbranch_execz 4                                          // 00000021DB64: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1178>
	global_load_b32 v14, v[26:27], off offset:412              // 00000021DB68: DC52019C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DB70: BF8903F7
	.long 0x7f1a150e                                           // 00000021DB74: 7F1A150E
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DB78: 8C7E017E
	.long 0x7f1c3880                                           // 00000021DB7C: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DB80: BF870001
	.long 0x7e1c398e                                           // 00000021DB84: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000021DB88: BE812000
	s_cbranch_execz 4                                          // 00000021DB8C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x11a0>
	global_load_b32 v15, v[26:27], off offset:416              // 00000021DB90: DC5201A0 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DB98: BF8903F7
	v_cvt_f16_f32_e32 v14, v15                                 // 00000021DB9C: 7E1C150F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DBA0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DBA4: BE812000
	s_cbranch_execz 4                                          // 00000021DBA8: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x11bc>
	global_load_b32 v15, v[26:27], off offset:420              // 00000021DBAC: DC5201A4 0F7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DBB4: BF8903F7
	.long 0x7f1c150f                                           // 00000021DBB8: 7F1C150F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DBBC: 8C7E017E
	.long 0x7f1e3880                                           // 00000021DBC0: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DBC4: BF870001
	.long 0x7e1e398f                                           // 00000021DBC8: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 00000021DBCC: BE812000
	s_cbranch_execz 4                                          // 00000021DBD0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x11e4>
	global_load_b32 v16, v[26:27], off offset:424              // 00000021DBD4: DC5201A8 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021DBDC: BF8903F7
	v_cvt_f16_f32_e32 v15, v16                                 // 00000021DBE0: 7E1E1510
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DBE4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DBE8: BE812000
	s_cbranch_execz 4                                          // 00000021DBEC: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1200>
	global_load_b32 v16, v[26:27], off offset:428              // 00000021DBF0: DC5201AC 107C001A
	s_waitcnt vmcnt(0)                                         // 00000021DBF8: BF8903F7
	.long 0x7f1e1510                                           // 00000021DBFC: 7F1E1510
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DC00: 8C7E017E
	.long 0x7f203880                                           // 00000021DC04: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DC08: BF870001
	.long 0x7e203990                                           // 00000021DC0C: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 00000021DC10: BE812000
	s_cbranch_execz 4                                          // 00000021DC14: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1228>
	global_load_b32 v17, v[26:27], off offset:432              // 00000021DC18: DC5201B0 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021DC20: BF8903F7
	v_cvt_f16_f32_e32 v16, v17                                 // 00000021DC24: 7E201511
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DC28: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DC2C: BE812000
	s_cbranch_execz 4                                          // 00000021DC30: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1244>
	global_load_b32 v17, v[26:27], off offset:436              // 00000021DC34: DC5201B4 117C001A
	s_waitcnt vmcnt(0)                                         // 00000021DC3C: BF8903F7
	.long 0x7f201511                                           // 00000021DC40: 7F201511
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DC44: 8C7E017E
	.long 0x7f223880                                           // 00000021DC48: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DC4C: BF870001
	.long 0x7e223991                                           // 00000021DC50: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 00000021DC54: BE812000
	s_cbranch_execz 4                                          // 00000021DC58: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x126c>
	global_load_b32 v18, v[26:27], off offset:440              // 00000021DC5C: DC5201B8 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021DC64: BF8903F7
	v_cvt_f16_f32_e32 v17, v18                                 // 00000021DC68: 7E221512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DC6C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DC70: BE812000
	s_cbranch_execz 4                                          // 00000021DC74: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1288>
	global_load_b32 v18, v[26:27], off offset:444              // 00000021DC78: DC5201BC 127C001A
	s_waitcnt vmcnt(0)                                         // 00000021DC80: BF8903F7
	.long 0x7f221512                                           // 00000021DC84: 7F221512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DC88: 8C7E017E
	ds_load_b128 v[35:38], v33 offset:192                      // 00000021DC8C: DBFC00C0 23000021
	ds_load_b128 v[39:42], v33 offset:208                      // 00000021DC94: DBFC00D0 27000021
	.long 0x7f243880                                           // 00000021DC9C: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DCA0: BF870001
	.long 0x7e243992                                           // 00000021DCA4: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 00000021DCA8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 00000021DCAC: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 00000021DCB4: BE812000
	s_cbranch_execz 4                                          // 00000021DCB8: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x12cc>
	global_load_b32 v10, v[26:27], off offset:448              // 00000021DCBC: DC5201C0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DCC4: BF8903F7
	v_cvt_f16_f32_e32 v18, v10                                 // 00000021DCC8: 7E24150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DCCC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DCD0: BE812000
	s_cbranch_execz 4                                          // 00000021DCD4: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x12e8>
	global_load_b32 v10, v[26:27], off offset:452              // 00000021DCD8: DC5201C4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DCE0: BF8903F7
	.long 0x7f24150a                                           // 00000021DCE4: 7F24150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DCE8: 8C7E017E
	.long 0x7f263880                                           // 00000021DCEC: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DCF0: BF870001
	.long 0x7e263993                                           // 00000021DCF4: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000021DCF8: BE812000
	s_cbranch_execz 4                                          // 00000021DCFC: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1310>
	global_load_b32 v10, v[26:27], off offset:456              // 00000021DD00: DC5201C8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DD08: BF8903F7
	v_cvt_f16_f32_e32 v19, v10                                 // 00000021DD0C: 7E26150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DD10: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DD14: BE812000
	s_cbranch_execz 4                                          // 00000021DD18: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x132c>
	global_load_b32 v10, v[26:27], off offset:460              // 00000021DD1C: DC5201CC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DD24: BF8903F7
	.long 0x7f26150a                                           // 00000021DD28: 7F26150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DD2C: 8C7E017E
	.long 0x7f283880                                           // 00000021DD30: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DD34: BF870001
	.long 0x7e283994                                           // 00000021DD38: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000021DD3C: BE812000
	s_cbranch_execz 4                                          // 00000021DD40: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1354>
	global_load_b32 v10, v[26:27], off offset:464              // 00000021DD44: DC5201D0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DD4C: BF8903F7
	v_cvt_f16_f32_e32 v20, v10                                 // 00000021DD50: 7E28150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DD54: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DD58: BE812000
	s_cbranch_execz 4                                          // 00000021DD5C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1370>
	global_load_b32 v10, v[26:27], off offset:468              // 00000021DD60: DC5201D4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DD68: BF8903F7
	.long 0x7f28150a                                           // 00000021DD6C: 7F28150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DD70: 8C7E017E
	.long 0x7f2a3880                                           // 00000021DD74: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DD78: BF870001
	.long 0x7e2a3995                                           // 00000021DD7C: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000021DD80: BE812000
	s_cbranch_execz 4                                          // 00000021DD84: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1398>
	global_load_b32 v10, v[26:27], off offset:472              // 00000021DD88: DC5201D8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DD90: BF8903F7
	v_cvt_f16_f32_e32 v21, v10                                 // 00000021DD94: 7E2A150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DD98: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DD9C: BE812000
	s_cbranch_execz 4                                          // 00000021DDA0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x13b4>
	global_load_b32 v10, v[26:27], off offset:476              // 00000021DDA4: DC5201DC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DDAC: BF8903F7
	.long 0x7f2a150a                                           // 00000021DDB0: 7F2A150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DDB4: 8C7E017E
	.long 0x7f2c3880                                           // 00000021DDB8: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DDBC: BF870001
	.long 0x7e2c3996                                           // 00000021DDC0: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000021DDC4: BE812000
	s_cbranch_execz 4                                          // 00000021DDC8: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x13dc>
	global_load_b32 v10, v[26:27], off offset:480              // 00000021DDCC: DC5201E0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DDD4: BF8903F7
	v_cvt_f16_f32_e32 v22, v10                                 // 00000021DDD8: 7E2C150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DDDC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DDE0: BE812000
	s_cbranch_execz 4                                          // 00000021DDE4: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x13f8>
	global_load_b32 v10, v[26:27], off offset:484              // 00000021DDE8: DC5201E4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DDF0: BF8903F7
	.long 0x7f2c150a                                           // 00000021DDF4: 7F2C150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DDF8: 8C7E017E
	.long 0x7f2e3880                                           // 00000021DDFC: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DE00: BF870001
	.long 0x7e2e3997                                           // 00000021DE04: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000021DE08: BE812000
	s_cbranch_execz 4                                          // 00000021DE0C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1420>
	global_load_b32 v10, v[26:27], off offset:488              // 00000021DE10: DC5201E8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DE18: BF8903F7
	v_cvt_f16_f32_e32 v23, v10                                 // 00000021DE1C: 7E2E150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DE20: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DE24: BE812000
	s_cbranch_execz 4                                          // 00000021DE28: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x143c>
	global_load_b32 v10, v[26:27], off offset:492              // 00000021DE2C: DC5201EC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DE34: BF8903F7
	.long 0x7f2e150a                                           // 00000021DE38: 7F2E150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DE3C: 8C7E017E
	.long 0x7f303880                                           // 00000021DE40: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DE44: BF870001
	.long 0x7e303998                                           // 00000021DE48: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000021DE4C: BE812000
	s_cbranch_execz 4                                          // 00000021DE50: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1464>
	global_load_b32 v10, v[26:27], off offset:496              // 00000021DE54: DC5201F0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DE5C: BF8903F7
	v_cvt_f16_f32_e32 v24, v10                                 // 00000021DE60: 7E30150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DE64: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DE68: BE812000
	s_cbranch_execz 4                                          // 00000021DE6C: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1480>
	global_load_b32 v10, v[26:27], off offset:500              // 00000021DE70: DC5201F4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DE78: BF8903F7
	.long 0x7f30150a                                           // 00000021DE7C: 7F30150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DE80: 8C7E017E
	.long 0x7f323880                                           // 00000021DE84: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021DE88: BF870001
	.long 0x7e323999                                           // 00000021DE8C: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000021DE90: BE812000
	s_cbranch_execz 4                                          // 00000021DE94: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x14a8>
	global_load_b32 v10, v[26:27], off offset:504              // 00000021DE98: DC5201F8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DEA0: BF8903F7
	v_cvt_f16_f32_e32 v25, v10                                 // 00000021DEA4: 7E32150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DEA8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000021DEAC: BE812000
	s_cbranch_execz 4                                          // 00000021DEB0: BFA50004 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x14c4>
	global_load_b32 v10, v[26:27], off offset:508              // 00000021DEB4: DC5201FC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000021DEBC: BF8903F7
	.long 0x7f32150a                                           // 00000021DEC0: 7F32150A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000021DEC4: 8C7E017E
	ds_load_b128 v[10:13], v33 offset:224                      // 00000021DEC8: DBFC00E0 0A000021
	ds_load_b128 v[14:17], v33 offset:240                      // 00000021DED0: DBFC00F0 0E000021
	s_waitcnt lgkmcnt(0)                                       // 00000021DED8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[10:17], v[2:9] // 00000021DEDC: CC404002 1C0A1512
	s_or_b32 exec_lo, exec_lo, s8                              // 00000021DEE4: 8C7E087E
	v_or_b32_e32 v11, v0, v31                                  // 00000021DEE8: 38163F00
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 00000021DEEC: CA100080 0C0C0080
	s_xor_b32 s1, vcc_lo, -1                                   // 00000021DEF4: 8D01C16A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000021DEF8: BF8704B2
	.long 0xd44b0000                                           // 00000021DEFC: D44B0000
	v_cndmask_b32_e32 v1, v29, v11, vcc_lo                     // 00000021DF00: 0202171D
	v_lshlrev_b32_e32 v10, 2, v11                              // 00000021DF04: 30141682
	s_and_b32 s8, s1, s0                                       // 00000021DF08: 8B080001
	s_and_saveexec_b32 s0, s8                                  // 00000021DF0C: BE802008
	s_cbranch_execz 33                                         // 00000021DF10: BFA50021 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1598>
	ds_load_b32 v0, v10 offset:18432                           // 00000021DF14: D8D84800 0000000A
	ds_load_b32 v13, v32                                       // 00000021DF1C: D8D80000 0D000020
	s_waitcnt lgkmcnt(0)                                       // 00000021DF24: BF89FC07
	v_sub_f32_e32 v0, v0, v13                                  // 00000021DF28: 08001B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021DF2C: BF870091
	v_mul_f32_e32 v13, 0x3fb8aa3b, v0                          // 00000021DF30: 101A00FF 3FB8AA3B
	v_fma_f32 v14, 0x3fb8aa3b, v0, -v13                        // 00000021DF38: D613000E 843600FF 3FB8AA3B
	v_rndne_f32_e32 v15, v13                                   // 00000021DF44: 7E1E470D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000021DF48: BF870221
	v_sub_f32_e32 v13, v13, v15                                // 00000021DF4C: 081A1F0D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021DF50: 7C3600FF C2CE8ED0
	v_fmac_f32_e32 v14, 0x32a5705f, v0                         // 00000021DF58: 561C00FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021DF60: BF870121
	v_add_f32_e32 v13, v13, v14                                // 00000021DF64: 061A1D0D
	v_cvt_i32_f32_e32 v14, v15                                 // 00000021DF68: 7E1C110F
	v_exp_f32_e32 v13, v13                                     // 00000021DF6C: 7E1A4B0D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021DF70: BF870095
	.long 0xd71c000d                                           // 00000021DF74: D71C000D
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                     // 00000021DF78: 02021D0D
	v_cndmask_b32_e32 v13, 0, v13, vcc_lo                      // 00000021DF7C: 021A1A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021DF80: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021DF88: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v13, vcc_lo              // 00000021DF8C: 02001AFF 7F800000
	v_mul_f32_e32 v13, v2, v0                                  // 00000021DF94: 101A0102
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021DF98: 8C7E007E
	v_lshl_or_b32 v0, v11, 6, v29                              // 00000021DF9C: D6560000 04750D0B
	v_or_b32_e32 v2, 2, v11                                    // 00000021DFA4: 38041682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021DFA8: BF870112
	.long 0xd73c000e                                           // 00000021DFAC: D73C000E
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021DFB0: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v2                           // 00000021DFB4: 7C96051D
	s_and_b32 s8, s1, vcc_lo                                   // 00000021DFB8: 8B086A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021DFBC: BF870092
	.long 0xd700000e                                           // 00000021DFC0: D700000E
	v_cndmask_b32_e32 v1, s2, v14, vcc_lo                      // 00000021DFC4: 02021C02
	v_add_co_ci_u32_e64 v15, null, s6, v15, s0                 // 00000021DFC8: D5207C0F 00021E06
	global_store_b32 v[14:15], v13, off                        // 00000021DFD0: DC6A0000 007C0D0E
	s_and_saveexec_b32 s0, s8                                  // 00000021DFD8: BE802008
	s_cbranch_execz 33                                         // 00000021DFDC: BFA50021 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1664>
	ds_load_b32 v0, v10 offset:18440                           // 00000021DFE0: D8D84808 0000000A
	ds_load_b32 v12, v32                                       // 00000021DFE8: D8D80000 0C000020
	s_waitcnt lgkmcnt(0)                                       // 00000021DFF0: BF89FC07
	v_sub_f32_e32 v0, v0, v12                                  // 00000021DFF4: 08001900
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021DFF8: BF870121
	v_mul_f32_e32 v12, 0x3fb8aa3b, v0                          // 00000021DFFC: 101800FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021E004: 7C3600FF C2CE8ED0
	v_fma_f32 v13, 0x3fb8aa3b, v0, -v12                        // 00000021E00C: D613000D 843200FF 3FB8AA3B
	v_rndne_f32_e32 v14, v12                                   // 00000021E018: 7E1C470C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E01C: BF870091
	v_dual_fmac_f32 v13, 0x32a5705f, v0 :: v_dual_sub_f32 v12, v12, v14// 00000021E020: C80A00FF 0D0C1D0C 32A5705F
	v_add_f32_e32 v12, v12, v13                                // 00000021E02C: 06181B0C
	v_cvt_i32_f32_e32 v13, v14                                 // 00000021E030: 7E1A110E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000021E034: BF870292
	v_exp_f32_e32 v12, v12                                     // 00000021E038: 7E184B0C
	.long 0xd71c000c                                           // 00000021E03C: D71C000C
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                     // 00000021E040: 02021B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021E044: BF870121
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 00000021E048: 02181880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021E04C: 7C3C00FF 42B17218
	v_cndmask_b32_e32 v0, 0x7f800000, v12, vcc_lo              // 00000021E054: 020018FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021E05C: BF870001
	v_mul_f32_e32 v12, v3, v0                                  // 00000021E060: 10180103
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021E064: 8C7E007E
	v_lshl_or_b32 v0, v2, 6, v29                               // 00000021E068: D6560000 04750D02
	v_or_b32_e32 v3, 4, v11                                    // 00000021E070: 38061684
	v_mov_b32_e32 v2, 0                                        // 00000021E074: 7E040280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000021E078: BF870193
	.long 0xd73c000d                                           // 00000021E07C: D73C000D
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021E080: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 00000021E084: 7C96071D
	s_and_b32 s8, s1, vcc_lo                                   // 00000021E088: 8B086A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E08C: BF870092
	.long 0xd700000f                                           // 00000021E090: D700000F
	v_cndmask_b32_e32 v1, s2, v13, vcc_lo                      // 00000021E094: 02021A02
	v_add_co_ci_u32_e64 v16, null, s6, v14, s0                 // 00000021E098: D5207C10 00021C06
	v_mov_b32_e32 v13, 0                                       // 00000021E0A0: 7E1A0280
	global_store_b32 v[15:16], v12, off                        // 00000021E0A4: DC6A0000 007C0C0F
	s_and_saveexec_b32 s0, s8                                  // 00000021E0AC: BE802008
	s_cbranch_execz 33                                         // 00000021E0B0: BFA50021 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1738>
	ds_load_b32 v0, v10 offset:18448                           // 00000021E0B4: D8D84810 0000000A
	ds_load_b32 v12, v32                                       // 00000021E0BC: D8D80000 0C000020
	s_waitcnt lgkmcnt(0)                                       // 00000021E0C4: BF89FC07
	v_sub_f32_e32 v0, v0, v12                                  // 00000021E0C8: 08001900
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021E0CC: BF870121
	v_mul_f32_e32 v12, 0x3fb8aa3b, v0                          // 00000021E0D0: 101800FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021E0D8: 7C3600FF C2CE8ED0
	v_fma_f32 v13, 0x3fb8aa3b, v0, -v12                        // 00000021E0E0: D613000D 843200FF 3FB8AA3B
	v_rndne_f32_e32 v14, v12                                   // 00000021E0EC: 7E1C470C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E0F0: BF870091
	v_dual_fmac_f32 v13, 0x32a5705f, v0 :: v_dual_sub_f32 v12, v12, v14// 00000021E0F4: C80A00FF 0D0C1D0C 32A5705F
	v_add_f32_e32 v12, v12, v13                                // 00000021E100: 06181B0C
	v_cvt_i32_f32_e32 v13, v14                                 // 00000021E104: 7E1A110E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000021E108: BF870292
	v_exp_f32_e32 v12, v12                                     // 00000021E10C: 7E184B0C
	.long 0xd71c000c                                           // 00000021E110: D71C000C
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                     // 00000021E114: 02021B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021E118: BF870121
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 00000021E11C: 02181880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021E120: 7C3C00FF 42B17218
	v_cndmask_b32_e32 v0, 0x7f800000, v12, vcc_lo              // 00000021E128: 020018FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000021E130: BF870001
	v_mul_f32_e32 v13, v4, v0                                  // 00000021E134: 101A0104
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021E138: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 00000021E13C: D6560000 04750D03
	v_or_b32_e32 v3, 6, v11                                    // 00000021E144: 38061686
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021E148: BF870112
	.long 0xd73c000e                                           // 00000021E14C: D73C000E
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021E150: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 00000021E154: 7C96071D
	s_and_b32 s8, s1, vcc_lo                                   // 00000021E158: 8B086A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E15C: BF870092
	.long 0xd700000e                                           // 00000021E160: D700000E
	v_cndmask_b32_e32 v1, s2, v14, vcc_lo                      // 00000021E164: 02021C02
	v_add_co_ci_u32_e64 v15, null, s6, v15, s0                 // 00000021E168: D5207C0F 00021E06
	global_store_b32 v[14:15], v13, off                        // 00000021E170: DC6A0000 007C0D0E
	s_and_saveexec_b32 s0, s8                                  // 00000021E178: BE802008
	s_cbranch_execz 33                                         // 00000021E17C: BFA50021 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1804>
	ds_load_b32 v0, v10 offset:18456                           // 00000021E180: D8D84818 0000000A
	ds_load_b32 v2, v32                                        // 00000021E188: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 00000021E190: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 00000021E194: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021E198: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 00000021E19C: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021E1A4: 7C3600FF C2CE8ED0
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v2                          // 00000021E1AC: D6130004 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v12, v2                                    // 00000021E1B8: 7E184702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021E1BC: BF870112
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 00000021E1C0: 560800FF 32A5705F
	v_sub_f32_e32 v2, v2, v12                                  // 00000021E1C8: 08041902
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021E1CC: BF870121
	v_add_f32_e32 v2, v2, v4                                   // 00000021E1D0: 06040902
	v_cvt_i32_f32_e32 v4, v12                                  // 00000021E1D4: 7E08110C
	v_exp_f32_e32 v2, v2                                       // 00000021E1D8: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E1DC: BF870095
	.long 0xd71c0002                                           // 00000021E1E0: D71C0002
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000021E1E4: 02020902
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 00000021E1E8: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021E1EC: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E1F4: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 00000021E1F8: 020004FF 7F800000
	v_mul_f32_e32 v2, v5, v0                                   // 00000021E200: 10040105
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021E204: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 00000021E208: D6560000 04750D03
	v_or_b32_e32 v4, 8, v11                                    // 00000021E210: 38081688
	v_mov_b32_e32 v3, 0                                        // 00000021E214: 7E060280
	v_mov_b32_e32 v5, 0                                        // 00000021E218: 7E0A0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000021E21C: BF870214
	.long 0xd73c000c                                           // 00000021E220: D73C000C
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021E224: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v4                           // 00000021E228: 7C96091D
	s_and_b32 s8, s1, vcc_lo                                   // 00000021E22C: 8B086A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E230: BF870092
	.long 0xd700000c                                           // 00000021E234: D700000C
	v_cndmask_b32_e32 v1, s2, v12, vcc_lo                      // 00000021E238: 02021802
	v_add_co_ci_u32_e64 v13, null, s6, v13, s0                 // 00000021E23C: D5207C0D 00021A06
	global_store_b32 v[12:13], v2, off                         // 00000021E244: DC6A0000 007C020C
	s_and_saveexec_b32 s0, s8                                  // 00000021E24C: BE802008
	s_cbranch_execz 33                                         // 00000021E250: BFA50021 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x18d8>
	ds_load_b32 v0, v10 offset:18464                           // 00000021E254: D8D84820 0000000A
	ds_load_b32 v2, v32                                        // 00000021E25C: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 00000021E264: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 00000021E268: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021E26C: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 00000021E270: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021E278: 7C3600FF C2CE8ED0
	v_fma_f32 v5, 0x3fb8aa3b, v0, -v2                          // 00000021E280: D6130005 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v12, v2                                    // 00000021E28C: 7E184702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021E290: BF870112
	v_fmac_f32_e32 v5, 0x32a5705f, v0                          // 00000021E294: 560A00FF 32A5705F
	v_sub_f32_e32 v2, v2, v12                                  // 00000021E29C: 08041902
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021E2A0: BF870121
	v_add_f32_e32 v2, v2, v5                                   // 00000021E2A4: 06040B02
	v_cvt_i32_f32_e32 v5, v12                                  // 00000021E2A8: 7E0A110C
	v_exp_f32_e32 v2, v2                                       // 00000021E2AC: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E2B0: BF870095
	.long 0xd71c0002                                           // 00000021E2B4: D71C0002
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 00000021E2B8: 02020B02
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 00000021E2BC: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021E2C0: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E2C8: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 00000021E2CC: 020004FF 7F800000
	v_mul_f32_e32 v5, v6, v0                                   // 00000021E2D4: 100A0106
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021E2D8: 8C7E007E
	v_lshl_or_b32 v0, v4, 6, v29                               // 00000021E2DC: D6560000 04750D04
	v_or_b32_e32 v2, 10, v11                                   // 00000021E2E4: 3804168A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021E2E8: BF870112
	.long 0xd73c000c                                           // 00000021E2EC: D73C000C
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021E2F0: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v2                           // 00000021E2F4: 7C96051D
	s_and_b32 s8, s1, vcc_lo                                   // 00000021E2F8: 8B086A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E2FC: BF870092
	.long 0xd700000c                                           // 00000021E300: D700000C
	v_cndmask_b32_e32 v1, s2, v12, vcc_lo                      // 00000021E304: 02021802
	v_add_co_ci_u32_e64 v13, null, s6, v13, s0                 // 00000021E308: D5207C0D 00021A06
	global_store_b32 v[12:13], v5, off                         // 00000021E310: DC6A0000 007C050C
	s_and_saveexec_b32 s0, s8                                  // 00000021E318: BE802008
	s_cbranch_execz 33                                         // 00000021E31C: BFA50021 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x19a4>
	ds_load_b32 v0, v10 offset:18472                           // 00000021E320: D8D84828 0000000A
	ds_load_b32 v3, v32                                        // 00000021E328: D8D80000 03000020
	s_waitcnt lgkmcnt(0)                                       // 00000021E330: BF89FC07
	v_sub_f32_e32 v0, v0, v3                                   // 00000021E334: 08000700
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E338: BF870091
	v_mul_f32_e32 v3, 0x3fb8aa3b, v0                           // 00000021E33C: 100600FF 3FB8AA3B
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v3                          // 00000021E344: D6130004 840E00FF 3FB8AA3B
	v_rndne_f32_e32 v5, v3                                     // 00000021E350: 7E0A4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000021E354: BF870221
	v_sub_f32_e32 v3, v3, v5                                   // 00000021E358: 08060B03
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021E35C: 7C3600FF C2CE8ED0
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 00000021E364: 560800FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021E36C: BF870121
	v_add_f32_e32 v3, v3, v4                                   // 00000021E370: 06060903
	v_cvt_i32_f32_e32 v4, v5                                   // 00000021E374: 7E081105
	v_exp_f32_e32 v3, v3                                       // 00000021E378: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E37C: BF870095
	.long 0xd71c0003                                           // 00000021E380: D71C0003
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 00000021E384: 02020903
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 00000021E388: 02060680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021E38C: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E394: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v3, vcc_lo               // 00000021E398: 020006FF 7F800000
	v_mul_f32_e32 v3, v7, v0                                   // 00000021E3A0: 10060107
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021E3A4: 8C7E007E
	v_lshl_or_b32 v0, v2, 6, v29                               // 00000021E3A8: D6560000 04750D02
	v_or_b32_e32 v4, 12, v11                                   // 00000021E3B0: 3808168C
	v_mov_b32_e32 v2, 0                                        // 00000021E3B4: 7E040280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000021E3B8: BF870193
	.long 0xd73c0005                                           // 00000021E3BC: D73C0005
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021E3C0: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v4                           // 00000021E3C4: 7C96091D
	s_and_b32 s8, s1, vcc_lo                                   // 00000021E3C8: 8B086A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E3CC: BF870092
	.long 0xd700000c                                           // 00000021E3D0: D700000C
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000021E3D4: 02020A02
	v_add_co_ci_u32_e64 v13, null, s6, v6, s0                  // 00000021E3D8: D5207C0D 00020C06
	v_mov_b32_e32 v5, 0                                        // 00000021E3E0: 7E0A0280
	global_store_b32 v[12:13], v3, off                         // 00000021E3E4: DC6A0000 007C030C
	s_and_saveexec_b32 s0, s8                                  // 00000021E3EC: BE802008
	s_cbranch_execz 33                                         // 00000021E3F0: BFA50021 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x1a78>
	ds_load_b32 v0, v10 offset:18480                           // 00000021E3F4: D8D84830 0000000A
	ds_load_b32 v3, v32                                        // 00000021E3FC: D8D80000 03000020
	s_waitcnt lgkmcnt(0)                                       // 00000021E404: BF89FC07
	v_sub_f32_e32 v0, v0, v3                                   // 00000021E408: 08000700
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E40C: BF870091
	v_mul_f32_e32 v3, 0x3fb8aa3b, v0                           // 00000021E410: 100600FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v0, -v3                          // 00000021E418: D6130005 840E00FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 00000021E424: 7E0C4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000021E428: BF870191
	v_sub_f32_e32 v3, v3, v6                                   // 00000021E42C: 08060D03
	v_fmac_f32_e32 v5, 0x32a5705f, v0                          // 00000021E430: 560A00FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021E438: 7C3600FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021E440: BF870122
	v_add_f32_e32 v3, v3, v5                                   // 00000021E444: 06060B03
	v_cvt_i32_f32_e32 v5, v6                                   // 00000021E448: 7E0A1106
	v_exp_f32_e32 v3, v3                                       // 00000021E44C: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E450: BF870095
	.long 0xd71c0003                                           // 00000021E454: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 00000021E458: 02020B03
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 00000021E45C: 02060680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021E460: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E468: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v3, vcc_lo               // 00000021E46C: 020006FF 7F800000
	v_mul_f32_e32 v5, v8, v0                                   // 00000021E474: 100A0108
	s_or_b32 exec_lo, exec_lo, s0                              // 00000021E478: 8C7E007E
	v_lshl_or_b32 v0, v4, 6, v29                               // 00000021E47C: D6560000 04750D04
	v_or_b32_e32 v3, 14, v11                                   // 00000021E484: 3806168E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021E488: BF870112
	.long 0xd73c0006                                           // 00000021E48C: D73C0006
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021E490: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 00000021E494: 7C96071D
	s_and_b32 s1, s1, vcc_lo                                   // 00000021E498: 8B016A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E49C: BF870092
	.long 0xd7000006                                           // 00000021E4A0: D7000006
	v_cndmask_b32_e32 v1, s2, v6, vcc_lo                       // 00000021E4A4: 02020C02
	v_add_co_ci_u32_e64 v7, null, s6, v7, s0                   // 00000021E4A8: D5207C07 00020E06
	global_store_b32 v[6:7], v5, off                           // 00000021E4B0: DC6A0000 007C0506
	s_and_saveexec_b32 s0, s1                                  // 00000021E4B8: BE802001
	s_cbranch_execz 63953                                      // 00000021E4BC: BFA5F9D1 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x204>
	ds_load_b32 v0, v10 offset:18488                           // 00000021E4C0: D8D84838 0000000A
	ds_load_b32 v2, v32                                        // 00000021E4C8: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 00000021E4D0: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 00000021E4D4: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021E4D8: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 00000021E4DC: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000021E4E4: 7C3600FF C2CE8ED0
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v2                          // 00000021E4EC: D6130004 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v5, v2                                     // 00000021E4F8: 7E0A4702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000021E4FC: BF870112
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 00000021E500: 560800FF 32A5705F
	v_sub_f32_e32 v2, v2, v5                                   // 00000021E508: 08040B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000021E50C: BF870121
	v_add_f32_e32 v2, v2, v4                                   // 00000021E510: 06040902
	v_cvt_i32_f32_e32 v4, v5                                   // 00000021E514: 7E081105
	v_exp_f32_e32 v2, v2                                       // 00000021E518: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E51C: BF870095
	.long 0xd71c0002                                           // 00000021E520: D71C0002
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000021E524: 02020902
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 00000021E528: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000021E52C: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021E534: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 00000021E538: 020004FF 7F800000
	v_mul_f32_e32 v2, v9, v0                                   // 00000021E540: 10040109
	s_branch 63919                                             // 00000021E544: BFA0F9AF <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi0EEEvPKfS3_S3_Pfi+0x204>
	s_endpgm                                                   // 00000021E548: BFB00000
		...

