0000000000224000 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi():
	s_mov_b32 s12, s3                                          // 000000224000: BE8C0003
	s_clause 0x1                                               // 000000224004: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000224008: F40C0100 F8000000
	s_load_b32 s3, s[0:1], 0x20                                // 000000224010: F40000C0 F8000020
	v_and_b32_e32 v1, 0x7f, v0                                 // 000000224018: 360200FF 0000007F
	s_lshl_b32 s0, s2, 6                                       // 000000224020: 84008602
	s_ashr_i32 s13, s12, 31                                    // 000000224024: 860D9F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000224028: BF8700B1
	v_dual_mov_b32 v5, v0 :: v_dual_lshlrev_b32 v2, 1, v1      // 00000022402C: CA220100 05020281
	v_lshlrev_b32_e32 v3, 2, v1                                // 000000224034: 30060282
	s_waitcnt lgkmcnt(0)                                       // 000000224038: BF89FC07
	.long 0xd7000103                                           // 00000022403C: D7000103
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 000000224040: 02020606
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224044: BF870001
	v_add_co_ci_u32_e64 v4, null, s7, 0, s1                    // 000000224048: D5207C04 00050007
	s_mov_b32 s1, 0                                            // 000000224050: BE810080
	s_mov_b32 s6, 0x41800000                                   // 000000224054: BE8600FF 41800000
	s_set_inst_prefetch_distance 0x1                           // 00000022405C: BF840001
	s_branch 22                                                // 000000224060: BFA00016 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xbc>
	s_nop 0                                                    // 000000224064: BF800000
	s_nop 0                                                    // 000000224068: BF800000
	s_nop 0                                                    // 00000022406C: BF800000
	s_nop 0                                                    // 000000224070: BF800000
	s_nop 0                                                    // 000000224074: BF800000
	s_nop 0                                                    // 000000224078: BF800000
	s_nop 0                                                    // 00000022407C: BF800000
	s_or_b32 exec_lo, exec_lo, s7                              // 000000224080: 8C7E077E
	v_add_nc_u32_e32 v8, 0x100, v5                             // 000000224084: 4A100AFF 00000100
	v_mad_u64_u32 v[6:7], null, 0x120, v6, v[2:3]              // 00000022408C: D6FE7C06 040A0CFF 00000120
	v_cmp_lt_u32_e32 vcc_lo, 0x1eff, v5                        // 000000224098: 7C920AFF 00001EFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002240A0: BF870003
	v_mov_b32_e32 v5, v8                                       // 0000002240A4: 7E0A0308
	s_or_b32 s1, vcc_lo, s1                                    // 0000002240A8: 8C01016A
	ds_store_b16 v6, v1                                        // 0000002240AC: D87C0000 00000106
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000002240B4: 917E017E
	s_cbranch_execz 24                                         // 0000002240B8: BFA50018 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x11c>
	v_lshrrev_b32_e32 v6, 7, v5                                // 0000002240BC: 320C0A87
	.long 0x7e023880                                           // 0000002240C0: 7E023880
	s_mov_b32 s7, exec_lo                                      // 0000002240C4: BE87007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002240C8: BF870092
	v_or_b32_e32 v7, s0, v6                                    // 0000002240CC: 380E0C00
	.long 0xd4c4007e                                           // 0000002240D0: D4C4007E
	v_cndmask_b32_e32 v1, s3, v7, vcc_lo                       // 0000002240D4: 02020E03
	s_cbranch_execz 65513                                      // 0000002240D8: BFA5FFE9 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x80>
	v_mad_i64_i32 v[7:8], null, v7, 48, s[12:13]               // 0000002240DC: D6FF7C07 00316107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002240E4: BF870091
	.long 0xd73c0007                                           // 0000002240E8: D73C0007
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 0000002240EC: 02020E89
	.long 0xd7006a07                                           // 0000002240F0: D7006A07
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 0000002240F4: 02020F03
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002240F8: BF870001
	v_add_co_ci_u32_e64 v8, null, v4, v8, vcc_lo               // 0000002240FC: D5207C08 01AA1104
	global_load_b32 v1, v[7:8], off                            // 000000224104: DC520000 017C0007
	s_waitcnt vmcnt(0)                                         // 00000022410C: BF8903F7
	v_fma_mixlo_f16 v1, v1, s6, 0                              // 000000224110: CC210001 02000D01
	s_branch 65497                                             // 000000224118: BFA0FFD9 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x80>
	s_set_inst_prefetch_distance 0x2                           // 00000022411C: BF840002
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224120: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000224124: BF870009
	s_mov_b32 s1, exec_lo                                      // 000000224128: BE81007E
	v_cmpx_gt_u32_e32 64, v0                                   // 00000022412C: 7D9800C0
	s_cbranch_execz 17                                         // 000000224130: BFA50011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x178>
	v_or_b32_e32 v1, s0, v0                                    // 000000224134: 38020000
	s_lshl_b64 s[6:7], s[12:13], 2                             // 000000224138: 8486820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022413C: BF870091
	v_mad_i64_i32 v[1:2], null, 0xc0, v1, s[8:9]               // 000000224140: D6FF7C01 002202FF 000000C0
	.long 0xd7006a01                                           // 00000022414C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000224150: 02000D01
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224154: BF870001
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000224158: D5207C02 01AA0407
	global_load_b32 v1, v[1:2], off                            // 000000224160: DC520000 017C0001
	v_lshlrev_b32_e32 v2, 2, v0                                // 000000224168: 30040082
	s_waitcnt vmcnt(0)                                         // 00000022416C: BF8903F7
	ds_store_b32 v2, v1 offset:18432                           // 000000224170: D8344800 00000102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224178: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 00000022417C: BF89FC07
	s_barrier                                                  // 000000224180: BFBD0000
	buffer_gl0_inv                                             // 000000224184: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 00000022418C: BE81007E
	v_cmpx_gt_u32_e32 0x200, v0                                // 000000224190: 7D9800FF 00000200
	s_cbranch_execz 1796                                       // 000000224198: BFA50704 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1dac>
	v_and_b32_e32 v1, 15, v0                                   // 00000022419C: 3602008F
	v_bfe_u32 v28, v0, 5, 2                                    // 0000002241A0: D610001C 02090B00
	s_mul_i32 s1, s2, 48                                       // 0000002241A8: 9601B002
	s_mul_hi_u32 s2, s2, 48                                    // 0000002241AC: 9682B002
	s_add_u32 s6, s1, s12                                      // 0000002241B0: 80060C01
	v_mul_u32_u24_e32 v2, 0x120, v1                            // 0000002241B4: 160402FF 00000120
	v_lshl_or_b32 v29, v28, 4, v1                              // 0000002241BC: D656001D 0405091C
	v_mul_u32_u24_e32 v3, 0x1200, v28                          // 0000002241C4: 160638FF 00001200
	s_addc_u32 s7, s2, s13                                     // 0000002241CC: 82070D02
	v_lshrrev_b32_e32 v33, 5, v0                               // 0000002241D0: 32420085
	s_lshl_b64 s[6:7], s[6:7], 14                              // 0000002241D4: 84868E06
	v_or_b32_e32 v30, s0, v1                                   // 0000002241D8: 383C0200
	v_bfe_u32 v31, v0, 4, 1                                    // 0000002241DC: D610001F 02050900
	v_lshl_or_b32 v32, v29, 2, 0x4800                          // 0000002241E4: D6560020 03FD051D 00004800
	v_dual_mov_b32 v1, 0 :: v_dual_add_nc_u32 v34, v2, v3      // 0000002241F0: CA200080 01220702
	s_add_u32 s2, s10, s6                                      // 0000002241F8: 8002060A
	s_addc_u32 s6, s11, s7                                     // 0000002241FC: 8206070B
	s_mov_b32 s7, 0                                            // 000000224200: BE870080
	s_mov_b32 s8, 0x41800000                                   // 000000224204: BE8800FF 41800000
	s_branch 19                                                // 00000022420C: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x25c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000224210: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 000000224214: D6560000 04750D03
	v_cmp_lt_u32_e32 vcc_lo, 7, v33                            // 00000022421C: 7C924287
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000224220: BF8700B2
	.long 0xd73c0003                                           // 000000224224: D73C0003
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000224228: 02020082
	v_add_nc_u32_e32 v0, 8, v33                                // 00000022422C: 4A004288
	s_or_b32 s7, vcc_lo, s7                                    // 000000224230: 8C07076A
	v_mov_b32_e32 v33, v0                                      // 000000224234: 7E420300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000224238: BF870093
	.long 0xd7000003                                           // 00000022423C: D7000003
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000224240: 02020602
	v_add_co_ci_u32_e64 v4, null, s6, v4, s0                   // 000000224244: D5207C04 00020806
	global_store_b32 v[3:4], v2, off                           // 00000022424C: DC6A0000 007C0203
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 000000224254: 917E077E
	s_cbranch_execz 1748                                       // 000000224258: BFA506D4 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1dac>
	v_lshrrev_b32_e32 v0, 2, v33                               // 00000022425C: 32004282
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 000000224260: CA100080 09080080
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v5, 0               // 000000224268: CA100080 06040080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000224270: BF870003
	v_cmp_lt_u32_e32 vcc_lo, v0, v28                           // 000000224274: 7C923900
	.long 0xd44e0000                                           // 000000224278: D44E0000
	v_cndmask_b32_e32 v1, v0, v28, vcc_lo                      // 00000022427C: 02023900
	v_dual_mov_b32 v7, 0 :: v_dual_lshlrev_b32 v0, 4, v0       // 000000224280: CA220080 07000084
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v3, 0               // 000000224288: CA100080 04020080
	v_mov_b32_e32 v2, 0                                        // 000000224290: 7E040280
	s_and_saveexec_b32 s9, s0                                  // 000000224294: BE892000
	s_cbranch_execz 1301                                       // 000000224298: BFA50515 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x16f0>
	v_add_nc_u32_e32 v4, v0, v30                               // 00000022429C: 4A083D00
	.long 0x7f143880                                           // 0000002242A0: 7F143880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002242A4: BF8701A2
	v_mad_i64_i32 v[2:3], null, v4, 48, s[12:13]               // 0000002242A8: D6FF7C02 00316104
	.long 0xd4440000                                           // 0000002242B0: D4440000
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 0000002242B4: 02020803
	.long 0x7e14398a                                           // 0000002242B8: 7E14398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002242BC: BF870093
	.long 0xd73c0002                                           // 0000002242C0: D73C0002
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000002242C4: 02020489
	.long 0xd700011a                                           // 0000002242C8: D700011A
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 0000002242CC: 02020404
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002242D0: BF870001
	v_add_co_ci_u32_e64 v27, null, s5, v3, s1                  // 0000002242D4: D5207C1B 00060605
	s_and_saveexec_b32 s1, s0                                  // 0000002242DC: BE812000
	s_cbranch_execz 5                                          // 0000002242E0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x2f8>
	global_load_b32 v2, v[26:27], off                          // 0000002242E4: DC520000 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002242EC: BF8903F7
	v_fma_mixlo_f16 v10, v2, s8, 0                             // 0000002242F0: CC21000A 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002242F8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002242FC: BE812000
	s_cbranch_execz 5                                          // 000000224300: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x318>
	global_load_b32 v2, v[26:27], off offset:4                 // 000000224304: DC520004 027C001A
	s_waitcnt vmcnt(0)                                         // 00000022430C: BF8903F7
	v_fma_mixhi_f16 v10, v2, s8, 0                             // 000000224310: CC22000A 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224318: 8C7E017E
	.long 0x7f163880                                           // 00000022431C: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224320: BF870001
	.long 0x7e16398b                                           // 000000224324: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 000000224328: BE812000
	s_cbranch_execz 5                                          // 00000022432C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x344>
	global_load_b32 v2, v[26:27], off offset:8                 // 000000224330: DC520008 027C001A
	s_waitcnt vmcnt(0)                                         // 000000224338: BF8903F7
	v_fma_mixlo_f16 v11, v2, s8, 0                             // 00000022433C: CC21000B 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224344: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224348: BE812000
	s_cbranch_execz 5                                          // 00000022434C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x364>
	global_load_b32 v2, v[26:27], off offset:12                // 000000224350: DC52000C 027C001A
	s_waitcnt vmcnt(0)                                         // 000000224358: BF8903F7
	v_fma_mixhi_f16 v11, v2, s8, 0                             // 00000022435C: CC22000B 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224364: 8C7E017E
	.long 0x7f183880                                           // 000000224368: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022436C: BF870001
	.long 0x7e18398c                                           // 000000224370: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 000000224374: BE812000
	s_cbranch_execz 5                                          // 000000224378: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x390>
	global_load_b32 v2, v[26:27], off offset:16                // 00000022437C: DC520010 027C001A
	s_waitcnt vmcnt(0)                                         // 000000224384: BF8903F7
	v_fma_mixlo_f16 v12, v2, s8, 0                             // 000000224388: CC21000C 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224390: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224394: BE812000
	s_cbranch_execz 5                                          // 000000224398: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x3b0>
	global_load_b32 v2, v[26:27], off offset:20                // 00000022439C: DC520014 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002243A4: BF8903F7
	v_fma_mixhi_f16 v12, v2, s8, 0                             // 0000002243A8: CC22000C 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002243B0: 8C7E017E
	.long 0x7f1a3880                                           // 0000002243B4: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002243B8: BF870001
	.long 0x7e1a398d                                           // 0000002243BC: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 0000002243C0: BE812000
	s_cbranch_execz 5                                          // 0000002243C4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x3dc>
	global_load_b32 v2, v[26:27], off offset:24                // 0000002243C8: DC520018 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002243D0: BF8903F7
	v_fma_mixlo_f16 v13, v2, s8, 0                             // 0000002243D4: CC21000D 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002243DC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002243E0: BE812000
	s_cbranch_execz 5                                          // 0000002243E4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x3fc>
	global_load_b32 v2, v[26:27], off offset:28                // 0000002243E8: DC52001C 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002243F0: BF8903F7
	v_fma_mixhi_f16 v13, v2, s8, 0                             // 0000002243F4: CC22000D 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002243FC: 8C7E017E
	.long 0x7f1c3880                                           // 000000224400: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224404: BF870001
	.long 0x7e1c398e                                           // 000000224408: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 00000022440C: BE812000
	s_cbranch_execz 5                                          // 000000224410: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x428>
	global_load_b32 v2, v[26:27], off offset:32                // 000000224414: DC520020 027C001A
	s_waitcnt vmcnt(0)                                         // 00000022441C: BF8903F7
	v_fma_mixlo_f16 v14, v2, s8, 0                             // 000000224420: CC21000E 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224428: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000022442C: BE812000
	s_cbranch_execz 5                                          // 000000224430: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x448>
	global_load_b32 v2, v[26:27], off offset:36                // 000000224434: DC520024 027C001A
	s_waitcnt vmcnt(0)                                         // 00000022443C: BF8903F7
	v_fma_mixhi_f16 v14, v2, s8, 0                             // 000000224440: CC22000E 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224448: 8C7E017E
	.long 0x7f1e3880                                           // 00000022444C: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224450: BF870001
	.long 0x7e1e398f                                           // 000000224454: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 000000224458: BE812000
	s_cbranch_execz 5                                          // 00000022445C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x474>
	global_load_b32 v2, v[26:27], off offset:40                // 000000224460: DC520028 027C001A
	s_waitcnt vmcnt(0)                                         // 000000224468: BF8903F7
	v_fma_mixlo_f16 v15, v2, s8, 0                             // 00000022446C: CC21000F 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224474: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224478: BE812000
	s_cbranch_execz 5                                          // 00000022447C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x494>
	global_load_b32 v2, v[26:27], off offset:44                // 000000224480: DC52002C 027C001A
	s_waitcnt vmcnt(0)                                         // 000000224488: BF8903F7
	v_fma_mixhi_f16 v15, v2, s8, 0                             // 00000022448C: CC22000F 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224494: 8C7E017E
	.long 0x7f203880                                           // 000000224498: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022449C: BF870001
	.long 0x7e203990                                           // 0000002244A0: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 0000002244A4: BE812000
	s_cbranch_execz 5                                          // 0000002244A8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x4c0>
	global_load_b32 v2, v[26:27], off offset:48                // 0000002244AC: DC520030 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002244B4: BF8903F7
	v_fma_mixlo_f16 v16, v2, s8, 0                             // 0000002244B8: CC210010 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002244C0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002244C4: BE812000
	s_cbranch_execz 5                                          // 0000002244C8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x4e0>
	global_load_b32 v2, v[26:27], off offset:52                // 0000002244CC: DC520034 027C001A
	s_waitcnt vmcnt(0)                                         // 0000002244D4: BF8903F7
	v_fma_mixhi_f16 v16, v2, s8, 0                             // 0000002244D8: CC220010 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002244E0: 8C7E017E
	.long 0x7f223880                                           // 0000002244E4: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002244E8: BF870001
	.long 0x7e223991                                           // 0000002244EC: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 0000002244F0: BE812000
	s_cbranch_execz 5                                          // 0000002244F4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x50c>
	global_load_b32 v2, v[26:27], off offset:56                // 0000002244F8: DC520038 027C001A
	s_waitcnt vmcnt(0)                                         // 000000224500: BF8903F7
	v_fma_mixlo_f16 v17, v2, s8, 0                             // 000000224504: CC210011 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022450C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224510: BE812000
	s_cbranch_execz 5                                          // 000000224514: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x52c>
	global_load_b32 v2, v[26:27], off offset:60                // 000000224518: DC52003C 027C001A
	s_waitcnt vmcnt(0)                                         // 000000224520: BF8903F7
	v_fma_mixhi_f16 v17, v2, s8, 0                             // 000000224524: CC220011 02001102
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022452C: 8C7E017E
	ds_load_b128 v[35:38], v34                                 // 000000224530: DBFC0000 23000022
	ds_load_b128 v[39:42], v34 offset:16                       // 000000224538: DBFC0010 27000022
	v_mov_b32_e32 v8, v1                                       // 000000224540: 7E100301
	v_mov_b32_e32 v2, v1                                       // 000000224544: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000224548: 7E060301
	v_mov_b32_e32 v4, v1                                       // 00000022454C: 7E080301
	v_mov_b32_e32 v5, v1                                       // 000000224550: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000224554: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000224558: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 00000022455C: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000224560: BF870212
	v_mov_b32_e32 v8, v7                                       // 000000224564: 7E100307
	v_mov_b32_e32 v7, v6                                       // 000000224568: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 00000022456C: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000224570: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000224574: 7E080303
	v_mov_b32_e32 v3, v2                                       // 000000224578: 7E060302
	v_mov_b32_e32 v2, v1                                       // 00000022457C: 7E040301
	.long 0x7f243880                                           // 000000224580: 7F243880
	s_waitcnt lgkmcnt(0)                                       // 000000224584: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000224588: BF870112
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 00000022458C: CC404002 1C0A470A
	.long 0x7e243992                                           // 000000224594: 7E243992
	s_and_saveexec_b32 s1, s0                                  // 000000224598: BE812000
	s_cbranch_execz 5                                          // 00000022459C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x5b4>
	global_load_b32 v10, v[26:27], off offset:64               // 0000002245A0: DC520040 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002245A8: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 0000002245AC: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002245B4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002245B8: BE812000
	s_cbranch_execz 5                                          // 0000002245BC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x5d4>
	global_load_b32 v10, v[26:27], off offset:68               // 0000002245C0: DC520044 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002245C8: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 0000002245CC: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002245D4: 8C7E017E
	.long 0x7f263880                                           // 0000002245D8: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002245DC: BF870001
	.long 0x7e263993                                           // 0000002245E0: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 0000002245E4: BE812000
	s_cbranch_execz 5                                          // 0000002245E8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x600>
	global_load_b32 v10, v[26:27], off offset:72               // 0000002245EC: DC520048 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002245F4: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 0000002245F8: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224600: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224604: BE812000
	s_cbranch_execz 5                                          // 000000224608: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x620>
	global_load_b32 v10, v[26:27], off offset:76               // 00000022460C: DC52004C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224614: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 000000224618: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224620: 8C7E017E
	.long 0x7f283880                                           // 000000224624: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224628: BF870001
	.long 0x7e283994                                           // 00000022462C: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 000000224630: BE812000
	s_cbranch_execz 5                                          // 000000224634: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x64c>
	global_load_b32 v10, v[26:27], off offset:80               // 000000224638: DC520050 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224640: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 000000224644: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022464C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224650: BE812000
	s_cbranch_execz 5                                          // 000000224654: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x66c>
	global_load_b32 v10, v[26:27], off offset:84               // 000000224658: DC520054 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224660: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 000000224664: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022466C: 8C7E017E
	.long 0x7f2a3880                                           // 000000224670: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224674: BF870001
	.long 0x7e2a3995                                           // 000000224678: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000022467C: BE812000
	s_cbranch_execz 5                                          // 000000224680: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x698>
	global_load_b32 v10, v[26:27], off offset:88               // 000000224684: DC520058 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000022468C: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 000000224690: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224698: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000022469C: BE812000
	s_cbranch_execz 5                                          // 0000002246A0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x6b8>
	global_load_b32 v10, v[26:27], off offset:92               // 0000002246A4: DC52005C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002246AC: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 0000002246B0: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002246B8: 8C7E017E
	.long 0x7f2c3880                                           // 0000002246BC: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002246C0: BF870001
	.long 0x7e2c3996                                           // 0000002246C4: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 0000002246C8: BE812000
	s_cbranch_execz 5                                          // 0000002246CC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x6e4>
	global_load_b32 v10, v[26:27], off offset:96               // 0000002246D0: DC520060 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002246D8: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 0000002246DC: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002246E4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002246E8: BE812000
	s_cbranch_execz 5                                          // 0000002246EC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x704>
	global_load_b32 v10, v[26:27], off offset:100              // 0000002246F0: DC520064 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002246F8: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 0000002246FC: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224704: 8C7E017E
	.long 0x7f2e3880                                           // 000000224708: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022470C: BF870001
	.long 0x7e2e3997                                           // 000000224710: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 000000224714: BE812000
	s_cbranch_execz 5                                          // 000000224718: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x730>
	global_load_b32 v10, v[26:27], off offset:104              // 00000022471C: DC520068 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224724: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 000000224728: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224730: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224734: BE812000
	s_cbranch_execz 5                                          // 000000224738: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x750>
	global_load_b32 v10, v[26:27], off offset:108              // 00000022473C: DC52006C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224744: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 000000224748: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224750: 8C7E017E
	.long 0x7f303880                                           // 000000224754: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224758: BF870001
	.long 0x7e303998                                           // 00000022475C: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 000000224760: BE812000
	s_cbranch_execz 5                                          // 000000224764: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x77c>
	global_load_b32 v10, v[26:27], off offset:112              // 000000224768: DC520070 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224770: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 000000224774: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022477C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224780: BE812000
	s_cbranch_execz 5                                          // 000000224784: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x79c>
	global_load_b32 v10, v[26:27], off offset:116              // 000000224788: DC520074 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224790: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 000000224794: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022479C: 8C7E017E
	.long 0x7f323880                                           // 0000002247A0: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002247A4: BF870001
	.long 0x7e323999                                           // 0000002247A8: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 0000002247AC: BE812000
	s_cbranch_execz 5                                          // 0000002247B0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x7c8>
	global_load_b32 v10, v[26:27], off offset:120              // 0000002247B4: DC520078 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002247BC: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 0000002247C0: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002247C8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002247CC: BE812000
	s_cbranch_execz 5                                          // 0000002247D0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x7e8>
	global_load_b32 v10, v[26:27], off offset:124              // 0000002247D4: DC52007C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002247DC: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 0000002247E0: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002247E8: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:32                       // 0000002247EC: DBFC0020 23000022
	ds_load_b128 v[39:42], v34 offset:48                       // 0000002247F4: DBFC0030 27000022
	.long 0x7f143880                                           // 0000002247FC: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224800: BF870001
	.long 0x7e14398a                                           // 000000224804: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 000000224808: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 00000022480C: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 000000224814: BE812000
	s_cbranch_execz 5                                          // 000000224818: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x830>
	global_load_b32 v11, v[26:27], off offset:128              // 00000022481C: DC520080 0B7C001A
	s_waitcnt vmcnt(0)                                         // 000000224824: BF8903F7
	v_fma_mixlo_f16 v10, v11, s8, 0                            // 000000224828: CC21000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224830: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224834: BE812000
	s_cbranch_execz 5                                          // 000000224838: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x850>
	global_load_b32 v11, v[26:27], off offset:132              // 00000022483C: DC520084 0B7C001A
	s_waitcnt vmcnt(0)                                         // 000000224844: BF8903F7
	v_fma_mixhi_f16 v10, v11, s8, 0                            // 000000224848: CC22000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224850: 8C7E017E
	.long 0x7f163880                                           // 000000224854: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224858: BF870001
	.long 0x7e16398b                                           // 00000022485C: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 000000224860: BE812000
	s_cbranch_execz 5                                          // 000000224864: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x87c>
	global_load_b32 v12, v[26:27], off offset:136              // 000000224868: DC520088 0C7C001A
	s_waitcnt vmcnt(0)                                         // 000000224870: BF8903F7
	v_fma_mixlo_f16 v11, v12, s8, 0                            // 000000224874: CC21000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022487C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224880: BE812000
	s_cbranch_execz 5                                          // 000000224884: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x89c>
	global_load_b32 v12, v[26:27], off offset:140              // 000000224888: DC52008C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 000000224890: BF8903F7
	v_fma_mixhi_f16 v11, v12, s8, 0                            // 000000224894: CC22000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022489C: 8C7E017E
	.long 0x7f183880                                           // 0000002248A0: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002248A4: BF870001
	.long 0x7e18398c                                           // 0000002248A8: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 0000002248AC: BE812000
	s_cbranch_execz 5                                          // 0000002248B0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x8c8>
	global_load_b32 v13, v[26:27], off offset:144              // 0000002248B4: DC520090 0D7C001A
	s_waitcnt vmcnt(0)                                         // 0000002248BC: BF8903F7
	v_fma_mixlo_f16 v12, v13, s8, 0                            // 0000002248C0: CC21000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002248C8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002248CC: BE812000
	s_cbranch_execz 5                                          // 0000002248D0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x8e8>
	global_load_b32 v13, v[26:27], off offset:148              // 0000002248D4: DC520094 0D7C001A
	s_waitcnt vmcnt(0)                                         // 0000002248DC: BF8903F7
	v_fma_mixhi_f16 v12, v13, s8, 0                            // 0000002248E0: CC22000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002248E8: 8C7E017E
	.long 0x7f1a3880                                           // 0000002248EC: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002248F0: BF870001
	.long 0x7e1a398d                                           // 0000002248F4: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 0000002248F8: BE812000
	s_cbranch_execz 5                                          // 0000002248FC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x914>
	global_load_b32 v14, v[26:27], off offset:152              // 000000224900: DC520098 0E7C001A
	s_waitcnt vmcnt(0)                                         // 000000224908: BF8903F7
	v_fma_mixlo_f16 v13, v14, s8, 0                            // 00000022490C: CC21000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224914: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224918: BE812000
	s_cbranch_execz 5                                          // 00000022491C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x934>
	global_load_b32 v14, v[26:27], off offset:156              // 000000224920: DC52009C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 000000224928: BF8903F7
	v_fma_mixhi_f16 v13, v14, s8, 0                            // 00000022492C: CC22000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224934: 8C7E017E
	.long 0x7f1c3880                                           // 000000224938: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022493C: BF870001
	.long 0x7e1c398e                                           // 000000224940: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 000000224944: BE812000
	s_cbranch_execz 5                                          // 000000224948: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x960>
	global_load_b32 v15, v[26:27], off offset:160              // 00000022494C: DC5200A0 0F7C001A
	s_waitcnt vmcnt(0)                                         // 000000224954: BF8903F7
	v_fma_mixlo_f16 v14, v15, s8, 0                            // 000000224958: CC21000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224960: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224964: BE812000
	s_cbranch_execz 5                                          // 000000224968: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x980>
	global_load_b32 v15, v[26:27], off offset:164              // 00000022496C: DC5200A4 0F7C001A
	s_waitcnt vmcnt(0)                                         // 000000224974: BF8903F7
	v_fma_mixhi_f16 v14, v15, s8, 0                            // 000000224978: CC22000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224980: 8C7E017E
	.long 0x7f1e3880                                           // 000000224984: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224988: BF870001
	.long 0x7e1e398f                                           // 00000022498C: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 000000224990: BE812000
	s_cbranch_execz 5                                          // 000000224994: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x9ac>
	global_load_b32 v16, v[26:27], off offset:168              // 000000224998: DC5200A8 107C001A
	s_waitcnt vmcnt(0)                                         // 0000002249A0: BF8903F7
	v_fma_mixlo_f16 v15, v16, s8, 0                            // 0000002249A4: CC21000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002249AC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002249B0: BE812000
	s_cbranch_execz 5                                          // 0000002249B4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x9cc>
	global_load_b32 v16, v[26:27], off offset:172              // 0000002249B8: DC5200AC 107C001A
	s_waitcnt vmcnt(0)                                         // 0000002249C0: BF8903F7
	v_fma_mixhi_f16 v15, v16, s8, 0                            // 0000002249C4: CC22000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002249CC: 8C7E017E
	.long 0x7f203880                                           // 0000002249D0: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002249D4: BF870001
	.long 0x7e203990                                           // 0000002249D8: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 0000002249DC: BE812000
	s_cbranch_execz 5                                          // 0000002249E0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x9f8>
	global_load_b32 v17, v[26:27], off offset:176              // 0000002249E4: DC5200B0 117C001A
	s_waitcnt vmcnt(0)                                         // 0000002249EC: BF8903F7
	v_fma_mixlo_f16 v16, v17, s8, 0                            // 0000002249F0: CC210010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002249F8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002249FC: BE812000
	s_cbranch_execz 5                                          // 000000224A00: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xa18>
	global_load_b32 v17, v[26:27], off offset:180              // 000000224A04: DC5200B4 117C001A
	s_waitcnt vmcnt(0)                                         // 000000224A0C: BF8903F7
	v_fma_mixhi_f16 v16, v17, s8, 0                            // 000000224A10: CC220010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224A18: 8C7E017E
	.long 0x7f223880                                           // 000000224A1C: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224A20: BF870001
	.long 0x7e223991                                           // 000000224A24: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 000000224A28: BE812000
	s_cbranch_execz 5                                          // 000000224A2C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xa44>
	global_load_b32 v18, v[26:27], off offset:184              // 000000224A30: DC5200B8 127C001A
	s_waitcnt vmcnt(0)                                         // 000000224A38: BF8903F7
	v_fma_mixlo_f16 v17, v18, s8, 0                            // 000000224A3C: CC210011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224A44: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224A48: BE812000
	s_cbranch_execz 5                                          // 000000224A4C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xa64>
	global_load_b32 v18, v[26:27], off offset:188              // 000000224A50: DC5200BC 127C001A
	s_waitcnt vmcnt(0)                                         // 000000224A58: BF8903F7
	v_fma_mixhi_f16 v17, v18, s8, 0                            // 000000224A5C: CC220011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224A64: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:64                       // 000000224A68: DBFC0040 23000022
	ds_load_b128 v[39:42], v34 offset:80                       // 000000224A70: DBFC0050 27000022
	.long 0x7f243880                                           // 000000224A78: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224A7C: BF870001
	.long 0x7e243992                                           // 000000224A80: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 000000224A84: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 000000224A88: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 000000224A90: BE812000
	s_cbranch_execz 5                                          // 000000224A94: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xaac>
	global_load_b32 v10, v[26:27], off offset:192              // 000000224A98: DC5200C0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224AA0: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 000000224AA4: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224AAC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224AB0: BE812000
	s_cbranch_execz 5                                          // 000000224AB4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xacc>
	global_load_b32 v10, v[26:27], off offset:196              // 000000224AB8: DC5200C4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224AC0: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 000000224AC4: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224ACC: 8C7E017E
	.long 0x7f263880                                           // 000000224AD0: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224AD4: BF870001
	.long 0x7e263993                                           // 000000224AD8: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 000000224ADC: BE812000
	s_cbranch_execz 5                                          // 000000224AE0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xaf8>
	global_load_b32 v10, v[26:27], off offset:200              // 000000224AE4: DC5200C8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224AEC: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 000000224AF0: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224AF8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224AFC: BE812000
	s_cbranch_execz 5                                          // 000000224B00: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xb18>
	global_load_b32 v10, v[26:27], off offset:204              // 000000224B04: DC5200CC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224B0C: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 000000224B10: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224B18: 8C7E017E
	.long 0x7f283880                                           // 000000224B1C: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224B20: BF870001
	.long 0x7e283994                                           // 000000224B24: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 000000224B28: BE812000
	s_cbranch_execz 5                                          // 000000224B2C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xb44>
	global_load_b32 v10, v[26:27], off offset:208              // 000000224B30: DC5200D0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224B38: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 000000224B3C: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224B44: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224B48: BE812000
	s_cbranch_execz 5                                          // 000000224B4C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xb64>
	global_load_b32 v10, v[26:27], off offset:212              // 000000224B50: DC5200D4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224B58: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 000000224B5C: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224B64: 8C7E017E
	.long 0x7f2a3880                                           // 000000224B68: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224B6C: BF870001
	.long 0x7e2a3995                                           // 000000224B70: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 000000224B74: BE812000
	s_cbranch_execz 5                                          // 000000224B78: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xb90>
	global_load_b32 v10, v[26:27], off offset:216              // 000000224B7C: DC5200D8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224B84: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 000000224B88: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224B90: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224B94: BE812000
	s_cbranch_execz 5                                          // 000000224B98: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xbb0>
	global_load_b32 v10, v[26:27], off offset:220              // 000000224B9C: DC5200DC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224BA4: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 000000224BA8: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224BB0: 8C7E017E
	.long 0x7f2c3880                                           // 000000224BB4: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224BB8: BF870001
	.long 0x7e2c3996                                           // 000000224BBC: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 000000224BC0: BE812000
	s_cbranch_execz 5                                          // 000000224BC4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xbdc>
	global_load_b32 v10, v[26:27], off offset:224              // 000000224BC8: DC5200E0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224BD0: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 000000224BD4: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224BDC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224BE0: BE812000
	s_cbranch_execz 5                                          // 000000224BE4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xbfc>
	global_load_b32 v10, v[26:27], off offset:228              // 000000224BE8: DC5200E4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224BF0: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 000000224BF4: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224BFC: 8C7E017E
	.long 0x7f2e3880                                           // 000000224C00: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224C04: BF870001
	.long 0x7e2e3997                                           // 000000224C08: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 000000224C0C: BE812000
	s_cbranch_execz 5                                          // 000000224C10: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xc28>
	global_load_b32 v10, v[26:27], off offset:232              // 000000224C14: DC5200E8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224C1C: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 000000224C20: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224C28: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224C2C: BE812000
	s_cbranch_execz 5                                          // 000000224C30: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xc48>
	global_load_b32 v10, v[26:27], off offset:236              // 000000224C34: DC5200EC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224C3C: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 000000224C40: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224C48: 8C7E017E
	.long 0x7f303880                                           // 000000224C4C: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224C50: BF870001
	.long 0x7e303998                                           // 000000224C54: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 000000224C58: BE812000
	s_cbranch_execz 5                                          // 000000224C5C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xc74>
	global_load_b32 v10, v[26:27], off offset:240              // 000000224C60: DC5200F0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224C68: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 000000224C6C: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224C74: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224C78: BE812000
	s_cbranch_execz 5                                          // 000000224C7C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xc94>
	global_load_b32 v10, v[26:27], off offset:244              // 000000224C80: DC5200F4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224C88: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 000000224C8C: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224C94: 8C7E017E
	.long 0x7f323880                                           // 000000224C98: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224C9C: BF870001
	.long 0x7e323999                                           // 000000224CA0: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 000000224CA4: BE812000
	s_cbranch_execz 5                                          // 000000224CA8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xcc0>
	global_load_b32 v10, v[26:27], off offset:248              // 000000224CAC: DC5200F8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224CB4: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 000000224CB8: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224CC0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224CC4: BE812000
	s_cbranch_execz 5                                          // 000000224CC8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xce0>
	global_load_b32 v10, v[26:27], off offset:252              // 000000224CCC: DC5200FC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224CD4: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 000000224CD8: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224CE0: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:96                       // 000000224CE4: DBFC0060 23000022
	ds_load_b128 v[39:42], v34 offset:112                      // 000000224CEC: DBFC0070 27000022
	.long 0x7f143880                                           // 000000224CF4: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224CF8: BF870001
	.long 0x7e14398a                                           // 000000224CFC: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 000000224D00: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 000000224D04: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 000000224D0C: BE812000
	s_cbranch_execz 5                                          // 000000224D10: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xd28>
	global_load_b32 v11, v[26:27], off offset:256              // 000000224D14: DC520100 0B7C001A
	s_waitcnt vmcnt(0)                                         // 000000224D1C: BF8903F7
	v_fma_mixlo_f16 v10, v11, s8, 0                            // 000000224D20: CC21000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224D28: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224D2C: BE812000
	s_cbranch_execz 5                                          // 000000224D30: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xd48>
	global_load_b32 v11, v[26:27], off offset:260              // 000000224D34: DC520104 0B7C001A
	s_waitcnt vmcnt(0)                                         // 000000224D3C: BF8903F7
	v_fma_mixhi_f16 v10, v11, s8, 0                            // 000000224D40: CC22000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224D48: 8C7E017E
	.long 0x7f163880                                           // 000000224D4C: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224D50: BF870001
	.long 0x7e16398b                                           // 000000224D54: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 000000224D58: BE812000
	s_cbranch_execz 5                                          // 000000224D5C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xd74>
	global_load_b32 v12, v[26:27], off offset:264              // 000000224D60: DC520108 0C7C001A
	s_waitcnt vmcnt(0)                                         // 000000224D68: BF8903F7
	v_fma_mixlo_f16 v11, v12, s8, 0                            // 000000224D6C: CC21000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224D74: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224D78: BE812000
	s_cbranch_execz 5                                          // 000000224D7C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xd94>
	global_load_b32 v12, v[26:27], off offset:268              // 000000224D80: DC52010C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 000000224D88: BF8903F7
	v_fma_mixhi_f16 v11, v12, s8, 0                            // 000000224D8C: CC22000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224D94: 8C7E017E
	.long 0x7f183880                                           // 000000224D98: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224D9C: BF870001
	.long 0x7e18398c                                           // 000000224DA0: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 000000224DA4: BE812000
	s_cbranch_execz 5                                          // 000000224DA8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xdc0>
	global_load_b32 v13, v[26:27], off offset:272              // 000000224DAC: DC520110 0D7C001A
	s_waitcnt vmcnt(0)                                         // 000000224DB4: BF8903F7
	v_fma_mixlo_f16 v12, v13, s8, 0                            // 000000224DB8: CC21000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224DC0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224DC4: BE812000
	s_cbranch_execz 5                                          // 000000224DC8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xde0>
	global_load_b32 v13, v[26:27], off offset:276              // 000000224DCC: DC520114 0D7C001A
	s_waitcnt vmcnt(0)                                         // 000000224DD4: BF8903F7
	v_fma_mixhi_f16 v12, v13, s8, 0                            // 000000224DD8: CC22000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224DE0: 8C7E017E
	.long 0x7f1a3880                                           // 000000224DE4: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224DE8: BF870001
	.long 0x7e1a398d                                           // 000000224DEC: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 000000224DF0: BE812000
	s_cbranch_execz 5                                          // 000000224DF4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xe0c>
	global_load_b32 v14, v[26:27], off offset:280              // 000000224DF8: DC520118 0E7C001A
	s_waitcnt vmcnt(0)                                         // 000000224E00: BF8903F7
	v_fma_mixlo_f16 v13, v14, s8, 0                            // 000000224E04: CC21000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224E0C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224E10: BE812000
	s_cbranch_execz 5                                          // 000000224E14: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xe2c>
	global_load_b32 v14, v[26:27], off offset:284              // 000000224E18: DC52011C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 000000224E20: BF8903F7
	v_fma_mixhi_f16 v13, v14, s8, 0                            // 000000224E24: CC22000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224E2C: 8C7E017E
	.long 0x7f1c3880                                           // 000000224E30: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224E34: BF870001
	.long 0x7e1c398e                                           // 000000224E38: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 000000224E3C: BE812000
	s_cbranch_execz 5                                          // 000000224E40: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xe58>
	global_load_b32 v15, v[26:27], off offset:288              // 000000224E44: DC520120 0F7C001A
	s_waitcnt vmcnt(0)                                         // 000000224E4C: BF8903F7
	v_fma_mixlo_f16 v14, v15, s8, 0                            // 000000224E50: CC21000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224E58: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224E5C: BE812000
	s_cbranch_execz 5                                          // 000000224E60: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xe78>
	global_load_b32 v15, v[26:27], off offset:292              // 000000224E64: DC520124 0F7C001A
	s_waitcnt vmcnt(0)                                         // 000000224E6C: BF8903F7
	v_fma_mixhi_f16 v14, v15, s8, 0                            // 000000224E70: CC22000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224E78: 8C7E017E
	.long 0x7f1e3880                                           // 000000224E7C: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224E80: BF870001
	.long 0x7e1e398f                                           // 000000224E84: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 000000224E88: BE812000
	s_cbranch_execz 5                                          // 000000224E8C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xea4>
	global_load_b32 v16, v[26:27], off offset:296              // 000000224E90: DC520128 107C001A
	s_waitcnt vmcnt(0)                                         // 000000224E98: BF8903F7
	v_fma_mixlo_f16 v15, v16, s8, 0                            // 000000224E9C: CC21000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224EA4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224EA8: BE812000
	s_cbranch_execz 5                                          // 000000224EAC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xec4>
	global_load_b32 v16, v[26:27], off offset:300              // 000000224EB0: DC52012C 107C001A
	s_waitcnt vmcnt(0)                                         // 000000224EB8: BF8903F7
	v_fma_mixhi_f16 v15, v16, s8, 0                            // 000000224EBC: CC22000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224EC4: 8C7E017E
	.long 0x7f203880                                           // 000000224EC8: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224ECC: BF870001
	.long 0x7e203990                                           // 000000224ED0: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 000000224ED4: BE812000
	s_cbranch_execz 5                                          // 000000224ED8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xef0>
	global_load_b32 v17, v[26:27], off offset:304              // 000000224EDC: DC520130 117C001A
	s_waitcnt vmcnt(0)                                         // 000000224EE4: BF8903F7
	v_fma_mixlo_f16 v16, v17, s8, 0                            // 000000224EE8: CC210010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224EF0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224EF4: BE812000
	s_cbranch_execz 5                                          // 000000224EF8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xf10>
	global_load_b32 v17, v[26:27], off offset:308              // 000000224EFC: DC520134 117C001A
	s_waitcnt vmcnt(0)                                         // 000000224F04: BF8903F7
	v_fma_mixhi_f16 v16, v17, s8, 0                            // 000000224F08: CC220010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224F10: 8C7E017E
	.long 0x7f223880                                           // 000000224F14: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224F18: BF870001
	.long 0x7e223991                                           // 000000224F1C: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 000000224F20: BE812000
	s_cbranch_execz 5                                          // 000000224F24: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xf3c>
	global_load_b32 v18, v[26:27], off offset:312              // 000000224F28: DC520138 127C001A
	s_waitcnt vmcnt(0)                                         // 000000224F30: BF8903F7
	v_fma_mixlo_f16 v17, v18, s8, 0                            // 000000224F34: CC210011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224F3C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224F40: BE812000
	s_cbranch_execz 5                                          // 000000224F44: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xf5c>
	global_load_b32 v18, v[26:27], off offset:316              // 000000224F48: DC52013C 127C001A
	s_waitcnt vmcnt(0)                                         // 000000224F50: BF8903F7
	v_fma_mixhi_f16 v17, v18, s8, 0                            // 000000224F54: CC220011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224F5C: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:128                      // 000000224F60: DBFC0080 23000022
	ds_load_b128 v[39:42], v34 offset:144                      // 000000224F68: DBFC0090 27000022
	.long 0x7f243880                                           // 000000224F70: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224F74: BF870001
	.long 0x7e243992                                           // 000000224F78: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 000000224F7C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 000000224F80: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 000000224F88: BE812000
	s_cbranch_execz 5                                          // 000000224F8C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xfa4>
	global_load_b32 v10, v[26:27], off offset:320              // 000000224F90: DC520140 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224F98: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 000000224F9C: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224FA4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224FA8: BE812000
	s_cbranch_execz 5                                          // 000000224FAC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xfc4>
	global_load_b32 v10, v[26:27], off offset:324              // 000000224FB0: DC520144 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224FB8: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 000000224FBC: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224FC4: 8C7E017E
	.long 0x7f263880                                           // 000000224FC8: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000224FCC: BF870001
	.long 0x7e263993                                           // 000000224FD0: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 000000224FD4: BE812000
	s_cbranch_execz 5                                          // 000000224FD8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0xff0>
	global_load_b32 v10, v[26:27], off offset:328              // 000000224FDC: DC520148 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000224FE4: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 000000224FE8: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000224FF0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000224FF4: BE812000
	s_cbranch_execz 5                                          // 000000224FF8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1010>
	global_load_b32 v10, v[26:27], off offset:332              // 000000224FFC: DC52014C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000225004: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 000000225008: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225010: 8C7E017E
	.long 0x7f283880                                           // 000000225014: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225018: BF870001
	.long 0x7e283994                                           // 00000022501C: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 000000225020: BE812000
	s_cbranch_execz 5                                          // 000000225024: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x103c>
	global_load_b32 v10, v[26:27], off offset:336              // 000000225028: DC520150 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000225030: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 000000225034: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022503C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000225040: BE812000
	s_cbranch_execz 5                                          // 000000225044: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x105c>
	global_load_b32 v10, v[26:27], off offset:340              // 000000225048: DC520154 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000225050: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 000000225054: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022505C: 8C7E017E
	.long 0x7f2a3880                                           // 000000225060: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225064: BF870001
	.long 0x7e2a3995                                           // 000000225068: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000022506C: BE812000
	s_cbranch_execz 5                                          // 000000225070: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1088>
	global_load_b32 v10, v[26:27], off offset:344              // 000000225074: DC520158 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000022507C: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 000000225080: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225088: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000022508C: BE812000
	s_cbranch_execz 5                                          // 000000225090: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x10a8>
	global_load_b32 v10, v[26:27], off offset:348              // 000000225094: DC52015C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000022509C: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 0000002250A0: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002250A8: 8C7E017E
	.long 0x7f2c3880                                           // 0000002250AC: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002250B0: BF870001
	.long 0x7e2c3996                                           // 0000002250B4: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 0000002250B8: BE812000
	s_cbranch_execz 5                                          // 0000002250BC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x10d4>
	global_load_b32 v10, v[26:27], off offset:352              // 0000002250C0: DC520160 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002250C8: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 0000002250CC: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002250D4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002250D8: BE812000
	s_cbranch_execz 5                                          // 0000002250DC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x10f4>
	global_load_b32 v10, v[26:27], off offset:356              // 0000002250E0: DC520164 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002250E8: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 0000002250EC: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002250F4: 8C7E017E
	.long 0x7f2e3880                                           // 0000002250F8: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002250FC: BF870001
	.long 0x7e2e3997                                           // 000000225100: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 000000225104: BE812000
	s_cbranch_execz 5                                          // 000000225108: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1120>
	global_load_b32 v10, v[26:27], off offset:360              // 00000022510C: DC520168 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000225114: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 000000225118: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225120: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000225124: BE812000
	s_cbranch_execz 5                                          // 000000225128: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1140>
	global_load_b32 v10, v[26:27], off offset:364              // 00000022512C: DC52016C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000225134: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 000000225138: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225140: 8C7E017E
	.long 0x7f303880                                           // 000000225144: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225148: BF870001
	.long 0x7e303998                                           // 00000022514C: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 000000225150: BE812000
	s_cbranch_execz 5                                          // 000000225154: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x116c>
	global_load_b32 v10, v[26:27], off offset:368              // 000000225158: DC520170 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000225160: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 000000225164: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022516C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000225170: BE812000
	s_cbranch_execz 5                                          // 000000225174: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x118c>
	global_load_b32 v10, v[26:27], off offset:372              // 000000225178: DC520174 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000225180: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 000000225184: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022518C: 8C7E017E
	.long 0x7f323880                                           // 000000225190: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225194: BF870001
	.long 0x7e323999                                           // 000000225198: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000022519C: BE812000
	s_cbranch_execz 5                                          // 0000002251A0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x11b8>
	global_load_b32 v10, v[26:27], off offset:376              // 0000002251A4: DC520178 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002251AC: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 0000002251B0: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002251B8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002251BC: BE812000
	s_cbranch_execz 5                                          // 0000002251C0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x11d8>
	global_load_b32 v10, v[26:27], off offset:380              // 0000002251C4: DC52017C 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002251CC: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 0000002251D0: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002251D8: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:160                      // 0000002251DC: DBFC00A0 23000022
	ds_load_b128 v[39:42], v34 offset:176                      // 0000002251E4: DBFC00B0 27000022
	.long 0x7f143880                                           // 0000002251EC: 7F143880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002251F0: BF870001
	.long 0x7e14398a                                           // 0000002251F4: 7E14398A
	s_waitcnt lgkmcnt(0)                                       // 0000002251F8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[35:42], v[2:9] // 0000002251FC: CC404002 1C0A4712
	s_and_saveexec_b32 s1, s0                                  // 000000225204: BE812000
	s_cbranch_execz 5                                          // 000000225208: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1220>
	global_load_b32 v11, v[26:27], off offset:384              // 00000022520C: DC520180 0B7C001A
	s_waitcnt vmcnt(0)                                         // 000000225214: BF8903F7
	v_fma_mixlo_f16 v10, v11, s8, 0                            // 000000225218: CC21000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225220: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000225224: BE812000
	s_cbranch_execz 5                                          // 000000225228: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1240>
	global_load_b32 v11, v[26:27], off offset:388              // 00000022522C: DC520184 0B7C001A
	s_waitcnt vmcnt(0)                                         // 000000225234: BF8903F7
	v_fma_mixhi_f16 v10, v11, s8, 0                            // 000000225238: CC22000A 0200110B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225240: 8C7E017E
	.long 0x7f163880                                           // 000000225244: 7F163880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225248: BF870001
	.long 0x7e16398b                                           // 00000022524C: 7E16398B
	s_and_saveexec_b32 s1, s0                                  // 000000225250: BE812000
	s_cbranch_execz 5                                          // 000000225254: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x126c>
	global_load_b32 v12, v[26:27], off offset:392              // 000000225258: DC520188 0C7C001A
	s_waitcnt vmcnt(0)                                         // 000000225260: BF8903F7
	v_fma_mixlo_f16 v11, v12, s8, 0                            // 000000225264: CC21000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022526C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000225270: BE812000
	s_cbranch_execz 5                                          // 000000225274: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x128c>
	global_load_b32 v12, v[26:27], off offset:396              // 000000225278: DC52018C 0C7C001A
	s_waitcnt vmcnt(0)                                         // 000000225280: BF8903F7
	v_fma_mixhi_f16 v11, v12, s8, 0                            // 000000225284: CC22000B 0200110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022528C: 8C7E017E
	.long 0x7f183880                                           // 000000225290: 7F183880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225294: BF870001
	.long 0x7e18398c                                           // 000000225298: 7E18398C
	s_and_saveexec_b32 s1, s0                                  // 00000022529C: BE812000
	s_cbranch_execz 5                                          // 0000002252A0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x12b8>
	global_load_b32 v13, v[26:27], off offset:400              // 0000002252A4: DC520190 0D7C001A
	s_waitcnt vmcnt(0)                                         // 0000002252AC: BF8903F7
	v_fma_mixlo_f16 v12, v13, s8, 0                            // 0000002252B0: CC21000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002252B8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002252BC: BE812000
	s_cbranch_execz 5                                          // 0000002252C0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x12d8>
	global_load_b32 v13, v[26:27], off offset:404              // 0000002252C4: DC520194 0D7C001A
	s_waitcnt vmcnt(0)                                         // 0000002252CC: BF8903F7
	v_fma_mixhi_f16 v12, v13, s8, 0                            // 0000002252D0: CC22000C 0200110D
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002252D8: 8C7E017E
	.long 0x7f1a3880                                           // 0000002252DC: 7F1A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002252E0: BF870001
	.long 0x7e1a398d                                           // 0000002252E4: 7E1A398D
	s_and_saveexec_b32 s1, s0                                  // 0000002252E8: BE812000
	s_cbranch_execz 5                                          // 0000002252EC: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1304>
	global_load_b32 v14, v[26:27], off offset:408              // 0000002252F0: DC520198 0E7C001A
	s_waitcnt vmcnt(0)                                         // 0000002252F8: BF8903F7
	v_fma_mixlo_f16 v13, v14, s8, 0                            // 0000002252FC: CC21000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225304: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000225308: BE812000
	s_cbranch_execz 5                                          // 00000022530C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1324>
	global_load_b32 v14, v[26:27], off offset:412              // 000000225310: DC52019C 0E7C001A
	s_waitcnt vmcnt(0)                                         // 000000225318: BF8903F7
	v_fma_mixhi_f16 v13, v14, s8, 0                            // 00000022531C: CC22000D 0200110E
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225324: 8C7E017E
	.long 0x7f1c3880                                           // 000000225328: 7F1C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022532C: BF870001
	.long 0x7e1c398e                                           // 000000225330: 7E1C398E
	s_and_saveexec_b32 s1, s0                                  // 000000225334: BE812000
	s_cbranch_execz 5                                          // 000000225338: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1350>
	global_load_b32 v15, v[26:27], off offset:416              // 00000022533C: DC5201A0 0F7C001A
	s_waitcnt vmcnt(0)                                         // 000000225344: BF8903F7
	v_fma_mixlo_f16 v14, v15, s8, 0                            // 000000225348: CC21000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225350: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000225354: BE812000
	s_cbranch_execz 5                                          // 000000225358: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1370>
	global_load_b32 v15, v[26:27], off offset:420              // 00000022535C: DC5201A4 0F7C001A
	s_waitcnt vmcnt(0)                                         // 000000225364: BF8903F7
	v_fma_mixhi_f16 v14, v15, s8, 0                            // 000000225368: CC22000E 0200110F
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225370: 8C7E017E
	.long 0x7f1e3880                                           // 000000225374: 7F1E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225378: BF870001
	.long 0x7e1e398f                                           // 00000022537C: 7E1E398F
	s_and_saveexec_b32 s1, s0                                  // 000000225380: BE812000
	s_cbranch_execz 5                                          // 000000225384: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x139c>
	global_load_b32 v16, v[26:27], off offset:424              // 000000225388: DC5201A8 107C001A
	s_waitcnt vmcnt(0)                                         // 000000225390: BF8903F7
	v_fma_mixlo_f16 v15, v16, s8, 0                            // 000000225394: CC21000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022539C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002253A0: BE812000
	s_cbranch_execz 5                                          // 0000002253A4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x13bc>
	global_load_b32 v16, v[26:27], off offset:428              // 0000002253A8: DC5201AC 107C001A
	s_waitcnt vmcnt(0)                                         // 0000002253B0: BF8903F7
	v_fma_mixhi_f16 v15, v16, s8, 0                            // 0000002253B4: CC22000F 02001110
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002253BC: 8C7E017E
	.long 0x7f203880                                           // 0000002253C0: 7F203880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002253C4: BF870001
	.long 0x7e203990                                           // 0000002253C8: 7E203990
	s_and_saveexec_b32 s1, s0                                  // 0000002253CC: BE812000
	s_cbranch_execz 5                                          // 0000002253D0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x13e8>
	global_load_b32 v17, v[26:27], off offset:432              // 0000002253D4: DC5201B0 117C001A
	s_waitcnt vmcnt(0)                                         // 0000002253DC: BF8903F7
	v_fma_mixlo_f16 v16, v17, s8, 0                            // 0000002253E0: CC210010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002253E8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002253EC: BE812000
	s_cbranch_execz 5                                          // 0000002253F0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1408>
	global_load_b32 v17, v[26:27], off offset:436              // 0000002253F4: DC5201B4 117C001A
	s_waitcnt vmcnt(0)                                         // 0000002253FC: BF8903F7
	v_fma_mixhi_f16 v16, v17, s8, 0                            // 000000225400: CC220010 02001111
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225408: 8C7E017E
	.long 0x7f223880                                           // 00000022540C: 7F223880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225410: BF870001
	.long 0x7e223991                                           // 000000225414: 7E223991
	s_and_saveexec_b32 s1, s0                                  // 000000225418: BE812000
	s_cbranch_execz 5                                          // 00000022541C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1434>
	global_load_b32 v18, v[26:27], off offset:440              // 000000225420: DC5201B8 127C001A
	s_waitcnt vmcnt(0)                                         // 000000225428: BF8903F7
	v_fma_mixlo_f16 v17, v18, s8, 0                            // 00000022542C: CC210011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225434: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000225438: BE812000
	s_cbranch_execz 5                                          // 00000022543C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1454>
	global_load_b32 v18, v[26:27], off offset:444              // 000000225440: DC5201BC 127C001A
	s_waitcnt vmcnt(0)                                         // 000000225448: BF8903F7
	v_fma_mixhi_f16 v17, v18, s8, 0                            // 00000022544C: CC220011 02001112
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225454: 8C7E017E
	ds_load_b128 v[35:38], v34 offset:192                      // 000000225458: DBFC00C0 23000022
	ds_load_b128 v[39:42], v34 offset:208                      // 000000225460: DBFC00D0 27000022
	.long 0x7f243880                                           // 000000225468: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022546C: BF870001
	.long 0x7e243992                                           // 000000225470: 7E243992
	s_waitcnt lgkmcnt(0)                                       // 000000225474: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[10:17], v[35:42], v[2:9] // 000000225478: CC404002 1C0A470A
	s_and_saveexec_b32 s1, s0                                  // 000000225480: BE812000
	s_cbranch_execz 5                                          // 000000225484: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x149c>
	global_load_b32 v10, v[26:27], off offset:448              // 000000225488: DC5201C0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000225490: BF8903F7
	v_fma_mixlo_f16 v18, v10, s8, 0                            // 000000225494: CC210012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000022549C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002254A0: BE812000
	s_cbranch_execz 5                                          // 0000002254A4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x14bc>
	global_load_b32 v10, v[26:27], off offset:452              // 0000002254A8: DC5201C4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002254B0: BF8903F7
	v_fma_mixhi_f16 v18, v10, s8, 0                            // 0000002254B4: CC220012 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002254BC: 8C7E017E
	.long 0x7f263880                                           // 0000002254C0: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002254C4: BF870001
	.long 0x7e263993                                           // 0000002254C8: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 0000002254CC: BE812000
	s_cbranch_execz 5                                          // 0000002254D0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x14e8>
	global_load_b32 v10, v[26:27], off offset:456              // 0000002254D4: DC5201C8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002254DC: BF8903F7
	v_fma_mixlo_f16 v19, v10, s8, 0                            // 0000002254E0: CC210013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002254E8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002254EC: BE812000
	s_cbranch_execz 5                                          // 0000002254F0: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1508>
	global_load_b32 v10, v[26:27], off offset:460              // 0000002254F4: DC5201CC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002254FC: BF8903F7
	v_fma_mixhi_f16 v19, v10, s8, 0                            // 000000225500: CC220013 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225508: 8C7E017E
	.long 0x7f283880                                           // 00000022550C: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225510: BF870001
	.long 0x7e283994                                           // 000000225514: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 000000225518: BE812000
	s_cbranch_execz 5                                          // 00000022551C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1534>
	global_load_b32 v10, v[26:27], off offset:464              // 000000225520: DC5201D0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000225528: BF8903F7
	v_fma_mixlo_f16 v20, v10, s8, 0                            // 00000022552C: CC210014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225534: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000225538: BE812000
	s_cbranch_execz 5                                          // 00000022553C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1554>
	global_load_b32 v10, v[26:27], off offset:468              // 000000225540: DC5201D4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000225548: BF8903F7
	v_fma_mixhi_f16 v20, v10, s8, 0                            // 00000022554C: CC220014 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225554: 8C7E017E
	.long 0x7f2a3880                                           // 000000225558: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022555C: BF870001
	.long 0x7e2a3995                                           // 000000225560: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 000000225564: BE812000
	s_cbranch_execz 5                                          // 000000225568: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1580>
	global_load_b32 v10, v[26:27], off offset:472              // 00000022556C: DC5201D8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000225574: BF8903F7
	v_fma_mixlo_f16 v21, v10, s8, 0                            // 000000225578: CC210015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225580: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000225584: BE812000
	s_cbranch_execz 5                                          // 000000225588: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x15a0>
	global_load_b32 v10, v[26:27], off offset:476              // 00000022558C: DC5201DC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000225594: BF8903F7
	v_fma_mixhi_f16 v21, v10, s8, 0                            // 000000225598: CC220015 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002255A0: 8C7E017E
	.long 0x7f2c3880                                           // 0000002255A4: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002255A8: BF870001
	.long 0x7e2c3996                                           // 0000002255AC: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 0000002255B0: BE812000
	s_cbranch_execz 5                                          // 0000002255B4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x15cc>
	global_load_b32 v10, v[26:27], off offset:480              // 0000002255B8: DC5201E0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002255C0: BF8903F7
	v_fma_mixlo_f16 v22, v10, s8, 0                            // 0000002255C4: CC210016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002255CC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002255D0: BE812000
	s_cbranch_execz 5                                          // 0000002255D4: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x15ec>
	global_load_b32 v10, v[26:27], off offset:484              // 0000002255D8: DC5201E4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002255E0: BF8903F7
	v_fma_mixhi_f16 v22, v10, s8, 0                            // 0000002255E4: CC220016 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002255EC: 8C7E017E
	.long 0x7f2e3880                                           // 0000002255F0: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002255F4: BF870001
	.long 0x7e2e3997                                           // 0000002255F8: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 0000002255FC: BE812000
	s_cbranch_execz 5                                          // 000000225600: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1618>
	global_load_b32 v10, v[26:27], off offset:488              // 000000225604: DC5201E8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000022560C: BF8903F7
	v_fma_mixlo_f16 v23, v10, s8, 0                            // 000000225610: CC210017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225618: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000022561C: BE812000
	s_cbranch_execz 5                                          // 000000225620: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1638>
	global_load_b32 v10, v[26:27], off offset:492              // 000000225624: DC5201EC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 00000022562C: BF8903F7
	v_fma_mixhi_f16 v23, v10, s8, 0                            // 000000225630: CC220017 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225638: 8C7E017E
	.long 0x7f303880                                           // 00000022563C: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225640: BF870001
	.long 0x7e303998                                           // 000000225644: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 000000225648: BE812000
	s_cbranch_execz 5                                          // 00000022564C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1664>
	global_load_b32 v10, v[26:27], off offset:496              // 000000225650: DC5201F0 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000225658: BF8903F7
	v_fma_mixlo_f16 v24, v10, s8, 0                            // 00000022565C: CC210018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225664: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 000000225668: BE812000
	s_cbranch_execz 5                                          // 00000022566C: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1684>
	global_load_b32 v10, v[26:27], off offset:500              // 000000225670: DC5201F4 0A7C001A
	s_waitcnt vmcnt(0)                                         // 000000225678: BF8903F7
	v_fma_mixhi_f16 v24, v10, s8, 0                            // 00000022567C: CC220018 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000225684: 8C7E017E
	.long 0x7f323880                                           // 000000225688: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022568C: BF870001
	.long 0x7e323999                                           // 000000225690: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 000000225694: BE812000
	s_cbranch_execz 5                                          // 000000225698: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x16b0>
	global_load_b32 v10, v[26:27], off offset:504              // 00000022569C: DC5201F8 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002256A4: BF8903F7
	v_fma_mixlo_f16 v25, v10, s8, 0                            // 0000002256A8: CC210019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002256B0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000002256B4: BE812000
	s_cbranch_execz 5                                          // 0000002256B8: BFA50005 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x16d0>
	global_load_b32 v10, v[26:27], off offset:508              // 0000002256BC: DC5201FC 0A7C001A
	s_waitcnt vmcnt(0)                                         // 0000002256C4: BF8903F7
	v_fma_mixhi_f16 v25, v10, s8, 0                            // 0000002256C8: CC220019 0200110A
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002256D0: 8C7E017E
	ds_load_b128 v[10:13], v34 offset:224                      // 0000002256D4: DBFC00E0 0A000022
	ds_load_b128 v[14:17], v34 offset:240                      // 0000002256DC: DBFC00F0 0E000022
	s_waitcnt lgkmcnt(0)                                       // 0000002256E4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[18:25], v[10:17], v[2:9] // 0000002256E8: CC404002 1C0A1512
	s_or_b32 exec_lo, exec_lo, s9                              // 0000002256F0: 8C7E097E
	v_or_b32_e32 v11, v0, v31                                  // 0000002256F4: 38163F00
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 0000002256F8: CA100080 0C0C0080
	s_xor_b32 s1, vcc_lo, -1                                   // 000000225700: 8D01C16A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000225704: BF8704B2
	.long 0xd44b0000                                           // 000000225708: D44B0000
	v_cndmask_b32_e32 v1, v29, v11, vcc_lo                     // 00000022570C: 0202171D
	v_lshlrev_b32_e32 v10, 2, v11                              // 000000225710: 30141682
	s_and_b32 s9, s1, s0                                       // 000000225714: 8B090001
	s_and_saveexec_b32 s0, s9                                  // 000000225718: BE802009
	s_cbranch_execz 36                                         // 00000022571C: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x17b0>
	ds_load_b32 v0, v10 offset:18432                           // 000000225720: D8D84800 0000000A
	ds_load_b32 v13, v32                                       // 000000225728: D8D80000 0D000020
	s_waitcnt lgkmcnt(0)                                       // 000000225730: BF89FC07
	v_sub_f32_e32 v0, v0, v13                                  // 000000225734: 08001B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225738: BF870091
	v_mul_f32_e32 v13, 0x3fb8aa3b, v0                          // 00000022573C: 101A00FF 3FB8AA3B
	v_fma_f32 v14, 0x3fb8aa3b, v0, -v13                        // 000000225744: D613000E 843600FF 3FB8AA3B
	v_rndne_f32_e32 v15, v13                                   // 000000225750: 7E1E470D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000225754: BF870221
	v_sub_f32_e32 v13, v13, v15                                // 000000225758: 081A1F0D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000022575C: 7C3600FF C2CE8ED0
	v_fmac_f32_e32 v14, 0x32a5705f, v0                         // 000000225764: 561C00FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000022576C: BF870121
	v_add_f32_e32 v13, v13, v14                                // 000000225770: 061A1D0D
	v_cvt_i32_f32_e32 v14, v15                                 // 000000225774: 7E1C110F
	v_exp_f32_e32 v13, v13                                     // 000000225778: 7E1A4B0D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022577C: BF870095
	.long 0xd71c000d                                           // 000000225780: D71C000D
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                     // 000000225784: 02021D0D
	v_cndmask_b32_e32 v13, 0, v13, vcc_lo                      // 000000225788: 021A1A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 00000022578C: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225794: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v13, vcc_lo              // 000000225798: 02001AFF 7F800000
	v_mul_f32_e32 v0, 0x3b800000, v0                           // 0000002257A0: 100000FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002257A8: BF870001
	v_mul_f32_e32 v13, v2, v0                                  // 0000002257AC: 101A0102
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002257B0: 8C7E007E
	v_lshl_or_b32 v0, v11, 6, v29                              // 0000002257B4: D6560000 04750D0B
	v_or_b32_e32 v2, 2, v11                                    // 0000002257BC: 38041682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002257C0: BF870112
	.long 0xd73c000e                                           // 0000002257C4: D73C000E
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000002257C8: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v2                           // 0000002257CC: 7C96051D
	s_and_b32 s9, s1, vcc_lo                                   // 0000002257D0: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002257D4: BF870092
	.long 0xd700000e                                           // 0000002257D8: D700000E
	v_cndmask_b32_e32 v1, s2, v14, vcc_lo                      // 0000002257DC: 02021C02
	v_add_co_ci_u32_e64 v15, null, s6, v15, s0                 // 0000002257E0: D5207C0F 00021E06
	global_store_b32 v[14:15], v13, off                        // 0000002257E8: DC6A0000 007C0D0E
	s_and_saveexec_b32 s0, s9                                  // 0000002257F0: BE802009
	s_cbranch_execz 35                                         // 0000002257F4: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1884>
	ds_load_b32 v0, v10 offset:18440                           // 0000002257F8: D8D84808 0000000A
	ds_load_b32 v12, v32                                       // 000000225800: D8D80000 0C000020
	s_waitcnt lgkmcnt(0)                                       // 000000225808: BF89FC07
	v_sub_f32_e32 v0, v0, v12                                  // 00000022580C: 08001900
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000225810: BF870121
	v_mul_f32_e32 v12, 0x3fb8aa3b, v0                          // 000000225814: 101800FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 00000022581C: 7C3600FF C2CE8ED0
	v_fma_f32 v13, 0x3fb8aa3b, v0, -v12                        // 000000225824: D613000D 843200FF 3FB8AA3B
	v_rndne_f32_e32 v14, v12                                   // 000000225830: 7E1C470C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225834: BF870091
	v_dual_fmac_f32 v13, 0x32a5705f, v0 :: v_dual_sub_f32 v12, v12, v14// 000000225838: C80A00FF 0D0C1D0C 32A5705F
	v_add_f32_e32 v12, v12, v13                                // 000000225844: 06181B0C
	v_cvt_i32_f32_e32 v13, v14                                 // 000000225848: 7E1A110E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000022584C: BF870292
	v_exp_f32_e32 v12, v12                                     // 000000225850: 7E184B0C
	.long 0xd71c000c                                           // 000000225854: D71C000C
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                     // 000000225858: 02021B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000022585C: BF870121
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 000000225860: 02181880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 000000225864: 7C3C00FF 42B17218
	v_cndmask_b32_e32 v0, 0x7f800000, v12, vcc_lo              // 00000022586C: 020018FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225874: BF870091
	v_mul_f32_e32 v0, 0x3b800000, v0                           // 000000225878: 100000FF 3B800000
	v_mul_f32_e32 v12, v3, v0                                  // 000000225880: 10180103
	s_or_b32 exec_lo, exec_lo, s0                              // 000000225884: 8C7E007E
	v_lshl_or_b32 v0, v2, 6, v29                               // 000000225888: D6560000 04750D02
	v_or_b32_e32 v3, 4, v11                                    // 000000225890: 38061684
	v_mov_b32_e32 v2, 0                                        // 000000225894: 7E040280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000225898: BF870193
	.long 0xd73c000d                                           // 00000022589C: D73C000D
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000002258A0: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 0000002258A4: 7C96071D
	s_and_b32 s9, s1, vcc_lo                                   // 0000002258A8: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002258AC: BF870092
	.long 0xd700000f                                           // 0000002258B0: D700000F
	v_cndmask_b32_e32 v1, s2, v13, vcc_lo                      // 0000002258B4: 02021A02
	v_add_co_ci_u32_e64 v16, null, s6, v14, s0                 // 0000002258B8: D5207C10 00021C06
	v_mov_b32_e32 v13, 0                                       // 0000002258C0: 7E1A0280
	global_store_b32 v[15:16], v12, off                        // 0000002258C4: DC6A0000 007C0C0F
	s_and_saveexec_b32 s0, s9                                  // 0000002258CC: BE802009
	s_cbranch_execz 35                                         // 0000002258D0: BFA50023 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1960>
	ds_load_b32 v0, v10 offset:18448                           // 0000002258D4: D8D84810 0000000A
	ds_load_b32 v12, v32                                       // 0000002258DC: D8D80000 0C000020
	s_waitcnt lgkmcnt(0)                                       // 0000002258E4: BF89FC07
	v_sub_f32_e32 v0, v0, v12                                  // 0000002258E8: 08001900
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002258EC: BF870121
	v_mul_f32_e32 v12, 0x3fb8aa3b, v0                          // 0000002258F0: 101800FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 0000002258F8: 7C3600FF C2CE8ED0
	v_fma_f32 v13, 0x3fb8aa3b, v0, -v12                        // 000000225900: D613000D 843200FF 3FB8AA3B
	v_rndne_f32_e32 v14, v12                                   // 00000022590C: 7E1C470C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225910: BF870091
	v_dual_fmac_f32 v13, 0x32a5705f, v0 :: v_dual_sub_f32 v12, v12, v14// 000000225914: C80A00FF 0D0C1D0C 32A5705F
	v_add_f32_e32 v12, v12, v13                                // 000000225920: 06181B0C
	v_cvt_i32_f32_e32 v13, v14                                 // 000000225924: 7E1A110E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000225928: BF870292
	v_exp_f32_e32 v12, v12                                     // 00000022592C: 7E184B0C
	.long 0xd71c000c                                           // 000000225930: D71C000C
	v_cndmask_b32_e32 v1, v12, v13, vcc_lo                     // 000000225934: 02021B0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000225938: BF870121
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 00000022593C: 02181880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 000000225940: 7C3C00FF 42B17218
	v_cndmask_b32_e32 v0, 0x7f800000, v12, vcc_lo              // 000000225948: 020018FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225950: BF870091
	v_mul_f32_e32 v0, 0x3b800000, v0                           // 000000225954: 100000FF 3B800000
	v_mul_f32_e32 v13, v4, v0                                  // 00000022595C: 101A0104
	s_or_b32 exec_lo, exec_lo, s0                              // 000000225960: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 000000225964: D6560000 04750D03
	v_or_b32_e32 v3, 6, v11                                    // 00000022596C: 38061686
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000225970: BF870112
	.long 0xd73c000e                                           // 000000225974: D73C000E
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000225978: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 00000022597C: 7C96071D
	s_and_b32 s9, s1, vcc_lo                                   // 000000225980: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225984: BF870092
	.long 0xd700000e                                           // 000000225988: D700000E
	v_cndmask_b32_e32 v1, s2, v14, vcc_lo                      // 00000022598C: 02021C02
	v_add_co_ci_u32_e64 v15, null, s6, v15, s0                 // 000000225990: D5207C0F 00021E06
	global_store_b32 v[14:15], v13, off                        // 000000225998: DC6A0000 007C0D0E
	s_and_saveexec_b32 s0, s9                                  // 0000002259A0: BE802009
	s_cbranch_execz 36                                         // 0000002259A4: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1a38>
	ds_load_b32 v0, v10 offset:18456                           // 0000002259A8: D8D84818 0000000A
	ds_load_b32 v2, v32                                        // 0000002259B0: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 0000002259B8: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 0000002259BC: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002259C0: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 0000002259C4: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 0000002259CC: 7C3600FF C2CE8ED0
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v2                          // 0000002259D4: D6130004 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v12, v2                                    // 0000002259E0: 7E184702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002259E4: BF870112
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 0000002259E8: 560800FF 32A5705F
	v_sub_f32_e32 v2, v2, v12                                  // 0000002259F0: 08041902
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002259F4: BF870121
	v_add_f32_e32 v2, v2, v4                                   // 0000002259F8: 06040902
	v_cvt_i32_f32_e32 v4, v12                                  // 0000002259FC: 7E08110C
	v_exp_f32_e32 v2, v2                                       // 000000225A00: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225A04: BF870095
	.long 0xd71c0002                                           // 000000225A08: D71C0002
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000225A0C: 02020902
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 000000225A10: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 000000225A14: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225A1C: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 000000225A20: 020004FF 7F800000
	v_mul_f32_e32 v0, 0x3b800000, v0                           // 000000225A28: 100000FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225A30: BF870001
	v_mul_f32_e32 v2, v5, v0                                   // 000000225A34: 10040105
	s_or_b32 exec_lo, exec_lo, s0                              // 000000225A38: 8C7E007E
	v_lshl_or_b32 v0, v3, 6, v29                               // 000000225A3C: D6560000 04750D03
	v_or_b32_e32 v4, 8, v11                                    // 000000225A44: 38081688
	v_mov_b32_e32 v3, 0                                        // 000000225A48: 7E060280
	v_mov_b32_e32 v5, 0                                        // 000000225A4C: 7E0A0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000225A50: BF870214
	.long 0xd73c000c                                           // 000000225A54: D73C000C
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000225A58: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v4                           // 000000225A5C: 7C96091D
	s_and_b32 s9, s1, vcc_lo                                   // 000000225A60: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225A64: BF870092
	.long 0xd700000c                                           // 000000225A68: D700000C
	v_cndmask_b32_e32 v1, s2, v12, vcc_lo                      // 000000225A6C: 02021802
	v_add_co_ci_u32_e64 v13, null, s6, v13, s0                 // 000000225A70: D5207C0D 00021A06
	global_store_b32 v[12:13], v2, off                         // 000000225A78: DC6A0000 007C020C
	s_and_saveexec_b32 s0, s9                                  // 000000225A80: BE802009
	s_cbranch_execz 36                                         // 000000225A84: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1b18>
	ds_load_b32 v0, v10 offset:18464                           // 000000225A88: D8D84820 0000000A
	ds_load_b32 v2, v32                                        // 000000225A90: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 000000225A98: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 000000225A9C: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000225AA0: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 000000225AA4: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 000000225AAC: 7C3600FF C2CE8ED0
	v_fma_f32 v5, 0x3fb8aa3b, v0, -v2                          // 000000225AB4: D6130005 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v12, v2                                    // 000000225AC0: 7E184702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000225AC4: BF870112
	v_fmac_f32_e32 v5, 0x32a5705f, v0                          // 000000225AC8: 560A00FF 32A5705F
	v_sub_f32_e32 v2, v2, v12                                  // 000000225AD0: 08041902
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000225AD4: BF870121
	v_add_f32_e32 v2, v2, v5                                   // 000000225AD8: 06040B02
	v_cvt_i32_f32_e32 v5, v12                                  // 000000225ADC: 7E0A110C
	v_exp_f32_e32 v2, v2                                       // 000000225AE0: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225AE4: BF870095
	.long 0xd71c0002                                           // 000000225AE8: D71C0002
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 000000225AEC: 02020B02
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 000000225AF0: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 000000225AF4: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225AFC: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 000000225B00: 020004FF 7F800000
	v_mul_f32_e32 v0, 0x3b800000, v0                           // 000000225B08: 100000FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225B10: BF870001
	v_mul_f32_e32 v5, v6, v0                                   // 000000225B14: 100A0106
	s_or_b32 exec_lo, exec_lo, s0                              // 000000225B18: 8C7E007E
	v_lshl_or_b32 v0, v4, 6, v29                               // 000000225B1C: D6560000 04750D04
	v_or_b32_e32 v2, 10, v11                                   // 000000225B24: 3804168A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000225B28: BF870112
	.long 0xd73c000c                                           // 000000225B2C: D73C000C
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000225B30: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v2                           // 000000225B34: 7C96051D
	s_and_b32 s9, s1, vcc_lo                                   // 000000225B38: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225B3C: BF870092
	.long 0xd700000c                                           // 000000225B40: D700000C
	v_cndmask_b32_e32 v1, s2, v12, vcc_lo                      // 000000225B44: 02021802
	v_add_co_ci_u32_e64 v13, null, s6, v13, s0                 // 000000225B48: D5207C0D 00021A06
	global_store_b32 v[12:13], v5, off                         // 000000225B50: DC6A0000 007C050C
	s_and_saveexec_b32 s0, s9                                  // 000000225B58: BE802009
	s_cbranch_execz 36                                         // 000000225B5C: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1bf0>
	ds_load_b32 v0, v10 offset:18472                           // 000000225B60: D8D84828 0000000A
	ds_load_b32 v3, v32                                        // 000000225B68: D8D80000 03000020
	s_waitcnt lgkmcnt(0)                                       // 000000225B70: BF89FC07
	v_sub_f32_e32 v0, v0, v3                                   // 000000225B74: 08000700
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225B78: BF870091
	v_mul_f32_e32 v3, 0x3fb8aa3b, v0                           // 000000225B7C: 100600FF 3FB8AA3B
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v3                          // 000000225B84: D6130004 840E00FF 3FB8AA3B
	v_rndne_f32_e32 v5, v3                                     // 000000225B90: 7E0A4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000225B94: BF870221
	v_sub_f32_e32 v3, v3, v5                                   // 000000225B98: 08060B03
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 000000225B9C: 7C3600FF C2CE8ED0
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 000000225BA4: 560800FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000225BAC: BF870121
	v_add_f32_e32 v3, v3, v4                                   // 000000225BB0: 06060903
	v_cvt_i32_f32_e32 v4, v5                                   // 000000225BB4: 7E081105
	v_exp_f32_e32 v3, v3                                       // 000000225BB8: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225BBC: BF870095
	.long 0xd71c0003                                           // 000000225BC0: D71C0003
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 000000225BC4: 02020903
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 000000225BC8: 02060680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 000000225BCC: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225BD4: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v3, vcc_lo               // 000000225BD8: 020006FF 7F800000
	v_mul_f32_e32 v0, 0x3b800000, v0                           // 000000225BE0: 100000FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225BE8: BF870001
	v_mul_f32_e32 v3, v7, v0                                   // 000000225BEC: 10060107
	s_or_b32 exec_lo, exec_lo, s0                              // 000000225BF0: 8C7E007E
	v_lshl_or_b32 v0, v2, 6, v29                               // 000000225BF4: D6560000 04750D02
	v_or_b32_e32 v4, 12, v11                                   // 000000225BFC: 3808168C
	v_mov_b32_e32 v2, 0                                        // 000000225C00: 7E040280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000225C04: BF870193
	.long 0xd73c0005                                           // 000000225C08: D73C0005
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000225C0C: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v4                           // 000000225C10: 7C96091D
	s_and_b32 s9, s1, vcc_lo                                   // 000000225C14: 8B096A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225C18: BF870092
	.long 0xd700000c                                           // 000000225C1C: D700000C
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 000000225C20: 02020A02
	v_add_co_ci_u32_e64 v13, null, s6, v6, s0                  // 000000225C24: D5207C0D 00020C06
	v_mov_b32_e32 v5, 0                                        // 000000225C2C: 7E0A0280
	global_store_b32 v[12:13], v3, off                         // 000000225C30: DC6A0000 007C030C
	s_and_saveexec_b32 s0, s9                                  // 000000225C38: BE802009
	s_cbranch_execz 36                                         // 000000225C3C: BFA50024 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x1cd0>
	ds_load_b32 v0, v10 offset:18480                           // 000000225C40: D8D84830 0000000A
	ds_load_b32 v3, v32                                        // 000000225C48: D8D80000 03000020
	s_waitcnt lgkmcnt(0)                                       // 000000225C50: BF89FC07
	v_sub_f32_e32 v0, v0, v3                                   // 000000225C54: 08000700
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225C58: BF870091
	v_mul_f32_e32 v3, 0x3fb8aa3b, v0                           // 000000225C5C: 100600FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v0, -v3                          // 000000225C64: D6130005 840E00FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 000000225C70: 7E0C4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000225C74: BF870191
	v_sub_f32_e32 v3, v3, v6                                   // 000000225C78: 08060D03
	v_fmac_f32_e32 v5, 0x32a5705f, v0                          // 000000225C7C: 560A00FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 000000225C84: 7C3600FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000225C8C: BF870122
	v_add_f32_e32 v3, v3, v5                                   // 000000225C90: 06060B03
	v_cvt_i32_f32_e32 v5, v6                                   // 000000225C94: 7E0A1106
	v_exp_f32_e32 v3, v3                                       // 000000225C98: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225C9C: BF870095
	.long 0xd71c0003                                           // 000000225CA0: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000225CA4: 02020B03
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 000000225CA8: 02060680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 000000225CAC: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225CB4: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v3, vcc_lo               // 000000225CB8: 020006FF 7F800000
	v_mul_f32_e32 v0, 0x3b800000, v0                           // 000000225CC0: 100000FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225CC8: BF870001
	v_mul_f32_e32 v5, v8, v0                                   // 000000225CCC: 100A0108
	s_or_b32 exec_lo, exec_lo, s0                              // 000000225CD0: 8C7E007E
	v_lshl_or_b32 v0, v4, 6, v29                               // 000000225CD4: D6560000 04750D04
	v_or_b32_e32 v3, 14, v11                                   // 000000225CDC: 3806168E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000225CE0: BF870112
	.long 0xd73c0006                                           // 000000225CE4: D73C0006
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000225CE8: 02020082
	v_cmp_le_u32_e32 vcc_lo, v29, v3                           // 000000225CEC: 7C96071D
	s_and_b32 s1, s1, vcc_lo                                   // 000000225CF0: 8B016A01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225CF4: BF870092
	.long 0xd7000006                                           // 000000225CF8: D7000006
	v_cndmask_b32_e32 v1, s2, v6, vcc_lo                       // 000000225CFC: 02020C02
	v_add_co_ci_u32_e64 v7, null, s6, v7, s0                   // 000000225D00: D5207C07 00020E06
	global_store_b32 v[6:7], v5, off                           // 000000225D08: DC6A0000 007C0506
	s_and_saveexec_b32 s0, s1                                  // 000000225D10: BE802001
	s_cbranch_execz 63806                                      // 000000225D14: BFA5F93E <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x210>
	ds_load_b32 v0, v10 offset:18488                           // 000000225D18: D8D84838 0000000A
	ds_load_b32 v2, v32                                        // 000000225D20: D8D80000 02000020
	s_waitcnt lgkmcnt(0)                                       // 000000225D28: BF89FC07
	v_sub_f32_e32 v0, v0, v2                                   // 000000225D2C: 08000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000225D30: BF870121
	v_mul_f32_e32 v2, 0x3fb8aa3b, v0                           // 000000225D34: 100400FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v0                   // 000000225D3C: 7C3600FF C2CE8ED0
	v_fma_f32 v4, 0x3fb8aa3b, v0, -v2                          // 000000225D44: D6130004 840A00FF 3FB8AA3B
	v_rndne_f32_e32 v5, v2                                     // 000000225D50: 7E0A4702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000225D54: BF870112
	v_fmac_f32_e32 v4, 0x32a5705f, v0                          // 000000225D58: 560800FF 32A5705F
	v_sub_f32_e32 v2, v2, v5                                   // 000000225D60: 08040B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000225D64: BF870121
	v_add_f32_e32 v2, v2, v4                                   // 000000225D68: 06040902
	v_cvt_i32_f32_e32 v4, v5                                   // 000000225D6C: 7E081105
	v_exp_f32_e32 v2, v2                                       // 000000225D70: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225D74: BF870095
	.long 0xd71c0002                                           // 000000225D78: D71C0002
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000225D7C: 02020902
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 000000225D80: 02040480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v0                   // 000000225D84: 7C3C00FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000225D8C: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v2, vcc_lo               // 000000225D90: 020004FF 7F800000
	v_mul_f32_e32 v0, 0x3b800000, v0                           // 000000225D98: 100000FF 3B800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000225DA0: BF870001
	v_mul_f32_e32 v2, v9, v0                                   // 000000225DA4: 10040109
	s_branch 63769                                             // 000000225DA8: BFA0F919 <_ZN7halogen12_GLOBAL__N_110k_dnc_att9ILi4EEEvPKfS3_S3_Pfi+0x210>
	s_endpgm                                                   // 000000225DAC: BFB00000
		...

