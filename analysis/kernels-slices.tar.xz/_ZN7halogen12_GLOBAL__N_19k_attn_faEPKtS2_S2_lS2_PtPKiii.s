0000000000019c00 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii>:
; _ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii():
	s_clause 0x1                                               // 000000019C00: BF850001
	s_load_b256 s[20:27], s[0:1], 0x20                         // 000000019C04: F40C0500 F8000020
	s_load_b256 s[12:19], s[0:1], null                         // 000000019C0C: F40C0300 F8000000
	v_cmp_gt_u32_e32 vcc_lo, 16, v0                            // 000000019C14: 7C980090
	v_lshlrev_b32_e32 v137, 2, v0                              // 000000019C18: 31120082
	s_waitcnt lgkmcnt(0)                                       // 000000019C1C: BF89FC07
	s_load_b32 s4, s[24:25], null                              // 000000019C20: F400010C F8000000
	s_and_saveexec_b32 s5, vcc_lo                              // 000000019C28: BE85206A
	v_dual_mov_b32 v1, 0xf149f2ca :: v_dual_mov_b32 v2, 0      // 000000019C2C: CA1000FF 01020080 F149F2CA
	v_add_nc_u32_e32 v3, 0x2400, v137                          // 000000019C38: 4A0712FF 00002400
	ds_store_2addr_b32 v3, v1, v2 offset0:128 offset1:160      // 000000019C40: D838A080 00020103
	s_or_b32 exec_lo, exec_lo, s5                              // 000000019C48: 8C7E057E
	s_load_b64 s[24:25], s[0:1], 0x38                          // 000000019C4C: F4040600 F8000038
	s_lshl_b32 s28, s2, 4                                      // 000000019C54: 841C8402
	v_mov_b32_e32 v8, 0                                        // 000000019C58: 7E100280
	v_and_b32_e32 v252, 15, v0                                 // 000000019C5C: 37F8008F
	s_or_b32 s0, s28, 15                                       // 000000019C60: 8C008F1C
	v_lshrrev_b32_e32 v174, 4, v0                              // 000000019C64: 335C0084
	s_lshl_b32 s26, s3, 8                                      // 000000019C68: 841A8803
	v_mov_b32_e32 v7, v8                                       // 000000019C6C: 7E0E0308
	v_dual_mov_b32 v6, v8 :: v_dual_lshlrev_b32 v143, 1, v252  // 000000019C70: CA220108 068FF881
	v_mov_b32_e32 v5, v8                                       // 000000019C78: 7E0A0308
	v_mov_b32_e32 v4, v8                                       // 000000019C7C: 7E080308
	v_mov_b32_e32 v3, v8                                       // 000000019C80: 7E060308
	v_mov_b32_e32 v2, v8                                       // 000000019C84: 7E040308
	v_mov_b32_e32 v1, v8                                       // 000000019C88: 7E020308
	v_mov_b32_e32 v16, v8                                      // 000000019C8C: 7E200308
	v_mov_b32_e32 v15, v8                                      // 000000019C90: 7E1E0308
	v_mov_b32_e32 v14, v8                                      // 000000019C94: 7E1C0308
	v_mov_b32_e32 v13, v8                                      // 000000019C98: 7E1A0308
	v_mov_b32_e32 v12, v8                                      // 000000019C9C: 7E180308
	s_waitcnt lgkmcnt(0)                                       // 000000019CA0: BF89FC07
	s_add_i32 s1, s24, -1                                      // 000000019CA4: 8101C118
	v_mov_b32_e32 v11, v8                                      // 000000019CA8: 7E160308
	s_min_i32 s0, s0, s1                                       // 000000019CAC: 89000100
	v_mov_b32_e32 v10, v8                                      // 000000019CB0: 7E140308
	v_mov_b32_e32 v9, v8                                       // 000000019CB4: 7E120308
	v_mov_b32_e32 v24, v8                                      // 000000019CB8: 7E300308
	v_mov_b32_e32 v23, v8                                      // 000000019CBC: 7E2E0308
	v_mov_b32_e32 v22, v8                                      // 000000019CC0: 7E2C0308
	v_mov_b32_e32 v21, v8                                      // 000000019CC4: 7E2A0308
	v_mov_b32_e32 v20, v8                                      // 000000019CC8: 7E280308
	v_mov_b32_e32 v19, v8                                      // 000000019CCC: 7E260308
	v_mov_b32_e32 v18, v8                                      // 000000019CD0: 7E240308
	v_mov_b32_e32 v17, v8                                      // 000000019CD4: 7E220308
	v_mov_b32_e32 v32, v8                                      // 000000019CD8: 7E400308
	v_mov_b32_e32 v31, v8                                      // 000000019CDC: 7E3E0308
	v_mov_b32_e32 v30, v8                                      // 000000019CE0: 7E3C0308
	v_mov_b32_e32 v29, v8                                      // 000000019CE4: 7E3A0308
	v_mov_b32_e32 v28, v8                                      // 000000019CE8: 7E380308
	v_mov_b32_e32 v27, v8                                      // 000000019CEC: 7E360308
	v_mov_b32_e32 v26, v8                                      // 000000019CF0: 7E340308
	v_mov_b32_e32 v25, v8                                      // 000000019CF4: 7E320308
	v_mov_b32_e32 v40, v8                                      // 000000019CF8: 7E500308
	v_mov_b32_e32 v39, v8                                      // 000000019CFC: 7E4E0308
	v_mov_b32_e32 v38, v8                                      // 000000019D00: 7E4C0308
	v_mov_b32_e32 v37, v8                                      // 000000019D04: 7E4A0308
	v_mov_b32_e32 v36, v8                                      // 000000019D08: 7E480308
	v_mov_b32_e32 v35, v8                                      // 000000019D0C: 7E460308
	v_mov_b32_e32 v34, v8                                      // 000000019D10: 7E440308
	v_mov_b32_e32 v33, v8                                      // 000000019D14: 7E420308
	v_mov_b32_e32 v48, v8                                      // 000000019D18: 7E600308
	v_mov_b32_e32 v47, v8                                      // 000000019D1C: 7E5E0308
	v_mov_b32_e32 v46, v8                                      // 000000019D20: 7E5C0308
	v_mov_b32_e32 v45, v8                                      // 000000019D24: 7E5A0308
	v_mov_b32_e32 v44, v8                                      // 000000019D28: 7E580308
	v_mov_b32_e32 v43, v8                                      // 000000019D2C: 7E560308
	v_mov_b32_e32 v42, v8                                      // 000000019D30: 7E540308
	v_mov_b32_e32 v41, v8                                      // 000000019D34: 7E520308
	v_mov_b32_e32 v56, v8                                      // 000000019D38: 7E700308
	v_mov_b32_e32 v55, v8                                      // 000000019D3C: 7E6E0308
	v_mov_b32_e32 v54, v8                                      // 000000019D40: 7E6C0308
	v_mov_b32_e32 v53, v8                                      // 000000019D44: 7E6A0308
	v_mov_b32_e32 v52, v8                                      // 000000019D48: 7E680308
	v_mov_b32_e32 v51, v8                                      // 000000019D4C: 7E660308
	v_mov_b32_e32 v50, v8                                      // 000000019D50: 7E640308
	v_mov_b32_e32 v49, v8                                      // 000000019D54: 7E620308
	v_mov_b32_e32 v64, v8                                      // 000000019D58: 7E800308
	v_mov_b32_e32 v63, v8                                      // 000000019D5C: 7E7E0308
	v_mov_b32_e32 v62, v8                                      // 000000019D60: 7E7C0308
	v_mov_b32_e32 v61, v8                                      // 000000019D64: 7E7A0308
	v_mov_b32_e32 v60, v8                                      // 000000019D68: 7E780308
	v_mov_b32_e32 v59, v8                                      // 000000019D6C: 7E760308
	v_mov_b32_e32 v58, v8                                      // 000000019D70: 7E740308
	v_mov_b32_e32 v57, v8                                      // 000000019D74: 7E720308
	v_mov_b32_e32 v72, v8                                      // 000000019D78: 7E900308
	v_mov_b32_e32 v71, v8                                      // 000000019D7C: 7E8E0308
	v_mov_b32_e32 v70, v8                                      // 000000019D80: 7E8C0308
	v_mov_b32_e32 v69, v8                                      // 000000019D84: 7E8A0308
	v_mov_b32_e32 v68, v8                                      // 000000019D88: 7E880308
	v_mov_b32_e32 v67, v8                                      // 000000019D8C: 7E860308
	v_mov_b32_e32 v66, v8                                      // 000000019D90: 7E840308
	v_mov_b32_e32 v65, v8                                      // 000000019D94: 7E820308
	v_mov_b32_e32 v80, v8                                      // 000000019D98: 7EA00308
	v_mov_b32_e32 v79, v8                                      // 000000019D9C: 7E9E0308
	v_mov_b32_e32 v78, v8                                      // 000000019DA0: 7E9C0308
	v_mov_b32_e32 v77, v8                                      // 000000019DA4: 7E9A0308
	v_mov_b32_e32 v76, v8                                      // 000000019DA8: 7E980308
	v_mov_b32_e32 v75, v8                                      // 000000019DAC: 7E960308
	v_mov_b32_e32 v74, v8                                      // 000000019DB0: 7E940308
	v_mov_b32_e32 v73, v8                                      // 000000019DB4: 7E920308
	v_mov_b32_e32 v88, v8                                      // 000000019DB8: 7EB00308
	v_mov_b32_e32 v87, v8                                      // 000000019DBC: 7EAE0308
	v_mov_b32_e32 v86, v8                                      // 000000019DC0: 7EAC0308
	v_mov_b32_e32 v85, v8                                      // 000000019DC4: 7EAA0308
	v_mov_b32_e32 v84, v8                                      // 000000019DC8: 7EA80308
	v_mov_b32_e32 v83, v8                                      // 000000019DCC: 7EA60308
	v_mov_b32_e32 v82, v8                                      // 000000019DD0: 7EA40308
	v_mov_b32_e32 v81, v8                                      // 000000019DD4: 7EA20308
	v_mov_b32_e32 v96, v8                                      // 000000019DD8: 7EC00308
	v_mov_b32_e32 v95, v8                                      // 000000019DDC: 7EBE0308
	v_mov_b32_e32 v94, v8                                      // 000000019DE0: 7EBC0308
	v_mov_b32_e32 v93, v8                                      // 000000019DE4: 7EBA0308
	v_mov_b32_e32 v92, v8                                      // 000000019DE8: 7EB80308
	v_mov_b32_e32 v91, v8                                      // 000000019DEC: 7EB60308
	v_mov_b32_e32 v90, v8                                      // 000000019DF0: 7EB40308
	v_mov_b32_e32 v89, v8                                      // 000000019DF4: 7EB20308
	v_mov_b32_e32 v104, v8                                     // 000000019DF8: 7ED00308
	v_mov_b32_e32 v103, v8                                     // 000000019DFC: 7ECE0308
	v_mov_b32_e32 v102, v8                                     // 000000019E00: 7ECC0308
	v_mov_b32_e32 v101, v8                                     // 000000019E04: 7ECA0308
	v_mov_b32_e32 v100, v8                                     // 000000019E08: 7EC80308
	v_mov_b32_e32 v99, v8                                      // 000000019E0C: 7EC60308
	v_mov_b32_e32 v98, v8                                      // 000000019E10: 7EC40308
	v_mov_b32_e32 v97, v8                                      // 000000019E14: 7EC20308
	v_mov_b32_e32 v112, v8                                     // 000000019E18: 7EE00308
	v_mov_b32_e32 v111, v8                                     // 000000019E1C: 7EDE0308
	v_mov_b32_e32 v110, v8                                     // 000000019E20: 7EDC0308
	v_mov_b32_e32 v109, v8                                     // 000000019E24: 7EDA0308
	v_mov_b32_e32 v108, v8                                     // 000000019E28: 7ED80308
	v_mov_b32_e32 v107, v8                                     // 000000019E2C: 7ED60308
	v_mov_b32_e32 v106, v8                                     // 000000019E30: 7ED40308
	v_mov_b32_e32 v105, v8                                     // 000000019E34: 7ED20308
	v_mov_b32_e32 v120, v8                                     // 000000019E38: 7EF00308
	v_mov_b32_e32 v119, v8                                     // 000000019E3C: 7EEE0308
	v_mov_b32_e32 v118, v8                                     // 000000019E40: 7EEC0308
	v_mov_b32_e32 v117, v8                                     // 000000019E44: 7EEA0308
	v_mov_b32_e32 v116, v8                                     // 000000019E48: 7EE80308
	v_mov_b32_e32 v115, v8                                     // 000000019E4C: 7EE60308
	v_mov_b32_e32 v114, v8                                     // 000000019E50: 7EE40308
	v_mov_b32_e32 v113, v8                                     // 000000019E54: 7EE20308
	v_mov_b32_e32 v128, v8                                     // 000000019E58: 7F000308
	v_mov_b32_e32 v127, v8                                     // 000000019E5C: 7EFE0308
	v_mov_b32_e32 v126, v8                                     // 000000019E60: 7EFC0308
	v_mov_b32_e32 v125, v8                                     // 000000019E64: 7EFA0308
	v_mov_b32_e32 v124, v8                                     // 000000019E68: 7EF80308
	v_mov_b32_e32 v123, v8                                     // 000000019E6C: 7EF60308
	v_mov_b32_e32 v122, v8                                     // 000000019E70: 7EF40308
	v_mov_b32_e32 v121, v8                                     // 000000019E74: 7EF20308
	s_add_i32 s1, s4, s0                                       // 000000019E78: 81010004
	s_ashr_i32 s27, s26, 31                                    // 000000019E7C: 861B9F1A
	s_cmp_lt_i32 s1, -15                                       // 000000019E80: BF04CF01
	s_cbranch_scc1 2121                                        // 000000019E84: BFA20849 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x23ac>
	v_or_b32_e32 v1, s28, v252                                 // 000000019E88: 3803F81C
	s_lshl_b64 s[6:7], s[26:27], 1                             // 000000019E8C: 8486811A
	s_ashr_i32 s2, s1, 31                                      // 000000019E90: 86029F01
	s_add_i32 s25, s25, -1                                     // 000000019E94: 8119C119
	s_lshr_b32 s2, s2, 28                                      // 000000019E98: 85029C02
	v_mad_i64_i32 v[1:2], null, 0x3000, v1, s[12:13]           // 000000019E9C: D6FF7C01 003202FF 00003000
	s_add_i32 s2, s1, s2                                       // 000000019EA8: 81020201
	v_add3_u32 v254, s4, s28, v0                               // 000000019EAC: D65500FE 04003804
	s_ashr_i32 s2, s2, 4                                       // 000000019EB4: 86028402
	v_lshl_add_u32 v255, v0, 6, 0x2200                         // 000000019EB8: D64600FF 03FD0D00 00002200
	v_lshl_or_b32 v0, v0, 5, 0x2000                            // 000000019EC4: D6560000 03FD0B00 00002000
	v_or_b32_e32 v176, 0x2600, v137                            // 000000019ED0: 396112FF 00002600
	v_or_b32_e32 v175, 0x2680, v137                            // 000000019ED8: 395F12FF 00002680
	.long 0xd7000001                                           // 000000019EE0: D7000001
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000019EE4: 02000D01
	s_delay_alu instid0(VALU_DEP_1)                            // 000000019EE8: BF870001
	v_add_co_ci_u32_e64 v2, null, s7, v2, s0                   // 000000019EEC: D5207C02 00020407
	s_mul_hi_i32 s0, s3, 0x2aaaaaab                            // 000000019EF4: 9700FF03 2AAAAAAB
	v_lshl_or_b32 v153, v174, 2, 0x2640                        // 000000019EFC: D6560099 03FD05AE 00002640
	s_lshr_b32 s5, s0, 31                                      // 000000019F08: 85059F00
	s_clause 0x1                                               // 000000019F0C: BF850001
	global_load_b128 v[7:10], v[1:2], off offset:16            // 000000019F10: DC5E0010 077C0001
	global_load_b128 v[3:6], v[1:2], off                       // 000000019F18: DC5E0000 037C0001
	s_ashr_i32 s0, s0, 1                                       // 000000019F20: 86008100
	v_lshl_or_b32 v154, v252, 5, 0x2000                        // 000000019F24: D656009A 03FD0BFC 00002000
	s_add_i32 s0, s0, s5                                       // 000000019F30: 81000500
	v_lshl_or_b32 v155, v174, 12, v143                         // 000000019F34: D656009B 063D19AE
	s_ashr_i32 s1, s0, 31                                      // 000000019F3C: 86019F00
	s_mov_b32 s31, 0                                           // 000000019F40: BE9F0080
	s_lshl_b64 s[0:1], s[0:1], 9                               // 000000019F44: 84808900
	s_waitcnt vmcnt(0)                                         // 000000019F48: BF8903F7
	s_clause 0x1                                               // 000000019F4C: BF850001
	scratch_store_b128 off, v[3:6], off                        // 000000019F50: DC750000 007C0300
	scratch_store_b128 off, v[7:10], off offset:16             // 000000019F58: DC750010 007C0700
	s_clause 0x1                                               // 000000019F60: BF850001
	global_load_b128 v[7:10], v[1:2], off offset:48            // 000000019F64: DC5E0030 077C0001
	global_load_b128 v[3:6], v[1:2], off offset:32             // 000000019F6C: DC5E0020 037C0001
	s_add_u32 s5, s16, s0                                      // 000000019F74: 80050010
	s_addc_u32 s6, s17, s1                                     // 000000019F78: 82060111
	s_add_u32 s17, s14, s0                                     // 000000019F7C: 8011000E
	s_addc_u32 s29, s15, s1                                    // 000000019F80: 821D010F
	s_add_i32 s30, s2, 1                                       // 000000019F84: 811E8102
	s_waitcnt vmcnt(0)                                         // 000000019F88: BF8903F7
	s_clause 0x1                                               // 000000019F8C: BF850001
	scratch_store_b128 off, v[3:6], off offset:32              // 000000019F90: DC750020 007C0300
	scratch_store_b128 off, v[7:10], off offset:48             // 000000019F98: DC750030 007C0700
	s_clause 0x1                                               // 000000019FA0: BF850001
	global_load_b128 v[7:10], v[1:2], off offset:80            // 000000019FA4: DC5E0050 077C0001
	global_load_b128 v[3:6], v[1:2], off offset:64             // 000000019FAC: DC5E0040 037C0001
	s_waitcnt vmcnt(0)                                         // 000000019FB4: BF8903F7
	s_clause 0x1                                               // 000000019FB8: BF850001
	scratch_store_b128 off, v[3:6], off offset:64              // 000000019FBC: DC750040 007C0300
	scratch_store_b128 off, v[7:10], off offset:80             // 000000019FC4: DC750050 007C0700
	s_clause 0x1                                               // 000000019FCC: BF850001
	global_load_b128 v[7:10], v[1:2], off offset:112           // 000000019FD0: DC5E0070 077C0001
	global_load_b128 v[3:6], v[1:2], off offset:96             // 000000019FD8: DC5E0060 037C0001
	s_waitcnt vmcnt(0)                                         // 000000019FE0: BF8903F7
	s_clause 0x1                                               // 000000019FE4: BF850001
	scratch_store_b128 off, v[3:6], off offset:96              // 000000019FE8: DC750060 007C0300
	scratch_store_b128 off, v[7:10], off offset:112            // 000000019FF0: DC750070 007C0700
	s_clause 0x1                                               // 000000019FF8: BF850001
	global_load_b128 v[7:10], v[1:2], off offset:144           // 000000019FFC: DC5E0090 077C0001
	global_load_b128 v[3:6], v[1:2], off offset:128            // 00000001A004: DC5E0080 037C0001
	s_waitcnt vmcnt(0)                                         // 00000001A00C: BF8903F7
	s_clause 0x1                                               // 00000001A010: BF850001
	scratch_store_b128 off, v[3:6], off offset:128             // 00000001A014: DC750080 007C0300
	scratch_store_b128 off, v[7:10], off offset:144            // 00000001A01C: DC750090 007C0700
	s_clause 0x1                                               // 00000001A024: BF850001
	global_load_b128 v[7:10], v[1:2], off offset:176           // 00000001A028: DC5E00B0 077C0001
	global_load_b128 v[3:6], v[1:2], off offset:160            // 00000001A030: DC5E00A0 037C0001
	s_waitcnt vmcnt(0)                                         // 00000001A038: BF8903F7
	s_clause 0x1                                               // 00000001A03C: BF850001
	scratch_store_b128 off, v[3:6], off offset:160             // 00000001A040: DC7500A0 007C0300
	scratch_store_b128 off, v[7:10], off offset:176            // 00000001A048: DC7500B0 007C0700
	s_clause 0x13                                              // 00000001A050: BF850013
	global_load_b128 v[181:184], v[1:2], off offset:208        // 00000001A054: DC5E00D0 B57C0001
	global_load_b128 v[177:180], v[1:2], off offset:192        // 00000001A05C: DC5E00C0 B17C0001
	global_load_b128 v[189:192], v[1:2], off offset:240        // 00000001A064: DC5E00F0 BD7C0001
	global_load_b128 v[185:188], v[1:2], off offset:224        // 00000001A06C: DC5E00E0 B97C0001
	global_load_b128 v[197:200], v[1:2], off offset:272        // 00000001A074: DC5E0110 C57C0001
	global_load_b128 v[193:196], v[1:2], off offset:256        // 00000001A07C: DC5E0100 C17C0001
	global_load_b128 v[205:208], v[1:2], off offset:304        // 00000001A084: DC5E0130 CD7C0001
	global_load_b128 v[201:204], v[1:2], off offset:288        // 00000001A08C: DC5E0120 C97C0001
	global_load_b128 v[213:216], v[1:2], off offset:336        // 00000001A094: DC5E0150 D57C0001
	global_load_b128 v[209:212], v[1:2], off offset:320        // 00000001A09C: DC5E0140 D17C0001
	global_load_b128 v[221:224], v[1:2], off offset:368        // 00000001A0A4: DC5E0170 DD7C0001
	global_load_b128 v[217:220], v[1:2], off offset:352        // 00000001A0AC: DC5E0160 D97C0001
	global_load_b128 v[229:232], v[1:2], off offset:400        // 00000001A0B4: DC5E0190 E57C0001
	global_load_b128 v[225:228], v[1:2], off offset:384        // 00000001A0BC: DC5E0180 E17C0001
	global_load_b128 v[237:240], v[1:2], off offset:432        // 00000001A0C4: DC5E01B0 ED7C0001
	global_load_b128 v[233:236], v[1:2], off offset:416        // 00000001A0CC: DC5E01A0 E97C0001
	global_load_b128 v[245:248], v[1:2], off offset:464        // 00000001A0D4: DC5E01D0 F57C0001
	global_load_b128 v[241:244], v[1:2], off offset:448        // 00000001A0DC: DC5E01C0 F17C0001
	global_load_b128 v[133:136], v[1:2], off offset:496        // 00000001A0E4: DC5E01F0 857C0001
	global_load_b128 v[129:132], v[1:2], off offset:480        // 00000001A0EC: DC5E01E0 817C0001
	v_dual_mov_b32 v165, 0 :: v_dual_lshlrev_b32 v2, 2, v252   // 00000001A0F4: CA220080 A503F882
	v_lshlrev_b32_e32 v1, 6, v174                              // 00000001A0FC: 30035C86
	v_mov_b32_e32 v121, 0                                      // 00000001A100: 7EF20280
	v_mov_b32_e32 v113, 0                                      // 00000001A104: 7EE20280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000001A108: BF870004
	v_dual_mov_b32 v105, 0 :: v_dual_mov_b32 v118, v165        // 00000001A10C: CA100080 697601A5
	v_mov_b32_e32 v122, v165                                   // 00000001A114: 7EF403A5
	v_or3_b32 v253, v1, v2, 0x2200                             // 00000001A118: D65800FD 03FE0501 00002200
	v_dual_mov_b32 v124, v165 :: v_dual_add_nc_u32 v1, 0x2640, v137// 00000001A124: CA2001A5 7C0112FF 00002640
	v_mov_b32_e32 v126, v165                                   // 00000001A130: 7EFC03A5
	v_mov_b32_e32 v123, v165                                   // 00000001A134: 7EF603A5
	v_mov_b32_e32 v125, v165                                   // 00000001A138: 7EFA03A5
	s_clause 0x1                                               // 00000001A13C: BF850001
	scratch_store_b32 off, v1, off offset:192                  // 00000001A140: DC6900C0 007C0100
	scratch_store_b32 off, v143, off offset:196                // 00000001A148: DC6900C4 007C8F00
	v_lshlrev_b32_e32 v1, 8, v174                              // 00000001A150: 30035C88
	v_mov_b32_e32 v127, v165                                   // 00000001A154: 7EFE03A5
	v_mov_b32_e32 v114, v165                                   // 00000001A158: 7EE403A5
	v_mov_b32_e32 v128, v165                                   // 00000001A15C: 7F0003A5
	v_mov_b32_e32 v115, v165                                   // 00000001A160: 7EE603A5
	.long 0xd7000098                                           // 00000001A164: D7000098
	v_cndmask_b32_e32 v1, s5, v1, vcc_lo                       // 00000001A168: 02020205
	v_mul_u32_u24_e32 v1, 30, v252                             // 00000001A16C: 1603F89E
	v_mov_b32_e32 v116, v165                                   // 00000001A170: 7EE803A5
	v_mov_b32_e32 v117, v165                                   // 00000001A174: 7EEA03A5
	v_mov_b32_e32 v119, v165                                   // 00000001A178: 7EEE03A5
	v_dual_mov_b32 v120, v165 :: v_dual_mov_b32 v97, 0         // 00000001A17C: CA1001A5 78600080
	v_dual_mov_b32 v106, v165 :: v_dual_add_nc_u32 v251, v143, v1// 00000001A184: CA2001A5 6AFA038F
	v_mov_b32_e32 v89, 0                                       // 00000001A18C: 7EB20280
	v_mov_b32_e32 v107, v165                                   // 00000001A190: 7ED603A5
	v_dual_mov_b32 v108, v165 :: v_dual_mov_b32 v81, 0         // 00000001A194: CA1001A5 6C500080
	v_mov_b32_e32 v109, v165                                   // 00000001A19C: 7EDA03A5
	v_dual_mov_b32 v110, v165 :: v_dual_mov_b32 v73, 0         // 00000001A1A0: CA1001A5 6E480080
	v_mov_b32_e32 v111, v165                                   // 00000001A1A8: 7EDE03A5
	v_dual_mov_b32 v112, v165 :: v_dual_mov_b32 v65, 0         // 00000001A1AC: CA1001A5 70400080
	v_dual_mov_b32 v98, v165 :: v_dual_mov_b32 v57, 0          // 00000001A1B4: CA1001A5 62380080
	v_mov_b32_e32 v99, v165                                    // 00000001A1BC: 7EC603A5
	v_dual_mov_b32 v100, v165 :: v_dual_mov_b32 v49, 0         // 00000001A1C0: CA1001A5 64300080
	v_mov_b32_e32 v101, v165                                   // 00000001A1C8: 7ECA03A5
	v_dual_mov_b32 v102, v165 :: v_dual_mov_b32 v41, 0         // 00000001A1CC: CA1001A5 66280080
	v_mov_b32_e32 v103, v165                                   // 00000001A1D4: 7ECE03A5
	v_dual_mov_b32 v104, v165 :: v_dual_mov_b32 v33, 0         // 00000001A1D8: CA1001A5 68200080
	v_dual_mov_b32 v90, v165 :: v_dual_mov_b32 v25, 0          // 00000001A1E0: CA1001A5 5A180080
	v_mov_b32_e32 v91, v165                                    // 00000001A1E8: 7EB603A5
	v_dual_mov_b32 v92, v165 :: v_dual_mov_b32 v17, 0          // 00000001A1EC: CA1001A5 5C100080
	v_mov_b32_e32 v93, v165                                    // 00000001A1F4: 7EBA03A5
	v_dual_mov_b32 v94, v165 :: v_dual_mov_b32 v9, 0           // 00000001A1F8: CA1001A5 5E080080
	v_mov_b32_e32 v95, v165                                    // 00000001A200: 7EBE03A5
	v_dual_mov_b32 v96, v165 :: v_dual_mov_b32 v1, 0           // 00000001A204: CA1001A5 60000080
	v_mov_b32_e32 v82, v165                                    // 00000001A20C: 7EA403A5
	v_mov_b32_e32 v83, v165                                    // 00000001A210: 7EA603A5
	v_mov_b32_e32 v84, v165                                    // 00000001A214: 7EA803A5
	v_mov_b32_e32 v85, v165                                    // 00000001A218: 7EAA03A5
	v_mov_b32_e32 v86, v165                                    // 00000001A21C: 7EAC03A5
	v_mov_b32_e32 v87, v165                                    // 00000001A220: 7EAE03A5
	v_mov_b32_e32 v88, v165                                    // 00000001A224: 7EB003A5
	v_mov_b32_e32 v74, v165                                    // 00000001A228: 7E9403A5
	v_mov_b32_e32 v75, v165                                    // 00000001A22C: 7E9603A5
	v_mov_b32_e32 v76, v165                                    // 00000001A230: 7E9803A5
	v_mov_b32_e32 v77, v165                                    // 00000001A234: 7E9A03A5
	v_mov_b32_e32 v78, v165                                    // 00000001A238: 7E9C03A5
	v_mov_b32_e32 v79, v165                                    // 00000001A23C: 7E9E03A5
	v_mov_b32_e32 v80, v165                                    // 00000001A240: 7EA003A5
	v_mov_b32_e32 v66, v165                                    // 00000001A244: 7E8403A5
	v_mov_b32_e32 v67, v165                                    // 00000001A248: 7E8603A5
	v_mov_b32_e32 v68, v165                                    // 00000001A24C: 7E8803A5
	v_mov_b32_e32 v69, v165                                    // 00000001A250: 7E8A03A5
	v_mov_b32_e32 v70, v165                                    // 00000001A254: 7E8C03A5
	v_mov_b32_e32 v71, v165                                    // 00000001A258: 7E8E03A5
	v_mov_b32_e32 v72, v165                                    // 00000001A25C: 7E9003A5
	v_mov_b32_e32 v58, v165                                    // 00000001A260: 7E7403A5
	v_mov_b32_e32 v59, v165                                    // 00000001A264: 7E7603A5
	v_mov_b32_e32 v60, v165                                    // 00000001A268: 7E7803A5
	v_mov_b32_e32 v61, v165                                    // 00000001A26C: 7E7A03A5
	v_mov_b32_e32 v62, v165                                    // 00000001A270: 7E7C03A5
	v_mov_b32_e32 v63, v165                                    // 00000001A274: 7E7E03A5
	v_mov_b32_e32 v64, v165                                    // 00000001A278: 7E8003A5
	v_mov_b32_e32 v50, v165                                    // 00000001A27C: 7E6403A5
	v_mov_b32_e32 v51, v165                                    // 00000001A280: 7E6603A5
	v_mov_b32_e32 v52, v165                                    // 00000001A284: 7E6803A5
	v_mov_b32_e32 v53, v165                                    // 00000001A288: 7E6A03A5
	v_mov_b32_e32 v54, v165                                    // 00000001A28C: 7E6C03A5
	v_mov_b32_e32 v55, v165                                    // 00000001A290: 7E6E03A5
	v_mov_b32_e32 v56, v165                                    // 00000001A294: 7E7003A5
	v_mov_b32_e32 v42, v165                                    // 00000001A298: 7E5403A5
	v_mov_b32_e32 v43, v165                                    // 00000001A29C: 7E5603A5
	v_mov_b32_e32 v44, v165                                    // 00000001A2A0: 7E5803A5
	v_mov_b32_e32 v45, v165                                    // 00000001A2A4: 7E5A03A5
	v_mov_b32_e32 v46, v165                                    // 00000001A2A8: 7E5C03A5
	v_mov_b32_e32 v47, v165                                    // 00000001A2AC: 7E5E03A5
	v_mov_b32_e32 v48, v165                                    // 00000001A2B0: 7E6003A5
	v_mov_b32_e32 v34, v165                                    // 00000001A2B4: 7E4403A5
	v_mov_b32_e32 v35, v165                                    // 00000001A2B8: 7E4603A5
	v_mov_b32_e32 v36, v165                                    // 00000001A2BC: 7E4803A5
	v_mov_b32_e32 v37, v165                                    // 00000001A2C0: 7E4A03A5
	v_mov_b32_e32 v38, v165                                    // 00000001A2C4: 7E4C03A5
	v_mov_b32_e32 v39, v165                                    // 00000001A2C8: 7E4E03A5
	v_mov_b32_e32 v40, v165                                    // 00000001A2CC: 7E5003A5
	v_mov_b32_e32 v26, v165                                    // 00000001A2D0: 7E3403A5
	v_mov_b32_e32 v27, v165                                    // 00000001A2D4: 7E3603A5
	v_mov_b32_e32 v28, v165                                    // 00000001A2D8: 7E3803A5
	v_mov_b32_e32 v29, v165                                    // 00000001A2DC: 7E3A03A5
	v_mov_b32_e32 v30, v165                                    // 00000001A2E0: 7E3C03A5
	v_mov_b32_e32 v31, v165                                    // 00000001A2E4: 7E3E03A5
	v_mov_b32_e32 v32, v165                                    // 00000001A2E8: 7E4003A5
	v_mov_b32_e32 v18, v165                                    // 00000001A2EC: 7E2403A5
	v_mov_b32_e32 v19, v165                                    // 00000001A2F0: 7E2603A5
	v_mov_b32_e32 v20, v165                                    // 00000001A2F4: 7E2803A5
	v_mov_b32_e32 v21, v165                                    // 00000001A2F8: 7E2A03A5
	v_mov_b32_e32 v22, v165                                    // 00000001A2FC: 7E2C03A5
	v_mov_b32_e32 v23, v165                                    // 00000001A300: 7E2E03A5
	v_mov_b32_e32 v24, v165                                    // 00000001A304: 7E3003A5
	v_mov_b32_e32 v10, v165                                    // 00000001A308: 7E1403A5
	v_mov_b32_e32 v11, v165                                    // 00000001A30C: 7E1603A5
	v_mov_b32_e32 v12, v165                                    // 00000001A310: 7E1803A5
	v_mov_b32_e32 v13, v165                                    // 00000001A314: 7E1A03A5
	v_mov_b32_e32 v14, v165                                    // 00000001A318: 7E1C03A5
	v_mov_b32_e32 v15, v165                                    // 00000001A31C: 7E1E03A5
	v_mov_b32_e32 v16, v165                                    // 00000001A320: 7E2003A5
	v_mov_b32_e32 v2, v165                                     // 00000001A324: 7E0403A5
	v_mov_b32_e32 v3, v165                                     // 00000001A328: 7E0603A5
	v_mov_b32_e32 v4, v165                                     // 00000001A32C: 7E0803A5
	v_mov_b32_e32 v5, v165                                     // 00000001A330: 7E0A03A5
	v_mov_b32_e32 v6, v165                                     // 00000001A334: 7E0C03A5
	v_mov_b32_e32 v7, v165                                     // 00000001A338: 7E0E03A5
	v_mov_b32_e32 v8, v165                                     // 00000001A33C: 7E1003A5
	v_add_co_ci_u32_e64 v156, null, s6, 0, s0                  // 00000001A340: D5207C9C 00010006
	s_branch 297                                               // 00000001A348: BFA00129 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xbf0>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001A34C: 8C7E017E
	v_add_f32_e32 v137, v141, v140                             // 00000001A350: 0713198D
	ds_load_b32 v139, v175                                     // 00000001A354: D8D80000 8B0000AF
	v_add_f32_e32 v137, v137, v143                             // 00000001A35C: 07131F89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001A360: BF870091
	v_add_f32_e32 v137, v137, v142                             // 00000001A364: 07131D89
	v_add_f32_e32 v137, v137, v145                             // 00000001A368: 07132389
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001A36C: BF870091
	v_add_f32_e32 v137, v137, v144                             // 00000001A370: 07132189
	v_add_f32_e32 v137, v137, v147                             // 00000001A374: 07132789
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001A378: BF870091
	v_add_f32_e32 v137, v137, v146                             // 00000001A37C: 07132589
	v_add_f32_e32 v137, v137, v149                             // 00000001A380: 07132B89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001A384: BF870091
	v_add_f32_e32 v137, v137, v148                             // 00000001A388: 07132989
	v_add_f32_e32 v137, v137, v151                             // 00000001A38C: 07132F89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001A390: BF870091
	v_add_f32_e32 v137, v137, v150                             // 00000001A394: 07132D89
	v_add_f32_e32 v137, v137, v158                             // 00000001A398: 07133D89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001A39C: BF870091
	v_add_f32_e32 v137, v137, v157                             // 00000001A3A0: 07133B89
	v_add_f32_e32 v137, v137, v160                             // 00000001A3A4: 07134189
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001A3A8: BF8700A1
	v_add_f32_e32 v137, v137, v159                             // 00000001A3AC: 07133F89
	s_waitcnt lgkmcnt(0)                                       // 00000001A3B0: BF89FC07
	v_fmac_f32_e32 v137, v249, v139                            // 00000001A3B4: 571317F9
	ds_store_b32 v176, v138                                    // 00000001A3B8: D8340000 00008AB0
	ds_store_b32 v175, v137                                    // 00000001A3C0: D8340000 000089AF
	scratch_load_b32 v137, off, off offset:192                 // 00000001A3C8: DC5100C0 897C0000
	s_waitcnt vmcnt(0)                                         // 00000001A3D0: BF8903F7
	ds_store_b32 v137, v249                                    // 00000001A3D4: D8340000 0000F989
	s_or_b32 exec_lo, exec_lo, s33                             // 00000001A3DC: 8C7E217E
	ds_load_b128 v[138:141], v154                              // 00000001A3E0: DBFC0000 8A00009A
	ds_load_b128 v[142:145], v154 offset:16                    // 00000001A3E8: DBFC0010 8E00009A
	ds_load_b128 v[157:160], v251                              // 00000001A3F0: DBFC0000 9D0000FB
	ds_load_b128 v[161:164], v251 offset:16                    // 00000001A3F8: DBFC0010 A10000FB
	ds_load_2addr_b32 v[146:147], v153 offset1:2               // 00000001A400: D8DC0200 92000099
	ds_load_2addr_b32 v[148:149], v153 offset0:4 offset1:6     // 00000001A408: D8DC0604 94000099
	ds_load_2addr_b32 v[150:151], v153 offset0:8 offset1:10    // 00000001A410: D8DC0A08 96000099
	ds_load_2addr_b32 v[249:250], v153 offset0:12 offset1:14   // 00000001A418: D8DC0E0C F9000099
	s_add_i32 s30, s30, -1                                     // 00000001A420: 811EC11E
	s_add_i32 s31, s31, 16                                     // 00000001A424: 811F901F
	s_cmp_eq_u32 s30, 0                                        // 00000001A428: BF06801E
	s_waitcnt lgkmcnt(3)                                       // 00000001A42C: BF89FC37
	v_dual_mul_f32 v121, v146, v121 :: v_dual_mul_f32 v122, v147, v122// 00000001A430: C8C6F392 797AF593
	s_waitcnt lgkmcnt(2)                                       // 00000001A438: BF89FC27
	v_dual_mul_f32 v123, v148, v123 :: v_dual_mul_f32 v124, v149, v124// 00000001A43C: C8C6F794 7B7CF995
	s_waitcnt lgkmcnt(1)                                       // 00000001A444: BF89FC17
	v_dual_mul_f32 v125, v150, v125 :: v_dual_mul_f32 v126, v151, v126// 00000001A448: C8C6FB96 7D7EFD97
	s_waitcnt lgkmcnt(0)                                       // 00000001A450: BF89FC07
	v_dual_mul_f32 v127, v249, v127 :: v_dual_mul_f32 v128, v250, v128// 00000001A454: C8C6FFF9 7F8101FA
	v_dual_mul_f32 v113, v146, v113 :: v_dual_mul_f32 v114, v147, v114// 00000001A45C: C8C6E392 7172E593
	v_dual_mul_f32 v115, v148, v115 :: v_dual_mul_f32 v116, v149, v116// 00000001A464: C8C6E794 7374E995
	s_delay_alu instid0(VALU_DEP_3)                            // 00000001A46C: BF870003
	v_wmma_f32_16x16x16_bf16 v[121:128], v[138:145], v[157:164], v[121:128]// 00000001A470: CC414079 1DE73B8A
	ds_load_b128 v[161:164], v251 offset:528                   // 00000001A478: DBFC0210 A10000FB
	ds_load_b128 v[157:160], v251 offset:512                   // 00000001A480: DBFC0200 9D0000FB
	v_dual_mul_f32 v117, v150, v117 :: v_dual_mul_f32 v118, v151, v118// 00000001A488: C8C6EB96 7576ED97
	v_dual_mul_f32 v119, v249, v119 :: v_dual_mul_f32 v120, v250, v120// 00000001A490: C8C6EFF9 7778F1FA
	v_dual_mul_f32 v105, v146, v105 :: v_dual_mul_f32 v106, v147, v106// 00000001A498: C8C6D392 696AD593
	v_dual_mul_f32 v107, v148, v107 :: v_dual_mul_f32 v108, v149, v108// 00000001A4A0: C8C6D794 6B6CD995
	v_dual_mul_f32 v109, v150, v109 :: v_dual_mul_f32 v110, v151, v110// 00000001A4A8: C8C6DB96 6D6EDD97
	v_dual_mul_f32 v111, v249, v111 :: v_dual_mul_f32 v112, v250, v112// 00000001A4B0: C8C6DFF9 6F70E1FA
	v_dual_mul_f32 v97, v146, v97 :: v_dual_mul_f32 v98, v147, v98// 00000001A4B8: C8C6C392 6162C593
	v_dual_mul_f32 v99, v148, v99 :: v_dual_mul_f32 v100, v149, v100// 00000001A4C0: C8C6C794 6364C995
	v_dual_mul_f32 v101, v150, v101 :: v_dual_mul_f32 v102, v151, v102// 00000001A4C8: C8C6CB96 6566CD97
	v_dual_mul_f32 v103, v249, v103 :: v_dual_mul_f32 v104, v250, v104// 00000001A4D0: C8C6CFF9 6768D1FA
	s_waitcnt lgkmcnt(0)                                       // 00000001A4D8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[138:145], v[157:164], v[113:120]// 00000001A4DC: CC414071 1DC73B8A
	ds_load_b128 v[161:164], v251 offset:1040                  // 00000001A4E4: DBFC0410 A10000FB
	ds_load_b128 v[157:160], v251 offset:1024                  // 00000001A4EC: DBFC0400 9D0000FB
	v_dual_mul_f32 v89, v146, v89 :: v_dual_mul_f32 v90, v147, v90// 00000001A4F4: C8C6B392 595AB593
	v_dual_mul_f32 v91, v148, v91 :: v_dual_mul_f32 v92, v149, v92// 00000001A4FC: C8C6B794 5B5CB995
	v_dual_mul_f32 v93, v150, v93 :: v_dual_mul_f32 v94, v151, v94// 00000001A504: C8C6BB96 5D5EBD97
	v_dual_mul_f32 v95, v249, v95 :: v_dual_mul_f32 v96, v250, v96// 00000001A50C: C8C6BFF9 5F60C1FA
	v_dual_mul_f32 v81, v146, v81 :: v_dual_mul_f32 v82, v147, v82// 00000001A514: C8C6A392 5152A593
	v_dual_mul_f32 v83, v148, v83 :: v_dual_mul_f32 v84, v149, v84// 00000001A51C: C8C6A794 5354A995
	v_dual_mul_f32 v85, v150, v85 :: v_dual_mul_f32 v86, v151, v86// 00000001A524: C8C6AB96 5556AD97
	v_dual_mul_f32 v87, v249, v87 :: v_dual_mul_f32 v88, v250, v88// 00000001A52C: C8C6AFF9 5758B1FA
	v_dual_mul_f32 v73, v146, v73 :: v_dual_mul_f32 v74, v147, v74// 00000001A534: C8C69392 494A9593
	v_dual_mul_f32 v75, v148, v75 :: v_dual_mul_f32 v76, v149, v76// 00000001A53C: C8C69794 4B4C9995
	s_waitcnt lgkmcnt(0)                                       // 00000001A544: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[138:145], v[157:164], v[105:112]// 00000001A548: CC414069 1DA73B8A
	ds_load_b128 v[161:164], v251 offset:1552                  // 00000001A550: DBFC0610 A10000FB
	ds_load_b128 v[157:160], v251 offset:1536                  // 00000001A558: DBFC0600 9D0000FB
	v_dual_mul_f32 v77, v150, v77 :: v_dual_mul_f32 v78, v151, v78// 00000001A560: C8C69B96 4D4E9D97
	v_dual_mul_f32 v79, v249, v79 :: v_dual_mul_f32 v80, v250, v80// 00000001A568: C8C69FF9 4F50A1FA
	v_dual_mul_f32 v65, v146, v65 :: v_dual_mul_f32 v66, v147, v66// 00000001A570: C8C68392 41428593
	v_dual_mul_f32 v67, v148, v67 :: v_dual_mul_f32 v68, v149, v68// 00000001A578: C8C68794 43448995
	v_dual_mul_f32 v69, v150, v69 :: v_dual_mul_f32 v70, v151, v70// 00000001A580: C8C68B96 45468D97
	v_dual_mul_f32 v71, v249, v71 :: v_dual_mul_f32 v72, v250, v72// 00000001A588: C8C68FF9 474891FA
	v_dual_mul_f32 v57, v146, v57 :: v_dual_mul_f32 v58, v147, v58// 00000001A590: C8C67392 393A7593
	v_dual_mul_f32 v59, v148, v59 :: v_dual_mul_f32 v60, v149, v60// 00000001A598: C8C67794 3B3C7995
	v_dual_mul_f32 v61, v150, v61 :: v_dual_mul_f32 v62, v151, v62// 00000001A5A0: C8C67B96 3D3E7D97
	v_dual_mul_f32 v63, v249, v63 :: v_dual_mul_f32 v64, v250, v64// 00000001A5A8: C8C67FF9 3F4081FA
	s_waitcnt lgkmcnt(0)                                       // 00000001A5B0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[138:145], v[157:164], v[97:104]// 00000001A5B4: CC414061 1D873B8A
	ds_load_b128 v[161:164], v251 offset:2064                  // 00000001A5BC: DBFC0810 A10000FB
	ds_load_b128 v[157:160], v251 offset:2048                  // 00000001A5C4: DBFC0800 9D0000FB
	v_dual_mul_f32 v49, v146, v49 :: v_dual_mul_f32 v50, v147, v50// 00000001A5CC: C8C66392 31326593
	v_dual_mul_f32 v51, v148, v51 :: v_dual_mul_f32 v52, v149, v52// 00000001A5D4: C8C66794 33346995
	v_dual_mul_f32 v53, v150, v53 :: v_dual_mul_f32 v54, v151, v54// 00000001A5DC: C8C66B96 35366D97
	v_dual_mul_f32 v55, v249, v55 :: v_dual_mul_f32 v56, v250, v56// 00000001A5E4: C8C66FF9 373871FA
	v_dual_mul_f32 v41, v146, v41 :: v_dual_mul_f32 v42, v147, v42// 00000001A5EC: C8C65392 292A5593
	v_dual_mul_f32 v43, v148, v43 :: v_dual_mul_f32 v44, v149, v44// 00000001A5F4: C8C65794 2B2C5995
	v_dual_mul_f32 v45, v150, v45 :: v_dual_mul_f32 v46, v151, v46// 00000001A5FC: C8C65B96 2D2E5D97
	v_dual_mul_f32 v47, v249, v47 :: v_dual_mul_f32 v48, v250, v48// 00000001A604: C8C65FF9 2F3061FA
	v_dual_mul_f32 v33, v146, v33 :: v_dual_mul_f32 v34, v147, v34// 00000001A60C: C8C64392 21224593
	v_dual_mul_f32 v35, v148, v35 :: v_dual_mul_f32 v36, v149, v36// 00000001A614: C8C64794 23244995
	s_waitcnt lgkmcnt(0)                                       // 00000001A61C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[138:145], v[157:164], v[89:96]// 00000001A620: CC414059 1D673B8A
	ds_load_b128 v[161:164], v251 offset:2576                  // 00000001A628: DBFC0A10 A10000FB
	ds_load_b128 v[157:160], v251 offset:2560                  // 00000001A630: DBFC0A00 9D0000FB
	v_dual_mul_f32 v37, v150, v37 :: v_dual_mul_f32 v38, v151, v38// 00000001A638: C8C64B96 25264D97
	v_dual_mul_f32 v39, v249, v39 :: v_dual_mul_f32 v40, v250, v40// 00000001A640: C8C64FF9 272851FA
	v_dual_mul_f32 v25, v146, v25 :: v_dual_mul_f32 v26, v147, v26// 00000001A648: C8C63392 191A3593
	v_dual_mul_f32 v27, v148, v27 :: v_dual_mul_f32 v28, v149, v28// 00000001A650: C8C63794 1B1C3995
	v_dual_mul_f32 v29, v150, v29 :: v_dual_mul_f32 v30, v151, v30// 00000001A658: C8C63B96 1D1E3D97
	v_dual_mul_f32 v31, v249, v31 :: v_dual_mul_f32 v32, v250, v32// 00000001A660: C8C63FF9 1F2041FA
	v_dual_mul_f32 v17, v146, v17 :: v_dual_mul_f32 v18, v147, v18// 00000001A668: C8C62392 11122593
	v_dual_mul_f32 v19, v148, v19 :: v_dual_mul_f32 v20, v149, v20// 00000001A670: C8C62794 13142995
	v_dual_mul_f32 v21, v150, v21 :: v_dual_mul_f32 v22, v151, v22// 00000001A678: C8C62B96 15162D97
	v_dual_mul_f32 v23, v249, v23 :: v_dual_mul_f32 v24, v250, v24// 00000001A680: C8C62FF9 171831FA
	s_waitcnt lgkmcnt(0)                                       // 00000001A688: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[138:145], v[157:164], v[81:88]// 00000001A68C: CC414051 1D473B8A
	ds_load_b128 v[161:164], v251 offset:3088                  // 00000001A694: DBFC0C10 A10000FB
	ds_load_b128 v[157:160], v251 offset:3072                  // 00000001A69C: DBFC0C00 9D0000FB
	v_dual_mul_f32 v9, v146, v9 :: v_dual_mul_f32 v10, v147, v10// 00000001A6A4: C8C61392 090A1593
	v_dual_mul_f32 v11, v148, v11 :: v_dual_mul_f32 v12, v149, v12// 00000001A6AC: C8C61794 0B0C1995
	v_dual_mul_f32 v13, v150, v13 :: v_dual_mul_f32 v14, v151, v14// 00000001A6B4: C8C61B96 0D0E1D97
	v_dual_mul_f32 v15, v249, v15 :: v_dual_mul_f32 v16, v250, v16// 00000001A6BC: C8C61FF9 0F1021FA
	v_dual_mul_f32 v1, v146, v1 :: v_dual_mul_f32 v2, v147, v2 // 00000001A6C4: C8C60392 01020593
	v_dual_mul_f32 v3, v148, v3 :: v_dual_mul_f32 v4, v149, v4 // 00000001A6CC: C8C60794 03040995
	v_dual_mul_f32 v5, v150, v5 :: v_dual_mul_f32 v6, v151, v6 // 00000001A6D4: C8C60B96 05060D97
	v_dual_mul_f32 v7, v249, v7 :: v_dual_mul_f32 v8, v250, v8 // 00000001A6DC: C8C60FF9 070811FA
	s_waitcnt lgkmcnt(0)                                       // 00000001A6E4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[138:145], v[157:164], v[73:80]// 00000001A6E8: CC414049 1D273B8A
	ds_load_b128 v[161:164], v251 offset:3600                  // 00000001A6F0: DBFC0E10 A10000FB
	ds_load_b128 v[157:160], v251 offset:3584                  // 00000001A6F8: DBFC0E00 9D0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000001A700: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[138:145], v[157:164], v[65:72]// 00000001A704: CC414041 1D073B8A
	ds_load_b128 v[161:164], v251 offset:4112                  // 00000001A70C: DBFC1010 A10000FB
	ds_load_b128 v[157:160], v251 offset:4096                  // 00000001A714: DBFC1000 9D0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000001A71C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[138:145], v[157:164], v[57:64]// 00000001A720: CC414039 1CE73B8A
	ds_load_b128 v[161:164], v251 offset:4624                  // 00000001A728: DBFC1210 A10000FB
	ds_load_b128 v[157:160], v251 offset:4608                  // 00000001A730: DBFC1200 9D0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000001A738: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[138:145], v[157:164], v[49:56]// 00000001A73C: CC414031 1CC73B8A
	ds_load_b128 v[161:164], v251 offset:5136                  // 00000001A744: DBFC1410 A10000FB
	ds_load_b128 v[157:160], v251 offset:5120                  // 00000001A74C: DBFC1400 9D0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000001A754: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[138:145], v[157:164], v[41:48]// 00000001A758: CC414029 1CA73B8A
	ds_load_b128 v[161:164], v251 offset:5648                  // 00000001A760: DBFC1610 A10000FB
	ds_load_b128 v[157:160], v251 offset:5632                  // 00000001A768: DBFC1600 9D0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000001A770: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[138:145], v[157:164], v[33:40]// 00000001A774: CC414021 1C873B8A
	ds_load_b128 v[161:164], v251 offset:6160                  // 00000001A77C: DBFC1810 A10000FB
	ds_load_b128 v[157:160], v251 offset:6144                  // 00000001A784: DBFC1800 9D0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000001A78C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[138:145], v[157:164], v[25:32]// 00000001A790: CC414019 1C673B8A
	ds_load_b128 v[161:164], v251 offset:6672                  // 00000001A798: DBFC1A10 A10000FB
	ds_load_b128 v[157:160], v251 offset:6656                  // 00000001A7A0: DBFC1A00 9D0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000001A7A8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[138:145], v[157:164], v[17:24]// 00000001A7AC: CC414011 1C473B8A
	ds_load_b128 v[161:164], v251 offset:7184                  // 00000001A7B4: DBFC1C10 A10000FB
	ds_load_b128 v[157:160], v251 offset:7168                  // 00000001A7BC: DBFC1C00 9D0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000001A7C4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[138:145], v[157:164], v[9:16]// 00000001A7C8: CC414009 1C273B8A
	ds_load_b128 v[161:164], v251 offset:7696                  // 00000001A7D0: DBFC1E10 A10000FB
	ds_load_b128 v[157:160], v251 offset:7680                  // 00000001A7D8: DBFC1E00 9D0000FB
	s_waitcnt lgkmcnt(0)                                       // 00000001A7E0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[138:145], v[157:164], v[1:8]// 00000001A7E4: CC414001 1C073B8A
	s_cbranch_scc1 1517                                        // 00000001A7EC: BFA205ED <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x23a4>
	v_dual_mov_b32 v166, v165 :: v_dual_add_nc_u32 v137, s31, v252// 00000001A7F0: CA2001A5 A689F81F
	v_mov_b32_e32 v167, v165                                   // 00000001A7F8: 7F4E03A5
	v_mov_b32_e32 v168, v165                                   // 00000001A7FC: 7F5003A5
	v_mov_b32_e32 v169, v165                                   // 00000001A800: 7F5203A5
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000001A804: BF870244
	v_min_i32_e32 v137, s25, v137                              // 00000001A808: 23131219
	v_mov_b32_e32 v170, v165                                   // 00000001A80C: 7F5403A5
	v_mov_b32_e32 v171, v165                                   // 00000001A810: 7F5603A5
	v_mov_b32_e32 v172, v165                                   // 00000001A814: 7F5803A5
	v_ashrrev_i32_e32 v138, 31, v137                           // 00000001A818: 3515129F
	.long 0xd72c008c                                           // 00000001A81C: D72C008C
	v_cndmask_b32_e32 v1, s19, v137, vcc_lo                    // 00000001A820: 02031213
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001A824: BF8700A2
	.long 0xd72c008b                                           // 00000001A828: D72C008B
	v_cndmask_b32_e32 v1, s18, v138, vcc_lo                    // 00000001A82C: 02031412
	v_mad_u64_u32 v[137:138], null, s18, v137, 0               // 00000001A830: D6FE7C89 02031212
	v_add3_u32 v138, v138, v139, v140                          // 00000001A838: D655008A 0633178A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000001A840: BF870241
	.long 0xd73c0091                                           // 00000001A844: D73C0091
	v_cndmask_b32_e32 v1, 1, v137, vcc_lo                      // 00000001A848: 02031281
	v_dual_mov_b32 v137, v165 :: v_dual_mov_b32 v138, v166     // 00000001A84C: CA1001A5 898A01A6
	v_dual_mov_b32 v139, v167 :: v_dual_mov_b32 v140, v168     // 00000001A854: CA1001A7 8B8C01A8
	v_dual_mov_b32 v141, v169 :: v_dual_mov_b32 v142, v170     // 00000001A85C: CA1001A9 8D8E01AA
	.long 0xd7000093                                           // 00000001A864: D7000093
	v_cndmask_b32_e32 v1, s17, v145, vcc_lo                    // 00000001A868: 02032211
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001A86C: BF870001
	v_add_co_ci_u32_e64 v148, null, s29, v146, s0              // 00000001A870: D5207C94 0003241D
	v_dual_mov_b32 v143, v171 :: v_dual_mov_b32 v144, v172     // 00000001A878: CA1001AB 8F9001AC
	s_clause 0x1                                               // 00000001A880: BF850001
	global_load_b128 v[161:164], v[147:148], off offset:16     // 00000001A884: DC5E0010 A17C0093
	global_load_b128 v[157:160], v[147:148], off               // 00000001A88C: DC5E0000 9D7C0093
	s_clause 0x1                                               // 00000001A894: BF850001
	scratch_load_b128 v[166:169], off, off                     // 00000001A898: DC5D0000 A67C0000
	scratch_load_b128 v[170:173], off, off offset:16           // 00000001A8A0: DC5D0010 AA7C0000
	s_waitcnt vmcnt(0)                                         // 00000001A8A8: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[166:173], v[157:164], v[137:144]// 00000001A8AC: CC414089 1E273BA6
	s_clause 0x1                                               // 00000001A8B4: BF850001
	global_load_b128 v[161:164], v[147:148], off offset:48     // 00000001A8B8: DC5E0030 A17C0093
	global_load_b128 v[157:160], v[147:148], off offset:32     // 00000001A8C0: DC5E0020 9D7C0093
	s_clause 0x1                                               // 00000001A8C8: BF850001
	scratch_load_b128 v[166:169], off, off offset:32           // 00000001A8CC: DC5D0020 A67C0000
	scratch_load_b128 v[170:173], off, off offset:48           // 00000001A8D4: DC5D0030 AA7C0000
	s_waitcnt vmcnt(0)                                         // 00000001A8DC: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[166:173], v[157:164], v[137:144]// 00000001A8E0: CC414089 1E273BA6
	s_clause 0x1                                               // 00000001A8E8: BF850001
	global_load_b128 v[161:164], v[147:148], off offset:80     // 00000001A8EC: DC5E0050 A17C0093
	global_load_b128 v[157:160], v[147:148], off offset:64     // 00000001A8F4: DC5E0040 9D7C0093
	s_clause 0x1                                               // 00000001A8FC: BF850001
	scratch_load_b128 v[166:169], off, off offset:64           // 00000001A900: DC5D0040 A67C0000
	scratch_load_b128 v[170:173], off, off offset:80           // 00000001A908: DC5D0050 AA7C0000
	s_waitcnt vmcnt(0)                                         // 00000001A910: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[166:173], v[157:164], v[137:144]// 00000001A914: CC414089 1E273BA6
	s_clause 0x1                                               // 00000001A91C: BF850001
	global_load_b128 v[161:164], v[147:148], off offset:112    // 00000001A920: DC5E0070 A17C0093
	global_load_b128 v[157:160], v[147:148], off offset:96     // 00000001A928: DC5E0060 9D7C0093
	s_clause 0x1                                               // 00000001A930: BF850001
	scratch_load_b128 v[166:169], off, off offset:96           // 00000001A934: DC5D0060 A67C0000
	scratch_load_b128 v[170:173], off, off offset:112          // 00000001A93C: DC5D0070 AA7C0000
	s_waitcnt vmcnt(0)                                         // 00000001A944: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[166:173], v[157:164], v[137:144]// 00000001A948: CC414089 1E273BA6
	s_clause 0x1                                               // 00000001A950: BF850001
	global_load_b128 v[161:164], v[147:148], off offset:144    // 00000001A954: DC5E0090 A17C0093
	global_load_b128 v[157:160], v[147:148], off offset:128    // 00000001A95C: DC5E0080 9D7C0093
	s_clause 0x1                                               // 00000001A964: BF850001
	scratch_load_b128 v[166:169], off, off offset:128          // 00000001A968: DC5D0080 A67C0000
	scratch_load_b128 v[170:173], off, off offset:144          // 00000001A970: DC5D0090 AA7C0000
	s_waitcnt vmcnt(0)                                         // 00000001A978: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[166:173], v[157:164], v[137:144]// 00000001A97C: CC414089 1E273BA6
	s_clause 0x1                                               // 00000001A984: BF850001
	global_load_b128 v[161:164], v[147:148], off offset:176    // 00000001A988: DC5E00B0 A17C0093
	global_load_b128 v[157:160], v[147:148], off offset:160    // 00000001A990: DC5E00A0 9D7C0093
	s_clause 0x1                                               // 00000001A998: BF850001
	scratch_load_b128 v[166:169], off, off offset:160          // 00000001A99C: DC5D00A0 A67C0000
	scratch_load_b128 v[170:173], off, off offset:176          // 00000001A9A4: DC5D00B0 AA7C0000
	s_waitcnt vmcnt(0)                                         // 00000001A9AC: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[166:173], v[157:164], v[137:144]// 00000001A9B0: CC414089 1E273BA6
	s_clause 0x1                                               // 00000001A9B8: BF850001
	global_load_b128 v[161:164], v[147:148], off offset:208    // 00000001A9BC: DC5E00D0 A17C0093
	global_load_b128 v[157:160], v[147:148], off offset:192    // 00000001A9C4: DC5E00C0 9D7C0093
	s_waitcnt vmcnt(0)                                         // 00000001A9CC: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[177:184], v[157:164], v[137:144]// 00000001A9D0: CC414089 1E273BB1
	s_clause 0x1                                               // 00000001A9D8: BF850001
	global_load_b128 v[161:164], v[147:148], off offset:240    // 00000001A9DC: DC5E00F0 A17C0093
	global_load_b128 v[157:160], v[147:148], off offset:224    // 00000001A9E4: DC5E00E0 9D7C0093
	s_waitcnt vmcnt(0)                                         // 00000001A9EC: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[185:192], v[157:164], v[137:144]// 00000001A9F0: CC414089 1E273BB9
	s_clause 0x1                                               // 00000001A9F8: BF850001
	global_load_b128 v[161:164], v[147:148], off offset:272    // 00000001A9FC: DC5E0110 A17C0093
	global_load_b128 v[157:160], v[147:148], off offset:256    // 00000001AA04: DC5E0100 9D7C0093
	s_waitcnt vmcnt(0)                                         // 00000001AA0C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[193:200], v[157:164], v[137:144]// 00000001AA10: CC414089 1E273BC1
	s_clause 0x1                                               // 00000001AA18: BF850001
	global_load_b128 v[161:164], v[147:148], off offset:304    // 00000001AA1C: DC5E0130 A17C0093
	global_load_b128 v[157:160], v[147:148], off offset:288    // 00000001AA24: DC5E0120 9D7C0093
	s_waitcnt vmcnt(0)                                         // 00000001AA2C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[201:208], v[157:164], v[137:144]// 00000001AA30: CC414089 1E273BC9
	s_clause 0x1                                               // 00000001AA38: BF850001
	global_load_b128 v[161:164], v[147:148], off offset:336    // 00000001AA3C: DC5E0150 A17C0093
	global_load_b128 v[157:160], v[147:148], off offset:320    // 00000001AA44: DC5E0140 9D7C0093
	s_waitcnt vmcnt(0)                                         // 00000001AA4C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[209:216], v[157:164], v[137:144]// 00000001AA50: CC414089 1E273BD1
	s_clause 0x1                                               // 00000001AA58: BF850001
	global_load_b128 v[161:164], v[147:148], off offset:368    // 00000001AA5C: DC5E0170 A17C0093
	global_load_b128 v[157:160], v[147:148], off offset:352    // 00000001AA64: DC5E0160 9D7C0093
	s_waitcnt vmcnt(0)                                         // 00000001AA6C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[217:224], v[157:164], v[137:144]// 00000001AA70: CC414089 1E273BD9
	s_clause 0x1                                               // 00000001AA78: BF850001
	global_load_b128 v[161:164], v[147:148], off offset:400    // 00000001AA7C: DC5E0190 A17C0093
	global_load_b128 v[157:160], v[147:148], off offset:384    // 00000001AA84: DC5E0180 9D7C0093
	s_waitcnt vmcnt(0)                                         // 00000001AA8C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[225:232], v[157:164], v[137:144]// 00000001AA90: CC414089 1E273BE1
	s_clause 0x1                                               // 00000001AA98: BF850001
	global_load_b128 v[161:164], v[147:148], off offset:432    // 00000001AA9C: DC5E01B0 A17C0093
	global_load_b128 v[157:160], v[147:148], off offset:416    // 00000001AAA4: DC5E01A0 9D7C0093
	s_waitcnt vmcnt(0)                                         // 00000001AAAC: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[233:240], v[157:164], v[137:144]// 00000001AAB0: CC414089 1E273BE9
	s_clause 0x1                                               // 00000001AAB8: BF850001
	global_load_b128 v[161:164], v[147:148], off offset:464    // 00000001AABC: DC5E01D0 A17C0093
	global_load_b128 v[157:160], v[147:148], off offset:448    // 00000001AAC4: DC5E01C0 9D7C0093
	s_waitcnt vmcnt(0)                                         // 00000001AACC: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[241:248], v[157:164], v[137:144]// 00000001AAD0: CC414089 1E273BF1
	s_clause 0x1                                               // 00000001AAD8: BF850001
	global_load_b128 v[161:164], v[147:148], off offset:496    // 00000001AADC: DC5E01F0 A17C0093
	global_load_b128 v[157:160], v[147:148], off offset:480    // 00000001AAE4: DC5E01E0 9D7C0093
	s_waitcnt vmcnt(0)                                         // 00000001AAEC: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[129:136], v[157:164], v[137:144]// 00000001AAF0: CC414089 1E273B81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000001AAF8: BF8701A1
	v_mul_f32_e32 v151, 0x3d800000, v141                       // 00000001AAFC: 112F1AFF 3D800000
	.long 0xd700008d                                           // 00000001AB04: D700008D
	v_cndmask_b32_e32 v1, v152, v145, vcc_lo                   // 00000001AB08: 02032398
	v_mul_f32_e32 v157, 0x3d800000, v142                       // 00000001AB0C: 113B1CFF 3D800000
	v_add_co_ci_u32_e64 v142, null, v156, v146, s0             // 00000001AB14: D5207C8E 0003259C
	v_dual_mul_f32 v147, 0x3d800000, v137 :: v_dual_mul_f32 v148, 0x3d800000, v138// 00000001AB1C: C8C712FF 939514FF 3D800000
	v_dual_mul_f32 v149, 0x3d800000, v139 :: v_dual_mul_f32 v150, 0x3d800000, v140// 00000001AB28: C8C716FF 959718FF 3D800000
	global_load_b128 v[137:140], v[141:142], off               // 00000001AB34: DC5E0000 897C008D
	v_dual_mul_f32 v143, 0x3d800000, v143 :: v_dual_mul_f32 v144, 0x3d800000, v144// 00000001AB3C: C8C71EFF 8F9120FF 3D800000
	s_waitcnt vmcnt(0)                                         // 00000001AB48: BF8903F7
	ds_store_b16 v155, v137                                    // 00000001AB4C: D87C0000 0000899B
	ds_store_b16_d16_hi v155, v137 offset:32                   // 00000001AB54: DA840020 0000899B
	ds_store_b16 v155, v138 offset:64                          // 00000001AB5C: D87C0040 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:96                   // 00000001AB64: DA840060 00008A9B
	ds_store_b16 v155, v139 offset:128                         // 00000001AB6C: D87C0080 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:160                  // 00000001AB74: DA8400A0 00008B9B
	ds_store_b16 v155, v140 offset:192                         // 00000001AB7C: D87C00C0 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:224                  // 00000001AB84: DA8400E0 00008C9B
	global_load_b128 v[137:140], v[141:142], off offset:16     // 00000001AB8C: DC5E0010 897C008D
	s_waitcnt vmcnt(0)                                         // 00000001AB94: BF8903F7
	ds_store_b16 v155, v137 offset:256                         // 00000001AB98: D87C0100 0000899B
	ds_store_b16_d16_hi v155, v137 offset:288                  // 00000001ABA0: DA840120 0000899B
	ds_store_b16 v155, v138 offset:320                         // 00000001ABA8: D87C0140 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:352                  // 00000001ABB0: DA840160 00008A9B
	ds_store_b16 v155, v139 offset:384                         // 00000001ABB8: D87C0180 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:416                  // 00000001ABC0: DA8401A0 00008B9B
	ds_store_b16 v155, v140 offset:448                         // 00000001ABC8: D87C01C0 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:480                  // 00000001ABD0: DA8401E0 00008C9B
	global_load_b128 v[137:140], v[141:142], off offset:32     // 00000001ABD8: DC5E0020 897C008D
	s_waitcnt vmcnt(0)                                         // 00000001ABE0: BF8903F7
	ds_store_b16 v155, v137 offset:512                         // 00000001ABE4: D87C0200 0000899B
	ds_store_b16_d16_hi v155, v137 offset:544                  // 00000001ABEC: DA840220 0000899B
	ds_store_b16 v155, v138 offset:576                         // 00000001ABF4: D87C0240 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:608                  // 00000001ABFC: DA840260 00008A9B
	ds_store_b16 v155, v139 offset:640                         // 00000001AC04: D87C0280 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:672                  // 00000001AC0C: DA8402A0 00008B9B
	ds_store_b16 v155, v140 offset:704                         // 00000001AC14: D87C02C0 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:736                  // 00000001AC1C: DA8402E0 00008C9B
	global_load_b128 v[137:140], v[141:142], off offset:48     // 00000001AC24: DC5E0030 897C008D
	s_waitcnt vmcnt(0)                                         // 00000001AC2C: BF8903F7
	ds_store_b16 v155, v137 offset:768                         // 00000001AC30: D87C0300 0000899B
	ds_store_b16_d16_hi v155, v137 offset:800                  // 00000001AC38: DA840320 0000899B
	ds_store_b16 v155, v138 offset:832                         // 00000001AC40: D87C0340 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:864                  // 00000001AC48: DA840360 00008A9B
	ds_store_b16 v155, v139 offset:896                         // 00000001AC50: D87C0380 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:928                  // 00000001AC58: DA8403A0 00008B9B
	ds_store_b16 v155, v140 offset:960                         // 00000001AC60: D87C03C0 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:992                  // 00000001AC68: DA8403E0 00008C9B
	global_load_b128 v[137:140], v[141:142], off offset:64     // 00000001AC70: DC5E0040 897C008D
	s_waitcnt vmcnt(0)                                         // 00000001AC78: BF8903F7
	ds_store_b16 v155, v137 offset:1024                        // 00000001AC7C: D87C0400 0000899B
	ds_store_b16_d16_hi v155, v137 offset:1056                 // 00000001AC84: DA840420 0000899B
	ds_store_b16 v155, v138 offset:1088                        // 00000001AC8C: D87C0440 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:1120                 // 00000001AC94: DA840460 00008A9B
	ds_store_b16 v155, v139 offset:1152                        // 00000001AC9C: D87C0480 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:1184                 // 00000001ACA4: DA8404A0 00008B9B
	ds_store_b16 v155, v140 offset:1216                        // 00000001ACAC: D87C04C0 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:1248                 // 00000001ACB4: DA8404E0 00008C9B
	global_load_b128 v[137:140], v[141:142], off offset:80     // 00000001ACBC: DC5E0050 897C008D
	s_waitcnt vmcnt(0)                                         // 00000001ACC4: BF8903F7
	ds_store_b16 v155, v137 offset:1280                        // 00000001ACC8: D87C0500 0000899B
	ds_store_b16_d16_hi v155, v137 offset:1312                 // 00000001ACD0: DA840520 0000899B
	ds_store_b16 v155, v138 offset:1344                        // 00000001ACD8: D87C0540 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:1376                 // 00000001ACE0: DA840560 00008A9B
	ds_store_b16 v155, v139 offset:1408                        // 00000001ACE8: D87C0580 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:1440                 // 00000001ACF0: DA8405A0 00008B9B
	ds_store_b16 v155, v140 offset:1472                        // 00000001ACF8: D87C05C0 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:1504                 // 00000001AD00: DA8405E0 00008C9B
	global_load_b128 v[137:140], v[141:142], off offset:96     // 00000001AD08: DC5E0060 897C008D
	s_waitcnt vmcnt(0)                                         // 00000001AD10: BF8903F7
	ds_store_b16 v155, v137 offset:1536                        // 00000001AD14: D87C0600 0000899B
	ds_store_b16_d16_hi v155, v137 offset:1568                 // 00000001AD1C: DA840620 0000899B
	ds_store_b16 v155, v138 offset:1600                        // 00000001AD24: D87C0640 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:1632                 // 00000001AD2C: DA840660 00008A9B
	ds_store_b16 v155, v139 offset:1664                        // 00000001AD34: D87C0680 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:1696                 // 00000001AD3C: DA8406A0 00008B9B
	ds_store_b16 v155, v140 offset:1728                        // 00000001AD44: D87C06C0 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:1760                 // 00000001AD4C: DA8406E0 00008C9B
	global_load_b128 v[137:140], v[141:142], off offset:112    // 00000001AD54: DC5E0070 897C008D
	s_waitcnt vmcnt(0)                                         // 00000001AD5C: BF8903F7
	ds_store_b16 v155, v137 offset:1792                        // 00000001AD60: D87C0700 0000899B
	ds_store_b16_d16_hi v155, v137 offset:1824                 // 00000001AD68: DA840720 0000899B
	ds_store_b16 v155, v138 offset:1856                        // 00000001AD70: D87C0740 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:1888                 // 00000001AD78: DA840760 00008A9B
	ds_store_b16 v155, v139 offset:1920                        // 00000001AD80: D87C0780 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:1952                 // 00000001AD88: DA8407A0 00008B9B
	ds_store_b16 v155, v140 offset:1984                        // 00000001AD90: D87C07C0 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:2016                 // 00000001AD98: DA8407E0 00008C9B
	global_load_b128 v[137:140], v[141:142], off offset:128    // 00000001ADA0: DC5E0080 897C008D
	s_waitcnt vmcnt(0)                                         // 00000001ADA8: BF8903F7
	ds_store_b16 v155, v137 offset:2048                        // 00000001ADAC: D87C0800 0000899B
	ds_store_b16_d16_hi v155, v137 offset:2080                 // 00000001ADB4: DA840820 0000899B
	ds_store_b16 v155, v138 offset:2112                        // 00000001ADBC: D87C0840 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:2144                 // 00000001ADC4: DA840860 00008A9B
	ds_store_b16 v155, v139 offset:2176                        // 00000001ADCC: D87C0880 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:2208                 // 00000001ADD4: DA8408A0 00008B9B
	ds_store_b16 v155, v140 offset:2240                        // 00000001ADDC: D87C08C0 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:2272                 // 00000001ADE4: DA8408E0 00008C9B
	global_load_b128 v[137:140], v[141:142], off offset:144    // 00000001ADEC: DC5E0090 897C008D
	s_waitcnt vmcnt(0)                                         // 00000001ADF4: BF8903F7
	ds_store_b16 v155, v137 offset:2304                        // 00000001ADF8: D87C0900 0000899B
	ds_store_b16_d16_hi v155, v137 offset:2336                 // 00000001AE00: DA840920 0000899B
	ds_store_b16 v155, v138 offset:2368                        // 00000001AE08: D87C0940 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:2400                 // 00000001AE10: DA840960 00008A9B
	ds_store_b16 v155, v139 offset:2432                        // 00000001AE18: D87C0980 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:2464                 // 00000001AE20: DA8409A0 00008B9B
	ds_store_b16 v155, v140 offset:2496                        // 00000001AE28: D87C09C0 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:2528                 // 00000001AE30: DA8409E0 00008C9B
	global_load_b128 v[137:140], v[141:142], off offset:160    // 00000001AE38: DC5E00A0 897C008D
	s_waitcnt vmcnt(0)                                         // 00000001AE40: BF8903F7
	ds_store_b16 v155, v137 offset:2560                        // 00000001AE44: D87C0A00 0000899B
	ds_store_b16_d16_hi v155, v137 offset:2592                 // 00000001AE4C: DA840A20 0000899B
	ds_store_b16 v155, v138 offset:2624                        // 00000001AE54: D87C0A40 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:2656                 // 00000001AE5C: DA840A60 00008A9B
	ds_store_b16 v155, v139 offset:2688                        // 00000001AE64: D87C0A80 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:2720                 // 00000001AE6C: DA840AA0 00008B9B
	ds_store_b16 v155, v140 offset:2752                        // 00000001AE74: D87C0AC0 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:2784                 // 00000001AE7C: DA840AE0 00008C9B
	global_load_b128 v[137:140], v[141:142], off offset:176    // 00000001AE84: DC5E00B0 897C008D
	s_waitcnt vmcnt(0)                                         // 00000001AE8C: BF8903F7
	ds_store_b16 v155, v137 offset:2816                        // 00000001AE90: D87C0B00 0000899B
	ds_store_b16_d16_hi v155, v137 offset:2848                 // 00000001AE98: DA840B20 0000899B
	ds_store_b16 v155, v138 offset:2880                        // 00000001AEA0: D87C0B40 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:2912                 // 00000001AEA8: DA840B60 00008A9B
	ds_store_b16 v155, v139 offset:2944                        // 00000001AEB0: D87C0B80 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:2976                 // 00000001AEB8: DA840BA0 00008B9B
	ds_store_b16 v155, v140 offset:3008                        // 00000001AEC0: D87C0BC0 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:3040                 // 00000001AEC8: DA840BE0 00008C9B
	global_load_b128 v[137:140], v[141:142], off offset:192    // 00000001AED0: DC5E00C0 897C008D
	s_waitcnt vmcnt(0)                                         // 00000001AED8: BF8903F7
	ds_store_b16 v155, v137 offset:3072                        // 00000001AEDC: D87C0C00 0000899B
	ds_store_b16_d16_hi v155, v137 offset:3104                 // 00000001AEE4: DA840C20 0000899B
	ds_store_b16 v155, v138 offset:3136                        // 00000001AEEC: D87C0C40 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:3168                 // 00000001AEF4: DA840C60 00008A9B
	ds_store_b16 v155, v139 offset:3200                        // 00000001AEFC: D87C0C80 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:3232                 // 00000001AF04: DA840CA0 00008B9B
	ds_store_b16 v155, v140 offset:3264                        // 00000001AF0C: D87C0CC0 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:3296                 // 00000001AF14: DA840CE0 00008C9B
	global_load_b128 v[137:140], v[141:142], off offset:208    // 00000001AF1C: DC5E00D0 897C008D
	s_waitcnt vmcnt(0)                                         // 00000001AF24: BF8903F7
	ds_store_b16 v155, v137 offset:3328                        // 00000001AF28: D87C0D00 0000899B
	ds_store_b16_d16_hi v155, v137 offset:3360                 // 00000001AF30: DA840D20 0000899B
	ds_store_b16 v155, v138 offset:3392                        // 00000001AF38: D87C0D40 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:3424                 // 00000001AF40: DA840D60 00008A9B
	ds_store_b16 v155, v139 offset:3456                        // 00000001AF48: D87C0D80 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:3488                 // 00000001AF50: DA840DA0 00008B9B
	ds_store_b16 v155, v140 offset:3520                        // 00000001AF58: D87C0DC0 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:3552                 // 00000001AF60: DA840DE0 00008C9B
	global_load_b128 v[137:140], v[141:142], off offset:224    // 00000001AF68: DC5E00E0 897C008D
	s_waitcnt vmcnt(0)                                         // 00000001AF70: BF8903F7
	ds_store_b16 v155, v137 offset:3584                        // 00000001AF74: D87C0E00 0000899B
	ds_store_b16_d16_hi v155, v137 offset:3616                 // 00000001AF7C: DA840E20 0000899B
	ds_store_b16 v155, v138 offset:3648                        // 00000001AF84: D87C0E40 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:3680                 // 00000001AF8C: DA840E60 00008A9B
	ds_store_b16 v155, v139 offset:3712                        // 00000001AF94: D87C0E80 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:3744                 // 00000001AF9C: DA840EA0 00008B9B
	ds_store_b16 v155, v140 offset:3776                        // 00000001AFA4: D87C0EC0 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:3808                 // 00000001AFAC: DA840EE0 00008C9B
	global_load_b128 v[137:140], v[141:142], off offset:240    // 00000001AFB4: DC5E00F0 897C008D
	s_waitcnt vmcnt(0)                                         // 00000001AFBC: BF8903F7
	ds_store_b16 v155, v137 offset:3840                        // 00000001AFC0: D87C0F00 0000899B
	ds_store_b16_d16_hi v155, v137 offset:3872                 // 00000001AFC8: DA840F20 0000899B
	ds_store_b16 v155, v138 offset:3904                        // 00000001AFD0: D87C0F40 00008A9B
	ds_store_b16_d16_hi v155, v138 offset:3936                 // 00000001AFD8: DA840F60 00008A9B
	ds_store_b16 v155, v139 offset:3968                        // 00000001AFE0: D87C0F80 00008B9B
	ds_store_b16_d16_hi v155, v139 offset:4000                 // 00000001AFE8: DA840FA0 00008B9B
	ds_store_b16 v155, v140 offset:4032                        // 00000001AFF0: D87C0FC0 00008C9B
	ds_store_b16_d16_hi v155, v140 offset:4064                 // 00000001AFF8: DA840FE0 00008C9B
	ds_store_2addr_b32 v253, v147, v148 offset1:32             // 00000001B000: D8382000 009493FD
	ds_store_2addr_b32 v253, v149, v150 offset0:64 offset1:96  // 00000001B008: D8386040 009695FD
	ds_store_2addr_b32 v253, v151, v157 offset0:128 offset1:160// 00000001B010: D838A080 009D97FD
	ds_store_2addr_b32 v253, v143, v144 offset0:192 offset1:224// 00000001B018: D838E0C0 00908FFD
	s_and_saveexec_b32 s33, vcc_lo                             // 00000001B020: BEA1206A
	s_cbranch_execz 64749                                      // 00000001B024: BFA5FCED <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x7dc>
	ds_load_b32 v139, v176                                     // 00000001B028: D8D80000 8B0000B0
	.long 0xd4430010                                           // 00000001B030: D4430010
	v_cndmask_b32_e32 v1, s31, v254, vcc_lo                    // 00000001B034: 0203FC1F
	s_waitcnt lgkmcnt(0)                                       // 00000001B038: BF89FC07
	v_mov_b32_e32 v138, v139                                   // 00000001B03C: 7F14038B
	s_and_saveexec_b32 s0, s16                                 // 00000001B040: BE802010
	s_cbranch_execz 7                                          // 00000001B044: BFA50007 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x1464>
	ds_load_b32 v137, v255                                     // 00000001B048: D8D80000 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B050: BF89FC07
	v_dual_max_f32 v138, v139, v139 :: v_dual_max_f32 v137, v137, v137// 00000001B054: CA95178B 8A891389
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B05C: BF870001
	v_max_f32_e32 v138, v138, v137                             // 00000001B060: 2115138A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001B064: 8C7E007E
	.long 0xd441000f                                           // 00000001B068: D441000F
	v_cndmask_b32_e32 v1, s31, v254, vcc_lo                    // 00000001B06C: 0203FC1F
	s_and_saveexec_b32 s0, s15                                 // 00000001B070: BE80200F
	s_cbranch_execz 7                                          // 00000001B074: BFA50007 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x1494>
	ds_load_b32 v137, v255 offset:4                            // 00000001B078: D8D80004 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B080: BF89FC07
	v_dual_max_f32 v138, v138, v138 :: v_dual_max_f32 v137, v137, v137// 00000001B084: CA95158A 8A891389
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B08C: BF870001
	v_max_f32_e32 v138, v138, v137                             // 00000001B090: 2115138A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001B094: 8C7E007E
	s_add_i32 s0, s31, 2                                       // 00000001B098: 8100821F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B09C: BF870009
	.long 0xd443000e                                           // 00000001B0A0: D443000E
	v_cndmask_b32_e32 v1, s0, v254, vcc_lo                     // 00000001B0A4: 0203FC00
	s_and_saveexec_b32 s0, s14                                 // 00000001B0A8: BE80200E
	s_cbranch_execz 7                                          // 00000001B0AC: BFA50007 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x14cc>
	ds_load_b32 v137, v255 offset:8                            // 00000001B0B0: D8D80008 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B0B8: BF89FC07
	v_dual_max_f32 v138, v138, v138 :: v_dual_max_f32 v137, v137, v137// 00000001B0BC: CA95158A 8A891389
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B0C4: BF870001
	v_max_f32_e32 v138, v138, v137                             // 00000001B0C8: 2115138A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001B0CC: 8C7E007E
	s_add_i32 s0, s31, 3                                       // 00000001B0D0: 8100831F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B0D4: BF870009
	.long 0xd443000d                                           // 00000001B0D8: D443000D
	v_cndmask_b32_e32 v1, s0, v254, vcc_lo                     // 00000001B0DC: 0203FC00
	s_and_saveexec_b32 s0, s13                                 // 00000001B0E0: BE80200D
	s_cbranch_execz 7                                          // 00000001B0E4: BFA50007 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x1504>
	ds_load_b32 v137, v255 offset:12                           // 00000001B0E8: D8D8000C 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B0F0: BF89FC07
	v_dual_max_f32 v138, v138, v138 :: v_dual_max_f32 v137, v137, v137// 00000001B0F4: CA95158A 8A891389
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B0FC: BF870001
	v_max_f32_e32 v138, v138, v137                             // 00000001B100: 2115138A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001B104: 8C7E007E
	s_add_i32 s0, s31, 4                                       // 00000001B108: 8100841F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B10C: BF870009
	.long 0xd443000c                                           // 00000001B110: D443000C
	v_cndmask_b32_e32 v1, s0, v254, vcc_lo                     // 00000001B114: 0203FC00
	s_and_saveexec_b32 s0, s12                                 // 00000001B118: BE80200C
	s_cbranch_execz 7                                          // 00000001B11C: BFA50007 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x153c>
	ds_load_b32 v137, v255 offset:16                           // 00000001B120: D8D80010 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B128: BF89FC07
	v_dual_max_f32 v138, v138, v138 :: v_dual_max_f32 v137, v137, v137// 00000001B12C: CA95158A 8A891389
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B134: BF870001
	v_max_f32_e32 v138, v138, v137                             // 00000001B138: 2115138A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001B13C: 8C7E007E
	s_add_i32 s0, s31, 5                                       // 00000001B140: 8100851F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B144: BF870009
	.long 0xd443000b                                           // 00000001B148: D443000B
	v_cndmask_b32_e32 v1, s0, v254, vcc_lo                     // 00000001B14C: 0203FC00
	s_and_saveexec_b32 s0, s11                                 // 00000001B150: BE80200B
	s_cbranch_execz 7                                          // 00000001B154: BFA50007 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x1574>
	ds_load_b32 v137, v255 offset:20                           // 00000001B158: D8D80014 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B160: BF89FC07
	v_dual_max_f32 v138, v138, v138 :: v_dual_max_f32 v137, v137, v137// 00000001B164: CA95158A 8A891389
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B16C: BF870001
	v_max_f32_e32 v138, v138, v137                             // 00000001B170: 2115138A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001B174: 8C7E007E
	s_add_i32 s0, s31, 6                                       // 00000001B178: 8100861F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B17C: BF870009
	.long 0xd443000a                                           // 00000001B180: D443000A
	v_cndmask_b32_e32 v1, s0, v254, vcc_lo                     // 00000001B184: 0203FC00
	s_and_saveexec_b32 s0, s10                                 // 00000001B188: BE80200A
	s_cbranch_execz 7                                          // 00000001B18C: BFA50007 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x15ac>
	ds_load_b32 v137, v255 offset:24                           // 00000001B190: D8D80018 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B198: BF89FC07
	v_dual_max_f32 v138, v138, v138 :: v_dual_max_f32 v137, v137, v137// 00000001B19C: CA95158A 8A891389
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B1A4: BF870001
	v_max_f32_e32 v138, v138, v137                             // 00000001B1A8: 2115138A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001B1AC: 8C7E007E
	s_add_i32 s0, s31, 7                                       // 00000001B1B0: 8100871F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B1B4: BF870009
	.long 0xd4430009                                           // 00000001B1B8: D4430009
	v_cndmask_b32_e32 v1, s0, v254, vcc_lo                     // 00000001B1BC: 0203FC00
	s_and_saveexec_b32 s0, s9                                  // 00000001B1C0: BE802009
	s_cbranch_execz 7                                          // 00000001B1C4: BFA50007 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x15e4>
	ds_load_b32 v137, v255 offset:28                           // 00000001B1C8: D8D8001C 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B1D0: BF89FC07
	v_dual_max_f32 v138, v138, v138 :: v_dual_max_f32 v137, v137, v137// 00000001B1D4: CA95158A 8A891389
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B1DC: BF870001
	v_max_f32_e32 v138, v138, v137                             // 00000001B1E0: 2115138A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001B1E4: 8C7E007E
	s_add_i32 s0, s31, 8                                       // 00000001B1E8: 8100881F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B1EC: BF870009
	.long 0xd4430008                                           // 00000001B1F0: D4430008
	v_cndmask_b32_e32 v1, s0, v254, vcc_lo                     // 00000001B1F4: 0203FC00
	s_and_saveexec_b32 s0, s8                                  // 00000001B1F8: BE802008
	s_cbranch_execz 7                                          // 00000001B1FC: BFA50007 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x161c>
	ds_load_b32 v137, v255 offset:32                           // 00000001B200: D8D80020 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B208: BF89FC07
	v_dual_max_f32 v138, v138, v138 :: v_dual_max_f32 v137, v137, v137// 00000001B20C: CA95158A 8A891389
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B214: BF870001
	v_max_f32_e32 v138, v138, v137                             // 00000001B218: 2115138A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001B21C: 8C7E007E
	s_add_i32 s0, s31, 9                                       // 00000001B220: 8100891F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B224: BF870009
	.long 0xd4430007                                           // 00000001B228: D4430007
	v_cndmask_b32_e32 v1, s0, v254, vcc_lo                     // 00000001B22C: 0203FC00
	s_and_saveexec_b32 s0, s7                                  // 00000001B230: BE802007
	s_cbranch_execz 7                                          // 00000001B234: BFA50007 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x1654>
	ds_load_b32 v137, v255 offset:36                           // 00000001B238: D8D80024 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B240: BF89FC07
	v_dual_max_f32 v138, v138, v138 :: v_dual_max_f32 v137, v137, v137// 00000001B244: CA95158A 8A891389
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B24C: BF870001
	v_max_f32_e32 v138, v138, v137                             // 00000001B250: 2115138A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001B254: 8C7E007E
	s_add_i32 s0, s31, 10                                      // 00000001B258: 81008A1F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B25C: BF870009
	.long 0xd4430006                                           // 00000001B260: D4430006
	v_cndmask_b32_e32 v1, s0, v254, vcc_lo                     // 00000001B264: 0203FC00
	s_and_saveexec_b32 s0, s6                                  // 00000001B268: BE802006
	s_cbranch_execz 7                                          // 00000001B26C: BFA50007 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x168c>
	ds_load_b32 v137, v255 offset:40                           // 00000001B270: D8D80028 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B278: BF89FC07
	v_dual_max_f32 v138, v138, v138 :: v_dual_max_f32 v137, v137, v137// 00000001B27C: CA95158A 8A891389
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B284: BF870001
	v_max_f32_e32 v138, v138, v137                             // 00000001B288: 2115138A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001B28C: 8C7E007E
	s_add_i32 s0, s31, 11                                      // 00000001B290: 81008B1F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B294: BF870009
	.long 0xd4430005                                           // 00000001B298: D4430005
	v_cndmask_b32_e32 v1, s0, v254, vcc_lo                     // 00000001B29C: 0203FC00
	s_and_saveexec_b32 s0, s5                                  // 00000001B2A0: BE802005
	s_cbranch_execz 7                                          // 00000001B2A4: BFA50007 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x16c4>
	ds_load_b32 v137, v255 offset:44                           // 00000001B2A8: D8D8002C 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B2B0: BF89FC07
	v_dual_max_f32 v138, v138, v138 :: v_dual_max_f32 v137, v137, v137// 00000001B2B4: CA95158A 8A891389
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B2BC: BF870001
	v_max_f32_e32 v138, v138, v137                             // 00000001B2C0: 2115138A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001B2C4: 8C7E007E
	s_add_i32 s0, s31, 12                                      // 00000001B2C8: 81008C1F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B2CC: BF870009
	.long 0xd4430004                                           // 00000001B2D0: D4430004
	v_cndmask_b32_e32 v1, s0, v254, vcc_lo                     // 00000001B2D4: 0203FC00
	s_and_saveexec_b32 s0, s4                                  // 00000001B2D8: BE802004
	s_cbranch_execz 7                                          // 00000001B2DC: BFA50007 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x16fc>
	ds_load_b32 v137, v255 offset:48                           // 00000001B2E0: D8D80030 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B2E8: BF89FC07
	v_dual_max_f32 v138, v138, v138 :: v_dual_max_f32 v137, v137, v137// 00000001B2EC: CA95158A 8A891389
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B2F4: BF870001
	v_max_f32_e32 v138, v138, v137                             // 00000001B2F8: 2115138A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001B2FC: 8C7E007E
	s_add_i32 s0, s31, 13                                      // 00000001B300: 81008D1F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B304: BF870009
	.long 0xd4430002                                           // 00000001B308: D4430002
	v_cndmask_b32_e32 v1, s0, v254, vcc_lo                     // 00000001B30C: 0203FC00
	s_and_saveexec_b32 s0, s2                                  // 00000001B310: BE802002
	s_cbranch_execz 7                                          // 00000001B314: BFA50007 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x1734>
	ds_load_b32 v137, v255 offset:52                           // 00000001B318: D8D80034 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B320: BF89FC07
	v_dual_max_f32 v138, v138, v138 :: v_dual_max_f32 v137, v137, v137// 00000001B324: CA95158A 8A891389
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B32C: BF870001
	v_max_f32_e32 v138, v138, v137                             // 00000001B330: 2115138A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001B334: 8C7E007E
	s_add_i32 s0, s31, 14                                      // 00000001B338: 81008E1F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B33C: BF870009
	.long 0xd4430001                                           // 00000001B340: D4430001
	v_cndmask_b32_e32 v1, s0, v254, vcc_lo                     // 00000001B344: 0203FC00
	s_and_saveexec_b32 s0, s1                                  // 00000001B348: BE802001
	s_cbranch_execz 7                                          // 00000001B34C: BFA50007 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x176c>
	ds_load_b32 v137, v255 offset:56                           // 00000001B350: D8D80038 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B358: BF89FC07
	v_dual_max_f32 v138, v138, v138 :: v_dual_max_f32 v137, v137, v137// 00000001B35C: CA95158A 8A891389
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B364: BF870001
	v_max_f32_e32 v138, v138, v137                             // 00000001B368: 2115138A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001B36C: 8C7E007E
	s_add_i32 s0, s31, 15                                      // 00000001B370: 81008F1F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000001B374: BF870009
	.long 0xd4430000                                           // 00000001B378: D4430000
	v_cndmask_b32_e32 v1, s0, v254, vcc_lo                     // 00000001B37C: 0203FC00
	s_and_saveexec_b32 s34, s0                                 // 00000001B380: BEA22000
	s_cbranch_execz 7                                          // 00000001B384: BFA50007 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x17a4>
	ds_load_b32 v137, v255 offset:60                           // 00000001B388: D8D8003C 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B390: BF89FC07
	v_dual_max_f32 v138, v138, v138 :: v_dual_max_f32 v137, v137, v137// 00000001B394: CA95158A 8A891389
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B39C: BF870001
	v_max_f32_e32 v138, v138, v137                             // 00000001B3A0: 2115138A
	s_or_b32 exec_lo, exec_lo, s34                             // 00000001B3A4: 8C7E227E
	v_dual_mov_b32 v140, 0 :: v_dual_mov_b32 v141, 0           // 00000001B3A8: CA100080 8C8C0080
	s_and_saveexec_b32 s34, s16                                // 00000001B3B0: BEA22010
	s_cbranch_execz 33                                         // 00000001B3B4: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x183c>
	ds_load_b32 v137, v255                                     // 00000001B3B8: D8D80000 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B3C0: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000001B3C4: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B3C8: BF870121
	v_mul_f32_e32 v141, 0x3fb8aa3b, v137                       // 00000001B3CC: 111B12FF 3FB8AA3B
	.long 0xd41b0010                                           // 00000001B3D4: D41B0010
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001B3D8: 020312FF C2CE8ED0
	v_fma_f32 v142, 0x3fb8aa3b, v137, -v141                    // 00000001B3E0: D613008E 863712FF 3FB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 00000001B3EC: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B3F0: BF870091
	v_dual_fmac_f32 v142, 0x32a5705f, v137 :: v_dual_sub_f32 v141, v141, v143// 00000001B3F4: C80B12FF 8E8D1F8D 32A5705F
	v_add_f32_e32 v141, v141, v142                             // 00000001B400: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 00000001B404: 7F1C118F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001B408: BF870292
	v_exp_f32_e32 v141, v141                                   // 00000001B40C: 7F1A4B8D
	.long 0xd71c008d                                           // 00000001B410: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 00000001B414: 02031D8D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001B418: BF8700A1
	v_cndmask_b32_e64 v141, 0, v141, s16                       // 00000001B41C: D501008D 00431A80
	.long 0xd41e0010                                           // 00000001B424: D41E0010
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001B428: 020312FF 42B17218
	v_cndmask_b32_e64 v141, 0x7f800000, v141, s16              // 00000001B430: D501008D 00431AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s34                             // 00000001B43C: 8C7E227E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B440: BF870091
	v_bfe_u32 v137, v141, 16, 1                                // 00000001B444: D6100089 0205218D
	v_add3_u32 v137, v141, v137, 0x7fff                        // 00000001B44C: D6550089 03FF138D 00007FFF
	ds_store_b16_d16_hi v0, v137                               // 00000001B458: DA840000 00008900
	s_and_saveexec_b32 s16, s15                                // 00000001B460: BE90200F
	s_cbranch_execz 34                                         // 00000001B464: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x18f0>
	ds_load_b32 v137, v255 offset:4                            // 00000001B468: D8D80004 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B470: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000001B474: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B478: BF870091
	v_mul_f32_e32 v140, 0x3fb8aa3b, v137                       // 00000001B47C: 111912FF 3FB8AA3B
	v_fma_f32 v142, 0x3fb8aa3b, v137, -v140                    // 00000001B484: D613008E 863312FF 3FB8AA3B
	v_rndne_f32_e32 v143, v140                                 // 00000001B490: 7F1E478C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001B494: BF870191
	v_sub_f32_e32 v140, v140, v143                             // 00000001B498: 09191F8C
	v_fmac_f32_e32 v142, 0x32a5705f, v137                      // 00000001B49C: 571D12FF 32A5705F
	.long 0xd41b000f                                           // 00000001B4A4: D41B000F
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001B4A8: 020312FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B4B0: BF870122
	v_add_f32_e32 v140, v140, v142                             // 00000001B4B4: 07191D8C
	v_cvt_i32_f32_e32 v142, v143                               // 00000001B4B8: 7F1C118F
	v_exp_f32_e32 v140, v140                                   // 00000001B4BC: 7F184B8C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B4C0: BF870095
	.long 0xd71c008c                                           // 00000001B4C4: D71C008C
	v_cndmask_b32_e32 v1, v140, v142, vcc_lo                   // 00000001B4C8: 02031D8C
	v_cndmask_b32_e64 v140, 0, v140, s15                       // 00000001B4CC: D501008C 003F1880
	.long 0xd41e000f                                           // 00000001B4D4: D41E000F
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001B4D8: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B4E0: BF870001
	v_cndmask_b32_e64 v140, 0x7f800000, v140, s15              // 00000001B4E4: D501008C 003F18FF 7F800000
	s_or_b32 exec_lo, exec_lo, s16                             // 00000001B4F0: 8C7E107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B4F4: BF870121
	v_bfe_u32 v137, v140, 16, 1                                // 00000001B4F8: D6100089 0205218C
	v_dual_mov_b32 v142, 0 :: v_dual_mov_b32 v143, 0           // 00000001B500: CA100080 8E8E0080
	v_add3_u32 v137, v140, v137, 0x7fff                        // 00000001B508: D6550089 03FF138C 00007FFF
	ds_store_b16_d16_hi v0, v137 offset:2                      // 00000001B514: DA840002 00008900
	s_and_saveexec_b32 s15, s14                                // 00000001B51C: BE8F200E
	s_cbranch_execz 34                                         // 00000001B520: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x19ac>
	ds_load_b32 v137, v255 offset:8                            // 00000001B524: D8D80008 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B52C: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000001B530: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B534: BF870121
	v_mul_f32_e32 v143, 0x3fb8aa3b, v137                       // 00000001B538: 111F12FF 3FB8AA3B
	.long 0xd41b000e                                           // 00000001B540: D41B000E
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001B544: 020312FF C2CE8ED0
	v_fma_f32 v144, 0x3fb8aa3b, v137, -v143                    // 00000001B54C: D6130090 863F12FF 3FB8AA3B
	v_rndne_f32_e32 v145, v143                                 // 00000001B558: 7F22478F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001B55C: BF870112
	v_fmac_f32_e32 v144, 0x32a5705f, v137                      // 00000001B560: 572112FF 32A5705F
	v_sub_f32_e32 v143, v143, v145                             // 00000001B568: 091F238F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B56C: BF870121
	v_add_f32_e32 v143, v143, v144                             // 00000001B570: 071F218F
	v_cvt_i32_f32_e32 v144, v145                               // 00000001B574: 7F201191
	v_exp_f32_e32 v143, v143                                   // 00000001B578: 7F1E4B8F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B57C: BF870095
	.long 0xd71c008f                                           // 00000001B580: D71C008F
	v_cndmask_b32_e32 v1, v143, v144, vcc_lo                   // 00000001B584: 0203218F
	v_cndmask_b32_e64 v143, 0, v143, s14                       // 00000001B588: D501008F 003B1E80
	.long 0xd41e000e                                           // 00000001B590: D41E000E
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001B594: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B59C: BF870001
	v_cndmask_b32_e64 v143, 0x7f800000, v143, s14              // 00000001B5A0: D501008F 003B1EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s15                             // 00000001B5AC: 8C7E0F7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B5B0: BF870091
	v_bfe_u32 v137, v143, 16, 1                                // 00000001B5B4: D6100089 0205218F
	v_add3_u32 v137, v143, v137, 0x7fff                        // 00000001B5BC: D6550089 03FF138F 00007FFF
	ds_store_b16_d16_hi v0, v137 offset:4                      // 00000001B5C8: DA840004 00008900
	s_and_saveexec_b32 s14, s13                                // 00000001B5D0: BE8E200D
	s_cbranch_execz 34                                         // 00000001B5D4: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x1a60>
	ds_load_b32 v137, v255 offset:12                           // 00000001B5D8: D8D8000C 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B5E0: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000001B5E4: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B5E8: BF870091
	v_mul_f32_e32 v142, 0x3fb8aa3b, v137                       // 00000001B5EC: 111D12FF 3FB8AA3B
	v_fma_f32 v144, 0x3fb8aa3b, v137, -v142                    // 00000001B5F4: D6130090 863B12FF 3FB8AA3B
	v_rndne_f32_e32 v145, v142                                 // 00000001B600: 7F22478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001B604: BF870191
	v_sub_f32_e32 v142, v142, v145                             // 00000001B608: 091D238E
	v_fmac_f32_e32 v144, 0x32a5705f, v137                      // 00000001B60C: 572112FF 32A5705F
	.long 0xd41b000d                                           // 00000001B614: D41B000D
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001B618: 020312FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B620: BF870122
	v_add_f32_e32 v142, v142, v144                             // 00000001B624: 071D218E
	v_cvt_i32_f32_e32 v144, v145                               // 00000001B628: 7F201191
	v_exp_f32_e32 v142, v142                                   // 00000001B62C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B630: BF870095
	.long 0xd71c008e                                           // 00000001B634: D71C008E
	v_cndmask_b32_e32 v1, v142, v144, vcc_lo                   // 00000001B638: 0203218E
	v_cndmask_b32_e64 v142, 0, v142, s13                       // 00000001B63C: D501008E 00371C80
	.long 0xd41e000d                                           // 00000001B644: D41E000D
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001B648: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B650: BF870001
	v_cndmask_b32_e64 v142, 0x7f800000, v142, s13              // 00000001B654: D501008E 00371CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s14                             // 00000001B660: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B664: BF870121
	v_bfe_u32 v137, v142, 16, 1                                // 00000001B668: D6100089 0205218E
	v_dual_mov_b32 v144, 0 :: v_dual_mov_b32 v145, 0           // 00000001B670: CA100080 90900080
	v_add3_u32 v137, v142, v137, 0x7fff                        // 00000001B678: D6550089 03FF138E 00007FFF
	ds_store_b16_d16_hi v0, v137 offset:6                      // 00000001B684: DA840006 00008900
	s_and_saveexec_b32 s13, s12                                // 00000001B68C: BE8D200C
	s_cbranch_execz 33                                         // 00000001B690: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x1b18>
	ds_load_b32 v137, v255 offset:16                           // 00000001B694: D8D80010 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B69C: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000001B6A0: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B6A4: BF870121
	v_mul_f32_e32 v145, 0x3fb8aa3b, v137                       // 00000001B6A8: 112312FF 3FB8AA3B
	.long 0xd41b000c                                           // 00000001B6B0: D41B000C
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001B6B4: 020312FF C2CE8ED0
	v_fma_f32 v146, 0x3fb8aa3b, v137, -v145                    // 00000001B6BC: D6130092 864712FF 3FB8AA3B
	v_rndne_f32_e32 v147, v145                                 // 00000001B6C8: 7F264791
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B6CC: BF870091
	v_dual_fmac_f32 v146, 0x32a5705f, v137 :: v_dual_sub_f32 v145, v145, v147// 00000001B6D0: C80B12FF 92912791 32A5705F
	v_add_f32_e32 v145, v145, v146                             // 00000001B6DC: 07232591
	v_cvt_i32_f32_e32 v146, v147                               // 00000001B6E0: 7F241193
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001B6E4: BF870292
	v_exp_f32_e32 v145, v145                                   // 00000001B6E8: 7F224B91
	.long 0xd71c0091                                           // 00000001B6EC: D71C0091
	v_cndmask_b32_e32 v1, v145, v146, vcc_lo                   // 00000001B6F0: 02032591
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001B6F4: BF8700A1
	v_cndmask_b32_e64 v145, 0, v145, s12                       // 00000001B6F8: D5010091 00332280
	.long 0xd41e000c                                           // 00000001B700: D41E000C
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001B704: 020312FF 42B17218
	v_cndmask_b32_e64 v145, 0x7f800000, v145, s12              // 00000001B70C: D5010091 003322FF 7F800000
	s_or_b32 exec_lo, exec_lo, s13                             // 00000001B718: 8C7E0D7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B71C: BF870091
	v_bfe_u32 v137, v145, 16, 1                                // 00000001B720: D6100089 02052191
	v_add3_u32 v137, v145, v137, 0x7fff                        // 00000001B728: D6550089 03FF1391 00007FFF
	ds_store_b16_d16_hi v0, v137 offset:8                      // 00000001B734: DA840008 00008900
	s_and_saveexec_b32 s12, s11                                // 00000001B73C: BE8C200B
	s_cbranch_execz 34                                         // 00000001B740: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x1bcc>
	ds_load_b32 v137, v255 offset:20                           // 00000001B744: D8D80014 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B74C: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000001B750: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B754: BF870091
	v_mul_f32_e32 v144, 0x3fb8aa3b, v137                       // 00000001B758: 112112FF 3FB8AA3B
	v_fma_f32 v146, 0x3fb8aa3b, v137, -v144                    // 00000001B760: D6130092 864312FF 3FB8AA3B
	v_rndne_f32_e32 v147, v144                                 // 00000001B76C: 7F264790
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001B770: BF870191
	v_sub_f32_e32 v144, v144, v147                             // 00000001B774: 09212790
	v_fmac_f32_e32 v146, 0x32a5705f, v137                      // 00000001B778: 572512FF 32A5705F
	.long 0xd41b000b                                           // 00000001B780: D41B000B
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001B784: 020312FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B78C: BF870122
	v_add_f32_e32 v144, v144, v146                             // 00000001B790: 07212590
	v_cvt_i32_f32_e32 v146, v147                               // 00000001B794: 7F241193
	v_exp_f32_e32 v144, v144                                   // 00000001B798: 7F204B90
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B79C: BF870095
	.long 0xd71c0090                                           // 00000001B7A0: D71C0090
	v_cndmask_b32_e32 v1, v144, v146, vcc_lo                   // 00000001B7A4: 02032590
	v_cndmask_b32_e64 v144, 0, v144, s11                       // 00000001B7A8: D5010090 002F2080
	.long 0xd41e000b                                           // 00000001B7B0: D41E000B
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001B7B4: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B7BC: BF870001
	v_cndmask_b32_e64 v144, 0x7f800000, v144, s11              // 00000001B7C0: D5010090 002F20FF 7F800000
	s_or_b32 exec_lo, exec_lo, s12                             // 00000001B7CC: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B7D0: BF870121
	v_bfe_u32 v137, v144, 16, 1                                // 00000001B7D4: D6100089 02052190
	v_dual_mov_b32 v146, 0 :: v_dual_mov_b32 v147, 0           // 00000001B7DC: CA100080 92920080
	v_add3_u32 v137, v144, v137, 0x7fff                        // 00000001B7E4: D6550089 03FF1390 00007FFF
	ds_store_b16_d16_hi v0, v137 offset:10                     // 00000001B7F0: DA84000A 00008900
	s_and_saveexec_b32 s11, s10                                // 00000001B7F8: BE8B200A
	s_cbranch_execz 34                                         // 00000001B7FC: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x1c88>
	ds_load_b32 v137, v255 offset:24                           // 00000001B800: D8D80018 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B808: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000001B80C: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B810: BF870121
	v_mul_f32_e32 v147, 0x3fb8aa3b, v137                       // 00000001B814: 112712FF 3FB8AA3B
	.long 0xd41b000a                                           // 00000001B81C: D41B000A
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001B820: 020312FF C2CE8ED0
	v_fma_f32 v148, 0x3fb8aa3b, v137, -v147                    // 00000001B828: D6130094 864F12FF 3FB8AA3B
	v_rndne_f32_e32 v149, v147                                 // 00000001B834: 7F2A4793
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001B838: BF870112
	v_fmac_f32_e32 v148, 0x32a5705f, v137                      // 00000001B83C: 572912FF 32A5705F
	v_sub_f32_e32 v147, v147, v149                             // 00000001B844: 09272B93
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B848: BF870121
	v_add_f32_e32 v147, v147, v148                             // 00000001B84C: 07272993
	v_cvt_i32_f32_e32 v148, v149                               // 00000001B850: 7F281195
	v_exp_f32_e32 v147, v147                                   // 00000001B854: 7F264B93
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B858: BF870095
	.long 0xd71c0093                                           // 00000001B85C: D71C0093
	v_cndmask_b32_e32 v1, v147, v148, vcc_lo                   // 00000001B860: 02032993
	v_cndmask_b32_e64 v147, 0, v147, s10                       // 00000001B864: D5010093 002B2680
	.long 0xd41e000a                                           // 00000001B86C: D41E000A
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001B870: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B878: BF870001
	v_cndmask_b32_e64 v147, 0x7f800000, v147, s10              // 00000001B87C: D5010093 002B26FF 7F800000
	s_or_b32 exec_lo, exec_lo, s11                             // 00000001B888: 8C7E0B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B88C: BF870091
	v_bfe_u32 v137, v147, 16, 1                                // 00000001B890: D6100089 02052193
	v_add3_u32 v137, v147, v137, 0x7fff                        // 00000001B898: D6550089 03FF1393 00007FFF
	ds_store_b16_d16_hi v0, v137 offset:12                     // 00000001B8A4: DA84000C 00008900
	s_and_saveexec_b32 s10, s9                                 // 00000001B8AC: BE8A2009
	s_cbranch_execz 34                                         // 00000001B8B0: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x1d3c>
	ds_load_b32 v137, v255 offset:28                           // 00000001B8B4: D8D8001C 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B8BC: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000001B8C0: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B8C4: BF870091
	v_mul_f32_e32 v146, 0x3fb8aa3b, v137                       // 00000001B8C8: 112512FF 3FB8AA3B
	v_fma_f32 v148, 0x3fb8aa3b, v137, -v146                    // 00000001B8D0: D6130094 864B12FF 3FB8AA3B
	v_rndne_f32_e32 v149, v146                                 // 00000001B8DC: 7F2A4792
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001B8E0: BF870191
	v_sub_f32_e32 v146, v146, v149                             // 00000001B8E4: 09252B92
	v_fmac_f32_e32 v148, 0x32a5705f, v137                      // 00000001B8E8: 572912FF 32A5705F
	.long 0xd41b0009                                           // 00000001B8F0: D41B0009
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001B8F4: 020312FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B8FC: BF870122
	v_add_f32_e32 v146, v146, v148                             // 00000001B900: 07252992
	v_cvt_i32_f32_e32 v148, v149                               // 00000001B904: 7F281195
	v_exp_f32_e32 v146, v146                                   // 00000001B908: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B90C: BF870095
	.long 0xd71c0092                                           // 00000001B910: D71C0092
	v_cndmask_b32_e32 v1, v146, v148, vcc_lo                   // 00000001B914: 02032992
	v_cndmask_b32_e64 v146, 0, v146, s9                        // 00000001B918: D5010092 00272480
	.long 0xd41e0009                                           // 00000001B920: D41E0009
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001B924: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001B92C: BF870001
	v_cndmask_b32_e64 v146, 0x7f800000, v146, s9               // 00000001B930: D5010092 002724FF 7F800000
	s_or_b32 exec_lo, exec_lo, s10                             // 00000001B93C: 8C7E0A7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B940: BF870121
	v_bfe_u32 v137, v146, 16, 1                                // 00000001B944: D6100089 02052192
	v_dual_mov_b32 v148, 0 :: v_dual_mov_b32 v149, 0           // 00000001B94C: CA100080 94940080
	v_add3_u32 v137, v146, v137, 0x7fff                        // 00000001B954: D6550089 03FF1392 00007FFF
	ds_store_b16_d16_hi v0, v137 offset:14                     // 00000001B960: DA84000E 00008900
	s_and_saveexec_b32 s9, s8                                  // 00000001B968: BE892008
	s_cbranch_execz 33                                         // 00000001B96C: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x1df4>
	ds_load_b32 v137, v255 offset:32                           // 00000001B970: D8D80020 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001B978: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000001B97C: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001B980: BF870121
	v_mul_f32_e32 v149, 0x3fb8aa3b, v137                       // 00000001B984: 112B12FF 3FB8AA3B
	.long 0xd41b0008                                           // 00000001B98C: D41B0008
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001B990: 020312FF C2CE8ED0
	v_fma_f32 v150, 0x3fb8aa3b, v137, -v149                    // 00000001B998: D6130096 865712FF 3FB8AA3B
	v_rndne_f32_e32 v151, v149                                 // 00000001B9A4: 7F2E4795
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B9A8: BF870091
	v_dual_fmac_f32 v150, 0x32a5705f, v137 :: v_dual_sub_f32 v149, v149, v151// 00000001B9AC: C80B12FF 96952F95 32A5705F
	v_add_f32_e32 v149, v149, v150                             // 00000001B9B8: 072B2D95
	v_cvt_i32_f32_e32 v150, v151                               // 00000001B9BC: 7F2C1197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001B9C0: BF870292
	v_exp_f32_e32 v149, v149                                   // 00000001B9C4: 7F2A4B95
	.long 0xd71c0095                                           // 00000001B9C8: D71C0095
	v_cndmask_b32_e32 v1, v149, v150, vcc_lo                   // 00000001B9CC: 02032D95
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001B9D0: BF8700A1
	v_cndmask_b32_e64 v149, 0, v149, s8                        // 00000001B9D4: D5010095 00232A80
	.long 0xd41e0008                                           // 00000001B9DC: D41E0008
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001B9E0: 020312FF 42B17218
	v_cndmask_b32_e64 v149, 0x7f800000, v149, s8               // 00000001B9E8: D5010095 00232AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s9                              // 00000001B9F4: 8C7E097E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001B9F8: BF870091
	v_bfe_u32 v137, v149, 16, 1                                // 00000001B9FC: D6100089 02052195
	v_add3_u32 v137, v149, v137, 0x7fff                        // 00000001BA04: D6550089 03FF1395 00007FFF
	ds_store_b16_d16_hi v0, v137 offset:16                     // 00000001BA10: DA840010 00008900
	s_and_saveexec_b32 s8, s7                                  // 00000001BA18: BE882007
	s_cbranch_execz 34                                         // 00000001BA1C: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x1ea8>
	ds_load_b32 v137, v255 offset:36                           // 00000001BA20: D8D80024 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001BA28: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000001BA2C: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BA30: BF870091
	v_mul_f32_e32 v148, 0x3fb8aa3b, v137                       // 00000001BA34: 112912FF 3FB8AA3B
	v_fma_f32 v150, 0x3fb8aa3b, v137, -v148                    // 00000001BA3C: D6130096 865312FF 3FB8AA3B
	v_rndne_f32_e32 v151, v148                                 // 00000001BA48: 7F2E4794
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000001BA4C: BF870191
	v_sub_f32_e32 v148, v148, v151                             // 00000001BA50: 09292F94
	v_fmac_f32_e32 v150, 0x32a5705f, v137                      // 00000001BA54: 572D12FF 32A5705F
	.long 0xd41b0007                                           // 00000001BA5C: D41B0007
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001BA60: 020312FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BA68: BF870122
	v_add_f32_e32 v148, v148, v150                             // 00000001BA6C: 07292D94
	v_cvt_i32_f32_e32 v150, v151                               // 00000001BA70: 7F2C1197
	v_exp_f32_e32 v148, v148                                   // 00000001BA74: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BA78: BF870095
	.long 0xd71c0094                                           // 00000001BA7C: D71C0094
	v_cndmask_b32_e32 v1, v148, v150, vcc_lo                   // 00000001BA80: 02032D94
	v_cndmask_b32_e64 v148, 0, v148, s7                        // 00000001BA84: D5010094 001F2880
	.long 0xd41e0007                                           // 00000001BA8C: D41E0007
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001BA90: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001BA98: BF870001
	v_cndmask_b32_e64 v148, 0x7f800000, v148, s7               // 00000001BA9C: D5010094 001F28FF 7F800000
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001BAA8: 8C7E087E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BAAC: BF870121
	v_bfe_u32 v137, v148, 16, 1                                // 00000001BAB0: D6100089 02052194
	v_dual_mov_b32 v150, 0 :: v_dual_mov_b32 v151, 0           // 00000001BAB8: CA100080 96960080
	v_add3_u32 v137, v148, v137, 0x7fff                        // 00000001BAC0: D6550089 03FF1394 00007FFF
	ds_store_b16_d16_hi v0, v137 offset:18                     // 00000001BACC: DA840012 00008900
	s_and_saveexec_b32 s7, s6                                  // 00000001BAD4: BE872006
	s_cbranch_execz 34                                         // 00000001BAD8: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x1f64>
	ds_load_b32 v137, v255 offset:40                           // 00000001BADC: D8D80028 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001BAE4: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000001BAE8: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BAEC: BF870121
	v_mul_f32_e32 v151, 0x3fb8aa3b, v137                       // 00000001BAF0: 112F12FF 3FB8AA3B
	.long 0xd41b0006                                           // 00000001BAF8: D41B0006
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001BAFC: 020312FF C2CE8ED0
	v_fma_f32 v157, 0x3fb8aa3b, v137, -v151                    // 00000001BB04: D613009D 865F12FF 3FB8AA3B
	v_rndne_f32_e32 v158, v151                                 // 00000001BB10: 7F3C4797
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001BB14: BF870112
	v_fmac_f32_e32 v157, 0x32a5705f, v137                      // 00000001BB18: 573B12FF 32A5705F
	v_sub_f32_e32 v151, v151, v158                             // 00000001BB20: 092F3D97
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BB24: BF870121
	v_add_f32_e32 v151, v151, v157                             // 00000001BB28: 072F3B97
	v_cvt_i32_f32_e32 v157, v158                               // 00000001BB2C: 7F3A119E
	v_exp_f32_e32 v151, v151                                   // 00000001BB30: 7F2E4B97
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BB34: BF870095
	.long 0xd71c0097                                           // 00000001BB38: D71C0097
	v_cndmask_b32_e32 v1, v151, v157, vcc_lo                   // 00000001BB3C: 02033B97
	v_cndmask_b32_e64 v151, 0, v151, s6                        // 00000001BB40: D5010097 001B2E80
	.long 0xd41e0006                                           // 00000001BB48: D41E0006
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001BB4C: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001BB54: BF870001
	v_cndmask_b32_e64 v151, 0x7f800000, v151, s6               // 00000001BB58: D5010097 001B2EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000001BB64: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BB68: BF870091
	v_bfe_u32 v137, v151, 16, 1                                // 00000001BB6C: D6100089 02052197
	v_add3_u32 v137, v151, v137, 0x7fff                        // 00000001BB74: D6550089 03FF1397 00007FFF
	ds_store_b16_d16_hi v0, v137 offset:20                     // 00000001BB80: DA840014 00008900
	s_and_saveexec_b32 s6, s5                                  // 00000001BB88: BE862005
	s_cbranch_execz 33                                         // 00000001BB8C: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2014>
	ds_load_b32 v137, v255 offset:44                           // 00000001BB90: D8D8002C 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001BB98: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000001BB9C: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BBA0: BF870091
	v_mul_f32_e32 v150, 0x3fb8aa3b, v137                       // 00000001BBA4: 112D12FF 3FB8AA3B
	v_fma_f32 v157, 0x3fb8aa3b, v137, -v150                    // 00000001BBAC: D613009D 865B12FF 3FB8AA3B
	v_rndne_f32_e32 v158, v150                                 // 00000001BBB8: 7F3C4796
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BBBC: BF870091
	v_dual_fmac_f32 v157, 0x32a5705f, v137 :: v_dual_sub_f32 v150, v150, v158// 00000001BBC0: C80B12FF 9D973D96 32A5705F
	v_add_f32_e32 v150, v150, v157                             // 00000001BBCC: 072D3B96
	v_cvt_i32_f32_e32 v157, v158                               // 00000001BBD0: 7F3A119E
	.long 0xd41b0005                                           // 00000001BBD4: D41B0005
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001BBD8: 020312FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001BBE0: BF870293
	v_exp_f32_e32 v150, v150                                   // 00000001BBE4: 7F2C4B96
	.long 0xd71c0096                                           // 00000001BBE8: D71C0096
	v_cndmask_b32_e32 v1, v150, v157, vcc_lo                   // 00000001BBEC: 02033B96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001BBF0: BF8700A1
	v_cndmask_b32_e64 v150, 0, v150, s5                        // 00000001BBF4: D5010096 00172C80
	.long 0xd41e0005                                           // 00000001BBFC: D41E0005
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001BC00: 020312FF 42B17218
	v_cndmask_b32_e64 v150, 0x7f800000, v150, s5               // 00000001BC08: D5010096 00172CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s6                              // 00000001BC14: 8C7E067E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BC18: BF870121
	v_bfe_u32 v137, v150, 16, 1                                // 00000001BC1C: D6100089 02052196
	v_dual_mov_b32 v157, 0 :: v_dual_mov_b32 v158, 0           // 00000001BC24: CA100080 9D9E0080
	v_add3_u32 v137, v150, v137, 0x7fff                        // 00000001BC2C: D6550089 03FF1396 00007FFF
	ds_store_b16_d16_hi v0, v137 offset:22                     // 00000001BC38: DA840016 00008900
	s_and_saveexec_b32 s5, s4                                  // 00000001BC40: BE852004
	s_cbranch_execz 33                                         // 00000001BC44: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x20cc>
	ds_load_b32 v137, v255 offset:48                           // 00000001BC48: D8D80030 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001BC50: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000001BC54: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BC58: BF870091
	v_mul_f32_e32 v158, 0x3fb8aa3b, v137                       // 00000001BC5C: 113D12FF 3FB8AA3B
	v_fma_f32 v159, 0x3fb8aa3b, v137, -v158                    // 00000001BC64: D613009F 867B12FF 3FB8AA3B
	v_rndne_f32_e32 v160, v158                                 // 00000001BC70: 7F40479E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BC74: BF870121
	v_dual_sub_f32 v158, v158, v160 :: v_dual_fmac_f32 v159, 0x32a5705f, v137// 00000001BC78: C941419E 9E9F12FF 32A5705F
	.long 0xd41b0004                                           // 00000001BC84: D41B0004
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001BC88: 020312FF C2CE8ED0
	v_add_f32_e32 v158, v158, v159                             // 00000001BC90: 073D3F9E
	v_cvt_i32_f32_e32 v159, v160                               // 00000001BC94: 7F3E11A0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001BC98: BF870292
	v_exp_f32_e32 v158, v158                                   // 00000001BC9C: 7F3C4B9E
	.long 0xd71c009e                                           // 00000001BCA0: D71C009E
	v_cndmask_b32_e32 v1, v158, v159, vcc_lo                   // 00000001BCA4: 02033F9E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001BCA8: BF8700A1
	v_cndmask_b32_e64 v158, 0, v158, s4                        // 00000001BCAC: D501009E 00133C80
	.long 0xd41e0004                                           // 00000001BCB4: D41E0004
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001BCB8: 020312FF 42B17218
	v_cndmask_b32_e64 v158, 0x7f800000, v158, s4               // 00000001BCC0: D501009E 00133CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s5                              // 00000001BCCC: 8C7E057E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BCD0: BF870091
	v_bfe_u32 v137, v158, 16, 1                                // 00000001BCD4: D6100089 0205219E
	v_add3_u32 v137, v158, v137, 0x7fff                        // 00000001BCDC: D6550089 03FF139E 00007FFF
	ds_store_b16_d16_hi v0, v137 offset:24                     // 00000001BCE8: DA840018 00008900
	s_and_saveexec_b32 s4, s2                                  // 00000001BCF0: BE842002
	s_cbranch_execz 34                                         // 00000001BCF4: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2180>
	ds_load_b32 v137, v255 offset:52                           // 00000001BCF8: D8D80034 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001BD00: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000001BD04: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BD08: BF870121
	v_mul_f32_e32 v157, 0x3fb8aa3b, v137                       // 00000001BD0C: 113B12FF 3FB8AA3B
	.long 0xd41b0002                                           // 00000001BD14: D41B0002
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001BD18: 020312FF C2CE8ED0
	v_fma_f32 v159, 0x3fb8aa3b, v137, -v157                    // 00000001BD20: D613009F 867712FF 3FB8AA3B
	v_rndne_f32_e32 v160, v157                                 // 00000001BD2C: 7F40479D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001BD30: BF870112
	v_fmac_f32_e32 v159, 0x32a5705f, v137                      // 00000001BD34: 573F12FF 32A5705F
	v_sub_f32_e32 v157, v157, v160                             // 00000001BD3C: 093B419D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BD40: BF870121
	v_add_f32_e32 v157, v157, v159                             // 00000001BD44: 073B3F9D
	v_cvt_i32_f32_e32 v159, v160                               // 00000001BD48: 7F3E11A0
	v_exp_f32_e32 v157, v157                                   // 00000001BD4C: 7F3A4B9D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BD50: BF870095
	.long 0xd71c009d                                           // 00000001BD54: D71C009D
	v_cndmask_b32_e32 v1, v157, v159, vcc_lo                   // 00000001BD58: 02033F9D
	v_cndmask_b32_e64 v157, 0, v157, s2                        // 00000001BD5C: D501009D 000B3A80
	.long 0xd41e0002                                           // 00000001BD64: D41E0002
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001BD68: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001BD70: BF870001
	v_cndmask_b32_e64 v157, 0x7f800000, v157, s2               // 00000001BD74: D501009D 000B3AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 00000001BD80: 8C7E047E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BD84: BF870121
	v_bfe_u32 v137, v157, 16, 1                                // 00000001BD88: D6100089 0205219D
	v_dual_mov_b32 v159, 0 :: v_dual_mov_b32 v160, 0           // 00000001BD90: CA100080 9FA00080
	v_add3_u32 v137, v157, v137, 0x7fff                        // 00000001BD98: D6550089 03FF139D 00007FFF
	ds_store_b16_d16_hi v0, v137 offset:26                     // 00000001BDA4: DA84001A 00008900
	s_and_saveexec_b32 s2, s1                                  // 00000001BDAC: BE822001
	s_cbranch_execz 33                                         // 00000001BDB0: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2238>
	ds_load_b32 v137, v255 offset:56                           // 00000001BDB4: D8D80038 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001BDBC: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000001BDC0: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BDC4: BF870091
	v_mul_f32_e32 v160, 0x3fb8aa3b, v137                       // 00000001BDC8: 114112FF 3FB8AA3B
	v_fma_f32 v161, 0x3fb8aa3b, v137, -v160                    // 00000001BDD0: D61300A1 868312FF 3FB8AA3B
	v_rndne_f32_e32 v162, v160                                 // 00000001BDDC: 7F4447A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BDE0: BF870091
	v_dual_fmac_f32 v161, 0x32a5705f, v137 :: v_dual_sub_f32 v160, v160, v162// 00000001BDE4: C80B12FF A1A145A0 32A5705F
	v_add_f32_e32 v160, v160, v161                             // 00000001BDF0: 074143A0
	v_cvt_i32_f32_e32 v161, v162                               // 00000001BDF4: 7F4211A2
	.long 0xd41b0001                                           // 00000001BDF8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001BDFC: 020312FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001BE04: BF870293
	v_exp_f32_e32 v160, v160                                   // 00000001BE08: 7F404BA0
	.long 0xd71c00a0                                           // 00000001BE0C: D71C00A0
	v_cndmask_b32_e32 v1, v160, v161, vcc_lo                   // 00000001BE10: 020343A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001BE14: BF8700A1
	v_cndmask_b32_e64 v160, 0, v160, s1                        // 00000001BE18: D50100A0 00074080
	.long 0xd41e0001                                           // 00000001BE20: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001BE24: 020312FF 42B17218
	v_cndmask_b32_e64 v160, 0x7f800000, v160, s1               // 00000001BE2C: D50100A0 000740FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000001BE38: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BE3C: BF870091
	v_bfe_u32 v137, v160, 16, 1                                // 00000001BE40: D6100089 020521A0
	v_add3_u32 v137, v160, v137, 0x7fff                        // 00000001BE48: D6550089 03FF13A0 00007FFF
	ds_store_b16_d16_hi v0, v137 offset:28                     // 00000001BE54: DA84001C 00008900
	s_and_saveexec_b32 s1, s0                                  // 00000001BE5C: BE812000
	s_cbranch_execz 34                                         // 00000001BE60: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x22ec>
	ds_load_b32 v137, v255 offset:60                           // 00000001BE64: D8D8003C 890000FF
	s_waitcnt lgkmcnt(0)                                       // 00000001BE6C: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000001BE70: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BE74: BF870121
	v_mul_f32_e32 v159, 0x3fb8aa3b, v137                       // 00000001BE78: 113F12FF 3FB8AA3B
	.long 0xd41b0000                                           // 00000001BE80: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001BE84: 020312FF C2CE8ED0
	v_fma_f32 v161, 0x3fb8aa3b, v137, -v159                    // 00000001BE8C: D61300A1 867F12FF 3FB8AA3B
	v_rndne_f32_e32 v162, v159                                 // 00000001BE98: 7F44479F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001BE9C: BF870112
	v_fmac_f32_e32 v161, 0x32a5705f, v137                      // 00000001BEA0: 574312FF 32A5705F
	v_sub_f32_e32 v159, v159, v162                             // 00000001BEA8: 093F459F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BEAC: BF870121
	v_add_f32_e32 v159, v159, v161                             // 00000001BEB0: 073F439F
	v_cvt_i32_f32_e32 v161, v162                               // 00000001BEB4: 7F4211A2
	v_exp_f32_e32 v159, v159                                   // 00000001BEB8: 7F3E4B9F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BEBC: BF870095
	.long 0xd71c009f                                           // 00000001BEC0: D71C009F
	v_cndmask_b32_e32 v1, v159, v161, vcc_lo                   // 00000001BEC4: 0203439F
	v_cndmask_b32_e64 v159, 0, v159, s0                        // 00000001BEC8: D501009F 00033E80
	.long 0xd41e0000                                           // 00000001BED0: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001BED4: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001BEDC: BF870001
	v_cndmask_b32_e64 v159, 0x7f800000, v159, s0               // 00000001BEE0: D501009F 00033EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001BEEC: 8C7E017E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000001BEF0: BF870131
	v_bfe_u32 v137, v159, 16, 1                                // 00000001BEF4: D6100089 0205219F
	v_mov_b32_e32 v249, 0                                      // 00000001BEFC: 7FF20280
	s_mov_b32 s1, exec_lo                                      // 00000001BF00: BE81007E
	v_add3_u32 v137, v159, v137, 0x7fff                        // 00000001BF04: D6550089 03FF139F 00007FFF
	ds_store_b16_d16_hi v0, v137 offset:30                     // 00000001BF10: DA84001E 00008900
	v_cmpx_lt_f32_e32 0xefa18f08, v139                         // 00000001BF18: 7D2316FF EFA18F08
	s_cbranch_execz 63754                                      // 00000001BF20: BFA5F90A <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x74c>
	v_sub_f32_e32 v137, v139, v138                             // 00000001BF24: 0913158B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BF28: BF870121
	v_mul_f32_e32 v139, 0x3fb8aa3b, v137                       // 00000001BF2C: 111712FF 3FB8AA3B
	.long 0xd41b0000                                           // 00000001BF34: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000001BF38: 020312FF C2CE8ED0
	v_fma_f32 v161, 0x3fb8aa3b, v137, -v139                    // 00000001BF40: D61300A1 862F12FF 3FB8AA3B
	v_rndne_f32_e32 v162, v139                                 // 00000001BF4C: 7F44478B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001BF50: BF870112
	v_fmac_f32_e32 v161, 0x32a5705f, v137                      // 00000001BF54: 574312FF 32A5705F
	v_sub_f32_e32 v139, v139, v162                             // 00000001BF5C: 0917458B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001BF60: BF870121
	v_add_f32_e32 v139, v139, v161                             // 00000001BF64: 0717438B
	v_cvt_i32_f32_e32 v161, v162                               // 00000001BF68: 7F4211A2
	v_exp_f32_e32 v139, v139                                   // 00000001BF6C: 7F164B8B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001BF70: BF870095
	.long 0xd71c008b                                           // 00000001BF74: D71C008B
	v_cndmask_b32_e32 v1, v139, v161, vcc_lo                   // 00000001BF78: 0203438B
	v_cndmask_b32_e64 v139, 0, v139, s0                        // 00000001BF7C: D501008B 00031680
	.long 0xd41e0000                                           // 00000001BF84: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000001BF88: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001BF90: BF870001
	v_cndmask_b32_e64 v249, 0x7f800000, v139, s0               // 00000001BF94: D50100F9 000316FF 7F800000
	s_branch 63722                                             // 00000001BFA0: BFA0F8EA <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x74c>
	scratch_load_b32 v143, off, off offset:196                 // 00000001BFA4: DC5100C4 8F7C0000
	v_lshlrev_b32_e32 v0, 2, v174                              // 00000001BFAC: 30015C82
	s_lshl_b64 s[0:1], s[26:27], 1                             // 00000001BFB0: 8480811A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001BFB4: BF8700A9
	s_add_u32 s2, s22, s0                                      // 00000001BFB8: 80020016
	s_addc_u32 s4, s23, s1                                     // 00000001BFBC: 82040117
	v_add_nc_u32_e32 v129, 0x2400, v0                          // 00000001BFC0: 4B0200FF 00002400
	s_lshl_b32 s0, s3, 9                                       // 00000001BFC8: 84008903
	ds_load_2addr_b32 v[137:138], v129 offset0:164 offset1:166 // 00000001BFCC: D8DCA6A4 89000081
	ds_load_2addr_b32 v[135:136], v129 offset0:168 offset1:170 // 00000001BFD4: D8DCAAA8 87000081
	ds_load_2addr_b32 v[133:134], v129 offset0:172 offset1:174 // 00000001BFDC: D8DCAEAC 85000081
	ds_load_2addr_b32 v[139:140], v129 offset0:160 offset1:162 // 00000001BFE4: D8DCA2A0 8B000081
	s_ashr_i32 s1, s0, 31                                      // 00000001BFEC: 86019F00
	s_waitcnt vmcnt(0)                                         // 00000001BFF0: BF8903F7
	.long 0xd7000281                                           // 00000001BFF4: D7000281
	v_cndmask_b32_e32 v1, s2, v143, vcc_lo                     // 00000001BFF8: 02031E02
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000001BFFC: 84808100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000001C000: BF870159
	s_add_u32 s0, s20, s0                                      // 00000001C004: 80000014
	s_addc_u32 s1, s21, s1                                     // 00000001C008: 82010115
	s_waitcnt lgkmcnt(0)                                       // 00000001C00C: BF89FC07
	v_div_scale_f32 v131, null, v139, v139, 1.0                // 00000001C010: D6FC7C83 03CB178B
	v_div_scale_f32 v141, vcc_lo, 1.0, v139, 1.0               // 00000001C018: D6FC6A8D 03CB16F2
	v_rcp_f32_e32 v132, v131                                   // 00000001C020: 7F085583
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C024: BF870095
	v_fma_f32 v0, -v131, v132, 1.0                             // 00000001C028: D6130000 23CB0983
	v_fmac_f32_e32 v132, v0, v132                              // 00000001C030: 57090900
	v_add_nc_u32_e32 v0, s28, v174                             // 00000001C034: 4A015C1C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C038: BF870092
	v_mul_f32_e32 v142, v141, v132                             // 00000001C03C: 111D098D
	v_fma_f32 v130, -v131, v142, v141                          // 00000001C040: D6130082 26371D83
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001C048: BF870121
	v_fmac_f32_e32 v142, v130, v132                            // 00000001C04C: 571D0982
	v_add_co_ci_u32_e64 v130, null, s4, 0, s2                  // 00000001C050: D5207C82 00090004
	v_fma_f32 v131, -v131, v142, v141                          // 00000001C058: D6130083 26371D83
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001C060: BF8700A1
	v_div_fmas_f32 v141, v131, v132, v142                      // 00000001C064: D637008D 063B0983
	.long 0xd7000083                                           // 00000001C06C: D7000083
	v_cndmask_b32_e32 v1, s0, v143, vcc_lo                     // 00000001C070: 02031E00
	v_add_co_ci_u32_e64 v132, null, s1, 0, s0                  // 00000001C074: D5207C84 00010001
	s_delay_alu instid0(VALU_DEP_3)                            // 00000001C07C: BF870003
	v_div_fixup_f32 v139, v141, v139, 1.0                      // 00000001C080: D627008B 03CB178D
	.long 0xd4440000                                           // 00000001C088: D4440000
	v_cndmask_b32_e32 v1, s24, v0, vcc_lo                      // 00000001C08C: 02020018
	s_and_saveexec_b32 s1, s0                                  // 00000001C090: BE812000
	s_cbranch_execz 69                                         // 00000001C094: BFA50045 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x25ac>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 00000001C098: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 00000001C0A4: 10F2F38B
	global_load_u16 v141, v[141:142], off offset:512           // 00000001C0A8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000001C0B0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000001C0B4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C0B8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000001C0BC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000001C0C4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000001C0D0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001C0D4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000001C0D8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000001C0DC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000001C0E4: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001C0EC: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000001C0F0: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000001C0F4: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000001C0F8: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C0FC: BF870095
	.long 0xd71c008e                                           // 00000001C100: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000001C104: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000001C108: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000001C10C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C114: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000001C118: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000001C120: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C124: BF870091
	v_div_scale_f32 v142, null, v141, v141, v121               // 00000001C128: D6FC7C8E 05E71B8D
	v_rcp_f32_e32 v143, v142                                   // 00000001C130: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C134: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000001C138: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000001C140: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v141, v121             // 00000001C144: D6FC6A90 05E71B79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C14C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000001C150: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000001C154: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C15C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000001C160: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000001C164: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C16C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000001C170: D637008E 06471F8E
	v_div_fixup_f32 v121, v142, v141, v121                     // 00000001C178: D6270079 05E71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 00000001C180: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C18C: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 00000001C190: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 00000001C198: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[141:142], v121, off              // 00000001C1A4: DC960000 007C798D
	s_or_b32 exec_lo, exec_lo, s1                              // 00000001C1AC: 8C7E017E
	v_div_scale_f32 v121, null, v140, v140, 1.0                // 00000001C1B0: D6FC7C79 03CB198C
	v_div_scale_f32 v143, vcc_lo, 1.0, v140, 1.0               // 00000001C1B8: D6FC6A8F 03CB18F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001C1C0: BF870292
	v_rcp_f32_e32 v141, v121                                   // 00000001C1C4: 7F1A5579
	v_fma_f32 v142, -v121, v141, 1.0                           // 00000001C1C8: D613008E 23CB1B79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C1D0: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000001C1D4: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000001C1D8: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C1DC: BF870091
	v_fma_f32 v144, -v121, v142, v143                          // 00000001C1E0: D6130090 263F1D79
	v_fmac_f32_e32 v142, v144, v141                            // 00000001C1E8: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C1EC: BF870091
	v_fma_f32 v121, -v121, v142, v143                          // 00000001C1F0: D6130079 263F1D79
	v_div_fmas_f32 v141, v121, v141, v142                      // 00000001C1F8: D637008D 063B1B79
	v_add_nc_u32_e32 v121, 2, v0                               // 00000001C200: 4AF20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001C204: BF870112
	v_div_fixup_f32 v140, v141, v140, 1.0                      // 00000001C208: D627008C 03CB198D
	.long 0xd4440001                                           // 00000001C210: D4440001
	v_cndmask_b32_e32 v1, s24, v121, vcc_lo                    // 00000001C214: 0202F218
	s_and_saveexec_b32 s2, s1                                  // 00000001C218: BE822001
	s_cbranch_execz 69                                         // 00000001C21C: BFA50045 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2734>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 00000001C220: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 00000001C22C: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 00000001C230: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000001C238: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000001C23C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C240: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000001C244: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000001C24C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000001C258: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001C25C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000001C260: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000001C264: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000001C26C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001C274: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000001C278: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000001C27C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000001C280: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C284: BF870095
	.long 0xd71c008e                                           // 00000001C288: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000001C28C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000001C290: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000001C294: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C29C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000001C2A0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000001C2A8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C2AC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 00000001C2B0: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000001C2B8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C2BC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000001C2C0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000001C2C8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 00000001C2CC: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C2D4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000001C2D8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000001C2DC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C2E4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000001C2E8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000001C2EC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C2F4: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000001C2F8: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 00000001C300: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 00000001C308: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C314: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 00000001C318: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 00000001C320: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 00000001C32C: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 00000001C334: 8C7E027E
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 00000001C338: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 00000001C340: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001C348: BF870292
	v_rcp_f32_e32 v141, v122                                   // 00000001C34C: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 00000001C350: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C358: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000001C35C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000001C360: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C364: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 00000001C368: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 00000001C370: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C374: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 00000001C378: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 00000001C380: D637008D 063B1B7A
	v_add_nc_u32_e32 v122, 4, v0                               // 00000001C388: 4AF40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001C38C: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 00000001C390: D6270089 03CB138D
	.long 0xd4440002                                           // 00000001C398: D4440002
	v_cndmask_b32_e32 v1, s24, v122, vcc_lo                    // 00000001C39C: 0202F418
	s_and_saveexec_b32 s3, s2                                  // 00000001C3A0: BE832002
	s_cbranch_execz 69                                         // 00000001C3A4: BFA50045 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x28bc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 00000001C3A8: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 00000001C3B4: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 00000001C3B8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000001C3C0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000001C3C4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C3C8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000001C3CC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000001C3D4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000001C3E0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001C3E4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000001C3E8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000001C3EC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000001C3F4: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001C3FC: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000001C400: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000001C404: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000001C408: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C40C: BF870095
	.long 0xd71c008e                                           // 00000001C410: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000001C414: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000001C418: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000001C41C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C424: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000001C428: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000001C430: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C434: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 00000001C438: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000001C440: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C444: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000001C448: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000001C450: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 00000001C454: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C45C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000001C460: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000001C464: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C46C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000001C470: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000001C474: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C47C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000001C480: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 00000001C488: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 00000001C490: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C49C: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 00000001C4A0: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 00000001C4A8: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 00000001C4B4: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 00000001C4BC: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 00000001C4C0: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 00000001C4C8: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001C4D0: BF870292
	v_rcp_f32_e32 v141, v123                                   // 00000001C4D4: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 00000001C4D8: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C4E0: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000001C4E4: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000001C4E8: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C4EC: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 00000001C4F0: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 00000001C4F8: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C4FC: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 00000001C500: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 00000001C508: D637008D 063B1B7B
	v_add_nc_u32_e32 v123, 6, v0                               // 00000001C510: 4AF60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001C514: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 00000001C518: D627008A 03CB158D
	.long 0xd4440003                                           // 00000001C520: D4440003
	v_cndmask_b32_e32 v1, s24, v123, vcc_lo                    // 00000001C524: 0202F618
	s_and_saveexec_b32 s4, s3                                  // 00000001C528: BE842003
	s_cbranch_execz 69                                         // 00000001C52C: BFA50045 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2a44>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 00000001C530: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 00000001C53C: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 00000001C540: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000001C548: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000001C54C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C550: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000001C554: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000001C55C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000001C568: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001C56C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000001C570: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000001C574: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000001C57C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001C584: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000001C588: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000001C58C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000001C590: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C594: BF870095
	.long 0xd71c008e                                           // 00000001C598: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000001C59C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000001C5A0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000001C5A4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C5AC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000001C5B0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000001C5B8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C5BC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 00000001C5C0: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 00000001C5C8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C5CC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000001C5D0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000001C5D8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 00000001C5DC: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C5E4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000001C5E8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000001C5EC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C5F4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000001C5F8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000001C5FC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C604: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000001C608: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 00000001C610: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 00000001C618: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C624: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 00000001C628: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 00000001C630: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 00000001C63C: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000001C644: 8C7E047E
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 00000001C648: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 00000001C650: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001C658: BF870292
	v_rcp_f32_e32 v141, v124                                   // 00000001C65C: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 00000001C660: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C668: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000001C66C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000001C670: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C674: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 00000001C678: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 00000001C680: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C684: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 00000001C688: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 00000001C690: D637008D 063B1B7C
	v_add_nc_u32_e32 v124, 8, v0                               // 00000001C698: 4AF80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001C69C: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 00000001C6A0: D6270087 03CB0F8D
	.long 0xd4440004                                           // 00000001C6A8: D4440004
	v_cndmask_b32_e32 v1, s24, v124, vcc_lo                    // 00000001C6AC: 0202F818
	s_and_saveexec_b32 s5, s4                                  // 00000001C6B0: BE852004
	s_cbranch_execz 69                                         // 00000001C6B4: BFA50045 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2bcc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 00000001C6B8: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 00000001C6C4: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 00000001C6C8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000001C6D0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000001C6D4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C6D8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000001C6DC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000001C6E4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000001C6F0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001C6F4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000001C6F8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000001C6FC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000001C704: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001C70C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000001C710: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000001C714: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000001C718: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C71C: BF870095
	.long 0xd71c008e                                           // 00000001C720: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000001C724: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000001C728: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000001C72C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C734: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000001C738: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000001C740: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C744: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 00000001C748: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 00000001C750: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C754: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000001C758: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000001C760: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 00000001C764: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C76C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000001C770: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000001C774: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C77C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000001C780: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000001C784: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C78C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000001C790: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 00000001C798: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 00000001C7A0: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C7AC: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 00000001C7B0: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 00000001C7B8: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 00000001C7C4: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 00000001C7CC: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 00000001C7D0: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 00000001C7D8: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001C7E0: BF870292
	v_rcp_f32_e32 v141, v125                                   // 00000001C7E4: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 00000001C7E8: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C7F0: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000001C7F4: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000001C7F8: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C7FC: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 00000001C800: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 00000001C808: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C80C: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 00000001C810: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 00000001C818: D637008D 063B1B7D
	v_add_nc_u32_e32 v125, 10, v0                              // 00000001C820: 4AFA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001C824: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 00000001C828: D6270088 03CB118D
	.long 0xd4440005                                           // 00000001C830: D4440005
	v_cndmask_b32_e32 v1, s24, v125, vcc_lo                    // 00000001C834: 0202FA18
	s_and_saveexec_b32 s6, s5                                  // 00000001C838: BE862005
	s_cbranch_execz 69                                         // 00000001C83C: BFA50045 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2d54>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 00000001C840: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 00000001C84C: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 00000001C850: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000001C858: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000001C85C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C860: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000001C864: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000001C86C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000001C878: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001C87C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000001C880: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000001C884: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000001C88C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001C894: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000001C898: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000001C89C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000001C8A0: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C8A4: BF870095
	.long 0xd71c008e                                           // 00000001C8A8: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000001C8AC: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000001C8B0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000001C8B4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C8BC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000001C8C0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000001C8C8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C8CC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 00000001C8D0: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000001C8D8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C8DC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000001C8E0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000001C8E8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 00000001C8EC: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C8F4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000001C8F8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000001C8FC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C904: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000001C908: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000001C90C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C914: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000001C918: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 00000001C920: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 00000001C928: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C934: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 00000001C938: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 00000001C940: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 00000001C94C: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 00000001C954: 8C7E067E
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 00000001C958: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 00000001C960: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001C968: BF870292
	v_rcp_f32_e32 v141, v126                                   // 00000001C96C: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 00000001C970: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C978: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000001C97C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000001C980: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C984: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 00000001C988: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 00000001C990: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C994: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 00000001C998: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 00000001C9A0: D637008D 063B1B7E
	v_add_nc_u32_e32 v126, 12, v0                              // 00000001C9A8: 4AFC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001C9AC: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 00000001C9B0: D6270085 03CB0B8D
	.long 0xd4440006                                           // 00000001C9B8: D4440006
	v_cndmask_b32_e32 v1, s24, v126, vcc_lo                    // 00000001C9BC: 0202FC18
	s_and_saveexec_b32 s7, s6                                  // 00000001C9C0: BE872006
	s_cbranch_execz 69                                         // 00000001C9C4: BFA50045 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2edc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 00000001C9C8: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 00000001C9D4: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 00000001C9D8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000001C9E0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000001C9E4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001C9E8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000001C9EC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000001C9F4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000001CA00: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001CA04: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000001CA08: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000001CA0C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000001CA14: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001CA1C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000001CA20: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000001CA24: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000001CA28: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001CA2C: BF870095
	.long 0xd71c008e                                           // 00000001CA30: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000001CA34: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000001CA38: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000001CA3C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001CA44: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000001CA48: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000001CA50: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001CA54: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 00000001CA58: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000001CA60: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001CA64: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000001CA68: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000001CA70: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 00000001CA74: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001CA7C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000001CA80: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000001CA84: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001CA8C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000001CA90: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000001CA94: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001CA9C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000001CAA0: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 00000001CAA8: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 00000001CAB0: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001CABC: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 00000001CAC0: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 00000001CAC8: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 00000001CAD4: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 00000001CADC: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 00000001CAE0: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 00000001CAE8: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001CAF0: BF870292
	v_rcp_f32_e32 v141, v127                                   // 00000001CAF4: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 00000001CAF8: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001CB00: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000001CB04: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000001CB08: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001CB0C: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 00000001CB10: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 00000001CB18: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001CB1C: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 00000001CB20: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 00000001CB28: D637008D 063B1B7F
	v_add_nc_u32_e32 v127, 14, v0                              // 00000001CB30: 4AFE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001CB34: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 00000001CB38: D6270086 03CB0D8D
	.long 0xd4440007                                           // 00000001CB40: D4440007
	v_cndmask_b32_e32 v1, s24, v127, vcc_lo                    // 00000001CB44: 0202FE18
	s_and_saveexec_b32 s8, s7                                  // 00000001CB48: BE882007
	s_cbranch_execnz 361                                       // 00000001CB4C: BFA60169 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x34f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CB50: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001CB54: BE882000
	s_cbranch_execnz 430                                       // 00000001CB58: BFA601AE <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3614>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CB5C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001CB60: BE882001
	s_cbranch_execnz 499                                       // 00000001CB64: BFA601F3 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3734>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CB68: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001CB6C: BE882002
	s_cbranch_execnz 568                                       // 00000001CB70: BFA60238 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3854>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CB74: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001CB78: BE882003
	s_cbranch_execnz 637                                       // 00000001CB7C: BFA6027D <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3974>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CB80: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001CB84: BE882004
	s_cbranch_execnz 706                                       // 00000001CB88: BFA602C2 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3a94>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CB8C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001CB90: BE882005
	s_cbranch_execnz 775                                       // 00000001CB94: BFA60307 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3bb4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CB98: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001CB9C: BE882006
	s_cbranch_execnz 844                                       // 00000001CBA0: BFA6034C <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3cd4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CBA4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001CBA8: BE882007
	s_cbranch_execnz 913                                       // 00000001CBAC: BFA60391 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3df4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CBB0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001CBB4: BE882000
	s_cbranch_execnz 982                                       // 00000001CBB8: BFA603D6 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3f14>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CBBC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001CBC0: BE882001
	s_cbranch_execnz 1051                                      // 00000001CBC4: BFA6041B <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x4034>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CBC8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001CBCC: BE882002
	s_cbranch_execnz 1120                                      // 00000001CBD0: BFA60460 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x4154>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CBD4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001CBD8: BE882003
	s_cbranch_execnz 1189                                      // 00000001CBDC: BFA604A5 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x4274>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CBE0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001CBE4: BE882004
	s_cbranch_execnz 1258                                      // 00000001CBE8: BFA604EA <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x4394>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CBEC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001CBF0: BE882005
	s_cbranch_execnz 1327                                      // 00000001CBF4: BFA6052F <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x44b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CBF8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001CBFC: BE882006
	s_cbranch_execnz 1396                                      // 00000001CC00: BFA60574 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x45d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CC04: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001CC08: BE882007
	s_cbranch_execnz 1465                                      // 00000001CC0C: BFA605B9 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x46f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CC10: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001CC14: BE882000
	s_cbranch_execnz 1534                                      // 00000001CC18: BFA605FE <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x4814>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CC1C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001CC20: BE882001
	s_cbranch_execnz 1603                                      // 00000001CC24: BFA60643 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x4934>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CC28: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001CC2C: BE882002
	s_cbranch_execnz 1672                                      // 00000001CC30: BFA60688 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x4a54>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CC34: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001CC38: BE882003
	s_cbranch_execnz 1741                                      // 00000001CC3C: BFA606CD <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x4b74>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CC40: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001CC44: BE882004
	s_cbranch_execnz 1810                                      // 00000001CC48: BFA60712 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x4c94>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CC4C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001CC50: BE882005
	s_cbranch_execnz 1879                                      // 00000001CC54: BFA60757 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x4db4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CC58: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001CC5C: BE882006
	s_cbranch_execnz 1948                                      // 00000001CC60: BFA6079C <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x4ed4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CC64: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001CC68: BE882007
	s_cbranch_execnz 2017                                      // 00000001CC6C: BFA607E1 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x4ff4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CC70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001CC74: BE882000
	s_cbranch_execnz 2086                                      // 00000001CC78: BFA60826 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x5114>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CC7C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001CC80: BE882001
	s_cbranch_execnz 2155                                      // 00000001CC84: BFA6086B <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x5234>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CC88: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001CC8C: BE882002
	s_cbranch_execnz 2224                                      // 00000001CC90: BFA608B0 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x5354>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CC94: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001CC98: BE882003
	s_cbranch_execnz 2293                                      // 00000001CC9C: BFA608F5 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x5474>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CCA0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001CCA4: BE882004
	s_cbranch_execnz 2362                                      // 00000001CCA8: BFA6093A <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x5594>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CCAC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001CCB0: BE882005
	s_cbranch_execnz 2431                                      // 00000001CCB4: BFA6097F <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x56b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CCB8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001CCBC: BE882006
	s_cbranch_execnz 2500                                      // 00000001CCC0: BFA609C4 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x57d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CCC4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001CCC8: BE882007
	s_cbranch_execnz 2569                                      // 00000001CCCC: BFA60A09 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x58f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CCD0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001CCD4: BE882000
	s_cbranch_execnz 2638                                      // 00000001CCD8: BFA60A4E <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x5a14>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CCDC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001CCE0: BE882001
	s_cbranch_execnz 2707                                      // 00000001CCE4: BFA60A93 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x5b34>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CCE8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001CCEC: BE882002
	s_cbranch_execnz 2776                                      // 00000001CCF0: BFA60AD8 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x5c54>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CCF4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001CCF8: BE882003
	s_cbranch_execnz 2845                                      // 00000001CCFC: BFA60B1D <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x5d74>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CD00: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001CD04: BE882004
	s_cbranch_execnz 2914                                      // 00000001CD08: BFA60B62 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x5e94>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CD0C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001CD10: BE882005
	s_cbranch_execnz 2983                                      // 00000001CD14: BFA60BA7 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x5fb4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CD18: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001CD1C: BE882006
	s_cbranch_execnz 3052                                      // 00000001CD20: BFA60BEC <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x60d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CD24: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001CD28: BE882007
	s_cbranch_execnz 3121                                      // 00000001CD2C: BFA60C31 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x61f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CD30: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001CD34: BE882000
	s_cbranch_execnz 3190                                      // 00000001CD38: BFA60C76 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x6314>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CD3C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001CD40: BE882001
	s_cbranch_execnz 3259                                      // 00000001CD44: BFA60CBB <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x6434>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CD48: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001CD4C: BE882002
	s_cbranch_execnz 3328                                      // 00000001CD50: BFA60D00 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x6554>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CD54: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001CD58: BE882003
	s_cbranch_execnz 3397                                      // 00000001CD5C: BFA60D45 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x6674>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CD60: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001CD64: BE882004
	s_cbranch_execnz 3466                                      // 00000001CD68: BFA60D8A <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x6794>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CD6C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001CD70: BE882005
	s_cbranch_execnz 3535                                      // 00000001CD74: BFA60DCF <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x68b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CD78: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001CD7C: BE882006
	s_cbranch_execnz 3604                                      // 00000001CD80: BFA60E14 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x69d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CD84: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001CD88: BE882007
	s_cbranch_execnz 3673                                      // 00000001CD8C: BFA60E59 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x6af4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CD90: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001CD94: BE882000
	s_cbranch_execnz 3742                                      // 00000001CD98: BFA60E9E <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x6c14>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CD9C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001CDA0: BE882001
	s_cbranch_execnz 3811                                      // 00000001CDA4: BFA60EE3 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x6d34>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CDA8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001CDAC: BE882002
	s_cbranch_execnz 3880                                      // 00000001CDB0: BFA60F28 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x6e54>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CDB4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001CDB8: BE882003
	s_cbranch_execnz 3949                                      // 00000001CDBC: BFA60F6D <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x6f74>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CDC0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001CDC4: BE882004
	s_cbranch_execnz 4018                                      // 00000001CDC8: BFA60FB2 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x7094>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CDCC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001CDD0: BE882005
	s_cbranch_execnz 4087                                      // 00000001CDD4: BFA60FF7 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x71b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CDD8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001CDDC: BE882006
	s_cbranch_execnz 4156                                      // 00000001CDE0: BFA6103C <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x72d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CDE4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001CDE8: BE882007
	s_cbranch_execnz 4225                                      // 00000001CDEC: BFA61081 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x73f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CDF0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001CDF4: BE882000
	s_cbranch_execnz 4294                                      // 00000001CDF8: BFA610C6 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x7514>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CDFC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001CE00: BE882001
	s_cbranch_execnz 4363                                      // 00000001CE04: BFA6110B <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x7634>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CE08: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001CE0C: BE882002
	s_cbranch_execnz 4432                                      // 00000001CE10: BFA61150 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x7754>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CE14: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001CE18: BE882003
	s_cbranch_execnz 4501                                      // 00000001CE1C: BFA61195 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x7874>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CE20: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001CE24: BE882004
	s_cbranch_execnz 4570                                      // 00000001CE28: BFA611DA <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x7994>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CE2C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001CE30: BE882005
	s_cbranch_execnz 4639                                      // 00000001CE34: BFA6121F <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x7ab4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CE38: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001CE3C: BE882006
	s_cbranch_execnz 4708                                      // 00000001CE40: BFA61264 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x7bd4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CE44: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001CE48: BE882007
	s_cbranch_execnz 4777                                      // 00000001CE4C: BFA612A9 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x7cf4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CE50: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001CE54: BE882000
	s_cbranch_execnz 4846                                      // 00000001CE58: BFA612EE <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x7e14>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CE5C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001CE60: BE882001
	s_cbranch_execnz 4915                                      // 00000001CE64: BFA61333 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x7f34>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CE68: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001CE6C: BE882002
	s_cbranch_execnz 4984                                      // 00000001CE70: BFA61378 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x8054>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CE74: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001CE78: BE882003
	s_cbranch_execnz 5053                                      // 00000001CE7C: BFA613BD <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x8174>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CE80: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001CE84: BE882004
	s_cbranch_execnz 5122                                      // 00000001CE88: BFA61402 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x8294>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CE8C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001CE90: BE882005
	s_cbranch_execnz 5191                                      // 00000001CE94: BFA61447 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x83b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CE98: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001CE9C: BE882006
	s_cbranch_execnz 5260                                      // 00000001CEA0: BFA6148C <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x84d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CEA4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001CEA8: BE882007
	s_cbranch_execnz 5329                                      // 00000001CEAC: BFA614D1 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x85f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CEB0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001CEB4: BE882000
	s_cbranch_execnz 5398                                      // 00000001CEB8: BFA61516 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x8714>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CEBC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001CEC0: BE882001
	s_cbranch_execnz 5467                                      // 00000001CEC4: BFA6155B <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x8834>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CEC8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001CECC: BE882002
	s_cbranch_execnz 5536                                      // 00000001CED0: BFA615A0 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x8954>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CED4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001CED8: BE882003
	s_cbranch_execnz 5605                                      // 00000001CEDC: BFA615E5 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x8a74>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CEE0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001CEE4: BE882004
	s_cbranch_execnz 5674                                      // 00000001CEE8: BFA6162A <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x8b94>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CEEC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001CEF0: BE882005
	s_cbranch_execnz 5743                                      // 00000001CEF4: BFA6166F <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x8cb4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CEF8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001CEFC: BE882006
	s_cbranch_execnz 5812                                      // 00000001CF00: BFA616B4 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x8dd4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CF04: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001CF08: BE882007
	s_cbranch_execnz 5881                                      // 00000001CF0C: BFA616F9 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x8ef4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CF10: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001CF14: BE882000
	s_cbranch_execnz 5950                                      // 00000001CF18: BFA6173E <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x9014>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CF1C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001CF20: BE882001
	s_cbranch_execnz 6019                                      // 00000001CF24: BFA61783 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x9134>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CF28: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001CF2C: BE882002
	s_cbranch_execnz 6088                                      // 00000001CF30: BFA617C8 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x9254>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CF34: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001CF38: BE882003
	s_cbranch_execnz 6157                                      // 00000001CF3C: BFA6180D <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x9374>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CF40: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001CF44: BE882004
	s_cbranch_execnz 6226                                      // 00000001CF48: BFA61852 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x9494>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CF4C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001CF50: BE882005
	s_cbranch_execnz 6295                                      // 00000001CF54: BFA61897 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x95b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CF58: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001CF5C: BE882006
	s_cbranch_execnz 6364                                      // 00000001CF60: BFA618DC <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x96d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CF64: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001CF68: BE882007
	s_cbranch_execnz 6433                                      // 00000001CF6C: BFA61921 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x97f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CF70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001CF74: BE882000
	s_cbranch_execnz 6502                                      // 00000001CF78: BFA61966 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x9914>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CF7C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001CF80: BE882001
	s_cbranch_execnz 6571                                      // 00000001CF84: BFA619AB <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x9a34>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CF88: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001CF8C: BE882002
	s_cbranch_execnz 6640                                      // 00000001CF90: BFA619F0 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x9b54>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CF94: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001CF98: BE882003
	s_cbranch_execnz 6709                                      // 00000001CF9C: BFA61A35 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x9c74>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CFA0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001CFA4: BE882004
	s_cbranch_execnz 6778                                      // 00000001CFA8: BFA61A7A <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x9d94>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CFAC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001CFB0: BE882005
	s_cbranch_execnz 6847                                      // 00000001CFB4: BFA61ABF <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x9eb4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CFB8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001CFBC: BE882006
	s_cbranch_execnz 6916                                      // 00000001CFC0: BFA61B04 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x9fd4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CFC4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001CFC8: BE882007
	s_cbranch_execnz 6985                                      // 00000001CFCC: BFA61B49 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xa0f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CFD0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001CFD4: BE882000
	s_cbranch_execnz 7054                                      // 00000001CFD8: BFA61B8E <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xa214>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CFDC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001CFE0: BE882001
	s_cbranch_execnz 7123                                      // 00000001CFE4: BFA61BD3 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xa334>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CFE8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001CFEC: BE882002
	s_cbranch_execnz 7192                                      // 00000001CFF0: BFA61C18 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xa454>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001CFF4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001CFF8: BE882003
	s_cbranch_execnz 7261                                      // 00000001CFFC: BFA61C5D <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xa574>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D000: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001D004: BE882004
	s_cbranch_execnz 7330                                      // 00000001D008: BFA61CA2 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xa694>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D00C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001D010: BE882005
	s_cbranch_execnz 7399                                      // 00000001D014: BFA61CE7 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xa7b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D018: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001D01C: BE882006
	s_cbranch_execnz 7468                                      // 00000001D020: BFA61D2C <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xa8d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D024: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001D028: BE882007
	s_cbranch_execnz 7537                                      // 00000001D02C: BFA61D71 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xa9f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D030: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001D034: BE882000
	s_cbranch_execnz 7606                                      // 00000001D038: BFA61DB6 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xab14>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D03C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001D040: BE882001
	s_cbranch_execnz 7675                                      // 00000001D044: BFA61DFB <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xac34>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D048: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001D04C: BE882002
	s_cbranch_execnz 7744                                      // 00000001D050: BFA61E40 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xad54>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D054: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001D058: BE882003
	s_cbranch_execnz 7813                                      // 00000001D05C: BFA61E85 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xae74>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D060: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001D064: BE882004
	s_cbranch_execnz 7882                                      // 00000001D068: BFA61ECA <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xaf94>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D06C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001D070: BE882005
	s_cbranch_execnz 7951                                      // 00000001D074: BFA61F0F <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xb0b4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D078: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001D07C: BE882006
	s_cbranch_execnz 8020                                      // 00000001D080: BFA61F54 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xb1d4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D084: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001D088: BE882007
	s_cbranch_execnz 8089                                      // 00000001D08C: BFA61F99 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xb2f4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D090: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001D094: BE882000
	s_cbranch_execnz 8158                                      // 00000001D098: BFA61FDE <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xb414>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D09C: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 00000001D0A0: BE802001
	s_cbranch_execnz 8227                                      // 00000001D0A4: BFA62023 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xb534>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001D0A8: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 00000001D0AC: BE802002
	s_cbranch_execnz 8296                                      // 00000001D0B0: BFA62068 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xb654>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001D0B4: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 00000001D0B8: BE802003
	s_cbranch_execnz 8365                                      // 00000001D0BC: BFA620AD <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xb774>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001D0C0: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000001D0C4: BE802004
	s_cbranch_execnz 8434                                      // 00000001D0C8: BFA620F2 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xb894>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001D0CC: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000001D0D0: BE802005
	s_cbranch_execnz 8503                                      // 00000001D0D4: BFA62137 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xb9b4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001D0D8: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000001D0DC: BE802006
	s_cbranch_execnz 8572                                      // 00000001D0E0: BFA6217C <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xbad4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000001D0E4: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000001D0E8: BE802007
	s_cbranch_execnz 8641                                      // 00000001D0EC: BFA621C1 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0xbbf4>
	s_endpgm                                                   // 00000001D0F0: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 00000001D0F4: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 00000001D100: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 00000001D104: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000001D10C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000001D110: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D114: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000001D118: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000001D120: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000001D12C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001D130: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000001D134: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000001D138: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000001D140: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D148: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000001D14C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000001D150: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000001D154: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D158: BF870095
	.long 0xd71c008e                                           // 00000001D15C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000001D160: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000001D164: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000001D168: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D170: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000001D174: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000001D17C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D180: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 00000001D184: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 00000001D18C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D190: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000001D194: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000001D19C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 00000001D1A0: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D1A8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000001D1AC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000001D1B0: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D1B8: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000001D1BC: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000001D1C0: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D1C8: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000001D1CC: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 00000001D1D4: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 00000001D1DC: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D1E8: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 00000001D1EC: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 00000001D1F4: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 00000001D200: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D208: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001D20C: BE882000
	s_cbranch_execz 65106                                      // 00000001D210: BFA5FE52 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2f5c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 00000001D214: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 00000001D220: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 00000001D224: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 00000001D22C: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 00000001D230: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D234: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 00000001D238: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 00000001D240: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 00000001D24C: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001D250: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 00000001D254: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 00000001D258: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 00000001D260: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D268: BF870121
	v_add_f32_e32 v141, v141, v142                             // 00000001D26C: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 00000001D270: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 00000001D274: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D278: BF870095
	.long 0xd71c008d                                           // 00000001D27C: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 00000001D280: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 00000001D284: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 00000001D288: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D290: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 00000001D294: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 00000001D29C: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D2A0: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 00000001D2A4: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 00000001D2AC: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D2B0: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 00000001D2B4: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 00000001D2BC: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 00000001D2C0: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D2C8: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 00000001D2CC: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 00000001D2D0: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D2D8: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 00000001D2DC: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 00000001D2E0: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D2E8: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 00000001D2EC: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 00000001D2F4: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 00000001D2FC: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D308: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 00000001D30C: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 00000001D314: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 00000001D320: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D328: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001D32C: BE882001
	s_cbranch_execz 65037                                      // 00000001D330: BFA5FE0D <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2f68>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 00000001D334: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 00000001D340: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 00000001D344: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 00000001D34C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000001D350: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D354: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 00000001D358: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 00000001D360: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 00000001D36C: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001D370: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 00000001D374: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000001D378: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 00000001D380: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D388: BF870121
	v_add_f32_e32 v128, v128, v141                             // 00000001D38C: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 00000001D390: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 00000001D394: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D398: BF870095
	.long 0xd71c0080                                           // 00000001D39C: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 00000001D3A0: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 00000001D3A4: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000001D3A8: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D3B0: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 00000001D3B4: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000001D3BC: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D3C0: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 00000001D3C4: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 00000001D3CC: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D3D0: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 00000001D3D4: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 00000001D3DC: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 00000001D3E0: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D3E8: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 00000001D3EC: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 00000001D3F0: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D3F8: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 00000001D3FC: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 00000001D400: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D408: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 00000001D40C: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 00000001D414: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 00000001D41C: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D428: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 00000001D42C: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 00000001D434: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 00000001D440: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D448: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001D44C: BE882002
	s_cbranch_execz 64968                                      // 00000001D450: BFA5FDC8 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2f74>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 00000001D454: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000001D460: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000001D468: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000001D46C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D470: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000001D474: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 00000001D47C: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 00000001D488: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001D48C: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 00000001D490: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 00000001D498: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000001D49C: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 00000001D4A0: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 00000001D4A4: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000001D4A8: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 00000001D4B0: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D4B4: BF870095
	.long 0xd71c0072                                           // 00000001D4B8: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 00000001D4BC: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000001D4C0: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000001D4C4: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D4CC: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 00000001D4D0: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000001D4DC: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D4E0: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000001D4E4: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 00000001D4EC: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D4F0: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 00000001D4F4: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 00000001D4FC: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 00000001D500: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D508: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 00000001D50C: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 00000001D510: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D518: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 00000001D51C: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 00000001D520: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D528: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 00000001D52C: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000001D534: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 00000001D53C: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D548: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 00000001D54C: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 00000001D554: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000001D560: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D568: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001D56C: BE882003
	s_cbranch_execz 64899                                      // 00000001D570: BFA5FD83 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2f80>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 00000001D574: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000001D580: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000001D588: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000001D58C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D590: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000001D594: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000001D59C: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 00000001D5A8: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001D5AC: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 00000001D5B0: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000001D5B4: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000001D5BC: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D5C4: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000001D5C8: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 00000001D5CC: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 00000001D5D0: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D5D4: BF870095
	.long 0xd71c0072                                           // 00000001D5D8: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000001D5DC: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000001D5E0: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000001D5E4: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D5EC: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 00000001D5F0: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000001D5FC: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D600: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000001D604: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000001D60C: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D610: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 00000001D614: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 00000001D61C: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 00000001D620: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D628: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 00000001D62C: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 00000001D630: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D638: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 00000001D63C: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 00000001D640: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D648: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 00000001D64C: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000001D654: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 00000001D65C: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D668: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000001D66C: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000001D674: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000001D680: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D688: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001D68C: BE882004
	s_cbranch_execz 64830                                      // 00000001D690: BFA5FD3E <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2f8c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 00000001D694: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000001D6A0: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000001D6A8: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000001D6AC: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D6B0: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000001D6B4: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000001D6BC: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000001D6C8: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001D6CC: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000001D6D0: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000001D6D4: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000001D6DC: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D6E4: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000001D6E8: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000001D6EC: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000001D6F0: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D6F4: BF870095
	.long 0xd71c0072                                           // 00000001D6F8: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000001D6FC: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000001D700: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000001D704: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D70C: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 00000001D710: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000001D71C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D720: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000001D724: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000001D72C: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D730: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000001D734: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000001D73C: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000001D740: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D748: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 00000001D74C: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 00000001D750: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D758: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 00000001D75C: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 00000001D760: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D768: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 00000001D76C: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000001D774: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 00000001D77C: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D788: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000001D78C: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000001D794: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000001D7A0: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D7A8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001D7AC: BE882005
	s_cbranch_execz 64761                                      // 00000001D7B0: BFA5FCF9 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2f98>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 00000001D7B4: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000001D7C0: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000001D7C8: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000001D7CC: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D7D0: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000001D7D4: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000001D7DC: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000001D7E8: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001D7EC: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000001D7F0: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000001D7F4: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000001D7FC: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D804: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000001D808: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000001D80C: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000001D810: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D814: BF870095
	.long 0xd71c0072                                           // 00000001D818: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000001D81C: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000001D820: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000001D824: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D82C: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 00000001D830: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 00000001D838: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D840: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000001D844: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000001D84C: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D850: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000001D854: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000001D85C: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000001D860: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D868: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 00000001D86C: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 00000001D870: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D878: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 00000001D87C: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 00000001D880: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D888: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 00000001D88C: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000001D894: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 00000001D89C: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D8A8: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000001D8AC: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000001D8B4: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000001D8C0: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D8C8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001D8CC: BE882006
	s_cbranch_execz 64692                                      // 00000001D8D0: BFA5FCB4 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2fa4>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 00000001D8D4: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000001D8E0: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000001D8E8: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000001D8EC: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D8F0: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000001D8F4: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000001D8FC: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000001D908: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001D90C: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000001D910: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000001D914: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000001D91C: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001D924: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000001D928: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000001D92C: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000001D930: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D934: BF870095
	.long 0xd71c0072                                           // 00000001D938: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000001D93C: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000001D940: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000001D944: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D94C: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 00000001D950: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000001D95C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D960: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000001D964: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000001D96C: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D970: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000001D974: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000001D97C: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000001D980: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D988: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 00000001D98C: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 00000001D990: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D998: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 00000001D99C: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 00000001D9A0: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D9A8: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 00000001D9AC: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000001D9B4: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 00000001D9BC: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001D9C8: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000001D9CC: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000001D9D4: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000001D9E0: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001D9E8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001D9EC: BE882007
	s_cbranch_execz 64623                                      // 00000001D9F0: BFA5FC6F <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2fb0>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 00000001D9F4: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000001DA00: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000001DA08: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000001DA0C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DA10: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000001DA14: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000001DA1C: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000001DA28: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001DA2C: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000001DA30: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000001DA34: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000001DA3C: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DA44: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000001DA48: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000001DA4C: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000001DA50: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DA54: BF870095
	.long 0xd71c0072                                           // 00000001DA58: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000001DA5C: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000001DA60: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000001DA64: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DA6C: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 00000001DA70: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000001DA7C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DA80: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000001DA84: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000001DA8C: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DA90: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000001DA94: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000001DA9C: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000001DAA0: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DAA8: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 00000001DAAC: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 00000001DAB0: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DAB8: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 00000001DABC: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 00000001DAC0: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DAC8: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 00000001DACC: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000001DAD4: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 00000001DADC: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DAE8: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000001DAEC: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000001DAF4: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000001DB00: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001DB08: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001DB0C: BE882000
	s_cbranch_execz 64554                                      // 00000001DB10: BFA5FC2A <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2fbc>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 00000001DB14: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 00000001DB20: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 00000001DB24: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 00000001DB2C: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000001DB30: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DB34: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000001DB38: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000001DB40: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000001DB4C: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001DB50: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000001DB54: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000001DB58: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000001DB60: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DB68: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000001DB6C: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000001DB70: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000001DB74: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DB78: BF870095
	.long 0xd71c0072                                           // 00000001DB7C: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000001DB80: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000001DB84: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000001DB88: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DB90: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 00000001DB94: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000001DB9C: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DBA0: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 00000001DBA4: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 00000001DBAC: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DBB0: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 00000001DBB4: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 00000001DBBC: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 00000001DBC0: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DBC8: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 00000001DBCC: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 00000001DBD0: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DBD8: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 00000001DBDC: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 00000001DBE0: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DBE8: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 00000001DBEC: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 00000001DBF4: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 00000001DBFC: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DC08: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 00000001DC0C: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 00000001DC14: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 00000001DC20: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001DC28: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001DC2C: BE882001
	s_cbranch_execz 64485                                      // 00000001DC30: BFA5FBE5 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2fc8>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 00000001DC34: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 00000001DC40: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 00000001DC44: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 00000001DC4C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000001DC50: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DC54: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 00000001DC58: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000001DC60: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 00000001DC68: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 00000001DC74: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001DC78: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 00000001DC7C: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 00000001DC84: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DC88: BF870121
	v_add_f32_e32 v113, v113, v114                             // 00000001DC8C: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 00000001DC90: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 00000001DC94: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DC98: BF870095
	.long 0xd71c0071                                           // 00000001DC9C: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 00000001DCA0: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 00000001DCA4: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000001DCA8: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DCB0: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 00000001DCB4: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000001DCBC: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DCC0: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 00000001DCC4: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 00000001DCCC: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DCD0: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 00000001DCD4: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 00000001DCDC: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 00000001DCE0: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DCE8: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 00000001DCEC: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 00000001DCF0: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DCF8: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 00000001DCFC: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 00000001DD00: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DD08: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 00000001DD0C: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 00000001DD14: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 00000001DD1C: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DD28: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 00000001DD2C: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 00000001DD34: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 00000001DD40: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001DD48: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001DD4C: BE882002
	s_cbranch_execz 64416                                      // 00000001DD50: BFA5FBA0 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2fd4>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 00000001DD54: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000001DD60: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000001DD68: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000001DD6C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DD70: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000001DD74: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 00000001DD7C: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 00000001DD88: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001DD8C: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 00000001DD90: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000001DD94: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 00000001DD9C: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DDA4: BF870121
	v_add_f32_e32 v106, v106, v113                             // 00000001DDA8: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 00000001DDAC: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 00000001DDB0: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DDB4: BF870095
	.long 0xd71c006a                                           // 00000001DDB8: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 00000001DDBC: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000001DDC0: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000001DDC4: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DDCC: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 00000001DDD0: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000001DDDC: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DDE0: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000001DDE4: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 00000001DDEC: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DDF0: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 00000001DDF4: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 00000001DDFC: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 00000001DE00: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DE08: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 00000001DE0C: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 00000001DE10: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DE18: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 00000001DE1C: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 00000001DE20: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DE28: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 00000001DE2C: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000001DE34: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 00000001DE3C: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DE48: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 00000001DE4C: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 00000001DE54: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000001DE60: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001DE68: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001DE6C: BE882003
	s_cbranch_execz 64347                                      // 00000001DE70: BFA5FB5B <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2fe0>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 00000001DE74: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000001DE80: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000001DE88: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000001DE8C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DE90: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000001DE94: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000001DE9C: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 00000001DEA8: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DEAC: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 00000001DEB0: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 00000001DEBC: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 00000001DEC0: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000001DEC4: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001DECC: BF870293
	v_exp_f32_e32 v106, v106                                   // 00000001DED0: 7ED44B6A
	.long 0xd71c006a                                           // 00000001DED4: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000001DED8: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DEDC: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000001DEE0: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000001DEE4: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 00000001DEEC: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DEF8: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 00000001DEFC: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000001DF00: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001DF08: BF870291
	v_rcp_f32_e32 v108, v107                                   // 00000001DF0C: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 00000001DF10: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001DF18: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 00000001DF1C: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 00000001DF20: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 00000001DF28: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DF2C: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 00000001DF30: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 00000001DF38: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DF3C: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 00000001DF40: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 00000001DF48: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DF50: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000001DF54: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 00000001DF5C: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 00000001DF68: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001DF70: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000001DF74: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000001DF80: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001DF88: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001DF8C: BE882004
	s_cbranch_execz 64278                                      // 00000001DF90: BFA5FB16 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2fec>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 00000001DF94: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000001DFA0: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000001DFA8: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000001DFAC: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DFB0: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000001DFB4: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000001DFBC: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000001DFC8: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001DFCC: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000001DFD0: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000001DFD4: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000001DFDC: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001DFE4: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000001DFE8: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000001DFEC: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000001DFF0: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001DFF4: BF870095
	.long 0xd71c006a                                           // 00000001DFF8: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000001DFFC: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000001E000: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000001E004: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E00C: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 00000001E010: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000001E01C: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E020: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000001E024: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000001E02C: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E030: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000001E034: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000001E03C: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000001E040: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E048: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 00000001E04C: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 00000001E050: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E058: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 00000001E05C: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 00000001E060: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E068: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 00000001E06C: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000001E074: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 00000001E07C: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E088: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000001E08C: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000001E094: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000001E0A0: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001E0A8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001E0AC: BE882005
	s_cbranch_execz 64209                                      // 00000001E0B0: BFA5FAD1 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x2ff8>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 00000001E0B4: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000001E0C0: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000001E0C8: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000001E0CC: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E0D0: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000001E0D4: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000001E0DC: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000001E0E8: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001E0EC: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000001E0F0: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000001E0F4: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000001E0FC: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E104: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000001E108: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000001E10C: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000001E110: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E114: BF870095
	.long 0xd71c006a                                           // 00000001E118: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000001E11C: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000001E120: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000001E124: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E12C: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 00000001E130: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 00000001E138: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E140: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000001E144: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000001E14C: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E150: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000001E154: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000001E15C: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000001E160: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E168: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 00000001E16C: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 00000001E170: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E178: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 00000001E17C: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 00000001E180: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E188: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 00000001E18C: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000001E194: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 00000001E19C: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E1A8: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000001E1AC: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000001E1B4: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000001E1C0: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001E1C8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001E1CC: BE882006
	s_cbranch_execz 64140                                      // 00000001E1D0: BFA5FA8C <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3004>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 00000001E1D4: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000001E1E0: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000001E1E8: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000001E1EC: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E1F0: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000001E1F4: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000001E1FC: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000001E208: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001E20C: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000001E210: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000001E214: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000001E21C: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E224: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000001E228: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000001E22C: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000001E230: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E234: BF870095
	.long 0xd71c006a                                           // 00000001E238: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000001E23C: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000001E240: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000001E244: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E24C: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 00000001E250: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000001E25C: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E260: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000001E264: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000001E26C: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E270: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000001E274: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000001E27C: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000001E280: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E288: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 00000001E28C: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 00000001E290: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E298: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 00000001E29C: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 00000001E2A0: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E2A8: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 00000001E2AC: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000001E2B4: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 00000001E2BC: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E2C8: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000001E2CC: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000001E2D4: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000001E2E0: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001E2E8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001E2EC: BE882007
	s_cbranch_execz 64071                                      // 00000001E2F0: BFA5FA47 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3010>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 00000001E2F4: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000001E300: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000001E308: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000001E30C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E310: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000001E314: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000001E31C: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000001E328: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001E32C: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000001E330: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000001E334: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000001E33C: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E344: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000001E348: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000001E34C: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000001E350: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E354: BF870095
	.long 0xd71c006a                                           // 00000001E358: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000001E35C: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000001E360: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000001E364: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E36C: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 00000001E370: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000001E37C: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E380: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000001E384: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000001E38C: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E390: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000001E394: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000001E39C: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000001E3A0: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E3A8: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 00000001E3AC: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 00000001E3B0: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E3B8: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 00000001E3BC: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 00000001E3C0: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E3C8: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 00000001E3CC: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000001E3D4: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 00000001E3DC: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E3E8: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000001E3EC: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000001E3F4: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000001E400: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001E408: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001E40C: BE882000
	s_cbranch_execz 64002                                      // 00000001E410: BFA5FA02 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x301c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 00000001E414: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 00000001E420: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 00000001E424: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 00000001E42C: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000001E430: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E434: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000001E438: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000001E440: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000001E44C: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001E450: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000001E454: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000001E458: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000001E460: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E468: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000001E46C: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000001E470: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000001E474: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E478: BF870095
	.long 0xd71c006a                                           // 00000001E47C: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000001E480: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000001E484: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000001E488: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E490: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 00000001E494: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000001E49C: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E4A0: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 00000001E4A4: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 00000001E4AC: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E4B0: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 00000001E4B4: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 00000001E4BC: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 00000001E4C0: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E4C8: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 00000001E4CC: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 00000001E4D0: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E4D8: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 00000001E4DC: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 00000001E4E0: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E4E8: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 00000001E4EC: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 00000001E4F4: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 00000001E4FC: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E508: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 00000001E50C: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 00000001E514: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 00000001E520: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001E528: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001E52C: BE882001
	s_cbranch_execz 63933                                      // 00000001E530: BFA5F9BD <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3028>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 00000001E534: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 00000001E540: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 00000001E544: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 00000001E54C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000001E550: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E554: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 00000001E558: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000001E560: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 00000001E568: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 00000001E574: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001E578: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 00000001E57C: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 00000001E584: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E588: BF870121
	v_add_f32_e32 v105, v105, v106                             // 00000001E58C: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 00000001E590: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 00000001E594: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E598: BF870095
	.long 0xd71c0069                                           // 00000001E59C: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 00000001E5A0: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 00000001E5A4: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000001E5A8: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E5B0: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 00000001E5B4: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000001E5BC: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E5C0: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 00000001E5C4: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 00000001E5CC: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E5D0: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 00000001E5D4: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 00000001E5DC: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 00000001E5E0: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E5E8: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 00000001E5EC: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 00000001E5F0: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E5F8: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 00000001E5FC: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 00000001E600: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E608: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 00000001E60C: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 00000001E614: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 00000001E61C: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E628: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 00000001E62C: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 00000001E634: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 00000001E640: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001E648: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001E64C: BE882002
	s_cbranch_execz 63864                                      // 00000001E650: BFA5F978 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3034>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 00000001E654: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000001E660: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000001E668: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000001E66C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E670: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000001E674: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 00000001E67C: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 00000001E688: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001E68C: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 00000001E690: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000001E694: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 00000001E69C: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E6A4: BF870121
	v_add_f32_e32 v98, v98, v105                               // 00000001E6A8: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 00000001E6AC: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 00000001E6B0: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E6B4: BF870095
	.long 0xd71c0062                                           // 00000001E6B8: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 00000001E6BC: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000001E6C0: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000001E6C4: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E6CC: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 00000001E6D0: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000001E6DC: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E6E0: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000001E6E4: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 00000001E6EC: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E6F0: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 00000001E6F4: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 00000001E6FC: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 00000001E700: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E708: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 00000001E70C: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 00000001E710: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E718: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 00000001E71C: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 00000001E720: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E728: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 00000001E72C: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000001E734: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 00000001E73C: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E748: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 00000001E74C: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 00000001E754: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000001E760: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001E768: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001E76C: BE882003
	s_cbranch_execz 63795                                      // 00000001E770: BFA5F933 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3040>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 00000001E774: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000001E780: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000001E788: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000001E78C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E790: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000001E794: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000001E79C: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 00000001E7A8: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E7AC: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 00000001E7B0: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 00000001E7BC: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 00000001E7C0: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000001E7C4: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001E7CC: BF870293
	v_exp_f32_e32 v98, v98                                     // 00000001E7D0: 7EC44B62
	.long 0xd71c0062                                           // 00000001E7D4: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000001E7D8: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E7DC: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000001E7E0: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000001E7E4: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 00000001E7EC: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E7F8: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 00000001E7FC: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000001E800: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001E808: BF870291
	v_rcp_f32_e32 v100, v99                                    // 00000001E80C: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 00000001E810: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001E818: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 00000001E81C: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 00000001E820: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 00000001E828: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E82C: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 00000001E830: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 00000001E838: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E83C: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 00000001E840: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 00000001E848: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E850: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000001E854: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 00000001E85C: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 00000001E868: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001E870: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000001E874: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000001E880: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001E888: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001E88C: BE882004
	s_cbranch_execz 63726                                      // 00000001E890: BFA5F8EE <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x304c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 00000001E894: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000001E8A0: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000001E8A8: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000001E8AC: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E8B0: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000001E8B4: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000001E8BC: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000001E8C8: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001E8CC: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000001E8D0: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000001E8D4: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000001E8DC: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001E8E4: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000001E8E8: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000001E8EC: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000001E8F0: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E8F4: BF870095
	.long 0xd71c0062                                           // 00000001E8F8: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000001E8FC: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000001E900: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000001E904: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E90C: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 00000001E910: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000001E91C: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E920: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000001E924: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 00000001E92C: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E930: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000001E934: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 00000001E93C: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000001E940: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E948: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 00000001E94C: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 00000001E950: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E958: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 00000001E95C: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 00000001E960: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E968: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 00000001E96C: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000001E974: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 00000001E97C: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E988: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 00000001E98C: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000001E994: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000001E9A0: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001E9A8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001E9AC: BE882005
	s_cbranch_execz 63657                                      // 00000001E9B0: BFA5F8A9 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3058>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 00000001E9B4: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000001E9C0: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000001E9C8: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000001E9CC: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001E9D0: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000001E9D4: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000001E9DC: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000001E9E8: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001E9EC: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000001E9F0: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000001E9F4: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000001E9FC: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001EA04: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000001EA08: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000001EA0C: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000001EA10: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EA14: BF870095
	.long 0xd71c0062                                           // 00000001EA18: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000001EA1C: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000001EA20: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000001EA24: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EA2C: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 00000001EA30: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 00000001EA38: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EA40: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000001EA44: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 00000001EA4C: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EA50: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000001EA54: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 00000001EA5C: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000001EA60: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EA68: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 00000001EA6C: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 00000001EA70: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EA78: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 00000001EA7C: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 00000001EA80: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EA88: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 00000001EA8C: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000001EA94: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 00000001EA9C: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EAA8: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 00000001EAAC: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000001EAB4: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000001EAC0: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001EAC8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001EACC: BE882006
	s_cbranch_execz 63588                                      // 00000001EAD0: BFA5F864 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3064>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 00000001EAD4: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000001EAE0: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000001EAE8: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000001EAEC: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EAF0: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000001EAF4: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000001EAFC: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000001EB08: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001EB0C: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000001EB10: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000001EB14: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000001EB1C: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001EB24: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000001EB28: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000001EB2C: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000001EB30: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EB34: BF870095
	.long 0xd71c0062                                           // 00000001EB38: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000001EB3C: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000001EB40: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000001EB44: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EB4C: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 00000001EB50: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000001EB5C: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EB60: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000001EB64: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 00000001EB6C: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EB70: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000001EB74: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 00000001EB7C: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000001EB80: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EB88: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 00000001EB8C: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 00000001EB90: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EB98: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 00000001EB9C: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 00000001EBA0: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EBA8: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 00000001EBAC: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000001EBB4: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 00000001EBBC: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EBC8: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 00000001EBCC: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000001EBD4: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000001EBE0: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001EBE8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001EBEC: BE882007
	s_cbranch_execz 63519                                      // 00000001EBF0: BFA5F81F <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3070>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 00000001EBF4: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000001EC00: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000001EC08: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000001EC0C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EC10: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000001EC14: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000001EC1C: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000001EC28: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001EC2C: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000001EC30: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000001EC34: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000001EC3C: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001EC44: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000001EC48: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000001EC4C: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000001EC50: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EC54: BF870095
	.long 0xd71c0062                                           // 00000001EC58: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000001EC5C: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000001EC60: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000001EC64: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EC6C: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 00000001EC70: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000001EC7C: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EC80: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000001EC84: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 00000001EC8C: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EC90: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000001EC94: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 00000001EC9C: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000001ECA0: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001ECA8: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 00000001ECAC: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 00000001ECB0: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001ECB8: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 00000001ECBC: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 00000001ECC0: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001ECC8: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 00000001ECCC: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000001ECD4: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 00000001ECDC: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001ECE8: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 00000001ECEC: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000001ECF4: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000001ED00: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001ED08: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001ED0C: BE882000
	s_cbranch_execz 63450                                      // 00000001ED10: BFA5F7DA <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x307c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 00000001ED14: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 00000001ED20: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 00000001ED24: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 00000001ED2C: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000001ED30: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001ED34: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000001ED38: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000001ED40: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000001ED4C: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001ED50: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000001ED54: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000001ED58: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000001ED60: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001ED68: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000001ED6C: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000001ED70: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000001ED74: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001ED78: BF870095
	.long 0xd71c0062                                           // 00000001ED7C: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000001ED80: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000001ED84: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000001ED88: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001ED90: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 00000001ED94: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000001ED9C: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EDA0: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 00000001EDA4: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 00000001EDAC: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EDB0: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 00000001EDB4: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 00000001EDBC: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 00000001EDC0: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EDC8: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 00000001EDCC: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 00000001EDD0: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EDD8: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 00000001EDDC: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 00000001EDE0: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EDE8: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 00000001EDEC: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 00000001EDF4: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 00000001EDFC: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EE08: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 00000001EE0C: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 00000001EE14: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 00000001EE20: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001EE28: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001EE2C: BE882001
	s_cbranch_execz 63381                                      // 00000001EE30: BFA5F795 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3088>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 00000001EE34: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 00000001EE40: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 00000001EE44: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 00000001EE4C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000001EE50: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001EE54: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 00000001EE58: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000001EE60: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 00000001EE68: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 00000001EE74: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001EE78: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 00000001EE7C: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 00000001EE84: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001EE88: BF870121
	v_add_f32_e32 v97, v97, v98                                // 00000001EE8C: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 00000001EE90: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 00000001EE94: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EE98: BF870095
	.long 0xd71c0061                                           // 00000001EE9C: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 00000001EEA0: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 00000001EEA4: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000001EEA8: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EEB0: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 00000001EEB4: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000001EEBC: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EEC0: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 00000001EEC4: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 00000001EECC: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EED0: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 00000001EED4: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 00000001EEDC: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 00000001EEE0: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EEE8: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 00000001EEEC: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 00000001EEF0: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EEF8: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 00000001EEFC: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 00000001EF00: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EF08: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 00000001EF0C: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 00000001EF14: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 00000001EF1C: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EF28: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 00000001EF2C: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 00000001EF34: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 00000001EF40: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001EF48: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001EF4C: BE882002
	s_cbranch_execz 63312                                      // 00000001EF50: BFA5F750 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3094>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 00000001EF54: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000001EF60: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000001EF68: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000001EF6C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EF70: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000001EF74: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 00000001EF7C: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 00000001EF88: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001EF8C: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 00000001EF90: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000001EF94: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 00000001EF9C: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001EFA4: BF870121
	v_add_f32_e32 v90, v90, v97                                // 00000001EFA8: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 00000001EFAC: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 00000001EFB0: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EFB4: BF870095
	.long 0xd71c005a                                           // 00000001EFB8: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 00000001EFBC: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000001EFC0: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000001EFC4: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EFCC: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 00000001EFD0: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000001EFDC: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EFE0: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000001EFE4: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 00000001EFEC: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001EFF0: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 00000001EFF4: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 00000001EFFC: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 00000001F000: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F008: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 00000001F00C: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 00000001F010: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F018: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 00000001F01C: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 00000001F020: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F028: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 00000001F02C: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000001F034: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 00000001F03C: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F048: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 00000001F04C: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 00000001F054: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000001F060: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001F068: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001F06C: BE882003
	s_cbranch_execz 63243                                      // 00000001F070: BFA5F70B <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x30a0>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 00000001F074: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000001F080: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000001F088: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000001F08C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F090: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000001F094: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000001F09C: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 00000001F0A8: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F0AC: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 00000001F0B0: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 00000001F0BC: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 00000001F0C0: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000001F0C4: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001F0CC: BF870293
	v_exp_f32_e32 v90, v90                                     // 00000001F0D0: 7EB44B5A
	.long 0xd71c005a                                           // 00000001F0D4: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000001F0D8: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001F0DC: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000001F0E0: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000001F0E4: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 00000001F0EC: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F0F8: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 00000001F0FC: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000001F100: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001F108: BF870291
	v_rcp_f32_e32 v92, v91                                     // 00000001F10C: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 00000001F110: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001F118: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 00000001F11C: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 00000001F120: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 00000001F128: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F12C: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 00000001F130: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 00000001F138: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F13C: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 00000001F140: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 00000001F148: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001F150: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000001F154: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 00000001F15C: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 00000001F168: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001F170: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000001F174: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000001F180: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001F188: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001F18C: BE882004
	s_cbranch_execz 63174                                      // 00000001F190: BFA5F6C6 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x30ac>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 00000001F194: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000001F1A0: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000001F1A8: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000001F1AC: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F1B0: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000001F1B4: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000001F1BC: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000001F1C8: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001F1CC: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000001F1D0: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000001F1D4: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000001F1DC: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001F1E4: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000001F1E8: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000001F1EC: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000001F1F0: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F1F4: BF870095
	.long 0xd71c005a                                           // 00000001F1F8: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000001F1FC: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000001F200: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000001F204: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F20C: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 00000001F210: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000001F21C: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F220: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000001F224: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000001F22C: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F230: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000001F234: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000001F23C: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 00000001F240: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F248: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 00000001F24C: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 00000001F250: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F258: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 00000001F25C: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 00000001F260: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F268: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 00000001F26C: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000001F274: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 00000001F27C: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F288: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000001F28C: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000001F294: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000001F2A0: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001F2A8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001F2AC: BE882005
	s_cbranch_execz 63105                                      // 00000001F2B0: BFA5F681 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x30b8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 00000001F2B4: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000001F2C0: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000001F2C8: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000001F2CC: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F2D0: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000001F2D4: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000001F2DC: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000001F2E8: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001F2EC: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000001F2F0: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000001F2F4: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000001F2FC: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001F304: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000001F308: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000001F30C: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000001F310: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F314: BF870095
	.long 0xd71c005a                                           // 00000001F318: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000001F31C: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000001F320: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000001F324: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F32C: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 00000001F330: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 00000001F338: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F340: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000001F344: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000001F34C: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F350: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000001F354: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000001F35C: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 00000001F360: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F368: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 00000001F36C: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 00000001F370: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F378: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 00000001F37C: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 00000001F380: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F388: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 00000001F38C: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000001F394: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 00000001F39C: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F3A8: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000001F3AC: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000001F3B4: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000001F3C0: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001F3C8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001F3CC: BE882006
	s_cbranch_execz 63036                                      // 00000001F3D0: BFA5F63C <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x30c4>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 00000001F3D4: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000001F3E0: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000001F3E8: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000001F3EC: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F3F0: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000001F3F4: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000001F3FC: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000001F408: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001F40C: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000001F410: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000001F414: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000001F41C: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001F424: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000001F428: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000001F42C: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000001F430: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F434: BF870095
	.long 0xd71c005a                                           // 00000001F438: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000001F43C: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000001F440: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000001F444: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F44C: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 00000001F450: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000001F45C: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F460: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000001F464: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000001F46C: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F470: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000001F474: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000001F47C: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 00000001F480: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F488: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 00000001F48C: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 00000001F490: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F498: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 00000001F49C: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 00000001F4A0: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F4A8: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 00000001F4AC: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000001F4B4: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 00000001F4BC: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F4C8: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000001F4CC: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000001F4D4: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000001F4E0: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001F4E8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001F4EC: BE882007
	s_cbranch_execz 62967                                      // 00000001F4F0: BFA5F5F7 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x30d0>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 00000001F4F4: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000001F500: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000001F508: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000001F50C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F510: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000001F514: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000001F51C: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000001F528: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001F52C: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000001F530: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000001F534: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000001F53C: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001F544: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000001F548: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000001F54C: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000001F550: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F554: BF870095
	.long 0xd71c005a                                           // 00000001F558: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000001F55C: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000001F560: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000001F564: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F56C: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 00000001F570: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000001F57C: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F580: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000001F584: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000001F58C: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F590: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000001F594: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000001F59C: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 00000001F5A0: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F5A8: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 00000001F5AC: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 00000001F5B0: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F5B8: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 00000001F5BC: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 00000001F5C0: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F5C8: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 00000001F5CC: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000001F5D4: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 00000001F5DC: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F5E8: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000001F5EC: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000001F5F4: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000001F600: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001F608: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001F60C: BE882000
	s_cbranch_execz 62898                                      // 00000001F610: BFA5F5B2 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x30dc>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 00000001F614: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 00000001F620: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 00000001F624: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 00000001F62C: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000001F630: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F634: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000001F638: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000001F640: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000001F64C: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001F650: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000001F654: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000001F658: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000001F660: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001F668: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000001F66C: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000001F670: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000001F674: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F678: BF870095
	.long 0xd71c005a                                           // 00000001F67C: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000001F680: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000001F684: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000001F688: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F690: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 00000001F694: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000001F69C: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F6A0: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 00000001F6A4: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 00000001F6AC: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F6B0: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 00000001F6B4: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 00000001F6BC: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 00000001F6C0: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F6C8: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 00000001F6CC: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 00000001F6D0: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F6D8: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 00000001F6DC: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 00000001F6E0: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F6E8: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 00000001F6EC: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 00000001F6F4: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 00000001F6FC: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F708: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 00000001F70C: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 00000001F714: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 00000001F720: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001F728: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000001F72C: BE882001
	s_cbranch_execz 62829                                      // 00000001F730: BFA5F56D <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x30e8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 00000001F734: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 00000001F740: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 00000001F744: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 00000001F74C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000001F750: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001F754: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 00000001F758: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000001F760: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 00000001F768: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 00000001F774: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000001F778: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 00000001F77C: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 00000001F784: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001F788: BF870121
	v_add_f32_e32 v89, v89, v90                                // 00000001F78C: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 00000001F790: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 00000001F794: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F798: BF870095
	.long 0xd71c0059                                           // 00000001F79C: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 00000001F7A0: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 00000001F7A4: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000001F7A8: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F7B0: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 00000001F7B4: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000001F7BC: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F7C0: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 00000001F7C4: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 00000001F7CC: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F7D0: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 00000001F7D4: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 00000001F7DC: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 00000001F7E0: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F7E8: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 00000001F7EC: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 00000001F7F0: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F7F8: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 00000001F7FC: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 00000001F800: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F808: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 00000001F80C: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 00000001F814: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 00000001F81C: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F828: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 00000001F82C: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 00000001F834: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 00000001F840: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001F848: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000001F84C: BE882002
	s_cbranch_execz 62760                                      // 00000001F850: BFA5F528 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x30f4>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 00000001F854: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000001F860: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000001F868: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000001F86C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F870: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000001F874: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 00000001F87C: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 00000001F888: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001F88C: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 00000001F890: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000001F894: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 00000001F89C: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001F8A4: BF870121
	v_add_f32_e32 v82, v82, v89                                // 00000001F8A8: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 00000001F8AC: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 00000001F8B0: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F8B4: BF870095
	.long 0xd71c0052                                           // 00000001F8B8: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 00000001F8BC: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000001F8C0: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000001F8C4: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F8CC: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 00000001F8D0: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000001F8DC: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F8E0: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000001F8E4: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 00000001F8EC: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F8F0: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 00000001F8F4: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 00000001F8FC: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 00000001F900: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F908: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 00000001F90C: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 00000001F910: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F918: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 00000001F91C: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 00000001F920: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F928: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 00000001F92C: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000001F934: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 00000001F93C: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F948: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 00000001F94C: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 00000001F954: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000001F960: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001F968: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000001F96C: BE882003
	s_cbranch_execz 62691                                      // 00000001F970: BFA5F4E3 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3100>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 00000001F974: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000001F980: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000001F988: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000001F98C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F990: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000001F994: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000001F99C: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 00000001F9A8: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F9AC: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 00000001F9B0: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 00000001F9BC: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 00000001F9C0: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000001F9C4: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001F9CC: BF870293
	v_exp_f32_e32 v82, v82                                     // 00000001F9D0: 7EA44B52
	.long 0xd71c0052                                           // 00000001F9D4: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000001F9D8: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001F9DC: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000001F9E0: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000001F9E4: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 00000001F9EC: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001F9F8: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 00000001F9FC: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000001FA00: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000001FA08: BF870291
	v_rcp_f32_e32 v84, v83                                     // 00000001FA0C: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 00000001FA10: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000001FA18: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 00000001FA1C: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 00000001FA20: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 00000001FA28: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FA2C: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 00000001FA30: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 00000001FA38: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FA3C: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 00000001FA40: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 00000001FA48: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001FA50: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000001FA54: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 00000001FA5C: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 00000001FA68: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 00000001FA70: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000001FA74: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000001FA80: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001FA88: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000001FA8C: BE882004
	s_cbranch_execz 62622                                      // 00000001FA90: BFA5F49E <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x310c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 00000001FA94: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000001FAA0: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000001FAA8: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000001FAAC: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FAB0: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000001FAB4: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000001FABC: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000001FAC8: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001FACC: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000001FAD0: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000001FAD4: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000001FADC: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001FAE4: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000001FAE8: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000001FAEC: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000001FAF0: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FAF4: BF870095
	.long 0xd71c0052                                           // 00000001FAF8: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000001FAFC: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000001FB00: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000001FB04: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FB0C: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 00000001FB10: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000001FB1C: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FB20: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000001FB24: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000001FB2C: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FB30: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000001FB34: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000001FB3C: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000001FB40: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FB48: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 00000001FB4C: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 00000001FB50: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FB58: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 00000001FB5C: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 00000001FB60: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FB68: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 00000001FB6C: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000001FB74: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 00000001FB7C: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FB88: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000001FB8C: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000001FB94: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000001FBA0: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001FBA8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000001FBAC: BE882005
	s_cbranch_execz 62553                                      // 00000001FBB0: BFA5F459 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3118>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 00000001FBB4: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000001FBC0: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000001FBC8: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000001FBCC: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FBD0: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000001FBD4: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000001FBDC: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000001FBE8: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001FBEC: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000001FBF0: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000001FBF4: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000001FBFC: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001FC04: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000001FC08: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000001FC0C: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000001FC10: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FC14: BF870095
	.long 0xd71c0052                                           // 00000001FC18: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000001FC1C: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000001FC20: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000001FC24: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FC2C: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 00000001FC30: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 00000001FC38: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FC40: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000001FC44: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000001FC4C: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FC50: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000001FC54: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000001FC5C: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000001FC60: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FC68: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 00000001FC6C: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 00000001FC70: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FC78: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 00000001FC7C: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 00000001FC80: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FC88: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 00000001FC8C: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000001FC94: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 00000001FC9C: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FCA8: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000001FCAC: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000001FCB4: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000001FCC0: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001FCC8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000001FCCC: BE882006
	s_cbranch_execz 62484                                      // 00000001FCD0: BFA5F414 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3124>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 00000001FCD4: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000001FCE0: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000001FCE8: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000001FCEC: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FCF0: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000001FCF4: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000001FCFC: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000001FD08: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001FD0C: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000001FD10: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000001FD14: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000001FD1C: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001FD24: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000001FD28: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000001FD2C: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000001FD30: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FD34: BF870095
	.long 0xd71c0052                                           // 00000001FD38: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000001FD3C: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000001FD40: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000001FD44: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FD4C: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 00000001FD50: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000001FD5C: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FD60: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000001FD64: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000001FD6C: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FD70: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000001FD74: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000001FD7C: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000001FD80: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FD88: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 00000001FD8C: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 00000001FD90: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FD98: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 00000001FD9C: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 00000001FDA0: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FDA8: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 00000001FDAC: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000001FDB4: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 00000001FDBC: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FDC8: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000001FDCC: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000001FDD4: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000001FDE0: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001FDE8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000001FDEC: BE882007
	s_cbranch_execz 62415                                      // 00000001FDF0: BFA5F3CF <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3130>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 00000001FDF4: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000001FE00: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000001FE08: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000001FE0C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FE10: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000001FE14: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000001FE1C: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000001FE28: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001FE2C: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000001FE30: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000001FE34: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000001FE3C: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001FE44: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000001FE48: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000001FE4C: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000001FE50: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FE54: BF870095
	.long 0xd71c0052                                           // 00000001FE58: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000001FE5C: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000001FE60: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000001FE64: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FE6C: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 00000001FE70: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000001FE7C: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FE80: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000001FE84: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000001FE8C: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FE90: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000001FE94: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000001FE9C: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000001FEA0: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FEA8: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 00000001FEAC: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 00000001FEB0: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FEB8: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 00000001FEBC: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 00000001FEC0: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FEC8: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 00000001FECC: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000001FED4: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 00000001FEDC: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FEE8: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000001FEEC: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000001FEF4: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000001FF00: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000001FF08: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000001FF0C: BE882000
	s_cbranch_execz 62346                                      // 00000001FF10: BFA5F38A <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x313c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 00000001FF14: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 00000001FF20: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 00000001FF24: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000001FF2C: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000001FF30: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FF34: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000001FF38: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000001FF40: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000001FF4C: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000001FF50: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000001FF54: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000001FF58: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000001FF60: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000001FF68: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000001FF6C: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000001FF70: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000001FF74: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FF78: BF870095
	.long 0xd71c0052                                           // 00000001FF7C: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000001FF80: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000001FF84: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000001FF88: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FF90: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 00000001FF94: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000001FF9C: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FFA0: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 00000001FFA4: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 00000001FFAC: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FFB0: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 00000001FFB4: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 00000001FFBC: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 00000001FFC0: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FFC8: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 00000001FFCC: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 00000001FFD0: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FFD8: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 00000001FFDC: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 00000001FFE0: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000001FFE8: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 00000001FFEC: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 00000001FFF4: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 00000001FFFC: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020008: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 00000002000C: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 000000020014: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 000000020020: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 000000020028: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000002002C: BE882001
	s_cbranch_execz 62277                                      // 000000020030: BFA5F345 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3148>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 000000020034: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 000000020040: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 000000020044: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 00000002004C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000020050: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000020054: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 000000020058: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000020060: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 000000020068: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 000000020074: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000020078: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 00000002007C: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 000000020084: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000020088: BF870121
	v_add_f32_e32 v81, v81, v82                                // 00000002008C: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 000000020090: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 000000020094: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020098: BF870095
	.long 0xd71c0051                                           // 00000002009C: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 0000000200A0: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 0000000200A4: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000200A8: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000200B0: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 0000000200B4: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000200BC: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000200C0: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 0000000200C4: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 0000000200CC: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000200D0: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 0000000200D4: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 0000000200DC: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 0000000200E0: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000200E8: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 0000000200EC: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 0000000200F0: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000200F8: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 0000000200FC: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 000000020100: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020108: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 00000002010C: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 000000020114: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 00000002011C: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020128: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 00000002012C: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 000000020134: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 000000020140: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 000000020148: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000002014C: BE882002
	s_cbranch_execz 62208                                      // 000000020150: BFA5F300 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3154>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 000000020154: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000020160: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000020168: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000002016C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020170: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000020174: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 00000002017C: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 000000020188: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002018C: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 000000020190: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000020194: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 00000002019C: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000201A4: BF870121
	v_add_f32_e32 v74, v74, v81                                // 0000000201A8: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 0000000201AC: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 0000000201B0: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000201B4: BF870095
	.long 0xd71c004a                                           // 0000000201B8: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 0000000201BC: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000201C0: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000201C4: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000201CC: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 0000000201D0: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000201DC: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000201E0: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000201E4: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 0000000201EC: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000201F0: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 0000000201F4: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 0000000201FC: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 000000020200: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020208: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 00000002020C: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 000000020210: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020218: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 00000002021C: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 000000020220: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020228: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 00000002022C: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000020234: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 00000002023C: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020248: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 00000002024C: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 000000020254: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000020260: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000020268: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000002026C: BE882003
	s_cbranch_execz 62139                                      // 000000020270: BFA5F2BB <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3160>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 000000020274: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000020280: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000020288: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000002028C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020290: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000020294: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000002029C: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 0000000202A8: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000202AC: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 0000000202B0: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 0000000202BC: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 0000000202C0: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000202C4: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000202CC: BF870293
	v_exp_f32_e32 v74, v74                                     // 0000000202D0: 7E944B4A
	.long 0xd71c004a                                           // 0000000202D4: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000202D8: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000202DC: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000202E0: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000202E4: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 0000000202EC: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000202F8: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 0000000202FC: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000020300: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000020308: BF870291
	v_rcp_f32_e32 v76, v75                                     // 00000002030C: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 000000020310: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000020318: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 00000002031C: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 000000020320: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 000000020328: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002032C: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 000000020330: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 000000020338: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002033C: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 000000020340: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 000000020348: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000020350: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000020354: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 00000002035C: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 000000020368: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000020370: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000020374: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000020380: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000020388: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000002038C: BE882004
	s_cbranch_execz 62070                                      // 000000020390: BFA5F276 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x316c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 000000020394: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000203A0: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000203A8: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000203AC: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000203B0: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000203B4: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000203BC: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000203C8: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000203CC: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000203D0: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000203D4: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000203DC: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000203E4: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000203E8: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000203EC: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000203F0: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000203F4: BF870095
	.long 0xd71c004a                                           // 0000000203F8: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000203FC: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000020400: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000020404: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002040C: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 000000020410: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000002041C: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020420: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000020424: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 00000002042C: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020430: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000020434: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 00000002043C: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000020440: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020448: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 00000002044C: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 000000020450: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020458: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 00000002045C: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 000000020460: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020468: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 00000002046C: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000020474: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 00000002047C: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020488: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 00000002048C: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000020494: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000204A0: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000204A8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000204AC: BE882005
	s_cbranch_execz 62001                                      // 0000000204B0: BFA5F231 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3178>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 0000000204B4: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000204C0: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000204C8: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000204CC: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000204D0: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000204D4: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000204DC: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000204E8: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000204EC: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000204F0: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000204F4: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000204FC: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000020504: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000020508: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000002050C: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000020510: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020514: BF870095
	.long 0xd71c004a                                           // 000000020518: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000002051C: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000020520: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000020524: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002052C: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 000000020530: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 000000020538: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020540: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000020544: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 00000002054C: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020550: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000020554: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 00000002055C: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000020560: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020568: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 00000002056C: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 000000020570: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020578: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 00000002057C: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 000000020580: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020588: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 00000002058C: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000020594: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 00000002059C: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000205A8: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000205AC: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000205B4: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000205C0: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000205C8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000205CC: BE882006
	s_cbranch_execz 61932                                      // 0000000205D0: BFA5F1EC <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3184>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 0000000205D4: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000205E0: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000205E8: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000205EC: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000205F0: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000205F4: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000205FC: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000020608: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002060C: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000020610: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000020614: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000002061C: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000020624: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000020628: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000002062C: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000020630: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020634: BF870095
	.long 0xd71c004a                                           // 000000020638: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000002063C: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000020640: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000020644: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002064C: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 000000020650: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000002065C: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020660: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000020664: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 00000002066C: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020670: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000020674: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 00000002067C: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000020680: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020688: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 00000002068C: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 000000020690: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020698: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 00000002069C: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000206A0: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000206A8: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000206AC: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000206B4: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 0000000206BC: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000206C8: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000206CC: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000206D4: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000206E0: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000206E8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000206EC: BE882007
	s_cbranch_execz 61863                                      // 0000000206F0: BFA5F1A7 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3190>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 0000000206F4: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000020700: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000020708: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000002070C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020710: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000020714: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000002071C: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000020728: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002072C: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000020730: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000020734: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000002073C: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000020744: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000020748: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000002074C: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000020750: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020754: BF870095
	.long 0xd71c004a                                           // 000000020758: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000002075C: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000020760: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000020764: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002076C: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 000000020770: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000002077C: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020780: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000020784: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 00000002078C: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020790: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000020794: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 00000002079C: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000207A0: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000207A8: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000207AC: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000000207B0: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000207B8: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000207BC: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000207C0: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000207C8: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000207CC: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000207D4: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 0000000207DC: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000207E8: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000207EC: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000207F4: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000020800: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000020808: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000002080C: BE882000
	s_cbranch_execz 61794                                      // 000000020810: BFA5F162 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x319c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 000000020814: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 000000020820: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 000000020824: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000002082C: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000020830: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020834: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000020838: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000020840: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000002084C: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000020850: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000020854: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000020858: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000020860: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000020868: BF870121
	v_add_f32_e32 v74, v74, v75                                // 00000002086C: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000020870: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000020874: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020878: BF870095
	.long 0xd71c004a                                           // 00000002087C: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000020880: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000020884: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000020888: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020890: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 000000020894: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000002089C: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000208A0: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 0000000208A4: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 0000000208AC: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000208B0: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 0000000208B4: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 0000000208BC: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 0000000208C0: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000208C8: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 0000000208CC: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 0000000208D0: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000208D8: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 0000000208DC: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 0000000208E0: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000208E8: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 0000000208EC: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 0000000208F4: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 0000000208FC: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020908: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 00000002090C: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 000000020914: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 000000020920: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 000000020928: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000002092C: BE882001
	s_cbranch_execz 61725                                      // 000000020930: BFA5F11D <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x31a8>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 000000020934: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 000000020940: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 000000020944: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 00000002094C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000020950: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000020954: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 000000020958: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000020960: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 000000020968: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 000000020974: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000020978: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 00000002097C: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 000000020984: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000020988: BF870121
	v_add_f32_e32 v73, v73, v74                                // 00000002098C: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 000000020990: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 000000020994: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020998: BF870095
	.long 0xd71c0049                                           // 00000002099C: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000000209A0: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000209A4: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000209A8: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000209B0: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 0000000209B4: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000209BC: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000209C0: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 0000000209C4: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 0000000209CC: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000209D0: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 0000000209D4: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 0000000209DC: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 0000000209E0: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000209E8: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 0000000209EC: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 0000000209F0: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000209F8: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 0000000209FC: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 000000020A00: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020A08: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 000000020A0C: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 000000020A14: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 000000020A1C: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020A28: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 000000020A2C: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 000000020A34: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 000000020A40: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 000000020A48: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000020A4C: BE882002
	s_cbranch_execz 61656                                      // 000000020A50: BFA5F0D8 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x31b4>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 000000020A54: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000020A60: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000020A68: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000020A6C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020A70: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000020A74: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 000000020A7C: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 000000020A88: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000020A8C: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 000000020A90: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000020A94: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 000000020A9C: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000020AA4: BF870121
	v_add_f32_e32 v66, v66, v73                                // 000000020AA8: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 000000020AAC: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 000000020AB0: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020AB4: BF870095
	.long 0xd71c0042                                           // 000000020AB8: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 000000020ABC: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000020AC0: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000020AC4: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020ACC: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 000000020AD0: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000020ADC: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020AE0: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000020AE4: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 000000020AEC: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020AF0: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 000000020AF4: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 000000020AFC: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 000000020B00: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020B08: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 000000020B0C: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 000000020B10: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020B18: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 000000020B1C: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 000000020B20: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020B28: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 000000020B2C: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000020B34: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 000000020B3C: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020B48: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 000000020B4C: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 000000020B54: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000020B60: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000020B68: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000020B6C: BE882003
	s_cbranch_execz 61587                                      // 000000020B70: BFA5F093 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x31c0>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 000000020B74: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000020B80: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000020B88: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000020B8C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020B90: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000020B94: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000020B9C: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 000000020BA8: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020BAC: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 000000020BB0: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 000000020BBC: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 000000020BC0: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000020BC4: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000020BCC: BF870293
	v_exp_f32_e32 v66, v66                                     // 000000020BD0: 7E844B42
	.long 0xd71c0042                                           // 000000020BD4: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000020BD8: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000020BDC: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000020BE0: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000020BE4: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 000000020BEC: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020BF8: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 000000020BFC: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000020C00: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000020C08: BF870291
	v_rcp_f32_e32 v68, v67                                     // 000000020C0C: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 000000020C10: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000020C18: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 000000020C1C: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 000000020C20: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 000000020C28: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020C2C: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 000000020C30: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 000000020C38: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020C3C: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 000000020C40: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 000000020C48: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000020C50: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000020C54: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 000000020C5C: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 000000020C68: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 000000020C70: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000020C74: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000020C80: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000020C88: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000020C8C: BE882004
	s_cbranch_execz 61518                                      // 000000020C90: BFA5F04E <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x31cc>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 000000020C94: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000020CA0: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000020CA8: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000020CAC: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020CB0: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000020CB4: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000020CBC: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000020CC8: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000020CCC: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000020CD0: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000020CD4: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000020CDC: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000020CE4: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000020CE8: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000020CEC: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000020CF0: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020CF4: BF870095
	.long 0xd71c0042                                           // 000000020CF8: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000020CFC: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000020D00: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000020D04: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020D0C: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 000000020D10: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000020D1C: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020D20: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000020D24: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000020D2C: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020D30: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000020D34: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000020D3C: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000020D40: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020D48: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 000000020D4C: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 000000020D50: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020D58: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 000000020D5C: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 000000020D60: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020D68: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 000000020D6C: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000020D74: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 000000020D7C: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020D88: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000020D8C: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000020D94: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000020DA0: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000020DA8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000020DAC: BE882005
	s_cbranch_execz 61449                                      // 000000020DB0: BFA5F009 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x31d8>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 000000020DB4: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000020DC0: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000020DC8: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000020DCC: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020DD0: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000020DD4: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000020DDC: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000020DE8: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000020DEC: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000020DF0: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000020DF4: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000020DFC: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000020E04: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000020E08: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000020E0C: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000020E10: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020E14: BF870095
	.long 0xd71c0042                                           // 000000020E18: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000020E1C: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000020E20: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000020E24: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020E2C: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000020E30: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 000000020E38: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020E40: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000020E44: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000020E4C: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020E50: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000020E54: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000020E5C: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000020E60: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020E68: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000020E6C: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 000000020E70: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020E78: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 000000020E7C: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 000000020E80: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020E88: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000020E8C: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000020E94: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 000000020E9C: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020EA8: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000020EAC: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000020EB4: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000020EC0: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000020EC8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000020ECC: BE882006
	s_cbranch_execz 61380                                      // 000000020ED0: BFA5EFC4 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x31e4>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 000000020ED4: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000020EE0: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000020EE8: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000020EEC: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020EF0: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000020EF4: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000020EFC: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000020F08: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000020F0C: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000020F10: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000020F14: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000020F1C: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000020F24: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000020F28: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000020F2C: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000020F30: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020F34: BF870095
	.long 0xd71c0042                                           // 000000020F38: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000020F3C: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000020F40: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000020F44: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020F4C: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 000000020F50: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000020F5C: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020F60: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000020F64: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000020F6C: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020F70: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000020F74: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000020F7C: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000020F80: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020F88: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000020F8C: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000020F90: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020F98: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 000000020F9C: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 000000020FA0: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020FA8: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000020FAC: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000020FB4: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 000000020FBC: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000020FC8: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000020FCC: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000020FD4: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000020FE0: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000020FE8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000020FEC: BE882007
	s_cbranch_execz 61311                                      // 000000020FF0: BFA5EF7F <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x31f0>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 000000020FF4: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000021000: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000021008: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000002100C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021010: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000021014: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 00000002101C: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000021028: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002102C: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000021030: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000021034: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 00000002103C: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000021044: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000021048: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 00000002104C: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000021050: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021054: BF870095
	.long 0xd71c0042                                           // 000000021058: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 00000002105C: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000021060: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000021064: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002106C: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 000000021070: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000002107C: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021080: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000021084: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 00000002108C: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021090: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000021094: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 00000002109C: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000210A0: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000210A8: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000210AC: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 0000000210B0: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000210B8: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 0000000210BC: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 0000000210C0: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000210C8: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000210CC: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000210D4: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 0000000210DC: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000210E8: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000210EC: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000210F4: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000021100: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000021108: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000002110C: BE882000
	s_cbranch_execz 61242                                      // 000000021110: BFA5EF3A <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x31fc>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 000000021114: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 000000021120: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 000000021124: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 00000002112C: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000021130: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021134: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000021138: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000021140: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 00000002114C: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000021150: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000021154: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000021158: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000021160: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000021168: BF870121
	v_add_f32_e32 v66, v66, v67                                // 00000002116C: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000021170: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000021174: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021178: BF870095
	.long 0xd71c0042                                           // 00000002117C: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000021180: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000021184: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000021188: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021190: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000021194: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 00000002119C: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000211A0: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 0000000211A4: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 0000000211AC: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000211B0: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 0000000211B4: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 0000000211BC: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 0000000211C0: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000211C8: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 0000000211CC: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 0000000211D0: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000211D8: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 0000000211DC: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 0000000211E0: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000211E8: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 0000000211EC: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 0000000211F4: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 0000000211FC: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021208: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 00000002120C: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 000000021214: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 000000021220: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 000000021228: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000002122C: BE882001
	s_cbranch_execz 61173                                      // 000000021230: BFA5EEF5 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3208>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 000000021234: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 000000021240: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 000000021244: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 00000002124C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000021250: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000021254: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 000000021258: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000021260: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 000000021268: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 000000021274: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000021278: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 00000002127C: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 000000021284: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000021288: BF870121
	v_add_f32_e32 v65, v65, v66                                // 00000002128C: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000021290: 7E841143
	v_exp_f32_e32 v65, v65                                     // 000000021294: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021298: BF870095
	.long 0xd71c0041                                           // 00000002129C: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 0000000212A0: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 0000000212A4: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000212A8: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000212B0: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 0000000212B4: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000212BC: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000212C0: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 0000000212C4: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 0000000212CC: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000212D0: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 0000000212D4: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 0000000212DC: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 0000000212E0: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000212E8: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 0000000212EC: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 0000000212F0: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000212F8: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 0000000212FC: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 000000021300: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021308: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 00000002130C: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 000000021314: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 00000002131C: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021328: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 00000002132C: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 000000021334: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 000000021340: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 000000021348: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000002134C: BE882002
	s_cbranch_execz 61104                                      // 000000021350: BFA5EEB0 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3214>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 000000021354: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000021360: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000021368: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000002136C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021370: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000021374: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 00000002137C: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 000000021388: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002138C: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 000000021390: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000021394: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 00000002139C: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000213A4: BF870121
	v_add_f32_e32 v58, v58, v65                                // 0000000213A8: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 0000000213AC: 7E821142
	v_exp_f32_e32 v58, v58                                     // 0000000213B0: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000213B4: BF870095
	.long 0xd71c003a                                           // 0000000213B8: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 0000000213BC: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000213C0: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000213C4: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000213CC: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 0000000213D0: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000213DC: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000213E0: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000213E4: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 0000000213EC: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000213F0: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 0000000213F4: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 0000000213FC: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 000000021400: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021408: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 00000002140C: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 000000021410: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021418: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 00000002141C: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 000000021420: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021428: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 00000002142C: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000021434: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 00000002143C: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021448: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 00000002144C: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 000000021454: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000021460: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000021468: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000002146C: BE882003
	s_cbranch_execz 61035                                      // 000000021470: BFA5EE6B <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3220>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 000000021474: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000021480: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000021488: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000002148C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021490: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000021494: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000002149C: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 0000000214A8: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000214AC: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 0000000214B0: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 0000000214BC: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 0000000214C0: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000214C4: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000214CC: BF870293
	v_exp_f32_e32 v58, v58                                     // 0000000214D0: 7E744B3A
	.long 0xd71c003a                                           // 0000000214D4: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000214D8: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000214DC: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000214E0: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000214E4: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 0000000214EC: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000214F8: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 0000000214FC: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000021500: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000021508: BF870291
	v_rcp_f32_e32 v60, v59                                     // 00000002150C: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 000000021510: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000021518: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 00000002151C: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 000000021520: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 000000021528: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002152C: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 000000021530: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 000000021538: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002153C: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 000000021540: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 000000021548: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000021550: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000021554: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 00000002155C: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 000000021568: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000021570: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000021574: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000021580: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000021588: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000002158C: BE882004
	s_cbranch_execz 60966                                      // 000000021590: BFA5EE26 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x322c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 000000021594: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000215A0: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000215A8: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000215AC: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000215B0: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000215B4: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000215BC: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000215C8: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000215CC: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000215D0: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000215D4: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000215DC: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000215E4: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000215E8: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000215EC: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000215F0: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000215F4: BF870095
	.long 0xd71c003a                                           // 0000000215F8: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000215FC: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000021600: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000021604: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002160C: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 000000021610: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000002161C: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021620: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000021624: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000002162C: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021630: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000021634: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000002163C: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000021640: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021648: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 00000002164C: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 000000021650: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021658: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 00000002165C: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 000000021660: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021668: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 00000002166C: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000021674: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 00000002167C: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021688: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 00000002168C: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000021694: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000216A0: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000216A8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000216AC: BE882005
	s_cbranch_execz 60897                                      // 0000000216B0: BFA5EDE1 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3238>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 0000000216B4: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000216C0: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000216C8: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000216CC: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000216D0: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000216D4: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000216DC: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000216E8: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000216EC: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000216F0: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000216F4: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000216FC: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000021704: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000021708: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000002170C: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000021710: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021714: BF870095
	.long 0xd71c003a                                           // 000000021718: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000002171C: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000021720: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000021724: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002172C: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 000000021730: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 000000021738: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021740: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000021744: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000002174C: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021750: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000021754: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000002175C: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000021760: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021768: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 00000002176C: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 000000021770: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021778: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 00000002177C: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 000000021780: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021788: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 00000002178C: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000021794: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 00000002179C: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000217A8: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000217AC: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000217B4: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000217C0: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000217C8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000217CC: BE882006
	s_cbranch_execz 60828                                      // 0000000217D0: BFA5ED9C <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3244>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 0000000217D4: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000217E0: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000217E8: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000217EC: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000217F0: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000217F4: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000217FC: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000021808: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002180C: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000021810: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000021814: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000002181C: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000021824: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000021828: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000002182C: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000021830: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021834: BF870095
	.long 0xd71c003a                                           // 000000021838: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000002183C: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000021840: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000021844: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002184C: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 000000021850: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000002185C: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021860: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000021864: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000002186C: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021870: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000021874: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000002187C: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000021880: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021888: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 00000002188C: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 000000021890: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021898: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 00000002189C: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000218A0: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000218A8: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000218AC: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000218B4: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 0000000218BC: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000218C8: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000218CC: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000218D4: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000218E0: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000218E8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000218EC: BE882007
	s_cbranch_execz 60759                                      // 0000000218F0: BFA5ED57 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3250>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 0000000218F4: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000021900: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000021908: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000002190C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021910: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000021914: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000002191C: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000021928: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002192C: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000021930: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000021934: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000002193C: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000021944: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000021948: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 00000002194C: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000021950: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021954: BF870095
	.long 0xd71c003a                                           // 000000021958: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 00000002195C: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000021960: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000021964: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002196C: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 000000021970: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 00000002197C: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021980: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000021984: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 00000002198C: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021990: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000021994: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 00000002199C: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000219A0: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000219A8: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000219AC: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000000219B0: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000219B8: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000219BC: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000219C0: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000219C8: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000219CC: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000219D4: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 0000000219DC: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000219E8: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000219EC: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000219F4: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000021A00: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000021A08: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000021A0C: BE882000
	s_cbranch_execz 60690                                      // 000000021A10: BFA5ED12 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x325c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 000000021A14: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 000000021A20: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 000000021A24: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 000000021A2C: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000021A30: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021A34: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000021A38: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000021A40: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000021A4C: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000021A50: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000021A54: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000021A58: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000021A60: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000021A68: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000021A6C: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000021A70: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000021A74: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021A78: BF870095
	.long 0xd71c003a                                           // 000000021A7C: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000021A80: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000021A84: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000021A88: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021A90: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 000000021A94: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000021A9C: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021AA0: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 000000021AA4: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 000000021AAC: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021AB0: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 000000021AB4: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 000000021ABC: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 000000021AC0: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021AC8: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 000000021ACC: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 000000021AD0: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021AD8: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 000000021ADC: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 000000021AE0: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021AE8: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 000000021AEC: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 000000021AF4: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 000000021AFC: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021B08: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 000000021B0C: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 000000021B14: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 000000021B20: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 000000021B28: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000021B2C: BE882001
	s_cbranch_execz 60621                                      // 000000021B30: BFA5ECCD <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3268>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 000000021B34: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 000000021B40: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 000000021B44: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 000000021B4C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000021B50: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000021B54: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 000000021B58: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000021B60: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 000000021B68: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 000000021B74: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000021B78: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 000000021B7C: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 000000021B84: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000021B88: BF870121
	v_add_f32_e32 v57, v57, v58                                // 000000021B8C: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 000000021B90: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 000000021B94: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021B98: BF870095
	.long 0xd71c0039                                           // 000000021B9C: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 000000021BA0: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 000000021BA4: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000021BA8: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021BB0: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 000000021BB4: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000021BBC: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021BC0: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 000000021BC4: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 000000021BCC: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021BD0: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 000000021BD4: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 000000021BDC: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 000000021BE0: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021BE8: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 000000021BEC: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 000000021BF0: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021BF8: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 000000021BFC: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 000000021C00: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021C08: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 000000021C0C: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 000000021C14: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 000000021C1C: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021C28: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 000000021C2C: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 000000021C34: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 000000021C40: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 000000021C48: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000021C4C: BE882002
	s_cbranch_execz 60552                                      // 000000021C50: BFA5EC88 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3274>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 000000021C54: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000021C60: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000021C68: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000021C6C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021C70: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000021C74: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 000000021C7C: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 000000021C88: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000021C8C: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 000000021C90: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000021C94: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 000000021C9C: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000021CA4: BF870121
	v_add_f32_e32 v50, v50, v57                                // 000000021CA8: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 000000021CAC: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 000000021CB0: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021CB4: BF870095
	.long 0xd71c0032                                           // 000000021CB8: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 000000021CBC: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000021CC0: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000021CC4: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021CCC: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 000000021CD0: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000021CDC: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021CE0: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000021CE4: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 000000021CEC: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021CF0: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 000000021CF4: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 000000021CFC: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 000000021D00: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021D08: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 000000021D0C: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 000000021D10: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021D18: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 000000021D1C: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 000000021D20: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021D28: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 000000021D2C: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000021D34: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 000000021D3C: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021D48: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 000000021D4C: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 000000021D54: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000021D60: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000021D68: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000021D6C: BE882003
	s_cbranch_execz 60483                                      // 000000021D70: BFA5EC43 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3280>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 000000021D74: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000021D80: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000021D88: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000021D8C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021D90: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000021D94: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000021D9C: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 000000021DA8: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021DAC: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 000000021DB0: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 000000021DBC: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 000000021DC0: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000021DC4: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000021DCC: BF870293
	v_exp_f32_e32 v50, v50                                     // 000000021DD0: 7E644B32
	.long 0xd71c0032                                           // 000000021DD4: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000021DD8: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000021DDC: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000021DE0: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000021DE4: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 000000021DEC: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021DF8: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 000000021DFC: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000021E00: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000021E08: BF870291
	v_rcp_f32_e32 v52, v51                                     // 000000021E0C: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 000000021E10: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000021E18: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 000000021E1C: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 000000021E20: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 000000021E28: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021E2C: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 000000021E30: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 000000021E38: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021E3C: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 000000021E40: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 000000021E48: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000021E50: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000021E54: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 000000021E5C: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 000000021E68: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 000000021E70: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000021E74: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000021E80: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000021E88: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000021E8C: BE882004
	s_cbranch_execz 60414                                      // 000000021E90: BFA5EBFE <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x328c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 000000021E94: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000021EA0: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000021EA8: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000021EAC: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021EB0: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000021EB4: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000021EBC: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000021EC8: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000021ECC: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000021ED0: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000021ED4: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000021EDC: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000021EE4: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000021EE8: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000021EEC: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000021EF0: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021EF4: BF870095
	.long 0xd71c0032                                           // 000000021EF8: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000021EFC: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000021F00: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000021F04: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021F0C: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 000000021F10: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000021F1C: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021F20: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000021F24: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000021F2C: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021F30: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000021F34: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000021F3C: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000021F40: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021F48: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 000000021F4C: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 000000021F50: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021F58: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 000000021F5C: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 000000021F60: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021F68: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 000000021F6C: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000021F74: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 000000021F7C: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021F88: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000021F8C: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000021F94: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000021FA0: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000021FA8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000021FAC: BE882005
	s_cbranch_execz 60345                                      // 000000021FB0: BFA5EBB9 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3298>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 000000021FB4: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000021FC0: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000021FC8: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000021FCC: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000021FD0: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000021FD4: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000021FDC: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000021FE8: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000021FEC: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000021FF0: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000021FF4: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000021FFC: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000022004: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000022008: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000002200C: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000022010: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022014: BF870095
	.long 0xd71c0032                                           // 000000022018: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000002201C: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000022020: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000022024: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002202C: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 000000022030: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 000000022038: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022040: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000022044: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 00000002204C: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022050: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000022054: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 00000002205C: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000022060: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022068: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 00000002206C: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 000000022070: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022078: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 00000002207C: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 000000022080: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022088: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 00000002208C: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000022094: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 00000002209C: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000220A8: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000220AC: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000220B4: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000220C0: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000220C8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000220CC: BE882006
	s_cbranch_execz 60276                                      // 0000000220D0: BFA5EB74 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x32a4>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 0000000220D4: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000220E0: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000220E8: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000220EC: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000220F0: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000220F4: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000220FC: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000022108: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002210C: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000022110: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000022114: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000002211C: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000022124: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000022128: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000002212C: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000022130: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022134: BF870095
	.long 0xd71c0032                                           // 000000022138: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000002213C: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000022140: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000022144: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002214C: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 000000022150: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000002215C: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022160: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000022164: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 00000002216C: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022170: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000022174: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 00000002217C: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000022180: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022188: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 00000002218C: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 000000022190: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022198: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 00000002219C: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 0000000221A0: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000221A8: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000221AC: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000221B4: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 0000000221BC: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000221C8: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000221CC: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000221D4: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000221E0: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000221E8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000221EC: BE882007
	s_cbranch_execz 60207                                      // 0000000221F0: BFA5EB2F <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x32b0>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 0000000221F4: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000022200: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000022208: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000002220C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022210: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000022214: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 00000002221C: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000022228: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002222C: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000022230: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000022234: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 00000002223C: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000022244: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000022248: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 00000002224C: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000022250: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022254: BF870095
	.long 0xd71c0032                                           // 000000022258: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 00000002225C: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000022260: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000022264: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002226C: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 000000022270: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000002227C: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022280: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000022284: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 00000002228C: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022290: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000022294: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 00000002229C: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000222A0: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000222A8: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000222AC: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 0000000222B0: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000222B8: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 0000000222BC: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 0000000222C0: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000222C8: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000222CC: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000222D4: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 0000000222DC: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000222E8: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000222EC: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000222F4: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000022300: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000022308: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000002230C: BE882000
	s_cbranch_execz 60138                                      // 000000022310: BFA5EAEA <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x32bc>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 000000022314: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 000000022320: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 000000022324: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 00000002232C: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000022330: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022334: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000022338: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000022340: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 00000002234C: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000022350: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000022354: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000022358: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000022360: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000022368: BF870121
	v_add_f32_e32 v50, v50, v51                                // 00000002236C: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000022370: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000022374: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022378: BF870095
	.long 0xd71c0032                                           // 00000002237C: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000022380: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000022384: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000022388: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022390: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 000000022394: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 00000002239C: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000223A0: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 0000000223A4: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 0000000223AC: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000223B0: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 0000000223B4: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 0000000223BC: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 0000000223C0: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000223C8: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 0000000223CC: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 0000000223D0: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000223D8: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 0000000223DC: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 0000000223E0: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000223E8: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 0000000223EC: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 0000000223F4: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 0000000223FC: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022408: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 00000002240C: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 000000022414: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 000000022420: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 000000022428: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000002242C: BE882001
	s_cbranch_execz 60069                                      // 000000022430: BFA5EAA5 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x32c8>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 000000022434: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 000000022440: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 000000022444: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 00000002244C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000022450: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000022454: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 000000022458: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000022460: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 000000022468: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 000000022474: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000022478: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 00000002247C: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 000000022484: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000022488: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000002248C: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 000000022490: 7E641133
	v_exp_f32_e32 v49, v49                                     // 000000022494: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022498: BF870095
	.long 0xd71c0031                                           // 00000002249C: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 0000000224A0: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 0000000224A4: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000224A8: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000224B0: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 0000000224B4: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000224BC: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000224C0: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 0000000224C4: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 0000000224CC: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000224D0: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 0000000224D4: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 0000000224DC: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 0000000224E0: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000224E8: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 0000000224EC: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 0000000224F0: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000224F8: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 0000000224FC: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 000000022500: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022508: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 00000002250C: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 000000022514: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 00000002251C: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022528: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 00000002252C: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 000000022534: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 000000022540: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 000000022548: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000002254C: BE882002
	s_cbranch_execz 60000                                      // 000000022550: BFA5EA60 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x32d4>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 000000022554: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000022560: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000022568: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000002256C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022570: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000022574: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 00000002257C: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 000000022588: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002258C: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 000000022590: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000022594: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 00000002259C: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000225A4: BF870121
	v_add_f32_e32 v42, v42, v49                                // 0000000225A8: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 0000000225AC: 7E621132
	v_exp_f32_e32 v42, v42                                     // 0000000225B0: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000225B4: BF870095
	.long 0xd71c002a                                           // 0000000225B8: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 0000000225BC: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000225C0: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000225C4: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000225CC: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 0000000225D0: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000225DC: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000225E0: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000225E4: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 0000000225EC: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000225F0: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 0000000225F4: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 0000000225FC: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 000000022600: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022608: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 00000002260C: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 000000022610: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022618: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 00000002261C: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 000000022620: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022628: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 00000002262C: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000022634: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 00000002263C: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022648: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 00000002264C: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 000000022654: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000022660: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000022668: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000002266C: BE882003
	s_cbranch_execz 59931                                      // 000000022670: BFA5EA1B <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x32e0>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 000000022674: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000022680: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000022688: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000002268C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022690: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000022694: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000002269C: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 0000000226A8: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000226AC: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 0000000226B0: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 0000000226BC: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 0000000226C0: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000226C4: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000226CC: BF870293
	v_exp_f32_e32 v42, v42                                     // 0000000226D0: 7E544B2A
	.long 0xd71c002a                                           // 0000000226D4: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000226D8: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000226DC: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000226E0: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000226E4: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 0000000226EC: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000226F8: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 0000000226FC: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000022700: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000022708: BF870291
	v_rcp_f32_e32 v44, v43                                     // 00000002270C: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 000000022710: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000022718: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 00000002271C: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 000000022720: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 000000022728: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002272C: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 000000022730: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 000000022738: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002273C: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 000000022740: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 000000022748: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000022750: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000022754: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 00000002275C: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 000000022768: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000022770: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000022774: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000022780: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000022788: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000002278C: BE882004
	s_cbranch_execz 59862                                      // 000000022790: BFA5E9D6 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x32ec>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 000000022794: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000227A0: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000227A8: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000227AC: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000227B0: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000227B4: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000227BC: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000227C8: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000227CC: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000227D0: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000227D4: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000227DC: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000227E4: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000227E8: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000227EC: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000227F0: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000227F4: BF870095
	.long 0xd71c002a                                           // 0000000227F8: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000227FC: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000022800: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000022804: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002280C: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 000000022810: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 00000002281C: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022820: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000022824: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000002282C: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022830: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 000000022834: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000002283C: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000022840: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022848: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 00000002284C: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 000000022850: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022858: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 00000002285C: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 000000022860: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022868: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 00000002286C: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000022874: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 00000002287C: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022888: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 00000002288C: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000022894: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000228A0: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000228A8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000228AC: BE882005
	s_cbranch_execz 59793                                      // 0000000228B0: BFA5E991 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x32f8>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 0000000228B4: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000228C0: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000228C8: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000228CC: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000228D0: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000228D4: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000228DC: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000228E8: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000228EC: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000228F0: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000228F4: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000228FC: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000022904: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000022908: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 00000002290C: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000022910: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022914: BF870095
	.long 0xd71c002a                                           // 000000022918: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 00000002291C: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000022920: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000022924: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002292C: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 000000022930: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 000000022938: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022940: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000022944: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 00000002294C: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022950: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 000000022954: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 00000002295C: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000022960: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022968: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 00000002296C: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 000000022970: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022978: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 00000002297C: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 000000022980: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022988: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 00000002298C: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000022994: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 00000002299C: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000229A8: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000229AC: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000229B4: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000229C0: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000229C8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000229CC: BE882006
	s_cbranch_execz 59724                                      // 0000000229D0: BFA5E94C <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3304>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 0000000229D4: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000229E0: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000229E8: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000229EC: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000229F0: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000229F4: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000229FC: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000022A08: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000022A0C: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000022A10: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000022A14: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000022A1C: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000022A24: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000022A28: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000022A2C: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000022A30: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022A34: BF870095
	.long 0xd71c002a                                           // 000000022A38: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000022A3C: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000022A40: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000022A44: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022A4C: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 000000022A50: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000022A5C: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022A60: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000022A64: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000022A6C: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022A70: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 000000022A74: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000022A7C: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000022A80: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022A88: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 000000022A8C: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 000000022A90: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022A98: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 000000022A9C: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 000000022AA0: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022AA8: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 000000022AAC: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000022AB4: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 000000022ABC: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022AC8: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000022ACC: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000022AD4: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000022AE0: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000022AE8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000022AEC: BE882007
	s_cbranch_execz 59655                                      // 000000022AF0: BFA5E907 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3310>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 000000022AF4: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000022B00: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000022B08: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000022B0C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022B10: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000022B14: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000022B1C: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000022B28: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000022B2C: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000022B30: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000022B34: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000022B3C: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000022B44: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000022B48: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000022B4C: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000022B50: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022B54: BF870095
	.long 0xd71c002a                                           // 000000022B58: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000022B5C: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000022B60: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000022B64: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022B6C: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 000000022B70: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000022B7C: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022B80: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000022B84: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000022B8C: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022B90: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 000000022B94: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000022B9C: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000022BA0: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022BA8: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 000000022BAC: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 000000022BB0: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022BB8: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 000000022BBC: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 000000022BC0: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022BC8: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 000000022BCC: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000022BD4: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 000000022BDC: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022BE8: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000022BEC: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000022BF4: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000022C00: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000022C08: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000022C0C: BE882000
	s_cbranch_execz 59586                                      // 000000022C10: BFA5E8C2 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x331c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 000000022C14: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 000000022C20: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 000000022C24: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 000000022C2C: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000022C30: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022C34: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000022C38: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000022C40: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000022C4C: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000022C50: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000022C54: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000022C58: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000022C60: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000022C68: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000022C6C: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000022C70: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000022C74: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022C78: BF870095
	.long 0xd71c002a                                           // 000000022C7C: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000022C80: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000022C84: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000022C88: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022C90: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 000000022C94: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000022C9C: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022CA0: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 000000022CA4: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 000000022CAC: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022CB0: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 000000022CB4: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 000000022CBC: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 000000022CC0: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022CC8: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 000000022CCC: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 000000022CD0: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022CD8: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 000000022CDC: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 000000022CE0: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022CE8: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 000000022CEC: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 000000022CF4: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 000000022CFC: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022D08: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 000000022D0C: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 000000022D14: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 000000022D20: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 000000022D28: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000022D2C: BE882001
	s_cbranch_execz 59517                                      // 000000022D30: BFA5E87D <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3328>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 000000022D34: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 000000022D40: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 000000022D44: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 000000022D4C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000022D50: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000022D54: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 000000022D58: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000022D60: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 000000022D68: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 000000022D74: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000022D78: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 000000022D7C: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 000000022D84: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000022D88: BF870121
	v_add_f32_e32 v41, v41, v42                                // 000000022D8C: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 000000022D90: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 000000022D94: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022D98: BF870095
	.long 0xd71c0029                                           // 000000022D9C: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 000000022DA0: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 000000022DA4: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000022DA8: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022DB0: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 000000022DB4: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000022DBC: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022DC0: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 000000022DC4: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 000000022DCC: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022DD0: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 000000022DD4: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 000000022DDC: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 000000022DE0: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022DE8: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 000000022DEC: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 000000022DF0: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022DF8: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 000000022DFC: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 000000022E00: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022E08: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 000000022E0C: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 000000022E14: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 000000022E1C: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022E28: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 000000022E2C: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 000000022E34: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 000000022E40: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 000000022E48: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000022E4C: BE882002
	s_cbranch_execz 59448                                      // 000000022E50: BFA5E838 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3334>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 000000022E54: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000022E60: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000022E68: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000022E6C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022E70: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000022E74: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 000000022E7C: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 000000022E88: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000022E8C: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 000000022E90: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000022E94: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 000000022E9C: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000022EA4: BF870121
	v_add_f32_e32 v34, v34, v41                                // 000000022EA8: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 000000022EAC: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 000000022EB0: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022EB4: BF870095
	.long 0xd71c0022                                           // 000000022EB8: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 000000022EBC: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000022EC0: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000022EC4: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022ECC: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 000000022ED0: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000022EDC: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022EE0: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000022EE4: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 000000022EEC: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022EF0: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 000000022EF4: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 000000022EFC: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 000000022F00: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022F08: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 000000022F0C: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 000000022F10: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022F18: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 000000022F1C: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 000000022F20: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022F28: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 000000022F2C: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000022F34: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 000000022F3C: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022F48: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 000000022F4C: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 000000022F54: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000022F60: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000022F68: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000022F6C: BE882003
	s_cbranch_execz 59379                                      // 000000022F70: BFA5E7F3 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3340>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 000000022F74: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000022F80: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000022F88: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000022F8C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022F90: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000022F94: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000022F9C: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 000000022FA8: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022FAC: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 000000022FB0: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 000000022FBC: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 000000022FC0: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000022FC4: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000022FCC: BF870293
	v_exp_f32_e32 v34, v34                                     // 000000022FD0: 7E444B22
	.long 0xd71c0022                                           // 000000022FD4: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000022FD8: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000022FDC: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000022FE0: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000022FE4: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 000000022FEC: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000022FF8: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 000000022FFC: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000023000: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000023008: BF870291
	v_rcp_f32_e32 v36, v35                                     // 00000002300C: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 000000023010: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000023018: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 00000002301C: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 000000023020: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 000000023028: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002302C: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 000000023030: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 000000023038: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002303C: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 000000023040: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 000000023048: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000023050: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000023054: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 00000002305C: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 000000023068: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 000000023070: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000023074: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000023080: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000023088: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000002308C: BE882004
	s_cbranch_execz 59310                                      // 000000023090: BFA5E7AE <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x334c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 000000023094: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000230A0: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000230A8: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000230AC: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000230B0: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000230B4: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000230BC: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000230C8: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000230CC: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000230D0: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000230D4: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000230DC: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000230E4: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000230E8: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000230EC: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000230F0: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000230F4: BF870095
	.long 0xd71c0022                                           // 0000000230F8: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000230FC: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000023100: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000023104: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002310C: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 000000023110: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000002311C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023120: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000023124: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000002312C: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023130: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000023134: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000002313C: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000023140: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023148: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 00000002314C: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 000000023150: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023158: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 00000002315C: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 000000023160: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023168: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 00000002316C: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000023174: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 00000002317C: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023188: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 00000002318C: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000023194: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000231A0: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000231A8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000231AC: BE882005
	s_cbranch_execz 59241                                      // 0000000231B0: BFA5E769 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3358>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 0000000231B4: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000231C0: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000231C8: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000231CC: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000231D0: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000231D4: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000231DC: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000231E8: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000231EC: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000231F0: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000231F4: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000231FC: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000023204: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000023208: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000002320C: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000023210: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023214: BF870095
	.long 0xd71c0022                                           // 000000023218: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000002321C: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000023220: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000023224: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002322C: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 000000023230: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 000000023238: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023240: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000023244: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000002324C: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023250: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000023254: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000002325C: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000023260: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023268: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 00000002326C: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 000000023270: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023278: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 00000002327C: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 000000023280: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023288: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 00000002328C: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000023294: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 00000002329C: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000232A8: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000232AC: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000232B4: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000232C0: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000232C8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000232CC: BE882006
	s_cbranch_execz 59172                                      // 0000000232D0: BFA5E724 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3364>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 0000000232D4: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000232E0: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000232E8: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000232EC: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000232F0: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000232F4: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000232FC: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000023308: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002330C: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000023310: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000023314: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000002331C: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000023324: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000023328: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000002332C: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000023330: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023334: BF870095
	.long 0xd71c0022                                           // 000000023338: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000002333C: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000023340: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000023344: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002334C: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 000000023350: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000002335C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023360: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000023364: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000002336C: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023370: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000023374: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000002337C: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000023380: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023388: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 00000002338C: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 000000023390: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023398: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 00000002339C: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 0000000233A0: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000233A8: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000233AC: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000233B4: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 0000000233BC: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000233C8: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000233CC: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000233D4: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000233E0: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000233E8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000233EC: BE882007
	s_cbranch_execz 59103                                      // 0000000233F0: BFA5E6DF <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3370>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 0000000233F4: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000023400: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000023408: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000002340C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023410: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000023414: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000002341C: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000023428: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002342C: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000023430: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000023434: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000002343C: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000023444: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000023448: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 00000002344C: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000023450: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023454: BF870095
	.long 0xd71c0022                                           // 000000023458: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 00000002345C: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000023460: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000023464: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002346C: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 000000023470: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000002347C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023480: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000023484: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 00000002348C: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023490: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000023494: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 00000002349C: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000234A0: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000234A8: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000234AC: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 0000000234B0: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000234B8: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 0000000234BC: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 0000000234C0: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000234C8: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000234CC: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000234D4: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 0000000234DC: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000234E8: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000234EC: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000234F4: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000023500: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000023508: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000002350C: BE882000
	s_cbranch_execz 59034                                      // 000000023510: BFA5E69A <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x337c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 000000023514: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 000000023520: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 000000023524: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 00000002352C: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000023530: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023534: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000023538: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000023540: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 00000002354C: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000023550: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000023554: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000023558: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000023560: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000023568: BF870121
	v_add_f32_e32 v34, v34, v35                                // 00000002356C: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000023570: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000023574: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023578: BF870095
	.long 0xd71c0022                                           // 00000002357C: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000023580: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000023584: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000023588: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023590: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 000000023594: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 00000002359C: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000235A0: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 0000000235A4: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 0000000235AC: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000235B0: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000000235B4: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 0000000235BC: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 0000000235C0: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000235C8: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 0000000235CC: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 0000000235D0: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000235D8: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 0000000235DC: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 0000000235E0: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000235E8: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 0000000235EC: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 0000000235F4: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 0000000235FC: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023608: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 00000002360C: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 000000023614: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 000000023620: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 000000023628: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000002362C: BE882001
	s_cbranch_execz 58965                                      // 000000023630: BFA5E655 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3388>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 000000023634: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 000000023640: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 000000023644: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 00000002364C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000023650: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000023654: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 000000023658: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000023660: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 000000023668: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 000000023674: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000023678: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 00000002367C: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 000000023684: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000023688: BF870121
	v_add_f32_e32 v33, v33, v34                                // 00000002368C: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 000000023690: 7E441123
	v_exp_f32_e32 v33, v33                                     // 000000023694: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023698: BF870095
	.long 0xd71c0021                                           // 00000002369C: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000000236A0: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000000236A4: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000236A8: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000236B0: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 0000000236B4: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000236BC: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000236C0: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 0000000236C4: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 0000000236CC: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000236D0: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 0000000236D4: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 0000000236DC: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 0000000236E0: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000236E8: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 0000000236EC: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 0000000236F0: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000236F8: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 0000000236FC: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 000000023700: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023708: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 00000002370C: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 000000023714: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 00000002371C: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023728: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 00000002372C: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 000000023734: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 000000023740: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 000000023748: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000002374C: BE882002
	s_cbranch_execz 58896                                      // 000000023750: BFA5E610 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3394>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 000000023754: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000023760: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000023768: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000002376C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023770: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000023774: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 00000002377C: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 000000023788: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002378C: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 000000023790: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000023794: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 00000002379C: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000237A4: BF870121
	v_add_f32_e32 v26, v26, v33                                // 0000000237A8: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000237AC: 7E421122
	v_exp_f32_e32 v26, v26                                     // 0000000237B0: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000237B4: BF870095
	.long 0xd71c001a                                           // 0000000237B8: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 0000000237BC: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000237C0: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000237C4: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000237CC: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 0000000237D0: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000237DC: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000237E0: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000237E4: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 0000000237EC: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000237F0: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 0000000237F4: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 0000000237FC: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 000000023800: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023808: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 00000002380C: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 000000023810: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023818: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 00000002381C: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 000000023820: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023828: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 00000002382C: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000023834: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 00000002383C: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023848: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 00000002384C: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 000000023854: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000023860: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000023868: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000002386C: BE882003
	s_cbranch_execz 58827                                      // 000000023870: BFA5E5CB <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x33a0>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 000000023874: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000023880: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000023888: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000002388C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023890: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000023894: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 00000002389C: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 0000000238A8: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000238AC: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 0000000238B0: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 0000000238BC: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 0000000238C0: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000238C4: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000238CC: BF870293
	v_exp_f32_e32 v26, v26                                     // 0000000238D0: 7E344B1A
	.long 0xd71c001a                                           // 0000000238D4: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000238D8: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000238DC: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000238E0: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000238E4: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 0000000238EC: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000238F8: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 0000000238FC: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000023900: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000023908: BF870291
	v_rcp_f32_e32 v28, v27                                     // 00000002390C: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 000000023910: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000023918: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 00000002391C: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 000000023920: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 000000023928: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002392C: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 000000023930: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 000000023938: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002393C: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 000000023940: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 000000023948: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000023950: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000023954: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 00000002395C: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 000000023968: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000023970: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000023974: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000023980: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000023988: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000002398C: BE882004
	s_cbranch_execz 58758                                      // 000000023990: BFA5E586 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x33ac>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 000000023994: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000239A0: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000239A8: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000239AC: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000239B0: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000239B4: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000239BC: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000239C8: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000239CC: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000239D0: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000239D4: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000239DC: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000239E4: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000239E8: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000239EC: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000239F0: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000239F4: BF870095
	.long 0xd71c001a                                           // 0000000239F8: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000239FC: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000023A00: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000023A04: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023A0C: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 000000023A10: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000023A1C: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023A20: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000023A24: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000023A2C: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023A30: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 000000023A34: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000023A3C: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000023A40: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023A48: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 000000023A4C: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 000000023A50: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023A58: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 000000023A5C: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 000000023A60: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023A68: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 000000023A6C: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000023A74: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 000000023A7C: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023A88: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000023A8C: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000023A94: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000023AA0: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000023AA8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000023AAC: BE882005
	s_cbranch_execz 58689                                      // 000000023AB0: BFA5E541 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x33b8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 000000023AB4: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000023AC0: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000023AC8: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000023ACC: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023AD0: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000023AD4: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000023ADC: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000023AE8: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000023AEC: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000023AF0: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000023AF4: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000023AFC: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000023B04: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000023B08: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000023B0C: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000023B10: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023B14: BF870095
	.long 0xd71c001a                                           // 000000023B18: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000023B1C: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000023B20: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000023B24: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023B2C: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 000000023B30: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 000000023B38: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023B40: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000023B44: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000023B4C: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023B50: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 000000023B54: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000023B5C: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000023B60: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023B68: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 000000023B6C: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 000000023B70: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023B78: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 000000023B7C: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 000000023B80: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023B88: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 000000023B8C: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000023B94: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 000000023B9C: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023BA8: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000023BAC: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000023BB4: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000023BC0: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000023BC8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000023BCC: BE882006
	s_cbranch_execz 58620                                      // 000000023BD0: BFA5E4FC <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x33c4>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 000000023BD4: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000023BE0: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000023BE8: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000023BEC: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023BF0: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000023BF4: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000023BFC: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000023C08: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000023C0C: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000023C10: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000023C14: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000023C1C: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000023C24: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000023C28: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000023C2C: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000023C30: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023C34: BF870095
	.long 0xd71c001a                                           // 000000023C38: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000023C3C: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000023C40: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000023C44: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023C4C: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 000000023C50: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000023C5C: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023C60: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000023C64: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000023C6C: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023C70: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 000000023C74: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000023C7C: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000023C80: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023C88: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 000000023C8C: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 000000023C90: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023C98: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 000000023C9C: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 000000023CA0: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023CA8: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 000000023CAC: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000023CB4: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 000000023CBC: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023CC8: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000023CCC: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000023CD4: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000023CE0: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000023CE8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000023CEC: BE882007
	s_cbranch_execz 58551                                      // 000000023CF0: BFA5E4B7 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x33d0>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 000000023CF4: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000023D00: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000023D08: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000023D0C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023D10: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000023D14: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000023D1C: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000023D28: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000023D2C: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000023D30: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000023D34: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000023D3C: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000023D44: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000023D48: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000023D4C: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000023D50: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023D54: BF870095
	.long 0xd71c001a                                           // 000000023D58: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000023D5C: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000023D60: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000023D64: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023D6C: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 000000023D70: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000023D7C: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023D80: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000023D84: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000023D8C: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023D90: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 000000023D94: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000023D9C: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000023DA0: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023DA8: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 000000023DAC: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 000000023DB0: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023DB8: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 000000023DBC: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 000000023DC0: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023DC8: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 000000023DCC: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000023DD4: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 000000023DDC: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023DE8: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000023DEC: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000023DF4: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000023E00: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000023E08: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000023E0C: BE882000
	s_cbranch_execz 58482                                      // 000000023E10: BFA5E472 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x33dc>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 000000023E14: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 000000023E20: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 000000023E24: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 000000023E2C: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000023E30: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023E34: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000023E38: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000023E40: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000023E4C: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000023E50: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000023E54: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000023E58: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000023E60: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000023E68: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000023E6C: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000023E70: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000023E74: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023E78: BF870095
	.long 0xd71c001a                                           // 000000023E7C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000023E80: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000023E84: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000023E88: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023E90: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 000000023E94: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000023E9C: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023EA0: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 000000023EA4: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 000000023EAC: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023EB0: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 000000023EB4: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 000000023EBC: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 000000023EC0: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023EC8: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 000000023ECC: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 000000023ED0: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023ED8: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 000000023EDC: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 000000023EE0: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023EE8: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 000000023EEC: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 000000023EF4: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 000000023EFC: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023F08: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 000000023F0C: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 000000023F14: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 000000023F20: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 000000023F28: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000023F2C: BE882001
	s_cbranch_execz 58413                                      // 000000023F30: BFA5E42D <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x33e8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 000000023F34: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 000000023F40: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 000000023F44: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 000000023F4C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000023F50: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000023F54: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 000000023F58: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000023F60: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 000000023F68: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 000000023F74: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000023F78: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 000000023F7C: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 000000023F84: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000023F88: BF870121
	v_add_f32_e32 v25, v25, v26                                // 000000023F8C: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 000000023F90: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 000000023F94: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023F98: BF870095
	.long 0xd71c0019                                           // 000000023F9C: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000023FA0: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 000000023FA4: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000023FA8: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023FB0: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 000000023FB4: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000023FBC: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023FC0: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 000000023FC4: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 000000023FCC: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023FD0: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 000000023FD4: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 000000023FDC: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 000000023FE0: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023FE8: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 000000023FEC: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 000000023FF0: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000023FF8: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 000000023FFC: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 000000024000: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024008: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 00000002400C: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 000000024014: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 00000002401C: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024028: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 00000002402C: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 000000024034: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 000000024040: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 000000024048: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000002404C: BE882002
	s_cbranch_execz 58344                                      // 000000024050: BFA5E3E8 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x33f4>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 000000024054: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000024060: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000024068: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000002406C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024070: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000024074: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 00000002407C: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 000000024088: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002408C: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 000000024090: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000024094: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 00000002409C: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000240A4: BF870121
	v_add_f32_e32 v18, v18, v25                                // 0000000240A8: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 0000000240AC: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 0000000240B0: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000240B4: BF870095
	.long 0xd71c0012                                           // 0000000240B8: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 0000000240BC: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000240C0: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000240C4: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000240CC: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 0000000240D0: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000240DC: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000240E0: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000240E4: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 0000000240EC: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000240F0: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 0000000240F4: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 0000000240FC: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 000000024100: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024108: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 00000002410C: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 000000024110: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024118: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 00000002411C: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 000000024120: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024128: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 00000002412C: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000024134: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 00000002413C: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024148: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 00000002414C: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 000000024154: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000024160: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000024168: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000002416C: BE882003
	s_cbranch_execz 58275                                      // 000000024170: BFA5E3A3 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3400>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 000000024174: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000024180: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000024188: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000002418C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024190: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000024194: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000002419C: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 0000000241A8: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000241AC: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 0000000241B0: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 0000000241BC: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 0000000241C0: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000241C4: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000241CC: BF870293
	v_exp_f32_e32 v18, v18                                     // 0000000241D0: 7E244B12
	.long 0xd71c0012                                           // 0000000241D4: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000241D8: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000241DC: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000241E0: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000241E4: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 0000000241EC: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000241F8: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 0000000241FC: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000024200: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000024208: BF870291
	v_rcp_f32_e32 v20, v19                                     // 00000002420C: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 000000024210: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000024218: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 00000002421C: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 000000024220: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 000000024228: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002422C: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 000000024230: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 000000024238: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002423C: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 000000024240: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 000000024248: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000024250: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000024254: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 00000002425C: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 000000024268: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000024270: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000024274: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000024280: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000024288: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000002428C: BE882004
	s_cbranch_execz 58206                                      // 000000024290: BFA5E35E <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x340c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 000000024294: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000242A0: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000242A8: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000242AC: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000242B0: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000242B4: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000242BC: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000242C8: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000242CC: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000242D0: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000242D4: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000242DC: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000242E4: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000242E8: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000242EC: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000242F0: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000242F4: BF870095
	.long 0xd71c0012                                           // 0000000242F8: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000242FC: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000024300: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000024304: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002430C: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 000000024310: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000002431C: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024320: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000024324: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000002432C: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024330: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000024334: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000002433C: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000024340: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024348: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 00000002434C: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 000000024350: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024358: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 00000002435C: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 000000024360: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024368: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 00000002436C: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000024374: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 00000002437C: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024388: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 00000002438C: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000024394: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000243A0: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000243A8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000243AC: BE882005
	s_cbranch_execz 58137                                      // 0000000243B0: BFA5E319 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3418>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 0000000243B4: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000243C0: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000243C8: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000243CC: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000243D0: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000243D4: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000243DC: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000243E8: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000243EC: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000243F0: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000243F4: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000243FC: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000024404: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000024408: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000002440C: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000024410: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024414: BF870095
	.long 0xd71c0012                                           // 000000024418: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000002441C: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000024420: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000024424: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002442C: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 000000024430: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 000000024438: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024440: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000024444: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000002444C: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024450: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000024454: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000002445C: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000024460: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024468: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 00000002446C: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 000000024470: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024478: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 00000002447C: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 000000024480: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024488: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 00000002448C: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000024494: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 00000002449C: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000244A8: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000244AC: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000244B4: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000244C0: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000244C8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000244CC: BE882006
	s_cbranch_execz 58068                                      // 0000000244D0: BFA5E2D4 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3424>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 0000000244D4: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000244E0: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000244E8: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000244EC: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000244F0: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000244F4: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000244FC: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000024508: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002450C: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000024510: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000024514: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000002451C: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000024524: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000024528: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000002452C: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000024530: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024534: BF870095
	.long 0xd71c0012                                           // 000000024538: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000002453C: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000024540: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000024544: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002454C: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 000000024550: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000002455C: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024560: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000024564: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000002456C: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024570: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000024574: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000002457C: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000024580: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024588: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 00000002458C: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 000000024590: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024598: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 00000002459C: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000245A0: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000245A8: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000245AC: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000245B4: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 0000000245BC: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000245C8: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000245CC: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000245D4: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000245E0: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000245E8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000245EC: BE882007
	s_cbranch_execz 57999                                      // 0000000245F0: BFA5E28F <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3430>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 0000000245F4: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000024600: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000024608: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000002460C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024610: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000024614: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000002461C: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000024628: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002462C: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000024630: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000024634: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000002463C: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000024644: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000024648: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 00000002464C: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000024650: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024654: BF870095
	.long 0xd71c0012                                           // 000000024658: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 00000002465C: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000024660: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000024664: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002466C: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 000000024670: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000002467C: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024680: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000024684: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 00000002468C: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024690: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000024694: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 00000002469C: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000246A0: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000246A8: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000246AC: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000000246B0: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000246B8: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000000246BC: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000246C0: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000246C8: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000246CC: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000246D4: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 0000000246DC: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000246E8: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000246EC: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000246F4: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000024700: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000024708: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000002470C: BE882000
	s_cbranch_execz 57930                                      // 000000024710: BFA5E24A <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x343c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 000000024714: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 000000024720: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 000000024724: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 00000002472C: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000024730: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024734: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000024738: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000024740: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 00000002474C: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000024750: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000024754: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000024758: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000024760: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000024768: BF870121
	v_add_f32_e32 v18, v18, v19                                // 00000002476C: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000024770: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000024774: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024778: BF870095
	.long 0xd71c0012                                           // 00000002477C: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000024780: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000024784: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000024788: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024790: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 000000024794: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 00000002479C: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000247A0: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 0000000247A4: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 0000000247AC: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000247B0: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 0000000247B4: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 0000000247BC: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 0000000247C0: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000247C8: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 0000000247CC: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 0000000247D0: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000247D8: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 0000000247DC: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 0000000247E0: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000247E8: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 0000000247EC: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 0000000247F4: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 0000000247FC: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024808: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 00000002480C: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 000000024814: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 000000024820: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 000000024828: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000002482C: BE882001
	s_cbranch_execz 57861                                      // 000000024830: BFA5E205 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3448>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 000000024834: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 000000024840: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 000000024844: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 00000002484C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000024850: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000024854: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 000000024858: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000024860: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 000000024868: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 000000024874: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000024878: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 00000002487C: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 000000024884: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000024888: BF870121
	v_add_f32_e32 v17, v17, v18                                // 00000002488C: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 000000024890: 7E241113
	v_exp_f32_e32 v17, v17                                     // 000000024894: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024898: BF870095
	.long 0xd71c0011                                           // 00000002489C: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000000248A0: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000000248A4: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000248A8: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000248B0: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 0000000248B4: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000248BC: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000248C0: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 0000000248C4: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 0000000248CC: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000248D0: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 0000000248D4: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 0000000248DC: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 0000000248E0: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000248E8: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 0000000248EC: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 0000000248F0: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000248F8: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 0000000248FC: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 000000024900: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024908: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 00000002490C: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 000000024914: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 00000002491C: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024928: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 00000002492C: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 000000024934: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 000000024940: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 000000024948: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000002494C: BE882002
	s_cbranch_execz 57792                                      // 000000024950: BFA5E1C0 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3454>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 000000024954: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000024960: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000024968: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000002496C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024970: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000024974: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 00000002497C: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 000000024988: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002498C: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 000000024990: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000024994: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 00000002499C: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000249A4: BF870121
	v_add_f32_e32 v10, v10, v17                                // 0000000249A8: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 0000000249AC: 7E221112
	v_exp_f32_e32 v10, v10                                     // 0000000249B0: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000249B4: BF870095
	.long 0xd71c000a                                           // 0000000249B8: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 0000000249BC: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000249C0: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000249C4: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000249CC: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 0000000249D0: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000249DC: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000249E0: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000249E4: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 0000000249EC: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000249F0: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 0000000249F4: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 0000000249FC: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 000000024A00: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024A08: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 000000024A0C: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 000000024A10: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024A18: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 000000024A1C: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 000000024A20: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024A28: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 000000024A2C: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000024A34: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 000000024A3C: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024A48: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 000000024A4C: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 000000024A54: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000024A60: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000024A68: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000024A6C: BE882003
	s_cbranch_execz 57723                                      // 000000024A70: BFA5E17B <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3460>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 000000024A74: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000024A80: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000024A88: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000024A8C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024A90: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000024A94: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000024A9C: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 000000024AA8: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024AAC: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 000000024AB0: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 000000024ABC: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 000000024AC0: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000024AC4: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000024ACC: BF870293
	v_exp_f32_e32 v10, v10                                     // 000000024AD0: 7E144B0A
	.long 0xd71c000a                                           // 000000024AD4: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000024AD8: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000024ADC: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000024AE0: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000024AE4: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 000000024AEC: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024AF8: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 000000024AFC: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000024B00: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000024B08: BF870291
	v_rcp_f32_e32 v12, v11                                     // 000000024B0C: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 000000024B10: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000024B18: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 000000024B1C: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 000000024B20: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 000000024B28: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024B2C: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 000000024B30: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 000000024B38: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024B3C: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 000000024B40: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 000000024B48: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000024B50: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000024B54: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 000000024B5C: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 000000024B68: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000024B70: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000024B74: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000024B80: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000024B88: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000024B8C: BE882004
	s_cbranch_execz 57654                                      // 000000024B90: BFA5E136 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x346c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 000000024B94: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000024BA0: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000024BA8: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000024BAC: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024BB0: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000024BB4: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000024BBC: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000024BC8: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000024BCC: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000024BD0: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000024BD4: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000024BDC: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000024BE4: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000024BE8: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000024BEC: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000024BF0: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024BF4: BF870095
	.long 0xd71c000a                                           // 000000024BF8: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000024BFC: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000024C00: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000024C04: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024C0C: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 000000024C10: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000024C1C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024C20: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000024C24: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000024C2C: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024C30: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000024C34: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000024C3C: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000024C40: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024C48: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 000000024C4C: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 000000024C50: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024C58: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 000000024C5C: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 000000024C60: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024C68: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 000000024C6C: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000024C74: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 000000024C7C: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024C88: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000024C8C: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000024C94: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000024CA0: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000024CA8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000024CAC: BE882005
	s_cbranch_execz 57585                                      // 000000024CB0: BFA5E0F1 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3478>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 000000024CB4: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000024CC0: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000024CC8: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000024CCC: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024CD0: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000024CD4: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000024CDC: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000024CE8: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000024CEC: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000024CF0: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000024CF4: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000024CFC: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000024D04: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000024D08: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000024D0C: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000024D10: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024D14: BF870095
	.long 0xd71c000a                                           // 000000024D18: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000024D1C: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000024D20: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000024D24: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024D2C: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 000000024D30: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 000000024D38: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024D40: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000024D44: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000024D4C: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024D50: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000024D54: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000024D5C: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000024D60: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024D68: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000024D6C: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 000000024D70: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024D78: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 000000024D7C: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 000000024D80: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024D88: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000024D8C: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000024D94: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 000000024D9C: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024DA8: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000024DAC: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000024DB4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000024DC0: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000024DC8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000024DCC: BE882006
	s_cbranch_execz 57516                                      // 000000024DD0: BFA5E0AC <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3484>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 000000024DD4: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000024DE0: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000024DE8: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000024DEC: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024DF0: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000024DF4: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000024DFC: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000024E08: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000024E0C: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000024E10: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000024E14: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000024E1C: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000024E24: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000024E28: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000024E2C: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000024E30: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024E34: BF870095
	.long 0xd71c000a                                           // 000000024E38: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000024E3C: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000024E40: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000024E44: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024E4C: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 000000024E50: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000024E5C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024E60: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000024E64: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000024E6C: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024E70: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000024E74: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000024E7C: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000024E80: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024E88: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000024E8C: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 000000024E90: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024E98: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 000000024E9C: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 000000024EA0: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024EA8: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000024EAC: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000024EB4: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 000000024EBC: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024EC8: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000024ECC: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000024ED4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000024EE0: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000024EE8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000024EEC: BE882007
	s_cbranch_execz 57447                                      // 000000024EF0: BFA5E067 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x3490>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 000000024EF4: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000024F00: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000024F08: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000024F0C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024F10: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000024F14: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000024F1C: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000024F28: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000024F2C: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000024F30: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000024F34: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000024F3C: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000024F44: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000024F48: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000024F4C: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000024F50: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024F54: BF870095
	.long 0xd71c000a                                           // 000000024F58: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000024F5C: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000024F60: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000024F64: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024F6C: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 000000024F70: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000024F7C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024F80: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000024F84: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000024F8C: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024F90: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000024F94: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000024F9C: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000024FA0: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024FA8: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000024FAC: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 000000024FB0: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024FB8: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 000000024FBC: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 000000024FC0: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024FC8: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000024FCC: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000024FD4: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 000000024FDC: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000024FE8: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000024FEC: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000024FF4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000025000: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000025008: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000002500C: BE882000
	s_cbranch_execz 57378                                      // 000000025010: BFA5E022 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x349c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 000000025014: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 000000025020: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 000000025024: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 00000002502C: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000025030: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025034: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000025038: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000025040: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 00000002504C: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000025050: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000025054: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000025058: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000025060: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000025068: BF870121
	v_add_f32_e32 v10, v10, v11                                // 00000002506C: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000025070: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000025074: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025078: BF870095
	.long 0xd71c000a                                           // 00000002507C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000025080: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000025084: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000025088: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025090: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 000000025094: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 00000002509C: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000250A0: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 0000000250A4: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 0000000250AC: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000250B0: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 0000000250B4: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 0000000250BC: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 0000000250C0: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000250C8: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 0000000250CC: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 0000000250D0: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000250D8: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 0000000250DC: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 0000000250E0: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000250E8: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 0000000250EC: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 0000000250F4: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 0000000250FC: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025108: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 00000002510C: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 000000025114: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 000000025120: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 000000025128: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 00000002512C: BE802001
	s_cbranch_execz 57309                                      // 000000025130: BFA5DFDD <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x34a8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 000000025134: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000025140: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000025148: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000002514C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025150: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000025154: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 00000002515C: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 000000025168: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002516C: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 000000025170: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 000000025174: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000002517C: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000025184: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 000000025188: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 00000002518C: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 000000025190: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025194: BF870095
	.long 0xd71c0001                                           // 000000025198: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 00000002519C: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000251A0: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000251A4: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000251AC: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 0000000251B0: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000251BC: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000251C0: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000251C4: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 0000000251CC: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000251D0: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 0000000251D4: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 0000000251DC: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 0000000251E0: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000251E8: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 0000000251EC: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 0000000251F0: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000251F8: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 0000000251FC: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 000000025200: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025208: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 00000002520C: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000025214: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 00000002521C: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025228: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 00000002522C: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 000000025234: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000025240: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000025248: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 00000002524C: BE802002
	s_cbranch_execz 57240                                      // 000000025250: BFA5DF98 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x34b4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 000000025254: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000025260: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000025268: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000002526C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025270: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000025274: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000002527C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 000000025288: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002528C: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 000000025290: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000025294: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000002529C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000252A4: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000252A8: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 0000000252AC: 7E041109
	v_exp_f32_e32 v1, v1                                       // 0000000252B0: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000252B4: BF870095
	.long 0xd71c0001                                           // 0000000252B8: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000252BC: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000252C0: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000252C4: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000252CC: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 0000000252D0: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000252DC: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000252E0: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000252E4: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000252EC: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000252F0: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 0000000252F4: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 0000000252FC: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 000000025300: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025308: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 00000002530C: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 000000025310: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025318: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 00000002531C: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 000000025320: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025328: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 00000002532C: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000025334: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 00000002533C: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025348: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000002534C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000025354: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000025360: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000025368: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 00000002536C: BE802003
	s_cbranch_execz 57171                                      // 000000025370: BFA5DF53 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x34c0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 000000025374: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000025380: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000025388: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000002538C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025390: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000025394: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000002539C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000253A8: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000253AC: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000253B0: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000253B4: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000253BC: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000253C4: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000253C8: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000253CC: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000253D0: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000253D4: BF870095
	.long 0xd71c0001                                           // 0000000253D8: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000253DC: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000253E0: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000253E4: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000253EC: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 0000000253F0: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000253FC: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025400: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000025404: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000002540C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025410: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000025414: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000002541C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000025420: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025428: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 00000002542C: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 000000025430: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025438: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 00000002543C: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 000000025440: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025448: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 00000002544C: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000025454: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 00000002545C: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025468: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000002546C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000025474: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000025480: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000025488: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000002548C: BE802004
	s_cbranch_execz 57102                                      // 000000025490: BFA5DF0E <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x34cc>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 000000025494: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000254A0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000254A8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000254AC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000254B0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000254B4: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000254BC: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000254C8: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000254CC: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000254D0: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000254D4: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000254DC: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000254E4: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000254E8: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000254EC: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000254F0: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000254F4: BF870095
	.long 0xd71c0001                                           // 0000000254F8: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000254FC: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000025500: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000025504: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002550C: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 000000025510: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 000000025518: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025520: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000025524: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000002552C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025530: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000025534: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000002553C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000025540: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025548: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000002554C: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 000000025550: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025558: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 00000002555C: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 000000025560: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025568: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000002556C: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000025574: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 00000002557C: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025588: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000002558C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000025594: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000255A0: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000255A8: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000000255AC: BE802005
	s_cbranch_execz 57033                                      // 0000000255B0: BFA5DEC9 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x34d8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 0000000255B4: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000255C0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000255C8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000255CC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000255D0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000255D4: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000255DC: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000255E8: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000255EC: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000255F0: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000255F4: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000255FC: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000025604: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000025608: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000002560C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000025610: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025614: BF870095
	.long 0xd71c0001                                           // 000000025618: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000002561C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000025620: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000025624: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002562C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 000000025630: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000002563C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025640: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000025644: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000002564C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025650: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000025654: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000002565C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000025660: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025668: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000002566C: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 000000025670: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025678: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000002567C: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 000000025680: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025688: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000002568C: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000025694: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 00000002569C: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000256A8: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000256AC: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000256B4: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000256C0: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000256C8: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000000256CC: BE802006
	s_cbranch_execz 56964                                      // 0000000256D0: BFA5DE84 <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x34e4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 0000000256D4: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000256E0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000256E8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000256EC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000256F0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000256F4: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000256FC: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000025708: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002570C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000025710: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000025714: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000002571C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000025724: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000025728: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000002572C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000025730: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025734: BF870095
	.long 0xd71c0001                                           // 000000025738: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000002573C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000025740: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000025744: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002574C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 000000025750: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000002575C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025760: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000025764: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000002576C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025770: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000025774: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000002577C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000025780: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025788: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000002578C: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 000000025790: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025798: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000002579C: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000257A0: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000257A8: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000257AC: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000257B4: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 0000000257BC: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000257C8: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000257CC: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000257D4: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000257E0: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000257E8: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000000257EC: BE802007
	s_cbranch_execz 56895                                      // 0000000257F0: BFA5DE3F <_ZN7halogen12_GLOBAL__N_19k_attn_faEPKtS2_S2_lS2_PtPKiii+0x34f0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 0000000257F4: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000025800: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000025808: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000002580C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025810: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000025814: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000002581C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000025828: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002582C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000025830: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000025834: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000002583C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000025844: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000025848: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000002584C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000025850: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025854: BF870095
	.long 0xd71c0001                                           // 000000025858: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000002585C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000025860: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000025864: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002586C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 000000025870: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000002587C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025880: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000025884: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000002588C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025890: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000025894: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000002589C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000258A0: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000258A8: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000258AC: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000258B0: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000258B8: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000258BC: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000258C0: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000258C8: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000258CC: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000258D4: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 0000000258DC: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000258E8: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000258EC: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000258F4: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000025900: DC9601E0 007C0200
	s_endpgm                                                   // 000000025908: BFB00000
		...

