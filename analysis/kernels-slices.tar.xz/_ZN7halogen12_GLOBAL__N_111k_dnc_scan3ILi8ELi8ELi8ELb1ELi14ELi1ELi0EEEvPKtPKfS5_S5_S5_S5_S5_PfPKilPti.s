00000000000b9300 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000B9300: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000B9304: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000B930C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000B9314: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000B9318: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000B931C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000B9320: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000B9328: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000B932C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000B9330: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000B9334: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000B933C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000B9340: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000B9344: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000B9348: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B934C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000B9350: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000B9354: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000B9358: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000B935C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000B9364: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000B936C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000B9370: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000B9374: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000B9378: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000B937C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000B9380: 821E191E
	.long 0xd7001f02                                           // 0000000B9384: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000B9388: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000B938C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000B9394: BE9E0080
	s_nop 0                                                    // 0000000B9398: BF800000
	s_nop 0                                                    // 0000000B939C: BF800000
	s_nop 0                                                    // 0000000B93A0: BF800000
	s_nop 0                                                    // 0000000B93A4: BF800000
	s_nop 0                                                    // 0000000B93A8: BF800000
	s_nop 0                                                    // 0000000B93AC: BF800000
	s_nop 0                                                    // 0000000B93B0: BF800000
	s_nop 0                                                    // 0000000B93B4: BF800000
	s_nop 0                                                    // 0000000B93B8: BF800000
	s_nop 0                                                    // 0000000B93BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000B93C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000B93C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B93CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000B93D0: 300C1089
	.long 0xd7006a06                                           // 0000000B93D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000B93D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B93DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000B93E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000B93E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000B93F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000B93F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000B93FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000B9408: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000B940C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000B9410: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000B9418: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000B941C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000B9420: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000B9424: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 0000000B942C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000B9434: 32040084
	s_mov_b32 s0, 0                                            // 0000000B9438: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000B943C: BF89FC07
	s_barrier                                                  // 0000000B9440: BFBD0000
	buffer_gl0_inv                                             // 0000000B9444: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000B944C: BF02801E
	s_cbranch_scc1 12                                          // 0000000B9450: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000B9454: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000B945C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B9464: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 0000000B9468: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000B9470: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000B9474: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000B9478: 916A007E
	s_cbranch_vccz 2                                           // 0000000B947C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2088                                              // 0000000B9480: BFA00828 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2224>
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000B9484: 304E0A82
	s_add_i32 s0, s30, 63                                      // 0000000B9488: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000B948C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000B9494: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000B9498: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000B949C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000B94A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000000B94A4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000000B94AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000B94B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000B94B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000B94B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000B94BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000B94C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000B94C4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000000B94C8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000B94D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000B94D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000B94DC: B00A0204
	.long 0xd7000b2c                                           // 0000000B94E0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 0000000B94E4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000B94E8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 0000000B94EC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 0000000B94F4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000B9500: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 0000000B9504: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 0000000B9510: 3816500A
	.long 0xd7000a05                                           // 0000000B9514: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000B9518: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B951C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000B9520: D5207C06 00290001
	.long 0xd7000107                                           // 0000000B9528: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000B952C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9530: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000B9534: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000B953C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000B9540: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000B9544: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000B954C: 84848E02
	.long 0xd700010b                                           // 0000000B9550: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000B9554: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000B9558: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000B955C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000B9564: 8205050F
	.long 0xd700010d                                           // 0000000B9568: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000B956C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9570: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000B9574: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000B957C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000B9580: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000B9588: D5207C10 00061880
	.long 0xd7000111                                           // 0000000B9590: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000B9594: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B959C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000B95A0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000B95A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000B95AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000B95B4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000B95BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000B95C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B95C8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000B95CC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000B95D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000B95D8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000B95E0: D5207C18 00061880
	.long 0xd7000119                                           // 0000000B95E8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000B95EC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B95F4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000B95F8: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000B9600: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000B9604: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 0000000B960C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 0000000B9614: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000B9618: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 0000000B9620: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 0000000B9624: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 0000000B962C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000B9634: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 0000000B963C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 0000000B9644: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 0000000B964C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 0000000B9654: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 0000000B965C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 0000000B9664: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 0000000B966C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 0000000B9674: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 0000000B967C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 0000000B9684: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 0000000B968C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 0000000B9694: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 0000000B969C: BE850080
	s_mov_b32 s6, 0x42800000                                   // 0000000B96A0: BE8600FF 42800000
	s_mov_b32 s7, 0x3c800000                                   // 0000000B96A8: BE8700FF 3C800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000B96B0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000B96B4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000B96BC: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000B96C0: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000B96C4: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B96C8: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000B96CC: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000B96D0: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000B96D4: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000B96D8: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000B96DC: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000B96E4: BE84206A
	s_cbranch_execz 77                                         // 0000000B96E8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x520>
	v_or_b32_e32 v29, s11, v0                                  // 0000000B96EC: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B96F0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000B96F4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000B96FC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9700: BF870091
	.long 0xd73c001d                                           // 0000000B9704: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000B9708: 02023A82
	.long 0xd700011d                                           // 0000000B970C: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000B9710: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B9714: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000B9718: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000B9720: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B9728: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000B972C: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000B9730: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000B973C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 0000000B9740: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 0000000B974C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000B9750: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000B975C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B9760: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 0000000B9764: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000B9770: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B9774: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 0000000B9778: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 0000000B9780: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000B9784: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 0000000B978C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000B9794: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 0000000B9798: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B979C: BF870193
	v_exp_f32_e32 v32, v32                                     // 0000000B97A0: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 0000000B97A4: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B97A8: BF870296
	.long 0xd71c0020                                           // 0000000B97AC: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000B97B0: 02024520
	.long 0xd71c001f                                           // 0000000B97B4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000B97B8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B97BC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000B97C0: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000B97C8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000B97CC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000B97D4: D5010020 00064080
	.long 0xd41e0001                                           // 0000000B97DC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000B97E0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B97E8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000B97EC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000B97F8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000B97FC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000B9804: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 0000000B9810: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 0000000B9818: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B9820: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000B9824: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000B982C: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B9830: BF89FC07
	s_barrier                                                  // 0000000B9834: BFBD0000
	buffer_gl0_inv                                             // 0000000B9838: E0AC0000 00000000
	s_branch 15                                                // 0000000B9840: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B9844: 8C7E047E
	.long 0xd700011d                                           // 0000000B9848: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000B984C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B9854: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B9858: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000B9860: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000B9864: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000B9868: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000B986C: BF89FC07
	s_barrier                                                  // 0000000B9870: BFBD0000
	buffer_gl0_inv                                             // 0000000B9874: E0AC0000 00000000
	s_cbranch_scc1 182                                         // 0000000B987C: BFA200B6 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x858>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000B9880: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 0000000B9888: CA100128 21220126
	s_mov_b32 s13, 0                                           // 0000000B9890: BE8D0080
	s_nop 0                                                    // 0000000B9894: BF800000
	s_nop 0                                                    // 0000000B9898: BF800000
	s_nop 0                                                    // 0000000B989C: BF800000
	s_nop 0                                                    // 0000000B98A0: BF800000
	s_nop 0                                                    // 0000000B98A4: BF800000
	s_nop 0                                                    // 0000000B98A8: BF800000
	s_nop 0                                                    // 0000000B98AC: BF800000
	s_nop 0                                                    // 0000000B98B0: BF800000
	s_nop 0                                                    // 0000000B98B4: BF800000
	s_nop 0                                                    // 0000000B98B8: BF800000
	s_nop 0                                                    // 0000000B98BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000000B98C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000B98C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000B98D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000B98D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B98DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000B98E0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000B98E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000B98EC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000B98F4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000B98F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000000B98FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000B9904: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000B990C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000B9910: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000B9914: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B9918: BF89FC07
	s_barrier                                                  // 0000000B991C: BFBD0000
	buffer_gl0_inv                                             // 0000000B9920: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000B9928: BE842000
	s_cbranch_execz 65477                                      // 0000000B992C: BFA5FFC5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	v_or3_b32 v31, s12, s11, v2                                // 0000000B9930: D658001F 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9938: BF870091
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 0000000B993C: D6FE7C1F 0009611F
	.long 0xd73c001f                                           // 0000000B9944: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 0000000B9948: 02023E89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B994C: BF870091
	.long 0xd700011f                                           // 0000000B9950: D700011F
	v_cndmask_b32_e32 v1, v44, v31, vcc_lo                     // 0000000B9954: 02023F2C
	v_add_co_ci_u32_e64 v32, null, v45, v32, s1                // 0000000B9958: D5207C20 0006412D
	s_mov_b32 s1, 0                                            // 0000000B9960: BE810080
	global_load_b32 v31, v[31:32], off                         // 0000000B9964: DC520000 1F7C001F
	v_mad_u64_u32 v[32:33], null, 0x44, s1, v[1:2]             // 0000000B996C: D6FE7C20 040402FF 00000044
	s_add_i32 s13, s1, 8                                       // 0000000B9978: 810D8801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000B997C: B6810078
	ds_load_2addr_b32 v[33:34], v32 offset1:17                 // 0000000B9980: D8DC1100 21000020
	ds_load_2addr_b32 v[35:36], v32 offset0:34 offset1:51      // 0000000B9988: D8DC3322 23000020
	ds_load_2addr_b32 v[60:61], v32 offset0:68 offset1:85      // 0000000B9990: D8DC5544 3C000020
	ds_load_2addr_b32 v[62:63], v32 offset0:102 offset1:119    // 0000000B9998: D8DC7766 3E000020
	v_lshl_add_u32 v32, s1, 2, v46                             // 0000000B99A0: D6460020 04B90401
	s_mov_b32 s1, s13                                          // 0000000B99A8: BE81000D
	ds_load_2addr_b32 v[64:65], v32 offset1:1                  // 0000000B99AC: D8DC0100 40000020
	ds_load_2addr_b32 v[66:67], v32 offset0:2 offset1:3        // 0000000B99B4: D8DC0302 42000020
	ds_load_2addr_b32 v[68:69], v32 offset0:4 offset1:5        // 0000000B99BC: D8DC0504 44000020
	ds_load_2addr_b32 v[70:71], v32 offset0:6 offset1:7        // 0000000B99C4: D8DC0706 46000020
	s_waitcnt lgkmcnt(7)                                       // 0000000B99CC: BF89FC77
	v_fma_mixlo_f16 v32, v33, s6, 0                            // 0000000B99D0: CC210020 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000B99D8: CC210022 02000D22
	s_waitcnt lgkmcnt(6)                                       // 0000000B99E0: BF89FC67
	v_fma_mixlo_f16 v35, v35, s6, 0                            // 0000000B99E4: CC210023 02000D23
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B99EC: BF870193
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B99F0: CC200020 8A000F20
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B99F8: CC200022 8A000F22
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000B9A00: BF870003
	v_fma_mix_f32 v35, v35, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9A04: CC200023 8A000F23
	s_waitcnt lgkmcnt(3)                                       // 0000000B9A0C: BF89FC37
	v_fma_mixlo_f16 v33, v64, s6, 0                            // 0000000B9A10: CC210021 02000D40
	v_fma_mixlo_f16 v64, v65, s6, 0                            // 0000000B9A18: CC210040 02000D41
	s_waitcnt lgkmcnt(2)                                       // 0000000B9A20: BF89FC27
	v_fma_mixlo_f16 v65, v66, s6, 0                            // 0000000B9A24: CC210041 02000D42
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B9A2C: BF870193
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9A30: CC200021 8A000F21
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9A38: CC200040 8A000F40
	s_waitcnt vmcnt(0)                                         // 0000000B9A40: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000B9A44: BF870242
	v_fma_f32 v31, -v33, v32, v31                              // 0000000B9A48: D613001F 247E4121
	v_fma_mixlo_f16 v32, v36, s6, 0                            // 0000000B9A50: CC210020 02000D24
	v_fma_mixlo_f16 v33, v67, s6, 0                            // 0000000B9A58: CC210021 02000D43
	v_fma_mix_f32 v36, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9A60: CC200024 8A000F41
	v_fma_f32 v31, -v64, v34, v31                              // 0000000B9A68: D613001F 247E4540
	v_fma_mixlo_f16 v34, v60, s6, 0                            // 0000000B9A70: CC210022 02000D3C
	s_waitcnt lgkmcnt(1)                                       // 0000000B9A78: BF89FC17
	v_fma_mixlo_f16 v60, v68, s6, 0                            // 0000000B9A7C: CC21003C 02000D44
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9A84: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9A8C: CC200021 8A000F21
	v_fma_f32 v31, -v36, v35, v31                              // 0000000B9A94: D613001F 247E4724
	v_fma_mixlo_f16 v35, v61, s6, 0                            // 0000000B9A9C: CC210023 02000D3D
	v_fma_mixlo_f16 v36, v69, s6, 0                            // 0000000B9AA4: CC210024 02000D45
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9AAC: CC200022 8A000F22
	v_fma_mix_f32 v60, v60, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9AB4: CC20003C 8A000F3C
	v_fma_f32 v31, -v33, v32, v31                              // 0000000B9ABC: D613001F 247E4121
	v_fma_mixlo_f16 v32, v62, s6, 0                            // 0000000B9AC4: CC210020 02000D3E
	s_waitcnt lgkmcnt(0)                                       // 0000000B9ACC: BF89FC07
	v_fma_mixlo_f16 v33, v70, s6, 0                            // 0000000B9AD0: CC210021 02000D46
	v_fma_mix_f32 v35, v35, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9AD8: CC200023 8A000F23
	v_fma_mix_f32 v36, v36, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9AE0: CC200024 8A000F24
	v_fma_f32 v31, -v60, v34, v31                              // 0000000B9AE8: D613001F 247E453C
	v_fma_mixlo_f16 v34, v63, s6, 0                            // 0000000B9AF0: CC210022 02000D3F
	v_fma_mixlo_f16 v60, v71, s6, 0                            // 0000000B9AF8: CC21003C 02000D47
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9B00: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9B08: CC200021 8A000F21
	v_fma_f32 v31, -v36, v35, v31                              // 0000000B9B10: D613001F 247E4724
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9B18: CC200022 8A000F22
	v_fma_mix_f32 v35, v60, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9B20: CC200023 8A000F3C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9B28: BF870093
	v_fma_f32 v31, -v33, v32, v31                              // 0000000B9B2C: D613001F 247E4121
	v_fma_f32 v31, -v35, v34, v31                              // 0000000B9B34: D613001F 247E4523
	s_cbranch_scc1 65419                                       // 0000000B9B3C: BFA2FF8B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x66c>
	v_mad_u64_u32 v[32:33], null, 0x44, s12, v[4:5]            // 0000000B9B40: D6FE7C20 041018FF 00000044
	ds_store_b32 v32, v31                                      // 0000000B9B4C: D8340000 00001F20
	s_branch 65339                                             // 0000000B9B54: BFA0FF3B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	v_mov_b32_e32 v30, v14                                     // 0000000B9B58: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000B9B5C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000B9B64: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 0000000B9B68: 7E46032B
	s_mov_b32 s12, 0                                           // 0000000B9B6C: BE8C0080
	s_branch 21                                                // 0000000B9B70: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8c8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000B9B74: 8C7E0D7E
	.long 0xd700011f                                           // 0000000B9B78: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000B9B7C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B9B84: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000B9B88: D5207C20 00064080
	.long 0xd700011d                                           // 0000000B9B90: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000B9B94: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 0000000B9B9C: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B9BA0: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000B9BA8: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000B9BAC: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000B9BB0: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000B9BB4: BC7C0000
	s_barrier                                                  // 0000000B9BB8: BFBD0000
	buffer_gl0_inv                                             // 0000000B9BBC: E0AC0000 00000000
	s_cbranch_scc1 606                                         // 0000000B9BC4: BFA2025E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1240>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B9BC8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000B9BCC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 0000000B9BD4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 0000000B9BD8: 7E780326
	s_mov_b32 s13, 0                                           // 0000000B9BDC: BE8D0080
	s_nop 0                                                    // 0000000B9BE0: BF800000
	s_nop 0                                                    // 0000000B9BE4: BF800000
	s_nop 0                                                    // 0000000B9BE8: BF800000
	s_nop 0                                                    // 0000000B9BEC: BF800000
	s_nop 0                                                    // 0000000B9BF0: BF800000
	s_nop 0                                                    // 0000000B9BF4: BF800000
	s_nop 0                                                    // 0000000B9BF8: BF800000
	s_nop 0                                                    // 0000000B9BFC: BF800000
	global_load_b32 v61, v[33:34], off                         // 0000000B9C00: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000000B9C08: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000000B9C10: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000B9C14: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B9C1C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000B9C20: D5207C22 00064480
	.long 0xd4490004                                           // 0000000B9C28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000000B9C2C: 020278FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000B9C34: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000B9C38: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 0000000B9C3C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 0000000B9C44: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000B9C4C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000B9C50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x900>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000B9C54: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B9C58: BF89FC07
	s_barrier                                                  // 0000000B9C5C: BFBD0000
	buffer_gl0_inv                                             // 0000000B9C60: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000B9C68: BE8D2000
	s_cbranch_execz 65473                                      // 0000000B9C6C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x874>
	v_or_b32_e32 v33, s12, v2                                  // 0000000B9C70: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9C74: BF870091
	v_or_b32_e32 v36, s11, v33                                 // 0000000B9C78: 3848420B
	.long 0xd4440001                                           // 0000000B9C7C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 0000000B9C80: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000B9C84: 8B7E017E
	s_cbranch_execz 65466                                      // 0000000B9C88: BFA5FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x874>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 0000000B9C8C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000B9C94: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:2 offset1:3        // 0000000B9C9C: D8DC0302 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 0000000B9CA4: D8DC3322 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:4 offset1:5        // 0000000B9CAC: D8DC0504 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:6 offset1:7        // 0000000B9CB4: D8DC0706 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 0000000B9CBC: D8DC5544 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:102 offset1:119     // 0000000B9CC4: D8DC7766 4A000001
	s_mov_b32 s14, 0                                           // 0000000B9CCC: BE8E0080
	s_waitcnt lgkmcnt(6)                                       // 0000000B9CD0: BF89FC67
	v_fma_f32 v76, v60, v62, 0                                 // 0000000B9CD4: D613004C 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9CDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B9CE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B9CE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B9CE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9CEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B9CF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B9CF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B9CF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9CFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B9D00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B9D04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B9D08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B9D0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B9D10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:8 offset1:9        // 0000000B9D14: D8DC0908 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 0000000B9D1C: D8DC9988 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:10 offset1:11      // 0000000B9D24: D8DC0B0A 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:170 offset1:187     // 0000000B9D2C: D8DCBBAA 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:12 offset1:13      // 0000000B9D34: D8DC0D0C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:14 offset1:15      // 0000000B9D3C: D8DC0F0E 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 0000000B9D44: D8DCDDCC 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:238 offset1:255     // 0000000B9D4C: D8DCFFEE 4A000001
	s_waitcnt lgkmcnt(6)                                       // 0000000B9D54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B9D58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9D5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B9D60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B9D64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B9D68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9D6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B9D70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B9D74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B9D78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9D7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B9D80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B9D84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B9D88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B9D8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B9D90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:16 offset1:17      // 0000000B9D94: D8DC1110 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:16 offset1:33      // 0000000B9D9C: D8DC2110 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:18 offset1:19      // 0000000B9DA4: D8DC1312 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000B9DAC: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:20 offset1:21      // 0000000B9DB4: D8DC1514 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:22 offset1:23      // 0000000B9DBC: D8DC1716 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:84 offset1:101     // 0000000B9DC4: D8DC6554 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000B9DCC: D8DC8776 4A000030
	s_waitcnt lgkmcnt(6)                                       // 0000000B9DD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B9DD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9DDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B9DE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B9DE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B9DE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9DEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B9DF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B9DF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B9DF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9DFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B9E00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B9E04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B9E08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B9E0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B9E10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 0000000B9E14: D8DC1918 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:152 offset1:169    // 0000000B9E1C: D8DCA998 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:26 offset1:27      // 0000000B9E24: D8DC1B1A 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:186 offset1:203    // 0000000B9E2C: D8DCCBBA 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:28 offset1:29      // 0000000B9E34: D8DC1D1C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000B9E3C: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:220 offset1:237    // 0000000B9E44: D8DCEDDC 48000030
	ds_load_2addr_b32 v[74:75], v49 offset0:126 offset1:143    // 0000000B9E4C: D8DC8F7E 4A000031
	s_waitcnt lgkmcnt(6)                                       // 0000000B9E54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B9E58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9E5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B9E60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B9E64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B9E68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9E6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B9E70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B9E74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B9E78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9E7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B9E80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B9E84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B9E88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B9E8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B9E90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:32 offset1:33      // 0000000B9E94: D8DC2120 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:32 offset1:49      // 0000000B9E9C: D8DC3120 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 0000000B9EA4: D8DC2322 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:66 offset1:83      // 0000000B9EAC: D8DC5342 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:36 offset1:37      // 0000000B9EB4: D8DC2524 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:38 offset1:39      // 0000000B9EBC: D8DC2726 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000B9EC4: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000B9ECC: D8DC9786 4A000032
	s_waitcnt lgkmcnt(6)                                       // 0000000B9ED4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B9ED8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9EDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B9EE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B9EE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B9EE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9EEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B9EF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B9EF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B9EF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9EFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B9F00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B9F04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B9F08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B9F0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B9F10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:40 offset1:41      // 0000000B9F14: D8DC2928 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:168 offset1:185    // 0000000B9F1C: D8DCB9A8 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:42 offset1:43      // 0000000B9F24: D8DC2B2A 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:202 offset1:219    // 0000000B9F2C: D8DCDBCA 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:44 offset1:45      // 0000000B9F34: D8DC2D2C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:46 offset1:47      // 0000000B9F3C: D8DC2F2E 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:236 offset1:253    // 0000000B9F44: D8DCFDEC 48000032
	ds_load_2addr_b32 v[74:75], v51 offset0:14 offset1:31      // 0000000B9F4C: D8DC1F0E 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000B9F54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B9F58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9F5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B9F60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B9F64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B9F68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9F6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B9F70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B9F74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B9F78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9F7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000B9F80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000B9F84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000B9F88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B9F8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000B9F90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 0000000B9F94: D8DC3130 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:48 offset1:65      // 0000000B9F9C: D8DC4130 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:50 offset1:51      // 0000000B9FA4: D8DC3332 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:82 offset1:99      // 0000000B9FAC: D8DC6352 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:52 offset1:53      // 0000000B9FB4: D8DC3534 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:54 offset1:55      // 0000000B9FBC: D8DC3736 4600002E
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000B9FC4: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000B9FCC: D8DCA796 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000B9FD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000B9FD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9FDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000B9FE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000B9FE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000B9FE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9FEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000B9FF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000B9FF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000B9FF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9FFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BA000: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BA004: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BA008: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BA00C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BA010: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:56 offset1:57      // 0000000BA014: D8DC3938 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:184 offset1:201    // 0000000BA01C: D8DCC9B8 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:58 offset1:59      // 0000000BA024: D8DC3B3A 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:218 offset1:235    // 0000000BA02C: D8DCEBDA 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:60 offset1:61      // 0000000BA034: D8DC3D3C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:62 offset1:63      // 0000000BA03C: D8DC3F3E 4600002E
	ds_load_2addr_b32 v[72:73], v52 offset0:124 offset1:141    // 0000000BA044: D8DC8D7C 48000034
	ds_load_2addr_b32 v[74:75], v53 offset0:30 offset1:47      // 0000000BA04C: D8DC2F1E 4A000035
	s_waitcnt lgkmcnt(6)                                       // 0000000BA054: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BA058: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA05C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BA060: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BA064: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BA068: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA06C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BA070: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BA074: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BA078: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA07C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BA080: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BA084: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BA088: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BA08C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BA090: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:64 offset1:65      // 0000000BA094: D8DC4140 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:64 offset1:81      // 0000000BA09C: D8DC5140 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:66 offset1:67      // 0000000BA0A4: D8DC4342 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:98 offset1:115     // 0000000BA0AC: D8DC7362 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:68 offset1:69      // 0000000BA0B4: D8DC4544 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:70 offset1:71      // 0000000BA0BC: D8DC4746 4600002E
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000BA0C4: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000BA0CC: D8DCB7A6 4A000035
	s_waitcnt lgkmcnt(6)                                       // 0000000BA0D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BA0D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA0DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BA0E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BA0E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BA0E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA0EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BA0F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BA0F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BA0F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA0FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BA100: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BA104: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BA108: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BA10C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BA110: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 0000000BA114: D8DC4948 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:200 offset1:217    // 0000000BA11C: D8DCD9C8 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:74 offset1:75      // 0000000BA124: D8DC4B4A 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:234 offset1:251    // 0000000BA12C: D8DCFBEA 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:76 offset1:77      // 0000000BA134: D8DC4D4C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:78 offset1:79      // 0000000BA13C: D8DC4F4E 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:12 offset1:29      // 0000000BA144: D8DC1D0C 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:46 offset1:63      // 0000000BA14C: D8DC3F2E 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000BA154: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BA158: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA15C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BA160: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BA164: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BA168: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA16C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BA170: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BA174: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BA178: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA17C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BA180: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BA184: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BA188: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BA18C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BA190: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:80 offset1:81      // 0000000BA194: D8DC5150 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:80 offset1:97      // 0000000BA19C: D8DC6150 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 0000000BA1A4: D8DC5352 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:114 offset1:131    // 0000000BA1AC: D8DC8372 42000036
	ds_load_2addr_b32 v[68:69], v46 offset0:84 offset1:85      // 0000000BA1B4: D8DC5554 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:86 offset1:87      // 0000000BA1BC: D8DC5756 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000BA1C4: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000BA1CC: D8DCC7B6 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000BA1D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BA1D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA1DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BA1E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BA1E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BA1E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA1EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BA1F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BA1F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BA1F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA1FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BA200: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BA204: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BA208: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BA20C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BA210: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:88 offset1:89      // 0000000BA214: D8DC5958 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:216 offset1:233    // 0000000BA21C: D8DCE9D8 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:90 offset1:91      // 0000000BA224: D8DC5B5A 4000002E
	ds_load_2addr_b32 v[66:67], v55 offset0:122 offset1:139    // 0000000BA22C: D8DC8B7A 42000037
	ds_load_2addr_b32 v[68:69], v46 offset0:92 offset1:93      // 0000000BA234: D8DC5D5C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:94 offset1:95      // 0000000BA23C: D8DC5F5E 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:28 offset1:45      // 0000000BA244: D8DC2D1C 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:62 offset1:79      // 0000000BA24C: D8DC4F3E 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000BA254: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BA258: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA25C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BA260: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BA264: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BA268: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA26C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BA270: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BA274: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BA278: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA27C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BA280: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BA284: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BA288: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BA28C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BA290: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 0000000BA294: D8DC6160 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:96 offset1:113     // 0000000BA29C: D8DC7160 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:98 offset1:99      // 0000000BA2A4: D8DC6362 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:130 offset1:147    // 0000000BA2AC: D8DC9382 42000038
	ds_load_2addr_b32 v[68:69], v46 offset0:100 offset1:101    // 0000000BA2B4: D8DC6564 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:102 offset1:103    // 0000000BA2BC: D8DC6766 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000BA2C4: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000BA2CC: D8DCD7C6 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000BA2D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BA2D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA2DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BA2E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BA2E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BA2E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA2EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BA2F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BA2F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BA2F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA2FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BA300: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BA304: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BA308: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BA30C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BA310: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:104 offset1:105    // 0000000BA314: D8DC6968 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:232 offset1:249    // 0000000BA31C: D8DCF9E8 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 0000000BA324: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:10 offset1:27      // 0000000BA32C: D8DC1B0A 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:108 offset1:109    // 0000000BA334: D8DC6D6C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:110 offset1:111    // 0000000BA33C: D8DC6F6E 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:44 offset1:61      // 0000000BA344: D8DC3D2C 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:78 offset1:95      // 0000000BA34C: D8DC5F4E 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000BA354: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BA358: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA35C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BA360: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BA364: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BA368: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA36C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BA370: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BA374: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BA378: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA37C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BA380: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BA384: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BA388: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BA38C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BA390: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:112 offset1:113    // 0000000BA394: D8DC7170 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:112 offset1:129    // 0000000BA39C: D8DC8170 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:114 offset1:115    // 0000000BA3A4: D8DC7372 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:146 offset1:163    // 0000000BA3AC: D8DCA392 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:116 offset1:117    // 0000000BA3B4: D8DC7574 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:118 offset1:119    // 0000000BA3BC: D8DC7776 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000BA3C4: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000BA3CC: D8DCE7D6 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000BA3D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BA3D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA3DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BA3E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000BA3E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BA3E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA3EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BA3F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000BA3F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BA3F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BA3FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BA400: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000BA404: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BA408: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BA40C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BA410: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 0000000BA414: D8DC7978 3C00002E
	ds_load_2addr_b32 v[62:63], v58 offset0:120 offset1:137    // 0000000BA41C: D8DC8978 3E00003A
	ds_load_2addr_b32 v[64:65], v46 offset0:122 offset1:123    // 0000000BA424: D8DC7B7A 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:26 offset1:43      // 0000000BA42C: D8DC2B1A 4200003B
	ds_load_2addr_b32 v[68:69], v46 offset0:124 offset1:125    // 0000000BA434: D8DC7D7C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:126 offset1:127    // 0000000BA43C: D8DC7F7E 4600002E
	ds_load_2addr_b32 v[72:73], v59 offset0:60 offset1:77      // 0000000BA444: D8DC4D3C 4800003B
	ds_load_2addr_b32 v[74:75], v59 offset0:94 offset1:111     // 0000000BA44C: D8DC6F5E 4A00003B
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000000BA454: 30424282
	s_waitcnt lgkmcnt(6)                                       // 0000000BA458: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000BA45C: 56987D3C
	ds_load_b32 v60, v33 offset:17440                          // 0000000BA460: D8D84420 3C000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000BA468: CA10011E 2220011D
	v_mov_b32_e32 v62, v35                                     // 0000000BA470: 7E7C0323
	v_fmac_f32_e32 v76, v61, v63                               // 0000000BA474: 56987F3D
	v_mov_b32_e32 v61, v1                                      // 0000000BA478: 7E7A0301
	s_waitcnt lgkmcnt(5)                                       // 0000000BA47C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA480: BF870092
	v_fmac_f32_e32 v76, v64, v66                               // 0000000BA484: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 0000000BA488: 56988741
	s_waitcnt lgkmcnt(2)                                       // 0000000BA48C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA490: BF870091
	v_fmac_f32_e32 v76, v68, v72                               // 0000000BA494: 56989144
	v_fmac_f32_e32 v76, v69, v73                               // 0000000BA498: 56989345
	s_waitcnt lgkmcnt(1)                                       // 0000000BA49C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA4A0: BF870091
	v_fmac_f32_e32 v76, v70, v74                               // 0000000BA4A4: 56989546
	v_fmac_f32_e32 v76, v71, v75                               // 0000000BA4A8: 56989747
	s_waitcnt lgkmcnt(0)                                       // 0000000BA4AC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BA4B0: BF870001
	v_mul_f32_e32 v60, v76, v60                                // 0000000BA4B4: 1078794C
	s_nop 0                                                    // 0000000BA4B8: BF800000
	s_nop 0                                                    // 0000000BA4BC: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000BA4C0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000BA4C8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000BA4D0: 4A7C7CC1
	.long 0xd7000121                                           // 0000000BA4D4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000BA4D8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000BA4DC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000BA4E0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000BA4E8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000BA4EC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000BA4F0: 4A7A7AFF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000BA4F8: 8C0E0E04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BA4FC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 0000000BA500: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000BA504: 917E0E7E
	s_cbranch_execnz 65517                                     // 0000000BA508: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11c0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000BA50C: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA510: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 0000000BA514: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 0000000BA51C: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 0000000BA528: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 0000000BA534: DC960000 007C2421
	s_branch 64909                                             // 0000000BA53C: BFA0FD8D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x874>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000BA540: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 0000000BA548: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000BA54C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000BA550: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000BA558: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000BA55C: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000BA564: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000BA56C: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000BA570: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000BA574: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000BA57C: A0010401
	s_mov_b32 s4, 0                                            // 0000000BA580: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000BA584: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000BA588: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000BA58C: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000BA590: BF870585
	.long 0xd71c001d                                           // 0000000BA594: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000BA598: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000BA59C: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000BA5A0: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000BA5A8: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000BA5AC: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000BA5B4: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000000BA5B8: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000BA5BC: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000BA5C8: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000BA5D0: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BA5D8: BF870001
	.long 0xd4490001                                           // 0000000BA5DC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000BA5E0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000BA5E8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000BA5EC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000BA5F0: 1040411E
	ds_store_b32 v29, v32                                      // 0000000BA5F4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000BA5FC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BA604: 917E047E
	s_cbranch_execnz 65519                                     // 0000000BA608: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x12c8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BA60C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000BA610: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 0000000BA618: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 0000000BA620: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BA624: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BA628: BF89FC07
	s_barrier                                                  // 0000000BA62C: BFBD0000
	buffer_gl0_inv                                             // 0000000BA630: E0AC0000 00000000
	s_nop 0                                                    // 0000000BA638: BF800000
	s_nop 0                                                    // 0000000BA63C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BA640: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 0000000BA648: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BA650: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BA658: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BA65C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000BA664: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BA668: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BA670: BF870004
	.long 0xd4490004                                           // 0000000BA674: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BA678: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BA680: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BA684: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BA688: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 0000000BA68C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000BA694: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BA69C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BA6A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1340>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BA6A4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000BA6A8: BF89FC07
	s_barrier                                                  // 0000000BA6AC: BFBD0000
	buffer_gl0_inv                                             // 0000000BA6B0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000000BA6B8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 0000000BA6C0: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 0000000BA6C8: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 0000000BA6D0: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000BA6D8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000BA6DC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BA6E0: BF840001
	s_nop 0                                                    // 0000000BA6E4: BF800000
	s_nop 0                                                    // 0000000BA6E8: BF800000
	s_nop 0                                                    // 0000000BA6EC: BF800000
	s_nop 0                                                    // 0000000BA6F0: BF800000
	s_nop 0                                                    // 0000000BA6F4: BF800000
	s_nop 0                                                    // 0000000BA6F8: BF800000
	s_nop 0                                                    // 0000000BA6FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA700: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000BA704: 327A7884
	.long 0xd4490001                                           // 0000000BA708: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000BA70C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000BA714: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000BA718: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BA724: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000BA728: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000BA730: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000BA738: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000BA740: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000BA748: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000BA750: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000BA758: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000BA760: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000BA764: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BA770: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000BA774: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000BA778: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000BA780: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000BA784: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000BA788: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000BA78C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA790: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000BA794: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000BA798: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000BA79C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA7A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000BA7A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000BA7B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000BA7B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BA7C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BA7C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1400>
	s_set_inst_prefetch_distance 0x2                           // 0000000BA7C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BA7CC: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 0000000BA7D0: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BA7D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BA7E0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BA7E4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BA7E8: BF89FC07
	s_barrier                                                  // 0000000BA7EC: BFBD0000
	buffer_gl0_inv                                             // 0000000BA7F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000BA7F8: BF800000
	s_nop 0                                                    // 0000000BA7FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BA800: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 0000000BA808: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BA810: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BA818: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BA81C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BA824: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BA828: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BA830: BF870004
	.long 0xd4490004                                           // 0000000BA834: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BA838: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BA840: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BA844: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BA848: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BA84C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BA854: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BA85C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BA860: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1500>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BA864: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000BA868: BF89FC07
	s_barrier                                                  // 0000000BA86C: BFBD0000
	buffer_gl0_inv                                             // 0000000BA870: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000000BA878: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 0000000BA880: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 0000000BA888: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 0000000BA890: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000BA898: 7E780300
	s_mov_b32 s4, 0                                            // 0000000BA89C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BA8A0: BF840001
	s_nop 0                                                    // 0000000BA8A4: BF800000
	s_nop 0                                                    // 0000000BA8A8: BF800000
	s_nop 0                                                    // 0000000BA8AC: BF800000
	s_nop 0                                                    // 0000000BA8B0: BF800000
	s_nop 0                                                    // 0000000BA8B4: BF800000
	s_nop 0                                                    // 0000000BA8B8: BF800000
	s_nop 0                                                    // 0000000BA8BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BA8C0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000BA8C4: 327A7884
	.long 0xd4490001                                           // 0000000BA8C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000BA8CC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000BA8D4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000BA8D8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BA8E4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000BA8E8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000BA8F0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000BA8F8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000BA900: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000BA908: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000BA910: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000BA918: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000BA920: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000BA924: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BA930: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000BA934: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000BA938: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000BA940: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000BA944: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000BA948: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000BA94C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA950: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000BA954: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000BA958: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000BA95C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BA960: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000BA964: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000BA970: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000BA978: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BA980: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BA984: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000BA988: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BA98C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 0000000BA990: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BA998: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BA9A0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BA9A4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BA9A8: BF89FC07
	s_barrier                                                  // 0000000BA9AC: BFBD0000
	buffer_gl0_inv                                             // 0000000BA9B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000BA9B8: BF800000
	s_nop 0                                                    // 0000000BA9BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BA9C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 0000000BA9C8: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BA9D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BA9D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BA9DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BA9E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BA9E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BA9F0: BF870004
	.long 0xd4490004                                           // 0000000BA9F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BA9F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BAA00: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BAA04: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BAA08: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BAA0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BAA14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BAA1C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BAA20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x16c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BAA24: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 0000000BAA28: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000BAA30: BF89FC07
	s_barrier                                                  // 0000000BAA34: BFBD0000
	buffer_gl0_inv                                             // 0000000BAA38: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000BAA40: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 0000000BAA44: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 0000000BAA4C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 0000000BAA54: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 0000000BAA5C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000000BAA64: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BAA68: BF840001
	s_nop 0                                                    // 0000000BAA6C: BF800000
	s_nop 0                                                    // 0000000BAA70: BF800000
	s_nop 0                                                    // 0000000BAA74: BF800000
	s_nop 0                                                    // 0000000BAA78: BF800000
	s_nop 0                                                    // 0000000BAA7C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000BAA80: 327C7A84
	.long 0xd4490001                                           // 0000000BAA84: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000BAA88: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BAA90: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000BAA94: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000BAA98: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BAAA4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000BAAA8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000BAAB0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000BAAB8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000BAAC0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000BAAC8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000BAAD0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000BAAD8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000BAAE0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000BAAE4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BAAE8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000BAAEC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000BAAF8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000BAB00: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000BAB04: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000BAB08: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000BAB0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAB10: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000BAB14: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000BAB18: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000BAB1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAB20: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000BAB24: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000BAB30: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000BAB38: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BAB40: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BAB44: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1780>
	s_set_inst_prefetch_distance 0x2                           // 0000000BAB48: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BAB4C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 0000000BAB50: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BAB58: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BAB60: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BAB64: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BAB68: BF89FC07
	s_barrier                                                  // 0000000BAB6C: BFBD0000
	buffer_gl0_inv                                             // 0000000BAB70: E0AC0000 00000000
	s_nop 0                                                    // 0000000BAB78: BF800000
	s_nop 0                                                    // 0000000BAB7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BAB80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 0000000BAB88: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BAB90: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BAB98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BAB9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BABA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BABA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BABB0: BF870004
	.long 0xd4490004                                           // 0000000BABB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BABB8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BABC0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BABC4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BABC8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BABCC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BABD4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BABDC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BABE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1880>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BABE4: 8C7E0A7E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000000BABE8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000BABF0: BF89FC07
	s_barrier                                                  // 0000000BABF4: BFBD0000
	buffer_gl0_inv                                             // 0000000BABF8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 0000000BAC00: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 0000000BAC08: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 0000000BAC10: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 0000000BAC18: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000BAC20: 7E780300
	s_mov_b32 s4, 0                                            // 0000000BAC24: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BAC28: BF840001
	s_nop 0                                                    // 0000000BAC2C: BF800000
	s_nop 0                                                    // 0000000BAC30: BF800000
	s_nop 0                                                    // 0000000BAC34: BF800000
	s_nop 0                                                    // 0000000BAC38: BF800000
	s_nop 0                                                    // 0000000BAC3C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BAC40: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000BAC44: 327A7884
	.long 0xd4490001                                           // 0000000BAC48: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000BAC4C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000BAC54: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000BAC58: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BAC64: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000BAC68: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000BAC70: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000BAC78: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000BAC80: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000BAC88: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000BAC90: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000BAC98: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000BACA0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000BACA4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BACB0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000BACB4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000BACB8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000BACC0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000BACC4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000BACC8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000BACCC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BACD0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000BACD4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000BACD8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000BACDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BACE0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000BACE4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000BACF0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000BACF8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BAD00: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BAD04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1940>
	s_set_inst_prefetch_distance 0x2                           // 0000000BAD08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BAD0C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 0000000BAD10: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BAD18: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BAD20: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BAD24: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BAD28: BF89FC07
	s_barrier                                                  // 0000000BAD2C: BFBD0000
	buffer_gl0_inv                                             // 0000000BAD30: E0AC0000 00000000
	s_nop 0                                                    // 0000000BAD38: BF800000
	s_nop 0                                                    // 0000000BAD3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BAD40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 0000000BAD48: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BAD50: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BAD58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BAD5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BAD64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BAD68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BAD70: BF870004
	.long 0xd4490004                                           // 0000000BAD74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BAD78: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BAD80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BAD84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BAD88: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BAD8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BAD94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BAD9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BADA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a40>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BADA4: 8C7E0A7E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 0000000BADA8: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000000BADB0: BF89FC07
	s_barrier                                                  // 0000000BADB4: BFBD0000
	buffer_gl0_inv                                             // 0000000BADB8: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 0000000BADC0: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 0000000BADC4: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 0000000BADCC: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 0000000BADD4: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 0000000BADDC: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000000BADE4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BADE8: BF840001
	s_nop 0                                                    // 0000000BADEC: BF800000
	s_nop 0                                                    // 0000000BADF0: BF800000
	s_nop 0                                                    // 0000000BADF4: BF800000
	s_nop 0                                                    // 0000000BADF8: BF800000
	s_nop 0                                                    // 0000000BADFC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 0000000BAE00: 327C7884
	.long 0xd4490001                                           // 0000000BAE04: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000BAE08: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BAE10: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000BAE14: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000BAE18: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BAE24: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000BAE28: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000BAE30: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000BAE38: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000BAE40: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000BAE48: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000BAE50: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000BAE58: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000BAE60: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000BAE64: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BAE68: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000BAE6C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000BAE78: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000BAE80: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000BAE84: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000BAE88: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000BAE8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAE90: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000BAE94: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000BAE98: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000BAE9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BAEA0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000000BAEA4: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 0000000BAEB0: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BAEB4: BF870002
	v_mov_b32_e32 v60, v63                                     // 0000000BAEB8: 7E78033F
	ds_store_b32 v62, v70                                      // 0000000BAEBC: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BAEC4: 917E047E
	s_cbranch_execnz 65485                                     // 0000000BAEC8: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b00>
	s_set_inst_prefetch_distance 0x2                           // 0000000BAECC: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BAED0: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 0000000BAED4: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BAEDC: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BAEE4: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BAEE8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BAEEC: BF89FC07
	s_barrier                                                  // 0000000BAEF0: BFBD0000
	buffer_gl0_inv                                             // 0000000BAEF4: E0AC0000 00000000
	s_nop 0                                                    // 0000000BAEFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BAF00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 0000000BAF08: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BAF10: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BAF18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BAF1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BAF24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BAF28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BAF30: BF870004
	.long 0xd4490004                                           // 0000000BAF34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BAF38: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BAF40: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BAF44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BAF48: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BAF4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BAF54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BAF5C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BAF60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BAF64: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 0000000BAF68: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000BAF70: BF89FC07
	s_barrier                                                  // 0000000BAF74: BFBD0000
	buffer_gl0_inv                                             // 0000000BAF78: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 0000000BAF80: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 0000000BAF88: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 0000000BAF90: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 0000000BAF98: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000BAFA0: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000BAFA4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BAFA8: BF840001
	s_nop 0                                                    // 0000000BAFAC: BF800000
	s_nop 0                                                    // 0000000BAFB0: BF800000
	s_nop 0                                                    // 0000000BAFB4: BF800000
	s_nop 0                                                    // 0000000BAFB8: BF800000
	s_nop 0                                                    // 0000000BAFBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BAFC0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000BAFC4: 327C7A84
	.long 0xd4490001                                           // 0000000BAFC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000BAFCC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000BAFD4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000BAFD8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BAFE4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000BAFE8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000BAFF0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000BAFF8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000BB000: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000BB008: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000BB010: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000BB018: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000BB020: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000BB024: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BB028: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000BB02C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000BB038: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000BB040: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000BB044: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000BB048: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000BB04C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB050: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000BB054: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000BB058: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000BB05C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB060: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000BB064: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000BB070: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000BB078: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BB080: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BB084: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	s_set_inst_prefetch_distance 0x2                           // 0000000BB088: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BB08C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 0000000BB090: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BB098: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BB0A0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BB0A4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BB0A8: BF89FC07
	s_barrier                                                  // 0000000BB0AC: BFBD0000
	buffer_gl0_inv                                             // 0000000BB0B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000BB0B8: BF800000
	s_nop 0                                                    // 0000000BB0BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BB0C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 0000000BB0C8: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BB0D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BB0D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BB0DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BB0E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BB0E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BB0F0: BF870004
	.long 0xd4490004                                           // 0000000BB0F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BB0F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BB100: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BB104: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BB108: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BB10C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BB114: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BB11C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BB120: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dc0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BB124: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000BB128: BF89FC07
	s_barrier                                                  // 0000000BB12C: BFBD0000
	buffer_gl0_inv                                             // 0000000BB130: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 0000000BB138: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 0000000BB140: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 0000000BB148: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 0000000BB150: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000BB158: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000BB15C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BB160: BF840001
	s_nop 0                                                    // 0000000BB164: BF800000
	s_nop 0                                                    // 0000000BB168: BF800000
	s_nop 0                                                    // 0000000BB16C: BF800000
	s_nop 0                                                    // 0000000BB170: BF800000
	s_nop 0                                                    // 0000000BB174: BF800000
	s_nop 0                                                    // 0000000BB178: BF800000
	s_nop 0                                                    // 0000000BB17C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BB180: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000BB184: 327C7A84
	.long 0xd4490001                                           // 0000000BB188: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000BB18C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000BB194: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000BB198: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BB1A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000BB1A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000BB1B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000BB1B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000BB1C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000BB1C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000BB1D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000BB1D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000BB1E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000BB1E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BB1E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000BB1EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000BB1F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000BB200: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000BB204: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000BB208: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000BB20C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB210: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000BB214: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000BB218: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000BB21C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB220: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000BB224: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000BB230: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000BB238: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BB240: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BB244: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e80>
	s_set_inst_prefetch_distance 0x2                           // 0000000BB248: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BB24C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000BB250: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BB258: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BB260: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BB264: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BB268: BF89FC07
	s_barrier                                                  // 0000000BB26C: BFBD0000
	buffer_gl0_inv                                             // 0000000BB270: E0AC0000 00000000
	s_nop 0                                                    // 0000000BB278: BF800000
	s_nop 0                                                    // 0000000BB27C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BB280: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 0000000BB288: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BB290: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BB298: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BB29C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BB2A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BB2A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BB2B0: BF870004
	.long 0xd4490004                                           // 0000000BB2B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BB2B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BB2C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BB2C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BB2C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BB2CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BB2D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BB2DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BB2E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BB2E4: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 0000000BB2E8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 0000000BB2F0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000BB2F8: BF89FC07
	s_barrier                                                  // 0000000BB2FC: BFBD0000
	buffer_gl0_inv                                             // 0000000BB300: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 0000000BB308: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 0000000BB310: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000BB318: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 0000000BB320: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000BB328: 7E780300
	s_mov_b32 s4, 0                                            // 0000000BB32C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BB330: BF840001
	s_nop 0                                                    // 0000000BB334: BF800000
	s_nop 0                                                    // 0000000BB338: BF800000
	s_nop 0                                                    // 0000000BB33C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BB340: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000BB344: 327A7884
	.long 0xd4490001                                           // 0000000BB348: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000BB34C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000BB354: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000BB358: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BB364: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000BB368: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000BB370: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000BB378: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000BB380: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000BB388: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000BB390: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000BB398: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000BB3A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000BB3A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BB3B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000BB3B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000BB3B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000BB3C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000BB3C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000BB3C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000BB3CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB3D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000BB3D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000BB3D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000BB3DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB3E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000BB3E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000BB3F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000BB3F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BB400: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BB404: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_set_inst_prefetch_distance 0x2                           // 0000000BB408: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BB40C: 8C7E047E
	.long 0xd7000107                                           // 0000000BB410: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000BB414: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BB41C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000BB420: D5207C08 00061080
	.long 0xd7000109                                           // 0000000BB428: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000BB42C: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000BB434: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000BB43C: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000BB440: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BB448: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000BB44C: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000BB454: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000BB458: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000BB460: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000BB468: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000BB46C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BB474: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000BB478: D5207C10 00062080
	.long 0xd7000111                                           // 0000000BB480: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000BB484: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000BB48C: D5207C12 00062480
	.long 0xd7000113                                           // 0000000BB494: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000BB498: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BB4A0: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000BB4A4: D5207C14 00062880
	.long 0xd7000115                                           // 0000000BB4AC: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000BB4B0: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000BB4B8: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000BB4C0: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000BB4C4: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BB4CC: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000BB4D0: D5207C18 00063080
	.long 0xd7000119                                           // 0000000BB4D8: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000BB4DC: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000BB4E4: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000BB4EC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000BB4F0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BB4F8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000BB4FC: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000BB504: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000BB508: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000BB50C: BF062105
	s_barrier                                                  // 0000000BB510: BFBD0000
	buffer_gl0_inv                                             // 0000000BB514: E0AC0000 00000000
	s_cbranch_scc0 63589                                       // 0000000BB51C: BFA1F865 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b4>
	v_mov_b32_e32 v4, v38                                      // 0000000BB520: 7E080326
	s_add_u32 s0, s28, s20                                     // 0000000BB524: 8000141C
	.long 0xd73c0000                                           // 0000000BB528: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000BB52C: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000BB530: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000BB534: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000BB538: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000BB53C: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000BB540: 82010103
	.long 0xd7006a00                                           // 0000000BB544: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000BB548: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000BB54C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000BB550: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000BB558: BE810080
	.long 0xd7006a00                                           // 0000000BB55C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 0000000BB560: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000BB564: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB56C: BF870092
	.long 0xd7006a00                                           // 0000000BB570: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000BB574: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000BB578: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 0000000BB580: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000BB588: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 0000000BB590: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000BB598: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000BB59C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000BB5A4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000BB5A8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000BB5AC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000BB5B4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000BB5B8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000BB5C0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000BB5C8: 917E017E
	s_cbranch_execnz 65516                                     // 0000000BB5CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2280>
	s_endpgm                                                   // 0000000BB5D0: BFB00000
		...

