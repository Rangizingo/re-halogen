0000000000077700 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000077700: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 000000077704: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000007770C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 000000077714: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 000000077718: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000007771C: 861B9F1A
	v_dual_mov_b32 v5, v0 :: v_dual_and_b32 v4, 15, v0         // 000000077720: CA240100 0504008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000077728: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v4                                // 00000007772C: 30020882
	s_waitcnt lgkmcnt(0)                                       // 000000077730: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 000000077734: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000007773C: 84928214
	s_add_u32 s25, s16, s18                                    // 000000077740: 80191210
	s_addc_u32 s28, s17, s19                                   // 000000077744: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 000000077748: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007774C: BF870009
	s_add_u32 s25, s25, s20                                    // 000000077750: 80191419
	s_addc_u32 s30, s28, s21                                   // 000000077754: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 000000077758: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000007775C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 000000077764: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000007776C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 000000077770: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 000000077774: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000077778: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000007777C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 000000077780: 821E191E
	.long 0xd7001f02                                           // 000000077784: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 000000077788: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000007778C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 000000077794: BE9E0080
	s_nop 0                                                    // 000000077798: BF800000
	s_nop 0                                                    // 00000007779C: BF800000
	s_nop 0                                                    // 0000000777A0: BF800000
	s_nop 0                                                    // 0000000777A4: BF800000
	s_nop 0                                                    // 0000000777A8: BF800000
	s_nop 0                                                    // 0000000777AC: BF800000
	s_nop 0                                                    // 0000000777B0: BF800000
	s_nop 0                                                    // 0000000777B4: BF800000
	s_nop 0                                                    // 0000000777B8: BF800000
	s_nop 0                                                    // 0000000777BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v5                                // 0000000777C0: 32100A84
	v_add_nc_u32_e32 v10, 0x80, v5                             // 0000000777C4: 4A140AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000777CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000777D0: 300C1089
	.long 0xd7006a06                                           // 0000000777D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000777D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000777DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000777E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v5                         // 0000000777E8: 7C920AFF 0000077F
	v_mov_b32_e32 v5, v10                                      // 0000000777F0: 7E0A030A
	global_load_b32 v9, v[6:7], off                            // 0000000777F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000777FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 000000077808: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000007780C: BF8903F7
	ds_store_b32 v6, v9                                        // 000000077810: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 000000077818: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000007781C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 000000077820: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 000000077824: F4000780 F8000058
	v_or_b32_e32 v49, 0xffffff80, v0                           // 00000007782C: 386200FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 000000077834: 32040084
	s_mov_b32 s0, 0                                            // 000000077838: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000007783C: BF89FC07
	s_barrier                                                  // 000000077840: BFBD0000
	buffer_gl0_inv                                             // 000000077844: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000007784C: BF02801E
	s_cbranch_scc1 12                                          // 000000077850: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 000000077854: 160604FF 00000044
	v_or_b32_e32 v5, 0xffffff80, v0                            // 00000007785C: 380A00FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000077864: BF870002
	v_lshl_add_u32 v48, v4, 2, v3                              // 000000077868: D6460030 040D0504
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v50, 2, v4      // 000000077870: CA220080 03320882
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000077878: 916A007E
	s_cbranch_vccz 2                                           // 00000007787C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 3374                                              // 000000077880: BFA00D2E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x363c>
	v_lshlrev_b32_e32 v50, 2, v4                               // 000000077884: 30640882
	s_add_i32 s0, s30, 63                                      // 000000077888: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000007788C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 000000077894: 85218600
	s_add_u32 s34, s10, s24                                    // 000000077898: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000007789C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000778A0: 84008702
	v_lshlrev_b32_e32 v51, 2, v0                               // 0000000778A4: 30660082
	s_ashr_i32 s1, s0, 31                                      // 0000000778A8: 86019F00
	v_lshlrev_b32_e32 v4, 1, v4                                // 0000000778AC: 30080881
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000778B0: 84808100
	v_lshlrev_b32_e32 v24, 8, v2                               // 0000000778B4: 30300488
	s_add_u32 s22, s22, s0                                     // 0000000778B8: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000778BC: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000778C0: 848A811A
	v_mad_u32_u24 v48, 0x44, v2, v50                           // 0000000778C4: D60B0030 04CA04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000778D0: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000778D4: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000778D8: B00A0204
	.long 0xd7000b37                                           // 0000000778DC: D7000B37
	v_cndmask_b32_e32 v1, s34, v50, vcc_lo                     // 0000000778E0: 02026422
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000778E4: BF8704B1
	v_add_co_ci_u32_e64 v56, null, s35, 0, s11                 // 0000000778E8: D5207C38 002D0023
	v_mad_u32_u24 v57, v2, s10, 0x3300                         // 0000000778F0: D60B0039 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000778FC: 848A8902
	v_dual_mov_b32 v27, s11 :: v_dual_add_nc_u32 v54, 1, v2    // 000000077900: CA20000B 1B360481
	v_or_b32_e32 v26, s10, v51                                 // 000000077908: 3834660A
	.long 0xd7000a04                                           // 00000007790C: D7000A04
	v_cndmask_b32_e32 v1, s22, v4, vcc_lo                      // 000000077910: 02020816
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000077914: BF870191
	v_add_co_ci_u32_e64 v5, null, s1, 0, s10                   // 000000077918: D5207C05 00290001
	.long 0xd700011c                                           // 000000077920: D700011C
	v_cndmask_b32_e32 v1, 0x30000, v26, vcc_lo                 // 000000077924: 020234FF 00030000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007792C: BF8700A1
	v_add_co_ci_u32_e64 v29, null, 0, v27, s1                  // 000000077930: D5207C1D 00063680
	.long 0xd7000106                                           // 000000077938: D7000106
	v_cndmask_b32_e32 v1, s12, v26, vcc_lo                     // 00000007793C: 0202340C
	v_add_co_ci_u32_e64 v7, null, s13, v27, s1                 // 000000077940: D5207C07 0006360D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077948: BF870094
	.long 0xd7000108                                           // 00000007794C: D7000108
	v_cndmask_b32_e32 v1, s12, v28, vcc_lo                     // 000000077950: 0202380C
	v_add_co_ci_u32_e64 v9, null, s13, v29, s1                 // 000000077954: D5207C09 00063A0D
	.long 0xd700011e                                           // 00000007795C: D700011E
	v_cndmask_b32_e32 v1, 0x60000, v26, vcc_lo                 // 000000077960: 020234FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000077968: BF8700A1
	v_add_co_ci_u32_e64 v31, null, 0, v27, s1                  // 00000007796C: D5207C1F 00063680
	.long 0xd7000120                                           // 000000077974: D7000120
	v_cndmask_b32_e32 v1, 0x90000, v26, vcc_lo                 // 000000077978: 020234FF 00090000
	v_add_co_ci_u32_e64 v33, null, 0, v27, s1                  // 000000077980: D5207C21 00063680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077988: BF870094
	.long 0xd700010a                                           // 00000007798C: D700010A
	v_cndmask_b32_e32 v1, s12, v30, vcc_lo                     // 000000077990: 02023C0C
	v_add_co_ci_u32_e64 v11, null, s13, v31, s1                // 000000077994: D5207C0B 00063E0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007799C: BF870094
	.long 0xd700010c                                           // 0000000779A0: D700010C
	v_cndmask_b32_e32 v1, s12, v32, vcc_lo                     // 0000000779A4: 0202400C
	v_add_co_ci_u32_e64 v13, null, s13, v33, s1                // 0000000779A8: D5207C0D 0006420D
	.long 0xd7000122                                           // 0000000779B0: D7000122
	v_cndmask_b32_e32 v1, 0xc0000, v26, vcc_lo                 // 0000000779B4: 020234FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000779BC: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v27, s1                  // 0000000779C0: D5207C23 00063680
	.long 0xd7000124                                           // 0000000779C8: D7000124
	v_cndmask_b32_e32 v1, 0xf0000, v26, vcc_lo                 // 0000000779CC: 020234FF 000F0000
	v_add_co_ci_u32_e64 v37, null, 0, v27, s1                  // 0000000779D4: D5207C25 00063680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000779DC: BF870094
	.long 0xd700010e                                           // 0000000779E0: D700010E
	v_cndmask_b32_e32 v1, s12, v34, vcc_lo                     // 0000000779E4: 0202440C
	v_add_co_ci_u32_e64 v15, null, s13, v35, s1                // 0000000779E8: D5207C0F 0006460D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000779F0: BF870094
	.long 0xd7000110                                           // 0000000779F4: D7000110
	v_cndmask_b32_e32 v1, s12, v36, vcc_lo                     // 0000000779F8: 0202480C
	v_add_co_ci_u32_e64 v17, null, s13, v37, s1                // 0000000779FC: D5207C11 00064A0D
	.long 0xd7000126                                           // 000000077A04: D7000126
	v_cndmask_b32_e32 v1, 0x120000, v26, vcc_lo                // 000000077A08: 020234FF 00120000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000077A10: BF8700A1
	v_add_co_ci_u32_e64 v39, null, 0, v27, s1                  // 000000077A14: D5207C27 00063680
	.long 0xd7000128                                           // 000000077A1C: D7000128
	v_cndmask_b32_e32 v1, 0x150000, v26, vcc_lo                // 000000077A20: 020234FF 00150000
	v_add_co_ci_u32_e64 v41, null, 0, v27, s1                  // 000000077A28: D5207C29 00063680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077A30: BF870094
	.long 0xd7000112                                           // 000000077A34: D7000112
	v_cndmask_b32_e32 v1, s12, v38, vcc_lo                     // 000000077A38: 02024C0C
	v_add_co_ci_u32_e64 v19, null, s13, v39, s1                // 000000077A3C: D5207C13 00064E0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077A44: BF870094
	.long 0xd7000114                                           // 000000077A48: D7000114
	v_cndmask_b32_e32 v1, s12, v40, vcc_lo                     // 000000077A4C: 0202500C
	v_add_co_ci_u32_e64 v21, null, s13, v41, s1                // 000000077A50: D5207C15 0006520D
	s_lshl_b64 s[10:11], s[2:3], 14                            // 000000077A58: 848A8E02
	.long 0xd7000116                                           // 000000077A5C: D7000116
	v_cndmask_b32_e32 v1, s4, v26, vcc_lo                      // 000000077A60: 02023404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000077A64: BF8700C1
	v_add_co_ci_u32_e64 v23, null, s5, v27, s1                 // 000000077A68: D5207C17 00063605
	s_add_u32 s1, s14, s10                                     // 000000077A70: 80010A0E
	s_addc_u32 s4, s15, s11                                    // 000000077A74: 82040B0F
	.long 0xd7000118                                           // 000000077A78: D7000118
	v_cndmask_b32_e32 v1, s1, v24, vcc_lo                      // 000000077A7C: 02023001
	v_add_co_ci_u32_e64 v25, null, s4, 0, s1                   // 000000077A80: D5207C19 00050004
	.long 0xd700011a                                           // 000000077A88: D700011A
	v_cndmask_b32_e32 v1, s6, v26, vcc_lo                      // 000000077A8C: 02023406
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000077A90: BF8700A1
	v_add_co_ci_u32_e64 v27, null, s7, v27, s1                 // 000000077A94: D5207C1B 00063607
	.long 0xd700011c                                           // 000000077A9C: D700011C
	v_cndmask_b32_e32 v1, s6, v28, vcc_lo                      // 000000077AA0: 02023806
	v_add_co_ci_u32_e64 v29, null, s7, v29, s1                 // 000000077AA4: D5207C1D 00063A07
	.long 0xd700011e                                           // 000000077AAC: D700011E
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 000000077AB0: 02023C06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000077AB4: BF8700A1
	v_add_co_ci_u32_e64 v31, null, s7, v31, s1                 // 000000077AB8: D5207C1F 00063E07
	.long 0xd7000120                                           // 000000077AC0: D7000120
	v_cndmask_b32_e32 v1, s6, v32, vcc_lo                      // 000000077AC4: 02024006
	v_add_co_ci_u32_e64 v33, null, s7, v33, s1                 // 000000077AC8: D5207C21 00064207
	.long 0xd7000122                                           // 000000077AD0: D7000122
	v_cndmask_b32_e32 v1, s6, v34, vcc_lo                      // 000000077AD4: 02024406
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000077AD8: BF8700A1
	v_add_co_ci_u32_e64 v35, null, s7, v35, s1                 // 000000077ADC: D5207C23 00064607
	.long 0xd7000124                                           // 000000077AE4: D7000124
	v_cndmask_b32_e32 v1, s6, v36, vcc_lo                      // 000000077AE8: 02024806
	v_add_co_ci_u32_e64 v37, null, s7, v37, s1                 // 000000077AEC: D5207C25 00064A07
	.long 0xd7000126                                           // 000000077AF4: D7000126
	v_cndmask_b32_e32 v1, s6, v38, vcc_lo                      // 000000077AF8: 02024C06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000077AFC: BF870001
	v_add_co_ci_u32_e64 v39, null, s7, v39, s1                 // 000000077B00: D5207C27 00064E07
	.long 0xd7000128                                           // 000000077B08: D7000128
	v_cndmask_b32_e32 v1, s6, v40, vcc_lo                      // 000000077B0C: 02025006
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v52, 0x4320, v51 // 000000077B10: CA200080 033466FF 00004320
	v_add_nc_u32_e32 v53, 0x4420, v51                          // 000000077B1C: 4A6A66FF 00004420
	.long 0xd44c0000                                           // 000000077B24: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000077B28: 020200FF 00000080
	v_add_nc_u32_e32 v58, 0x2200, v48                          // 000000077B30: 4A7460FF 00002200
	v_or_b32_e32 v59, 0x2200, v1                               // 000000077B38: 387602FF 00002200
	v_add_co_ci_u32_e64 v41, null, s7, v41, s1                 // 000000077B40: D5207C29 00065207
	s_mov_b32 s5, 0                                            // 000000077B48: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 000000077B4C: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 000000077B50: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000077B58: BF870499
	s_add_i32 s6, s31, s1                                      // 000000077B5C: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 000000077B60: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000077B64: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 000000077B68: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 000000077B6C: 84078605
	s_add_u32 s10, s8, s10                                     // 000000077B70: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 000000077B74: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 000000077B78: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 000000077B80: BE84206A
	s_cbranch_execz 77                                         // 000000077B84: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5bc>
	v_or_b32_e32 v42, s7, v0                                   // 000000077B88: 38540007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077B8C: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 000000077B90: D6FE7C2A 0009612A
	v_ashrrev_i32_e32 v43, 31, v42                             // 000000077B98: 3456549F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077B9C: BF870091
	.long 0xd73c002a                                           // 000000077BA0: D73C002A
	v_cndmask_b32_e32 v1, 2, v42, vcc_lo                       // 000000077BA4: 02025482
	.long 0xd700012a                                           // 000000077BA8: D700012A
	v_cndmask_b32_e32 v1, s8, v42, vcc_lo                      // 000000077BAC: 02025408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000077BB0: BF8700C1
	v_add_co_ci_u32_e64 v43, null, s9, v43, s1                 // 000000077BB4: D5207C2B 00065609
	global_load_b32 v42, v[42:43], off                         // 000000077BBC: DC520000 2A7C002A
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000077BC4: BF890007
	v_sub_f32_e32 v43, s6, v42                                 // 000000077BC8: 08565406
	v_dual_mul_f32 v45, 0x3fb8aa3b, v42 :: v_dual_mul_f32 v44, 0x3fb8aa3b, v43// 000000077BCC: C8C654FF 2D2C56FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000077BD8: BF8701A1
	v_fma_f32 v60, 0x3fb8aa3b, v42, -v45                       // 000000077BDC: D613003C 84B654FF 3FB8AA3B
	v_rndne_f32_e32 v61, v45                                   // 000000077BE8: 7E7A472D
	v_fma_f32 v46, 0x3fb8aa3b, v43, -v44                       // 000000077BEC: D613002E 84B256FF 3FB8AA3B
	v_rndne_f32_e32 v47, v44                                   // 000000077BF8: 7E5E472C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000077BFC: BF870113
	v_dual_fmac_f32 v60, 0x32a5705f, v42 :: v_dual_sub_f32 v45, v45, v61// 000000077C00: C80A54FF 3C2C7B2D 32A5705F
	v_sub_f32_e32 v44, v44, v47                                // 000000077C0C: 08585F2C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000077C10: BF870124
	v_fmac_f32_e32 v46, 0x32a5705f, v43                        // 000000077C14: 565C56FF 32A5705F
	.long 0xd41b0001                                           // 000000077C1C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v43, vcc_lo              // 000000077C20: 020256FF C2CE8ED0
	v_dual_add_f32 v45, v45, v60 :: v_dual_add_f32 v44, v44, v46// 000000077C28: C908792D 2D2C5D2C
	v_cvt_i32_f32_e32 v46, v47                                 // 000000077C30: 7E5C112F
	v_cvt_i32_f32_e32 v47, v61                                 // 000000077C34: 7E5E113D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000077C38: BF870193
	v_exp_f32_e32 v45, v45                                     // 000000077C3C: 7E5A4B2D
	v_exp_f32_e32 v44, v44                                     // 000000077C40: 7E584B2C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000077C44: BF870296
	.long 0xd71c002d                                           // 000000077C48: D71C002D
	v_cndmask_b32_e32 v1, v45, v47, vcc_lo                     // 000000077C4C: 02025F2D
	.long 0xd71c002c                                           // 000000077C50: D71C002C
	v_cndmask_b32_e32 v1, v44, v46, vcc_lo                     // 000000077C54: 02025D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000077C58: BF8700A1
	v_cndmask_b32_e64 v44, 0, v44, s1                          // 000000077C5C: D501002C 00065880
	.long 0xd41b0001                                           // 000000077C64: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v42, vcc_lo              // 000000077C68: 020254FF C2CE8ED0
	v_cndmask_b32_e64 v45, 0, v45, s1                          // 000000077C70: D501002D 00065A80
	.long 0xd41e0001                                           // 000000077C78: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v43, vcc_lo              // 000000077C7C: 020256FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000077C84: BF8700A1
	v_cndmask_b32_e64 v43, 0x7f800000, v44, s1                 // 000000077C88: D501002B 000658FF 7F800000
	.long 0xd41e0001                                           // 000000077C94: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v42, vcc_lo              // 000000077C98: 020254FF 42B17218
	v_cndmask_b32_e64 v42, 0x7f800000, v45, s1                 // 000000077CA0: D501002A 00065AFF 7F800000
	ds_store_b32 v52, v43                                      // 000000077CAC: D8340000 00002B34
	ds_store_b32 v53, v42                                      // 000000077CB4: D8340000 00002A35
	s_or_b32 exec_lo, exec_lo, s4                              // 000000077CBC: 8C7E047E
	v_dual_mov_b32 v43, v7 :: v_dual_mov_b32 v42, v6           // 000000077CC0: CA100107 2B2A0106
	v_dual_mov_b32 v44, v51 :: v_dual_mov_b32 v45, v49         // 000000077CC8: CA100133 2C2C0131
	s_mov_b32 s10, 0                                           // 000000077CD0: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000077CD4: BF89FC07
	s_barrier                                                  // 000000077CD8: BFBD0000
	buffer_gl0_inv                                             // 000000077CDC: E0AC0000 00000000
	s_nop 0                                                    // 000000077CE4: BF800000
	s_nop 0                                                    // 000000077CE8: BF800000
	s_nop 0                                                    // 000000077CEC: BF800000
	s_nop 0                                                    // 000000077CF0: BF800000
	s_nop 0                                                    // 000000077CF4: BF800000
	s_nop 0                                                    // 000000077CF8: BF800000
	s_nop 0                                                    // 000000077CFC: BF800000
	global_load_b32 v46, v[42:43], off                         // 000000077D00: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000077D08: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 000000077D10: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000077D14: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000077D1C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000077D20: D5207C2B 00065680
	.long 0xd4490004                                           // 000000077D28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 000000077D2C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000077D34: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000077D38: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 000000077D3C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000077D44: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000077D4C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000077D50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x600>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000077D54: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000077D58: BF89FC07
	s_barrier                                                  // 000000077D5C: BFBD0000
	buffer_gl0_inv                                             // 000000077D60: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000077D68: BE842000
	s_cbranch_execz 140                                        // 000000077D6C: BFA5008C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8a0>
	v_or_b32_e32 v42, s7, v2                                   // 000000077D70: 38540407
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077D74: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 000000077D78: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 000000077D80: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000077D84: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077D88: BF870091
	.long 0xd700012a                                           // 000000077D8C: D700012A
	v_cndmask_b32_e32 v1, v55, v42, vcc_lo                     // 000000077D90: 02025537
	v_add_co_ci_u32_e64 v43, null, v56, v43, s1                // 000000077D94: D5207C2B 00065738
	s_mov_b32 s1, 0                                            // 000000077D9C: BE810080
	global_load_b32 v42, v[42:43], off                         // 000000077DA0: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 000000077DA8: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v57                             // 000000077DB4: D6460048 04E50401
	s_add_i32 s10, s1, 16                                      // 000000077DBC: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 000000077DC0: B6810070
	s_mov_b32 s1, s10                                          // 000000077DC4: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 000000077DC8: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 000000077DD0: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 000000077DD8: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 000000077DE0: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 000000077DE8: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 000000077DF0: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 000000077DF8: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 000000077DFC: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 000000077E00: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 000000077E04: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000077E0C: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 000000077E10: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 000000077E14: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 000000077E18: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000077E20: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 000000077E24: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 000000077E28: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 000000077E2C: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 000000077E34: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 000000077E38: 7E56152C
	s_waitcnt vmcnt(0)                                         // 000000077E3C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000077E40: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 000000077E44: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 000000077E4C: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 000000077E50: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 000000077E54: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 000000077E5C: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 000000077E64: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 000000077E68: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 000000077E6C: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 000000077E70: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000077E74: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 000000077E78: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[60:61], v72 offset0:4 offset1:5        // 000000077E80: D8DC0504 3C000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 000000077E88: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 000000077E90: BF89FC07
	v_cvt_f16_f32_e32 v43, v60                                 // 000000077E94: 7E56153C
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 000000077E98: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 000000077EA0: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v61                                 // 000000077EA8: 7E58153D
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 000000077EAC: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 000000077EB4: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 000000077EBC: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 000000077EC4: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 000000077ECC: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 000000077ED4: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 000000077ED8: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 000000077EDC: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000077EE0: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000077EE4: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 000000077EEC: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 000000077EF0: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 000000077EF4: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000077EF8: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 000000077F00: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 000000077F04: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000077F08: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000077F0C: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 000000077F14: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 000000077F18: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 000000077F1C: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000077F20: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 000000077F28: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 000000077F2C: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000077F30: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000077F34: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 000000077F3C: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 000000077F40: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 000000077F44: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000077F48: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 000000077F50: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 000000077F54: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000077F58: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000077F5C: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 000000077F64: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 000000077F68: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 000000077F6C: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000077F70: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 000000077F78: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 000000077F7C: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000077F80: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000077F84: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000077F8C: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 000000077F94: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6a8>
	ds_store_b32 v58, v42                                      // 000000077F98: D8340000 00002A3A
	s_or_b32 exec_lo, exec_lo, s4                              // 000000077FA0: 8C7E047E
	v_dual_mov_b32 v43, v9 :: v_dual_mov_b32 v42, v8           // 000000077FA4: CA100109 2B2A0108
	v_dual_mov_b32 v44, v51 :: v_dual_mov_b32 v45, v49         // 000000077FAC: CA100133 2C2C0131
	s_mov_b32 s10, 0                                           // 000000077FB4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000077FB8: BF89FC07
	s_barrier                                                  // 000000077FBC: BFBD0000
	buffer_gl0_inv                                             // 000000077FC0: E0AC0000 00000000
	s_nop 0                                                    // 000000077FC8: BF800000
	s_nop 0                                                    // 000000077FCC: BF800000
	s_nop 0                                                    // 000000077FD0: BF800000
	s_nop 0                                                    // 000000077FD4: BF800000
	s_nop 0                                                    // 000000077FD8: BF800000
	s_nop 0                                                    // 000000077FDC: BF800000
	s_nop 0                                                    // 000000077FE0: BF800000
	s_nop 0                                                    // 000000077FE4: BF800000
	s_nop 0                                                    // 000000077FE8: BF800000
	s_nop 0                                                    // 000000077FEC: BF800000
	s_nop 0                                                    // 000000077FF0: BF800000
	s_nop 0                                                    // 000000077FF4: BF800000
	s_nop 0                                                    // 000000077FF8: BF800000
	s_nop 0                                                    // 000000077FFC: BF800000
	global_load_b32 v46, v[42:43], off                         // 000000078000: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000078008: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 000000078010: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000078014: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007801C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000078020: D5207C2B 00065680
	.long 0xd4490004                                           // 000000078028: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000007802C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000078034: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000078038: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000007803C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000078044: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000007804C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000078050: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x900>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000078054: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000078058: BF89FC07
	s_barrier                                                  // 00000007805C: BFBD0000
	buffer_gl0_inv                                             // 000000078060: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000078068: BE842000
	s_cbranch_execz 141                                        // 00000007806C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xba4>
	v_add3_u32 v42, v2, s7, 8                                  // 000000078070: D655002A 02200F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078078: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000007807C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 000000078084: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000078088: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007808C: BF870091
	.long 0xd700012a                                           // 000000078090: D700012A
	v_cndmask_b32_e32 v1, v55, v42, vcc_lo                     // 000000078094: 02025537
	v_add_co_ci_u32_e64 v43, null, v56, v43, s1                // 000000078098: D5207C2B 00065738
	s_mov_b32 s1, 0                                            // 0000000780A0: BE810080
	global_load_b32 v42, v[42:43], off                         // 0000000780A4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 0000000780AC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v57                             // 0000000780B8: D6460048 04E50401
	s_add_i32 s10, s1, 16                                      // 0000000780C0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 0000000780C4: B6810070
	s_mov_b32 s1, s10                                          // 0000000780C8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 0000000780CC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 0000000780D4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 0000000780DC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 0000000780E4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 0000000780EC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 0000000780F4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 0000000780FC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 000000078100: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 000000078104: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 000000078108: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000078110: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 000000078114: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 000000078118: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000007811C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000078124: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 000000078128: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000007812C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 000000078130: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 000000078138: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000007813C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 000000078140: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000078144: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 000000078148: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 000000078150: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 000000078154: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 000000078158: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 000000078160: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 000000078168: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000007816C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 000000078170: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 000000078174: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000078178: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000007817C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[60:61], v72 offset0:4 offset1:5        // 000000078184: D8DC0504 3C000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000007818C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 000000078194: BF89FC07
	v_cvt_f16_f32_e32 v43, v60                                 // 000000078198: 7E56153C
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000007819C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 0000000781A4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v61                                 // 0000000781AC: 7E58153D
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 0000000781B0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 0000000781B8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 0000000781C0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 0000000781C8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 0000000781D0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 0000000781D8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 0000000781DC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 0000000781E0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000781E4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 0000000781E8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 0000000781F0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 0000000781F4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 0000000781F8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 0000000781FC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 000000078204: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 000000078208: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000007820C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078210: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 000000078218: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000007821C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 000000078220: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078224: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000007822C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 000000078230: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000078234: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078238: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 000000078240: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 000000078244: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 000000078248: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000007824C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 000000078254: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 000000078258: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000007825C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078260: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 000000078268: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000007826C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 000000078270: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078274: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000007827C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 000000078280: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078284: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078288: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078290: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 000000078298: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x9ac>
	ds_store_b32 v58, v42 offset:544                           // 00000007829C: D8340220 00002A3A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000782A4: 8C7E047E
	v_dual_mov_b32 v43, v11 :: v_dual_mov_b32 v42, v10         // 0000000782A8: CA10010B 2B2A010A
	v_dual_mov_b32 v44, v51 :: v_dual_mov_b32 v45, v49         // 0000000782B0: CA100133 2C2C0131
	s_mov_b32 s10, 0                                           // 0000000782B8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000782BC: BF89FC07
	s_barrier                                                  // 0000000782C0: BFBD0000
	buffer_gl0_inv                                             // 0000000782C4: E0AC0000 00000000
	s_nop 0                                                    // 0000000782CC: BF800000
	s_nop 0                                                    // 0000000782D0: BF800000
	s_nop 0                                                    // 0000000782D4: BF800000
	s_nop 0                                                    // 0000000782D8: BF800000
	s_nop 0                                                    // 0000000782DC: BF800000
	s_nop 0                                                    // 0000000782E0: BF800000
	s_nop 0                                                    // 0000000782E4: BF800000
	s_nop 0                                                    // 0000000782E8: BF800000
	s_nop 0                                                    // 0000000782EC: BF800000
	s_nop 0                                                    // 0000000782F0: BF800000
	s_nop 0                                                    // 0000000782F4: BF800000
	s_nop 0                                                    // 0000000782F8: BF800000
	s_nop 0                                                    // 0000000782FC: BF800000
	global_load_b32 v46, v[42:43], off                         // 000000078300: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000078308: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 000000078310: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000078314: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007831C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000078320: D5207C2B 00065680
	.long 0xd4490004                                           // 000000078328: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000007832C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000078334: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000078338: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000007833C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000078344: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000007834C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000078350: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc00>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000078354: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000078358: BF89FC07
	s_barrier                                                  // 00000007835C: BFBD0000
	buffer_gl0_inv                                             // 000000078360: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000078368: BE842000
	s_cbranch_execz 141                                        // 00000007836C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xea4>
	v_add3_u32 v42, v2, s7, 16                                 // 000000078370: D655002A 02400F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078378: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000007837C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 000000078384: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000078388: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007838C: BF870091
	.long 0xd700012a                                           // 000000078390: D700012A
	v_cndmask_b32_e32 v1, v55, v42, vcc_lo                     // 000000078394: 02025537
	v_add_co_ci_u32_e64 v43, null, v56, v43, s1                // 000000078398: D5207C2B 00065738
	s_mov_b32 s1, 0                                            // 0000000783A0: BE810080
	global_load_b32 v42, v[42:43], off                         // 0000000783A4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 0000000783AC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v57                             // 0000000783B8: D6460048 04E50401
	s_add_i32 s10, s1, 16                                      // 0000000783C0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 0000000783C4: B6810070
	s_mov_b32 s1, s10                                          // 0000000783C8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 0000000783CC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 0000000783D4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 0000000783DC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 0000000783E4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 0000000783EC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 0000000783F4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 0000000783FC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 000000078400: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 000000078404: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 000000078408: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000078410: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 000000078414: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 000000078418: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000007841C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000078424: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 000000078428: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000007842C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 000000078430: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 000000078438: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000007843C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 000000078440: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000078444: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 000000078448: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 000000078450: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 000000078454: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 000000078458: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 000000078460: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 000000078468: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000007846C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 000000078470: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 000000078474: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000078478: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000007847C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[60:61], v72 offset0:4 offset1:5        // 000000078484: D8DC0504 3C000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000007848C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 000000078494: BF89FC07
	v_cvt_f16_f32_e32 v43, v60                                 // 000000078498: 7E56153C
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000007849C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 0000000784A4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v61                                 // 0000000784AC: 7E58153D
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 0000000784B0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 0000000784B8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 0000000784C0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 0000000784C8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 0000000784D0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 0000000784D8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 0000000784DC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 0000000784E0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000784E4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 0000000784E8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 0000000784F0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 0000000784F4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 0000000784F8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 0000000784FC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 000000078504: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 000000078508: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000007850C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078510: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 000000078518: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000007851C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 000000078520: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078524: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000007852C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 000000078530: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000078534: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078538: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 000000078540: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 000000078544: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 000000078548: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000007854C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 000000078554: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 000000078558: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000007855C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078560: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 000000078568: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000007856C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 000000078570: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078574: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000007857C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 000000078580: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078584: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078588: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078590: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 000000078598: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xcac>
	ds_store_b32 v58, v42 offset:1088                          // 00000007859C: D8340440 00002A3A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000785A4: 8C7E047E
	v_dual_mov_b32 v43, v13 :: v_dual_mov_b32 v42, v12         // 0000000785A8: CA10010D 2B2A010C
	v_dual_mov_b32 v44, v51 :: v_dual_mov_b32 v45, v49         // 0000000785B0: CA100133 2C2C0131
	s_mov_b32 s10, 0                                           // 0000000785B8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000785BC: BF89FC07
	s_barrier                                                  // 0000000785C0: BFBD0000
	buffer_gl0_inv                                             // 0000000785C4: E0AC0000 00000000
	s_nop 0                                                    // 0000000785CC: BF800000
	s_nop 0                                                    // 0000000785D0: BF800000
	s_nop 0                                                    // 0000000785D4: BF800000
	s_nop 0                                                    // 0000000785D8: BF800000
	s_nop 0                                                    // 0000000785DC: BF800000
	s_nop 0                                                    // 0000000785E0: BF800000
	s_nop 0                                                    // 0000000785E4: BF800000
	s_nop 0                                                    // 0000000785E8: BF800000
	s_nop 0                                                    // 0000000785EC: BF800000
	s_nop 0                                                    // 0000000785F0: BF800000
	s_nop 0                                                    // 0000000785F4: BF800000
	s_nop 0                                                    // 0000000785F8: BF800000
	s_nop 0                                                    // 0000000785FC: BF800000
	global_load_b32 v46, v[42:43], off                         // 000000078600: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000078608: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 000000078610: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000078614: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007861C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000078620: D5207C2B 00065680
	.long 0xd4490004                                           // 000000078628: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000007862C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000078634: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000078638: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000007863C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000078644: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000007864C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000078650: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xf00>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000078654: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000078658: BF89FC07
	s_barrier                                                  // 00000007865C: BFBD0000
	buffer_gl0_inv                                             // 000000078660: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000078668: BE842000
	s_cbranch_execz 141                                        // 00000007866C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11a4>
	v_add3_u32 v42, v2, s7, 24                                 // 000000078670: D655002A 02600F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078678: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000007867C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 000000078684: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000078688: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007868C: BF870091
	.long 0xd700012a                                           // 000000078690: D700012A
	v_cndmask_b32_e32 v1, v55, v42, vcc_lo                     // 000000078694: 02025537
	v_add_co_ci_u32_e64 v43, null, v56, v43, s1                // 000000078698: D5207C2B 00065738
	s_mov_b32 s1, 0                                            // 0000000786A0: BE810080
	global_load_b32 v42, v[42:43], off                         // 0000000786A4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 0000000786AC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v57                             // 0000000786B8: D6460048 04E50401
	s_add_i32 s10, s1, 16                                      // 0000000786C0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 0000000786C4: B6810070
	s_mov_b32 s1, s10                                          // 0000000786C8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 0000000786CC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 0000000786D4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 0000000786DC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 0000000786E4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 0000000786EC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 0000000786F4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 0000000786FC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 000000078700: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 000000078704: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 000000078708: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000078710: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 000000078714: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 000000078718: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000007871C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000078724: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 000000078728: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000007872C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 000000078730: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 000000078738: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000007873C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 000000078740: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000078744: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 000000078748: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 000000078750: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 000000078754: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 000000078758: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 000000078760: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 000000078768: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000007876C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 000000078770: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 000000078774: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000078778: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000007877C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[60:61], v72 offset0:4 offset1:5        // 000000078784: D8DC0504 3C000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000007878C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 000000078794: BF89FC07
	v_cvt_f16_f32_e32 v43, v60                                 // 000000078798: 7E56153C
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000007879C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 0000000787A4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v61                                 // 0000000787AC: 7E58153D
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 0000000787B0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 0000000787B8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 0000000787C0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 0000000787C8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 0000000787D0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 0000000787D8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 0000000787DC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 0000000787E0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000787E4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 0000000787E8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 0000000787F0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 0000000787F4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 0000000787F8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 0000000787FC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 000000078804: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 000000078808: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000007880C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078810: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 000000078818: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000007881C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 000000078820: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078824: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000007882C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 000000078830: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000078834: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078838: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 000000078840: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 000000078844: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 000000078848: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000007884C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 000000078854: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 000000078858: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000007885C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078860: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 000000078868: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000007886C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 000000078870: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078874: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000007887C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 000000078880: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078884: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078888: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078890: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 000000078898: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfac>
	ds_store_b32 v58, v42 offset:1632                          // 00000007889C: D8340660 00002A3A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000788A4: 8C7E047E
	v_dual_mov_b32 v43, v15 :: v_dual_mov_b32 v42, v14         // 0000000788A8: CA10010F 2B2A010E
	v_dual_mov_b32 v44, v51 :: v_dual_mov_b32 v45, v49         // 0000000788B0: CA100133 2C2C0131
	s_mov_b32 s10, 0                                           // 0000000788B8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000788BC: BF89FC07
	s_barrier                                                  // 0000000788C0: BFBD0000
	buffer_gl0_inv                                             // 0000000788C4: E0AC0000 00000000
	s_nop 0                                                    // 0000000788CC: BF800000
	s_nop 0                                                    // 0000000788D0: BF800000
	s_nop 0                                                    // 0000000788D4: BF800000
	s_nop 0                                                    // 0000000788D8: BF800000
	s_nop 0                                                    // 0000000788DC: BF800000
	s_nop 0                                                    // 0000000788E0: BF800000
	s_nop 0                                                    // 0000000788E4: BF800000
	s_nop 0                                                    // 0000000788E8: BF800000
	s_nop 0                                                    // 0000000788EC: BF800000
	s_nop 0                                                    // 0000000788F0: BF800000
	s_nop 0                                                    // 0000000788F4: BF800000
	s_nop 0                                                    // 0000000788F8: BF800000
	s_nop 0                                                    // 0000000788FC: BF800000
	global_load_b32 v46, v[42:43], off                         // 000000078900: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000078908: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 000000078910: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000078914: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007891C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000078920: D5207C2B 00065680
	.long 0xd4490004                                           // 000000078928: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000007892C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000078934: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000078938: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000007893C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000078944: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000007894C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000078950: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1200>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000078954: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000078958: BF89FC07
	s_barrier                                                  // 00000007895C: BFBD0000
	buffer_gl0_inv                                             // 000000078960: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000078968: BE842000
	s_cbranch_execz 141                                        // 00000007896C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14a4>
	v_add3_u32 v42, v2, s7, 32                                 // 000000078970: D655002A 02800F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078978: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000007897C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 000000078984: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000078988: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007898C: BF870091
	.long 0xd700012a                                           // 000000078990: D700012A
	v_cndmask_b32_e32 v1, v55, v42, vcc_lo                     // 000000078994: 02025537
	v_add_co_ci_u32_e64 v43, null, v56, v43, s1                // 000000078998: D5207C2B 00065738
	s_mov_b32 s1, 0                                            // 0000000789A0: BE810080
	global_load_b32 v42, v[42:43], off                         // 0000000789A4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 0000000789AC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v57                             // 0000000789B8: D6460048 04E50401
	s_add_i32 s10, s1, 16                                      // 0000000789C0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 0000000789C4: B6810070
	s_mov_b32 s1, s10                                          // 0000000789C8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 0000000789CC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 0000000789D4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 0000000789DC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 0000000789E4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 0000000789EC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 0000000789F4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 0000000789FC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 000000078A00: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 000000078A04: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 000000078A08: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000078A10: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 000000078A14: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 000000078A18: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 000000078A1C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000078A24: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 000000078A28: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 000000078A2C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 000000078A30: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 000000078A38: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 000000078A3C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 000000078A40: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000078A44: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 000000078A48: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 000000078A50: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 000000078A54: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 000000078A58: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 000000078A60: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 000000078A68: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 000000078A6C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 000000078A70: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 000000078A74: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000078A78: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 000000078A7C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[60:61], v72 offset0:4 offset1:5        // 000000078A84: D8DC0504 3C000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 000000078A8C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 000000078A94: BF89FC07
	v_cvt_f16_f32_e32 v43, v60                                 // 000000078A98: 7E56153C
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 000000078A9C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 000000078AA4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v61                                 // 000000078AAC: 7E58153D
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 000000078AB0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 000000078AB8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 000000078AC0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 000000078AC8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 000000078AD0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 000000078AD8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 000000078ADC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 000000078AE0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000078AE4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078AE8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 000000078AF0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 000000078AF4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 000000078AF8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078AFC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 000000078B04: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 000000078B08: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000078B0C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078B10: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 000000078B18: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 000000078B1C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 000000078B20: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078B24: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 000000078B2C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 000000078B30: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000078B34: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078B38: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 000000078B40: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 000000078B44: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 000000078B48: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078B4C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 000000078B54: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 000000078B58: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000078B5C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078B60: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 000000078B68: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 000000078B6C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 000000078B70: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078B74: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 000000078B7C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 000000078B80: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078B84: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078B88: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078B90: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 000000078B98: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x12ac>
	ds_store_b32 v58, v42 offset:2176                          // 000000078B9C: D8340880 00002A3A
	s_or_b32 exec_lo, exec_lo, s4                              // 000000078BA4: 8C7E047E
	v_dual_mov_b32 v43, v17 :: v_dual_mov_b32 v42, v16         // 000000078BA8: CA100111 2B2A0110
	v_dual_mov_b32 v44, v51 :: v_dual_mov_b32 v45, v49         // 000000078BB0: CA100133 2C2C0131
	s_mov_b32 s10, 0                                           // 000000078BB8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000078BBC: BF89FC07
	s_barrier                                                  // 000000078BC0: BFBD0000
	buffer_gl0_inv                                             // 000000078BC4: E0AC0000 00000000
	s_nop 0                                                    // 000000078BCC: BF800000
	s_nop 0                                                    // 000000078BD0: BF800000
	s_nop 0                                                    // 000000078BD4: BF800000
	s_nop 0                                                    // 000000078BD8: BF800000
	s_nop 0                                                    // 000000078BDC: BF800000
	s_nop 0                                                    // 000000078BE0: BF800000
	s_nop 0                                                    // 000000078BE4: BF800000
	s_nop 0                                                    // 000000078BE8: BF800000
	s_nop 0                                                    // 000000078BEC: BF800000
	s_nop 0                                                    // 000000078BF0: BF800000
	s_nop 0                                                    // 000000078BF4: BF800000
	s_nop 0                                                    // 000000078BF8: BF800000
	s_nop 0                                                    // 000000078BFC: BF800000
	global_load_b32 v46, v[42:43], off                         // 000000078C00: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000078C08: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 000000078C10: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000078C14: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000078C1C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000078C20: D5207C2B 00065680
	.long 0xd4490004                                           // 000000078C28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 000000078C2C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000078C34: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000078C38: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 000000078C3C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000078C44: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000078C4C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000078C50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1500>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000078C54: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000078C58: BF89FC07
	s_barrier                                                  // 000000078C5C: BFBD0000
	buffer_gl0_inv                                             // 000000078C60: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000078C68: BE842000
	s_cbranch_execz 141                                        // 000000078C6C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x17a4>
	v_add3_u32 v42, v2, s7, 40                                 // 000000078C70: D655002A 02A00F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078C78: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 000000078C7C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 000000078C84: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000078C88: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078C8C: BF870091
	.long 0xd700012a                                           // 000000078C90: D700012A
	v_cndmask_b32_e32 v1, v55, v42, vcc_lo                     // 000000078C94: 02025537
	v_add_co_ci_u32_e64 v43, null, v56, v43, s1                // 000000078C98: D5207C2B 00065738
	s_mov_b32 s1, 0                                            // 000000078CA0: BE810080
	global_load_b32 v42, v[42:43], off                         // 000000078CA4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 000000078CAC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v57                             // 000000078CB8: D6460048 04E50401
	s_add_i32 s10, s1, 16                                      // 000000078CC0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 000000078CC4: B6810070
	s_mov_b32 s1, s10                                          // 000000078CC8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 000000078CCC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 000000078CD4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 000000078CDC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 000000078CE4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 000000078CEC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 000000078CF4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 000000078CFC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 000000078D00: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 000000078D04: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 000000078D08: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000078D10: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 000000078D14: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 000000078D18: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 000000078D1C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000078D24: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 000000078D28: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 000000078D2C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 000000078D30: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 000000078D38: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 000000078D3C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 000000078D40: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000078D44: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 000000078D48: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 000000078D50: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 000000078D54: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 000000078D58: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 000000078D60: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 000000078D68: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 000000078D6C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 000000078D70: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 000000078D74: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000078D78: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 000000078D7C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[60:61], v72 offset0:4 offset1:5        // 000000078D84: D8DC0504 3C000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 000000078D8C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 000000078D94: BF89FC07
	v_cvt_f16_f32_e32 v43, v60                                 // 000000078D98: 7E56153C
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 000000078D9C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 000000078DA4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v61                                 // 000000078DAC: 7E58153D
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 000000078DB0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 000000078DB8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 000000078DC0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 000000078DC8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 000000078DD0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 000000078DD8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 000000078DDC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 000000078DE0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000078DE4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078DE8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 000000078DF0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 000000078DF4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 000000078DF8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078DFC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 000000078E04: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 000000078E08: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000078E0C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078E10: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 000000078E18: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 000000078E1C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 000000078E20: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078E24: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 000000078E2C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 000000078E30: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000078E34: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078E38: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 000000078E40: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 000000078E44: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 000000078E48: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078E4C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 000000078E54: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 000000078E58: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000078E5C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078E60: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 000000078E68: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 000000078E6C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 000000078E70: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078E74: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 000000078E7C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 000000078E80: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078E84: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000078E88: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000078E90: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 000000078E98: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15ac>
	ds_store_b32 v58, v42 offset:2720                          // 000000078E9C: D8340AA0 00002A3A
	s_or_b32 exec_lo, exec_lo, s4                              // 000000078EA4: 8C7E047E
	v_dual_mov_b32 v43, v19 :: v_dual_mov_b32 v42, v18         // 000000078EA8: CA100113 2B2A0112
	v_dual_mov_b32 v44, v51 :: v_dual_mov_b32 v45, v49         // 000000078EB0: CA100133 2C2C0131
	s_mov_b32 s10, 0                                           // 000000078EB8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000078EBC: BF89FC07
	s_barrier                                                  // 000000078EC0: BFBD0000
	buffer_gl0_inv                                             // 000000078EC4: E0AC0000 00000000
	s_nop 0                                                    // 000000078ECC: BF800000
	s_nop 0                                                    // 000000078ED0: BF800000
	s_nop 0                                                    // 000000078ED4: BF800000
	s_nop 0                                                    // 000000078ED8: BF800000
	s_nop 0                                                    // 000000078EDC: BF800000
	s_nop 0                                                    // 000000078EE0: BF800000
	s_nop 0                                                    // 000000078EE4: BF800000
	s_nop 0                                                    // 000000078EE8: BF800000
	s_nop 0                                                    // 000000078EEC: BF800000
	s_nop 0                                                    // 000000078EF0: BF800000
	s_nop 0                                                    // 000000078EF4: BF800000
	s_nop 0                                                    // 000000078EF8: BF800000
	s_nop 0                                                    // 000000078EFC: BF800000
	global_load_b32 v46, v[42:43], off                         // 000000078F00: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000078F08: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 000000078F10: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000078F14: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000078F1C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000078F20: D5207C2B 00065680
	.long 0xd4490004                                           // 000000078F28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 000000078F2C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000078F34: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000078F38: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 000000078F3C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000078F44: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000078F4C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000078F50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1800>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000078F54: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000078F58: BF89FC07
	s_barrier                                                  // 000000078F5C: BFBD0000
	buffer_gl0_inv                                             // 000000078F60: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000078F68: BE842000
	s_cbranch_execz 141                                        // 000000078F6C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1aa4>
	v_add3_u32 v42, v2, s7, 48                                 // 000000078F70: D655002A 02C00F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078F78: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 000000078F7C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 000000078F84: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000078F88: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000078F8C: BF870091
	.long 0xd700012a                                           // 000000078F90: D700012A
	v_cndmask_b32_e32 v1, v55, v42, vcc_lo                     // 000000078F94: 02025537
	v_add_co_ci_u32_e64 v43, null, v56, v43, s1                // 000000078F98: D5207C2B 00065738
	s_mov_b32 s1, 0                                            // 000000078FA0: BE810080
	global_load_b32 v42, v[42:43], off                         // 000000078FA4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 000000078FAC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v57                             // 000000078FB8: D6460048 04E50401
	s_add_i32 s10, s1, 16                                      // 000000078FC0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 000000078FC4: B6810070
	s_mov_b32 s1, s10                                          // 000000078FC8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 000000078FCC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 000000078FD4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 000000078FDC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 000000078FE4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 000000078FEC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 000000078FF4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 000000078FFC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 000000079000: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 000000079004: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 000000079008: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000079010: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 000000079014: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 000000079018: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000007901C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000079024: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 000000079028: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000007902C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 000000079030: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 000000079038: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000007903C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 000000079040: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000079044: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 000000079048: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 000000079050: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 000000079054: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 000000079058: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 000000079060: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 000000079068: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000007906C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 000000079070: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 000000079074: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000079078: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000007907C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[60:61], v72 offset0:4 offset1:5        // 000000079084: D8DC0504 3C000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000007908C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 000000079094: BF89FC07
	v_cvt_f16_f32_e32 v43, v60                                 // 000000079098: 7E56153C
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000007909C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 0000000790A4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v61                                 // 0000000790AC: 7E58153D
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 0000000790B0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 0000000790B8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 0000000790C0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 0000000790C8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 0000000790D0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 0000000790D8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 0000000790DC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 0000000790E0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000790E4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 0000000790E8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 0000000790F0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 0000000790F4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 0000000790F8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 0000000790FC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 000000079104: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 000000079108: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000007910C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000079110: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 000000079118: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000007911C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 000000079120: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000079124: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000007912C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 000000079130: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000079134: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000079138: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 000000079140: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 000000079144: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 000000079148: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000007914C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 000000079154: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 000000079158: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000007915C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000079160: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 000000079168: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000007916C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 000000079170: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000079174: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000007917C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 000000079180: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079184: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000079188: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000079190: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 000000079198: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x18ac>
	ds_store_b32 v58, v42 offset:3264                          // 00000007919C: D8340CC0 00002A3A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000791A4: 8C7E047E
	v_dual_mov_b32 v43, v21 :: v_dual_mov_b32 v42, v20         // 0000000791A8: CA100115 2B2A0114
	v_dual_mov_b32 v44, v51 :: v_dual_mov_b32 v45, v49         // 0000000791B0: CA100133 2C2C0131
	s_mov_b32 s10, 0                                           // 0000000791B8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000791BC: BF89FC07
	s_barrier                                                  // 0000000791C0: BFBD0000
	buffer_gl0_inv                                             // 0000000791C4: E0AC0000 00000000
	s_nop 0                                                    // 0000000791CC: BF800000
	s_nop 0                                                    // 0000000791D0: BF800000
	s_nop 0                                                    // 0000000791D4: BF800000
	s_nop 0                                                    // 0000000791D8: BF800000
	s_nop 0                                                    // 0000000791DC: BF800000
	s_nop 0                                                    // 0000000791E0: BF800000
	s_nop 0                                                    // 0000000791E4: BF800000
	s_nop 0                                                    // 0000000791E8: BF800000
	s_nop 0                                                    // 0000000791EC: BF800000
	s_nop 0                                                    // 0000000791F0: BF800000
	s_nop 0                                                    // 0000000791F4: BF800000
	s_nop 0                                                    // 0000000791F8: BF800000
	s_nop 0                                                    // 0000000791FC: BF800000
	global_load_b32 v46, v[42:43], off                         // 000000079200: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000079208: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 000000079210: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000079214: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007921C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000079220: D5207C2B 00065680
	.long 0xd4490004                                           // 000000079228: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000007922C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000079234: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000079238: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000007923C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000079244: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000007924C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000079250: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b00>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000079254: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000079258: BF89FC07
	s_barrier                                                  // 00000007925C: BFBD0000
	buffer_gl0_inv                                             // 000000079260: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000079268: BE842000
	s_cbranch_execz 141                                        // 00000007926C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1da4>
	v_add3_u32 v42, v2, s7, 56                                 // 000000079270: D655002A 02E00F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079278: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000007927C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 000000079284: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000079288: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007928C: BF870091
	.long 0xd700012a                                           // 000000079290: D700012A
	v_cndmask_b32_e32 v1, v55, v42, vcc_lo                     // 000000079294: 02025537
	v_add_co_ci_u32_e64 v43, null, v56, v43, s1                // 000000079298: D5207C2B 00065738
	s_mov_b32 s1, 0                                            // 0000000792A0: BE810080
	global_load_b32 v42, v[42:43], off                         // 0000000792A4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 0000000792AC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v57                             // 0000000792B8: D6460048 04E50401
	s_add_i32 s10, s1, 16                                      // 0000000792C0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 0000000792C4: B6810070
	s_mov_b32 s1, s10                                          // 0000000792C8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 0000000792CC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 0000000792D4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 0000000792DC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 0000000792E4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 0000000792EC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 0000000792F4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 0000000792FC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 000000079300: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 000000079304: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 000000079308: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000079310: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 000000079314: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 000000079318: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000007931C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000079324: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 000000079328: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000007932C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 000000079330: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 000000079338: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000007933C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 000000079340: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000079344: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 000000079348: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 000000079350: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 000000079354: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 000000079358: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 000000079360: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 000000079368: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000007936C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 000000079370: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 000000079374: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000079378: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000007937C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[60:61], v72 offset0:4 offset1:5        // 000000079384: D8DC0504 3C000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000007938C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 000000079394: BF89FC07
	v_cvt_f16_f32_e32 v43, v60                                 // 000000079398: 7E56153C
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000007939C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 0000000793A4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v61                                 // 0000000793AC: 7E58153D
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 0000000793B0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 0000000793B8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 0000000793C0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 0000000793C8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 0000000793D0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 0000000793D8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 0000000793DC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 0000000793E0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000793E4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 0000000793E8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 0000000793F0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 0000000793F4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 0000000793F8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 0000000793FC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 000000079404: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 000000079408: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000007940C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000079410: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 000000079418: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000007941C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 000000079420: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000079424: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000007942C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 000000079430: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000079434: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000079438: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 000000079440: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 000000079444: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 000000079448: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000007944C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 000000079454: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 000000079458: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000007945C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000079460: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 000000079468: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000007946C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 000000079470: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000079474: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000007947C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 000000079480: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079484: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000079488: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000079490: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 000000079498: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1bac>
	ds_store_b32 v58, v42 offset:3808                          // 00000007949C: D8340EE0 00002A3A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000794A4: 8C7E047E
	v_mov_b32_e32 v43, v25                                     // 0000000794A8: 7E560319
	v_dual_mov_b32 v45, v23 :: v_dual_mov_b32 v42, v24         // 0000000794AC: CA100117 2D2A0118
	v_mov_b32_e32 v44, v22                                     // 0000000794B4: 7E580316
	v_mov_b32_e32 v60, v54                                     // 0000000794B8: 7E780336
	s_waitcnt lgkmcnt(0)                                       // 0000000794BC: BF89FC07
	s_barrier                                                  // 0000000794C0: BFBD0000
	s_mov_b32 s10, 0                                           // 0000000794C4: BE8A0080
	buffer_gl0_inv                                             // 0000000794C8: E0AC0000 00000000
	s_branch 21                                                // 0000000794D0: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e28>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000000794D4: 8C7E0B7E
	.long 0xd700012c                                           // 0000000794D8: D700012C
	v_cndmask_b32_e32 v1, 0x30000, v44, vcc_lo                 // 0000000794DC: 020258FF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000794E4: BF870001
	v_add_co_ci_u32_e64 v45, null, 0, v45, s1                  // 0000000794E8: D5207C2D 00065A80
	.long 0xd700012a                                           // 0000000794F0: D700012A
	v_cndmask_b32_e32 v1, 0x800, v42, vcc_lo                   // 0000000794F4: 020254FF 00000800
	v_add_nc_u32_e32 v60, 8, v60                               // 0000000794FC: 4A787888
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000079500: D5207C2B 00065680
	s_add_i32 s1, s10, 8                                       // 000000079508: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000007950C: BF08B70A
	s_mov_b32 s10, s1                                          // 000000079510: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 000000079514: BC7C0000
	s_barrier                                                  // 000000079518: BFBD0000
	buffer_gl0_inv                                             // 00000007951C: E0AC0000 00000000
	s_cbranch_scc1 219                                         // 000000079524: BFA200DB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2194>
	v_dual_mov_b32 v47, v45 :: v_dual_mov_b32 v46, v44         // 000000079528: CA10012D 2F2E012C
	v_dual_mov_b32 v61, v51 :: v_dual_mov_b32 v62, v49         // 000000079530: CA100133 3D3E0131
	s_mov_b32 s11, 0                                           // 000000079538: BE8B0080
	s_nop 0                                                    // 00000007953C: BF800000
	global_load_b32 v63, v[46:47], off                         // 000000079540: DC520000 3F7C002E
	v_add_nc_u32_e32 v62, 0x80, v62                            // 000000079548: 4A7C7CFF 00000080
	.long 0xd700012e                                           // 000000079550: D700012E
	v_cndmask_b32_e32 v1, 0x6000, v46, vcc_lo                  // 000000079554: 02025CFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007955C: BF870191
	v_add_co_ci_u32_e64 v47, null, 0, v47, s1                  // 000000079560: D5207C2F 00065E80
	.long 0xd4490004                                           // 000000079568: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v62, vcc_lo                   // 00000007956C: 02027CFF 0000037F
	s_or_b32 s11, s4, s11                                      // 000000079574: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 000000079578: BF8903F7
	ds_store_b32 v61, v63 offset:13056                         // 00000007957C: D8343300 00003F3D
	v_add_nc_u32_e32 v61, 0x204, v61                           // 000000079584: 4A7A7AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000007958C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000079590: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e40>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000079594: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000079598: BF89FC07
	s_barrier                                                  // 00000007959C: BFBD0000
	buffer_gl0_inv                                             // 0000000795A0: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 0000000795A8: BE8B2000
	s_cbranch_execz 65481                                      // 0000000795AC: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dd4>
	v_or_b32_e32 v46, s10, v2                                  // 0000000795B0: 385C040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000795B4: BF870091
	v_or_b32_e32 v61, s7, v46                                  // 0000000795B8: 387A5C07
	.long 0xd4440001                                           // 0000000795BC: D4440001
	v_cndmask_b32_e32 v1, s30, v61, vcc_lo                     // 0000000795C0: 02027A1E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000795C4: 8B7E017E
	s_cbranch_execz 65474                                      // 0000000795C8: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dd4>
	v_mov_b32_e32 v62, 0                                       // 0000000795CC: 7E7C0280
	s_mov_b32 s1, 0                                            // 0000000795D0: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000795D4: BF870009
	v_mad_u64_u32 v[63:64], null, 0x44, s1, v[1:2]             // 0000000795D8: D6FE7C3F 040402FF 00000044
	v_lshl_add_u32 v47, s1, 2, v57                             // 0000000795E4: D646002F 04E50401
	s_add_i32 s4, s1, 16                                       // 0000000795EC: 81049001
	s_cmpk_lt_u32 s1, 0x70                                     // 0000000795F0: B6810070
	s_mov_b32 s1, s4                                           // 0000000795F4: BE810004
	ds_load_2addr_b32 v[66:67], v47 offset0:2 offset1:3        // 0000000795F8: D8DC0302 4200002F
	ds_load_2addr_b32 v[68:69], v47 offset0:4 offset1:5        // 000000079600: D8DC0504 4400002F
	ds_load_2addr_b32 v[64:65], v63 offset0:68 offset1:85      // 000000079608: D8DC5544 4000003F
	ds_load_2addr_b32 v[70:71], v47 offset0:6 offset1:7        // 000000079610: D8DC0706 4600002F
	ds_load_2addr_b32 v[74:75], v47 offset0:8 offset1:9        // 000000079618: D8DC0908 4A00002F
	ds_load_2addr_b32 v[76:77], v47 offset0:10 offset1:11      // 000000079620: D8DC0B0A 4C00002F
	ds_load_2addr_b32 v[78:79], v47 offset0:12 offset1:13      // 000000079628: D8DC0D0C 4E00002F
	ds_load_2addr_b32 v[80:81], v47 offset0:14 offset1:15      // 000000079630: D8DC0F0E 5000002F
	s_waitcnt lgkmcnt(5)                                       // 000000079638: BF89FC57
	v_cvt_f16_f32_e32 v90, v64                                 // 00000007963C: 7EB41540
	v_cvt_f16_f32_e32 v91, v65                                 // 000000079640: 7EB61541
	ds_load_2addr_b32 v[64:65], v63 offset0:34 offset1:51      // 000000079644: D8DC3322 4000003F
	s_waitcnt lgkmcnt(0)                                       // 00000007964C: BF89FC07
	v_cvt_f16_f32_e32 v92, v64                                 // 000000079650: 7EB81540
	v_cvt_f16_f32_e32 v93, v65                                 // 000000079654: 7EBA1541
	ds_load_2addr_b32 v[64:65], v63 offset1:17                 // 000000079658: D8DC1100 4000003F
	s_waitcnt lgkmcnt(0)                                       // 000000079660: BF89FC07
	v_cvt_f16_f32_e32 v94, v64                                 // 000000079664: 7EBC1540
	v_cvt_f16_f32_e32 v95, v65                                 // 000000079668: 7EBE1541
	ds_load_2addr_b32 v[64:65], v47 offset1:1                  // 00000007966C: D8DC0100 4000002F
	s_waitcnt lgkmcnt(0)                                       // 000000079674: BF89FC07
	v_cvt_f16_f32_e32 v47, v64                                 // 000000079678: 7E5E1540
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007967C: BF870001
	v_fma_mix_f32 v47, v47, v94, v62 op_sel_hi:[1,1,0]         // 000000079680: CC20002F 1CFABD2F
	v_cvt_f16_f32_e32 v62, v66                                 // 000000079688: 7E7C1542
	ds_load_2addr_b32 v[72:73], v63 offset0:102 offset1:119    // 00000007968C: D8DC7766 4800003F
	ds_load_2addr_b32 v[82:83], v63 offset0:136 offset1:153    // 000000079694: D8DC9988 5200003F
	ds_load_2addr_b32 v[84:85], v63 offset0:170 offset1:187    // 00000007969C: D8DCBBAA 5400003F
	ds_load_2addr_b32 v[86:87], v63 offset0:204 offset1:221    // 0000000796A4: D8DCDDCC 5600003F
	ds_load_2addr_b32 v[88:89], v63 offset0:238 offset1:255    // 0000000796AC: D8DCFFEE 5800003F
	v_cvt_f16_f32_e32 v63, v65                                 // 0000000796B4: 7E7E1541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000796B8: BF870121
	v_fma_mix_f32 v47, v63, v95, v47 op_sel_hi:[1,1,0]         // 0000000796BC: CC20002F 1CBEBF3F
	v_cvt_f16_f32_e32 v63, v67                                 // 0000000796C4: 7E7E1543
	v_fma_mix_f32 v47, v62, v92, v47 op_sel_hi:[1,1,0]         // 0000000796C8: CC20002F 1CBEB93E
	v_cvt_f16_f32_e32 v62, v68                                 // 0000000796D0: 7E7C1544
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000796D4: BF870002
	v_fma_mix_f32 v47, v63, v93, v47 op_sel_hi:[1,1,0]         // 0000000796D8: CC20002F 1CBEBB3F
	v_cvt_f16_f32_e32 v63, v69                                 // 0000000796E0: 7E7E1545
	s_waitcnt lgkmcnt(4)                                       // 0000000796E4: BF89FC47
	v_cvt_f16_f32_e32 v64, v72                                 // 0000000796E8: 7E801548
	v_cvt_f16_f32_e32 v65, v73                                 // 0000000796EC: 7E821549
	v_fma_mix_f32 v47, v62, v90, v47 op_sel_hi:[1,1,0]         // 0000000796F0: CC20002F 1CBEB53E
	v_cvt_f16_f32_e32 v62, v70                                 // 0000000796F8: 7E7C1546
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000796FC: BF870122
	v_fma_mix_f32 v47, v63, v91, v47 op_sel_hi:[1,1,0]         // 000000079700: CC20002F 1CBEB73F
	v_cvt_f16_f32_e32 v63, v71                                 // 000000079708: 7E7E1547
	v_fma_mix_f32 v47, v62, v64, v47 op_sel_hi:[1,1,0]         // 00000007970C: CC20002F 1CBE813E
	v_cvt_f16_f32_e32 v62, v74                                 // 000000079714: 7E7C154A
	s_waitcnt lgkmcnt(3)                                       // 000000079718: BF89FC37
	v_cvt_f16_f32_e32 v64, v82                                 // 00000007971C: 7E801552
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000079720: BF8701B3
	v_fma_mix_f32 v47, v63, v65, v47 op_sel_hi:[1,1,0]         // 000000079724: CC20002F 1CBE833F
	v_cvt_f16_f32_e32 v63, v75                                 // 00000007972C: 7E7E154B
	v_cvt_f16_f32_e32 v65, v83                                 // 000000079730: 7E821553
	v_fma_mix_f32 v47, v62, v64, v47 op_sel_hi:[1,1,0]         // 000000079734: CC20002F 1CBE813E
	v_cvt_f16_f32_e32 v62, v76                                 // 00000007973C: 7E7C154C
	s_waitcnt lgkmcnt(2)                                       // 000000079740: BF89FC27
	v_cvt_f16_f32_e32 v64, v84                                 // 000000079744: 7E801554
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000079748: BF8701B3
	v_fma_mix_f32 v47, v63, v65, v47 op_sel_hi:[1,1,0]         // 00000007974C: CC20002F 1CBE833F
	v_cvt_f16_f32_e32 v63, v77                                 // 000000079754: 7E7E154D
	v_cvt_f16_f32_e32 v65, v85                                 // 000000079758: 7E821555
	v_fma_mix_f32 v47, v62, v64, v47 op_sel_hi:[1,1,0]         // 00000007975C: CC20002F 1CBE813E
	v_cvt_f16_f32_e32 v62, v78                                 // 000000079764: 7E7C154E
	s_waitcnt lgkmcnt(1)                                       // 000000079768: BF89FC17
	v_cvt_f16_f32_e32 v64, v86                                 // 00000007976C: 7E801556
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000079770: BF8701B3
	v_fma_mix_f32 v47, v63, v65, v47 op_sel_hi:[1,1,0]         // 000000079774: CC20002F 1CBE833F
	v_cvt_f16_f32_e32 v63, v79                                 // 00000007977C: 7E7E154F
	v_cvt_f16_f32_e32 v65, v87                                 // 000000079780: 7E821557
	v_fma_mix_f32 v47, v62, v64, v47 op_sel_hi:[1,1,0]         // 000000079784: CC20002F 1CBE813E
	v_cvt_f16_f32_e32 v62, v80                                 // 00000007978C: 7E7C1550
	s_waitcnt lgkmcnt(0)                                       // 000000079790: BF89FC07
	v_cvt_f16_f32_e32 v64, v88                                 // 000000079794: 7E801558
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000079798: BF8701B3
	v_fma_mix_f32 v47, v63, v65, v47 op_sel_hi:[1,1,0]         // 00000007979C: CC20002F 1CBE833F
	v_cvt_f16_f32_e32 v63, v81                                 // 0000000797A4: 7E7E1551
	v_cvt_f16_f32_e32 v65, v89                                 // 0000000797A8: 7E821559
	v_fma_mix_f32 v47, v62, v64, v47 op_sel_hi:[1,1,0]         // 0000000797AC: CC20002F 1CBE813E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000797B4: BF870001
	v_fma_mix_f32 v62, v63, v65, v47 op_sel_hi:[1,1,0]         // 0000000797B8: CC20003E 1CBE833F
	s_cbranch_scc1 65412                                       // 0000000797C0: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ed4>
	v_dual_mov_b32 v63, v1 :: v_dual_lshlrev_b32 v46, 2, v46   // 0000000797C4: CA220101 3F2E5C82
	s_mov_b32 s12, 0                                           // 0000000797CC: BE8C0080
	ds_load_b32 v64, v46 offset:17440                          // 0000000797D0: D8D84420 4000002E
	v_dual_mov_b32 v47, v43 :: v_dual_mov_b32 v46, v42         // 0000000797D8: CA10012B 2F2E012A
	s_waitcnt lgkmcnt(0)                                       // 0000000797E0: BF89FC07
	v_mul_f32_e32 v62, v62, v64                                // 0000000797E4: 107C813E
	v_mov_b32_e32 v64, v60                                     // 0000000797E8: 7E80033C
	s_nop 0                                                    // 0000000797EC: BF800000
	s_nop 0                                                    // 0000000797F0: BF800000
	s_nop 0                                                    // 0000000797F4: BF800000
	s_nop 0                                                    // 0000000797F8: BF800000
	s_nop 0                                                    // 0000000797FC: BF800000
	global_load_b32 v65, v[46:47], off                         // 000000079800: DC520000 417C002E
	ds_load_b32 v66, v63 offset:8704                           // 000000079808: D8D82200 4200003F
	v_add_nc_u32_e32 v64, -1, v64                              // 000000079810: 4A8080C1
	.long 0xd700012e                                           // 000000079814: D700012E
	v_cndmask_b32_e32 v0, v46, v132, vcc_lo                    // 000000079818: 0201092E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007981C: BF870191
	v_add_co_ci_u32_e64 v47, null, 0, v47, s1                  // 000000079820: D5207C2F 00065E80
	.long 0xd44a0004                                           // 000000079828: D44A0004
	v_cndmask_b32_e32 v1, 0, v64, vcc_lo                       // 00000007982C: 02028080
	v_add_nc_u32_e32 v63, 0x44, v63                            // 000000079830: 4A7E7EFF 00000044
	s_or_b32 s12, s4, s12                                      // 000000079838: 8C0C0C04
	s_waitcnt lgkmcnt(0)                                       // 00000007983C: BF89FC07
	v_cvt_f16_f32_e32 v66, v66                                 // 000000079840: 7E841542
	s_waitcnt vmcnt(0)                                         // 000000079844: BF8903F7
	v_cvt_f16_f32_e32 v65, v65                                 // 000000079848: 7E821541
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007984C: BF870001
	v_fma_mix_f32 v62, v65, v66, v62 op_sel_hi:[1,1,0]         // 000000079850: CC20003E 1CFA8541
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 000000079858: 917E0C7E
	s_cbranch_execnz 65512                                     // 00000007985C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2100>
	s_or_b32 exec_lo, exec_lo, s12                             // 000000079860: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000079864: BF870121
	v_bfe_u32 v63, v62, 16, 1                                  // 000000079868: D610003F 0205213E
	v_mad_u64_u32 v[46:47], null, 0x3000, v61, v[4:5]          // 000000079870: D6FE7C2E 04127AFF 00003000
	v_add3_u32 v61, v62, v63, 0x7fff                           // 00000007987C: D655003D 03FE7F3E 00007FFF
	global_store_d16_hi_b16 v[46:47], v61, off                 // 000000079888: DC960000 007C3D2E
	s_branch 65296                                             // 000000079890: BFA0FF10 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dd4>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 000000079894: A201FF06 3FB8AA3B
	v_mov_b32_e32 v44, v49                                     // 00000007989C: 7E580331
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000798A0: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000798A4: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 0000000798AC: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 0000000798B0: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 0000000798B8: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 0000000798C0: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000798C4: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 0000000798C8: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000798D0: A0010401
	s_mov_b32 s4, 0                                            // 0000000798D4: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000798D8: BF87000A
	v_exp_f32_e32 v42, s1                                      // 0000000798DC: 7E544A01
	s_cvt_i32_f32 s1, s7                                       // 0000000798E0: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000798E4: BF870585
	.long 0xd71c002a                                           // 0000000798E8: D71C002A
	v_cndmask_b32_e32 v0, v42, v1, vcc_lo                      // 0000000798EC: 0200032A
	s_cselect_b32 s1, -1, 0                                    // 0000000798F0: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 0000000798F4: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000798FC: BF870131
	v_cndmask_b32_e64 v43, 0, v42, s1                          // 000000079900: D501002B 00065480
	s_cselect_b32 s1, -1, 0                                    // 000000079908: 980180C1
	v_mov_b32_e32 v42, v48                                     // 00000007990C: 7E540330
	v_cndmask_b32_e64 v43, 0x7f800000, v43, s1                 // 000000079910: D501002B 000656FF 7F800000
	ds_load_b32 v45, v42                                       // 00000007991C: D8D80000 2D00002A
	v_add_nc_u32_e32 v44, 0x80, v44                            // 000000079924: 4A5858FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007992C: BF870001
	.long 0xd4490001                                           // 000000079930: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v44, vcc_lo                   // 000000079934: 020258FF 0000077F
	s_or_b32 s4, s1, s4                                        // 00000007993C: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 000000079940: BF89FC07
	v_mul_f32_e32 v45, v43, v45                                // 000000079944: 105A5B2B
	ds_store_b32 v42, v45                                      // 000000079948: D8340000 00002D2A
	v_add_nc_u32_e32 v42, 0x220, v42                           // 000000079950: 4A5454FF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000079958: 917E047E
	s_cbranch_execnz 65519                                     // 00000007995C: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x221c>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000079960: 8C7E047E
	v_dual_mov_b32 v43, v27 :: v_dual_mov_b32 v42, v26         // 000000079964: CA10011B 2B2A011A
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v45, v51           // 00000007996C: CA100080 2C2C0133
	v_mov_b32_e32 v46, v49                                     // 000000079974: 7E5C0331
	s_mov_b32 s6, 0                                            // 000000079978: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007997C: BF89FC07
	s_barrier                                                  // 000000079980: BFBD0000
	buffer_gl0_inv                                             // 000000079984: E0AC0000 00000000
	s_nop 0                                                    // 00000007998C: BF800000
	s_nop 0                                                    // 000000079990: BF800000
	s_nop 0                                                    // 000000079994: BF800000
	s_nop 0                                                    // 000000079998: BF800000
	s_nop 0                                                    // 00000007999C: BF800000
	s_nop 0                                                    // 0000000799A0: BF800000
	s_nop 0                                                    // 0000000799A4: BF800000
	s_nop 0                                                    // 0000000799A8: BF800000
	s_nop 0                                                    // 0000000799AC: BF800000
	s_nop 0                                                    // 0000000799B0: BF800000
	s_nop 0                                                    // 0000000799B4: BF800000
	s_nop 0                                                    // 0000000799B8: BF800000
	s_nop 0                                                    // 0000000799BC: BF800000
	global_load_b32 v47, v[42:43], off                         // 0000000799C0: DC520000 2F7C002A
	ds_load_b32 v60, v44 offset:17184                          // 0000000799C8: D8D84320 3C00002C
	v_add_nc_u32_e32 v46, 0x80, v46                            // 0000000799D0: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 0000000799D8: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 0000000799DC: 020254FF 00006000
	v_add_nc_u32_e32 v44, 4, v44                               // 0000000799E4: 4A585884
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 0000000799E8: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000799F0: BF870004
	.long 0xd4490004                                           // 0000000799F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 0000000799F8: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000079A00: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000079A04: BF890007
	v_mul_f32_e32 v47, v47, v60                                // 000000079A08: 105E792F
	ds_store_b32 v45, v47 offset:13056                         // 000000079A0C: D8343300 00002F2D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 000000079A14: 4A5A5AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000079A1C: 917E067E
	s_cbranch_execnz 65511                                     // 000000079A20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x22c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000079A24: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000079A28: BF89FC07
	s_barrier                                                  // 000000079A2C: BFBD0000
	buffer_gl0_inv                                             // 000000079A30: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v59 offset1:17                 // 000000079A38: D8DC1100 2A00003B
	ds_load_2addr_b32 v[44:45], v59 offset0:34 offset1:51      // 000000079A40: D8DC3322 2C00003B
	ds_load_2addr_b32 v[46:47], v59 offset0:68 offset1:85      // 000000079A48: D8DC5544 2E00003B
	ds_load_2addr_b32 v[60:61], v59 offset0:102 offset1:119    // 000000079A50: D8DC7766 3C00003B
	v_mov_b32_e32 v62, v0                                      // 000000079A58: 7E7C0300
	s_mov_b32 s4, 0                                            // 000000079A5C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 000000079A60: BF89FC37
	v_cvt_f16_f32_e32 v42, v42                                 // 000000079A64: 7E54152A
	v_cvt_f16_f32_e32 v43, v43                                 // 000000079A68: 7E56152B
	s_waitcnt lgkmcnt(2)                                       // 000000079A6C: BF89FC27
	v_cvt_f16_f32_e32 v44, v44                                 // 000000079A70: 7E58152C
	v_cvt_f16_f32_e32 v45, v45                                 // 000000079A74: 7E5A152D
	s_waitcnt lgkmcnt(1)                                       // 000000079A78: BF89FC17
	v_cvt_f16_f32_e32 v46, v46                                 // 000000079A7C: 7E5C152E
	v_cvt_f16_f32_e32 v47, v47                                 // 000000079A80: 7E5E152F
	s_waitcnt lgkmcnt(0)                                       // 000000079A84: BF89FC07
	v_cvt_f16_f32_e32 v60, v60                                 // 000000079A88: 7E78153C
	v_cvt_f16_f32_e32 v61, v61                                 // 000000079A8C: 7E7A153D
	v_cvt_f32_f16_e32 v42, v42                                 // 000000079A90: 7E54172A
	v_cvt_f32_f16_e32 v43, v43                                 // 000000079A94: 7E56172B
	v_cvt_f32_f16_e32 v44, v44                                 // 000000079A98: 7E58172C
	v_cvt_f32_f16_e32 v45, v45                                 // 000000079A9C: 7E5A172D
	v_cvt_f32_f16_e32 v46, v46                                 // 000000079AA0: 7E5C172E
	v_cvt_f32_f16_e32 v47, v47                                 // 000000079AA4: 7E5E172F
	v_cvt_f32_f16_e32 v60, v60                                 // 000000079AA8: 7E78173C
	v_cvt_f32_f16_e32 v61, v61                                 // 000000079AAC: 7E7A173D
	v_lshrrev_b32_e32 v63, 4, v62                              // 000000079AB0: 327E7C84
	.long 0xd4490001                                           // 000000079AB4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v62, vcc_lo                   // 000000079AB8: 02027CFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000079AC0: BF870002
	v_lshlrev_b32_e32 v70, 2, v63                              // 000000079AC4: 308C7E82
	v_mad_u64_u32 v[63:64], null, 0x44, v63, v[1:2]            // 000000079AC8: D6FE7C3F 04067EFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000079AD4: 8C040401
	v_add_nc_u32_e32 v65, 0x3200, v70                          // 000000079AD8: 4A828CFF 00003200
	v_add_nc_u32_e32 v66, 0x3600, v70                          // 000000079AE0: 4A848CFF 00003600
	v_add_nc_u32_e32 v68, 0x3a00, v70                          // 000000079AE8: 4A888CFF 00003A00
	v_add_nc_u32_e32 v70, 0x3e00, v70                          // 000000079AF0: 4A8C8CFF 00003E00
	ds_load_b32 v71, v63                                       // 000000079AF8: D8D80000 4700003F
	ds_load_2addr_b32 v[66:67], v66 offset0:66 offset1:195     // 000000079B00: D8DCC342 42000042
	ds_load_2addr_b32 v[64:65], v65 offset0:64 offset1:193     // 000000079B08: D8DCC140 40000041
	ds_load_2addr_b32 v[68:69], v68 offset0:68 offset1:197     // 000000079B10: D8DCC544 44000044
	s_waitcnt lgkmcnt(2)                                       // 000000079B18: BF89FC27
	v_cvt_f16_f32_e32 v66, v66                                 // 000000079B1C: 7E841542
	s_waitcnt lgkmcnt(1)                                       // 000000079B20: BF89FC17
	v_cvt_f16_f32_e32 v64, v64                                 // 000000079B24: 7E801540
	v_cvt_f16_f32_e32 v72, v65                                 // 000000079B28: 7E901541
	v_cvt_f16_f32_e32 v67, v67                                 // 000000079B2C: 7E861543
	s_waitcnt lgkmcnt(0)                                       // 000000079B30: BF89FC07
	v_cvt_f16_f32_e32 v68, v68                                 // 000000079B34: 7E881544
	v_fma_mix_f32 v71, v64, v42, v71 op_sel_hi:[1,0,0]         // 000000079B38: CC200047 0D1E5540
	ds_load_2addr_b32 v[64:65], v70 offset0:70 offset1:199     // 000000079B40: D8DCC746 40000046
	v_fma_mix_f32 v70, v72, v43, v71 op_sel_hi:[1,0,0]         // 000000079B48: CC200046 0D1E5748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079B50: BF870091
	v_fma_mix_f32 v66, v66, v44, v70 op_sel_hi:[1,0,0]         // 000000079B54: CC200042 0D1A5942
	v_fma_mix_f32 v66, v67, v45, v66 op_sel_hi:[1,0,0]         // 000000079B5C: CC200042 0D0A5B43
	v_cvt_f16_f32_e32 v67, v69                                 // 000000079B64: 7E861545
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000079B68: BF8701C2
	v_fma_mix_f32 v66, v68, v46, v66 op_sel_hi:[1,0,0]         // 000000079B6C: CC200042 0D0A5D44
	s_waitcnt lgkmcnt(0)                                       // 000000079B74: BF89FC07
	v_cvt_f16_f32_e32 v64, v64                                 // 000000079B78: 7E801540
	v_cvt_f16_f32_e32 v65, v65                                 // 000000079B7C: 7E821541
	v_fma_mix_f32 v66, v67, v47, v66 op_sel_hi:[1,0,0]         // 000000079B80: CC200042 0D0A5F43
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000079B88: BF870121
	v_fma_mix_f32 v64, v64, v60, v66 op_sel_hi:[1,0,0]         // 000000079B8C: CC200040 0D0A7940
	v_add_nc_u32_e32 v66, 0x80, v62                            // 000000079B94: 4A847CFF 00000080
	v_fma_mix_f32 v64, v65, v61, v64 op_sel_hi:[1,0,0]         // 000000079B9C: CC200040 0D027B41
	s_delay_alu instid0(VALU_DEP_2)                            // 000000079BA4: BF870002
	v_mov_b32_e32 v62, v66                                     // 000000079BA8: 7E7C0342
	ds_store_b32 v63, v64                                      // 000000079BAC: D8340000 0000403F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000079BB4: 917E047E
	s_cbranch_execnz 65469                                     // 000000079BB8: BFA6FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23b0>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000079BBC: 8C7E047E
	v_dual_mov_b32 v43, v29 :: v_dual_mov_b32 v42, v28         // 000000079BC0: CA10011D 2B2A011C
	v_dual_mov_b32 v44, v51 :: v_dual_mov_b32 v45, 0           // 000000079BC8: CA100133 2C2C0080
	v_mov_b32_e32 v46, v49                                     // 000000079BD0: 7E5C0331
	s_mov_b32 s6, 0                                            // 000000079BD4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000079BD8: BF89FC07
	s_barrier                                                  // 000000079BDC: BFBD0000
	buffer_gl0_inv                                             // 000000079BE0: E0AC0000 00000000
	s_nop 0                                                    // 000000079BE8: BF800000
	s_nop 0                                                    // 000000079BEC: BF800000
	s_nop 0                                                    // 000000079BF0: BF800000
	s_nop 0                                                    // 000000079BF4: BF800000
	s_nop 0                                                    // 000000079BF8: BF800000
	s_nop 0                                                    // 000000079BFC: BF800000
	global_load_b32 v47, v[42:43], off                         // 000000079C00: DC520000 2F7C002A
	ds_load_b32 v60, v45 offset:17216                          // 000000079C08: D8D84340 3C00002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 000000079C10: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 000000079C18: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000079C1C: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 000000079C24: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000079C28: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 000000079C30: BF870004
	.long 0xd4490004                                           // 000000079C34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 000000079C38: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000079C40: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000079C44: BF890007
	v_mul_f32_e32 v47, v47, v60                                // 000000079C48: 105E792F
	ds_store_b32 v44, v47 offset:13056                         // 000000079C4C: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000079C54: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000079C5C: 917E067E
	s_cbranch_execnz 65511                                     // 000000079C60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2500>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000079C64: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000079C68: BF89FC07
	s_barrier                                                  // 000000079C6C: BFBD0000
	buffer_gl0_inv                                             // 000000079C70: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v59 offset0:136 offset1:153    // 000000079C78: D8DC9988 2A00003B
	ds_load_2addr_b32 v[44:45], v59 offset0:170 offset1:187    // 000000079C80: D8DCBBAA 2C00003B
	ds_load_2addr_b32 v[46:47], v59 offset0:204 offset1:221    // 000000079C88: D8DCDDCC 2E00003B
	ds_load_2addr_b32 v[60:61], v59 offset0:238 offset1:255    // 000000079C90: D8DCFFEE 3C00003B
	v_mov_b32_e32 v62, v0                                      // 000000079C98: 7E7C0300
	s_mov_b32 s4, 0                                            // 000000079C9C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 000000079CA0: BF89FC37
	v_cvt_f16_f32_e32 v42, v42                                 // 000000079CA4: 7E54152A
	v_cvt_f16_f32_e32 v43, v43                                 // 000000079CA8: 7E56152B
	s_waitcnt lgkmcnt(2)                                       // 000000079CAC: BF89FC27
	v_cvt_f16_f32_e32 v44, v44                                 // 000000079CB0: 7E58152C
	v_cvt_f16_f32_e32 v45, v45                                 // 000000079CB4: 7E5A152D
	s_waitcnt lgkmcnt(1)                                       // 000000079CB8: BF89FC17
	v_cvt_f16_f32_e32 v46, v46                                 // 000000079CBC: 7E5C152E
	v_cvt_f16_f32_e32 v47, v47                                 // 000000079CC0: 7E5E152F
	s_waitcnt lgkmcnt(0)                                       // 000000079CC4: BF89FC07
	v_cvt_f16_f32_e32 v60, v60                                 // 000000079CC8: 7E78153C
	v_cvt_f16_f32_e32 v61, v61                                 // 000000079CCC: 7E7A153D
	v_cvt_f32_f16_e32 v42, v42                                 // 000000079CD0: 7E54172A
	v_cvt_f32_f16_e32 v43, v43                                 // 000000079CD4: 7E56172B
	v_cvt_f32_f16_e32 v44, v44                                 // 000000079CD8: 7E58172C
	v_cvt_f32_f16_e32 v45, v45                                 // 000000079CDC: 7E5A172D
	v_cvt_f32_f16_e32 v46, v46                                 // 000000079CE0: 7E5C172E
	v_cvt_f32_f16_e32 v47, v47                                 // 000000079CE4: 7E5E172F
	v_cvt_f32_f16_e32 v60, v60                                 // 000000079CE8: 7E78173C
	v_cvt_f32_f16_e32 v61, v61                                 // 000000079CEC: 7E7A173D
	v_lshrrev_b32_e32 v63, 4, v62                              // 000000079CF0: 327E7C84
	.long 0xd4490001                                           // 000000079CF4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v62, vcc_lo                   // 000000079CF8: 02027CFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000079D00: BF870002
	v_lshlrev_b32_e32 v70, 2, v63                              // 000000079D04: 308C7E82
	v_mad_u64_u32 v[63:64], null, 0x44, v63, v[1:2]            // 000000079D08: D6FE7C3F 04067EFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000079D14: 8C040401
	v_add_nc_u32_e32 v65, 0x3200, v70                          // 000000079D18: 4A828CFF 00003200
	v_add_nc_u32_e32 v66, 0x3600, v70                          // 000000079D20: 4A848CFF 00003600
	v_add_nc_u32_e32 v68, 0x3a00, v70                          // 000000079D28: 4A888CFF 00003A00
	v_add_nc_u32_e32 v70, 0x3e00, v70                          // 000000079D30: 4A8C8CFF 00003E00
	ds_load_b32 v71, v63                                       // 000000079D38: D8D80000 4700003F
	ds_load_2addr_b32 v[66:67], v66 offset0:66 offset1:195     // 000000079D40: D8DCC342 42000042
	ds_load_2addr_b32 v[64:65], v65 offset0:64 offset1:193     // 000000079D48: D8DCC140 40000041
	ds_load_2addr_b32 v[68:69], v68 offset0:68 offset1:197     // 000000079D50: D8DCC544 44000044
	s_waitcnt lgkmcnt(2)                                       // 000000079D58: BF89FC27
	v_cvt_f16_f32_e32 v66, v66                                 // 000000079D5C: 7E841542
	s_waitcnt lgkmcnt(1)                                       // 000000079D60: BF89FC17
	v_cvt_f16_f32_e32 v64, v64                                 // 000000079D64: 7E801540
	v_cvt_f16_f32_e32 v72, v65                                 // 000000079D68: 7E901541
	v_cvt_f16_f32_e32 v67, v67                                 // 000000079D6C: 7E861543
	s_waitcnt lgkmcnt(0)                                       // 000000079D70: BF89FC07
	v_cvt_f16_f32_e32 v68, v68                                 // 000000079D74: 7E881544
	v_fma_mix_f32 v71, v64, v42, v71 op_sel_hi:[1,0,0]         // 000000079D78: CC200047 0D1E5540
	ds_load_2addr_b32 v[64:65], v70 offset0:70 offset1:199     // 000000079D80: D8DCC746 40000046
	v_fma_mix_f32 v70, v72, v43, v71 op_sel_hi:[1,0,0]         // 000000079D88: CC200046 0D1E5748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079D90: BF870091
	v_fma_mix_f32 v66, v66, v44, v70 op_sel_hi:[1,0,0]         // 000000079D94: CC200042 0D1A5942
	v_fma_mix_f32 v66, v67, v45, v66 op_sel_hi:[1,0,0]         // 000000079D9C: CC200042 0D0A5B43
	v_cvt_f16_f32_e32 v67, v69                                 // 000000079DA4: 7E861545
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000079DA8: BF8701C2
	v_fma_mix_f32 v66, v68, v46, v66 op_sel_hi:[1,0,0]         // 000000079DAC: CC200042 0D0A5D44
	s_waitcnt lgkmcnt(0)                                       // 000000079DB4: BF89FC07
	v_cvt_f16_f32_e32 v64, v64                                 // 000000079DB8: 7E801540
	v_cvt_f16_f32_e32 v65, v65                                 // 000000079DBC: 7E821541
	v_fma_mix_f32 v66, v67, v47, v66 op_sel_hi:[1,0,0]         // 000000079DC0: CC200042 0D0A5F43
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000079DC8: BF870121
	v_fma_mix_f32 v64, v64, v60, v66 op_sel_hi:[1,0,0]         // 000000079DCC: CC200040 0D0A7940
	v_add_nc_u32_e32 v66, 0x80, v62                            // 000000079DD4: 4A847CFF 00000080
	v_fma_mix_f32 v64, v65, v61, v64 op_sel_hi:[1,0,0]         // 000000079DDC: CC200040 0D027B41
	s_delay_alu instid0(VALU_DEP_2)                            // 000000079DE4: BF870002
	v_mov_b32_e32 v62, v66                                     // 000000079DE8: 7E7C0342
	ds_store_b32 v63, v64                                      // 000000079DEC: D8340000 0000403F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000079DF4: 917E047E
	s_cbranch_execnz 65469                                     // 000000079DF8: BFA6FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25f0>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000079DFC: 8C7E047E
	v_dual_mov_b32 v43, v31 :: v_dual_mov_b32 v42, v30         // 000000079E00: CA10011F 2B2A011E
	v_dual_mov_b32 v44, v51 :: v_dual_mov_b32 v45, 0           // 000000079E08: CA100133 2C2C0080
	v_mov_b32_e32 v46, v49                                     // 000000079E10: 7E5C0331
	s_mov_b32 s6, 0                                            // 000000079E14: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000079E18: BF89FC07
	s_barrier                                                  // 000000079E1C: BFBD0000
	buffer_gl0_inv                                             // 000000079E20: E0AC0000 00000000
	s_nop 0                                                    // 000000079E28: BF800000
	s_nop 0                                                    // 000000079E2C: BF800000
	s_nop 0                                                    // 000000079E30: BF800000
	s_nop 0                                                    // 000000079E34: BF800000
	s_nop 0                                                    // 000000079E38: BF800000
	s_nop 0                                                    // 000000079E3C: BF800000
	global_load_b32 v47, v[42:43], off                         // 000000079E40: DC520000 2F7C002A
	ds_load_b32 v60, v45 offset:17248                          // 000000079E48: D8D84360 3C00002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 000000079E50: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 000000079E58: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000079E5C: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 000000079E64: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000079E68: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 000000079E70: BF870004
	.long 0xd4490004                                           // 000000079E74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 000000079E78: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000079E80: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000079E84: BF890007
	v_mul_f32_e32 v47, v47, v60                                // 000000079E88: 105E792F
	ds_store_b32 v44, v47 offset:13056                         // 000000079E8C: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000079E94: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000079E9C: 917E067E
	s_cbranch_execnz 65511                                     // 000000079EA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2740>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000079EA4: 8C7E067E
	v_add_nc_u32_e32 v44, 0x400, v59                           // 000000079EA8: 4A5876FF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000079EB0: BF89FC07
	s_barrier                                                  // 000000079EB4: BFBD0000
	buffer_gl0_inv                                             // 000000079EB8: E0AC0000 00000000
	s_mov_b32 s4, 0                                            // 000000079EC0: BE840080
	ds_load_2addr_b32 v[42:43], v44 offset0:16 offset1:33      // 000000079EC4: D8DC2110 2A00002C
	ds_load_2addr_b32 v[45:46], v44 offset0:50 offset1:67      // 000000079ECC: D8DC4332 2D00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:84 offset1:101     // 000000079ED4: D8DC6554 3C00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:118 offset1:135    // 000000079EDC: D8DC8776 3E00002C
	s_waitcnt lgkmcnt(3)                                       // 000000079EE4: BF89FC37
	v_cvt_f16_f32_e32 v42, v42                                 // 000000079EE8: 7E54152A
	v_cvt_f16_f32_e32 v43, v43                                 // 000000079EEC: 7E56152B
	s_waitcnt lgkmcnt(2)                                       // 000000079EF0: BF89FC27
	v_cvt_f16_f32_e32 v45, v45                                 // 000000079EF4: 7E5A152D
	v_cvt_f16_f32_e32 v46, v46                                 // 000000079EF8: 7E5C152E
	s_waitcnt lgkmcnt(1)                                       // 000000079EFC: BF89FC17
	v_cvt_f16_f32_e32 v47, v60                                 // 000000079F00: 7E5E153C
	v_cvt_f16_f32_e32 v60, v61                                 // 000000079F04: 7E78153D
	s_waitcnt lgkmcnt(0)                                       // 000000079F08: BF89FC07
	v_cvt_f16_f32_e32 v61, v62                                 // 000000079F0C: 7E7A153E
	v_cvt_f16_f32_e32 v62, v63                                 // 000000079F10: 7E7C153F
	v_cvt_f32_f16_e32 v42, v42                                 // 000000079F14: 7E54172A
	v_cvt_f32_f16_e32 v43, v43                                 // 000000079F18: 7E56172B
	v_cvt_f32_f16_e32 v45, v45                                 // 000000079F1C: 7E5A172D
	v_cvt_f32_f16_e32 v46, v46                                 // 000000079F20: 7E5C172E
	v_cvt_f32_f16_e32 v47, v47                                 // 000000079F24: 7E5E172F
	v_cvt_f32_f16_e32 v60, v60                                 // 000000079F28: 7E78173C
	v_cvt_f32_f16_e32 v61, v61                                 // 000000079F2C: 7E7A173D
	v_cvt_f32_f16_e32 v62, v62                                 // 000000079F30: 7E7C173E
	v_mov_b32_e32 v63, v0                                      // 000000079F34: 7E7E0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000079F38: BF870121
	v_lshrrev_b32_e32 v64, 4, v63                              // 000000079F3C: 32807E84
	.long 0xd4490001                                           // 000000079F40: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v63, vcc_lo                   // 000000079F44: 02027EFF 0000077F
	v_lshlrev_b32_e32 v71, 2, v64                              // 000000079F4C: 308E8082
	v_mad_u64_u32 v[64:65], null, 0x44, v64, v[1:2]            // 000000079F50: D6FE7C40 040680FF 00000044
	s_or_b32 s4, s1, s4                                        // 000000079F5C: 8C040401
	v_add_nc_u32_e32 v66, 0x3200, v71                          // 000000079F60: 4A848EFF 00003200
	v_add_nc_u32_e32 v67, 0x3600, v71                          // 000000079F68: 4A868EFF 00003600
	v_add_nc_u32_e32 v69, 0x3a00, v71                          // 000000079F70: 4A8A8EFF 00003A00
	v_add_nc_u32_e32 v71, 0x3e00, v71                          // 000000079F78: 4A8E8EFF 00003E00
	ds_load_b32 v72, v64                                       // 000000079F80: D8D80000 48000040
	ds_load_2addr_b32 v[67:68], v67 offset0:66 offset1:195     // 000000079F88: D8DCC342 43000043
	ds_load_2addr_b32 v[65:66], v66 offset0:64 offset1:193     // 000000079F90: D8DCC140 41000042
	ds_load_2addr_b32 v[69:70], v69 offset0:68 offset1:197     // 000000079F98: D8DCC544 45000045
	s_waitcnt lgkmcnt(2)                                       // 000000079FA0: BF89FC27
	v_cvt_f16_f32_e32 v67, v67                                 // 000000079FA4: 7E861543
	s_waitcnt lgkmcnt(1)                                       // 000000079FA8: BF89FC17
	v_cvt_f16_f32_e32 v65, v65                                 // 000000079FAC: 7E821541
	v_cvt_f16_f32_e32 v73, v66                                 // 000000079FB0: 7E921542
	v_cvt_f16_f32_e32 v68, v68                                 // 000000079FB4: 7E881544
	s_waitcnt lgkmcnt(0)                                       // 000000079FB8: BF89FC07
	v_cvt_f16_f32_e32 v69, v69                                 // 000000079FBC: 7E8A1545
	v_fma_mix_f32 v72, v65, v42, v72 op_sel_hi:[1,0,0]         // 000000079FC0: CC200048 0D225541
	ds_load_2addr_b32 v[65:66], v71 offset0:70 offset1:199     // 000000079FC8: D8DCC746 41000047
	v_fma_mix_f32 v71, v73, v43, v72 op_sel_hi:[1,0,0]         // 000000079FD0: CC200047 0D225749
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000079FD8: BF870091
	v_fma_mix_f32 v67, v67, v45, v71 op_sel_hi:[1,0,0]         // 000000079FDC: CC200043 0D1E5B43
	v_fma_mix_f32 v67, v68, v46, v67 op_sel_hi:[1,0,0]         // 000000079FE4: CC200043 0D0E5D44
	v_cvt_f16_f32_e32 v68, v70                                 // 000000079FEC: 7E881546
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000079FF0: BF8701C2
	v_fma_mix_f32 v67, v69, v47, v67 op_sel_hi:[1,0,0]         // 000000079FF4: CC200043 0D0E5F45
	s_waitcnt lgkmcnt(0)                                       // 000000079FFC: BF89FC07
	v_cvt_f16_f32_e32 v65, v65                                 // 00000007A000: 7E821541
	v_cvt_f16_f32_e32 v66, v66                                 // 00000007A004: 7E841542
	v_fma_mix_f32 v67, v68, v60, v67 op_sel_hi:[1,0,0]         // 00000007A008: CC200043 0D0E7944
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007A010: BF870121
	v_fma_mix_f32 v65, v65, v61, v67 op_sel_hi:[1,0,0]         // 00000007A014: CC200041 0D0E7B41
	v_add_nc_u32_e32 v67, 0x80, v63                            // 00000007A01C: 4A867EFF 00000080
	v_fma_mix_f32 v65, v66, v62, v65 op_sel_hi:[1,0,0]         // 00000007A024: CC200041 0D067D42
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007A02C: BF870002
	v_mov_b32_e32 v63, v67                                     // 00000007A030: 7E7E0343
	ds_store_b32 v64, v65                                      // 00000007A034: D8340000 00004140
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007A03C: 917E047E
	s_cbranch_execnz 65469                                     // 00000007A040: BFA6FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2838>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007A044: 8C7E047E
	v_dual_mov_b32 v43, v33 :: v_dual_mov_b32 v42, v32         // 00000007A048: CA100121 2B2A0120
	v_dual_mov_b32 v45, v51 :: v_dual_mov_b32 v46, 0           // 00000007A050: CA100133 2D2E0080
	v_mov_b32_e32 v47, v49                                     // 00000007A058: 7E5E0331
	s_mov_b32 s6, 0                                            // 00000007A05C: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007A060: BF89FC07
	s_barrier                                                  // 00000007A064: BFBD0000
	buffer_gl0_inv                                             // 00000007A068: E0AC0000 00000000
	s_nop 0                                                    // 00000007A070: BF800000
	s_nop 0                                                    // 00000007A074: BF800000
	s_nop 0                                                    // 00000007A078: BF800000
	s_nop 0                                                    // 00000007A07C: BF800000
	global_load_b32 v60, v[42:43], off                         // 00000007A080: DC520000 3C7C002A
	ds_load_b32 v61, v46 offset:17280                          // 00000007A088: D8D84380 3D00002E
	v_add_nc_u32_e32 v47, 0x80, v47                            // 00000007A090: 4A5E5EFF 00000080
	.long 0xd700012a                                           // 00000007A098: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000007A09C: 020254FF 00006000
	v_add_nc_u32_e32 v46, 4, v46                               // 00000007A0A4: 4A5C5C84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000007A0A8: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007A0B0: BF870004
	.long 0xd4490004                                           // 00000007A0B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v47, vcc_lo                   // 00000007A0B8: 02025EFF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007A0C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007A0C4: BF890007
	v_mul_f32_e32 v60, v60, v61                                // 00000007A0C8: 10787B3C
	ds_store_b32 v45, v60 offset:13056                         // 00000007A0CC: D8343300 00003C2D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 00000007A0D4: 4A5A5AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007A0DC: 917E067E
	s_cbranch_execnz 65511                                     // 00000007A0E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2980>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007A0E4: 8C7E067E
	v_add_nc_u32_e32 v47, 0x600, v59                           // 00000007A0E8: 4A5E76FF 00000600
	s_waitcnt lgkmcnt(0)                                       // 00000007A0F0: BF89FC07
	s_barrier                                                  // 00000007A0F4: BFBD0000
	buffer_gl0_inv                                             // 00000007A0F8: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v44 offset0:152 offset1:169    // 00000007A100: D8DCA998 2A00002C
	ds_load_2addr_b32 v[45:46], v44 offset0:186 offset1:203    // 00000007A108: D8DCCBBA 2D00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:220 offset1:237    // 00000007A110: D8DCEDDC 3C00002C
	ds_load_2addr_b32 v[62:63], v47 offset0:126 offset1:143    // 00000007A118: D8DC8F7E 3E00002F
	s_mov_b32 s4, 0                                            // 00000007A120: BE840080
	s_waitcnt lgkmcnt(3)                                       // 00000007A124: BF89FC37
	v_cvt_f16_f32_e32 v42, v42                                 // 00000007A128: 7E54152A
	v_cvt_f16_f32_e32 v43, v43                                 // 00000007A12C: 7E56152B
	s_waitcnt lgkmcnt(2)                                       // 00000007A130: BF89FC27
	v_cvt_f16_f32_e32 v44, v45                                 // 00000007A134: 7E58152D
	v_cvt_f16_f32_e32 v45, v46                                 // 00000007A138: 7E5A152E
	s_waitcnt lgkmcnt(1)                                       // 00000007A13C: BF89FC17
	v_cvt_f16_f32_e32 v46, v60                                 // 00000007A140: 7E5C153C
	v_cvt_f16_f32_e32 v47, v61                                 // 00000007A144: 7E5E153D
	s_waitcnt lgkmcnt(0)                                       // 00000007A148: BF89FC07
	v_cvt_f16_f32_e32 v60, v62                                 // 00000007A14C: 7E78153E
	v_cvt_f16_f32_e32 v61, v63                                 // 00000007A150: 7E7A153F
	v_cvt_f32_f16_e32 v42, v42                                 // 00000007A154: 7E54172A
	v_cvt_f32_f16_e32 v43, v43                                 // 00000007A158: 7E56172B
	v_cvt_f32_f16_e32 v44, v44                                 // 00000007A15C: 7E58172C
	v_cvt_f32_f16_e32 v45, v45                                 // 00000007A160: 7E5A172D
	v_cvt_f32_f16_e32 v46, v46                                 // 00000007A164: 7E5C172E
	v_cvt_f32_f16_e32 v47, v47                                 // 00000007A168: 7E5E172F
	v_cvt_f32_f16_e32 v60, v60                                 // 00000007A16C: 7E78173C
	v_cvt_f32_f16_e32 v61, v61                                 // 00000007A170: 7E7A173D
	v_mov_b32_e32 v62, v0                                      // 00000007A174: 7E7C0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007A178: BF870121
	v_lshrrev_b32_e32 v63, 4, v62                              // 00000007A17C: 327E7C84
	.long 0xd4490001                                           // 00000007A180: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v62, vcc_lo                   // 00000007A184: 02027CFF 0000077F
	v_lshlrev_b32_e32 v70, 2, v63                              // 00000007A18C: 308C7E82
	v_mad_u64_u32 v[63:64], null, 0x44, v63, v[1:2]            // 00000007A190: D6FE7C3F 04067EFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007A19C: 8C040401
	v_add_nc_u32_e32 v65, 0x3200, v70                          // 00000007A1A0: 4A828CFF 00003200
	v_add_nc_u32_e32 v66, 0x3600, v70                          // 00000007A1A8: 4A848CFF 00003600
	v_add_nc_u32_e32 v68, 0x3a00, v70                          // 00000007A1B0: 4A888CFF 00003A00
	v_add_nc_u32_e32 v70, 0x3e00, v70                          // 00000007A1B8: 4A8C8CFF 00003E00
	ds_load_b32 v71, v63                                       // 00000007A1C0: D8D80000 4700003F
	ds_load_2addr_b32 v[66:67], v66 offset0:66 offset1:195     // 00000007A1C8: D8DCC342 42000042
	ds_load_2addr_b32 v[64:65], v65 offset0:64 offset1:193     // 00000007A1D0: D8DCC140 40000041
	ds_load_2addr_b32 v[68:69], v68 offset0:68 offset1:197     // 00000007A1D8: D8DCC544 44000044
	s_waitcnt lgkmcnt(2)                                       // 00000007A1E0: BF89FC27
	v_cvt_f16_f32_e32 v66, v66                                 // 00000007A1E4: 7E841542
	s_waitcnt lgkmcnt(1)                                       // 00000007A1E8: BF89FC17
	v_cvt_f16_f32_e32 v64, v64                                 // 00000007A1EC: 7E801540
	v_cvt_f16_f32_e32 v72, v65                                 // 00000007A1F0: 7E901541
	v_cvt_f16_f32_e32 v67, v67                                 // 00000007A1F4: 7E861543
	s_waitcnt lgkmcnt(0)                                       // 00000007A1F8: BF89FC07
	v_cvt_f16_f32_e32 v68, v68                                 // 00000007A1FC: 7E881544
	v_fma_mix_f32 v71, v64, v42, v71 op_sel_hi:[1,0,0]         // 00000007A200: CC200047 0D1E5540
	ds_load_2addr_b32 v[64:65], v70 offset0:70 offset1:199     // 00000007A208: D8DCC746 40000046
	v_fma_mix_f32 v70, v72, v43, v71 op_sel_hi:[1,0,0]         // 00000007A210: CC200046 0D1E5748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A218: BF870091
	v_fma_mix_f32 v66, v66, v44, v70 op_sel_hi:[1,0,0]         // 00000007A21C: CC200042 0D1A5942
	v_fma_mix_f32 v66, v67, v45, v66 op_sel_hi:[1,0,0]         // 00000007A224: CC200042 0D0A5B43
	v_cvt_f16_f32_e32 v67, v69                                 // 00000007A22C: 7E861545
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000007A230: BF8701C2
	v_fma_mix_f32 v66, v68, v46, v66 op_sel_hi:[1,0,0]         // 00000007A234: CC200042 0D0A5D44
	s_waitcnt lgkmcnt(0)                                       // 00000007A23C: BF89FC07
	v_cvt_f16_f32_e32 v64, v64                                 // 00000007A240: 7E801540
	v_cvt_f16_f32_e32 v65, v65                                 // 00000007A244: 7E821541
	v_fma_mix_f32 v66, v67, v47, v66 op_sel_hi:[1,0,0]         // 00000007A248: CC200042 0D0A5F43
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007A250: BF870121
	v_fma_mix_f32 v64, v64, v60, v66 op_sel_hi:[1,0,0]         // 00000007A254: CC200040 0D0A7940
	v_add_nc_u32_e32 v66, 0x80, v62                            // 00000007A25C: 4A847CFF 00000080
	v_fma_mix_f32 v64, v65, v61, v64 op_sel_hi:[1,0,0]         // 00000007A264: CC200040 0D027B41
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007A26C: BF870002
	v_mov_b32_e32 v62, v66                                     // 00000007A270: 7E7C0342
	ds_store_b32 v63, v64                                      // 00000007A274: D8340000 0000403F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007A27C: 917E047E
	s_cbranch_execnz 65469                                     // 00000007A280: BFA6FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a78>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007A284: 8C7E047E
	v_dual_mov_b32 v43, v35 :: v_dual_mov_b32 v42, v34         // 00000007A288: CA100123 2B2A0122
	v_dual_mov_b32 v44, v51 :: v_dual_mov_b32 v45, 0           // 00000007A290: CA100133 2C2C0080
	v_mov_b32_e32 v46, v49                                     // 00000007A298: 7E5C0331
	s_mov_b32 s6, 0                                            // 00000007A29C: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007A2A0: BF89FC07
	s_barrier                                                  // 00000007A2A4: BFBD0000
	buffer_gl0_inv                                             // 00000007A2A8: E0AC0000 00000000
	s_nop 0                                                    // 00000007A2B0: BF800000
	s_nop 0                                                    // 00000007A2B4: BF800000
	s_nop 0                                                    // 00000007A2B8: BF800000
	s_nop 0                                                    // 00000007A2BC: BF800000
	global_load_b32 v47, v[42:43], off                         // 00000007A2C0: DC520000 2F7C002A
	ds_load_b32 v60, v45 offset:17312                          // 00000007A2C8: D8D843A0 3C00002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 00000007A2D0: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 00000007A2D8: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000007A2DC: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 00000007A2E4: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000007A2E8: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007A2F0: BF870004
	.long 0xd4490004                                           // 00000007A2F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 00000007A2F8: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007A300: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007A304: BF890007
	v_mul_f32_e32 v47, v47, v60                                // 00000007A308: 105E792F
	ds_store_b32 v44, v47 offset:13056                         // 00000007A30C: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000007A314: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007A31C: 917E067E
	s_cbranch_execnz 65511                                     // 00000007A320: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2bc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007A324: 8C7E067E
	v_add_nc_u32_e32 v45, 0x800, v59                           // 00000007A328: 4A5A76FF 00000800
	s_waitcnt lgkmcnt(0)                                       // 00000007A330: BF89FC07
	s_barrier                                                  // 00000007A334: BFBD0000
	buffer_gl0_inv                                             // 00000007A338: E0AC0000 00000000
	s_mov_b32 s4, 0                                            // 00000007A340: BE840080
	ds_load_2addr_b32 v[42:43], v45 offset0:32 offset1:49      // 00000007A344: D8DC3120 2A00002D
	ds_load_2addr_b32 v[46:47], v45 offset0:66 offset1:83      // 00000007A34C: D8DC5342 2E00002D
	ds_load_2addr_b32 v[60:61], v45 offset0:100 offset1:117    // 00000007A354: D8DC7564 3C00002D
	ds_load_2addr_b32 v[62:63], v45 offset0:134 offset1:151    // 00000007A35C: D8DC9786 3E00002D
	s_waitcnt lgkmcnt(3)                                       // 00000007A364: BF89FC37
	v_cvt_f16_f32_e32 v42, v42                                 // 00000007A368: 7E54152A
	v_cvt_f16_f32_e32 v43, v43                                 // 00000007A36C: 7E56152B
	s_waitcnt lgkmcnt(2)                                       // 00000007A370: BF89FC27
	v_cvt_f16_f32_e32 v44, v46                                 // 00000007A374: 7E58152E
	v_cvt_f16_f32_e32 v46, v47                                 // 00000007A378: 7E5C152F
	s_waitcnt lgkmcnt(1)                                       // 00000007A37C: BF89FC17
	v_cvt_f16_f32_e32 v47, v60                                 // 00000007A380: 7E5E153C
	v_cvt_f16_f32_e32 v60, v61                                 // 00000007A384: 7E78153D
	s_waitcnt lgkmcnt(0)                                       // 00000007A388: BF89FC07
	v_cvt_f16_f32_e32 v61, v62                                 // 00000007A38C: 7E7A153E
	v_cvt_f16_f32_e32 v62, v63                                 // 00000007A390: 7E7C153F
	v_cvt_f32_f16_e32 v42, v42                                 // 00000007A394: 7E54172A
	v_cvt_f32_f16_e32 v43, v43                                 // 00000007A398: 7E56172B
	v_cvt_f32_f16_e32 v44, v44                                 // 00000007A39C: 7E58172C
	v_cvt_f32_f16_e32 v46, v46                                 // 00000007A3A0: 7E5C172E
	v_cvt_f32_f16_e32 v47, v47                                 // 00000007A3A4: 7E5E172F
	v_cvt_f32_f16_e32 v60, v60                                 // 00000007A3A8: 7E78173C
	v_cvt_f32_f16_e32 v61, v61                                 // 00000007A3AC: 7E7A173D
	v_cvt_f32_f16_e32 v62, v62                                 // 00000007A3B0: 7E7C173E
	v_mov_b32_e32 v63, v0                                      // 00000007A3B4: 7E7E0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007A3B8: BF870121
	v_lshrrev_b32_e32 v64, 4, v63                              // 00000007A3BC: 32807E84
	.long 0xd4490001                                           // 00000007A3C0: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v63, vcc_lo                   // 00000007A3C4: 02027EFF 0000077F
	v_lshlrev_b32_e32 v71, 2, v64                              // 00000007A3CC: 308E8082
	v_mad_u64_u32 v[64:65], null, 0x44, v64, v[1:2]            // 00000007A3D0: D6FE7C40 040680FF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007A3DC: 8C040401
	v_add_nc_u32_e32 v66, 0x3200, v71                          // 00000007A3E0: 4A848EFF 00003200
	v_add_nc_u32_e32 v67, 0x3600, v71                          // 00000007A3E8: 4A868EFF 00003600
	v_add_nc_u32_e32 v69, 0x3a00, v71                          // 00000007A3F0: 4A8A8EFF 00003A00
	v_add_nc_u32_e32 v71, 0x3e00, v71                          // 00000007A3F8: 4A8E8EFF 00003E00
	ds_load_b32 v72, v64                                       // 00000007A400: D8D80000 48000040
	ds_load_2addr_b32 v[67:68], v67 offset0:66 offset1:195     // 00000007A408: D8DCC342 43000043
	ds_load_2addr_b32 v[65:66], v66 offset0:64 offset1:193     // 00000007A410: D8DCC140 41000042
	ds_load_2addr_b32 v[69:70], v69 offset0:68 offset1:197     // 00000007A418: D8DCC544 45000045
	s_waitcnt lgkmcnt(2)                                       // 00000007A420: BF89FC27
	v_cvt_f16_f32_e32 v67, v67                                 // 00000007A424: 7E861543
	s_waitcnt lgkmcnt(1)                                       // 00000007A428: BF89FC17
	v_cvt_f16_f32_e32 v65, v65                                 // 00000007A42C: 7E821541
	v_cvt_f16_f32_e32 v73, v66                                 // 00000007A430: 7E921542
	v_cvt_f16_f32_e32 v68, v68                                 // 00000007A434: 7E881544
	s_waitcnt lgkmcnt(0)                                       // 00000007A438: BF89FC07
	v_cvt_f16_f32_e32 v69, v69                                 // 00000007A43C: 7E8A1545
	v_fma_mix_f32 v72, v65, v42, v72 op_sel_hi:[1,0,0]         // 00000007A440: CC200048 0D225541
	ds_load_2addr_b32 v[65:66], v71 offset0:70 offset1:199     // 00000007A448: D8DCC746 41000047
	v_fma_mix_f32 v71, v73, v43, v72 op_sel_hi:[1,0,0]         // 00000007A450: CC200047 0D225749
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A458: BF870091
	v_fma_mix_f32 v67, v67, v44, v71 op_sel_hi:[1,0,0]         // 00000007A45C: CC200043 0D1E5943
	v_fma_mix_f32 v67, v68, v46, v67 op_sel_hi:[1,0,0]         // 00000007A464: CC200043 0D0E5D44
	v_cvt_f16_f32_e32 v68, v70                                 // 00000007A46C: 7E881546
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000007A470: BF8701C2
	v_fma_mix_f32 v67, v69, v47, v67 op_sel_hi:[1,0,0]         // 00000007A474: CC200043 0D0E5F45
	s_waitcnt lgkmcnt(0)                                       // 00000007A47C: BF89FC07
	v_cvt_f16_f32_e32 v65, v65                                 // 00000007A480: 7E821541
	v_cvt_f16_f32_e32 v66, v66                                 // 00000007A484: 7E841542
	v_fma_mix_f32 v67, v68, v60, v67 op_sel_hi:[1,0,0]         // 00000007A488: CC200043 0D0E7944
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007A490: BF870121
	v_fma_mix_f32 v65, v65, v61, v67 op_sel_hi:[1,0,0]         // 00000007A494: CC200041 0D0E7B41
	v_add_nc_u32_e32 v67, 0x80, v63                            // 00000007A49C: 4A867EFF 00000080
	v_fma_mix_f32 v65, v66, v62, v65 op_sel_hi:[1,0,0]         // 00000007A4A4: CC200041 0D067D42
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007A4AC: BF870002
	v_mov_b32_e32 v63, v67                                     // 00000007A4B0: 7E7E0343
	ds_store_b32 v64, v65                                      // 00000007A4B4: D8340000 00004140
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007A4BC: 917E047E
	s_cbranch_execnz 65469                                     // 00000007A4C0: BFA6FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2cb8>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007A4C4: 8C7E047E
	v_dual_mov_b32 v43, v37 :: v_dual_mov_b32 v42, v36         // 00000007A4C8: CA100125 2B2A0124
	v_mov_b32_e32 v44, v51                                     // 00000007A4D0: 7E580333
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v47, v49           // 00000007A4D4: CA100080 2E2E0131
	s_mov_b32 s6, 0                                            // 00000007A4DC: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007A4E0: BF89FC07
	s_barrier                                                  // 00000007A4E4: BFBD0000
	buffer_gl0_inv                                             // 00000007A4E8: E0AC0000 00000000
	s_nop 0                                                    // 00000007A4F0: BF800000
	s_nop 0                                                    // 00000007A4F4: BF800000
	s_nop 0                                                    // 00000007A4F8: BF800000
	s_nop 0                                                    // 00000007A4FC: BF800000
	global_load_b32 v60, v[42:43], off                         // 00000007A500: DC520000 3C7C002A
	ds_load_b32 v61, v46 offset:17344                          // 00000007A508: D8D843C0 3D00002E
	v_add_nc_u32_e32 v47, 0x80, v47                            // 00000007A510: 4A5E5EFF 00000080
	.long 0xd700012a                                           // 00000007A518: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000007A51C: 020254FF 00006000
	v_add_nc_u32_e32 v46, 4, v46                               // 00000007A524: 4A5C5C84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000007A528: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007A530: BF870004
	.long 0xd4490004                                           // 00000007A534: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v47, vcc_lo                   // 00000007A538: 02025EFF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007A540: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007A544: BF890007
	v_mul_f32_e32 v60, v60, v61                                // 00000007A548: 10787B3C
	ds_store_b32 v44, v60 offset:13056                         // 00000007A54C: D8343300 00003C2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000007A554: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007A55C: 917E067E
	s_cbranch_execnz 65511                                     // 00000007A560: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e00>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007A564: 8C7E067E
	v_add_nc_u32_e32 v44, 0xc00, v59                           // 00000007A568: 4A5876FF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 00000007A570: BF89FC07
	s_barrier                                                  // 00000007A574: BFBD0000
	buffer_gl0_inv                                             // 00000007A578: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v45 offset0:168 offset1:185    // 00000007A580: D8DCB9A8 2A00002D
	ds_load_2addr_b32 v[46:47], v45 offset0:202 offset1:219    // 00000007A588: D8DCDBCA 2E00002D
	ds_load_2addr_b32 v[60:61], v45 offset0:236 offset1:253    // 00000007A590: D8DCFDEC 3C00002D
	ds_load_2addr_b32 v[62:63], v44 offset0:14 offset1:31      // 00000007A598: D8DC1F0E 3E00002C
	s_mov_b32 s4, 0                                            // 00000007A5A0: BE840080
	s_waitcnt lgkmcnt(3)                                       // 00000007A5A4: BF89FC37
	v_cvt_f16_f32_e32 v42, v42                                 // 00000007A5A8: 7E54152A
	v_cvt_f16_f32_e32 v43, v43                                 // 00000007A5AC: 7E56152B
	s_waitcnt lgkmcnt(2)                                       // 00000007A5B0: BF89FC27
	v_cvt_f16_f32_e32 v45, v46                                 // 00000007A5B4: 7E5A152E
	v_cvt_f16_f32_e32 v46, v47                                 // 00000007A5B8: 7E5C152F
	s_waitcnt lgkmcnt(1)                                       // 00000007A5BC: BF89FC17
	v_cvt_f16_f32_e32 v47, v60                                 // 00000007A5C0: 7E5E153C
	v_cvt_f16_f32_e32 v60, v61                                 // 00000007A5C4: 7E78153D
	s_waitcnt lgkmcnt(0)                                       // 00000007A5C8: BF89FC07
	v_cvt_f16_f32_e32 v61, v62                                 // 00000007A5CC: 7E7A153E
	v_cvt_f16_f32_e32 v62, v63                                 // 00000007A5D0: 7E7C153F
	v_cvt_f32_f16_e32 v42, v42                                 // 00000007A5D4: 7E54172A
	v_cvt_f32_f16_e32 v43, v43                                 // 00000007A5D8: 7E56172B
	v_cvt_f32_f16_e32 v45, v45                                 // 00000007A5DC: 7E5A172D
	v_cvt_f32_f16_e32 v46, v46                                 // 00000007A5E0: 7E5C172E
	v_cvt_f32_f16_e32 v47, v47                                 // 00000007A5E4: 7E5E172F
	v_cvt_f32_f16_e32 v60, v60                                 // 00000007A5E8: 7E78173C
	v_cvt_f32_f16_e32 v61, v61                                 // 00000007A5EC: 7E7A173D
	v_cvt_f32_f16_e32 v62, v62                                 // 00000007A5F0: 7E7C173E
	v_mov_b32_e32 v63, v0                                      // 00000007A5F4: 7E7E0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007A5F8: BF870121
	v_lshrrev_b32_e32 v64, 4, v63                              // 00000007A5FC: 32807E84
	.long 0xd4490001                                           // 00000007A600: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v63, vcc_lo                   // 00000007A604: 02027EFF 0000077F
	v_lshlrev_b32_e32 v71, 2, v64                              // 00000007A60C: 308E8082
	v_mad_u64_u32 v[64:65], null, 0x44, v64, v[1:2]            // 00000007A610: D6FE7C40 040680FF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007A61C: 8C040401
	v_add_nc_u32_e32 v66, 0x3200, v71                          // 00000007A620: 4A848EFF 00003200
	v_add_nc_u32_e32 v67, 0x3600, v71                          // 00000007A628: 4A868EFF 00003600
	v_add_nc_u32_e32 v69, 0x3a00, v71                          // 00000007A630: 4A8A8EFF 00003A00
	v_add_nc_u32_e32 v71, 0x3e00, v71                          // 00000007A638: 4A8E8EFF 00003E00
	ds_load_b32 v72, v64                                       // 00000007A640: D8D80000 48000040
	ds_load_2addr_b32 v[67:68], v67 offset0:66 offset1:195     // 00000007A648: D8DCC342 43000043
	ds_load_2addr_b32 v[65:66], v66 offset0:64 offset1:193     // 00000007A650: D8DCC140 41000042
	ds_load_2addr_b32 v[69:70], v69 offset0:68 offset1:197     // 00000007A658: D8DCC544 45000045
	s_waitcnt lgkmcnt(2)                                       // 00000007A660: BF89FC27
	v_cvt_f16_f32_e32 v67, v67                                 // 00000007A664: 7E861543
	s_waitcnt lgkmcnt(1)                                       // 00000007A668: BF89FC17
	v_cvt_f16_f32_e32 v65, v65                                 // 00000007A66C: 7E821541
	v_cvt_f16_f32_e32 v73, v66                                 // 00000007A670: 7E921542
	v_cvt_f16_f32_e32 v68, v68                                 // 00000007A674: 7E881544
	s_waitcnt lgkmcnt(0)                                       // 00000007A678: BF89FC07
	v_cvt_f16_f32_e32 v69, v69                                 // 00000007A67C: 7E8A1545
	v_fma_mix_f32 v72, v65, v42, v72 op_sel_hi:[1,0,0]         // 00000007A680: CC200048 0D225541
	ds_load_2addr_b32 v[65:66], v71 offset0:70 offset1:199     // 00000007A688: D8DCC746 41000047
	v_fma_mix_f32 v71, v73, v43, v72 op_sel_hi:[1,0,0]         // 00000007A690: CC200047 0D225749
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A698: BF870091
	v_fma_mix_f32 v67, v67, v45, v71 op_sel_hi:[1,0,0]         // 00000007A69C: CC200043 0D1E5B43
	v_fma_mix_f32 v67, v68, v46, v67 op_sel_hi:[1,0,0]         // 00000007A6A4: CC200043 0D0E5D44
	v_cvt_f16_f32_e32 v68, v70                                 // 00000007A6AC: 7E881546
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000007A6B0: BF8701C2
	v_fma_mix_f32 v67, v69, v47, v67 op_sel_hi:[1,0,0]         // 00000007A6B4: CC200043 0D0E5F45
	s_waitcnt lgkmcnt(0)                                       // 00000007A6BC: BF89FC07
	v_cvt_f16_f32_e32 v65, v65                                 // 00000007A6C0: 7E821541
	v_cvt_f16_f32_e32 v66, v66                                 // 00000007A6C4: 7E841542
	v_fma_mix_f32 v67, v68, v60, v67 op_sel_hi:[1,0,0]         // 00000007A6C8: CC200043 0D0E7944
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007A6D0: BF870121
	v_fma_mix_f32 v65, v65, v61, v67 op_sel_hi:[1,0,0]         // 00000007A6D4: CC200041 0D0E7B41
	v_add_nc_u32_e32 v67, 0x80, v63                            // 00000007A6DC: 4A867EFF 00000080
	v_fma_mix_f32 v65, v66, v62, v65 op_sel_hi:[1,0,0]         // 00000007A6E4: CC200041 0D067D42
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007A6EC: BF870002
	v_mov_b32_e32 v63, v67                                     // 00000007A6F0: 7E7E0343
	ds_store_b32 v64, v65                                      // 00000007A6F4: D8340000 00004140
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007A6FC: 917E047E
	s_cbranch_execnz 65469                                     // 00000007A700: BFA6FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ef8>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007A704: 8C7E047E
	v_dual_mov_b32 v43, v39 :: v_dual_mov_b32 v42, v38         // 00000007A708: CA100127 2B2A0126
	v_dual_mov_b32 v45, v51 :: v_dual_mov_b32 v46, 0           // 00000007A710: CA100133 2D2E0080
	v_mov_b32_e32 v47, v49                                     // 00000007A718: 7E5E0331
	s_mov_b32 s6, 0                                            // 00000007A71C: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007A720: BF89FC07
	s_barrier                                                  // 00000007A724: BFBD0000
	buffer_gl0_inv                                             // 00000007A728: E0AC0000 00000000
	s_nop 0                                                    // 00000007A730: BF800000
	s_nop 0                                                    // 00000007A734: BF800000
	s_nop 0                                                    // 00000007A738: BF800000
	s_nop 0                                                    // 00000007A73C: BF800000
	global_load_b32 v60, v[42:43], off                         // 00000007A740: DC520000 3C7C002A
	ds_load_b32 v61, v46 offset:17376                          // 00000007A748: D8D843E0 3D00002E
	v_add_nc_u32_e32 v47, 0x80, v47                            // 00000007A750: 4A5E5EFF 00000080
	.long 0xd700012a                                           // 00000007A758: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000007A75C: 020254FF 00006000
	v_add_nc_u32_e32 v46, 4, v46                               // 00000007A764: 4A5C5C84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000007A768: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007A770: BF870004
	.long 0xd4490004                                           // 00000007A774: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v47, vcc_lo                   // 00000007A778: 02025EFF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007A780: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007A784: BF890007
	v_mul_f32_e32 v60, v60, v61                                // 00000007A788: 10787B3C
	ds_store_b32 v45, v60 offset:13056                         // 00000007A78C: D8343300 00003C2D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 00000007A794: 4A5A5AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007A79C: 917E067E
	s_cbranch_execnz 65511                                     // 00000007A7A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3040>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007A7A4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000007A7A8: BF89FC07
	s_barrier                                                  // 00000007A7AC: BFBD0000
	buffer_gl0_inv                                             // 00000007A7B0: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v44 offset0:48 offset1:65      // 00000007A7B8: D8DC4130 2A00002C
	ds_load_2addr_b32 v[45:46], v44 offset0:82 offset1:99      // 00000007A7C0: D8DC6352 2D00002C
	ds_load_2addr_b32 v[60:61], v44 offset0:116 offset1:133    // 00000007A7C8: D8DC8574 3C00002C
	ds_load_2addr_b32 v[62:63], v44 offset0:150 offset1:167    // 00000007A7D0: D8DCA796 3E00002C
	s_mov_b32 s4, 0                                            // 00000007A7D8: BE840080
	s_waitcnt lgkmcnt(3)                                       // 00000007A7DC: BF89FC37
	v_cvt_f16_f32_e32 v42, v42                                 // 00000007A7E0: 7E54152A
	v_cvt_f16_f32_e32 v43, v43                                 // 00000007A7E4: 7E56152B
	s_waitcnt lgkmcnt(2)                                       // 00000007A7E8: BF89FC27
	v_cvt_f16_f32_e32 v45, v45                                 // 00000007A7EC: 7E5A152D
	v_cvt_f16_f32_e32 v46, v46                                 // 00000007A7F0: 7E5C152E
	s_waitcnt lgkmcnt(1)                                       // 00000007A7F4: BF89FC17
	v_cvt_f16_f32_e32 v47, v60                                 // 00000007A7F8: 7E5E153C
	v_cvt_f16_f32_e32 v60, v61                                 // 00000007A7FC: 7E78153D
	s_waitcnt lgkmcnt(0)                                       // 00000007A800: BF89FC07
	v_cvt_f16_f32_e32 v61, v62                                 // 00000007A804: 7E7A153E
	v_cvt_f16_f32_e32 v62, v63                                 // 00000007A808: 7E7C153F
	v_cvt_f32_f16_e32 v42, v42                                 // 00000007A80C: 7E54172A
	v_cvt_f32_f16_e32 v43, v43                                 // 00000007A810: 7E56172B
	v_cvt_f32_f16_e32 v45, v45                                 // 00000007A814: 7E5A172D
	v_cvt_f32_f16_e32 v46, v46                                 // 00000007A818: 7E5C172E
	v_cvt_f32_f16_e32 v47, v47                                 // 00000007A81C: 7E5E172F
	v_cvt_f32_f16_e32 v60, v60                                 // 00000007A820: 7E78173C
	v_cvt_f32_f16_e32 v61, v61                                 // 00000007A824: 7E7A173D
	v_cvt_f32_f16_e32 v62, v62                                 // 00000007A828: 7E7C173E
	v_mov_b32_e32 v63, v0                                      // 00000007A82C: 7E7E0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007A830: BF870121
	v_lshrrev_b32_e32 v64, 4, v63                              // 00000007A834: 32807E84
	.long 0xd4490001                                           // 00000007A838: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v63, vcc_lo                   // 00000007A83C: 02027EFF 0000077F
	v_lshlrev_b32_e32 v71, 2, v64                              // 00000007A844: 308E8082
	v_mad_u64_u32 v[64:65], null, 0x44, v64, v[1:2]            // 00000007A848: D6FE7C40 040680FF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007A854: 8C040401
	v_add_nc_u32_e32 v66, 0x3200, v71                          // 00000007A858: 4A848EFF 00003200
	v_add_nc_u32_e32 v67, 0x3600, v71                          // 00000007A860: 4A868EFF 00003600
	v_add_nc_u32_e32 v69, 0x3a00, v71                          // 00000007A868: 4A8A8EFF 00003A00
	v_add_nc_u32_e32 v71, 0x3e00, v71                          // 00000007A870: 4A8E8EFF 00003E00
	ds_load_b32 v72, v64                                       // 00000007A878: D8D80000 48000040
	ds_load_2addr_b32 v[67:68], v67 offset0:66 offset1:195     // 00000007A880: D8DCC342 43000043
	ds_load_2addr_b32 v[65:66], v66 offset0:64 offset1:193     // 00000007A888: D8DCC140 41000042
	ds_load_2addr_b32 v[69:70], v69 offset0:68 offset1:197     // 00000007A890: D8DCC544 45000045
	s_waitcnt lgkmcnt(2)                                       // 00000007A898: BF89FC27
	v_cvt_f16_f32_e32 v67, v67                                 // 00000007A89C: 7E861543
	s_waitcnt lgkmcnt(1)                                       // 00000007A8A0: BF89FC17
	v_cvt_f16_f32_e32 v65, v65                                 // 00000007A8A4: 7E821541
	v_cvt_f16_f32_e32 v73, v66                                 // 00000007A8A8: 7E921542
	v_cvt_f16_f32_e32 v68, v68                                 // 00000007A8AC: 7E881544
	s_waitcnt lgkmcnt(0)                                       // 00000007A8B0: BF89FC07
	v_cvt_f16_f32_e32 v69, v69                                 // 00000007A8B4: 7E8A1545
	v_fma_mix_f32 v72, v65, v42, v72 op_sel_hi:[1,0,0]         // 00000007A8B8: CC200048 0D225541
	ds_load_2addr_b32 v[65:66], v71 offset0:70 offset1:199     // 00000007A8C0: D8DCC746 41000047
	v_fma_mix_f32 v71, v73, v43, v72 op_sel_hi:[1,0,0]         // 00000007A8C8: CC200047 0D225749
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A8D0: BF870091
	v_fma_mix_f32 v67, v67, v45, v71 op_sel_hi:[1,0,0]         // 00000007A8D4: CC200043 0D1E5B43
	v_fma_mix_f32 v67, v68, v46, v67 op_sel_hi:[1,0,0]         // 00000007A8DC: CC200043 0D0E5D44
	v_cvt_f16_f32_e32 v68, v70                                 // 00000007A8E4: 7E881546
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000007A8E8: BF8701C2
	v_fma_mix_f32 v67, v69, v47, v67 op_sel_hi:[1,0,0]         // 00000007A8EC: CC200043 0D0E5F45
	s_waitcnt lgkmcnt(0)                                       // 00000007A8F4: BF89FC07
	v_cvt_f16_f32_e32 v65, v65                                 // 00000007A8F8: 7E821541
	v_cvt_f16_f32_e32 v66, v66                                 // 00000007A8FC: 7E841542
	v_fma_mix_f32 v67, v68, v60, v67 op_sel_hi:[1,0,0]         // 00000007A900: CC200043 0D0E7944
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007A908: BF870121
	v_fma_mix_f32 v65, v65, v61, v67 op_sel_hi:[1,0,0]         // 00000007A90C: CC200041 0D0E7B41
	v_add_nc_u32_e32 v67, 0x80, v63                            // 00000007A914: 4A867EFF 00000080
	v_fma_mix_f32 v65, v66, v62, v65 op_sel_hi:[1,0,0]         // 00000007A91C: CC200041 0D067D42
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007A924: BF870002
	v_mov_b32_e32 v63, v67                                     // 00000007A928: 7E7E0343
	ds_store_b32 v64, v65                                      // 00000007A92C: D8340000 00004140
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007A934: 917E047E
	s_cbranch_execnz 65469                                     // 00000007A938: BFA6FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3130>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007A93C: 8C7E047E
	v_dual_mov_b32 v43, v41 :: v_dual_mov_b32 v42, v40         // 00000007A940: CA100129 2B2A0128
	v_dual_mov_b32 v45, v51 :: v_dual_mov_b32 v46, 0           // 00000007A948: CA100133 2D2E0080
	v_mov_b32_e32 v47, v49                                     // 00000007A950: 7E5E0331
	s_mov_b32 s6, 0                                            // 00000007A954: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007A958: BF89FC07
	s_barrier                                                  // 00000007A95C: BFBD0000
	buffer_gl0_inv                                             // 00000007A960: E0AC0000 00000000
	s_nop 0                                                    // 00000007A968: BF800000
	s_nop 0                                                    // 00000007A96C: BF800000
	s_nop 0                                                    // 00000007A970: BF800000
	s_nop 0                                                    // 00000007A974: BF800000
	s_nop 0                                                    // 00000007A978: BF800000
	s_nop 0                                                    // 00000007A97C: BF800000
	global_load_b32 v60, v[42:43], off                         // 00000007A980: DC520000 3C7C002A
	ds_load_b32 v61, v46 offset:17408                          // 00000007A988: D8D84400 3D00002E
	v_add_nc_u32_e32 v47, 0x80, v47                            // 00000007A990: 4A5E5EFF 00000080
	.long 0xd700012a                                           // 00000007A998: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000007A99C: 020254FF 00006000
	v_add_nc_u32_e32 v46, 4, v46                               // 00000007A9A4: 4A5C5C84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000007A9A8: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007A9B0: BF870004
	.long 0xd4490004                                           // 00000007A9B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v47, vcc_lo                   // 00000007A9B8: 02025EFF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007A9C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007A9C4: BF890007
	v_mul_f32_e32 v60, v60, v61                                // 00000007A9C8: 10787B3C
	ds_store_b32 v45, v60 offset:13056                         // 00000007A9CC: D8343300 00003C2D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 00000007A9D4: 4A5A5AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007A9DC: 917E067E
	s_cbranch_execnz 65511                                     // 00000007A9E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3280>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007A9E4: 8C7E067E
	v_add_nc_u32_e32 v46, 0xe00, v59                           // 00000007A9E8: 4A5C76FF 00000E00
	v_add_nc_u32_e32 v60, 0x1000, v59                          // 00000007A9F0: 4A7876FF 00001000
	s_waitcnt lgkmcnt(0)                                       // 00000007A9F8: BF89FC07
	s_barrier                                                  // 00000007A9FC: BFBD0000
	buffer_gl0_inv                                             // 00000007AA00: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v44 offset0:184 offset1:201    // 00000007AA08: D8DCC9B8 2A00002C
	ds_load_2addr_b32 v[44:45], v44 offset0:218 offset1:235    // 00000007AA10: D8DCEBDA 2C00002C
	ds_load_2addr_b32 v[46:47], v46 offset0:124 offset1:141    // 00000007AA18: D8DC8D7C 2E00002E
	ds_load_2addr_b32 v[60:61], v60 offset0:30 offset1:47      // 00000007AA20: D8DC2F1E 3C00003C
	v_mov_b32_e32 v62, v0                                      // 00000007AA28: 7E7C0300
	s_mov_b32 s4, 0                                            // 00000007AA2C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 00000007AA30: BF89FC37
	v_cvt_f16_f32_e32 v42, v42                                 // 00000007AA34: 7E54152A
	v_cvt_f16_f32_e32 v43, v43                                 // 00000007AA38: 7E56152B
	s_waitcnt lgkmcnt(2)                                       // 00000007AA3C: BF89FC27
	v_cvt_f16_f32_e32 v44, v44                                 // 00000007AA40: 7E58152C
	v_cvt_f16_f32_e32 v45, v45                                 // 00000007AA44: 7E5A152D
	s_waitcnt lgkmcnt(1)                                       // 00000007AA48: BF89FC17
	v_cvt_f16_f32_e32 v46, v46                                 // 00000007AA4C: 7E5C152E
	v_cvt_f16_f32_e32 v47, v47                                 // 00000007AA50: 7E5E152F
	s_waitcnt lgkmcnt(0)                                       // 00000007AA54: BF89FC07
	v_cvt_f16_f32_e32 v60, v60                                 // 00000007AA58: 7E78153C
	v_cvt_f16_f32_e32 v61, v61                                 // 00000007AA5C: 7E7A153D
	v_cvt_f32_f16_e32 v42, v42                                 // 00000007AA60: 7E54172A
	v_cvt_f32_f16_e32 v43, v43                                 // 00000007AA64: 7E56172B
	v_cvt_f32_f16_e32 v44, v44                                 // 00000007AA68: 7E58172C
	v_cvt_f32_f16_e32 v45, v45                                 // 00000007AA6C: 7E5A172D
	v_cvt_f32_f16_e32 v46, v46                                 // 00000007AA70: 7E5C172E
	v_cvt_f32_f16_e32 v47, v47                                 // 00000007AA74: 7E5E172F
	v_cvt_f32_f16_e32 v60, v60                                 // 00000007AA78: 7E78173C
	v_cvt_f32_f16_e32 v61, v61                                 // 00000007AA7C: 7E7A173D
	v_lshrrev_b32_e32 v63, 4, v62                              // 00000007AA80: 327E7C84
	.long 0xd4490001                                           // 00000007AA84: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v62, vcc_lo                   // 00000007AA88: 02027CFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007AA90: BF870002
	v_lshlrev_b32_e32 v70, 2, v63                              // 00000007AA94: 308C7E82
	v_mad_u64_u32 v[63:64], null, 0x44, v63, v[1:2]            // 00000007AA98: D6FE7C3F 04067EFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007AAA4: 8C040401
	v_add_nc_u32_e32 v65, 0x3200, v70                          // 00000007AAA8: 4A828CFF 00003200
	v_add_nc_u32_e32 v66, 0x3600, v70                          // 00000007AAB0: 4A848CFF 00003600
	v_add_nc_u32_e32 v68, 0x3a00, v70                          // 00000007AAB8: 4A888CFF 00003A00
	v_add_nc_u32_e32 v70, 0x3e00, v70                          // 00000007AAC0: 4A8C8CFF 00003E00
	ds_load_b32 v71, v63                                       // 00000007AAC8: D8D80000 4700003F
	ds_load_2addr_b32 v[66:67], v66 offset0:66 offset1:195     // 00000007AAD0: D8DCC342 42000042
	ds_load_2addr_b32 v[64:65], v65 offset0:64 offset1:193     // 00000007AAD8: D8DCC140 40000041
	ds_load_2addr_b32 v[68:69], v68 offset0:68 offset1:197     // 00000007AAE0: D8DCC544 44000044
	s_waitcnt lgkmcnt(2)                                       // 00000007AAE8: BF89FC27
	v_cvt_f16_f32_e32 v66, v66                                 // 00000007AAEC: 7E841542
	s_waitcnt lgkmcnt(1)                                       // 00000007AAF0: BF89FC17
	v_cvt_f16_f32_e32 v64, v64                                 // 00000007AAF4: 7E801540
	v_cvt_f16_f32_e32 v72, v65                                 // 00000007AAF8: 7E901541
	v_cvt_f16_f32_e32 v67, v67                                 // 00000007AAFC: 7E861543
	s_waitcnt lgkmcnt(0)                                       // 00000007AB00: BF89FC07
	v_cvt_f16_f32_e32 v68, v68                                 // 00000007AB04: 7E881544
	v_fma_mix_f32 v71, v64, v42, v71 op_sel_hi:[1,0,0]         // 00000007AB08: CC200047 0D1E5540
	ds_load_2addr_b32 v[64:65], v70 offset0:70 offset1:199     // 00000007AB10: D8DCC746 40000046
	v_fma_mix_f32 v70, v72, v43, v71 op_sel_hi:[1,0,0]         // 00000007AB18: CC200046 0D1E5748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007AB20: BF870091
	v_fma_mix_f32 v66, v66, v44, v70 op_sel_hi:[1,0,0]         // 00000007AB24: CC200042 0D1A5942
	v_fma_mix_f32 v66, v67, v45, v66 op_sel_hi:[1,0,0]         // 00000007AB2C: CC200042 0D0A5B43
	v_cvt_f16_f32_e32 v67, v69                                 // 00000007AB34: 7E861545
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000007AB38: BF8701C2
	v_fma_mix_f32 v66, v68, v46, v66 op_sel_hi:[1,0,0]         // 00000007AB3C: CC200042 0D0A5D44
	s_waitcnt lgkmcnt(0)                                       // 00000007AB44: BF89FC07
	v_cvt_f16_f32_e32 v64, v64                                 // 00000007AB48: 7E801540
	v_cvt_f16_f32_e32 v65, v65                                 // 00000007AB4C: 7E821541
	v_fma_mix_f32 v66, v67, v47, v66 op_sel_hi:[1,0,0]         // 00000007AB50: CC200042 0D0A5F43
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007AB58: BF870121
	v_fma_mix_f32 v64, v64, v60, v66 op_sel_hi:[1,0,0]         // 00000007AB5C: CC200040 0D0A7940
	v_add_nc_u32_e32 v66, 0x80, v62                            // 00000007AB64: 4A847CFF 00000080
	v_fma_mix_f32 v64, v65, v61, v64 op_sel_hi:[1,0,0]         // 00000007AB6C: CC200040 0D027B41
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007AB74: BF870002
	v_mov_b32_e32 v62, v66                                     // 00000007AB78: 7E7C0342
	ds_store_b32 v63, v64                                      // 00000007AB7C: D8340000 0000403F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007AB84: 917E047E
	s_cbranch_execnz 65469                                     // 00000007AB88: BFA6FFBD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3380>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007AB8C: 8C7E047E
	.long 0xd7000106                                           // 00000007AB90: D7000106
	v_cndmask_b32_e32 v1, 0x180000, v6, vcc_lo                 // 00000007AB94: 02020CFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007AB9C: BF8700A1
	v_add_co_ci_u32_e64 v7, null, 0, v7, s1                    // 00000007ABA0: D5207C07 00060E80
	.long 0xd7000108                                           // 00000007ABA8: D7000108
	v_cndmask_b32_e32 v1, 0x180000, v8, vcc_lo                 // 00000007ABAC: 020210FF 00180000
	v_add_co_ci_u32_e64 v9, null, 0, v9, s1                    // 00000007ABB4: D5207C09 00061280
	.long 0xd700010a                                           // 00000007ABBC: D700010A
	v_cndmask_b32_e32 v1, 0x180000, v10, vcc_lo                // 00000007ABC0: 020214FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007ABC8: BF8700A1
	v_add_co_ci_u32_e64 v11, null, 0, v11, s1                  // 00000007ABCC: D5207C0B 00061680
	.long 0xd700010c                                           // 00000007ABD4: D700010C
	v_cndmask_b32_e32 v1, 0x180000, v12, vcc_lo                // 00000007ABD8: 020218FF 00180000
	v_add_co_ci_u32_e64 v13, null, 0, v13, s1                  // 00000007ABE0: D5207C0D 00061A80
	.long 0xd700010e                                           // 00000007ABE8: D700010E
	v_cndmask_b32_e32 v1, 0x180000, v14, vcc_lo                // 00000007ABEC: 02021CFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007ABF4: BF8700A1
	v_add_co_ci_u32_e64 v15, null, 0, v15, s1                  // 00000007ABF8: D5207C0F 00061E80
	.long 0xd7000110                                           // 00000007AC00: D7000110
	v_cndmask_b32_e32 v1, 0x180000, v16, vcc_lo                // 00000007AC04: 020220FF 00180000
	v_add_co_ci_u32_e64 v17, null, 0, v17, s1                  // 00000007AC0C: D5207C11 00062280
	.long 0xd7000112                                           // 00000007AC14: D7000112
	v_cndmask_b32_e32 v1, 0x180000, v18, vcc_lo                // 00000007AC18: 020224FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007AC20: BF8700A1
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 00000007AC24: D5207C13 00062680
	.long 0xd7000114                                           // 00000007AC2C: D7000114
	v_cndmask_b32_e32 v1, 0x180000, v20, vcc_lo                // 00000007AC30: 020228FF 00180000
	v_add_co_ci_u32_e64 v21, null, 0, v21, s1                  // 00000007AC38: D5207C15 00062A80
	.long 0xd7000116                                           // 00000007AC40: D7000116
	v_cndmask_b32_e32 v1, 0x180000, v22, vcc_lo                // 00000007AC44: 02022CFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007AC4C: BF8700A1
	v_add_co_ci_u32_e64 v23, null, 0, v23, s1                  // 00000007AC50: D5207C17 00062E80
	.long 0xd7000118                                           // 00000007AC58: D7000118
	v_cndmask_b32_e32 v1, 0xc0000, v24, vcc_lo                 // 00000007AC5C: 020230FF 000C0000
	v_add_co_ci_u32_e64 v25, null, 0, v25, s1                  // 00000007AC64: D5207C19 00063280
	.long 0xd700011a                                           // 00000007AC6C: D700011A
	v_cndmask_b32_e32 v1, 0x180000, v26, vcc_lo                // 00000007AC70: 020234FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007AC78: BF8700A1
	v_add_co_ci_u32_e64 v27, null, 0, v27, s1                  // 00000007AC7C: D5207C1B 00063680
	.long 0xd700011c                                           // 00000007AC84: D700011C
	v_cndmask_b32_e32 v1, 0x180000, v28, vcc_lo                // 00000007AC88: 020238FF 00180000
	v_add_co_ci_u32_e64 v29, null, 0, v29, s1                  // 00000007AC90: D5207C1D 00063A80
	.long 0xd700011e                                           // 00000007AC98: D700011E
	v_cndmask_b32_e32 v1, 0x180000, v30, vcc_lo                // 00000007AC9C: 02023CFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007ACA4: BF8700A1
	v_add_co_ci_u32_e64 v31, null, 0, v31, s1                  // 00000007ACA8: D5207C1F 00063E80
	.long 0xd7000120                                           // 00000007ACB0: D7000120
	v_cndmask_b32_e32 v1, 0x180000, v32, vcc_lo                // 00000007ACB4: 020240FF 00180000
	v_add_co_ci_u32_e64 v33, null, 0, v33, s1                  // 00000007ACBC: D5207C21 00064280
	.long 0xd7000122                                           // 00000007ACC4: D7000122
	v_cndmask_b32_e32 v1, 0x180000, v34, vcc_lo                // 00000007ACC8: 020244FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007ACD0: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v35, s1                  // 00000007ACD4: D5207C23 00064680
	.long 0xd7000124                                           // 00000007ACDC: D7000124
	v_cndmask_b32_e32 v1, 0x180000, v36, vcc_lo                // 00000007ACE0: 020248FF 00180000
	v_add_co_ci_u32_e64 v37, null, 0, v37, s1                  // 00000007ACE8: D5207C25 00064A80
	.long 0xd7000126                                           // 00000007ACF0: D7000126
	v_cndmask_b32_e32 v1, 0x180000, v38, vcc_lo                // 00000007ACF4: 02024CFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007ACFC: BF8700A1
	v_add_co_ci_u32_e64 v39, null, 0, v39, s1                  // 00000007AD00: D5207C27 00064E80
	.long 0xd7000128                                           // 00000007AD08: D7000128
	v_cndmask_b32_e32 v1, 0x180000, v40, vcc_lo                // 00000007AD0C: 020250FF 00180000
	v_add_co_ci_u32_e64 v41, null, 0, v41, s1                  // 00000007AD14: D5207C29 00065280
	s_add_i32 s5, s5, 1                                        // 00000007AD1C: 81058105
	s_waitcnt lgkmcnt(0)                                       // 00000007AD20: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 00000007AD24: BF062105
	s_barrier                                                  // 00000007AD28: BFBD0000
	buffer_gl0_inv                                             // 00000007AD2C: E0AC0000 00000000
	s_cbranch_scc0 62342                                       // 00000007AD34: BFA1F386 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x450>
	v_mov_b32_e32 v5, v49                                      // 00000007AD38: 7E0A0331
	s_add_u32 s0, s28, s20                                     // 00000007AD3C: 8000141C
	.long 0xd73c0000                                           // 00000007AD40: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000007AD44: 02020489
	s_addc_u32 s1, s29, s21                                    // 00000007AD48: 8201151D
	s_add_u32 s2, s24, s18                                     // 00000007AD4C: 80021218
	s_addc_u32 s3, s25, s19                                    // 00000007AD50: 82031319
	s_add_u32 s0, s2, s0                                       // 00000007AD54: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000007AD58: 82010103
	.long 0xd7006a00                                           // 00000007AD5C: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000007AD60: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000007AD64: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000007AD68: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 00000007AD70: BE810080
	.long 0xd7006a00                                           // 00000007AD74: D7006A00
	v_cndmask_b32_e32 v1, v0, v50, vcc_lo                      // 00000007AD78: 02026500
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000007AD7C: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007AD84: BF870092
	.long 0xd7006a00                                           // 00000007AD88: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000007AD8C: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000007AD90: D5207C01 01AA0211
	s_nop 0                                                    // 00000007AD98: BF800000
	s_nop 0                                                    // 00000007AD9C: BF800000
	s_nop 0                                                    // 00000007ADA0: BF800000
	s_nop 0                                                    // 00000007ADA4: BF800000
	s_nop 0                                                    // 00000007ADA8: BF800000
	s_nop 0                                                    // 00000007ADAC: BF800000
	s_nop 0                                                    // 00000007ADB0: BF800000
	s_nop 0                                                    // 00000007ADB4: BF800000
	s_nop 0                                                    // 00000007ADB8: BF800000
	s_nop 0                                                    // 00000007ADBC: BF800000
	ds_load_b32 v2, v48                                        // 00000007ADC0: D8D80000 02000030
	v_add_nc_u32_e32 v5, 0x80, v5                              // 00000007ADC8: 4A0A0AFF 00000080
	v_add_nc_u32_e32 v48, 0x220, v48                           // 00000007ADD0: 4A6060FF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000007ADD8: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v5                         // 00000007ADDC: 7C920AFF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 00000007ADE4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000007ADE8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 00000007ADEC: DC6A0000 007C0200
	.long 0xd7000000                                           // 00000007ADF4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 00000007ADF8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000007AE00: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000007AE08: 917E017E
	s_cbranch_execnz 65516                                     // 00000007AE0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x36c0>
	s_endpgm                                                   // 00000007AE10: BFB00000
		...

