0000000000025a00 <_ZN7halogen12_GLOBAL__N_17k_kv_btEPKtS2_liPtS3_>:
; _ZN7halogen12_GLOBAL__N_17k_kv_btEPKtS2_liPtS3_():
	s_clause 0x2                                               // 000000025A00: BF850002
	s_load_b32 s16, s[0:1], 0x18                               // 000000025A04: F4000400 F8000018
	s_load_b128 s[8:11], s[0:1], null                          // 000000025A0C: F4080200 F8000000
	s_load_b64 s[12:13], s[0:1], 0x10                          // 000000025A14: F4040300 F8000010
	v_lshrrev_b32_e32 v2, 6, v0                                // 000000025A1C: 32040086
	s_lshl_b32 s17, s2, 2                                      // 000000025A20: 84118202
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000025A24: 30020082
	s_mov_b32 s14, s3                                          // 000000025A28: BE8E0003
	s_ashr_i32 s15, s3, 31                                     // 000000025A2C: 860F9F03
	v_add_nc_u32_e32 v8, s17, v2                               // 000000025A30: 4A100411
	s_mov_b32 s3, exec_lo                                      // 000000025A34: BE83007E
	s_waitcnt lgkmcnt(0)                                       // 000000025A38: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000025A3C: BF870001
	.long 0xd4c3007e                                           // 000000025A40: D4C3007E
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 000000025A44: 02021010
	s_xor_b32 s3, exec_lo, s3                                  // 000000025A48: 8D03037E
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000025A4C: 30020082
	s_lshl_b32 s4, s14, 8                                      // 000000025A50: 8404880E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000025A54: BF870009
	s_ashr_i32 s5, s4, 31                                      // 000000025A58: 86059F04
	s_or_saveexec_b32 s3, s3                                   // 000000025A5C: BE832203
	v_dual_mov_b32 v7, s5 :: v_dual_mov_b32 v4, 0              // 000000025A60: CA100005 07040080
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v6, s4              // 000000025A68: CA100080 03060004
	v_mov_b32_e32 v5, 0                                        // 000000025A70: 7E0A0280
	s_xor_b32 exec_lo, exec_lo, s3                             // 000000025A74: 8D7E037E
	s_cbranch_execz 38                                         // 000000025A78: BFA50026 <_ZN7halogen12_GLOBAL__N_17k_kv_btEPKtS2_liPtS3_+0x114>
	v_ashrrev_i32_e32 v6, 31, v8                               // 000000025A7C: 340C109F
	.long 0xd72c0007                                           // 000000025A80: D72C0007
	v_cndmask_b32_e32 v1, s13, v8, vcc_lo                      // 000000025A84: 0202100D
	v_mad_u64_u32 v[4:5], null, s12, v8, 0                     // 000000025A88: D6FE7C04 0202100C
	s_lshl_b32 s4, s14, 8                                      // 000000025A90: 8404880E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000025A94: BF8700B9
	s_ashr_i32 s5, s4, 31                                      // 000000025A98: 86059F04
	.long 0xd72c0006                                           // 000000025A9C: D72C0006
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 000000025AA0: 02020C0C
	s_lshl_b64 s[6:7], s[4:5], 1                               // 000000025AA4: 84868104
	v_add3_u32 v5, v5, v6, v7                                  // 000000025AA8: D6550005 041E0D05
	v_lshlrev_b32_e32 v6, 3, v0                                // 000000025AB0: 300C0083
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000025AB4: BF870112
	.long 0xd73c0004                                           // 000000025AB8: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000025ABC: 02020881
	v_and_b32_e32 v6, 0x1f8, v6                                // 000000025AC0: 360C0CFF 000001F8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025AC8: BF870092
	.long 0xd7006a04                                           // 000000025ACC: D7006A04
	v_cndmask_b32_e32 v1, s8, v4, vcc_lo                       // 000000025AD0: 02020808
	v_add_co_ci_u32_e64 v5, null, s9, v5, vcc_lo               // 000000025AD4: D5207C05 01AA0A09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025ADC: BF870092
	.long 0xd7006a04                                           // 000000025AE0: D7006A04
	v_cndmask_b32_e32 v0, v4, v6, vcc_lo                       // 000000025AE4: 02000D04
	v_add_co_ci_u32_e64 v5, null, s7, v5, vcc_lo               // 000000025AE8: D5207C05 01AA0A07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025AF0: BF870092
	.long 0xd7006a04                                           // 000000025AF4: D7006A04
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000025AF8: 02020D04
	v_add_co_ci_u32_e64 v5, null, 0, v5, vcc_lo                // 000000025AFC: D5207C05 01AA0A80
	v_dual_mov_b32 v7, s5 :: v_dual_mov_b32 v6, s4             // 000000025B04: CA100005 07060004
	global_load_b64 v[4:5], v[4:5], off                        // 000000025B0C: DC560000 047C0004
	s_or_b32 exec_lo, exec_lo, s3                              // 000000025B14: 8C7E037E
	s_load_b128 s[4:7], s[0:1], 0x20                           // 000000025B18: F4080100 F8000020
	v_lshlrev_b32_e32 v9, 5, v0                                // 000000025B20: 30120085
	s_ashr_i32 s3, s2, 31                                      // 000000025B24: 86039F02
	s_lshl_b64 s[0:1], s[14:15], 11                            // 000000025B28: 84808B0E
	s_lshl_b64 s[2:3], s[2:3], 12                              // 000000025B2C: 84828C02
	v_and_b32_e32 v8, 12, v1                                   // 000000025B30: 3610028C
	v_and_b32_e32 v9, 0x780, v9                                // 000000025B34: 361212FF 00000780
	s_add_u32 s0, s2, s0                                       // 000000025B3C: 80000002
	s_addc_u32 s1, s3, s1                                      // 000000025B40: 82010103
	v_lshlrev_b32_e32 v2, 5, v2                                // 000000025B44: 30040485
	.long 0xd73c0006                                           // 000000025B48: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000025B4C: 02020C81
	v_lshlrev_b32_e32 v8, 1, v8                                // 000000025B50: 30101081
	v_lshlrev_b32_e32 v0, 1, v0                                // 000000025B54: 30000081
	s_waitcnt lgkmcnt(0)                                       // 000000025B58: BF89FC07
	s_add_u32 s2, s4, s0                                       // 000000025B5C: 80020004
	s_addc_u32 s3, s5, s1                                      // 000000025B60: 82030105
	.long 0xd7000209                                           // 000000025B64: D7000209
	v_cndmask_b32_e32 v1, s2, v9, vcc_lo                       // 000000025B68: 02021202
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000025B6C: BF8700B1
	v_add_co_ci_u32_e64 v10, null, s3, 0, s2                   // 000000025B70: D5207C0A 00090003
	s_cmp_ge_i32 s17, s16                                      // 000000025B78: BF031011
	.long 0xd7006a02                                           // 000000025B7C: D7006A02
	v_cndmask_b32_e32 v1, v9, v2, vcc_lo                       // 000000025B80: 02020509
	v_add_co_ci_u32_e64 v9, null, 0, v10, vcc_lo               // 000000025B84: D5207C09 01AA1480
	.long 0xd7006a0a                                           // 000000025B8C: D7006A0A
	v_cndmask_b32_e32 v1, s10, v6, vcc_lo                      // 000000025B90: 02020C0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000025B94: BF870211
	v_add_co_ci_u32_e64 v11, null, s11, v7, vcc_lo             // 000000025B98: D5207C0B 01AA0E0B
	.long 0xd7006a06                                           // 000000025BA0: D7006A06
	v_cndmask_b32_e32 v1, v2, v8, vcc_lo                       // 000000025BA4: 02021102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000025BA8: BF870211
	v_add_co_ci_u32_e64 v7, null, 0, v9, vcc_lo                // 000000025BAC: D5207C07 01AA1280
	.long 0xd7006a00                                           // 000000025BB4: D7006A00
	v_cndmask_b32_e32 v1, v10, v0, vcc_lo                      // 000000025BB8: 0202010A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000025BBC: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v11, vcc_lo               // 000000025BC0: D5207C02 01AA1680
	s_waitcnt vmcnt(0)                                         // 000000025BC8: BF8903F7
	global_store_b64 v[6:7], v[4:5], off                       // 000000025BCC: DC6E0000 007C0406
	s_cbranch_scc0 47                                          // 000000025BD4: BFA1002F <_ZN7halogen12_GLOBAL__N_17k_kv_btEPKtS2_liPtS3_+0x294>
	s_or_b32 s2, s17, 1                                        // 000000025BD8: 8C028111
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000025BDC: BF870009
	s_cmp_ge_i32 s2, s16                                       // 000000025BE0: BF031002
	s_cbranch_scc0 62                                          // 000000025BE4: BFA1003E <_ZN7halogen12_GLOBAL__N_17k_kv_btEPKtS2_liPtS3_+0x2e0>
	v_mov_b32_e32 v4, 0                                        // 000000025BE8: 7E080280
	s_or_b32 s2, s17, 2                                        // 000000025BEC: 8C028211
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000025BF0: BF870009
	s_cmp_ge_i32 s2, s16                                       // 000000025BF4: BF031002
	s_cbranch_scc0 81                                          // 000000025BF8: BFA10051 <_ZN7halogen12_GLOBAL__N_17k_kv_btEPKtS2_liPtS3_+0x340>
	s_or_b32 s17, s17, 3                                       // 000000025BFC: 8C118311
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000025C00: BF870009
	s_cmp_ge_i32 s17, s16                                      // 000000025C04: BF031011
	s_cbranch_scc1 19                                          // 000000025C08: BFA20013 <_ZN7halogen12_GLOBAL__N_17k_kv_btEPKtS2_liPtS3_+0x258>
	s_ashr_i32 s2, s17, 31                                     // 000000025C0C: 86029F11
	s_mul_hi_u32 s3, s12, s17                                  // 000000025C10: 9683110C
	s_mul_i32 s2, s12, s2                                      // 000000025C14: 9602020C
	s_mul_i32 s4, s13, s17                                     // 000000025C18: 9604110D
	s_add_i32 s3, s3, s2                                       // 000000025C1C: 81030203
	s_mul_i32 s2, s12, s17                                     // 000000025C20: 9602110C
	s_add_i32 s3, s3, s4                                       // 000000025C24: 81030403
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000025C28: BF870499
	s_lshl_b64 s[2:3], s[2:3], 1                               // 000000025C2C: 84828102
	.long 0xd7006a05                                           // 000000025C30: D7006A05
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 000000025C34: 02000500
	s_delay_alu instid0(VALU_DEP_1)                            // 000000025C38: BF870001
	v_add_co_ci_u32_e64 v6, null, s3, v2, vcc_lo               // 000000025C3C: D5207C06 01AA0403
	global_load_u16 v0, v[5:6], off                            // 000000025C44: DC4A0000 007C0005
	s_waitcnt vmcnt(0)                                         // 000000025C4C: BF8903F7
	v_lshl_or_b32 v4, v0, 16, v4                               // 000000025C50: D6560004 04112100
	v_mov_b32_e32 v2, 0                                        // 000000025C58: 7E040280
	s_add_u32 s0, s6, s0                                       // 000000025C5C: 80000006
	s_addc_u32 s1, s7, s1                                      // 000000025C60: 82010107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000025C64: BF870091
	.long 0xd73c0000                                           // 000000025C68: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000025C6C: 02020281
	.long 0xd7006a00                                           // 000000025C70: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000025C74: 02020000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000025C78: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000025C7C: D5207C01 01AA0201
	s_waitcnt vmcnt(0)                                         // 000000025C84: BF8903F7
	global_store_b64 v[0:1], v[3:4], off                       // 000000025C88: DC6E0000 007C0300
	s_endpgm                                                   // 000000025C90: BFB00000
	s_ashr_i32 s2, s17, 31                                     // 000000025C94: 86029F11
	s_mul_hi_u32 s3, s12, s17                                  // 000000025C98: 9683110C
	s_mul_i32 s2, s12, s2                                      // 000000025C9C: 9602020C
	s_mul_i32 s4, s13, s17                                     // 000000025CA0: 9604110D
	s_add_i32 s3, s3, s2                                       // 000000025CA4: 81030203
	s_mul_i32 s2, s12, s17                                     // 000000025CA8: 9602110C
	s_add_i32 s3, s3, s4                                       // 000000025CAC: 81030403
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000025CB0: BF870499
	s_lshl_b64 s[2:3], s[2:3], 1                               // 000000025CB4: 84828102
	.long 0xd7006a03                                           // 000000025CB8: D7006A03
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 000000025CBC: 02000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000025CC0: BF8704B1
	v_add_co_ci_u32_e64 v4, null, s3, v2, vcc_lo               // 000000025CC4: D5207C04 01AA0403
	global_load_u16 v3, v[3:4], off                            // 000000025CCC: DC4A0000 037C0003
	s_or_b32 s2, s17, 1                                        // 000000025CD4: 8C028111
	s_cmp_ge_i32 s2, s16                                       // 000000025CD8: BF031002
	s_cbranch_scc1 65474                                       // 000000025CDC: BFA2FFC2 <_ZN7halogen12_GLOBAL__N_17k_kv_btEPKtS2_liPtS3_+0x1e8>
	s_ashr_i32 s3, s2, 31                                      // 000000025CE0: 86039F02
	s_mul_hi_u32 s4, s12, s2                                   // 000000025CE4: 9684020C
	s_mul_i32 s3, s12, s3                                      // 000000025CE8: 9603030C
	s_mul_i32 s5, s13, s2                                      // 000000025CEC: 9605020D
	s_add_i32 s3, s4, s3                                       // 000000025CF0: 81030304
	s_mul_i32 s2, s12, s2                                      // 000000025CF4: 9602020C
	s_add_i32 s3, s3, s5                                       // 000000025CF8: 81030503
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000025CFC: BF870499
	s_lshl_b64 s[2:3], s[2:3], 1                               // 000000025D00: 84828102
	.long 0xd7006a04                                           // 000000025D04: D7006A04
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 000000025D08: 02000500
	s_delay_alu instid0(VALU_DEP_1)                            // 000000025D0C: BF870001
	v_add_co_ci_u32_e64 v5, null, s3, v2, vcc_lo               // 000000025D10: D5207C05 01AA0403
	global_load_u16 v4, v[4:5], off                            // 000000025D18: DC4A0000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000025D20: BF8903F7
	v_lshl_or_b32 v3, v4, 16, v3                               // 000000025D24: D6560003 040D2104
	v_mov_b32_e32 v4, 0                                        // 000000025D2C: 7E080280
	s_or_b32 s2, s17, 2                                        // 000000025D30: 8C028211
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000025D34: BF870009
	s_cmp_ge_i32 s2, s16                                       // 000000025D38: BF031002
	s_cbranch_scc1 65455                                       // 000000025D3C: BFA2FFAF <_ZN7halogen12_GLOBAL__N_17k_kv_btEPKtS2_liPtS3_+0x1fc>
	s_ashr_i32 s3, s2, 31                                      // 000000025D40: 86039F02
	s_mul_hi_u32 s4, s12, s2                                   // 000000025D44: 9684020C
	s_mul_i32 s3, s12, s3                                      // 000000025D48: 9603030C
	s_mul_i32 s5, s13, s2                                      // 000000025D4C: 9605020D
	s_add_i32 s3, s4, s3                                       // 000000025D50: 81030304
	s_mul_i32 s2, s12, s2                                      // 000000025D54: 9602020C
	s_add_i32 s3, s3, s5                                       // 000000025D58: 81030503
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000025D5C: BF870499
	s_lshl_b64 s[2:3], s[2:3], 1                               // 000000025D60: 84828102
	.long 0xd7006a04                                           // 000000025D64: D7006A04
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 000000025D68: 02000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000025D6C: BF8704B1
	v_add_co_ci_u32_e64 v5, null, s3, v2, vcc_lo               // 000000025D70: D5207C05 01AA0403
	global_load_u16 v4, v[4:5], off                            // 000000025D78: DC4A0000 047C0004
	s_or_b32 s17, s17, 3                                       // 000000025D80: 8C118311
	s_cmp_ge_i32 s17, s16                                      // 000000025D84: BF031011
	s_cbranch_scc0 65440                                       // 000000025D88: BFA1FFA0 <_ZN7halogen12_GLOBAL__N_17k_kv_btEPKtS2_liPtS3_+0x20c>
	s_branch 65458                                             // 000000025D8C: BFA0FFB2 <_ZN7halogen12_GLOBAL__N_17k_kv_btEPKtS2_liPtS3_+0x258>
		...

