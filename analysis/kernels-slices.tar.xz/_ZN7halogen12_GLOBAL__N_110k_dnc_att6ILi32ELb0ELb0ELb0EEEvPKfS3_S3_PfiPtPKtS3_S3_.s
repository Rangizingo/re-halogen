0000000000226800 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_():
	s_load_b256 s[4:11], s[0:1], null                          // 000000226800: F40C0100 F8000000
	v_dual_mov_b32 v6, v0 :: v_dual_and_b32 v1, 0x7f, v0       // 000000226808: CA240100 060000FF 0000007F
	s_mov_b32 s12, s3                                          // 000000226814: BE8C0003
	s_lshl_b32 s16, s2, 5                                      // 000000226818: 84108502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000022681C: BF8700B1
	v_dual_mov_b32 v4, v0 :: v_dual_lshlrev_b32 v1, 2, v1      // 000000226820: CA220100 04000282
	s_ashr_i32 s13, s12, 31                                    // 000000226828: 860D9F0C
	s_waitcnt lgkmcnt(0)                                       // 00000022682C: BF89FC07
	.long 0xd7000302                                           // 000000226830: D7000302
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 000000226834: 02020206
	s_delay_alu instid0(VALU_DEP_1)                            // 000000226838: BF870001
	v_add_co_ci_u32_e64 v3, null, s7, 0, s3                    // 00000022683C: D5207C03 000D0007
	s_mov_b32 s3, 0                                            // 000000226844: BE830080
	s_nop 0                                                    // 000000226848: BF800000
	s_nop 0                                                    // 00000022684C: BF800000
	s_nop 0                                                    // 000000226850: BF800000
	s_nop 0                                                    // 000000226854: BF800000
	s_nop 0                                                    // 000000226858: BF800000
	s_nop 0                                                    // 00000022685C: BF800000
	s_nop 0                                                    // 000000226860: BF800000
	s_nop 0                                                    // 000000226864: BF800000
	s_nop 0                                                    // 000000226868: BF800000
	s_nop 0                                                    // 00000022686C: BF800000
	s_nop 0                                                    // 000000226870: BF800000
	s_nop 0                                                    // 000000226874: BF800000
	s_nop 0                                                    // 000000226878: BF800000
	s_nop 0                                                    // 00000022687C: BF800000
	v_lshrrev_b32_e32 v5, 7, v4                                // 000000226880: 320A0887
	v_add_nc_u32_e32 v10, 0x100, v4                            // 000000226884: 4A1408FF 00000100
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022688C: BF870092
	v_or_b32_e32 v7, s16, v5                                   // 000000226890: 380E0A10
	v_mad_i64_i32 v[7:8], null, v7, 48, s[12:13]               // 000000226894: D6FF7C07 00316107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022689C: BF870091
	.long 0xd73c0007                                           // 0000002268A0: D73C0007
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 0000002268A4: 02020E89
	.long 0xd7006a07                                           // 0000002268A8: D7006A07
	v_cndmask_b32_e32 v1, v2, v7, vcc_lo                       // 0000002268AC: 02020F02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002268B0: BF870001
	v_add_co_ci_u32_e64 v8, null, v3, v8, vcc_lo               // 0000002268B4: D5207C08 01AA1103
	v_cmp_lt_u32_e32 vcc_lo, 0xeff, v4                         // 0000002268BC: 7C9208FF 00000EFF
	v_mov_b32_e32 v4, v10                                      // 0000002268C4: 7E08030A
	global_load_b32 v9, v[7:8], off                            // 0000002268C8: DC520000 097C0007
	v_mad_u64_u32 v[7:8], null, 0x204, v5, v[1:2]              // 0000002268D0: D6FE7C07 04060AFF 00000204
	s_or_b32 s3, vcc_lo, s3                                    // 0000002268DC: 8C03036A
	s_waitcnt vmcnt(0)                                         // 0000002268E0: BF8903F7
	ds_store_b32 v7, v9                                        // 0000002268E4: D8340000 00000907
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 0000002268EC: 917E037E
	s_cbranch_execnz 65507                                     // 0000002268F0: BFA6FFE3 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x80>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002268F4: 8C7E037E
	s_lshr_b32 s3, s2, 31                                      // 0000002268F8: 85039F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002268FC: BF870499
	s_add_i32 s2, s2, s3                                       // 000000226900: 81020302
	s_ashr_i32 s6, s2, 1                                       // 000000226904: 86068102
	s_mov_b32 s2, exec_lo                                      // 000000226908: BE82007E
	s_lshl_b32 s14, s6, 6                                      // 00000022690C: 840E8606
	v_cmpx_gt_u32_e32 64, v0                                   // 000000226910: 7D9800C0
	s_cbranch_execz 17                                         // 000000226914: BFA50011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x15c>
	v_or_b32_e32 v1, s14, v0                                   // 000000226918: 3802000E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000022691C: BF8704A1
	v_mad_i64_i32 v[1:2], null, 0xc0, v1, s[8:9]               // 000000226920: D6FF7C01 002202FF 000000C0
	s_lshl_b64 s[8:9], s[12:13], 2                             // 00000022692C: 8488820C
	.long 0xd7006a01                                           // 000000226930: D7006A01
	v_cndmask_b32_e32 v0, v1, v8, vcc_lo                       // 000000226934: 02001101
	s_delay_alu instid0(VALU_DEP_1)                            // 000000226938: BF870001
	v_add_co_ci_u32_e64 v2, null, s9, v2, vcc_lo               // 00000022693C: D5207C02 01AA0409
	global_load_b32 v1, v[1:2], off                            // 000000226944: DC520000 017C0001
	v_lshlrev_b32_e32 v2, 2, v0                                // 00000022694C: 30040082
	s_waitcnt vmcnt(0)                                         // 000000226950: BF8903F7
	ds_store_b32 v2, v1 offset:16512                           // 000000226954: D8344080 00000102
	s_or_b32 exec_lo, exec_lo, s2                              // 00000022695C: 8C7E027E
	s_mov_b64 s[2:3], 0                                        // 000000226960: BE820180
	s_cmp_eq_u64 s[10:11], 0                                   // 000000226964: BF10800A
	s_mul_hi_i32 s8, s6, 48                                    // 000000226968: 9708B006
	s_mul_i32 s9, s6, 48                                       // 00000022696C: 9609B006
	s_mov_b64 s[6:7], 0                                        // 000000226970: BE860180
	s_waitcnt lgkmcnt(0)                                       // 000000226974: BF89FC07
	s_barrier                                                  // 000000226978: BFBD0000
	buffer_gl0_inv                                             // 00000022697C: E0AC0000 00000000
	s_cbranch_scc1 6                                           // 000000226984: BFA20006 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x1a0>
	s_add_u32 s6, s9, s12                                      // 000000226988: 80060C09
	s_addc_u32 s7, s8, s13                                     // 00000022698C: 82070D08
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000226990: BF870499
	s_lshl_b64 s[6:7], s[6:7], 14                              // 000000226994: 84868E06
	s_add_u32 s6, s10, s6                                      // 000000226998: 8006060A
	s_addc_u32 s7, s11, s7                                     // 00000022699C: 8207070B
	s_load_b64 s[0:1], s[0:1], 0x28                            // 0000002269A0: F4040000 F8000028
	s_waitcnt lgkmcnt(0)                                       // 0000002269A8: BF89FC07
	s_cmp_eq_u64 s[0:1], 0                                     // 0000002269AC: BF108000
	s_cbranch_scc1 6                                           // 0000002269B0: BFA20006 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x1cc>
	s_add_u32 s2, s9, s12                                      // 0000002269B4: 80020C09
	s_addc_u32 s3, s8, s13                                     // 0000002269B8: 82030D08
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002269BC: BF870499
	s_lshl_b64 s[2:3], s[2:3], 13                              // 0000002269C0: 84828D02
	s_add_u32 s2, s0, s2                                       // 0000002269C4: 80020200
	s_addc_u32 s3, s1, s3                                      // 0000002269C8: 82030301
	s_sub_i32 s9, s16, s14                                     // 0000002269CC: 81890E10
	v_lshrrev_b32_e32 v7, 5, v0                                // 0000002269D0: 320E0085
	s_lshl_b32 s8, s9, 5                                       // 0000002269D4: 84088509
	s_mov_b32 s11, exec_lo                                     // 0000002269D8: BE8B007E
	s_sub_i32 s10, 0x800, s8                                   // 0000002269DC: 818A08FF 00000800
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002269E4: BF870009
	.long 0xd4c4007e                                           // 0000002269E8: D4C4007E
	v_cndmask_b32_e32 v1, s10, v0, vcc_lo                      // 0000002269EC: 0202000A
	s_cbranch_execz 189                                        // 0000002269F0: BFA500BD <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x4e8>
	v_mul_u32_u24_e32 v1, 0x204, v0                            // 0000002269F4: 160200FF 00000204
	v_mul_u32_u24_e32 v2, 0x4080, v7                           // 0000002269FC: 16040EFF 00004080
	s_cmp_lg_u64 s[6:7], 0                                     // 000000226A04: BF118006
	v_add_nc_u32_e32 v9, s16, v7                               // 000000226A08: 4A120E10
	s_cselect_b32 s14, -1, 0                                   // 000000226A0C: 980E80C1
	s_cmp_lg_u64 s[2:3], 0                                     // 000000226A10: BF118002
	v_sub_nc_u32_e32 v8, v1, v2                                // 000000226A14: 4C100501
	s_cselect_b32 s15, -1, 0                                   // 000000226A18: 980F80C1
	s_lshl_b64 s[0:1], s[12:13], 9                             // 000000226A1C: 8480890C
	s_mov_b32 s12, 0                                           // 000000226A20: BE8C0080
	s_add_u32 s0, s4, s0                                       // 000000226A24: 80000004
	s_addc_u32 s1, s5, s1                                      // 000000226A28: 82010105
	s_mov_b32 s13, 0x41800000                                  // 000000226A2C: BE8D00FF 41800000
	s_branch 8                                                 // 000000226A34: BFA00008 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x258>
	v_add_nc_u32_e32 v6, 0x100, v6                             // 000000226A38: 4A0C0CFF 00000100
	v_add_nc_u32_e32 v9, 8, v9                                 // 000000226A40: 4A121288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000226A44: BF8704A2
	v_cmp_le_i32_e32 vcc_lo, s10, v6                           // 000000226A48: 7C860C0A
	s_or_b32 s12, vcc_lo, s12                                  // 000000226A4C: 8C0C0C6A
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 000000226A50: 917E0C7E
	s_cbranch_execz 164                                        // 000000226A54: BFA500A4 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x4e8>
	v_lshrrev_b32_e32 v1, 5, v6                                // 000000226A58: 32020C85
	v_dual_mov_b32 v5, 0 :: v_dual_add_nc_u32 v2, s9, v6       // 000000226A5C: CA200080 05020C09
	v_and_b32_e32 v4, 0x7fffffe0, v6                           // 000000226A64: 36080CFF 7FFFFFE0
	s_mov_b32 s16, exec_lo                                     // 000000226A6C: BE90007E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000226A70: BF870113
	v_add_nc_u32_e32 v3, s9, v1                                // 000000226A74: 4A060209
	v_sub_nc_u32_e32 v1, v2, v4                                // 000000226A78: 4C020902
	s_delay_alu instid0(VALU_DEP_1)                            // 000000226A7C: BF870001
	.long 0xd4c3007e                                           // 000000226A80: D4C3007E
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000226A84: 02020701
	s_cbranch_execz 108                                        // 000000226A88: BFA5006C <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x43c>
	v_mad_i64_i32 v[4:5], null, 0x6000, v9, s[0:1]             // 000000226A8C: D6FF7C04 000212FF 00006000
	v_mov_b32_e32 v2, 0                                        // 000000226A98: 7E040280
	v_mov_b32_e32 v10, v8                                      // 000000226A9C: 7E140308
	s_mov_b64 s[4:5], 0                                        // 000000226AA0: BE840180
	s_delay_alu instid0(VALU_DEP_3) | instid1(SALU_CYCLE_1)    // 000000226AA4: BF870483
	.long 0xd7006a17                                           // 000000226AA8: D7006A17
	v_cndmask_b32_e32 v0, v4, v4, vcc_lo                       // 000000226AAC: 02000904
	s_delay_alu instid0(VALU_DEP_1)                            // 000000226AB0: BF870001
	v_add_co_ci_u32_e64 v24, null, s5, v5, vcc_lo              // 000000226AB4: D5207C18 01AA0A05
	ds_load_2addr_b32 v[27:28], v10 offset1:1                  // 000000226ABC: D8DC0100 1B00000A
	ds_load_2addr_b32 v[29:30], v10 offset0:2 offset1:3        // 000000226AC4: D8DC0302 1D00000A
	ds_load_2addr_b32 v[31:32], v10 offset0:4 offset1:5        // 000000226ACC: D8DC0504 1F00000A
	ds_load_2addr_b32 v[33:34], v10 offset0:6 offset1:7        // 000000226AD4: D8DC0706 2100000A
	s_add_u32 s4, s4, 64                                       // 000000226ADC: 8004C004
	s_addc_u32 s5, s5, 0                                       // 000000226AE0: 82058005
	s_clause 0x3                                               // 000000226AE4: BF850003
	global_load_b128 v[11:14], v[23:24], off                   // 000000226AE8: DC5E0000 0B7C0017
	global_load_b128 v[15:18], v[23:24], off offset:16         // 000000226AF0: DC5E0010 0F7C0017
	global_load_b128 v[19:22], v[23:24], off offset:32         // 000000226AF8: DC5E0020 137C0017
	global_load_b128 v[23:26], v[23:24], off offset:48         // 000000226B00: DC5E0030 177C0017
	s_cmpk_eq_i32 s4, 0x200                                    // 000000226B08: B1840200
	s_waitcnt vmcnt(3) lgkmcnt(3)                              // 000000226B0C: BF890C37
	v_fmac_f32_e32 v2, v11, v27                                // 000000226B10: 5604370B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000226B14: BF8700C1
	v_fmac_f32_e32 v2, v12, v28                                // 000000226B18: 5604390C
	ds_load_2addr_b32 v[11:12], v10 offset0:8 offset1:9        // 000000226B1C: D8DC0908 0B00000A
	s_waitcnt lgkmcnt(3)                                       // 000000226B24: BF89FC37
	v_fmac_f32_e32 v2, v13, v29                                // 000000226B28: 56043B0D
	v_fmac_f32_e32 v2, v14, v30                                // 000000226B2C: 56043D0E
	ds_load_2addr_b32 v[13:14], v10 offset0:10 offset1:11      // 000000226B30: D8DC0B0A 0D00000A
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 000000226B38: BF890837
	v_fmac_f32_e32 v2, v15, v31                                // 000000226B3C: 56043F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000226B40: BF8700A1
	v_fmac_f32_e32 v2, v16, v32                                // 000000226B44: 56044110
	s_waitcnt lgkmcnt(2)                                       // 000000226B48: BF89FC27
	v_fmac_f32_e32 v2, v17, v33                                // 000000226B4C: 56044311
	s_delay_alu instid0(VALU_DEP_1)                            // 000000226B50: BF870001
	v_fmac_f32_e32 v2, v18, v34                                // 000000226B54: 56044512
	ds_load_2addr_b32 v[15:16], v10 offset0:12 offset1:13      // 000000226B58: D8DC0D0C 0F00000A
	ds_load_2addr_b32 v[17:18], v10 offset0:14 offset1:15      // 000000226B60: D8DC0F0E 1100000A
	v_add_nc_u32_e32 v10, 64, v10                              // 000000226B68: 4A1414C0
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 000000226B6C: BF890437
	v_fmac_f32_e32 v2, v19, v11                                // 000000226B70: 56041713
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000226B74: BF8700A1
	v_fmac_f32_e32 v2, v20, v12                                // 000000226B78: 56041914
	s_waitcnt lgkmcnt(2)                                       // 000000226B7C: BF89FC27
	v_fmac_f32_e32 v2, v21, v13                                // 000000226B80: 56041B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000226B84: BF8700A1
	v_fmac_f32_e32 v2, v22, v14                                // 000000226B88: 56041D16
	s_waitcnt vmcnt(0) lgkmcnt(1)                              // 000000226B8C: BF890017
	v_fmac_f32_e32 v2, v23, v15                                // 000000226B90: 56041F17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000226B94: BF8700A1
	v_fmac_f32_e32 v2, v24, v16                                // 000000226B98: 56042118
	s_waitcnt lgkmcnt(0)                                       // 000000226B9C: BF89FC07
	v_fmac_f32_e32 v2, v25, v17                                // 000000226BA0: 56042319
	s_delay_alu instid0(VALU_DEP_1)                            // 000000226BA4: BF870001
	v_fmac_f32_e32 v2, v26, v18                                // 000000226BA8: 5604251A
	s_cbranch_scc0 65469                                       // 000000226BAC: BFA1FFBD <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x2a4>
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000226BB0: 30080682
	v_lshlrev_b32_e32 v5, 2, v1                                // 000000226BB4: 300A0282
	ds_load_b32 v4, v4 offset:16512                            // 000000226BB8: D8D84080 04000004
	ds_load_b32 v5, v5 offset:16512                            // 000000226BC0: D8D84080 05000005
	s_waitcnt lgkmcnt(0)                                       // 000000226BC8: BF89FC07
	v_sub_f32_e32 v4, v4, v5                                   // 000000226BCC: 08080B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226BD0: BF870091
	v_mul_f32_e32 v5, 0x3fb8aa3b, v4                           // 000000226BD4: 100A08FF 3FB8AA3B
	v_fma_f32 v10, 0x3fb8aa3b, v4, -v5                         // 000000226BDC: D613000A 841608FF 3FB8AA3B
	v_rndne_f32_e32 v11, v5                                    // 000000226BE8: 7E164705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000226BEC: BF870121
	v_dual_sub_f32 v5, v5, v11 :: v_dual_fmac_f32 v10, 0x32a5705f, v4// 000000226BF0: C9401705 050A08FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 000000226BFC: 7C3608FF C2CE8ED0
	v_add_f32_e32 v5, v5, v10                                  // 000000226C04: 060A1505
	v_cvt_i32_f32_e32 v10, v11                                 // 000000226C08: 7E14110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000226C0C: BF870292
	v_exp_f32_e32 v5, v5                                       // 000000226C10: 7E0A4B05
	.long 0xd71c0005                                           // 000000226C14: D71C0005
	v_cndmask_b32_e32 v1, v5, v10, vcc_lo                      // 000000226C18: 02021505
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000226C1C: BF870121
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo                        // 000000226C20: 020A0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 000000226C24: 7C3C08FF 42B17218
	v_cndmask_b32_e32 v4, 0x7f800000, v5, vcc_lo               // 000000226C2C: 02080AFF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000226C34: BF870001
	v_mul_f32_e32 v5, v2, v4                                   // 000000226C38: 100A0902
	s_or_b32 exec_lo, exec_lo, s16                             // 000000226C3C: 8C7E107E
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000226C40: 3408069F
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000226C44: 3404029F
	s_and_not1_b32 vcc_lo, exec_lo, s14                        // 000000226C48: 916A0E7E
	s_cbranch_vccnz 17                                         // 000000226C4C: BFA40011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x494>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000226C50: BF870112
	.long 0xd73c000a                                           // 000000226C54: D73C000A
	v_cndmask_b32_e32 v1, 8, v3, vcc_lo                        // 000000226C58: 02020688
	.long 0xd73c000c                                           // 000000226C5C: D73C000C
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000226C60: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226C64: BF870092
	.long 0xd7006a0a                                           // 000000226C68: D7006A0A
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 000000226C6C: 02021406
	v_add_co_ci_u32_e64 v11, null, s7, v11, vcc_lo             // 000000226C70: D5207C0B 01AA1607
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226C78: BF870092
	.long 0xd7006a0a                                           // 000000226C7C: D7006A0A
	v_cndmask_b32_e32 v1, v10, v12, vcc_lo                     // 000000226C80: 0202190A
	v_add_co_ci_u32_e64 v11, null, v11, v13, vcc_lo            // 000000226C84: D5207C0B 01AA1B0B
	global_store_b32 v[10:11], v5, off                         // 000000226C8C: DC6A0000 007C050A
	s_and_not1_b32 vcc_lo, exec_lo, s15                        // 000000226C94: 916A0F7E
	s_cbranch_vccnz 65383                                      // 000000226C98: BFA4FF67 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x238>
	.long 0xd73c0003                                           // 000000226C9C: D73C0003
	v_cndmask_b32_e32 v1, 7, v3, vcc_lo                        // 000000226CA0: 02020687
	.long 0xd73c000a                                           // 000000226CA4: D73C000A
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000226CA8: 02020281
	v_fma_mixlo_f16 v1, v5, s13, 0                             // 000000226CAC: CC210001 02001B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226CB4: BF870093
	.long 0xd7006a02                                           // 000000226CB8: D7006A02
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000226CBC: 02020602
	v_add_co_ci_u32_e64 v3, null, s3, v4, vcc_lo               // 000000226CC0: D5207C03 01AA0803
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226CC8: BF870092
	.long 0xd7006a02                                           // 000000226CCC: D7006A02
	v_cndmask_b32_e32 v1, v2, v10, vcc_lo                      // 000000226CD0: 02021502
	v_add_co_ci_u32_e64 v3, null, v3, v11, vcc_lo              // 000000226CD4: D5207C03 01AA1703
	global_store_b16 v[2:3], v1, off                           // 000000226CDC: DC660000 007C0102
	s_branch 65364                                             // 000000226CE4: BFA0FF54 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x238>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000226CE8: 8C7E0B7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000226CEC: BF870009
	s_mov_b32 s0, exec_lo                                      // 000000226CF0: BE80007E
	.long 0xd4c4007e                                           // 000000226CF4: D4C4007E
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000226CF8: 02020008
	s_cbranch_execz 96                                         // 000000226CFC: BFA50060 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x680>
	s_cmp_lg_u64 s[6:7], 0                                     // 000000226D00: BF118006
	v_and_b32_e32 v1, 0xe0, v0                                 // 000000226D04: 360200FF 000000E0
	s_cselect_b32 s1, -1, 0                                    // 000000226D0C: 980180C1
	s_ashr_i32 s0, s9, 31                                      // 000000226D10: 86009F09
	.long 0xd7000402                                           // 000000226D14: D7000402
	v_cndmask_b32_e32 v1, s9, v0, vcc_lo                       // 000000226D18: 02020009
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000226D1C: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s0, 0, s4                    // 000000226D20: D5207C03 00110000
	v_lshlrev_b32_e32 v6, 8, v7                                // 000000226D28: 300C0E88
	.long 0xd7016a02                                           // 000000226D2C: D7016A02
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000226D30: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000226D34: BF8701C1
	v_subrev_co_ci_u32_e64 v3, null, 0, v3, vcc_lo             // 000000226D38: D5227C03 01AA0680
	v_mov_b32_e32 v1, 0                                        // 000000226D40: 7E020280
	v_lshlrev_b32_e32 v7, 7, v7                                // 000000226D44: 300E0E87
	s_cmp_lg_u64 s[2:3], 0                                     // 000000226D48: BF118002
	.long 0xd73c0004                                           // 000000226D4C: D73C0004
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000226D50: 02020482
	.long 0xd73c0002                                           // 000000226D54: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 000000226D58: 02020481
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226D5C: BF870092
	.long 0xd7006a04                                           // 000000226D60: D7006A04
	v_cndmask_b32_e32 v1, v6, v4, vcc_lo                       // 000000226D64: 02020906
	v_add_co_ci_u32_e64 v5, null, 0, v5, vcc_lo                // 000000226D68: D5207C05 01AA0A80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226D70: BF870093
	.long 0xd7006a06                                           // 000000226D74: D7006A06
	v_cndmask_b32_e32 v1, v7, v2, vcc_lo                       // 000000226D78: 02020507
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 000000226D7C: D5207C07 01AA0680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226D84: BF870094
	.long 0xd7006a02                                           // 000000226D88: D7006A02
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000226D8C: 02020806
	v_add_co_ci_u32_e64 v3, null, s7, v5, vcc_lo               // 000000226D90: D5207C03 01AA0A07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000226D98: BF870094
	.long 0xd7006a04                                           // 000000226D9C: D7006A04
	v_cndmask_b32_e32 v1, s2, v6, vcc_lo                       // 000000226DA0: 02020C02
	v_add_co_ci_u32_e64 v5, null, s3, v7, vcc_lo               // 000000226DA4: D5207C05 01AA0E03
	v_dual_mov_b32 v7, v1 :: v_dual_mov_b32 v6, v0             // 000000226DAC: CA100101 07060100
	s_cselect_b32 s2, -1, 0                                    // 000000226DB4: 980280C1
	s_mov_b32 s3, 0                                            // 000000226DB8: BE830080
	s_set_inst_prefetch_distance 0x1                           // 000000226DBC: BF840001
	s_branch 37                                                // 000000226DC0: BFA00025 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x658>
	s_nop 0                                                    // 000000226DC4: BF800000
	s_nop 0                                                    // 000000226DC8: BF800000
	s_nop 0                                                    // 000000226DCC: BF800000
	s_nop 0                                                    // 000000226DD0: BF800000
	s_nop 0                                                    // 000000226DD4: BF800000
	s_nop 0                                                    // 000000226DD8: BF800000
	s_nop 0                                                    // 000000226DDC: BF800000
	s_nop 0                                                    // 000000226DE0: BF800000
	s_nop 0                                                    // 000000226DE4: BF800000
	s_nop 0                                                    // 000000226DE8: BF800000
	s_nop 0                                                    // 000000226DEC: BF800000
	s_nop 0                                                    // 000000226DF0: BF800000
	s_nop 0                                                    // 000000226DF4: BF800000
	s_nop 0                                                    // 000000226DF8: BF800000
	s_nop 0                                                    // 000000226DFC: BF800000
	.long 0xd7006a06                                           // 000000226E00: D7006A06
	v_cndmask_b32_e32 v1, 0x100, v6, vcc_lo                    // 000000226E04: 02020CFF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000226E0C: BF8700A1
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 000000226E10: D5207C07 01AA0E80
	.long 0xd7006a02                                           // 000000226E18: D7006A02
	v_cndmask_b32_e32 v1, 0x800, v2, vcc_lo                    // 000000226E1C: 020204FF 00000800
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000226E24: D5207C03 01AA0680
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000226E2C: BF8700A4
	v_cmp_le_i32_e32 vcc_lo, s8, v6                            // 000000226E30: 7C860C08
	.long 0xd7000004                                           // 000000226E34: D7000004
	v_cndmask_b32_e32 v1, 0x400, v4, vcc_lo                    // 000000226E38: 020208FF 00000400
	v_add_co_ci_u32_e64 v5, null, 0, v5, s0                    // 000000226E40: D5207C05 00020A80
	s_or_b32 s3, vcc_lo, s3                                    // 000000226E48: 8C03036A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000226E4C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000226E50: 917E037E
	s_cbranch_execz 10                                         // 000000226E54: BFA5000A <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x680>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000226E58: 916A017E
	s_cbranch_vccnz 2                                          // 000000226E5C: BFA40002 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x668>
	global_store_b32 v[2:3], v1, off                           // 000000226E60: DC6A0000 007C0102
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 000000226E68: 916A027E
	s_cbranch_vccnz 65508                                      // 000000226E6C: BFA4FFE4 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x600>
	.long 0x7e003880                                           // 000000226E70: 7E003880
	global_store_b16 v[4:5], v0, off                           // 000000226E74: DC660000 007C0004
	s_branch 65504                                             // 000000226E7C: BFA0FFE0 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb0ELb0ELb0EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x600>
	s_set_inst_prefetch_distance 0x2                           // 000000226E80: BF840002
	s_endpgm                                                   // 000000226E84: BFB00000
		...

