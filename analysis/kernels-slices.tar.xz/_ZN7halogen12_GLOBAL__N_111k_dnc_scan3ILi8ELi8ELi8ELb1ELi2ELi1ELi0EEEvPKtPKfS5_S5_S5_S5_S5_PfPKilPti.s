000000000007af00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 00000007AF00: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 00000007AF04: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000007AF0C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 00000007AF14: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 00000007AF18: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000007AF1C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 00000007AF20: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000007AF28: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000007AF2C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 00000007AF30: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 00000007AF34: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000007AF3C: 84928214
	s_add_u32 s25, s16, s18                                    // 00000007AF40: 80191210
	s_addc_u32 s28, s17, s19                                   // 00000007AF44: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 00000007AF48: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007AF4C: BF870009
	s_add_u32 s25, s25, s20                                    // 00000007AF50: 80191419
	s_addc_u32 s30, s28, s21                                   // 00000007AF54: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 00000007AF58: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000007AF5C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 00000007AF64: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000007AF6C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 00000007AF70: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 00000007AF74: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000007AF78: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000007AF7C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 00000007AF80: 821E191E
	.long 0xd7001f02                                           // 00000007AF84: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 00000007AF88: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000007AF8C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 00000007AF94: BE9E0080
	s_nop 0                                                    // 00000007AF98: BF800000
	s_nop 0                                                    // 00000007AF9C: BF800000
	s_nop 0                                                    // 00000007AFA0: BF800000
	s_nop 0                                                    // 00000007AFA4: BF800000
	s_nop 0                                                    // 00000007AFA8: BF800000
	s_nop 0                                                    // 00000007AFAC: BF800000
	s_nop 0                                                    // 00000007AFB0: BF800000
	s_nop 0                                                    // 00000007AFB4: BF800000
	s_nop 0                                                    // 00000007AFB8: BF800000
	s_nop 0                                                    // 00000007AFBC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 00000007AFC0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 00000007AFC4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007AFCC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 00000007AFD0: 300C1089
	.long 0xd7006a06                                           // 00000007AFD4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000007AFD8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007AFDC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 00000007AFE0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000007AFE8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 00000007AFF0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 00000007AFF4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 00000007AFFC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 00000007B008: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000007B00C: BF8903F7
	ds_store_b32 v6, v9                                        // 00000007B010: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 00000007B018: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000007B01C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 00000007B020: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 00000007B024: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 00000007B02C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 00000007B034: 32040084
	s_mov_b32 s0, 0                                            // 00000007B038: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000007B03C: BF89FC07
	s_barrier                                                  // 00000007B040: BFBD0000
	buffer_gl0_inv                                             // 00000007B044: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000007B04C: BF02801E
	s_cbranch_scc1 12                                          // 00000007B050: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 00000007B054: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000007B05C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007B064: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 00000007B068: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 00000007B070: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000007B074: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000007B078: 916A007E
	s_cbranch_vccz 2                                           // 00000007B07C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2136                                              // 00000007B080: BFA00858 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x22e4>
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000007B084: 304E0A82
	s_add_i32 s0, s30, 63                                      // 00000007B088: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000007B08C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 00000007B094: 85218600
	s_add_u32 s34, s10, s24                                    // 00000007B098: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000007B09C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 00000007B0A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 00000007B0A4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 00000007B0AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 00000007B0B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000007B0B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 00000007B0B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 00000007B0BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 00000007B0C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 00000007B0C4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 00000007B0C8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 00000007B0D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 00000007B0D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 00000007B0DC: B00A0204
	.long 0xd7000b2c                                           // 00000007B0E0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 00000007B0E4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000007B0E8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 00000007B0EC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 00000007B0F4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 00000007B100: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 00000007B104: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 00000007B110: 3816500A
	.long 0xd7000a05                                           // 00000007B114: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 00000007B118: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007B11C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 00000007B120: D5207C06 00290001
	.long 0xd7000107                                           // 00000007B128: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 00000007B12C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007B130: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 00000007B134: D5207C08 0006180D
	.long 0xd7000109                                           // 00000007B13C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 00000007B140: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 00000007B144: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 00000007B14C: 84848E02
	.long 0xd700010b                                           // 00000007B150: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 00000007B154: 02021606
	s_add_u32 s4, s14, s4                                      // 00000007B158: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 00000007B15C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 00000007B164: 8205050F
	.long 0xd700010d                                           // 00000007B168: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 00000007B16C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007B170: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 00000007B174: D5207C0E 00050005
	.long 0xd700010f                                           // 00000007B17C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 00000007B180: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 00000007B188: D5207C10 00061880
	.long 0xd7000111                                           // 00000007B190: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 00000007B194: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007B19C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 00000007B1A0: D5207C12 00061880
	.long 0xd7000113                                           // 00000007B1A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 00000007B1AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 00000007B1B4: D5207C14 00061880
	.long 0xd7000115                                           // 00000007B1BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 00000007B1C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007B1C8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 00000007B1CC: D5207C16 00061880
	.long 0xd7000117                                           // 00000007B1D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 00000007B1D8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 00000007B1E0: D5207C18 00061880
	.long 0xd7000119                                           // 00000007B1E8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 00000007B1EC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007B1F4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 00000007B1F8: D5207C1A 00061880
	.long 0xd700011b                                           // 00000007B200: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 00000007B204: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 00000007B20C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 00000007B214: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000007B218: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 00000007B220: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 00000007B224: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 00000007B22C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 00000007B234: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 00000007B23C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 00000007B244: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 00000007B24C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 00000007B254: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 00000007B25C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 00000007B264: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 00000007B26C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 00000007B274: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 00000007B27C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 00000007B284: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 00000007B28C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 00000007B294: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 00000007B29C: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 00000007B2A0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 00000007B2A4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000007B2AC: BF870499
	s_add_i32 s6, s31, s1                                      // 00000007B2B0: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 00000007B2B4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B2B8: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 00000007B2BC: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 00000007B2C0: 84078605
	s_add_u32 s10, s8, s10                                     // 00000007B2C4: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 00000007B2C8: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 00000007B2CC: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 00000007B2D4: BE84206A
	s_cbranch_execz 77                                         // 00000007B2D8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510>
	v_or_b32_e32 v29, s7, v0                                   // 00000007B2DC: 383A0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007B2E0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 00000007B2E4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 00000007B2EC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007B2F0: BF870091
	.long 0xd73c001d                                           // 00000007B2F4: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 00000007B2F8: 02023A82
	.long 0xd700011d                                           // 00000007B2FC: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 00000007B300: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007B304: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 00000007B308: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 00000007B310: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007B318: BF890007
	v_sub_f32_e32 v30, s6, v29                                 // 00000007B31C: 083C3A06
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 00000007B320: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000007B32C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 00000007B330: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 00000007B33C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 00000007B340: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 00000007B34C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007B350: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 00000007B354: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 00000007B360: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007B364: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 00000007B368: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 00000007B370: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 00000007B374: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 00000007B37C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 00000007B384: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 00000007B388: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007B38C: BF870193
	v_exp_f32_e32 v32, v32                                     // 00000007B390: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 00000007B394: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007B398: BF870296
	.long 0xd71c0020                                           // 00000007B39C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 00000007B3A0: 02024520
	.long 0xd71c001f                                           // 00000007B3A4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 00000007B3A8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007B3AC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 00000007B3B0: D501001F 00063E80
	.long 0xd41b0001                                           // 00000007B3B8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 00000007B3BC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 00000007B3C4: D5010020 00064080
	.long 0xd41e0001                                           // 00000007B3CC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 00000007B3D0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007B3D8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 00000007B3DC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 00000007B3E8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 00000007B3EC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 00000007B3F4: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 00000007B400: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 00000007B408: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007B410: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 00000007B414: CA100108 1E1C0107
	s_mov_b32 s10, 0                                           // 00000007B41C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000007B420: BF89FC07
	s_barrier                                                  // 00000007B424: BFBD0000
	buffer_gl0_inv                                             // 00000007B428: E0AC0000 00000000
	s_branch 15                                                // 00000007B430: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007B434: 8C7E047E
	.long 0xd700011d                                           // 00000007B438: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 00000007B43C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007B444: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007B448: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 00000007B450: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000007B454: BF08B70A
	s_mov_b32 s10, s1                                          // 00000007B458: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 00000007B45C: BF89FC07
	s_barrier                                                  // 00000007B460: BFBD0000
	buffer_gl0_inv                                             // 00000007B464: E0AC0000 00000000
	s_cbranch_scc1 231                                         // 00000007B46C: BFA200E7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x90c>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 00000007B470: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 00000007B478: CA100128 21220126
	s_mov_b32 s11, 0                                           // 00000007B480: BE8B0080
	s_nop 0                                                    // 00000007B484: BF800000
	s_nop 0                                                    // 00000007B488: BF800000
	s_nop 0                                                    // 00000007B48C: BF800000
	s_nop 0                                                    // 00000007B490: BF800000
	s_nop 0                                                    // 00000007B494: BF800000
	s_nop 0                                                    // 00000007B498: BF800000
	s_nop 0                                                    // 00000007B49C: BF800000
	s_nop 0                                                    // 00000007B4A0: BF800000
	s_nop 0                                                    // 00000007B4A4: BF800000
	s_nop 0                                                    // 00000007B4A8: BF800000
	s_nop 0                                                    // 00000007B4AC: BF800000
	s_nop 0                                                    // 00000007B4B0: BF800000
	s_nop 0                                                    // 00000007B4B4: BF800000
	s_nop 0                                                    // 00000007B4B8: BF800000
	s_nop 0                                                    // 00000007B4BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 00000007B4C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 00000007B4C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 00000007B4D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 00000007B4D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007B4DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 00000007B4E0: D5207C20 00064080
	.long 0xd4490004                                           // 00000007B4E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 00000007B4EC: 020244FF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000007B4F4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000007B4F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 00000007B4FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 00000007B504: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000007B50C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000007B510: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000007B514: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000007B518: BF89FC07
	s_barrier                                                  // 00000007B51C: BFBD0000
	buffer_gl0_inv                                             // 00000007B520: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000007B528: BE842000
	s_cbranch_execz 65473                                      // 00000007B52C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_or3_b32 v31, s10, s7, v2                                 // 00000007B530: D658001F 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007B538: BF870091
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 00000007B53C: D6FE7C1F 0009611F
	.long 0xd73c001f                                           // 00000007B544: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 00000007B548: 02023E89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007B54C: BF870091
	.long 0xd700011f                                           // 00000007B550: D700011F
	v_cndmask_b32_e32 v1, v44, v31, vcc_lo                     // 00000007B554: 02023F2C
	v_add_co_ci_u32_e64 v32, null, v45, v32, s1                // 00000007B558: D5207C20 0006412D
	s_mov_b32 s1, 0                                            // 00000007B560: BE810080
	global_load_b32 v31, v[31:32], off                         // 00000007B564: DC520000 1F7C001F
	v_mad_u64_u32 v[32:33], null, 0x44, s1, v[1:2]             // 00000007B56C: D6FE7C20 040402FF 00000044
	s_add_i32 s11, s1, 8                                       // 00000007B578: 810B8801
	s_cmpk_lt_u32 s1, 0x78                                     // 00000007B57C: B6810078
	ds_load_2addr_b32 v[33:34], v32 offset1:17                 // 00000007B580: D8DC1100 21000020
	ds_load_2addr_b32 v[35:36], v32 offset0:34 offset1:51      // 00000007B588: D8DC3322 23000020
	ds_load_2addr_b32 v[60:61], v32 offset0:68 offset1:85      // 00000007B590: D8DC5544 3C000020
	ds_load_2addr_b32 v[62:63], v32 offset0:102 offset1:119    // 00000007B598: D8DC7766 3E000020
	v_lshl_add_u32 v32, s1, 2, v46                             // 00000007B5A0: D6460020 04B90401
	s_mov_b32 s1, s11                                          // 00000007B5A8: BE81000B
	ds_load_2addr_b32 v[64:65], v32 offset1:1                  // 00000007B5AC: D8DC0100 40000020
	ds_load_2addr_b32 v[66:67], v32 offset0:2 offset1:3        // 00000007B5B4: D8DC0302 42000020
	ds_load_2addr_b32 v[68:69], v32 offset0:4 offset1:5        // 00000007B5BC: D8DC0504 44000020
	ds_load_2addr_b32 v[70:71], v32 offset0:6 offset1:7        // 00000007B5C4: D8DC0706 46000020
	s_waitcnt lgkmcnt(7)                                       // 00000007B5CC: BF89FC77
	v_bfe_u32 v32, v33, 16, 1                                  // 00000007B5D0: D6100020 02052121
	v_bfe_u32 v72, v34, 16, 1                                  // 00000007B5D8: D6100048 02052122
	s_waitcnt lgkmcnt(6)                                       // 00000007B5E0: BF89FC67
	v_bfe_u32 v73, v35, 16, 1                                  // 00000007B5E4: D6100049 02052123
	v_bfe_u32 v74, v36, 16, 1                                  // 00000007B5EC: D610004A 02052124
	s_waitcnt lgkmcnt(5)                                       // 00000007B5F4: BF89FC57
	v_bfe_u32 v75, v60, 16, 1                                  // 00000007B5F8: D610004B 0205213C
	v_add3_u32 v32, v33, v32, 0x7fff                           // 00000007B600: D6550020 03FE4121 00007FFF
	v_add3_u32 v34, v34, v72, 0x7fff                           // 00000007B60C: D6550022 03FE9122 00007FFF
	v_add3_u32 v35, v35, v73, 0x7fff                           // 00000007B618: D6550023 03FE9323 00007FFF
	v_bfe_u32 v76, v61, 16, 1                                  // 00000007B624: D610004C 0205213D
	s_waitcnt lgkmcnt(3)                                       // 00000007B62C: BF89FC37
	v_bfe_u32 v79, v64, 16, 1                                  // 00000007B630: D610004F 02052140
	v_bfe_u32 v80, v65, 16, 1                                  // 00000007B638: D6100050 02052141
	s_waitcnt lgkmcnt(2)                                       // 00000007B640: BF89FC27
	v_bfe_u32 v81, v66, 16, 1                                  // 00000007B644: D6100051 02052142
	v_and_b32_e32 v32, 0xffff0000, v32                         // 00000007B64C: 364040FF FFFF0000
	v_bfe_u32 v82, v67, 16, 1                                  // 00000007B654: D6100052 02052143
	v_add3_u32 v33, v64, v79, 0x7fff                           // 00000007B65C: D6550021 03FE9F40 00007FFF
	v_add3_u32 v65, v65, v80, 0x7fff                           // 00000007B668: D6550041 03FEA141 00007FFF
	v_add3_u32 v66, v66, v81, 0x7fff                           // 00000007B674: D6550042 03FEA342 00007FFF
	v_and_b32_e32 v34, 0xffff0000, v34                         // 00000007B680: 364444FF FFFF0000
	s_waitcnt lgkmcnt(1)                                       // 00000007B688: BF89FC17
	v_bfe_u32 v83, v68, 16, 1                                  // 00000007B68C: D6100053 02052144
	v_and_b32_e32 v33, 0xffff0000, v33                         // 00000007B694: 364242FF FFFF0000
	v_and_b32_e32 v65, 0xffff0000, v65                         // 00000007B69C: 368282FF FFFF0000
	v_and_b32_e32 v35, 0xffff0000, v35                         // 00000007B6A4: 364646FF FFFF0000
	v_bfe_u32 v84, v69, 16, 1                                  // 00000007B6AC: D6100054 02052145
	v_bfe_u32 v77, v62, 16, 1                                  // 00000007B6B4: D610004D 0205213E
	s_waitcnt vmcnt(0)                                         // 00000007B6BC: BF8903F7
	v_fma_f32 v31, -v33, v32, v31                              // 00000007B6C0: D613001F 247E4121
	v_add3_u32 v32, v36, v74, 0x7fff                           // 00000007B6C8: D6550020 03FE9524 00007FFF
	v_add3_u32 v33, v67, v82, 0x7fff                           // 00000007B6D4: D6550021 03FEA543 00007FFF
	v_and_b32_e32 v36, 0xffff0000, v66                         // 00000007B6E0: 364884FF FFFF0000
	s_waitcnt lgkmcnt(0)                                       // 00000007B6E8: BF89FC07
	v_bfe_u32 v85, v70, 16, 1                                  // 00000007B6EC: D6100055 02052146
	v_fma_f32 v31, -v65, v34, v31                              // 00000007B6F4: D613001F 247E4541
	v_add3_u32 v34, v60, v75, 0x7fff                           // 00000007B6FC: D6550022 03FE973C 00007FFF
	v_add3_u32 v60, v68, v83, 0x7fff                           // 00000007B708: D655003C 03FEA744 00007FFF
	v_and_b32_e32 v32, 0xffff0000, v32                         // 00000007B714: 364040FF FFFF0000
	v_and_b32_e32 v33, 0xffff0000, v33                         // 00000007B71C: 364242FF FFFF0000
	v_fma_f32 v31, -v36, v35, v31                              // 00000007B724: D613001F 247E4724
	v_add3_u32 v35, v61, v76, 0x7fff                           // 00000007B72C: D6550023 03FE993D 00007FFF
	v_add3_u32 v36, v69, v84, 0x7fff                           // 00000007B738: D6550024 03FEA945 00007FFF
	v_and_b32_e32 v34, 0xffff0000, v34                         // 00000007B744: 364444FF FFFF0000
	v_and_b32_e32 v60, 0xffff0000, v60                         // 00000007B74C: 367878FF FFFF0000
	v_fma_f32 v31, -v33, v32, v31                              // 00000007B754: D613001F 247E4121
	v_bfe_u32 v78, v63, 16, 1                                  // 00000007B75C: D610004E 0205213F
	v_bfe_u32 v64, v71, 16, 1                                  // 00000007B764: D6100040 02052147
	v_add3_u32 v32, v62, v77, 0x7fff                           // 00000007B76C: D6550020 03FE9B3E 00007FFF
	v_add3_u32 v33, v70, v85, 0x7fff                           // 00000007B778: D6550021 03FEAB46 00007FFF
	v_and_b32_e32 v35, 0xffff0000, v35                         // 00000007B784: 364646FF FFFF0000
	v_and_b32_e32 v36, 0xffff0000, v36                         // 00000007B78C: 364848FF FFFF0000
	v_fma_f32 v31, -v60, v34, v31                              // 00000007B794: D613001F 247E453C
	v_add3_u32 v34, v63, v78, 0x7fff                           // 00000007B79C: D6550022 03FE9D3F 00007FFF
	v_add3_u32 v60, v71, v64, 0x7fff                           // 00000007B7A8: D655003C 03FE8147 00007FFF
	v_and_b32_e32 v32, 0xffff0000, v32                         // 00000007B7B4: 364040FF FFFF0000
	v_and_b32_e32 v33, 0xffff0000, v33                         // 00000007B7BC: 364242FF FFFF0000
	v_fma_f32 v31, -v36, v35, v31                              // 00000007B7C4: D613001F 247E4724
	v_and_b32_e32 v34, 0xffff0000, v34                         // 00000007B7CC: 364444FF FFFF0000
	v_and_b32_e32 v35, 0xffff0000, v60                         // 00000007B7D4: 364678FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007B7DC: BF870093
	v_fma_f32 v31, -v33, v32, v31                              // 00000007B7E0: D613001F 247E4121
	v_fma_f32 v31, -v35, v34, v31                              // 00000007B7E8: D613001F 247E4523
	s_cbranch_scc1 65374                                       // 00000007B7F0: BFA2FF5E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x66c>
	v_mad_u64_u32 v[32:33], null, 0x44, s10, v[4:5]            // 00000007B7F4: D6FE7C20 041014FF 00000044
	ds_store_b32 v32, v31                                      // 00000007B800: D8340000 00001F20
	s_branch 65290                                             // 00000007B808: BFA0FF0A <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_mov_b32_e32 v30, v14                                     // 00000007B80C: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 00000007B810: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 00000007B818: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 00000007B81C: 7E46032B
	s_mov_b32 s10, 0                                           // 00000007B820: BE8A0080
	s_branch 21                                                // 00000007B824: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x97c>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000007B828: 8C7E0B7E
	.long 0xd700011f                                           // 00000007B82C: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 00000007B830: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007B838: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 00000007B83C: D5207C20 00064080
	.long 0xd700011d                                           // 00000007B844: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 00000007B848: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 00000007B850: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007B854: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 00000007B85C: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000007B860: BF08B70A
	s_mov_b32 s10, s1                                          // 00000007B864: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 00000007B868: BC7C0000
	s_barrier                                                  // 00000007B86C: BFBD0000
	buffer_gl0_inv                                             // 00000007B870: E0AC0000 00000000
	s_cbranch_scc1 609                                         // 00000007B878: BFA20261 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1300>
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007B87C: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 00000007B880: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 00000007B888: 7E480328
	v_mov_b32_e32 v60, v38                                     // 00000007B88C: 7E780326
	s_mov_b32 s11, 0                                           // 00000007B890: BE8B0080
	s_nop 0                                                    // 00000007B894: BF800000
	s_nop 0                                                    // 00000007B898: BF800000
	s_nop 0                                                    // 00000007B89C: BF800000
	s_nop 0                                                    // 00000007B8A0: BF800000
	s_nop 0                                                    // 00000007B8A4: BF800000
	s_nop 0                                                    // 00000007B8A8: BF800000
	s_nop 0                                                    // 00000007B8AC: BF800000
	s_nop 0                                                    // 00000007B8B0: BF800000
	s_nop 0                                                    // 00000007B8B4: BF800000
	s_nop 0                                                    // 00000007B8B8: BF800000
	s_nop 0                                                    // 00000007B8BC: BF800000
	global_load_b32 v61, v[33:34], off                         // 00000007B8C0: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 00000007B8C8: 4A7878FF 00000080
	.long 0xd7000121                                           // 00000007B8D0: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 00000007B8D4: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007B8DC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 00000007B8E0: D5207C22 00064480
	.long 0xd4490004                                           // 00000007B8E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 00000007B8EC: 020278FF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000007B8F4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000007B8F8: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 00000007B8FC: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 00000007B904: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000007B90C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000007B910: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x9c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000007B914: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000007B918: BF89FC07
	s_barrier                                                  // 00000007B91C: BFBD0000
	buffer_gl0_inv                                             // 00000007B920: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 00000007B928: BE8B2000
	s_cbranch_execz 65470                                      // 00000007B92C: BFA5FFBE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x928>
	v_or_b32_e32 v33, s10, v2                                  // 00000007B930: 3842040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007B934: BF870091
	v_or_b32_e32 v36, s7, v33                                  // 00000007B938: 38484207
	.long 0xd4440001                                           // 00000007B93C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 00000007B940: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 00000007B944: 8B7E017E
	s_cbranch_execz 65463                                      // 00000007B948: BFA5FFB7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x928>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 00000007B94C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 00000007B954: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:2 offset1:3        // 00000007B95C: D8DC0302 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 00000007B964: D8DC3322 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:4 offset1:5        // 00000007B96C: D8DC0504 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:6 offset1:7        // 00000007B974: D8DC0706 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 00000007B97C: D8DC5544 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:102 offset1:119     // 00000007B984: D8DC7766 4A000001
	s_mov_b32 s12, 0                                           // 00000007B98C: BE8C0080
	s_waitcnt lgkmcnt(6)                                       // 00000007B990: BF89FC67
	v_fma_f32 v76, v60, v62, 0                                 // 00000007B994: D613004C 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007B99C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000007B9A0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000007B9A4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000007B9A8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007B9AC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000007B9B0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000007B9B4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000007B9B8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007B9BC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000007B9C0: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000007B9C4: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000007B9C8: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007B9CC: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000007B9D0: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:8 offset1:9        // 00000007B9D4: D8DC0908 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 00000007B9DC: D8DC9988 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:10 offset1:11      // 00000007B9E4: D8DC0B0A 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:170 offset1:187     // 00000007B9EC: D8DCBBAA 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:12 offset1:13      // 00000007B9F4: D8DC0D0C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:14 offset1:15      // 00000007B9FC: D8DC0F0E 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 00000007BA04: D8DCDDCC 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:238 offset1:255     // 00000007BA0C: D8DCFFEE 4A000001
	s_waitcnt lgkmcnt(6)                                       // 00000007BA14: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000007BA18: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BA1C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000007BA20: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000007BA24: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000007BA28: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BA2C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000007BA30: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000007BA34: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000007BA38: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BA3C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000007BA40: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000007BA44: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000007BA48: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BA4C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000007BA50: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:16 offset1:17      // 00000007BA54: D8DC1110 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:16 offset1:33      // 00000007BA5C: D8DC2110 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:18 offset1:19      // 00000007BA64: D8DC1312 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 00000007BA6C: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:20 offset1:21      // 00000007BA74: D8DC1514 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:22 offset1:23      // 00000007BA7C: D8DC1716 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:84 offset1:101     // 00000007BA84: D8DC6554 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 00000007BA8C: D8DC8776 4A000030
	s_waitcnt lgkmcnt(6)                                       // 00000007BA94: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000007BA98: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BA9C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000007BAA0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000007BAA4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000007BAA8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BAAC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000007BAB0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000007BAB4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000007BAB8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BABC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000007BAC0: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000007BAC4: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000007BAC8: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BACC: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000007BAD0: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 00000007BAD4: D8DC1918 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:152 offset1:169    // 00000007BADC: D8DCA998 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:26 offset1:27      // 00000007BAE4: D8DC1B1A 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:186 offset1:203    // 00000007BAEC: D8DCCBBA 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:28 offset1:29      // 00000007BAF4: D8DC1D1C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 00000007BAFC: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:220 offset1:237    // 00000007BB04: D8DCEDDC 48000030
	ds_load_2addr_b32 v[74:75], v49 offset0:126 offset1:143    // 00000007BB0C: D8DC8F7E 4A000031
	s_waitcnt lgkmcnt(6)                                       // 00000007BB14: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000007BB18: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BB1C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000007BB20: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000007BB24: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000007BB28: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BB2C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000007BB30: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000007BB34: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000007BB38: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BB3C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000007BB40: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000007BB44: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000007BB48: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BB4C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000007BB50: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:32 offset1:33      // 00000007BB54: D8DC2120 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:32 offset1:49      // 00000007BB5C: D8DC3120 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 00000007BB64: D8DC2322 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:66 offset1:83      // 00000007BB6C: D8DC5342 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:36 offset1:37      // 00000007BB74: D8DC2524 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:38 offset1:39      // 00000007BB7C: D8DC2726 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 00000007BB84: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 00000007BB8C: D8DC9786 4A000032
	s_waitcnt lgkmcnt(6)                                       // 00000007BB94: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000007BB98: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BB9C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000007BBA0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000007BBA4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000007BBA8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BBAC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000007BBB0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000007BBB4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000007BBB8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BBBC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000007BBC0: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000007BBC4: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000007BBC8: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BBCC: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000007BBD0: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:40 offset1:41      // 00000007BBD4: D8DC2928 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:168 offset1:185    // 00000007BBDC: D8DCB9A8 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:42 offset1:43      // 00000007BBE4: D8DC2B2A 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:202 offset1:219    // 00000007BBEC: D8DCDBCA 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:44 offset1:45      // 00000007BBF4: D8DC2D2C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:46 offset1:47      // 00000007BBFC: D8DC2F2E 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:236 offset1:253    // 00000007BC04: D8DCFDEC 48000032
	ds_load_2addr_b32 v[74:75], v51 offset0:14 offset1:31      // 00000007BC0C: D8DC1F0E 4A000033
	s_waitcnt lgkmcnt(6)                                       // 00000007BC14: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000007BC18: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BC1C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000007BC20: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000007BC24: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000007BC28: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BC2C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000007BC30: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000007BC34: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000007BC38: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BC3C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000007BC40: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000007BC44: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000007BC48: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BC4C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000007BC50: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 00000007BC54: D8DC3130 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:48 offset1:65      // 00000007BC5C: D8DC4130 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:50 offset1:51      // 00000007BC64: D8DC3332 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:82 offset1:99      // 00000007BC6C: D8DC6352 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:52 offset1:53      // 00000007BC74: D8DC3534 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:54 offset1:55      // 00000007BC7C: D8DC3736 4600002E
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 00000007BC84: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 00000007BC8C: D8DCA796 4A000033
	s_waitcnt lgkmcnt(6)                                       // 00000007BC94: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000007BC98: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BC9C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000007BCA0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000007BCA4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000007BCA8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BCAC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000007BCB0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000007BCB4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000007BCB8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BCBC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000007BCC0: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000007BCC4: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000007BCC8: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BCCC: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000007BCD0: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:56 offset1:57      // 00000007BCD4: D8DC3938 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:184 offset1:201    // 00000007BCDC: D8DCC9B8 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:58 offset1:59      // 00000007BCE4: D8DC3B3A 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:218 offset1:235    // 00000007BCEC: D8DCEBDA 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:60 offset1:61      // 00000007BCF4: D8DC3D3C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:62 offset1:63      // 00000007BCFC: D8DC3F3E 4600002E
	ds_load_2addr_b32 v[72:73], v52 offset0:124 offset1:141    // 00000007BD04: D8DC8D7C 48000034
	ds_load_2addr_b32 v[74:75], v53 offset0:30 offset1:47      // 00000007BD0C: D8DC2F1E 4A000035
	s_waitcnt lgkmcnt(6)                                       // 00000007BD14: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000007BD18: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BD1C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000007BD20: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000007BD24: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000007BD28: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BD2C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000007BD30: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000007BD34: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000007BD38: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BD3C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000007BD40: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000007BD44: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000007BD48: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BD4C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000007BD50: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:64 offset1:65      // 00000007BD54: D8DC4140 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:64 offset1:81      // 00000007BD5C: D8DC5140 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:66 offset1:67      // 00000007BD64: D8DC4342 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:98 offset1:115     // 00000007BD6C: D8DC7362 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:68 offset1:69      // 00000007BD74: D8DC4544 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:70 offset1:71      // 00000007BD7C: D8DC4746 4600002E
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 00000007BD84: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 00000007BD8C: D8DCB7A6 4A000035
	s_waitcnt lgkmcnt(6)                                       // 00000007BD94: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000007BD98: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BD9C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000007BDA0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000007BDA4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000007BDA8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BDAC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000007BDB0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000007BDB4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000007BDB8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BDBC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000007BDC0: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000007BDC4: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000007BDC8: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BDCC: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000007BDD0: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 00000007BDD4: D8DC4948 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:200 offset1:217    // 00000007BDDC: D8DCD9C8 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:74 offset1:75      // 00000007BDE4: D8DC4B4A 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:234 offset1:251    // 00000007BDEC: D8DCFBEA 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:76 offset1:77      // 00000007BDF4: D8DC4D4C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:78 offset1:79      // 00000007BDFC: D8DC4F4E 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:12 offset1:29      // 00000007BE04: D8DC1D0C 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:46 offset1:63      // 00000007BE0C: D8DC3F2E 4A000036
	s_waitcnt lgkmcnt(6)                                       // 00000007BE14: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000007BE18: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BE1C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000007BE20: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000007BE24: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000007BE28: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BE2C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000007BE30: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000007BE34: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000007BE38: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BE3C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000007BE40: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000007BE44: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000007BE48: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BE4C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000007BE50: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:80 offset1:81      // 00000007BE54: D8DC5150 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:80 offset1:97      // 00000007BE5C: D8DC6150 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 00000007BE64: D8DC5352 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:114 offset1:131    // 00000007BE6C: D8DC8372 42000036
	ds_load_2addr_b32 v[68:69], v46 offset0:84 offset1:85      // 00000007BE74: D8DC5554 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:86 offset1:87      // 00000007BE7C: D8DC5756 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 00000007BE84: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 00000007BE8C: D8DCC7B6 4A000036
	s_waitcnt lgkmcnt(6)                                       // 00000007BE94: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000007BE98: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BE9C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000007BEA0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000007BEA4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000007BEA8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BEAC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000007BEB0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000007BEB4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000007BEB8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BEBC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000007BEC0: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000007BEC4: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000007BEC8: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BECC: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000007BED0: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:88 offset1:89      // 00000007BED4: D8DC5958 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:216 offset1:233    // 00000007BEDC: D8DCE9D8 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:90 offset1:91      // 00000007BEE4: D8DC5B5A 4000002E
	ds_load_2addr_b32 v[66:67], v55 offset0:122 offset1:139    // 00000007BEEC: D8DC8B7A 42000037
	ds_load_2addr_b32 v[68:69], v46 offset0:92 offset1:93      // 00000007BEF4: D8DC5D5C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:94 offset1:95      // 00000007BEFC: D8DC5F5E 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:28 offset1:45      // 00000007BF04: D8DC2D1C 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:62 offset1:79      // 00000007BF0C: D8DC4F3E 4A000038
	s_waitcnt lgkmcnt(6)                                       // 00000007BF14: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000007BF18: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BF1C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000007BF20: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000007BF24: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000007BF28: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BF2C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000007BF30: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000007BF34: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000007BF38: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BF3C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000007BF40: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000007BF44: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000007BF48: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BF4C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000007BF50: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 00000007BF54: D8DC6160 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:96 offset1:113     // 00000007BF5C: D8DC7160 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:98 offset1:99      // 00000007BF64: D8DC6362 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:130 offset1:147    // 00000007BF6C: D8DC9382 42000038
	ds_load_2addr_b32 v[68:69], v46 offset0:100 offset1:101    // 00000007BF74: D8DC6564 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:102 offset1:103    // 00000007BF7C: D8DC6766 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 00000007BF84: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 00000007BF8C: D8DCD7C6 4A000038
	s_waitcnt lgkmcnt(6)                                       // 00000007BF94: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000007BF98: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BF9C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000007BFA0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000007BFA4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000007BFA8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BFAC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000007BFB0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000007BFB4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000007BFB8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BFBC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000007BFC0: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000007BFC4: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000007BFC8: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BFCC: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000007BFD0: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:104 offset1:105    // 00000007BFD4: D8DC6968 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:232 offset1:249    // 00000007BFDC: D8DCF9E8 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 00000007BFE4: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:10 offset1:27      // 00000007BFEC: D8DC1B0A 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:108 offset1:109    // 00000007BFF4: D8DC6D6C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:110 offset1:111    // 00000007BFFC: D8DC6F6E 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:44 offset1:61      // 00000007C004: D8DC3D2C 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:78 offset1:95      // 00000007C00C: D8DC5F4E 4A000039
	s_waitcnt lgkmcnt(6)                                       // 00000007C014: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000007C018: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007C01C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000007C020: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000007C024: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000007C028: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007C02C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000007C030: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000007C034: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000007C038: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007C03C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000007C040: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000007C044: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000007C048: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007C04C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000007C050: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:112 offset1:113    // 00000007C054: D8DC7170 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:112 offset1:129    // 00000007C05C: D8DC8170 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:114 offset1:115    // 00000007C064: D8DC7372 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:146 offset1:163    // 00000007C06C: D8DCA392 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:116 offset1:117    // 00000007C074: D8DC7574 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:118 offset1:119    // 00000007C07C: D8DC7776 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 00000007C084: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 00000007C08C: D8DCE7D6 4A000039
	s_waitcnt lgkmcnt(6)                                       // 00000007C094: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000007C098: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007C09C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000007C0A0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000007C0A4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000007C0A8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007C0AC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000007C0B0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000007C0B4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000007C0B8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007C0BC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000007C0C0: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000007C0C4: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000007C0C8: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007C0CC: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000007C0D0: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 00000007C0D4: D8DC7978 3C00002E
	ds_load_2addr_b32 v[62:63], v58 offset0:120 offset1:137    // 00000007C0DC: D8DC8978 3E00003A
	ds_load_2addr_b32 v[64:65], v46 offset0:122 offset1:123    // 00000007C0E4: D8DC7B7A 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:26 offset1:43      // 00000007C0EC: D8DC2B1A 4200003B
	ds_load_2addr_b32 v[68:69], v46 offset0:124 offset1:125    // 00000007C0F4: D8DC7D7C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:126 offset1:127    // 00000007C0FC: D8DC7F7E 4600002E
	ds_load_2addr_b32 v[72:73], v59 offset0:60 offset1:77      // 00000007C104: D8DC4D3C 4800003B
	ds_load_2addr_b32 v[74:75], v59 offset0:94 offset1:111     // 00000007C10C: D8DC6F5E 4A00003B
	v_lshlrev_b32_e32 v33, 2, v33                              // 00000007C114: 30424282
	s_waitcnt lgkmcnt(6)                                       // 00000007C118: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000007C11C: 56987D3C
	ds_load_b32 v60, v33 offset:17440                          // 00000007C120: D8D84420 3C000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 00000007C128: CA10011E 2220011D
	v_mov_b32_e32 v62, v35                                     // 00000007C130: 7E7C0323
	v_fmac_f32_e32 v76, v61, v63                               // 00000007C134: 56987F3D
	v_mov_b32_e32 v61, v1                                      // 00000007C138: 7E7A0301
	s_waitcnt lgkmcnt(5)                                       // 00000007C13C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C140: BF870092
	v_fmac_f32_e32 v76, v64, v66                               // 00000007C144: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 00000007C148: 56988741
	s_waitcnt lgkmcnt(2)                                       // 00000007C14C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C150: BF870091
	v_fmac_f32_e32 v76, v68, v72                               // 00000007C154: 56989144
	v_fmac_f32_e32 v76, v69, v73                               // 00000007C158: 56989345
	s_waitcnt lgkmcnt(1)                                       // 00000007C15C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C160: BF870091
	v_fmac_f32_e32 v76, v70, v74                               // 00000007C164: 56989546
	v_fmac_f32_e32 v76, v71, v75                               // 00000007C168: 56989747
	s_waitcnt lgkmcnt(0)                                       // 00000007C16C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007C170: BF870001
	v_mul_f32_e32 v60, v76, v60                                // 00000007C174: 1078794C
	s_nop 0                                                    // 00000007C178: BF800000
	s_nop 0                                                    // 00000007C17C: BF800000
	global_load_b32 v63, v[33:34], off                         // 00000007C180: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 00000007C188: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 00000007C190: 4A7C7CC1
	.long 0xd7000121                                           // 00000007C194: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 00000007C198: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007C19C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 00000007C1A0: D5207C22 00064480
	.long 0xd44a0004                                           // 00000007C1A8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 00000007C1AC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 00000007C1B0: 4A7A7AFF 00000044
	s_or_b32 s12, s4, s12                                      // 00000007C1B8: 8C0C0C04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007C1BC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 00000007C1C0: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 00000007C1C4: 917E0C7E
	s_cbranch_execnz 65517                                     // 00000007C1C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1280>
	s_or_b32 exec_lo, exec_lo, s12                             // 00000007C1CC: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C1D0: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 00000007C1D4: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 00000007C1DC: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 00000007C1E8: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 00000007C1F4: DC960000 007C2421
	s_branch 64906                                             // 00000007C1FC: BFA0FD8A <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x928>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 00000007C200: A201FF06 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 00000007C208: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000007C20C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 00000007C210: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 00000007C218: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 00000007C21C: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 00000007C224: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 00000007C22C: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000007C230: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 00000007C234: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 00000007C23C: A0010401
	s_mov_b32 s4, 0                                            // 00000007C240: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 00000007C244: BF87000A
	v_exp_f32_e32 v29, s1                                      // 00000007C248: 7E3A4A01
	s_cvt_i32_f32 s1, s7                                       // 00000007C24C: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 00000007C250: BF870585
	.long 0xd71c001d                                           // 00000007C254: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 00000007C258: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 00000007C25C: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 00000007C260: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000007C268: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 00000007C26C: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 00000007C274: 980180C1
	v_mov_b32_e32 v29, v37                                     // 00000007C278: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 00000007C27C: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 00000007C288: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 00000007C290: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007C298: BF870001
	.long 0xd4490001                                           // 00000007C29C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 00000007C2A0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 00000007C2A8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 00000007C2AC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 00000007C2B0: 1040411E
	ds_store_b32 v29, v32                                      // 00000007C2B4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 00000007C2BC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007C2C4: 917E047E
	s_cbranch_execnz 65519                                     // 00000007C2C8: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1388>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007C2CC: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 00000007C2D0: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 00000007C2D8: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 00000007C2E0: 7E420326
	s_mov_b32 s6, 0                                            // 00000007C2E4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007C2E8: BF89FC07
	s_barrier                                                  // 00000007C2EC: BFBD0000
	buffer_gl0_inv                                             // 00000007C2F0: E0AC0000 00000000
	s_nop 0                                                    // 00000007C2F8: BF800000
	s_nop 0                                                    // 00000007C2FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000007C300: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 00000007C308: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000007C310: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000007C318: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007C31C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 00000007C324: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007C328: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007C330: BF870004
	.long 0xd4490004                                           // 00000007C334: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000007C338: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007C340: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007C344: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000007C348: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 00000007C34C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 00000007C354: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007C35C: 917E067E
	s_cbranch_execnz 65511                                     // 00000007C360: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1400>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007C364: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000007C368: BF89FC07
	s_barrier                                                  // 00000007C36C: BFBD0000
	buffer_gl0_inv                                             // 00000007C370: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 00000007C378: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 00000007C380: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 00000007C388: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 00000007C390: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 00000007C398: 7E780300
	s_mov_b32 s4, 0                                            // 00000007C39C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000007C3A0: BF840001
	s_nop 0                                                    // 00000007C3A4: BF800000
	s_nop 0                                                    // 00000007C3A8: BF800000
	s_nop 0                                                    // 00000007C3AC: BF800000
	s_nop 0                                                    // 00000007C3B0: BF800000
	s_nop 0                                                    // 00000007C3B4: BF800000
	s_nop 0                                                    // 00000007C3B8: BF800000
	s_nop 0                                                    // 00000007C3BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C3C0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000007C3C4: 327A7884
	.long 0xd4490001                                           // 00000007C3C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000007C3CC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000007C3D4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000007C3D8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007C3E4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000007C3E8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000007C3F0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000007C3F8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000007C400: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000007C408: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000007C410: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000007C418: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000007C420: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000007C424: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007C430: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000007C434: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000007C438: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000007C440: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000007C444: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000007C448: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000007C44C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C450: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000007C454: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000007C458: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000007C45C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C460: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000007C464: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000007C470: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000007C478: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007C480: 917E047E
	s_cbranch_execnz 65486                                     // 00000007C484: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14c0>
	s_set_inst_prefetch_distance 0x2                           // 00000007C488: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007C48C: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 00000007C490: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000007C498: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000007C4A0: 7E420326
	s_mov_b32 s6, 0                                            // 00000007C4A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007C4A8: BF89FC07
	s_barrier                                                  // 00000007C4AC: BFBD0000
	buffer_gl0_inv                                             // 00000007C4B0: E0AC0000 00000000
	s_nop 0                                                    // 00000007C4B8: BF800000
	s_nop 0                                                    // 00000007C4BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000007C4C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 00000007C4C8: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000007C4D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000007C4D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007C4DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000007C4E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007C4E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007C4F0: BF870004
	.long 0xd4490004                                           // 00000007C4F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000007C4F8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007C500: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007C504: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000007C508: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007C50C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000007C514: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007C51C: 917E067E
	s_cbranch_execnz 65511                                     // 00000007C520: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007C524: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000007C528: BF89FC07
	s_barrier                                                  // 00000007C52C: BFBD0000
	buffer_gl0_inv                                             // 00000007C530: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 00000007C538: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 00000007C540: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 00000007C548: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 00000007C550: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 00000007C558: 7E780300
	s_mov_b32 s4, 0                                            // 00000007C55C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000007C560: BF840001
	s_nop 0                                                    // 00000007C564: BF800000
	s_nop 0                                                    // 00000007C568: BF800000
	s_nop 0                                                    // 00000007C56C: BF800000
	s_nop 0                                                    // 00000007C570: BF800000
	s_nop 0                                                    // 00000007C574: BF800000
	s_nop 0                                                    // 00000007C578: BF800000
	s_nop 0                                                    // 00000007C57C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C580: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000007C584: 327A7884
	.long 0xd4490001                                           // 00000007C588: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000007C58C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000007C594: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000007C598: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007C5A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000007C5A8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000007C5B0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000007C5B8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000007C5C0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000007C5C8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000007C5D0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000007C5D8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000007C5E0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000007C5E4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007C5F0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000007C5F4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000007C5F8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000007C600: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000007C604: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000007C608: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000007C60C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C610: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000007C614: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000007C618: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000007C61C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C620: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000007C624: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000007C630: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000007C638: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007C640: 917E047E
	s_cbranch_execnz 65486                                     // 00000007C644: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1680>
	s_set_inst_prefetch_distance 0x2                           // 00000007C648: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007C64C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 00000007C650: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000007C658: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000007C660: 7E420326
	s_mov_b32 s6, 0                                            // 00000007C664: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007C668: BF89FC07
	s_barrier                                                  // 00000007C66C: BFBD0000
	buffer_gl0_inv                                             // 00000007C670: E0AC0000 00000000
	s_nop 0                                                    // 00000007C678: BF800000
	s_nop 0                                                    // 00000007C67C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000007C680: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 00000007C688: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000007C690: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000007C698: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007C69C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000007C6A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007C6A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007C6B0: BF870004
	.long 0xd4490004                                           // 00000007C6B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000007C6B8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007C6C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007C6C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000007C6C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007C6CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000007C6D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007C6DC: 917E067E
	s_cbranch_execnz 65511                                     // 00000007C6E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1780>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007C6E4: 8C7E067E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 00000007C6E8: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 00000007C6F0: BF89FC07
	s_barrier                                                  // 00000007C6F4: BFBD0000
	buffer_gl0_inv                                             // 00000007C6F8: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 00000007C700: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 00000007C704: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 00000007C70C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 00000007C714: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 00000007C71C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 00000007C724: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000007C728: BF840001
	s_nop 0                                                    // 00000007C72C: BF800000
	s_nop 0                                                    // 00000007C730: BF800000
	s_nop 0                                                    // 00000007C734: BF800000
	s_nop 0                                                    // 00000007C738: BF800000
	s_nop 0                                                    // 00000007C73C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 00000007C740: 327C7A84
	.long 0xd4490001                                           // 00000007C744: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000007C748: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007C750: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000007C754: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000007C758: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007C764: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000007C768: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000007C770: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000007C778: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000007C780: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000007C788: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000007C790: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000007C798: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000007C7A0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000007C7A4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007C7A8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000007C7AC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000007C7B8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000007C7C0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000007C7C4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000007C7C8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000007C7CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C7D0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000007C7D4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000007C7D8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000007C7DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C7E0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 00000007C7E4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 00000007C7F0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 00000007C7F8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007C800: 917E047E
	s_cbranch_execnz 65486                                     // 00000007C804: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1840>
	s_set_inst_prefetch_distance 0x2                           // 00000007C808: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007C80C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 00000007C810: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000007C818: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000007C820: 7E420326
	s_mov_b32 s6, 0                                            // 00000007C824: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007C828: BF89FC07
	s_barrier                                                  // 00000007C82C: BFBD0000
	buffer_gl0_inv                                             // 00000007C830: E0AC0000 00000000
	s_nop 0                                                    // 00000007C838: BF800000
	s_nop 0                                                    // 00000007C83C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000007C840: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 00000007C848: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000007C850: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000007C858: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007C85C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000007C864: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007C868: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007C870: BF870004
	.long 0xd4490004                                           // 00000007C874: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000007C878: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007C880: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007C884: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000007C888: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007C88C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000007C894: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007C89C: 917E067E
	s_cbranch_execnz 65511                                     // 00000007C8A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1940>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007C8A4: 8C7E067E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 00000007C8A8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 00000007C8B0: BF89FC07
	s_barrier                                                  // 00000007C8B4: BFBD0000
	buffer_gl0_inv                                             // 00000007C8B8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 00000007C8C0: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 00000007C8C8: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 00000007C8D0: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 00000007C8D8: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 00000007C8E0: 7E780300
	s_mov_b32 s4, 0                                            // 00000007C8E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000007C8E8: BF840001
	s_nop 0                                                    // 00000007C8EC: BF800000
	s_nop 0                                                    // 00000007C8F0: BF800000
	s_nop 0                                                    // 00000007C8F4: BF800000
	s_nop 0                                                    // 00000007C8F8: BF800000
	s_nop 0                                                    // 00000007C8FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C900: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000007C904: 327A7884
	.long 0xd4490001                                           // 00000007C908: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000007C90C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000007C914: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000007C918: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007C924: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000007C928: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000007C930: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000007C938: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000007C940: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000007C948: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000007C950: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000007C958: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000007C960: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000007C964: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007C970: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000007C974: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000007C978: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000007C980: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000007C984: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000007C988: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000007C98C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C990: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000007C994: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000007C998: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000007C99C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C9A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000007C9A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000007C9B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000007C9B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007C9C0: 917E047E
	s_cbranch_execnz 65486                                     // 00000007C9C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a00>
	s_set_inst_prefetch_distance 0x2                           // 00000007C9C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007C9CC: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 00000007C9D0: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000007C9D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000007C9E0: 7E420326
	s_mov_b32 s6, 0                                            // 00000007C9E4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007C9E8: BF89FC07
	s_barrier                                                  // 00000007C9EC: BFBD0000
	buffer_gl0_inv                                             // 00000007C9F0: E0AC0000 00000000
	s_nop 0                                                    // 00000007C9F8: BF800000
	s_nop 0                                                    // 00000007C9FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000007CA00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 00000007CA08: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000007CA10: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000007CA18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007CA1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000007CA24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007CA28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007CA30: BF870004
	.long 0xd4490004                                           // 00000007CA34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000007CA38: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007CA40: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007CA44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000007CA48: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007CA4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000007CA54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007CA5C: 917E067E
	s_cbranch_execnz 65511                                     // 00000007CA60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b00>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007CA64: 8C7E067E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 00000007CA68: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 00000007CA70: BF89FC07
	s_barrier                                                  // 00000007CA74: BFBD0000
	buffer_gl0_inv                                             // 00000007CA78: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 00000007CA80: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 00000007CA84: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 00000007CA8C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 00000007CA94: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 00000007CA9C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 00000007CAA4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000007CAA8: BF840001
	s_nop 0                                                    // 00000007CAAC: BF800000
	s_nop 0                                                    // 00000007CAB0: BF800000
	s_nop 0                                                    // 00000007CAB4: BF800000
	s_nop 0                                                    // 00000007CAB8: BF800000
	s_nop 0                                                    // 00000007CABC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 00000007CAC0: 327C7884
	.long 0xd4490001                                           // 00000007CAC4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000007CAC8: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007CAD0: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000007CAD4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000007CAD8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007CAE4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000007CAE8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000007CAF0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000007CAF8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000007CB00: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000007CB08: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000007CB10: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000007CB18: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000007CB20: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000007CB24: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007CB28: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000007CB2C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000007CB38: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000007CB40: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000007CB44: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000007CB48: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000007CB4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007CB50: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000007CB54: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000007CB58: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000007CB5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007CB60: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 00000007CB64: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 00000007CB70: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007CB74: BF870002
	v_mov_b32_e32 v60, v63                                     // 00000007CB78: 7E78033F
	ds_store_b32 v62, v70                                      // 00000007CB7C: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007CB84: 917E047E
	s_cbranch_execnz 65485                                     // 00000007CB88: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1bc0>
	s_set_inst_prefetch_distance 0x2                           // 00000007CB8C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007CB90: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 00000007CB94: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000007CB9C: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000007CBA4: 7E420326
	s_mov_b32 s6, 0                                            // 00000007CBA8: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007CBAC: BF89FC07
	s_barrier                                                  // 00000007CBB0: BFBD0000
	buffer_gl0_inv                                             // 00000007CBB4: E0AC0000 00000000
	s_nop 0                                                    // 00000007CBBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000007CBC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 00000007CBC8: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000007CBD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000007CBD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007CBDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000007CBE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007CBE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007CBF0: BF870004
	.long 0xd4490004                                           // 00000007CBF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000007CBF8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007CC00: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007CC04: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000007CC08: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007CC0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000007CC14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007CC1C: 917E067E
	s_cbranch_execnz 65511                                     // 00000007CC20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007CC24: 8C7E067E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 00000007CC28: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 00000007CC30: BF89FC07
	s_barrier                                                  // 00000007CC34: BFBD0000
	buffer_gl0_inv                                             // 00000007CC38: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 00000007CC40: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 00000007CC48: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 00000007CC50: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 00000007CC58: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 00000007CC60: 7E7A0300
	s_mov_b32 s4, 0                                            // 00000007CC64: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000007CC68: BF840001
	s_nop 0                                                    // 00000007CC6C: BF800000
	s_nop 0                                                    // 00000007CC70: BF800000
	s_nop 0                                                    // 00000007CC74: BF800000
	s_nop 0                                                    // 00000007CC78: BF800000
	s_nop 0                                                    // 00000007CC7C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007CC80: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 00000007CC84: 327C7A84
	.long 0xd4490001                                           // 00000007CC88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000007CC8C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000007CC94: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000007CC98: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007CCA4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000007CCA8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000007CCB0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000007CCB8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000007CCC0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000007CCC8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000007CCD0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000007CCD8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000007CCE0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000007CCE4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007CCE8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000007CCEC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000007CCF8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000007CD00: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000007CD04: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000007CD08: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000007CD0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007CD10: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000007CD14: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000007CD18: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000007CD1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007CD20: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 00000007CD24: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 00000007CD30: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 00000007CD38: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007CD40: 917E047E
	s_cbranch_execnz 65486                                     // 00000007CD44: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d80>
	s_set_inst_prefetch_distance 0x2                           // 00000007CD48: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007CD4C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 00000007CD50: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000007CD58: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000007CD60: 7E420326
	s_mov_b32 s6, 0                                            // 00000007CD64: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007CD68: BF89FC07
	s_barrier                                                  // 00000007CD6C: BFBD0000
	buffer_gl0_inv                                             // 00000007CD70: E0AC0000 00000000
	s_nop 0                                                    // 00000007CD78: BF800000
	s_nop 0                                                    // 00000007CD7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000007CD80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 00000007CD88: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000007CD90: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000007CD98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007CD9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000007CDA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007CDA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007CDB0: BF870004
	.long 0xd4490004                                           // 00000007CDB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000007CDB8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007CDC0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007CDC4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000007CDC8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007CDCC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000007CDD4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007CDDC: 917E067E
	s_cbranch_execnz 65511                                     // 00000007CDE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e80>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007CDE4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000007CDE8: BF89FC07
	s_barrier                                                  // 00000007CDEC: BFBD0000
	buffer_gl0_inv                                             // 00000007CDF0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 00000007CDF8: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 00000007CE00: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 00000007CE08: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 00000007CE10: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 00000007CE18: 7E7A0300
	s_mov_b32 s4, 0                                            // 00000007CE1C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000007CE20: BF840001
	s_nop 0                                                    // 00000007CE24: BF800000
	s_nop 0                                                    // 00000007CE28: BF800000
	s_nop 0                                                    // 00000007CE2C: BF800000
	s_nop 0                                                    // 00000007CE30: BF800000
	s_nop 0                                                    // 00000007CE34: BF800000
	s_nop 0                                                    // 00000007CE38: BF800000
	s_nop 0                                                    // 00000007CE3C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007CE40: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 00000007CE44: 327C7A84
	.long 0xd4490001                                           // 00000007CE48: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000007CE4C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000007CE54: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000007CE58: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007CE64: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000007CE68: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000007CE70: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000007CE78: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000007CE80: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000007CE88: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000007CE90: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000007CE98: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000007CEA0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000007CEA4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007CEA8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000007CEAC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000007CEB8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000007CEC0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000007CEC4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000007CEC8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000007CECC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007CED0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000007CED4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000007CED8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000007CEDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007CEE0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 00000007CEE4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 00000007CEF0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 00000007CEF8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007CF00: 917E047E
	s_cbranch_execnz 65486                                     // 00000007CF04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f40>
	s_set_inst_prefetch_distance 0x2                           // 00000007CF08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007CF0C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 00000007CF10: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000007CF18: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000007CF20: 7E420326
	s_mov_b32 s6, 0                                            // 00000007CF24: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000007CF28: BF89FC07
	s_barrier                                                  // 00000007CF2C: BFBD0000
	buffer_gl0_inv                                             // 00000007CF30: E0AC0000 00000000
	s_nop 0                                                    // 00000007CF38: BF800000
	s_nop 0                                                    // 00000007CF3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000007CF40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 00000007CF48: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000007CF50: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000007CF58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007CF5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000007CF64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007CF68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007CF70: BF870004
	.long 0xd4490004                                           // 00000007CF74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000007CF78: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000007CF80: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007CF84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000007CF88: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007CF8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000007CF94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007CF9C: 917E067E
	s_cbranch_execnz 65511                                     // 00000007CFA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007CFA4: 8C7E067E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 00000007CFA8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 00000007CFB0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 00000007CFB8: BF89FC07
	s_barrier                                                  // 00000007CFBC: BFBD0000
	buffer_gl0_inv                                             // 00000007CFC0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 00000007CFC8: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 00000007CFD0: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 00000007CFD8: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 00000007CFE0: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 00000007CFE8: 7E780300
	s_mov_b32 s4, 0                                            // 00000007CFEC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000007CFF0: BF840001
	s_nop 0                                                    // 00000007CFF4: BF800000
	s_nop 0                                                    // 00000007CFF8: BF800000
	s_nop 0                                                    // 00000007CFFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007D000: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000007D004: 327A7884
	.long 0xd4490001                                           // 00000007D008: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000007D00C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000007D014: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000007D018: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000007D024: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000007D028: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000007D030: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000007D038: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000007D040: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000007D048: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000007D050: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000007D058: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000007D060: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000007D064: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007D070: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000007D074: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000007D078: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000007D080: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000007D084: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000007D088: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000007D08C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D090: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000007D094: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000007D098: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000007D09C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D0A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000007D0A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000007D0B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000007D0B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007D0C0: 917E047E
	s_cbranch_execnz 65486                                     // 00000007D0C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2100>
	s_set_inst_prefetch_distance 0x2                           // 00000007D0C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007D0CC: 8C7E047E
	.long 0xd7000107                                           // 00000007D0D0: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 00000007D0D4: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007D0DC: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 00000007D0E0: D5207C08 00061080
	.long 0xd7000109                                           // 00000007D0E8: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 00000007D0EC: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 00000007D0F4: D5207C0A 00061480
	.long 0xd700010d                                           // 00000007D0FC: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 00000007D100: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007D108: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 00000007D10C: D5207C0E 00061C80
	.long 0xd700010b                                           // 00000007D114: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 00000007D118: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 00000007D120: D5207C0C 00061880
	.long 0xd700010f                                           // 00000007D128: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 00000007D12C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007D134: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 00000007D138: D5207C10 00062080
	.long 0xd7000111                                           // 00000007D140: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 00000007D144: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 00000007D14C: D5207C12 00062480
	.long 0xd7000113                                           // 00000007D154: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 00000007D158: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007D160: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 00000007D164: D5207C14 00062880
	.long 0xd7000115                                           // 00000007D16C: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 00000007D170: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 00000007D178: D5207C16 00062C80
	.long 0xd7000117                                           // 00000007D180: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 00000007D184: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007D18C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 00000007D190: D5207C18 00063080
	.long 0xd7000119                                           // 00000007D198: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 00000007D19C: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 00000007D1A4: D5207C1A 00063480
	.long 0xd700011b                                           // 00000007D1AC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 00000007D1B0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007D1B8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 00000007D1BC: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 00000007D1C4: 81058105
	s_waitcnt lgkmcnt(0)                                       // 00000007D1C8: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 00000007D1CC: BF062105
	s_barrier                                                  // 00000007D1D0: BFBD0000
	buffer_gl0_inv                                             // 00000007D1D4: E0AC0000 00000000
	s_cbranch_scc0 63537                                       // 00000007D1DC: BFA1F831 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a4>
	v_mov_b32_e32 v4, v38                                      // 00000007D1E0: 7E080326
	s_add_u32 s0, s28, s20                                     // 00000007D1E4: 8000141C
	.long 0xd73c0000                                           // 00000007D1E8: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000007D1EC: 02020489
	s_addc_u32 s1, s29, s21                                    // 00000007D1F0: 8201151D
	s_add_u32 s2, s24, s18                                     // 00000007D1F4: 80021218
	s_addc_u32 s3, s25, s19                                    // 00000007D1F8: 82031319
	s_add_u32 s0, s2, s0                                       // 00000007D1FC: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000007D200: 82010103
	.long 0xd7006a00                                           // 00000007D204: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000007D208: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000007D20C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000007D210: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 00000007D218: BE810080
	.long 0xd7006a00                                           // 00000007D21C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 00000007D220: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000007D224: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D22C: BF870092
	.long 0xd7006a00                                           // 00000007D230: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000007D234: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000007D238: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 00000007D240: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 00000007D248: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 00000007D250: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000007D258: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000007D25C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 00000007D264: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000007D268: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 00000007D26C: DC6A0000 007C0200
	.long 0xd7000000                                           // 00000007D274: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 00000007D278: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000007D280: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000007D288: 917E017E
	s_cbranch_execnz 65516                                     // 00000007D28C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2340>
	s_endpgm                                                   // 00000007D290: BFB00000
		...

