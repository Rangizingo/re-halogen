0000000000228c00 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi8EEEvPKfS3_S3_Pfi>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi8EEEvPKfS3_S3_Pfi():
	s_load_b256 s[4:11], s[0:1], null                          // 000000228C00: F40C0100 F8000000
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v1, 0x7f, v0       // 000000228C08: CA240100 040000FF 0000007F
	s_and_b32 s16, s2, 0xf8000001                              // 000000228C14: 8B10FF02 F8000001
	s_lshr_b32 s15, s2, 1                                      // 000000228C1C: 850F8102
	s_lshl_b32 s14, s16, 5                                     // 000000228C20: 840E8510
	s_delay_alu instid0(VALU_DEP_1)                            // 000000228C24: BF870001
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000228C28: 30020282
	s_lshl_b32 s1, s15, 6                                      // 000000228C2C: 8401860F
	s_mov_b32 s12, s3                                          // 000000228C30: BE8C0003
	s_ashr_i32 s13, s3, 31                                     // 000000228C34: 860D9F03
	s_mov_b32 s2, 0                                            // 000000228C38: BE820080
	s_waitcnt lgkmcnt(0)                                       // 000000228C3C: BF89FC07
	.long 0xd7000002                                           // 000000228C40: D7000002
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 000000228C44: 02020206
	s_delay_alu instid0(VALU_DEP_1)                            // 000000228C48: BF870001
	v_add_co_ci_u32_e64 v3, null, s7, 0, s0                    // 000000228C4C: D5207C03 00010007
	s_or_b32 s0, s1, s14                                       // 000000228C54: 8C000E01
	s_nop 0                                                    // 000000228C58: BF800000
	s_nop 0                                                    // 000000228C5C: BF800000
	s_nop 0                                                    // 000000228C60: BF800000
	s_nop 0                                                    // 000000228C64: BF800000
	s_nop 0                                                    // 000000228C68: BF800000
	s_nop 0                                                    // 000000228C6C: BF800000
	s_nop 0                                                    // 000000228C70: BF800000
	s_nop 0                                                    // 000000228C74: BF800000
	s_nop 0                                                    // 000000228C78: BF800000
	s_nop 0                                                    // 000000228C7C: BF800000
	v_lshrrev_b32_e32 v7, 7, v4                                // 000000228C80: 320E0887
	v_add_nc_u32_e32 v9, 0x100, v4                             // 000000228C84: 4A1208FF 00000100
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228C8C: BF870092
	v_or_b32_e32 v5, s0, v7                                    // 000000228C90: 380A0E00
	v_mad_u64_u32 v[5:6], null, v5, 48, s[12:13]               // 000000228C94: D6FE7C05 00316105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228C9C: BF870091
	.long 0xd73c0005                                           // 000000228CA0: D73C0005
	v_cndmask_b32_e32 v1, 9, v5, vcc_lo                        // 000000228CA4: 02020A89
	.long 0xd7006a05                                           // 000000228CA8: D7006A05
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 000000228CAC: 02020B02
	s_delay_alu instid0(VALU_DEP_1)                            // 000000228CB0: BF870001
	v_add_co_ci_u32_e64 v6, null, v3, v6, vcc_lo               // 000000228CB4: D5207C06 01AA0D03
	v_cmp_lt_u32_e32 vcc_lo, 0xeff, v4                         // 000000228CBC: 7C9208FF 00000EFF
	v_mov_b32_e32 v4, v9                                       // 000000228CC4: 7E080309
	global_load_b32 v8, v[5:6], off                            // 000000228CC8: DC520000 087C0005
	v_mad_u64_u32 v[5:6], null, 0x204, v7, v[1:2]              // 000000228CD0: D6FE7C05 04060EFF 00000204
	s_or_b32 s2, vcc_lo, s2                                    // 000000228CDC: 8C02026A
	s_waitcnt vmcnt(0)                                         // 000000228CE0: BF8903F7
	ds_store_b32 v5, v8                                        // 000000228CE4: D8340000 00000805
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 000000228CEC: 917E027E
	s_cbranch_execnz 65507                                     // 000000228CF0: BFA6FFE3 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi8EEEvPKfS3_S3_Pfi+0x80>
	s_or_b32 exec_lo, exec_lo, s2                              // 000000228CF4: 8C7E027E
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000228CF8: 30020082
	s_mov_b32 s2, exec_lo                                      // 000000228CFC: BE82007E
	v_cmpx_gt_u32_e32 64, v0                                   // 000000228D00: 7D9800C0
	s_cbranch_execz 16                                         // 000000228D04: BFA50010 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi8EEEvPKfS3_S3_Pfi+0x148>
	v_or_b32_e32 v2, s1, v0                                    // 000000228D08: 38040001
	s_lshl_b64 s[6:7], s[12:13], 2                             // 000000228D0C: 8486820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228D10: BF870091
	v_mad_u64_u32 v[2:3], null, 0xc0, v2, s[8:9]               // 000000228D14: D6FE7C02 002204FF 000000C0
	.long 0xd7006a02                                           // 000000228D20: D7006A02
	v_cndmask_b32_e32 v0, v2, v6, vcc_lo                       // 000000228D24: 02000D02
	s_delay_alu instid0(VALU_DEP_1)                            // 000000228D28: BF870001
	v_add_co_ci_u32_e64 v3, null, s7, v3, vcc_lo               // 000000228D2C: D5207C03 01AA0607
	global_load_b32 v2, v[2:3], off                            // 000000228D34: DC520000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000228D3C: BF8903F7
	ds_store_b32 v1, v2 offset:16512                           // 000000228D40: D8344080 00000201
	s_or_b32 exec_lo, exec_lo, s2                              // 000000228D48: 8C7E027E
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000228D4C: 32040082
	s_sub_i32 s1, 64, s14                                      // 000000228D50: 81810EC0
	s_mov_b32 s6, exec_lo                                      // 000000228D54: BE86007E
	s_waitcnt lgkmcnt(0)                                       // 000000228D58: BF89FC07
	s_barrier                                                  // 000000228D5C: BFBD0000
	v_and_b32_e32 v8, 56, v2                                   // 000000228D60: 361004B8
	buffer_gl0_inv                                             // 000000228D64: E0AC0000 00000000
	.long 0xd4cc007e                                           // 000000228D6C: D4CC007E
	v_cndmask_b32_e32 v1, s1, v8, vcc_lo                       // 000000228D70: 02021001
	s_cbranch_execz 579                                        // 000000228D74: BFA50243 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi8EEEvPKfS3_S3_Pfi+0xa84>
	v_dual_mov_b32 v13, 0 :: v_dual_add_nc_u32 v2, s0, v8      // 000000228D78: CA200080 0D021000
	v_dual_mov_b32 v12, 0 :: v_dual_and_b32 v9, 31, v0         // 000000228D80: CA240080 0C08009F
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 000000228D88: CA100080 07060080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000228D90: BF870193
	v_readfirstlane_b32 s2, v2                                 // 000000228D94: 7E040502
	v_mul_u32_u24_e32 v10, 0x204, v9                           // 000000228D98: 161412FF 00000204
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 000000228DA0: CA100080 05040080
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 000000228DA8: CA100080 03020080
	s_mul_i32 s0, s2, 48                                       // 000000228DB0: 9600B002
	s_mul_hi_u32 s1, s2, 48                                    // 000000228DB4: 9681B002
	s_add_u32 s0, s0, s12                                      // 000000228DB8: 80000C00
	s_addc_u32 s1, s1, s13                                     // 000000228DBC: 82010D01
	s_mul_i32 s3, s2, 0x6000                                   // 000000228DC0: 9603FF02 00006000
	s_lshl_b64 s[0:1], s[0:1], 9                               // 000000228DC8: 84808900
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000228DCC: BF870009
	s_add_u32 s7, s4, s0                                       // 000000228DD0: 80070004
	s_addc_u32 s8, s5, s1                                      // 000000228DD4: 82080105
	s_add_i32 s9, s2, 7                                        // 000000228DD8: 81098702
	s_add_i32 s17, s3, 0x2a000                                 // 000000228DDC: 8111FF03 0002A000
	s_lshl_b64 s[0:1], s[12:13], 9                             // 000000228DE4: 8480890C
	s_mul_hi_i32 s9, s9, 0x6000                                // 000000228DE8: 9709FF09 00006000
	s_add_u32 s17, s17, s0                                     // 000000228DF0: 80110011
	s_addc_u32 s18, s9, s1                                     // 000000228DF4: 82120109
	s_add_u32 s9, s4, s17                                      // 000000228DF8: 80091104
	s_addc_u32 s17, s5, s18                                    // 000000228DFC: 82111205
	s_add_i32 s18, s2, 6                                       // 000000228E00: 81128602
	s_add_i32 s19, s3, 0x24000                                 // 000000228E04: 8113FF03 00024000
	s_mul_hi_i32 s18, s18, 0x6000                              // 000000228E0C: 9712FF12 00006000
	s_add_u32 s19, s19, s0                                     // 000000228E14: 80130013
	s_addc_u32 s20, s18, s1                                    // 000000228E18: 82140112
	s_add_u32 s18, s4, s19                                     // 000000228E1C: 80121304
	s_addc_u32 s19, s5, s20                                    // 000000228E20: 82131405
	s_add_i32 s20, s2, 1                                       // 000000228E24: 81148102
	s_add_i32 s21, s3, 0x6000                                  // 000000228E28: 8115FF03 00006000
	s_mul_hi_i32 s20, s20, 0x6000                              // 000000228E30: 9714FF14 00006000
	s_add_u32 s21, s21, s0                                     // 000000228E38: 80150015
	s_addc_u32 s22, s20, s1                                    // 000000228E3C: 82160114
	s_add_u32 s20, s4, s21                                     // 000000228E40: 80141504
	s_addc_u32 s21, s5, s22                                    // 000000228E44: 82151605
	s_add_i32 s22, s2, 5                                       // 000000228E48: 81168502
	s_add_i32 s23, s3, 0x1e000                                 // 000000228E4C: 8117FF03 0001E000
	s_mul_hi_i32 s22, s22, 0x6000                              // 000000228E54: 9716FF16 00006000
	s_add_u32 s23, s23, s0                                     // 000000228E5C: 80170017
	s_addc_u32 s24, s22, s1                                    // 000000228E60: 82180116
	s_add_u32 s22, s4, s23                                     // 000000228E64: 80161704
	s_addc_u32 s23, s5, s24                                    // 000000228E68: 82171805
	s_add_i32 s24, s2, 2                                       // 000000228E6C: 81188202
	s_add_i32 s25, s3, 0xc000                                  // 000000228E70: 8119FF03 0000C000
	s_mul_hi_i32 s24, s24, 0x6000                              // 000000228E78: 9718FF18 00006000
	s_add_u32 s25, s25, s0                                     // 000000228E80: 80190019
	s_addc_u32 s26, s24, s1                                    // 000000228E84: 821A0118
	s_add_u32 s24, s4, s25                                     // 000000228E88: 80181904
	s_addc_u32 s25, s5, s26                                    // 000000228E8C: 82191A05
	s_add_i32 s26, s2, 4                                       // 000000228E90: 811A8402
	s_add_i32 s27, s3, 0x18000                                 // 000000228E94: 811BFF03 00018000
	s_mul_hi_i32 s26, s26, 0x6000                              // 000000228E9C: 971AFF1A 00006000
	s_add_u32 s27, s27, s0                                     // 000000228EA4: 801B001B
	s_addc_u32 s28, s26, s1                                    // 000000228EA8: 821C011A
	s_add_u32 s26, s4, s27                                     // 000000228EAC: 801A1B04
	s_addc_u32 s27, s5, s28                                    // 000000228EB0: 821B1C05
	s_add_i32 s2, s2, 3                                        // 000000228EB4: 81028302
	s_add_i32 s3, s3, 0x12000                                  // 000000228EB8: 8103FF03 00012000
	s_mul_hi_i32 s2, s2, 0x6000                                // 000000228EC0: 9702FF02 00006000
	s_add_u32 s0, s3, s0                                       // 000000228EC8: 80000003
	s_addc_u32 s1, s2, s1                                      // 000000228ECC: 82010102
	s_add_u32 s4, s4, s0                                       // 000000228ED0: 80040004
	s_addc_u32 s5, s5, s1                                      // 000000228ED4: 82050105
	s_mov_b64 s[0:1], 0                                        // 000000228ED8: BE800180
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000228EDC: BF870009
	s_add_u32 s2, s7, s0                                       // 000000228EE0: 80020007
	s_addc_u32 s3, s8, s1                                      // 000000228EE4: 82030108
	s_add_u32 s34, s20, s0                                     // 000000228EE8: 80220014
	s_addc_u32 s35, s21, s1                                    // 000000228EEC: 82230115
	s_clause 0x1                                               // 000000228EF0: BF850001
	s_load_b128 s[28:31], s[2:3], null                         // 000000228EF4: F4080701 F8000000
	s_load_b128 s[36:39], s[34:35], null                       // 000000228EFC: F4080911 F8000000
	s_add_u32 s2, s24, s0                                      // 000000228F04: 80020018
	s_addc_u32 s3, s25, s1                                     // 000000228F08: 82030119
	s_add_u32 s34, s4, s0                                      // 000000228F0C: 80220004
	s_addc_u32 s35, s5, s1                                     // 000000228F10: 82230105
	s_clause 0x1                                               // 000000228F14: BF850001
	s_load_b128 s[40:43], s[2:3], null                         // 000000228F18: F4080A01 F8000000
	s_load_b128 s[44:47], s[34:35], null                       // 000000228F20: F4080B11 F8000000
	ds_load_2addr_b32 v[14:15], v10 offset1:1                  // 000000228F28: D8DC0100 0E00000A
	ds_load_2addr_b32 v[16:17], v10 offset0:2 offset1:3        // 000000228F30: D8DC0302 1000000A
	s_add_u32 s2, s26, s0                                      // 000000228F38: 8002001A
	s_addc_u32 s3, s27, s1                                     // 000000228F3C: 8203011B
	s_add_u32 s34, s22, s0                                     // 000000228F40: 80220016
	s_addc_u32 s35, s23, s1                                    // 000000228F44: 82230117
	s_clause 0x1                                               // 000000228F48: BF850001
	s_load_b128 s[48:51], s[2:3], null                         // 000000228F4C: F4080C01 F8000000
	s_load_b128 s[52:55], s[34:35], null                       // 000000228F54: F4080D11 F8000000
	s_add_u32 s2, s18, s0                                      // 000000228F5C: 80020012
	s_addc_u32 s3, s19, s1                                     // 000000228F60: 82030113
	s_add_u32 s34, s9, s0                                      // 000000228F64: 80220009
	s_addc_u32 s35, s17, s1                                    // 000000228F68: 82230111
	s_clause 0x1                                               // 000000228F6C: BF850001
	s_load_b128 s[56:59], s[2:3], null                         // 000000228F70: F4080E01 F8000000
	s_load_b128 s[60:63], s[34:35], null                       // 000000228F78: F4080F11 F8000000
	s_add_u32 s0, s0, 16                                       // 000000228F80: 80009000
	s_addc_u32 s1, s1, 0                                       // 000000228F84: 82018001
	s_cmpk_eq_i32 s0, 0x200                                    // 000000228F88: B1800200
	s_waitcnt lgkmcnt(0)                                       // 000000228F8C: BF89FC07
	v_fmac_f32_e32 v6, s44, v14                                // 000000228F90: 560C1C2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000228F94: BF870091
	v_dual_fmac_f32 v7, s40, v14 :: v_dual_fmac_f32 v6, s45, v15// 000000228F98: C8001C28 07061E2D
	v_dual_fmac_f32 v12, s36, v14 :: v_dual_fmac_f32 v7, s41, v15// 000000228FA0: C8001C24 0C061E29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000228FA8: BF870112
	v_dual_fmac_f32 v13, s28, v14 :: v_dual_fmac_f32 v6, s46, v16// 000000228FAC: C8001C1C 0D06202E
	v_dual_fmac_f32 v12, s37, v15 :: v_dual_fmac_f32 v5, s48, v14// 000000228FB4: C8001E25 0C041C30
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000228FBC: BF870212
	v_dual_fmac_f32 v13, s29, v15 :: v_dual_add_nc_u32 v10, 16, v10// 000000228FC0: C8201E1D 0D0A1490
	v_dual_fmac_f32 v2, s60, v14 :: v_dual_fmac_f32 v7, s42, v16// 000000228FC8: C8001C3C 0206202A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000228FD0: BF870213
	v_fmac_f32_e32 v12, s38, v16                               // 000000228FD4: 56182026
	v_dual_fmac_f32 v4, s52, v14 :: v_dual_fmac_f32 v5, s49, v15// 000000228FD8: C8001C34 04041E31
	v_fmac_f32_e32 v3, s56, v14                                // 000000228FE0: 56061C38
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000228FE4: BF870194
	v_dual_fmac_f32 v13, s30, v16 :: v_dual_fmac_f32 v2, s61, v15// 000000228FE8: C800201E 0D021E3D
	v_fmac_f32_e32 v4, s53, v15                                // 000000228FF0: 56081E35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000228FF4: BF870193
	v_dual_fmac_f32 v12, s39, v17 :: v_dual_fmac_f32 v3, s57, v15// 000000228FF8: C8002227 0C021E39
	v_fmac_f32_e32 v13, s31, v17                               // 000000229000: 561A221F
	v_fmac_f32_e32 v5, s50, v16                                // 000000229004: 560A2032
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000229008: BF870214
	v_dual_fmac_f32 v7, s43, v17 :: v_dual_fmac_f32 v4, s54, v16// 00000022900C: C800222B 07042036
	v_dual_fmac_f32 v3, s58, v16 :: v_dual_fmac_f32 v6, s47, v17// 000000229014: C800203A 0306222F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000022901C: BF870193
	v_dual_fmac_f32 v2, s62, v16 :: v_dual_fmac_f32 v5, s51, v17// 000000229020: C800203E 02042233
	v_fmac_f32_e32 v4, s55, v17                                // 000000229028: 56082237
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000022902C: BF870193
	v_fmac_f32_e32 v3, s59, v17                                // 000000229030: 5606223B
	v_fmac_f32_e32 v2, s63, v17                                // 000000229034: 5604223F
	s_cbranch_scc0 65448                                       // 000000229038: BFA1FFA8 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi8EEEvPKfS3_S3_Pfi+0x2dc>
	v_or_b32_e32 v10, s14, v9                                  // 00000022903C: 3814120E
	v_dual_mov_b32 v16, 0 :: v_dual_add_nc_u32 v11, s14, v8    // 000000229040: CA200080 100A100E
	v_cmp_le_u32_e32 vcc_lo, v9, v8                            // 000000229048: 7C961109
	v_mov_b32_e32 v15, 0                                       // 00000022904C: 7E1E0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000229050: BF870214
	v_lshl_add_u32 v8, v10, 2, 0x4080                          // 000000229054: D6460008 03FD050A 00004080
	v_lshlrev_b32_e32 v9, 2, v11                               // 000000229060: 30121682
	s_and_saveexec_b32 s0, vcc_lo                              // 000000229064: BE80206A
	s_cbranch_execz 33                                         // 000000229068: BFA50021 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi8EEEvPKfS3_S3_Pfi+0x4f0>
	ds_load_b32 v14, v9 offset:16512                           // 00000022906C: D8D84080 0E000009
	ds_load_b32 v16, v8                                        // 000000229074: D8D80000 10000008
	s_waitcnt lgkmcnt(0)                                       // 00000022907C: BF89FC07
	v_sub_f32_e32 v14, v14, v16                                // 000000229080: 081C210E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000229084: BF870121
	v_mul_f32_e32 v16, 0x3fb8aa3b, v14                         // 000000229088: 10201CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v14                  // 000000229090: 7C361CFF C2CE8ED0
	v_fma_f32 v17, 0x3fb8aa3b, v14, -v16                       // 000000229098: D6130011 84421CFF 3FB8AA3B
	v_rndne_f32_e32 v18, v16                                   // 0000002290A4: 7E244710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002290A8: BF870091
	v_dual_fmamk_f32 v17, v14, 0x32a5705f, v17 :: v_dual_sub_f32 v16, v16, v18// 0000002290AC: C88A230E 11102510 32A5705F
	v_add_f32_e32 v16, v16, v17                                // 0000002290B8: 06202310
	v_cvt_i32_f32_e32 v17, v18                                 // 0000002290BC: 7E221112
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002290C0: BF870292
	v_exp_f32_e32 v16, v16                                     // 0000002290C4: 7E204B10
	.long 0xd71c0010                                           // 0000002290C8: D71C0010
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                     // 0000002290CC: 02022310
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002290D0: BF870121
	v_cndmask_b32_e32 v16, 0, v16, vcc_lo                      // 0000002290D4: 02202080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v14                  // 0000002290D8: 7C3C1CFF 42B17218
	v_cndmask_b32_e32 v14, 0x7f800000, v16, vcc_lo             // 0000002290E0: 021C20FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002290E8: BF870001
	v_mul_f32_e32 v16, v13, v14                                // 0000002290EC: 10201D0D
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002290F0: 8C7E007E
	s_mul_i32 s0, s15, 48                                      // 0000002290F4: 9600B00F
	s_mul_hi_u32 s1, s15, 48                                   // 0000002290F8: 9681B00F
	s_add_u32 s0, s0, s12                                      // 0000002290FC: 80000C00
	s_addc_u32 s1, s1, s13                                     // 000000229100: 82010D01
	v_lshlrev_b32_e32 v13, 2, v10                              // 000000229104: 301A1482
	s_lshl_b64 s[0:1], s[0:1], 14                              // 000000229108: 84808E00
	v_lshlrev_b32_e32 v18, 8, v11                              // 00000022910C: 30241688
	s_add_u32 s0, s10, s0                                      // 000000229110: 8000000A
	s_addc_u32 s1, s11, s1                                     // 000000229114: 8201010B
	.long 0xd700000d                                           // 000000229118: D700000D
	v_cndmask_b32_e32 v1, s0, v13, vcc_lo                      // 00000022911C: 02021A00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000229120: BF8701A1
	v_add_co_ci_u32_e64 v14, null, s1, 0, s0                   // 000000229124: D5207C0E 00010001
	v_or_b32_e32 v17, 1, v11                                   // 00000022912C: 38221681
	.long 0xd7006a12                                           // 000000229130: D7006A12
	v_cndmask_b32_e32 v1, v13, v18, vcc_lo                     // 000000229134: 0202250D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000229138: BF870001
	v_add_co_ci_u32_e64 v19, null, 0, v14, vcc_lo              // 00000022913C: D5207C13 01AA1C80
	s_mov_b32 s0, exec_lo                                      // 000000229144: BE80007E
	global_store_b32 v[18:19], v16, off                        // 000000229148: DC6A0000 007C1012
	.long 0xd4cb007e                                           // 000000229150: D4CB007E
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 000000229154: 0202230A
	s_cbranch_execz 33                                         // 000000229158: BFA50021 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi8EEEvPKfS3_S3_Pfi+0x5e0>
	ds_load_b32 v15, v9 offset:16516                           // 00000022915C: D8D84084 0F000009
	ds_load_b32 v16, v8                                        // 000000229164: D8D80000 10000008
	s_waitcnt lgkmcnt(0)                                       // 00000022916C: BF89FC07
	v_sub_f32_e32 v15, v15, v16                                // 000000229170: 081E210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000229174: BF870091
	v_mul_f32_e32 v16, 0x3fb8aa3b, v15                         // 000000229178: 10201EFF 3FB8AA3B
	v_fma_f32 v18, 0x3fb8aa3b, v15, -v16                       // 000000229180: D6130012 84421EFF 3FB8AA3B
	v_rndne_f32_e32 v19, v16                                   // 00000022918C: 7E264710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000229190: BF870191
	v_sub_f32_e32 v16, v16, v19                                // 000000229194: 08202710
	v_fmamk_f32 v18, v15, 0x32a5705f, v18                      // 000000229198: 5824250F 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v15                  // 0000002291A0: 7C361EFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002291A8: BF870122
	v_add_f32_e32 v16, v16, v18                                // 0000002291AC: 06202510
	v_cvt_i32_f32_e32 v18, v19                                 // 0000002291B0: 7E241113
	v_exp_f32_e32 v16, v16                                     // 0000002291B4: 7E204B10
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002291B8: BF870095
	.long 0xd71c0010                                           // 0000002291BC: D71C0010
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 0000002291C0: 02022510
	v_cndmask_b32_e32 v16, 0, v16, vcc_lo                      // 0000002291C4: 02202080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v15                  // 0000002291C8: 7C3C1EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002291D0: BF870092
	v_cndmask_b32_e32 v15, 0x7f800000, v16, vcc_lo             // 0000002291D4: 021E20FF 7F800000
	v_mul_f32_e32 v15, v12, v15                                // 0000002291DC: 101E1F0C
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002291E0: 8C7E007E
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v17, 8, v17    // 0000002291E4: CA220080 0C102288
	v_or_b32_e32 v16, 2, v11                                   // 0000002291EC: 38201682
	s_mov_b32 s0, exec_lo                                      // 0000002291F0: BE80007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002291F4: BF870092
	.long 0xd7006a12                                           // 0000002291F8: D7006A12
	v_cndmask_b32_e32 v1, v13, v17, vcc_lo                     // 0000002291FC: 0202230D
	v_add_co_ci_u32_e64 v19, null, 0, v14, vcc_lo              // 000000229200: D5207C13 01AA1C80
	v_mov_b32_e32 v17, 0                                       // 000000229208: 7E220280
	global_store_b32 v[18:19], v15, off                        // 00000022920C: DC6A0000 007C0F12
	.long 0xd4cb007e                                           // 000000229214: D4CB007E
	v_cndmask_b32_e32 v1, v10, v16, vcc_lo                     // 000000229218: 0202210A
	s_cbranch_execz 33                                         // 00000022921C: BFA50021 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi8EEEvPKfS3_S3_Pfi+0x6a4>
	ds_load_b32 v15, v9 offset:16520                           // 000000229220: D8D84088 0F000009
	ds_load_b32 v17, v8                                        // 000000229228: D8D80000 11000008
	s_waitcnt lgkmcnt(0)                                       // 000000229230: BF89FC07
	v_sub_f32_e32 v15, v15, v17                                // 000000229234: 081E230F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000229238: BF870121
	v_mul_f32_e32 v17, 0x3fb8aa3b, v15                         // 00000022923C: 10221EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v15                  // 000000229244: 7C361EFF C2CE8ED0
	v_fma_f32 v18, 0x3fb8aa3b, v15, -v17                       // 00000022924C: D6130012 84461EFF 3FB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 000000229258: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022925C: BF870091
	v_dual_fmamk_f32 v18, v15, 0x32a5705f, v18 :: v_dual_sub_f32 v17, v17, v19// 000000229260: C88A250F 12102711 32A5705F
	v_add_f32_e32 v17, v17, v18                                // 00000022926C: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 000000229270: 7E241113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000229274: BF870292
	v_exp_f32_e32 v17, v17                                     // 000000229278: 7E224B11
	.long 0xd71c0011                                           // 00000022927C: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000229280: 02022511
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000229284: BF870121
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000229288: 02222280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v15                  // 00000022928C: 7C3C1EFF 42B17218
	v_cndmask_b32_e32 v15, 0x7f800000, v17, vcc_lo             // 000000229294: 021E22FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022929C: BF870001
	v_mul_f32_e32 v17, v7, v15                                 // 0000002292A0: 10221F07
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002292A4: 8C7E007E
	v_lshlrev_b32_e32 v15, 8, v16                              // 0000002292A8: 301E2088
	v_or_b32_e32 v7, 3, v11                                    // 0000002292AC: 380E1683
	s_mov_b32 s0, exec_lo                                      // 0000002292B0: BE80007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002292B4: BF870092
	.long 0xd7006a0f                                           // 0000002292B8: D7006A0F
	v_cndmask_b32_e32 v1, v13, v15, vcc_lo                     // 0000002292BC: 02021F0D
	v_add_co_ci_u32_e64 v16, null, 0, v14, vcc_lo              // 0000002292C0: D5207C10 01AA1C80
	global_store_b32 v[15:16], v17, off                        // 0000002292C8: DC6A0000 007C110F
	.long 0xd4cb007e                                           // 0000002292D0: D4CB007E
	v_cndmask_b32_e32 v1, v10, v7, vcc_lo                      // 0000002292D4: 02020F0A
	s_cbranch_execz 33                                         // 0000002292D8: BFA50021 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi8EEEvPKfS3_S3_Pfi+0x760>
	ds_load_b32 v12, v9 offset:16524                           // 0000002292DC: D8D8408C 0C000009
	ds_load_b32 v15, v8                                        // 0000002292E4: D8D80000 0F000008
	s_waitcnt lgkmcnt(0)                                       // 0000002292EC: BF89FC07
	v_sub_f32_e32 v12, v12, v15                                // 0000002292F0: 08181F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002292F4: BF870091
	v_mul_f32_e32 v15, 0x3fb8aa3b, v12                         // 0000002292F8: 101E18FF 3FB8AA3B
	v_fma_f32 v16, 0x3fb8aa3b, v12, -v15                       // 000000229300: D6130010 843E18FF 3FB8AA3B
	v_rndne_f32_e32 v17, v15                                   // 00000022930C: 7E22470F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000229310: BF870221
	v_sub_f32_e32 v15, v15, v17                                // 000000229314: 081E230F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v12                  // 000000229318: 7C3618FF C2CE8ED0
	v_fmamk_f32 v16, v12, 0x32a5705f, v16                      // 000000229320: 5820210C 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000229328: BF870121
	v_add_f32_e32 v15, v15, v16                                // 00000022932C: 061E210F
	v_cvt_i32_f32_e32 v16, v17                                 // 000000229330: 7E201111
	v_exp_f32_e32 v15, v15                                     // 000000229334: 7E1E4B0F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000229338: BF870095
	.long 0xd71c000f                                           // 00000022933C: D71C000F
	v_cndmask_b32_e32 v1, v15, v16, vcc_lo                     // 000000229340: 0202210F
	v_cndmask_b32_e32 v15, 0, v15, vcc_lo                      // 000000229344: 021E1E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v12                  // 000000229348: 7C3C18FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000229350: BF870092
	v_cndmask_b32_e32 v12, 0x7f800000, v15, vcc_lo             // 000000229354: 02181EFF 7F800000
	v_mul_f32_e32 v12, v6, v12                                 // 00000022935C: 10181906
	s_or_b32 exec_lo, exec_lo, s0                              // 000000229360: 8C7E007E
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v15, 8, v7      // 000000229364: CA220080 060E0E88
	v_or_b32_e32 v7, 4, v11                                    // 00000022936C: 380E1684
	s_mov_b32 s0, exec_lo                                      // 000000229370: BE80007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000229374: BF870092
	.long 0xd7006a10                                           // 000000229378: D7006A10
	v_cndmask_b32_e32 v1, v13, v15, vcc_lo                     // 00000022937C: 02021F0D
	v_add_co_ci_u32_e64 v17, null, 0, v14, vcc_lo              // 000000229380: D5207C11 01AA1C80
	v_mov_b32_e32 v15, 0                                       // 000000229388: 7E1E0280
	global_store_b32 v[16:17], v12, off                        // 00000022938C: DC6A0000 007C0C10
	.long 0xd4cb007e                                           // 000000229394: D4CB007E
	v_cndmask_b32_e32 v1, v10, v7, vcc_lo                      // 000000229398: 02020F0A
	s_cbranch_execz 33                                         // 00000022939C: BFA50021 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi8EEEvPKfS3_S3_Pfi+0x824>
	ds_load_b32 v12, v9 offset:16528                           // 0000002293A0: D8D84090 0C000009
	ds_load_b32 v15, v8                                        // 0000002293A8: D8D80000 0F000008
	s_waitcnt lgkmcnt(0)                                       // 0000002293B0: BF89FC07
	v_sub_f32_e32 v12, v12, v15                                // 0000002293B4: 08181F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002293B8: BF870091
	v_mul_f32_e32 v15, 0x3fb8aa3b, v12                         // 0000002293BC: 101E18FF 3FB8AA3B
	v_fma_f32 v16, 0x3fb8aa3b, v12, -v15                       // 0000002293C4: D6130010 843E18FF 3FB8AA3B
	v_rndne_f32_e32 v17, v15                                   // 0000002293D0: 7E22470F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002293D4: BF870221
	v_sub_f32_e32 v15, v15, v17                                // 0000002293D8: 081E230F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v12                  // 0000002293DC: 7C3618FF C2CE8ED0
	v_fmamk_f32 v16, v12, 0x32a5705f, v16                      // 0000002293E4: 5820210C 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002293EC: BF870121
	v_add_f32_e32 v15, v15, v16                                // 0000002293F0: 061E210F
	v_cvt_i32_f32_e32 v16, v17                                 // 0000002293F4: 7E201111
	v_exp_f32_e32 v15, v15                                     // 0000002293F8: 7E1E4B0F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002293FC: BF870095
	.long 0xd71c000f                                           // 000000229400: D71C000F
	v_cndmask_b32_e32 v1, v15, v16, vcc_lo                     // 000000229404: 0202210F
	v_cndmask_b32_e32 v15, 0, v15, vcc_lo                      // 000000229408: 021E1E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v12                  // 00000022940C: 7C3C18FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000229414: BF870092
	v_cndmask_b32_e32 v12, 0x7f800000, v15, vcc_lo             // 000000229418: 02181EFF 7F800000
	v_mul_f32_e32 v15, v5, v12                                 // 000000229420: 101E1905
	s_or_b32 exec_lo, exec_lo, s0                              // 000000229424: 8C7E007E
	v_lshlrev_b32_e32 v7, 8, v7                                // 000000229428: 300E0E88
	v_or_b32_e32 v5, 5, v11                                    // 00000022942C: 380A1685
	s_mov_b32 s0, exec_lo                                      // 000000229430: BE80007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000229434: BF870092
	.long 0xd7006a10                                           // 000000229438: D7006A10
	v_cndmask_b32_e32 v1, v13, v7, vcc_lo                      // 00000022943C: 02020F0D
	v_add_co_ci_u32_e64 v17, null, 0, v14, vcc_lo              // 000000229440: D5207C11 01AA1C80
	global_store_b32 v[16:17], v15, off                        // 000000229448: DC6A0000 007C0F10
	.long 0xd4cb007e                                           // 000000229450: D4CB007E
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 000000229454: 02020B0A
	s_cbranch_execz 33                                         // 000000229458: BFA50021 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi8EEEvPKfS3_S3_Pfi+0x8e0>
	ds_load_b32 v6, v9 offset:16532                            // 00000022945C: D8D84094 06000009
	ds_load_b32 v7, v8                                         // 000000229464: D8D80000 07000008
	s_waitcnt lgkmcnt(0)                                       // 00000022946C: BF89FC07
	v_sub_f32_e32 v6, v6, v7                                   // 000000229470: 080C0F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000229474: BF870091
	v_mul_f32_e32 v7, 0x3fb8aa3b, v6                           // 000000229478: 100E0CFF 3FB8AA3B
	v_fma_f32 v12, 0x3fb8aa3b, v6, -v7                         // 000000229480: D613000C 841E0CFF 3FB8AA3B
	v_rndne_f32_e32 v15, v7                                    // 00000022948C: 7E1E4707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000229490: BF870091
	v_dual_fmamk_f32 v12, v6, 0x32a5705f, v12 :: v_dual_sub_f32 v7, v7, v15// 000000229494: C88A1906 0C061F07 32A5705F
	v_add_f32_e32 v7, v7, v12                                  // 0000002294A0: 060E1907
	v_cvt_i32_f32_e32 v12, v15                                 // 0000002294A4: 7E18110F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v6                   // 0000002294A8: 7C360CFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002294B0: BF870293
	v_exp_f32_e32 v7, v7                                       // 0000002294B4: 7E0E4B07
	.long 0xd71c0007                                           // 0000002294B8: D71C0007
	v_cndmask_b32_e32 v1, v7, v12, vcc_lo                      // 0000002294BC: 02021907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002294C0: BF870121
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo                        // 0000002294C4: 020E0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v6                   // 0000002294C8: 7C3C0CFF 42B17218
	v_cndmask_b32_e32 v6, 0x7f800000, v7, vcc_lo               // 0000002294D0: 020C0EFF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002294D8: BF870001
	v_mul_f32_e32 v6, v4, v6                                   // 0000002294DC: 100C0D04
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002294E0: 8C7E007E
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v7, 8, v5       // 0000002294E4: CA220080 04060A88
	v_or_b32_e32 v5, 6, v11                                    // 0000002294EC: 380A1686
	s_mov_b32 s0, exec_lo                                      // 0000002294F0: BE80007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002294F4: BF870092
	.long 0xd7006a0f                                           // 0000002294F8: D7006A0F
	v_cndmask_b32_e32 v1, v13, v7, vcc_lo                      // 0000002294FC: 02020F0D
	v_add_co_ci_u32_e64 v16, null, 0, v14, vcc_lo              // 000000229500: D5207C10 01AA1C80
	v_mov_b32_e32 v7, 0                                        // 000000229508: 7E0E0280
	global_store_b32 v[15:16], v6, off                         // 00000022950C: DC6A0000 007C060F
	.long 0xd4cb007e                                           // 000000229514: D4CB007E
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 000000229518: 02020B0A
	s_cbranch_execz 33                                         // 00000022951C: BFA50021 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi8EEEvPKfS3_S3_Pfi+0x9a4>
	ds_load_b32 v6, v9 offset:16536                            // 000000229520: D8D84098 06000009
	ds_load_b32 v7, v8                                         // 000000229528: D8D80000 07000008
	s_waitcnt lgkmcnt(0)                                       // 000000229530: BF89FC07
	v_sub_f32_e32 v6, v6, v7                                   // 000000229534: 080C0F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000229538: BF870091
	v_mul_f32_e32 v7, 0x3fb8aa3b, v6                           // 00000022953C: 100E0CFF 3FB8AA3B
	v_fma_f32 v12, 0x3fb8aa3b, v6, -v7                         // 000000229544: D613000C 841E0CFF 3FB8AA3B
	v_rndne_f32_e32 v15, v7                                    // 000000229550: 7E1E4707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000229554: BF870091
	v_dual_fmamk_f32 v12, v6, 0x32a5705f, v12 :: v_dual_sub_f32 v7, v7, v15// 000000229558: C88A1906 0C061F07 32A5705F
	v_add_f32_e32 v7, v7, v12                                  // 000000229564: 060E1907
	v_cvt_i32_f32_e32 v12, v15                                 // 000000229568: 7E18110F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v6                   // 00000022956C: 7C360CFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000229574: BF870293
	v_exp_f32_e32 v7, v7                                       // 000000229578: 7E0E4B07
	.long 0xd71c0007                                           // 00000022957C: D71C0007
	v_cndmask_b32_e32 v1, v7, v12, vcc_lo                      // 000000229580: 02021907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000229584: BF870121
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo                        // 000000229588: 020E0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v6                   // 00000022958C: 7C3C0CFF 42B17218
	v_cndmask_b32_e32 v6, 0x7f800000, v7, vcc_lo               // 000000229594: 020C0EFF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022959C: BF870001
	v_mul_f32_e32 v7, v3, v6                                   // 0000002295A0: 100E0D03
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002295A4: 8C7E007E
	v_lshlrev_b32_e32 v5, 8, v5                                // 0000002295A8: 300A0A88
	v_or_b32_e32 v3, 7, v11                                    // 0000002295AC: 38061687
	s_mov_b32 s0, exec_lo                                      // 0000002295B0: BE80007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002295B4: BF870092
	.long 0xd7006a05                                           // 0000002295B8: D7006A05
	v_cndmask_b32_e32 v1, v13, v5, vcc_lo                      // 0000002295BC: 02020B0D
	v_add_co_ci_u32_e64 v6, null, 0, v14, vcc_lo               // 0000002295C0: D5207C06 01AA1C80
	global_store_b32 v[5:6], v7, off                           // 0000002295C8: DC6A0000 007C0705
	.long 0xd4cb007e                                           // 0000002295D0: D4CB007E
	v_cndmask_b32_e32 v1, v10, v3, vcc_lo                      // 0000002295D4: 0202070A
	s_cbranch_execz 33                                         // 0000002295D8: BFA50021 <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi8EEEvPKfS3_S3_Pfi+0xa60>
	ds_load_b32 v4, v9 offset:16540                            // 0000002295DC: D8D8409C 04000009
	ds_load_b32 v5, v8                                         // 0000002295E4: D8D80000 05000008
	s_waitcnt lgkmcnt(0)                                       // 0000002295EC: BF89FC07
	v_sub_f32_e32 v4, v4, v5                                   // 0000002295F0: 08080B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002295F4: BF870091
	v_mul_f32_e32 v5, 0x3fb8aa3b, v4                           // 0000002295F8: 100A08FF 3FB8AA3B
	v_fma_f32 v6, 0x3fb8aa3b, v4, -v5                          // 000000229600: D6130006 841608FF 3FB8AA3B
	v_rndne_f32_e32 v7, v5                                     // 00000022960C: 7E0E4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000229610: BF870221
	v_sub_f32_e32 v5, v5, v7                                   // 000000229614: 080A0F05
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 000000229618: 7C3608FF C2CE8ED0
	v_fmamk_f32 v6, v4, 0x32a5705f, v6                         // 000000229620: 580C0D04 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000229628: BF870121
	v_add_f32_e32 v5, v5, v6                                   // 00000022962C: 060A0D05
	v_cvt_i32_f32_e32 v6, v7                                   // 000000229630: 7E0C1107
	v_exp_f32_e32 v5, v5                                       // 000000229634: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000229638: BF870095
	.long 0xd71c0005                                           // 00000022963C: D71C0005
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 000000229640: 02020D05
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo                        // 000000229644: 020A0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 000000229648: 7C3C08FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000229650: BF870092
	v_cndmask_b32_e32 v4, 0x7f800000, v5, vcc_lo               // 000000229654: 02080AFF 7F800000
	v_mul_f32_e32 v4, v2, v4                                   // 00000022965C: 10080902
	s_or_b32 exec_lo, exec_lo, s0                              // 000000229660: 8C7E007E
	v_lshlrev_b32_e32 v2, 8, v3                                // 000000229664: 30040688
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000229668: BF870091
	.long 0xd7006a02                                           // 00000022966C: D7006A02
	v_cndmask_b32_e32 v1, v13, v2, vcc_lo                      // 000000229670: 0202050D
	v_add_co_ci_u32_e64 v3, null, 0, v14, vcc_lo               // 000000229674: D5207C03 01AA1C80
	global_store_b32 v[2:3], v4, off                           // 00000022967C: DC6A0000 007C0402
	s_or_b32 exec_lo, exec_lo, s6                              // 000000229684: 8C7E067E
	s_lshl_b32 s1, s16, 10                                     // 000000229688: 84018A10
	s_mov_b32 s0, exec_lo                                      // 00000022968C: BE80007E
	.long 0xd4cc007e                                           // 000000229690: D4CC007E
	v_cndmask_b32_e32 v1, s1, v0, vcc_lo                       // 000000229694: 02020001
	s_cbranch_execz 60                                         // 000000229698: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi8EEEvPKfS3_S3_Pfi+0xb8c>
	s_mul_i32 s0, s15, 0xc0000                                 // 00000022969C: 9600FF0F 000C0000
	s_lshl_b64 s[2:3], s[12:13], 14                            // 0000002296A4: 84828E0C
	s_mul_hi_u32 s4, s15, 0xc0000                              // 0000002296A8: 9684FF0F 000C0000
	s_add_u32 s0, s0, s2                                       // 0000002296B0: 80000200
	s_addc_u32 s2, s4, s3                                      // 0000002296B4: 82020304
	v_lshrrev_b32_e32 v3, 5, v0                                // 0000002296B8: 32060085
	s_add_u32 s0, s10, s0                                      // 0000002296BC: 8000000A
	s_addc_u32 s2, s11, s2                                     // 0000002296C0: 8202020B
	.long 0xd7000004                                           // 0000002296C4: D7000004
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 0000002296C8: 02020200
	v_mov_b32_e32 v2, 0                                        // 0000002296CC: 7E040280
	v_add_co_ci_u32_e64 v5, null, s2, 0, s0                    // 0000002296D0: D5207C05 00010002
	v_mov_b32_e32 v6, v3                                       // 0000002296D8: 7E0C0303
	s_mov_b32 s2, 0                                            // 0000002296DC: BE820080
	s_nop 0                                                    // 0000002296E0: BF800000
	s_nop 0                                                    // 0000002296E4: BF800000
	s_nop 0                                                    // 0000002296E8: BF800000
	s_nop 0                                                    // 0000002296EC: BF800000
	s_nop 0                                                    // 0000002296F0: BF800000
	s_nop 0                                                    // 0000002296F4: BF800000
	s_nop 0                                                    // 0000002296F8: BF800000
	s_nop 0                                                    // 0000002296FC: BF800000
	v_lshl_or_b32 v1, v3, 6, s14                               // 000000229700: D6560001 00390D03
	v_add_nc_u32_e32 v0, 0x100, v0                             // 000000229708: 4A0000FF 00000100
	v_add_nc_u32_e32 v3, 8, v3                                 // 000000229710: 4A060688
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000229714: BF870223
	.long 0xd73c0007                                           // 000000229718: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000022971C: 02020282
	v_and_b32_e32 v1, 0x3ffffff, v6                            // 000000229720: 36020CFF 03FFFFFF
	v_cmp_le_u32_e32 vcc_lo, s1, v0                            // 000000229728: 7C960001
	v_add_nc_u32_e32 v6, 8, v6                                 // 00000022972C: 4A0C0C88
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000229730: BF8700A3
	.long 0xd73c0009                                           // 000000229734: D73C0009
	v_cndmask_b32_e32 v1, 7, v1, vcc_lo                        // 000000229738: 02020287
	s_or_b32 s2, vcc_lo, s2                                    // 00000022973C: 8C02026A
	.long 0xd7010001                                           // 000000229740: D7010001
	v_cndmask_b32_e32 v1, v7, v9, vcc_lo                       // 000000229744: 02021307
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000229748: BF870111
	v_sub_co_ci_u32_e64 v8, null, v8, v10, s0                  // 00000022974C: D5217C08 00021508
	.long 0xd7000007                                           // 000000229754: D7000007
	v_cndmask_b32_e32 v1, v4, v1, vcc_lo                       // 000000229758: 02020304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000022975C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, v5, v8, s0                   // 000000229760: D5207C08 00021105
	.long 0xd7000004                                           // 000000229768: D7000004
	v_cndmask_b32_e32 v1, 0x400, v4, vcc_lo                    // 00000022976C: 020208FF 00000400
	v_add_co_ci_u32_e64 v5, null, 0, v5, s0                    // 000000229774: D5207C05 00020A80
	global_store_b32 v[7:8], v2, off                           // 00000022977C: DC6A0000 007C0207
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 000000229784: 917E027E
	s_cbranch_execnz 65501                                     // 000000229788: BFA6FFDD <_ZN7halogen12_GLOBAL__N_110k_dnc_att7ILi32ELi8EEEvPKfS3_S3_Pfi+0xb00>
	s_endpgm                                                   // 00000022978C: BFB00000
		...

