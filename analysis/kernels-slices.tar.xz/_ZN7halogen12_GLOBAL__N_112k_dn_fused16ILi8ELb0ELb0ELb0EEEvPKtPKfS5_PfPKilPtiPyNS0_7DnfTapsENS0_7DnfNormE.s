000000000004ba00 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE>:
; _ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE():
	s_clause 0x1                                               // 00000004BA00: BF850001
	s_load_b256 s[20:27], s[0:1], 0x20                         // 00000004BA04: F40C0500 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 00000004BA0C: F40C0200 F8000000
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 5, v0       // 00000004BA14: CA220080 02020085
	s_ashr_i32 s3, s2, 31                                      // 00000004BA1C: 86039F02
	s_mov_b32 s28, 0                                           // 00000004BA20: BE9C0080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004BA24: BF870001
	v_and_b32_e32 v3, 0x200, v3                                // 00000004BA28: 360606FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 00000004BA30: BF89FC07
	s_load_b32 s16, s[20:21], null                             // 00000004BA34: F400040A F8000000
	v_readfirstlane_b32 s20, v0                                // 00000004BA3C: 7E280500
	s_lshl_b64 s[4:5], s[22:23], 2                             // 00000004BA40: 84848216
	s_lshr_b32 s21, s20, 5                                     // 00000004BA44: 85158514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000004BA48: BF8704D9
	s_lshl_b32 s33, s21, 4                                     // 00000004BA4C: 84218415
	s_add_u32 s4, s14, s4                                      // 00000004BA50: 8004040E
	v_and_or_b32 v1, v0, 15, s33                               // 00000004BA54: D6570001 00851F00
	s_addc_u32 s5, s15, s5                                     // 00000004BA5C: 8205050F
	s_lshl_b64 s[6:7], s[2:3], 16                              // 00000004BA60: 84869002
	s_add_u32 s4, s4, s6                                       // 00000004BA64: 80040604
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004BA68: BF870001
	.long 0xd73c0001                                           // 00000004BA6C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000004BA70: 02020282
	s_addc_u32 s5, s5, s7                                      // 00000004BA74: 82050705
	s_waitcnt lgkmcnt(0)                                       // 00000004BA78: BF89FC07
	s_mul_i32 s14, s16, 0x9000000                              // 00000004BA7C: 960EFF10 09000000
	s_mul_hi_i32 s15, s16, 0x9000000                           // 00000004BA84: 970FFF10 09000000
	s_add_u32 s4, s4, s14                                      // 00000004BA8C: 80040E04
	s_addc_u32 s5, s5, s15                                     // 00000004BA90: 82050F05
	.long 0xd7006a01                                           // 00000004BA94: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000004BA98: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000004BA9C: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000004BAA0: D5207C02 01AA0405
	s_or_b32 s5, s21, s2                                       // 00000004BAA8: 8C050215
	.long 0xd7006abb                                           // 00000004BAAC: D7006ABB
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000004BAB0: 02020701
	v_add_co_ci_u32_e64 v188, null, 0, v2, vcc_lo              // 00000004BAB4: D5207CBC 01AA0480
	s_cselect_b32 s38, 0, -1                                   // 00000004BABC: 9826C180
	.long 0xd7006a09                                           // 00000004BAC0: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v187, vcc_lo                 // 00000004BAC4: 020376FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004BACC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v188, vcc_lo             // 00000004BAD0: D5207C0A 01AB7880
	.long 0xd7006a34                                           // 00000004BAD8: D7006A34
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004BADC: 0201FFBB
	.long 0x00002000                                           // 00000004BAE0: 00002000
	v_add_co_ci_u32_e64 v53, null, 0, v188, vcc_lo             // 00000004BAE4: D5207C35 01AB7880
	.long 0xd7006a0d                                           // 00000004BAEC: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v187, vcc_lo                 // 00000004BAF0: 020376FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004BAF8: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v188, vcc_lo             // 00000004BAFC: D5207C0E 01AB7880
	.long 0xd7006a0f                                           // 00000004BB04: D7006A0F
	v_cndmask_b32_e32 v1, 0x3000, v187, vcc_lo                 // 00000004BB08: 020376FF 00003000
	v_add_co_ci_u32_e64 v16, null, 0, v188, vcc_lo             // 00000004BB10: D5207C10 01AB7880
	.long 0xd7006a3c                                           // 00000004BB18: D7006A3C
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004BB1C: 0201FFBB
	.long 0x00004000                                           // 00000004BB20: 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004BB24: BF870001
	v_add_co_ci_u32_e64 v61, null, 0, v188, vcc_lo             // 00000004BB28: D5207C3D 01AB7880
	.long 0xd7006a11                                           // 00000004BB30: D7006A11
	v_cndmask_b32_e32 v1, 0x4000, v187, vcc_lo                 // 00000004BB34: 020376FF 00004000
	s_clause 0x7                                               // 00000004BB3C: BF850007
	global_load_b32 v5, v[187:188], off                        // 00000004BB40: DC520000 057C00BB
	global_load_b32 v6, v[187:188], off offset:1024            // 00000004BB48: DC520400 067C00BB
	global_load_b32 v7, v[187:188], off offset:2048            // 00000004BB50: DC520800 077C00BB
	global_load_b32 v8, v[187:188], off offset:3072            // 00000004BB58: DC520C00 087C00BB
	global_load_b32 v2, v[9:10], off offset:1024               // 00000004BB60: DC520400 027C0009
	global_load_b32 v3, v[9:10], off offset:2048               // 00000004BB68: DC520800 037C0009
	global_load_b32 v4, v[9:10], off offset:3072               // 00000004BB70: DC520C00 047C0009
	global_load_b32 v1, v[13:14], off offset:1024              // 00000004BB78: DC520400 017C000D
	v_add_co_ci_u32_e64 v18, null, 0, v188, vcc_lo             // 00000004BB80: D5207C12 01AB7880
	s_clause 0x7                                               // 00000004BB88: BF850007
	global_load_b32 v12, v[13:14], off offset:2048             // 00000004BB8C: DC520800 0C7C000D
	global_load_b32 v13, v[13:14], off offset:3072             // 00000004BB94: DC520C00 0D7C000D
	global_load_b32 v9, v[15:16], off offset:1024              // 00000004BB9C: DC520400 097C000F
	global_load_b32 v10, v[15:16], off offset:2048             // 00000004BBA4: DC520800 0A7C000F
	global_load_b32 v11, v[15:16], off offset:3072             // 00000004BBAC: DC520C00 0B7C000F
	global_load_b32 v14, v[17:18], off offset:1024             // 00000004BBB4: DC520400 0E7C0011
	global_load_b32 v15, v[17:18], off offset:2048             // 00000004BBBC: DC520800 0F7C0011
	global_load_b32 v16, v[17:18], off offset:3072             // 00000004BBC4: DC520C00 107C0011
	.long 0xd7006a11                                           // 00000004BBCC: D7006A11
	v_cndmask_b32_e32 v1, 0x5000, v187, vcc_lo                 // 00000004BBD0: 020376FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004BBD8: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v188, vcc_lo             // 00000004BBDC: D5207C12 01AB7880
	.long 0xd7006a41                                           // 00000004BBE4: D7006A41
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004BBE8: 0201FFBB
	.long 0x00006000                                           // 00000004BBEC: 00006000
	v_add_co_ci_u32_e64 v66, null, 0, v188, vcc_lo             // 00000004BBF0: D5207C42 01AB7880
	.long 0xd7006a17                                           // 00000004BBF8: D7006A17
	v_cndmask_b32_e32 v1, 0x6000, v187, vcc_lo                 // 00000004BBFC: 020376FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004BC04: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v188, vcc_lo             // 00000004BC08: D5207C18 01AB7880
	.long 0xd7006a19                                           // 00000004BC10: D7006A19
	v_cndmask_b32_e32 v1, 0x7000, v187, vcc_lo                 // 00000004BC14: 020376FF 00007000
	v_add_co_ci_u32_e64 v26, null, 0, v188, vcc_lo             // 00000004BC1C: D5207C1A 01AB7880
	.long 0xd7006a29                                           // 00000004BC24: D7006A29
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004BC28: 0201FFBB
	.long 0x00008000                                           // 00000004BC2C: 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004BC30: BF8700A1
	v_add_co_ci_u32_e64 v42, null, 0, v188, vcc_lo             // 00000004BC34: D5207C2A 01AB7880
	.long 0xd7006a20                                           // 00000004BC3C: D7006A20
	v_cndmask_b32_e32 v1, 0x8000, v187, vcc_lo                 // 00000004BC40: 020376FF 00008000
	v_add_co_ci_u32_e64 v33, null, 0, v188, vcc_lo             // 00000004BC48: D5207C21 01AB7880
	.long 0xd7006a22                                           // 00000004BC50: D7006A22
	v_cndmask_b32_e32 v1, 0x9000, v187, vcc_lo                 // 00000004BC54: 020376FF 00009000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004BC5C: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v188, vcc_lo             // 00000004BC60: D5207C23 01AB7880
	.long 0xd7006a2b                                           // 00000004BC68: D7006A2B
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004BC6C: 0201FFBB
	.long 0x0000a000                                           // 00000004BC70: 0000A000
	v_add_co_ci_u32_e64 v44, null, 0, v188, vcc_lo             // 00000004BC74: D5207C2C 01AB7880
	.long 0xd7006a25                                           // 00000004BC7C: D7006A25
	v_cndmask_b32_e32 v1, 0xa000, v187, vcc_lo                 // 00000004BC80: 020376FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004BC88: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v188, vcc_lo             // 00000004BC8C: D5207C26 01AB7880
	.long 0xd7006a27                                           // 00000004BC94: D7006A27
	v_cndmask_b32_e32 v1, 0xb000, v187, vcc_lo                 // 00000004BC98: 020376FF 0000B000
	v_add_co_ci_u32_e64 v40, null, 0, v188, vcc_lo             // 00000004BCA0: D5207C28 01AB7880
	.long 0xd7006a2d                                           // 00000004BCA8: D7006A2D
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004BCAC: 0201FFBB
	.long 0x0000c000                                           // 00000004BCB0: 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004BCB4: BF8700A1
	v_add_co_ci_u32_e64 v46, null, 0, v188, vcc_lo             // 00000004BCB8: D5207C2E 01AB7880
	.long 0xd7006a2f                                           // 00000004BCC0: D7006A2F
	v_cndmask_b32_e32 v1, 0xc000, v187, vcc_lo                 // 00000004BCC4: 020376FF 0000C000
	v_add_co_ci_u32_e64 v48, null, 0, v188, vcc_lo             // 00000004BCCC: D5207C30 01AB7880
	.long 0xd7006a36                                           // 00000004BCD4: D7006A36
	v_cndmask_b32_e32 v1, 0xd000, v187, vcc_lo                 // 00000004BCD8: 020376FF 0000D000
	s_clause 0x17                                              // 00000004BCE0: BF850017
	global_load_b32 v20, v[17:18], off offset:1024             // 00000004BCE4: DC520400 147C0011
	global_load_b32 v21, v[17:18], off offset:2048             // 00000004BCEC: DC520800 157C0011
	global_load_b32 v22, v[17:18], off offset:3072             // 00000004BCF4: DC520C00 167C0011
	global_load_b32 v17, v[23:24], off offset:1024             // 00000004BCFC: DC520400 117C0017
	global_load_b32 v18, v[23:24], off offset:2048             // 00000004BD04: DC520800 127C0017
	global_load_b32 v19, v[23:24], off offset:3072             // 00000004BD0C: DC520C00 137C0017
	global_load_b32 v23, v[25:26], off offset:1024             // 00000004BD14: DC520400 177C0019
	global_load_b32 v24, v[25:26], off offset:2048             // 00000004BD1C: DC520800 187C0019
	global_load_b32 v31, v[25:26], off offset:3072             // 00000004BD24: DC520C00 1F7C0019
	global_load_b32 v28, v[32:33], off offset:1024             // 00000004BD2C: DC520400 1C7C0020
	global_load_b32 v29, v[32:33], off offset:2048             // 00000004BD34: DC520800 1D7C0020
	global_load_b32 v30, v[32:33], off offset:3072             // 00000004BD3C: DC520C00 1E7C0020
	global_load_b32 v25, v[34:35], off offset:1024             // 00000004BD44: DC520400 197C0022
	global_load_b32 v26, v[34:35], off offset:2048             // 00000004BD4C: DC520800 1A7C0022
	global_load_b32 v27, v[34:35], off offset:3072             // 00000004BD54: DC520C00 1B7C0022
	global_load_b32 v32, v[37:38], off offset:1024             // 00000004BD5C: DC520400 207C0025
	global_load_b32 v36, v[37:38], off offset:2048             // 00000004BD64: DC520800 247C0025
	global_load_b32 v37, v[37:38], off offset:3072             // 00000004BD6C: DC520C00 257C0025
	global_load_b32 v33, v[39:40], off offset:1024             // 00000004BD74: DC520400 217C0027
	global_load_b32 v34, v[39:40], off offset:2048             // 00000004BD7C: DC520800 227C0027
	global_load_b32 v35, v[39:40], off offset:3072             // 00000004BD84: DC520C00 237C0027
	global_load_b32 v38, v[47:48], off offset:1024             // 00000004BD8C: DC520400 267C002F
	global_load_b32 v39, v[47:48], off offset:2048             // 00000004BD94: DC520800 277C002F
	global_load_b32 v40, v[47:48], off offset:3072             // 00000004BD9C: DC520C00 287C002F
	v_add_co_ci_u32_e64 v55, null, 0, v188, vcc_lo             // 00000004BDA4: D5207C37 01AB7880
	.long 0xd7006a2f                                           // 00000004BDAC: D7006A2F
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004BDB0: 0201FFBB
	.long 0x0000e000                                           // 00000004BDB4: 0000E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004BDB8: BF8700A1
	v_add_co_ci_u32_e64 v48, null, 0, v188, vcc_lo             // 00000004BDBC: D5207C30 01AB7880
	.long 0xd7006a3e                                           // 00000004BDC4: D7006A3E
	v_cndmask_b32_e32 v1, 0xe000, v187, vcc_lo                 // 00000004BDC8: 020376FF 0000E000
	v_add_co_ci_u32_e64 v63, null, 0, v188, vcc_lo             // 00000004BDD0: D5207C3F 01AB7880
	.long 0xd7006a43                                           // 00000004BDD8: D7006A43
	v_cndmask_b32_e32 v1, 0xf000, v187, vcc_lo                 // 00000004BDDC: 020376FF 0000F000
	s_clause 0x7                                               // 00000004BDE4: BF850007
	global_load_b32 v51, v[41:42], off offset:-4096            // 00000004BDE8: DC521000 337C0029
	global_load_b32 v58, v[41:42], off                         // 00000004BDF0: DC520000 3A7C0029
	global_load_b32 v50, v[43:44], off offset:-4096            // 00000004BDF8: DC521000 327C002B
	global_load_b32 v56, v[43:44], off                         // 00000004BE00: DC520000 387C002B
	global_load_b32 v44, v[45:46], off offset:-4096            // 00000004BE08: DC521000 2C7C002D
	global_load_b32 v43, v[45:46], off                         // 00000004BE10: DC520000 2B7C002D
	global_load_b32 v42, v[47:48], off offset:-4096            // 00000004BE18: DC521000 2A7C002F
	global_load_b32 v41, v[47:48], off                         // 00000004BE20: DC520000 297C002F
	v_add_co_ci_u32_e64 v68, null, 0, v188, vcc_lo             // 00000004BE28: D5207C44 01AB7880
	s_clause 0xf                                               // 00000004BE30: BF85000F
	global_load_b32 v48, v[54:55], off offset:1024             // 00000004BE34: DC520400 307C0036
	global_load_b32 v49, v[54:55], off offset:2048             // 00000004BE3C: DC520800 317C0036
	global_load_b32 v55, v[54:55], off offset:3072             // 00000004BE44: DC520C00 377C0036
	global_load_b32 v45, v[62:63], off offset:1024             // 00000004BE4C: DC520400 2D7C003E
	global_load_b32 v46, v[62:63], off offset:2048             // 00000004BE54: DC520800 2E7C003E
	global_load_b32 v47, v[62:63], off offset:3072             // 00000004BE5C: DC520C00 2F7C003E
	global_load_b32 v57, v[67:68], off                         // 00000004BE64: DC520000 397C0043
	global_load_b32 v59, v[67:68], off offset:1024             // 00000004BE6C: DC520400 3B7C0043
	global_load_b32 v54, v[52:53], off offset:-4096            // 00000004BE74: DC521000 367C0034
	global_load_b32 v64, v[52:53], off                         // 00000004BE7C: DC520000 407C0034
	global_load_b32 v53, v[60:61], off offset:-4096            // 00000004BE84: DC521000 357C003C
	global_load_b32 v63, v[60:61], off                         // 00000004BE8C: DC520000 3F7C003C
	global_load_b32 v52, v[65:66], off offset:-4096            // 00000004BE94: DC521000 347C0041
	global_load_b32 v62, v[65:66], off                         // 00000004BE9C: DC520000 3E7C0041
	global_load_b32 v60, v[67:68], off offset:2048             // 00000004BEA4: DC520800 3C7C0043
	global_load_b32 v61, v[67:68], off offset:3072             // 00000004BEAC: DC520C00 3D7C0043
	v_lshlrev_b32_e32 v65, 3, v0                               // 00000004BEB4: 30820083
	s_cbranch_scc1 1                                           // 00000004BEB8: BFA20001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4c0>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 00000004BEBC: BE9C4D83
	s_load_b32 s39, s[0:1], 0x38                               // 00000004BEC0: F40009C0 F8000038
	v_lshrrev_b32_e32 v69, 4, v0                               // 00000004BEC8: 328A0084
	s_mul_hi_i32 s4, s2, 0x55555556                            // 00000004BECC: 9704FF02 55555556
	v_and_b32_e32 v67, 0x78, v65                               // 00000004BED4: 368682FF 00000078
	s_lshr_b32 s14, s4, 31                                     // 00000004BEDC: 850E9F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000004BEE0: BF870499
	s_add_i32 s4, s4, s14                                      // 00000004BEE4: 81040E04
	s_lshl_b32 s14, s4, 7                                      // 00000004BEE8: 840E8704
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004BEEC: BF870001
	v_lshlrev_b32_e32 v67, 1, v67                              // 00000004BEF0: 30868681
	s_ashr_i32 s15, s14, 31                                    // 00000004BEF4: 860F9F0E
	s_mov_b32 s4, exec_lo                                      // 00000004BEF8: BE84007E
	s_lshl_b64 s[14:15], s[14:15], 1                           // 00000004BEFC: 848E810E
	s_waitcnt lgkmcnt(0)                                       // 00000004BF00: BF89FC07
	s_add_i32 s40, s39, -1                                     // 00000004BF04: 8128C127
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BF08: BF870099
	v_min_i32_e32 v66, s40, v69                                // 00000004BF0C: 22848A28
	v_mad_i64_i32 v[65:66], null, 0x5000, v66, s[8:9]          // 00000004BF10: D6FF7C41 002284FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BF1C: BF870091
	.long 0xd7006a41                                           // 00000004BF20: D7006A41
	v_cndmask_b32_e32 v0, v65, v14, vcc_lo                     // 00000004BF24: 02001D41
	v_add_co_ci_u32_e64 v66, null, s15, v66, vcc_lo            // 00000004BF28: D5207C42 01AA840F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BF30: BF870092
	.long 0xd7006a41                                           // 00000004BF34: D7006A41
	v_cndmask_b32_e32 v1, v65, v67, vcc_lo                     // 00000004BF38: 02028741
	v_add_co_ci_u32_e64 v66, null, 0, v66, vcc_lo              // 00000004BF3C: D5207C42 01AA8480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BF44: BF870092
	.long 0xd7006a43                                           // 00000004BF48: D7006A43
	v_cndmask_b32_e32 v1, 0x1000, v65, vcc_lo                  // 00000004BF4C: 020282FF 00001000
	v_add_co_ci_u32_e64 v68, null, 0, v66, vcc_lo              // 00000004BF54: D5207C44 01AA8480
	s_clause 0x1                                               // 00000004BF5C: BF850001
	global_load_b128 v[74:77], v[65:66], off                   // 00000004BF60: DC5E0000 4A7C0041
	global_load_b128 v[78:81], v[67:68], off                   // 00000004BF68: DC5E0000 4E7C0043
	.long 0xd4c3007e                                           // 00000004BF70: D4C3007E
	v_cndmask_b32_e32 v1, s39, v69, vcc_lo                     // 00000004BF74: 02028A27
	s_cbranch_execz 11                                         // 00000004BF78: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5a8>
	s_waitcnt vmcnt(1)                                         // 00000004BF7C: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 00000004BF80: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004BF84: BF870001
	v_mov_b32_e32 v75, v76                                     // 00000004BF88: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 00000004BF8C: 7E94034C
	s_waitcnt vmcnt(0)                                         // 00000004BF90: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 00000004BF94: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 00000004BF98: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 00000004BF9C: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 00000004BFA0: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 00000004BFA4: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s4                              // 00000004BFA8: 8C7E047E
	v_cmp_gt_u32_e32 vcc_lo, 16, v0                            // 00000004BFAC: 7C980090
	.long 0xd4440004                                           // 00000004BFB0: D4440004
	v_cndmask_b32_e32 v1, s39, v0, vcc_lo                      // 00000004BFB4: 02020027
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v140, 0            // 00000004BFB8: CA100080 418C0080
	s_and_b32 s16, vcc_lo, s4                                  // 00000004BFC0: 8B10046A
	scratch_store_b32 off, v65, off                            // 00000004BFC4: DC690000 007C4100
	s_and_saveexec_b32 s4, s16                                 // 00000004BFCC: BE842010
	s_cbranch_execz 30                                         // 00000004BFD0: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x64c>
	v_mul_u32_u24_e32 v65, 0xc0, v0                            // 00000004BFD4: 168200FF 000000C0
	s_lshl_b64 s[16:17], s[2:3], 2                             // 00000004BFDC: 84908202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BFE0: BF870091
	.long 0xd7001242                                           // 00000004BFE4: D7001242
	v_cndmask_b32_e32 v1, s10, v65, vcc_lo                     // 00000004BFE8: 0202820A
	v_add_co_ci_u32_e64 v67, null, s11, 0, s18                 // 00000004BFEC: D5207C43 0049000B
	.long 0xd7001244                                           // 00000004BFF4: D7001244
	v_cndmask_b32_e32 v1, s12, v65, vcc_lo                     // 00000004BFF8: 0202820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004BFFC: BF870211
	v_add_co_ci_u32_e64 v69, null, s13, 0, s18                 // 00000004C000: D5207C45 0049000D
	.long 0xd7006a41                                           // 00000004C008: D7006A41
	v_cndmask_b32_e32 v0, v66, v16, vcc_lo                     // 00000004C00C: 02002142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004C010: BF870211
	v_add_co_ci_u32_e64 v66, null, s17, v67, vcc_lo            // 00000004C014: D5207C42 01AA8611
	.long 0xd7006a43                                           // 00000004C01C: D7006A43
	v_cndmask_b32_e32 v0, v68, v16, vcc_lo                     // 00000004C020: 02002144
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004C024: BF870001
	v_add_co_ci_u32_e64 v68, null, s17, v69, vcc_lo            // 00000004C028: D5207C44 01AA8A11
	global_load_b32 v140, v[65:66], off                        // 00000004C030: DC520000 8C7C0041
	global_load_b32 v65, v[67:68], off                         // 00000004C038: DC520000 417C0043
	s_waitcnt vmcnt(0)                                         // 00000004C040: BF8903F7
	scratch_store_b32 off, v65, off                            // 00000004C044: DC690000 007C4100
	s_or_b32 exec_lo, exec_lo, s4                              // 00000004C04C: 8C7E047E
	s_waitcnt vmcnt(62)                                        // 00000004C050: BF89FBF7
	v_dual_mul_f32 v139, 0x43800000, v5 :: v_dual_mul_f32 v138, 0x43800000, v6// 00000004C054: C8C60AFF 8B8A0CFF 43800000
	v_dual_mul_f32 v137, 0x43800000, v7 :: v_dual_mul_f32 v136, 0x43800000, v8// 00000004C060: C8C60EFF 898810FF 43800000
	s_waitcnt vmcnt(9)                                         // 00000004C06C: BF8927F7
	v_dual_mul_f32 v135, 0x43800000, v54 :: v_dual_mul_f32 v54, 0x43800000, v4// 00000004C070: C8C66CFF 873608FF 43800000
	v_dual_mul_f32 v134, 0x43800000, v2 :: v_dual_mul_f32 v133, 0x43800000, v3// 00000004C07C: C8C604FF 868406FF 43800000
	s_waitcnt vmcnt(8)                                         // 00000004C088: BF8923F7
	v_dual_mul_f32 v132, 0x43800000, v64 :: v_dual_mul_f32 v131, 0x43800000, v1// 00000004C08C: C8C680FF 848202FF 43800000
	v_dual_mul_f32 v130, 0x43800000, v12 :: v_dual_mul_f32 v129, 0x43800000, v13// 00000004C098: C8C618FF 82801AFF 43800000
	s_waitcnt vmcnt(7)                                         // 00000004C0A4: BF891FF7
	v_dual_mul_f32 v128, 0x43800000, v53 :: v_dual_mul_f32 v53, 0x43800000, v11// 00000004C0A8: C8C66AFF 803416FF 43800000
	v_dual_mul_f32 v127, 0x43800000, v9 :: v_dual_mul_f32 v126, 0x43800000, v10// 00000004C0B4: C8C612FF 7F7E14FF 43800000
	s_waitcnt vmcnt(6)                                         // 00000004C0C0: BF891BF7
	v_dual_mul_f32 v125, 0x43800000, v63 :: v_dual_mul_f32 v124, 0x43800000, v14// 00000004C0C4: C8C67EFF 7D7C1CFF 43800000
	v_dual_mul_f32 v123, 0x43800000, v15 :: v_dual_mul_f32 v122, 0x43800000, v16// 00000004C0D0: C8C61EFF 7B7A20FF 43800000
	s_waitcnt vmcnt(5)                                         // 00000004C0DC: BF8917F7
	v_dual_mul_f32 v121, 0x43800000, v52 :: v_dual_mul_f32 v52, 0x43800000, v22// 00000004C0E0: C8C668FF 79342CFF 43800000
	v_dual_mul_f32 v120, 0x43800000, v20 :: v_dual_mul_f32 v119, 0x43800000, v21// 00000004C0EC: C8C628FF 78762AFF 43800000
	s_waitcnt vmcnt(4)                                         // 00000004C0F8: BF8913F7
	v_dual_mul_f32 v118, 0x43800000, v62 :: v_dual_mul_f32 v117, 0x43800000, v17// 00000004C0FC: C8C67CFF 767422FF 43800000
	v_dual_mul_f32 v116, 0x43800000, v18 :: v_dual_mul_f32 v115, 0x43800000, v19// 00000004C108: C8C624FF 747226FF 43800000
	v_dual_mul_f32 v114, 0x43800000, v51 :: v_dual_mul_f32 v111, 0x43800000, v58// 00000004C114: C8C666FF 726E74FF 43800000
	v_dual_mul_f32 v113, 0x43800000, v23 :: v_dual_mul_f32 v112, 0x43800000, v24// 00000004C120: C8C62EFF 717030FF 43800000
	v_dual_mul_f32 v51, 0x43800000, v31 :: v_dual_mul_f32 v110, 0x43800000, v28// 00000004C12C: C8C63EFF 336E38FF 43800000
	v_dual_mul_f32 v109, 0x43800000, v29 :: v_dual_mul_f32 v108, 0x43800000, v30// 00000004C138: C8C63AFF 6D6C3CFF 43800000
	v_dual_mul_f32 v107, 0x43800000, v50 :: v_dual_mul_f32 v106, 0x43800000, v25// 00000004C144: C8C664FF 6B6A32FF 43800000
	v_dual_mul_f32 v105, 0x43800000, v26 :: v_dual_mul_f32 v50, 0x43800000, v27// 00000004C150: C8C634FF 693236FF 43800000
	v_dual_mul_f32 v104, 0x43800000, v56 :: v_dual_mul_f32 v101, 0x43800000, v37// 00000004C15C: C8C670FF 68644AFF 43800000
	v_dual_mul_f32 v103, 0x43800000, v32 :: v_dual_mul_f32 v98, 0x43800000, v34// 00000004C168: C8C640FF 676244FF 43800000
	v_dual_mul_f32 v102, 0x43800000, v36 :: v_dual_mul_f32 v99, 0x43800000, v33// 00000004C174: C8C648FF 666242FF 43800000
	v_dual_mul_f32 v100, 0x43800000, v44 :: v_dual_mul_f32 v97, 0x43800000, v43// 00000004C180: C8C658FF 646056FF 43800000
	v_dual_mul_f32 v58, 0x43800000, v35 :: v_dual_mul_f32 v93, 0x43800000, v42// 00000004C18C: C8C646FF 3A5C54FF 43800000
	v_dual_mul_f32 v96, 0x43800000, v38 :: v_dual_mul_f32 v95, 0x43800000, v39// 00000004C198: C8C64CFF 605E4EFF 43800000
	v_dual_mul_f32 v94, 0x43800000, v40 :: v_dual_mul_f32 v91, 0x43800000, v49// 00000004C1A4: C8C650FF 5E5A62FF 43800000
	v_dual_mul_f32 v92, 0x43800000, v48 :: v_dual_mul_f32 v141, 0x43800000, v45// 00000004C1B0: C8C660FF 5C8C5AFF 43800000
	v_dual_mul_f32 v152, 0x43800000, v55 :: v_dual_mul_f32 v191, 0x43800000, v57// 00000004C1BC: C8C66EFF 98BE72FF 43800000
	v_dual_mul_f32 v90, 0x43800000, v41 :: v_dual_mul_f32 v189, 0x43800000, v59// 00000004C1C8: C8C652FF 5ABC76FF 43800000
	s_waitcnt vmcnt(2)                                         // 00000004C1D4: BF890BF7
	v_dual_mul_f32 v150, 0x43800000, v46 :: v_dual_mul_f32 v151, 0x43800000, v61// 00000004C1D8: C8C65CFF 96967AFF 43800000
	v_mul_f32_e32 v142, 0x43800000, v47                        // 00000004C1E4: 111C5EFF 43800000
	v_mul_f32_e32 v190, 0x43800000, v60                        // 00000004C1EC: 117C78FF 43800000
	s_cmp_lt_i32 s39, 1                                        // 00000004C1F4: BF048127
	s_cbranch_scc1 4714                                        // 00000004C1F8: BFA2126A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x51a4>
	s_add_u32 s30, s8, s14                                     // 00000004C1FC: 801E0E08
	s_addc_u32 s31, s9, s15                                    // 00000004C200: 821F0F09
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000004C204: 848E8202
	s_load_b64 s[26:27], s[0:1], 0x68                          // 00000004C208: F4040680 F8000068
	s_add_u32 s10, s10, s14                                    // 00000004C210: 800A0E0A
	s_addc_u32 s11, s11, s15                                   // 00000004C214: 820B0F0B
	s_add_u32 s34, s12, s14                                    // 00000004C218: 80220E0C
	s_addc_u32 s35, s13, s15                                   // 00000004C21C: 82230F0D
	s_add_i32 s3, s39, 15                                      // 00000004C220: 81038F27
	s_load_b256 s[12:19], s[0:1], 0x48                         // 00000004C224: F40C0300 F8000048
	s_ashr_i32 s4, s3, 31                                      // 00000004C22C: 86049F03
	.long 0xd71f008f                                           // 00000004C230: D71F008F
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000004C234: 020100C1
	s_lshr_b32 s4, s4, 28                                      // 00000004C238: 85049C04
	v_mov_b32_e32 v1, 0                                        // 00000004C23C: 7E020280
	s_add_i32 s3, s3, s4                                       // 00000004C240: 81030403
	v_mov_b32_e32 v149, 0x1000504                              // 00000004C244: 7F2A02FF 01000504
	s_waitcnt lgkmcnt(0)                                       // 00000004C24C: BF89FC07
	s_ashr_i32 s15, s3, 4                                      // 00000004C250: 860F8403
	s_cmp_lg_u32 s21, 0                                        // 00000004C254: BF078015
	s_movk_i32 s3, 0x5f40                                      // 00000004C258: B0035F40
	s_cselect_b32 s41, -1, 0                                   // 00000004C25C: 982980C1
	s_lshl_b32 s22, s2, 7                                      // 00000004C260: 84168702
	v_and_b32_e32 v2, 16, v143                                 // 00000004C264: 36051E90
	s_ashr_i32 s23, s22, 31                                    // 00000004C268: 86179F16
	s_cmp_gt_u32 s20, 63                                       // 00000004C26C: BF08BF14
	v_xor_b32_e32 v146, 2, v143                                // 00000004C270: 3B251E82
	s_cselect_b32 s42, -1, 0                                   // 00000004C274: 982A80C1
	s_cmp_eq_u32 s21, 0                                        // 00000004C278: BF068015
	v_add_nc_u32_e32 v144, 16, v2                              // 00000004C27C: 4B200490
	s_cselect_b32 s2, -1, 0                                    // 00000004C280: 980280C1
	v_xor_b32_e32 v147, 4, v143                                // 00000004C284: 3B271E84
	s_and_b32 s4, s2, exec_lo                                  // 00000004C288: 8B047E02
	s_cselect_b32 s43, s3, 0x5f80                              // 00000004C28C: 982BFF03 00005F80
	s_lshl_b64 s[36:37], s[22:23], 1                           // 00000004C294: 84A48116
	v_xor_b32_e32 v148, 8, v143                                // 00000004C298: 3B291E88
	s_add_u32 s44, s24, s36                                    // 00000004C29C: 802C2418
	s_addc_u32 s45, s25, s37                                   // 00000004C2A0: 822D2519
	s_max_i32 s46, s15, 1                                      // 00000004C2A4: 8A2E810F
	s_add_u32 s16, s16, s6                                     // 00000004C2A8: 80100610
	s_addc_u32 s17, s17, s7                                    // 00000004C2AC: 82110711
	s_add_u32 s18, s18, s6                                     // 00000004C2B0: 80120612
	s_mov_b32 s20, 0                                           // 00000004C2B4: BE940080
	s_addc_u32 s19, s19, s7                                    // 00000004C2B8: 82130713
	s_add_u32 s47, s26, s6                                     // 00000004C2BC: 802F061A
	s_addc_u32 s7, s27, s7                                     // 00000004C2C0: 8207071B
	s_mov_b32 s48, 0x41800000                                  // 00000004C2C4: BEB000FF 41800000
	s_movk_i32 s49, 0x1800                                     // 00000004C2CC: B0311800
	s_movk_i32 s50, 0x2900                                     // 00000004C2D0: B0322900
	s_mov_b32 s21, s20                                         // 00000004C2D4: BE950014
	s_mov_b32 s22, s20                                         // 00000004C2D8: BE960014
	s_mov_b32 s23, s20                                         // 00000004C2DC: BE970014
	s_mov_b32 s24, s20                                         // 00000004C2E0: BE980014
	s_mov_b32 s25, s20                                         // 00000004C2E4: BE990014
	s_mov_b32 s26, s20                                         // 00000004C2E8: BE9A0014
	s_mov_b32 s27, s20                                         // 00000004C2EC: BE9B0014
	s_mov_b32 s51, 0x3d800000                                  // 00000004C2F0: BEB300FF 3D800000
	s_mov_b32 s52, 0x76543210                                  // 00000004C2F8: BEB400FF 76543210
	s_mov_b32 s53, s20                                         // 00000004C300: BEB50014
	s_mov_b32 s6, s20                                          // 00000004C304: BE860014
	s_branch 10                                                // 00000004C308: BFA0000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x934>
	v_mov_b32_e32 v151, v65                                    // 00000004C30C: 7F2E0341
	v_mov_b32_e32 v152, v57                                    // 00000004C310: 7F300339
	v_mov_b32_e32 v58, v49                                     // 00000004C314: 7E740331
	v_mov_b32_e32 v50, v9                                      // 00000004C318: 7E640309
	v_mov_b32_e32 v51, v17                                     // 00000004C31C: 7E660311
	v_mov_b32_e32 v52, v25                                     // 00000004C320: 7E680319
	v_mov_b32_e32 v53, v33                                     // 00000004C324: 7E6A0321
	v_mov_b32_e32 v54, v41                                     // 00000004C328: 7E6C0329
	s_cmp_eq_u32 s53, s46                                      // 00000004C32C: BF062E35
	s_cbranch_scc1 4626                                        // 00000004C330: BFA21212 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x517c>
	v_mov_b32_e32 v44, v0                                      // 00000004C334: 7E580300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000004C338: BF8701B1
	v_ashrrev_i32_e32 v2, 4, v44                               // 00000004C33C: 34045884
	v_and_b32_e32 v55, 15, v44                                 // 00000004C340: 366E588F
	.long 0xd4440003                                           // 00000004C344: D4440003
	v_cndmask_b32_e32 v1, 16, v44, vcc_lo                      // 00000004C348: 02025890
	.long 0xd72c0003                                           // 00000004C34C: D72C0003
	v_cndmask_b32_e32 v1, 0x110, v2, vcc_lo                    // 00000004C350: 020204FF 00000110
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004C358: BF870001
	v_lshl_add_u32 v3, v55, 4, v3                              // 00000004C35C: D6460003 040D0937
	s_waitcnt vmcnt(1)                                         // 00000004C364: BF8907F7
	ds_store_b128 v3, v[74:77] offset:10496                    // 00000004C368: DB7C2900 00004A03
	s_waitcnt vmcnt(0)                                         // 00000004C370: BF8903F7
	ds_store_b128 v3, v[78:81] offset:6144                     // 00000004C374: DB7C1800 00004E03
	s_and_saveexec_b32 s4, s3                                  // 00000004C37C: BE842003
	s_cbranch_execz 6                                          // 00000004C380: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x99c>
	scratch_load_b32 v4, off, off                              // 00000004C384: DC510000 047C0000
	v_lshlrev_b32_e32 v3, 2, v44                               // 00000004C38C: 30065882
	s_waitcnt vmcnt(0)                                         // 00000004C390: BF8903F7
	ds_store_b32 v3, v4 offset:24064                           // 00000004C394: D8345E00 00000403
	s_or_b32 exec_lo, exec_lo, s4                              // 00000004C39C: 8C7E047E
	v_and_b32_e32 v34, 1, v44                                  // 00000004C3A0: 36445881
	s_lshl_b32 s54, s53, 4                                     // 00000004C3A4: 84368435
	v_or_b32_e32 v153, s33, v55                                // 00000004C3A8: 39326E21
	s_mov_b32 s29, exec_lo                                     // 00000004C3AC: BE9D007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004C3B0: BF870112
	v_or_b32_e32 v15, s54, v34                                 // 00000004C3B4: 381E4436
	v_and_b32_e32 v6, 0x7ffffffe, v153                         // 00000004C3B8: 360D32FF 7FFFFFFE
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000004C3C0: BF870232
	v_min_i32_e32 v3, s40, v15                                 // 00000004C3C4: 22061E28
	v_or_b32_e32 v5, 2, v15                                    // 00000004C3C8: 380A1E82
	v_or_b32_e32 v7, 4, v15                                    // 00000004C3CC: 380E1E84
	v_lshlrev_b32_e32 v19, 1, v6                               // 00000004C3D0: 30260C81
	v_or_b32_e32 v8, 6, v15                                    // 00000004C3D4: 38101E86
	v_mad_i64_i32 v[3:4], null, 0x5000, v3, s[8:9]             // 00000004C3D8: D6FF7C03 002206FF 00005000
	v_min_i32_e32 v5, s40, v5                                  // 00000004C3E4: 220A0A28
	v_min_i32_e32 v7, s40, v7                                  // 00000004C3E8: 220E0E28
	v_or_b32_e32 v17, 12, v15                                  // 00000004C3EC: 38221E8C
	v_min_i32_e32 v8, s40, v8                                  // 00000004C3F0: 22101028
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004C3F4: BF8700A4
	v_mad_i64_i32 v[5:6], null, 0x5000, v5, s[8:9]             // 00000004C3F8: D6FF7C05 00220AFF 00005000
	.long 0xd7006a09                                           // 00000004C404: D7006A09
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000004C408: 02004903
	v_add_co_ci_u32_e64 v10, null, s37, v4, vcc_lo             // 00000004C40C: D5207C0A 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v7, s[8:9]             // 00000004C414: D6FF7C03 00220EFF 00005000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C420: BF870093
	.long 0xd7006a07                                           // 00000004C424: D7006A07
	v_cndmask_b32_e32 v1, v9, v19, vcc_lo                      // 00000004C428: 02022709
	v_add_co_ci_u32_e64 v9, null, 0, v10, vcc_lo               // 00000004C42C: D5207C09 01AA1480
	.long 0xd7006a0a                                           // 00000004C434: D7006A0A
	v_cndmask_b32_e32 v0, v5, v36, vcc_lo                      // 00000004C438: 02004905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004C43C: BF870211
	v_add_co_ci_u32_e64 v11, null, s37, v6, vcc_lo             // 00000004C440: D5207C0B 01AA0C25
	.long 0xd7006a05                                           // 00000004C448: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 00000004C44C: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004C454: BF870211
	v_add_co_ci_u32_e64 v6, null, 0, v9, vcc_lo                // 00000004C458: D5207C06 01AA1280
	.long 0xd7006a07                                           // 00000004C460: D7006A07
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 00000004C464: 0202270A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004C468: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v11, vcc_lo               // 00000004C46C: D5207C09 01AA1680
	.long 0xd7006a0a                                           // 00000004C474: D7006A0A
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000004C478: 02004903
	v_add_co_ci_u32_e64 v11, null, s37, v4, vcc_lo             // 00000004C47C: D5207C0B 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v8, s[8:9]             // 00000004C484: D6FF7C03 002210FF 00005000
	.long 0xd7006a07                                           // 00000004C490: D7006A07
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 00000004C494: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004C49C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v9, vcc_lo                // 00000004C4A0: D5207C08 01AA1280
	.long 0xd7006a09                                           // 00000004C4A8: D7006A09
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 00000004C4AC: 0202270A
	v_add_co_ci_u32_e64 v10, null, 0, v11, vcc_lo              // 00000004C4B0: D5207C0A 01AA1680
	v_or_b32_e32 v11, 8, v15                                   // 00000004C4B8: 38161E88
	.long 0xd7006a03                                           // 00000004C4BC: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000004C4C0: 02004903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000004C4C4: BF870191
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 00000004C4C8: D5207C04 01AA0825
	v_min_i32_e32 v11, s40, v11                                // 00000004C4D0: 22161628
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C4D4: BF870093
	.long 0xd7006a0c                                           // 00000004C4D8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 00000004C4DC: 02022703
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 00000004C4E0: D5207C0D 01AA0880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004C4E8: BF8700A3
	v_mad_i64_i32 v[3:4], null, 0x5000, v11, s[8:9]            // 00000004C4EC: D6FF7C03 002216FF 00005000
	.long 0xd7006a09                                           // 00000004C4F8: D7006A09
	v_cndmask_b32_e32 v1, 0x2000, v9, vcc_lo                   // 00000004C4FC: 020212FF 00002000
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo              // 00000004C504: D5207C0A 01AA1480
	.long 0xd7006a0b                                           // 00000004C50C: D7006A0B
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 00000004C510: 020218FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000004C518: BF8700B1
	v_add_co_ci_u32_e64 v12, null, 0, v13, vcc_lo              // 00000004C51C: D5207C0C 01AA1A80
	v_or_b32_e32 v13, 10, v15                                  // 00000004C524: 381A1E8A
	.long 0xd7006a03                                           // 00000004C528: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000004C52C: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 00000004C530: D5207C04 01AA0825
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000004C538: BF870193
	v_min_i32_e32 v13, s40, v13                                // 00000004C53C: 221A1A28
	.long 0xd7006a0e                                           // 00000004C540: D7006A0E
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 00000004C544: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000004C548: BF870191
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000004C54C: D5207C10 01AA0880
	v_mad_i64_i32 v[3:4], null, 0x5000, v13, s[8:9]            // 00000004C554: D6FF7C03 00221AFF 00005000
	v_or_b32_e32 v15, 14, v15                                  // 00000004C560: 381E1E8E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C564: BF870094
	.long 0xd7006a0d                                           // 00000004C568: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v14, vcc_lo                  // 00000004C56C: 02021CFF 00002000
	v_add_co_ci_u32_e64 v14, null, 0, v16, vcc_lo              // 00000004C574: D5207C0E 01AA2080
	v_min_i32_e32 v16, s40, v17                                // 00000004C57C: 22202228
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004C580: BF8700A4
	v_min_i32_e32 v15, s40, v15                                // 00000004C584: 221E1E28
	.long 0xd7006a11                                           // 00000004C588: D7006A11
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000004C58C: 02004903
	v_add_co_ci_u32_e64 v18, null, s37, v4, vcc_lo             // 00000004C590: D5207C12 01AA0825
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000004C598: BF870194
	v_mad_i64_i32 v[3:4], null, 0x5000, v16, s[8:9]            // 00000004C59C: D6FF7C03 002220FF 00005000
	.long 0xd7006a11                                           // 00000004C5A8: D7006A11
	v_cndmask_b32_e32 v1, v17, v19, vcc_lo                     // 00000004C5AC: 02022711
	v_mad_i64_i32 v[15:16], null, 0x5000, v15, s[8:9]          // 00000004C5B0: D6FF7C0F 00221EFF 00005000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000004C5BC: BF870194
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 00000004C5C0: D5207C12 01AA2480
	.long 0xd7006a11                                           // 00000004C5C8: D7006A11
	v_cndmask_b32_e32 v1, 0x2000, v17, vcc_lo                  // 00000004C5CC: 020222FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004C5D4: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 00000004C5D8: D5207C12 01AA2480
	.long 0xd7006a03                                           // 00000004C5E0: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000004C5E4: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 00000004C5E8: D5207C04 01AA0825
	.long 0xd7006a0f                                           // 00000004C5F0: D7006A0F
	v_cndmask_b32_e32 v0, v15, v36, vcc_lo                     // 00000004C5F4: 0200490F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004C5F8: BF870211
	v_add_co_ci_u32_e64 v16, null, s37, v16, vcc_lo            // 00000004C5FC: D5207C10 01AA2025
	.long 0xd7006a03                                           // 00000004C604: D7006A03
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 00000004C608: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004C60C: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000004C610: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 00000004C618: D7006A0F
	v_cndmask_b32_e32 v1, v15, v19, vcc_lo                     // 00000004C61C: 0202270F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004C620: BF870211
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 00000004C624: D5207C10 01AA2080
	.long 0xd7006a03                                           // 00000004C62C: D7006A03
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 00000004C630: 020206FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004C638: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000004C63C: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 00000004C644: D7006A0F
	v_cndmask_b32_e32 v1, 0x2000, v15, vcc_lo                  // 00000004C648: 02021EFF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004C650: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 00000004C654: D5207C10 01AA2080
	s_clause 0x7                                               // 00000004C65C: BF850007
	global_load_b32 v42, v[5:6], off                           // 00000004C660: DC520000 2A7C0005
	global_load_b32 v41, v[7:8], off                           // 00000004C668: DC520000 297C0007
	global_load_b32 v40, v[9:10], off                          // 00000004C670: DC520000 287C0009
	global_load_b32 v39, v[11:12], off                         // 00000004C678: DC520000 277C000B
	global_load_b32 v38, v[13:14], off                         // 00000004C680: DC520000 267C000D
	global_load_b32 v37, v[17:18], off                         // 00000004C688: DC520000 257C0011
	global_load_b32 v35, v[3:4], off                           // 00000004C690: DC520000 237C0003
	global_load_b32 v36, v[15:16], off                         // 00000004C698: DC520000 247C000F
	v_lshlrev_b32_e32 v5, 16, v78                              // 00000004C6A0: 300A9C90
	v_and_b32_e32 v4, 0xffff0000, v74                          // 00000004C6A4: 360894FF FFFF0000
	v_and_b32_e32 v8, 0xffff0000, v75                          // 00000004C6AC: 361096FF FFFF0000
	v_lshlrev_b32_e32 v3, 16, v74                              // 00000004C6B4: 30069490
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000004C6B8: BF8701A4
	v_dual_mul_f32 v5, v5, v5 :: v_dual_lshlrev_b32 v12, 16, v80// 00000004C6BC: C8E20B05 050CA090
	v_lshlrev_b32_e32 v7, 16, v75                              // 00000004C6C4: 300E9690
	v_dual_mul_f32 v3, v3, v3 :: v_dual_and_b32 v6, 0xffff0000, v78// 00000004C6C8: C8E40703 03069CFF FFFF0000
	v_mul_f32_e32 v4, v4, v4                                   // 00000004C6D4: 10080904
	v_and_b32_e32 v13, 0xffff0000, v80                         // 00000004C6D8: 361AA0FF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v76                         // 00000004C6E0: 361498FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000004C6E8: BF8701B4
	v_dual_mul_f32 v6, v6, v6 :: v_dual_and_b32 v11, 0xffff0000, v77// 00000004C6EC: C8E40D06 060A9AFF FFFF0000
	v_mul_f32_e32 v12, v12, v12                                // 00000004C6F8: 1018190C
	v_add_f32_e32 v3, v3, v4                                   // 00000004C6FC: 06060903
	v_dual_add_f32 v4, v5, v6 :: v_dual_lshlrev_b32 v9, 16, v76// 00000004C700: C9220D05 04089890
	v_dual_mul_f32 v5, v7, v7 :: v_dual_mul_f32 v6, v8, v8     // 00000004C708: C8C60F07 05061108
	v_lshlrev_b32_e32 v7, 16, v79                              // 00000004C710: 300E9E90
	v_dual_mul_f32 v13, v13, v13 :: v_dual_and_b32 v8, 0xffff0000, v79// 00000004C714: C8E41B0D 0D089EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004C720: BF870113
	v_dual_add_f32 v5, v5, v6 :: v_dual_and_b32 v14, 0xffff0000, v81// 00000004C724: C9240D05 050EA2FF FFFF0000
	v_dual_mul_f32 v6, v7, v7 :: v_dual_mul_f32 v7, v8, v8     // 00000004C730: C8C60F07 06061108
	v_dual_mul_f32 v8, v9, v9 :: v_dual_mul_f32 v9, v10, v10   // 00000004C738: C8C61309 0808150A
	v_lshlrev_b32_e32 v10, 16, v77                             // 00000004C740: 30149A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004C744: BF870113
	v_dual_add_f32 v6, v6, v7 :: v_dual_add_f32 v7, v12, v13   // 00000004C748: C9080F06 06061B0C
	v_dual_add_f32 v8, v8, v9 :: v_dual_mul_f32 v9, v10, v10   // 00000004C750: C9061308 0808150A
	v_dual_mul_f32 v10, v11, v11 :: v_dual_lshlrev_b32 v11, 16, v81// 00000004C758: C8E2170B 0A0AA290
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004C760: BF870113
	v_add_f32_e32 v4, v4, v6                                   // 00000004C764: 06080D04
	v_dual_add_f32 v9, v9, v10 :: v_dual_mul_f32 v10, v11, v11 // 00000004C768: C9061509 090A170B
	v_mul_f32_e32 v11, v14, v14                                // 00000004C770: 10161D0E
	v_add_f32_e32 v3, v3, v5                                   // 00000004C774: 06060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004C778: BF870123
	v_add_f32_e32 v5, v8, v9                                   // 00000004C77C: 060A1308
	v_xor_b32_e32 v9, 1, v143                                  // 00000004C780: 3A131E81
	v_dual_add_f32 v8, v10, v11 :: v_dual_add_f32 v3, v3, v5   // 00000004C784: C908170A 08020B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000004C78C: BF8701A2
	v_cmp_lt_u32_e32 vcc_lo, v9, v144                          // 00000004C790: 7C932109
	v_cndmask_b32_e32 v9, v143, v9, vcc_lo                     // 00000004C794: 0212138F
	v_add_f32_e32 v5, v7, v8                                   // 00000004C798: 060A1107
	v_cmp_lt_u32_e32 vcc_lo, v146, v144                        // 00000004C79C: 7C932192
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000004C7A0: BF870193
	v_lshlrev_b32_e32 v6, 2, v9                                // 00000004C7A4: 300C1282
	v_dual_add_f32 v4, v4, v5 :: v_dual_cndmask_b32 v7, v143, v146// 00000004C7A8: C9120B04 0407258F
	v_cmp_lt_u32_e32 vcc_lo, v147, v144                        // 00000004C7B0: 7C932193
	ds_bpermute_b32 v5, v6, v3                                 // 00000004C7B4: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 00000004C7BC: DACC0000 06000406
	s_waitcnt lgkmcnt(0)                                       // 00000004C7C4: BF89FC07
	v_dual_add_f32 v4, v4, v6 :: v_dual_add_f32 v3, v3, v5     // 00000004C7C8: C9080D04 04020B03
	v_lshlrev_b32_e32 v5, 2, v7                                // 00000004C7D0: 300A0E82
	ds_bpermute_b32 v6, v5, v3                                 // 00000004C7D4: DACC0000 06000305
	ds_bpermute_b32 v5, v5, v4                                 // 00000004C7DC: DACC0000 05000405
	v_cndmask_b32_e32 v7, v143, v147, vcc_lo                   // 00000004C7E4: 020F278F
	v_cmp_lt_u32_e32 vcc_lo, v148, v144                        // 00000004C7E8: 7C932194
	s_waitcnt lgkmcnt(0)                                       // 00000004C7EC: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v5     // 00000004C7F0: C9080D03 03040B04
	s_delay_alu instid0(VALU_DEP_3)                            // 00000004C7F8: BF870003
	v_dual_cndmask_b32 v7, v143, v148 :: v_dual_lshlrev_b32 v6, 2, v7// 00000004C7FC: CA63298F 07060E82
	ds_bpermute_b32 v5, v6, v3                                 // 00000004C804: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 00000004C80C: DACC0000 06000406
	v_lshlrev_b32_e32 v7, 2, v7                                // 00000004C814: 300E0E82
	s_waitcnt lgkmcnt(0)                                       // 00000004C818: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 00000004C81C: C9080B03 03040D04
	ds_bpermute_b32 v5, v7, v3                                 // 00000004C824: DACC0000 05000307
	ds_bpermute_b32 v6, v7, v4                                 // 00000004C82C: DACC0000 06000407
	v_cmpx_eq_u32_e32 0, v55                                   // 00000004C834: 7D946E80
	s_cbranch_execz 41                                         // 00000004C838: BFA50029 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xee0>
	s_waitcnt lgkmcnt(0)                                       // 00000004C83C: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 00000004C840: C9080B03 03040D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C848: BF870091
	v_dual_add_f32 v3, 0x358637bd, v3 :: v_dual_add_f32 v4, 0x358637bd, v4// 00000004C84C: C90806FF 030408FF 358637BD
	v_dual_mul_f32 v5, 0x4b800000, v3 :: v_dual_mul_f32 v6, 0x4b800000, v4// 00000004C858: C8C606FF 050608FF 4B800000
	.long 0xd4140004                                           // 00000004C864: D4140004
	v_cndmask_b32_e32 v1, 0x800000, v4, vcc_lo                 // 00000004C868: 020208FF 00800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v3                      // 00000004C870: 7C2806FF 00800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C878: BF870092
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 00000004C87C: D5010004 00120D04
	v_rsq_f32_e32 v4, v4                                       // 00000004C884: 7E085D04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C888: BF870095
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_mul_f32 v6, 0x45800000, v4// 00000004C88C: CA460B03 030608FF 45800000
	v_rsq_f32_e32 v3, v3                                       // 00000004C898: 7E065D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 00000004C89C: BF870321
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 00000004C8A0: D5010004 00120D04
	v_rsq_f32_e32 v6, 0x43000000                               // 00000004C8A8: 7E0C5CFF 43000000
	v_mul_f32_e32 v5, 0x45800000, v3                           // 00000004C8B0: 100A06FF 45800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004C8B8: BF870001
	v_cndmask_b32_e32 v3, v3, v5, vcc_lo                       // 00000004C8BC: 02060B03
	v_lshlrev_b32_e32 v5, 2, v2                                // 00000004C8C0: 300A0482
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)   // 00000004C8C4: BF870105
	v_mul_f32_e32 v3, v6, v3                                   // 00000004C8C8: 10060706
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004C8CC: BF870002
	v_add_nc_u32_e32 v5, 0x5c00, v5                            // 00000004C8D0: 4A0A0AFF 00005C00
	ds_store_2addr_b32 v5, v4, v3 offset0:208 offset1:224      // 00000004C8D8: D838E0D0 00030405
	s_or_b32 exec_lo, exec_lo, s29                             // 00000004C8E0: 8C7E1D7E
	v_and_b32_e32 v43, 31, v44                                 // 00000004C8E4: 3656589F
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 00000004C8E8: 916A027E
	s_cbranch_vccnz 119                                        // 00000004C8EC: BFA40077 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10cc>
	.long 0xd7600045                                           // 00000004C8F0: D7600045
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                   // 00000004C8F4: 0201018C
	.long 0xd7600044                                           // 00000004C8F8: D7600044
	v_cndmask_b32_e32 v0, v140, v129, vcc_lo                   // 00000004C8FC: 0201038C
	.long 0xd7600043                                           // 00000004C900: D7600043
	v_cndmask_b32_e32 v0, v140, v130, vcc_lo                   // 00000004C904: 0201058C
	.long 0xd7600042                                           // 00000004C908: D7600042
	v_cndmask_b32_e32 v0, v140, v131, vcc_lo                   // 00000004C90C: 0201078C
	.long 0xd7600041                                           // 00000004C910: D7600041
	v_cndmask_b32_e32 v0, v140, v132, vcc_lo                   // 00000004C914: 0201098C
	.long 0xd7600040                                           // 00000004C918: D7600040
	v_cndmask_b32_e32 v0, v140, v133, vcc_lo                   // 00000004C91C: 02010B8C
	.long 0xd760003f                                           // 00000004C920: D760003F
	v_cndmask_b32_e32 v0, v140, v134, vcc_lo                   // 00000004C924: 02010D8C
	.long 0xd760003e                                           // 00000004C928: D760003E
	v_cndmask_b32_e32 v0, v140, v135, vcc_lo                   // 00000004C92C: 02010F8C
	.long 0xd760003d                                           // 00000004C930: D760003D
	v_cndmask_b32_e32 v0, v140, v136, vcc_lo                   // 00000004C934: 0201118C
	.long 0xd760003c                                           // 00000004C938: D760003C
	v_cndmask_b32_e32 v0, v140, v137, vcc_lo                   // 00000004C93C: 0201138C
	.long 0xd760003b                                           // 00000004C940: D760003B
	v_cndmask_b32_e32 v0, v140, v138, vcc_lo                   // 00000004C944: 0201158C
	.long 0xd760003a                                           // 00000004C948: D760003A
	v_cndmask_b32_e32 v0, v140, v139, vcc_lo                   // 00000004C94C: 0201178C
	.long 0xd7600039                                           // 00000004C950: D7600039
	v_cndmask_b32_e32 v0, v140, v140, vcc_lo                   // 00000004C954: 0201198C
	.long 0xd7600038                                           // 00000004C958: D7600038
	v_cndmask_b32_e32 v0, v140, v141, vcc_lo                   // 00000004C95C: 02011B8C
	.long 0xd7600037                                           // 00000004C960: D7600037
	v_cndmask_b32_e32 v0, v140, v142, vcc_lo                   // 00000004C964: 02011D8C
	.long 0xd760001d                                           // 00000004C968: D760001D
	v_cndmask_b32_e32 v0, v140, v143, vcc_lo                   // 00000004C96C: 02011F8C
	s_mov_b32 s4, exec_lo                                      // 00000004C970: BE84007E
	v_cmpx_gt_u32_e32 16, v43                                  // 00000004C974: 7D985690
	s_cbranch_execz 83                                         // 00000004C978: BFA50053 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10c8>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 00000004C97C: 7C945680
	s_add_f32 s69, s69, 0                                      // 00000004C980: A0458045
	v_lshlrev_b32_e32 v4, 2, v43                               // 00000004C984: 30085682
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000004C988: BF8704BA
	s_add_f32 s68, s69, s68                                    // 00000004C98C: A0444445
	v_cndmask_b32_e64 v3, 0, s69, vcc_lo                       // 00000004C990: D5010003 01A88A80
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 00000004C998: 7C945681
	s_add_f32 s67, s68, s67                                    // 00000004C99C: A0434344
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000004C9A0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s68, vcc_lo                      // 00000004C9A4: D5010003 01A88903
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 00000004C9AC: 7C945682
	s_add_f32 s66, s67, s66                                    // 00000004C9B0: A0424243
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000004C9B4: BF8704A2
	v_cndmask_b32_e64 v3, v3, s67, vcc_lo                      // 00000004C9B8: D5010003 01A88703
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 00000004C9C0: 7C945683
	s_add_f32 s65, s66, s65                                    // 00000004C9C4: A0414142
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000004C9C8: BF8704A2
	v_cndmask_b32_e64 v3, v3, s66, vcc_lo                      // 00000004C9CC: D5010003 01A88503
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 00000004C9D4: 7C945684
	s_add_f32 s64, s65, s64                                    // 00000004C9D8: A0404041
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000004C9DC: BF8704A2
	v_cndmask_b32_e64 v3, v3, s65, vcc_lo                      // 00000004C9E0: D5010003 01A88303
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 00000004C9E8: 7C945685
	s_add_f32 s63, s64, s63                                    // 00000004C9EC: A03F3F40
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000004C9F0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s64, vcc_lo                      // 00000004C9F4: D5010003 01A88103
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 00000004C9FC: 7C945686
	s_add_f32 s62, s63, s62                                    // 00000004CA00: A03E3E3F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000004CA04: BF8704A2
	v_cndmask_b32_e64 v3, v3, s63, vcc_lo                      // 00000004CA08: D5010003 01A87F03
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 00000004CA10: 7C945687
	s_add_f32 s61, s62, s61                                    // 00000004CA14: A03D3D3E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000004CA18: BF8704A2
	v_cndmask_b32_e64 v3, v3, s62, vcc_lo                      // 00000004CA1C: D5010003 01A87D03
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 00000004CA24: 7C945688
	s_add_f32 s60, s61, s60                                    // 00000004CA28: A03C3C3D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000004CA2C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s61, vcc_lo                      // 00000004CA30: D5010003 01A87B03
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 00000004CA38: 7C945689
	s_add_f32 s59, s60, s59                                    // 00000004CA3C: A03B3B3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000004CA40: BF8704A2
	v_cndmask_b32_e64 v3, v3, s60, vcc_lo                      // 00000004CA44: D5010003 01A87903
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 00000004CA4C: 7C94568A
	s_add_f32 s58, s59, s58                                    // 00000004CA50: A03A3A3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000004CA54: BF8704A2
	v_cndmask_b32_e64 v3, v3, s59, vcc_lo                      // 00000004CA58: D5010003 01A87703
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 00000004CA60: 7C94568B
	s_add_f32 s57, s58, s57                                    // 00000004CA64: A039393A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000004CA68: BF8704A2
	v_cndmask_b32_e64 v3, v3, s58, vcc_lo                      // 00000004CA6C: D5010003 01A87503
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 00000004CA74: 7C94568C
	s_add_f32 s56, s57, s56                                    // 00000004CA78: A0383839
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000004CA7C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s57, vcc_lo                      // 00000004CA80: D5010003 01A87303
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 00000004CA88: 7C94568D
	s_add_f32 s55, s56, s55                                    // 00000004CA8C: A0373738
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000004CA90: BF8704A2
	v_cndmask_b32_e64 v3, v3, s56, vcc_lo                      // 00000004CA94: D5010003 01A87103
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 00000004CA9C: 7C94568E
	s_add_f32 s29, s55, s29                                    // 00000004CAA0: A01D1D37
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004CAA4: BF870002
	v_cndmask_b32_e64 v3, v3, s55, vcc_lo                      // 00000004CAA8: D5010003 01A86F03
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 00000004CAB0: 7C94568F
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 00000004CAB4: BF870482
	v_cndmask_b32_e64 v3, v3, s29, vcc_lo                      // 00000004CAB8: D5010003 01A83B03
	ds_store_b32 v4, v3 offset:24128                           // 00000004CAC0: D8345E40 00000304
	s_or_b32 exec_lo, exec_lo, s4                              // 00000004CAC8: 8C7E047E
	s_add_i32 s53, s53, 1                                      // 00000004CACC: 81358135
	s_waitcnt lgkmcnt(0)                                       // 00000004CAD0: BF89FC07
	s_barrier                                                  // 00000004CAD4: BFBD0000
	s_cmp_ge_i32 s53, s15                                      // 00000004CAD8: BF030F35
	s_cbranch_scc0 6                                           // 00000004CADC: BFA10006 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10f8>
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 00000004CAE0: 916A267E
	s_cbranch_vccz 77                                          // 00000004CAE4: BFA3004D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x121c>
	s_and_b32 vcc_lo, exec_lo, s42                             // 00000004CAE8: 8B6A2A7E
	s_mov_b32 s3, -1                                           // 00000004CAEC: BE8300C1
	s_cbranch_vccnz 78                                         // 00000004CAF0: BFA4004E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x122c>
	s_branch 157                                               // 00000004CAF4: BFA0009D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x136c>
	s_lshl_b32 s4, s53, 4                                      // 00000004CAF8: 84048435
	v_lshlrev_b32_e32 v4, 4, v44                               // 00000004CAFC: 30085884
	s_waitcnt lgkmcnt(0)                                       // 00000004CB00: BF89FC07
	v_add_nc_u32_e32 v6, s4, v2                                // 00000004CB04: 4A0C0404
	s_mov_b32 s29, exec_lo                                     // 00000004CB08: BE9D007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004CB0C: BF870112
	v_and_b32_e32 v4, 0xf0, v4                                 // 00000004CB10: 360808FF 000000F0
	v_min_i32_e32 v2, s40, v6                                  // 00000004CB18: 22040C28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CB1C: BF870091
	v_mad_i64_i32 v[2:3], null, 0x5000, v2, s[30:31]           // 00000004CB20: D6FF7C02 007A04FF 00005000
	.long 0xd7006a02                                           // 00000004CB2C: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000004CB30: 02020902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004CB34: BF870111
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000004CB38: D5207C03 01AA0680
	.long 0xd7006a04                                           // 00000004CB40: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 00000004CB44: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004CB4C: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 00000004CB50: D5207C05 01AA0680
	s_clause 0x1                                               // 00000004CB58: BF850001
	global_load_b128 v[74:77], v[2:3], off                     // 00000004CB5C: DC5E0000 4A7C0002
	global_load_b128 v[78:81], v[4:5], off                     // 00000004CB64: DC5E0000 4E7C0004
	.long 0xd4c3007e                                           // 00000004CB6C: D4C3007E
	v_cndmask_b32_e32 v1, s39, v6, vcc_lo                      // 00000004CB70: 02020C27
	s_cbranch_execz 11                                         // 00000004CB74: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11a4>
	s_waitcnt vmcnt(1)                                         // 00000004CB78: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 00000004CB7C: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004CB80: BF870001
	v_mov_b32_e32 v75, v76                                     // 00000004CB84: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 00000004CB88: 7E94034C
	s_waitcnt vmcnt(0)                                         // 00000004CB8C: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 00000004CB90: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 00000004CB94: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 00000004CB98: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 00000004CB9C: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 00000004CBA0: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s29                             // 00000004CBA4: 8C7E1D7E
	s_and_saveexec_b32 s29, s3                                 // 00000004CBA8: BE9D2003
	s_cbranch_execz 23                                         // 00000004CBAC: BFA50017 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x120c>
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v2, s4, v44      // 00000004CBB0: CA200080 03025804
	v_mov_b32_e32 v140, 0                                      // 00000004CBB8: 7F180280
	s_mov_b32 s3, exec_lo                                      // 00000004CBBC: BE83007E
	scratch_store_b32 off, v3, off                             // 00000004CBC0: DC690000 007C0300
	.long 0xd4c4007e                                           // 00000004CBC8: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000004CBCC: 02020427
	s_cbranch_execz 13                                         // 00000004CBD0: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1208>
	v_mad_i64_i32 v[3:4], null, 0xc0, v2, s[10:11]             // 00000004CBD4: D6FF7C03 002A04FF 000000C0
	v_mad_i64_i32 v[5:6], null, 0xc0, v2, s[34:35]             // 00000004CBE0: D6FF7C05 008A04FF 000000C0
	global_load_b32 v140, v[3:4], off                          // 00000004CBEC: DC520000 8C7C0003
	global_load_b32 v2, v[5:6], off                            // 00000004CBF4: DC520000 027C0005
	s_waitcnt vmcnt(0)                                         // 00000004CBFC: BF8903F7
	scratch_store_b32 off, v2, off                             // 00000004CC00: DC690000 007C0200
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004CC08: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000004CC0C: BF870499
	s_or_b32 exec_lo, exec_lo, s29                             // 00000004CC10: 8C7E1D7E
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 00000004CC14: 916A267E
	s_cbranch_vccnz 65459                                      // 00000004CC18: BFA4FFB3 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10e8>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 00000004CC1C: BE9C4D83
	s_and_b32 vcc_lo, exec_lo, s42                             // 00000004CC20: 8B6A2A7E
	s_mov_b32 s3, -1                                           // 00000004CC24: BE8300C1
	s_cbranch_vccz 80                                          // 00000004CC28: BFA30050 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x136c>
	v_and_b32_e32 v2, -16, v44                                 // 00000004CC2C: 360458D0
	s_mov_b32 s3, exec_lo                                      // 00000004CC30: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004CC34: BF870001
	v_cmpx_eq_u32_e32 64, v2                                   // 00000004CC38: 7D9404C0
	s_cbranch_execz 73                                         // 00000004CC3C: BFA50049 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1364>
	v_lshlrev_b32_e32 v4, 2, v44                               // 00000004CC40: 30085882
	s_waitcnt lgkmcnt(0)                                       // 00000004CC44: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004CC48: BF870001
	v_add_nc_u32_e32 v5, 0x5c00, v4                            // 00000004CC4C: 4A0A08FF 00005C00
	ds_load_2addr_b32 v[2:3], v5 offset0:64 offset1:80         // 00000004CC54: D8DC5040 02000005
	ds_load_b32 v6, v1 offset:24188                            // 00000004CC5C: D8D85E7C 06000001
	s_waitcnt lgkmcnt(1)                                       // 00000004CC64: BF89FC17
	v_mul_f32_e32 v7, 0x3fb8aa3b, v3                           // 00000004CC68: 100E06FF 3FB8AA3B
	ds_load_b32 v8, v4 offset:24128                            // 00000004CC70: D8D85E40 08000004
	s_waitcnt lgkmcnt(1)                                       // 00000004CC78: BF89FC17
	v_sub_f32_e32 v6, v6, v3                                   // 00000004CC7C: 080C0706
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000004CC80: 7C3606FF C2CE8ED0
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v7                          // 00000004CC88: D6130009 841E06FF 3FB8AA3B
	v_rndne_f32_e32 v10, v7                                    // 00000004CC94: 7E144707
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004CC98: BF870114
	v_mul_f32_e32 v11, 0x3fb8aa3b, v6                          // 00000004CC9C: 10160CFF 3FB8AA3B
	v_sub_f32_e32 v7, v7, v10                                  // 00000004CCA4: 080E1507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000004CCA8: BF8701C2
	v_fma_f32 v12, 0x3fb8aa3b, v6, -v11                        // 00000004CCAC: D613000C 842E0CFF 3FB8AA3B
	v_fmac_f32_e32 v9, 0x32a5705f, v3                          // 00000004CCB8: 561206FF 32A5705F
	v_cvt_i32_f32_e32 v10, v10                                 // 00000004CCC0: 7E14110A
	v_rndne_f32_e32 v13, v11                                   // 00000004CCC4: 7E1A470B
	v_dual_fmac_f32 v12, 0x32a5705f, v6 :: v_dual_add_f32 v7, v7, v9// 00000004CCC8: C8080CFF 0C061307 32A5705F
	s_waitcnt lgkmcnt(0)                                       // 00000004CCD4: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004CCD8: BF870112
	v_dual_sub_f32 v9, v11, v13 :: v_dual_mul_f32 v2, v8, v2   // 00000004CCDC: C9461B0B 09020508
	v_exp_f32_e32 v7, v7                                       // 00000004CCE4: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004CCE8: BF870125
	.long 0xd71c0007                                           // 00000004CCEC: D71C0007
	v_cndmask_b32_e32 v1, v7, v10, vcc_lo                      // 00000004CCF0: 02021507
	v_cvt_i32_f32_e32 v10, v13                                 // 00000004CCF4: 7E14110D
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo                        // 00000004CCF8: 020E0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000004CCFC: 7C3C06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000004CD04: BF8701B2
	v_cndmask_b32_e32 v3, 0x7f800000, v7, vcc_lo               // 00000004CD08: 02060EFF 7F800000
	v_add_f32_e32 v9, v9, v12                                  // 00000004CD10: 06121909
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v6                   // 00000004CD14: 7C360CFF C2CE8ED0
	v_mul_f32_e32 v2, v3, v2                                   // 00000004CD1C: 10040503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CD20: BF870093
	v_exp_f32_e32 v9, v9                                       // 00000004CD24: 7E124B09
	v_mul_f32_e32 v2, 0x41800000, v2                           // 00000004CD28: 100404FF 41800000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CD30: BF870095
	.long 0xd71c0009                                           // 00000004CD34: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000004CD38: 02021509
	v_cndmask_b32_e32 v7, 0, v9, vcc_lo                        // 00000004CD3C: 020E1280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v6                   // 00000004CD40: 7C3C0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004CD48: BF870002
	v_cndmask_b32_e32 v6, 0x7f800000, v7, vcc_lo               // 00000004CD4C: 020C0EFF 7F800000
	ds_store_b32 v4, v3 offset:24064                           // 00000004CD54: D8345E00 00000304
	ds_store_2addr_b32 v5, v6, v2 offset0:96 offset1:112       // 00000004CD5C: D8387060 00020605
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004CD64: 8C7E037E
	s_mov_b32 s3, 0                                            // 00000004CD68: BE830080
	v_lshrrev_b32_e32 v154, 4, v43                             // 00000004CD6C: 33345684
	v_mul_u32_u24_e32 v57, 0x110, v55                          // 00000004CD70: 16726EFF 00000110
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 00000004CD78: 916A037E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004CD7C: BF870002
	v_lshlrev_b32_e32 v56, 2, v154                             // 00000004CD80: 30713482
	s_cbranch_vccnz 871                                        // 00000004CD84: BFA40367 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2124>
	v_mad_u32_u24 v2, 0x110, v55, s49                          // 00000004CD88: D60B0002 00C66EFF 00000110
	s_and_b32 s3, s2, exec_lo                                  // 00000004CD94: 8B037E02
	s_cselect_b32 s3, 0, 0x1100                                // 00000004CD98: 9803FF80 00001100
	v_mad_u32_u24 v3, 0x110, v55, s50                          // 00000004CDA0: D60B0003 00CA6EFF 00000110
	ds_load_b128 v[10:13], v57 offset:6144                     // 00000004CDAC: DBFC1800 0A000039
	ds_load_b128 v[14:17], v57 offset:6160                     // 00000004CDB4: DBFC1810 0E000039
	v_add_nc_u32_e32 v4, s3, v2                                // 00000004CDBC: 4A080403
	v_mov_b32_e32 v8, v1                                       // 00000004CDC0: 7E100301
	s_waitcnt lgkmcnt(0)                                       // 00000004CDC4: BF89FC07
	v_mov_b32_e32 v5, v1                                       // 00000004CDC8: 7E0A0301
	v_cndmask_b32_e64 v45, v3, v2, s2                          // 00000004CDCC: D501002D 000A0503
	v_mov_b32_e32 v3, v1                                       // 00000004CDD4: 7E060301
	ds_load_b128 v[18:21], v4                                  // 00000004CDD8: DBFC0000 12000004
	ds_load_b128 v[22:25], v4 offset:16                        // 00000004CDE0: DBFC0010 16000004
	ds_load_b128 v[26:29], v57 offset:6176                     // 00000004CDE8: DBFC1820 1A000039
	ds_load_b128 v[30:33], v57 offset:6192                     // 00000004CDF0: DBFC1830 1E000039
	ds_load_b128 v[59:62], v45 offset:32                       // 00000004CDF8: DBFC0020 3B00002D
	ds_load_b128 v[63:66], v45 offset:48                       // 00000004CE00: DBFC0030 3F00002D
	ds_load_b128 v[155:158], v45 offset:64                     // 00000004CE08: DBFC0040 9B00002D
	ds_load_b128 v[159:162], v45 offset:80                     // 00000004CE10: DBFC0050 9F00002D
	ds_load_b128 v[167:170], v57 offset:6224                   // 00000004CE18: DBFC1850 A7000039
	ds_load_b128 v[163:166], v57 offset:6208                   // 00000004CE20: DBFC1840 A3000039
	v_mov_b32_e32 v2, v1                                       // 00000004CE28: 7E040301
	v_mov_b32_e32 v4, v1                                       // 00000004CE2C: 7E080301
	v_mov_b32_e32 v6, v1                                       // 00000004CE30: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000004CE34: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 00000004CE38: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004CE3C: BF870212
	v_mov_b32_e32 v8, v7                                       // 00000004CE40: 7E100307
	v_mov_b32_e32 v7, v6                                       // 00000004CE44: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 00000004CE48: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 00000004CE4C: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 00000004CE50: 7E080303
	v_mov_b32_e32 v3, v2                                       // 00000004CE54: 7E060302
	v_mov_b32_e32 v2, v1                                       // 00000004CE58: 7E040301
	ds_load_b128 v[175:178], v57 offset:6256                   // 00000004CE5C: DBFC1870 AF000039
	ds_load_b128 v[171:174], v57 offset:6240                   // 00000004CE64: DBFC1860 AB000039
	ds_load_b128 v[183:186], v45 offset:112                    // 00000004CE6C: DBFC0070 B700002D
	ds_load_b128 v[179:182], v45 offset:96                     // 00000004CE74: DBFC0060 B300002D
	v_or_b32_e32 v49, 6, v154                                  // 00000004CE7C: 38633486
	v_or_b32_e32 v48, 8, v154                                  // 00000004CE80: 38613488
	v_or_b32_e32 v47, 10, v154                                 // 00000004CE84: 385F348A
	s_waitcnt lgkmcnt(12)                                      // 00000004CE88: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 00000004CE8C: CC414002 1C0A1512
	ds_load_b128 v[14:17], v57 offset:6288                     // 00000004CE94: DBFC1890 0E000039
	ds_load_b128 v[10:13], v57 offset:6272                     // 00000004CE9C: DBFC1880 0A000039
	ds_load_b128 v[22:25], v45 offset:144                      // 00000004CEA4: DBFC0090 1600002D
	ds_load_b128 v[18:21], v45 offset:128                      // 00000004CEAC: DBFC0080 1200002D
	s_and_not1_b32 vcc_lo, exec_lo, s41                        // 00000004CEB4: 916A297E
	s_mov_b32 s3, -1                                           // 00000004CEB8: BE8300C1
	s_waitcnt lgkmcnt(12)                                      // 00000004CEBC: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[59:66], v[26:33], v[2:9]// 00000004CEC0: CC414002 1C0A353B
	ds_load_b128 v[30:33], v57 offset:6320                     // 00000004CEC8: DBFC18B0 1E000039
	ds_load_b128 v[26:29], v57 offset:6304                     // 00000004CED0: DBFC18A0 1A000039
	ds_load_b128 v[65:68], v45 offset:176                      // 00000004CED8: DBFC00B0 4100002D
	ds_load_b128 v[61:64], v45 offset:160                      // 00000004CEE0: DBFC00A0 3D00002D
	v_lshlrev_b32_e32 v60, 2, v55                              // 00000004CEE8: 30786E82
	v_or_b32_e32 v59, 4, v154                                  // 00000004CEEC: 38773484
	s_waitcnt lgkmcnt(12)                                      // 00000004CEF0: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[155:162], v[163:170], v[2:9]// 00000004CEF4: CC414002 1C0B479B
	ds_load_b128 v[159:162], v57 offset:6352                   // 00000004CEFC: DBFC18D0 9F000039
	ds_load_b128 v[155:158], v57 offset:6336                   // 00000004CF04: DBFC18C0 9B000039
	v_add_nc_u32_e32 v46, 64, v60                              // 00000004CF0C: 4A5C78C0
	ds_load_b128 v[167:170], v57 offset:6384                   // 00000004CF10: DBFC18F0 A7000039
	ds_load_b128 v[163:166], v57 offset:6368                   // 00000004CF18: DBFC18E0 A3000039
	s_waitcnt lgkmcnt(12)                                      // 00000004CF20: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[179:186], v[171:178], v[2:9]// 00000004CF24: CC414002 1C0B57B3
	ds_load_b128 v[175:178], v45 offset:208                    // 00000004CF2C: DBFC00D0 AF00002D
	ds_load_b128 v[171:174], v45 offset:192                    // 00000004CF34: DBFC00C0 AB00002D
	s_waitcnt lgkmcnt(10)                                      // 00000004CF3C: BF89FCA7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 00000004CF40: CC414002 1C0A1512
	v_add_nc_u32_e32 v10, 0x5c00, v56                          // 00000004CF48: 4A1470FF 00005C00
	v_add_nc_u32_e32 v11, s43, v56                             // 00000004CF50: 4A16702B
	ds_load_b128 v[183:186], v45 offset:240                    // 00000004CF54: DBFC00F0 B700002D
	ds_load_b128 v[179:182], v45 offset:224                    // 00000004CF5C: DBFC00E0 B300002D
	ds_load_2addr_stride64_b32 v[12:13], v46 offset0:94 offset1:95// 00000004CF64: D8E05F5E 0C00002E
	v_or_b32_e32 v46, 12, v154                                 // 00000004CF6C: 385D348C
	s_waitcnt lgkmcnt(9)                                       // 00000004CF70: BF89FC97
	v_wmma_f32_16x16x16_bf16 v[2:9], v[61:68], v[26:33], v[2:9]// 00000004CF74: CC414002 1C0A353D
	ds_load_2addr_b32 v[28:29], v10 offset0:144 offset1:146    // 00000004CF7C: D8DC9290 1C00000A
	ds_load_2addr_b32 v[24:25], v10 offset0:148 offset1:150    // 00000004CF84: D8DC9694 1800000A
	ds_load_2addr_b32 v[20:21], v10 offset0:152 offset1:154    // 00000004CF8C: D8DC9A98 1400000A
	ds_load_2addr_b32 v[16:17], v10 offset0:156 offset1:158    // 00000004CF94: D8DC9E9C 1000000A
	ds_load_2addr_b32 v[26:27], v11 offset1:2                  // 00000004CF9C: D8DC0200 1A00000B
	ds_load_2addr_b32 v[22:23], v11 offset0:4 offset1:6        // 00000004CFA4: D8DC0604 1600000B
	ds_load_2addr_b32 v[18:19], v11 offset0:8 offset1:10       // 00000004CFAC: D8DC0A08 1200000B
	ds_load_2addr_b32 v[14:15], v11 offset0:12 offset1:14      // 00000004CFB4: D8DC0E0C 0E00000B
	v_or_b32_e32 v61, 2, v154                                  // 00000004CFBC: 387B3482
	v_or_b32_e32 v45, 14, v154                                 // 00000004CFC0: 385B348E
	s_waitcnt lgkmcnt(11)                                      // 00000004CFC4: BF89FCB7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[171:178], v[155:162], v[2:9]// 00000004CFC8: CC414002 1C0B37AB
	s_waitcnt lgkmcnt(9)                                       // 00000004CFD0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004CFD4: BF870001
	v_wmma_f32_16x16x16_bf16 v[2:9], v[179:186], v[163:170], v[2:9]// 00000004CFD8: CC414002 1C0B47B3
	s_cbranch_vccnz 353                                        // 00000004CFE0: BFA40161 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b68>
	.long 0x7e143880                                           // 00000004CFE4: 7E143880
	s_mov_b32 s3, exec_lo                                      // 00000004CFE8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004CFEC: BF870001
	.long 0x7f14390a                                           // 00000004CFF0: 7F14390A
	.long 0xd4cb007e                                           // 00000004CFF4: D4CB007E
	v_cndmask_b32_e32 v1, v55, v154, vcc_lo                    // 00000004CFF8: 02033537
	s_cbranch_execz 34                                         // 00000004CFFC: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1688>
	s_waitcnt lgkmcnt(7)                                       // 00000004D000: BF89FC77
	v_sub_f32_e32 v11, v28, v12                                // 00000004D004: 0816191C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D008: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v11                         // 00000004D00C: 103C16FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v11, -v30                       // 00000004D014: D613001F 847A16FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 00000004D020: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D024: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v11 :: v_dual_sub_f32 v30, v30, v32// 00000004D028: C80A16FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 00000004D034: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 00000004D038: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000004D03C: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004D044: BF870293
	v_exp_f32_e32 v30, v30                                     // 00000004D048: 7E3C4B1E
	.long 0xd71c001e                                           // 00000004D04C: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 00000004D050: 02023F1E
	s_waitcnt lgkmcnt(3)                                       // 00000004D054: BF89FC37
	v_mul_f32_e32 v31, v2, v26                                 // 00000004D058: 103E3502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D05C: BF870122
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 00000004D060: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000004D064: 7C3C16FF 42B17218
	v_dual_cndmask_b32 v11, 0x7f800000, v30 :: v_dual_mul_f32 v30, v13, v31// 00000004D06C: CA463CFF 0B1E3F0D 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D078: BF870091
	v_mul_f32_e32 v11, v11, v30                                // 00000004D07C: 10163D0B
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 00000004D080: CC22000A 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004D088: 8C7E037E
	v_mul_u32_u24_e32 v11, 48, v154                            // 00000004D08C: 161734B0
	s_mov_b32 s3, exec_lo                                      // 00000004D090: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004D094: BF870001
	v_lshl_add_u32 v11, v55, 1, v11                            // 00000004D098: D646000B 042D0337
	ds_store_b16_d16_hi v11, v10 offset:23296                  // 00000004D0A0: DA845B00 00000A0B
	.long 0xd4cb007e                                           // 00000004D0A8: D4CB007E
	v_cndmask_b32_e32 v1, v55, v61, vcc_lo                     // 00000004D0AC: 02027B37
	s_cbranch_execz 34                                         // 00000004D0B0: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x173c>
	s_waitcnt lgkmcnt(8)                                       // 00000004D0B4: BF89FC87
	v_sub_f32_e32 v10, v29, v12                                // 00000004D0B8: 0814191D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D0BC: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v10                         // 00000004D0C0: 103C14FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v30                       // 00000004D0C8: D613001F 847A14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 00000004D0D4: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D0D8: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v10 :: v_dual_sub_f32 v30, v30, v32// 00000004D0DC: C80A14FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 00000004D0E8: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 00000004D0EC: 7E3E1120
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004D0F0: BF870292
	v_exp_f32_e32 v30, v30                                     // 00000004D0F4: 7E3C4B1E
	.long 0xd71c001e                                           // 00000004D0F8: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 00000004D0FC: 02023F1E
	s_waitcnt lgkmcnt(4)                                       // 00000004D100: BF89FC47
	v_mul_f32_e32 v31, v3, v27                                 // 00000004D104: 103E3703
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000004D108: 7C3614FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D110: BF870123
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 00000004D114: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000004D118: 7C3C14FF 42B17218
	v_cndmask_b32_e32 v10, 0x7f800000, v30, vcc_lo             // 00000004D120: 02143CFF 7F800000
	v_mul_f32_e32 v30, v13, v31                                // 00000004D128: 103C3F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D12C: BF870091
	v_mul_f32_e32 v10, v10, v30                                // 00000004D130: 10143D0A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 00000004D134: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004D13C: 8C7E037E
	.long 0x7f143880                                           // 00000004D140: 7F143880
	v_or_b32_e32 v30, 0x5b00, v11                              // 00000004D144: 383C16FF 00005B00
	s_mov_b32 s3, exec_lo                                      // 00000004D14C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004D150: BF870002
	.long 0x7e16398a                                           // 00000004D154: 7E16398A
	ds_store_b16 v30, v10 offset:96                            // 00000004D158: D87C0060 00000A1E
	.long 0xd4cb007e                                           // 00000004D160: D4CB007E
	v_cndmask_b32_e32 v1, v55, v59, vcc_lo                     // 00000004D164: 02027737
	s_cbranch_execz 35                                         // 00000004D168: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x17f8>
	s_waitcnt lgkmcnt(8)                                       // 00000004D16C: BF89FC87
	v_sub_f32_e32 v11, v24, v12                                // 00000004D170: 08161918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D174: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 00000004D178: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000004D180: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 00000004D188: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000004D194: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D198: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 00000004D19C: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 00000004D1A8: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 00000004D1AC: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004D1B0: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000004D1B4: 7E3E4B1F
	.long 0xd71c001f                                           // 00000004D1B8: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000004D1BC: 0202411F
	s_waitcnt lgkmcnt(4)                                       // 00000004D1C0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D1C4: BF870121
	v_dual_mul_f32 v32, v4, v22 :: v_dual_cndmask_b32 v31, 0, v31// 00000004D1C8: C8D22D04 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000004D1D0: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000004D1D8: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D1E0: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 00000004D1E4: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 00000004D1E8: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004D1EC: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 00000004D1F0: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004D1F8: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004D1FC: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000004D200: BE83007E
	ds_store_b16 v30, v11 offset:192                           // 00000004D204: D87C00C0 00000B1E
	.long 0xd4cb007e                                           // 00000004D20C: D4CB007E
	v_cndmask_b32_e32 v1, v55, v49, vcc_lo                     // 00000004D210: 02026337
	s_cbranch_execz 35                                         // 00000004D214: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x18a4>
	s_waitcnt lgkmcnt(9)                                       // 00000004D218: BF89FC97
	v_sub_f32_e32 v10, v25, v12                                // 00000004D21C: 08141919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D220: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000004D224: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 00000004D22C: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 00000004D238: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004D23C: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 00000004D240: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 00000004D248: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000004D24C: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 00000004D250: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000004D254: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000004D258: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 00000004D260: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000004D264: BF870135
	.long 0xd71c000b                                           // 00000004D268: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 00000004D26C: 02023F0B
	s_waitcnt lgkmcnt(5)                                       // 00000004D270: BF89FC57
	v_mul_f32_e32 v31, v5, v23                                 // 00000004D274: 103E2F05
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 00000004D278: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000004D27C: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004D284: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 00000004D288: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000004D290: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D294: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 00000004D298: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 00000004D29C: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004D2A4: 8C7E037E
	.long 0x7e143880                                           // 00000004D2A8: 7E143880
	s_mov_b32 s3, exec_lo                                      // 00000004D2AC: BE83007E
	ds_store_b16_d16_hi v30, v10 offset:288                    // 00000004D2B0: DA840120 00000A1E
	.long 0x7e16390a                                           // 00000004D2B8: 7E16390A
	.long 0xd4cb007e                                           // 00000004D2BC: D4CB007E
	v_cndmask_b32_e32 v1, v55, v48, vcc_lo                     // 00000004D2C0: 02026137
	s_cbranch_execz 34                                         // 00000004D2C4: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1950>
	s_waitcnt lgkmcnt(9)                                       // 00000004D2C8: BF89FC97
	v_sub_f32_e32 v11, v20, v12                                // 00000004D2CC: 08161914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D2D0: BF870091
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 00000004D2D4: 103E16FF 3FB8AA3B
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 00000004D2DC: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000004D2E8: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D2EC: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 00000004D2F0: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 00000004D2FC: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 00000004D300: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004D304: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000004D308: 7E3E4B1F
	.long 0xd71c001f                                           // 00000004D30C: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000004D310: 0202411F
	s_waitcnt lgkmcnt(5)                                       // 00000004D314: BF89FC57
	v_mul_f32_e32 v32, v6, v18                                 // 00000004D318: 10402506
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000004D31C: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D324: BF870123
	v_cndmask_b32_e32 v31, 0, v31, vcc_lo                      // 00000004D328: 023E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000004D32C: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000004D334: 02163EFF 7F800000
	v_mul_f32_e32 v31, v13, v32                                // 00000004D33C: 103E410D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D340: BF870091
	v_mul_f32_e32 v11, v11, v31                                // 00000004D344: 10163F0B
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 00000004D348: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004D350: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004D354: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000004D358: BE83007E
	ds_store_b16 v30, v11 offset:384                           // 00000004D35C: D87C0180 00000B1E
	.long 0xd4cb007e                                           // 00000004D364: D4CB007E
	v_cndmask_b32_e32 v1, v55, v47, vcc_lo                     // 00000004D368: 02025F37
	s_cbranch_execz 35                                         // 00000004D36C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x19fc>
	s_waitcnt lgkmcnt(10)                                      // 00000004D370: BF89FCA7
	v_sub_f32_e32 v10, v21, v12                                // 00000004D374: 08141915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D378: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000004D37C: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 00000004D384: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 00000004D390: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004D394: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 00000004D398: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 00000004D3A0: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000004D3A4: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 00000004D3A8: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000004D3AC: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000004D3B0: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 00000004D3B8: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000004D3BC: BF870135
	.long 0xd71c000b                                           // 00000004D3C0: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 00000004D3C4: 02023F0B
	s_waitcnt lgkmcnt(6)                                       // 00000004D3C8: BF89FC67
	v_mul_f32_e32 v31, v7, v19                                 // 00000004D3CC: 103E2707
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 00000004D3D0: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000004D3D4: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004D3DC: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 00000004D3E0: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000004D3E8: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D3EC: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 00000004D3F0: 1014170A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 00000004D3F4: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004D3FC: 8C7E037E
	.long 0x7f143880                                           // 00000004D400: 7F143880
	s_mov_b32 s3, exec_lo                                      // 00000004D404: BE83007E
	ds_store_b16 v30, v10 offset:480                           // 00000004D408: D87C01E0 00000A1E
	.long 0x7e16398a                                           // 00000004D410: 7E16398A
	.long 0xd4cb007e                                           // 00000004D414: D4CB007E
	v_cndmask_b32_e32 v1, v55, v46, vcc_lo                     // 00000004D418: 02025D37
	s_cbranch_execz 35                                         // 00000004D41C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1aac>
	s_waitcnt lgkmcnt(10)                                      // 00000004D420: BF89FCA7
	v_sub_f32_e32 v11, v16, v12                                // 00000004D424: 08161910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D428: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 00000004D42C: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000004D434: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 00000004D43C: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000004D448: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D44C: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 00000004D450: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 00000004D45C: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 00000004D460: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004D464: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000004D468: 7E3E4B1F
	.long 0xd71c001f                                           // 00000004D46C: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000004D470: 0202411F
	s_waitcnt lgkmcnt(6)                                       // 00000004D474: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D478: BF870121
	v_dual_mul_f32 v32, v8, v14 :: v_dual_cndmask_b32 v31, 0, v31// 00000004D47C: C8D21D08 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000004D484: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000004D48C: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D494: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 00000004D498: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 00000004D49C: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004D4A0: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 00000004D4A4: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004D4AC: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004D4B0: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000004D4B4: BE83007E
	ds_store_b16 v30, v11 offset:576                           // 00000004D4B8: D87C0240 00000B1E
	.long 0xd4cb007e                                           // 00000004D4C0: D4CB007E
	v_cndmask_b32_e32 v1, v55, v45, vcc_lo                     // 00000004D4C4: 02025B37
	s_cbranch_execz 35                                         // 00000004D4C8: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b58>
	s_waitcnt lgkmcnt(11)                                      // 00000004D4CC: BF89FCB7
	v_sub_f32_e32 v10, v17, v12                                // 00000004D4D0: 08141911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D4D4: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000004D4D8: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 00000004D4E0: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 00000004D4EC: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004D4F0: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 00000004D4F4: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 00000004D4FC: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000004D500: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 00000004D504: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000004D508: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000004D50C: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 00000004D514: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000004D518: BF870135
	.long 0xd71c000b                                           // 00000004D51C: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 00000004D520: 02023F0B
	s_waitcnt lgkmcnt(7)                                       // 00000004D524: BF89FC77
	v_mul_f32_e32 v31, v9, v15                                 // 00000004D528: 103E1F09
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 00000004D52C: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000004D530: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004D538: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 00000004D53C: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000004D544: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D548: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 00000004D54C: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 00000004D550: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004D558: 8C7E037E
	s_mov_b32 s3, 0                                            // 00000004D55C: BE830080
	ds_store_b16_d16_hi v30, v10 offset:672                    // 00000004D560: DA8402A0 00000A1E
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000004D568: 8B6A037E
	s_cbranch_vccz 365                                         // 00000004D56C: BFA3016D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2124>
	v_or_b32_e32 v10, 0x5e40, v56                              // 00000004D570: 381470FF 00005E40
	v_mov_b32_e32 v63, 0                                       // 00000004D578: 7E7E0280
	v_mov_b32_e32 v65, 0                                       // 00000004D57C: 7E820280
	s_mov_b32 s3, exec_lo                                      // 00000004D580: BE83007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000004D584: BF870003
	v_subrev_nc_u32_e32 v64, 64, v10                           // 00000004D588: 4E8014C0
	ds_load_2addr_b32 v[32:33], v64 offset0:2 offset1:4        // 00000004D58C: D8DC0402 20000040
	ds_load_2addr_b32 v[30:31], v64 offset0:6 offset1:8        // 00000004D594: D8DC0806 1E000040
	ds_load_2addr_b32 v[10:11], v64 offset0:10 offset1:12      // 00000004D59C: D8DC0C0A 0A000040
	ds_load_b32 v62, v64 offset:56                             // 00000004D5A4: D8D80038 3E000040
	.long 0xd4c9007e                                           // 00000004D5AC: D4C9007E
	v_cndmask_b32_e32 v1, v55, v154, vcc_lo                    // 00000004D5B0: 02033537
	s_cbranch_execz 37                                         // 00000004D5B4: BFA50025 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1c4c>
	s_waitcnt lgkmcnt(11)                                      // 00000004D5B8: BF89FCB7
	v_sub_f32_e32 v28, v28, v12                                // 00000004D5BC: 0838191C
	ds_load_b32 v64, v64                                       // 00000004D5C0: D8D80000 40000040
	s_waitcnt lgkmcnt(8)                                       // 00000004D5C8: BF89FC87
	v_dual_mul_f32 v2, v2, v26 :: v_dual_mul_f32 v65, 0x3fb8aa3b, v28// 00000004D5CC: C8C63502 024038FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004D5D8: BF870111
	v_mul_f32_e32 v2, v13, v2                                  // 00000004D5DC: 1004050D
	v_fma_f32 v66, 0x3fb8aa3b, v28, -v65                       // 00000004D5E0: D6130042 850638FF 3FB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000004D5EC: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000004D5F0: BF8701C1
	v_dual_sub_f32 v65, v65, v67 :: v_dual_fmac_f32 v66, 0x32a5705f, v28// 00000004D5F4: C9408741 414238FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v28                  // 00000004D600: 7C3638FF C2CE8ED0
	s_waitcnt lgkmcnt(0)                                       // 00000004D608: BF89FC07
	v_mul_f32_e32 v2, v64, v2                                  // 00000004D60C: 10040540
	v_add_f32_e32 v65, v65, v66                                // 00000004D610: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000004D614: 7E841143
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004D618: BF870292
	v_exp_f32_e32 v65, v65                                     // 00000004D61C: 7E824B41
	.long 0xd71c0041                                           // 00000004D620: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000004D624: 02028541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D628: BF870121
	v_cndmask_b32_e32 v26, 0, v65, vcc_lo                      // 00000004D62C: 02348280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v28                  // 00000004D630: 7C3C38FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 00000004D638: 023434FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004D640: BF870001
	.long 0xd5080041                                           // 00000004D644: D5080041
	v_sub_co_ci_u32_e32 v1, vcc_lo, v2, v26, vcc_lo            // 00000004D648: 42023502
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004D64C: 8C7E037E
	v_or_b32_e32 v2, 0x5e40, v60                               // 00000004D650: 380478FF 00005E40
	s_waitcnt lgkmcnt(7)                                       // 00000004D658: BF89FC77
	v_lshlrev_b32_e32 v26, 6, v154                             // 00000004D65C: 30353486
	s_mov_b32 s3, exec_lo                                      // 00000004D660: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004D664: BF870001
	v_add3_u32 v2, v2, v26, 0xfffff8c0                         // 00000004D668: D6550002 03FE3502 FFFFF8C0
	ds_store_b32 v2, v65                                       // 00000004D674: D8340000 00004102
	.long 0xd4c9007e                                           // 00000004D67C: D4C9007E
	v_cndmask_b32_e32 v1, v55, v61, vcc_lo                     // 00000004D680: 02027B37
	s_cbranch_execz 33                                         // 00000004D684: BFA50021 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1d0c>
	v_dual_sub_f32 v26, v29, v12 :: v_dual_mul_f32 v3, v3, v27 // 00000004D688: C946191D 1A023703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D690: BF870121
	v_dual_mul_f32 v28, 0x3fb8aa3b, v26 :: v_dual_mul_f32 v3, v13, v3// 00000004D694: C8C634FF 1C02070D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v26                  // 00000004D6A0: 7C3634FF C2CE8ED0
	v_fma_f32 v29, 0x3fb8aa3b, v26, -v28                       // 00000004D6A8: D613001D 847234FF 3FB8AA3B
	v_rndne_f32_e32 v60, v28                                   // 00000004D6B4: 7E78471C
	s_waitcnt lgkmcnt(4)                                       // 00000004D6B8: BF89FC47
	v_mul_f32_e32 v3, v32, v3                                  // 00000004D6BC: 10060720
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D6C0: BF870092
	v_dual_fmac_f32 v29, 0x32a5705f, v26 :: v_dual_sub_f32 v28, v28, v60// 00000004D6C4: C80A34FF 1D1C791C 32A5705F
	v_add_f32_e32 v28, v28, v29                                // 00000004D6D0: 06383B1C
	v_cvt_i32_f32_e32 v29, v60                                 // 00000004D6D4: 7E3A113C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004D6D8: BF870292
	v_exp_f32_e32 v28, v28                                     // 00000004D6DC: 7E384B1C
	.long 0xd71c001c                                           // 00000004D6E0: D71C001C
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                     // 00000004D6E4: 02023B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D6E8: BF870121
	v_cndmask_b32_e32 v27, 0, v28, vcc_lo                      // 00000004D6EC: 02363880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v26                  // 00000004D6F0: 7C3C34FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v27, vcc_lo             // 00000004D6F8: 023436FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004D700: BF870001
	.long 0xd508003f                                           // 00000004D704: D508003F
	v_sub_co_ci_u32_e32 v1, vcc_lo, v3, v26, vcc_lo            // 00000004D708: 42023503
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004D70C: 8C7E037E
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v26, 0              // 00000004D710: CA100080 031A0080
	s_mov_b32 s3, exec_lo                                      // 00000004D718: BE83007E
	ds_store_b32 v2, v63 offset:128                            // 00000004D71C: D8340080 00003F02
	.long 0xd4c9007e                                           // 00000004D724: D4C9007E
	v_cndmask_b32_e32 v1, v55, v59, vcc_lo                     // 00000004D728: 02027737
	s_cbranch_execz 35                                         // 00000004D72C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1dbc>
	v_sub_f32_e32 v24, v24, v12                                // 00000004D730: 08301918
	s_waitcnt lgkmcnt(8)                                       // 00000004D734: BF89FC87
	v_mul_f32_e32 v4, v4, v22                                  // 00000004D738: 10082D04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000004D73C: BF8701A2
	v_mul_f32_e32 v26, 0x3fb8aa3b, v24                         // 00000004D740: 103430FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v24                  // 00000004D748: 7C3630FF C2CE8ED0
	v_mul_f32_e32 v4, v13, v4                                  // 00000004D750: 1008090D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000004D754: BF8701B3
	v_fma_f32 v27, 0x3fb8aa3b, v24, -v26                       // 00000004D758: D613001B 846A30FF 3FB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000004D764: 7E38471A
	s_waitcnt lgkmcnt(5)                                       // 00000004D768: BF89FC57
	v_mul_f32_e32 v4, v33, v4                                  // 00000004D76C: 10080921
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000004D770: BF870193
	v_fmac_f32_e32 v27, 0x32a5705f, v24                        // 00000004D774: 563630FF 32A5705F
	v_sub_f32_e32 v26, v26, v28                                // 00000004D77C: 0834391A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D780: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000004D784: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000004D788: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000004D78C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D790: BF870095
	.long 0xd71c001a                                           // 00000004D794: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000004D798: 0202371A
	v_cndmask_b32_e32 v22, 0, v26, vcc_lo                      // 00000004D79C: 022C3480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v24                  // 00000004D7A0: 7C3C30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D7A8: BF870092
	v_cndmask_b32_e32 v22, 0x7f800000, v22, vcc_lo             // 00000004D7AC: 022C2CFF 7F800000
	.long 0xd508001a                                           // 00000004D7B4: D508001A
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v22, vcc_lo            // 00000004D7B8: 42022D04
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004D7BC: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004D7C0: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000004D7C4: BE83007E
	ds_store_b32 v2, v26 offset:256                            // 00000004D7C8: D8340100 00001A02
	.long 0xd4c9007e                                           // 00000004D7D0: D4C9007E
	v_cndmask_b32_e32 v1, v55, v49, vcc_lo                     // 00000004D7D4: 02026337
	s_cbranch_execz 34                                         // 00000004D7D8: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1e64>
	v_sub_f32_e32 v3, v25, v12                                 // 00000004D7DC: 08061919
	s_waitcnt lgkmcnt(9)                                       // 00000004D7E0: BF89FC97
	v_mul_f32_e32 v5, v5, v23                                  // 00000004D7E4: 100A2F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D7E8: BF870091
	v_dual_mul_f32 v4, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, v13, v5// 00000004D7EC: C8C606FF 04040B0D 3FB8AA3B
	v_fma_f32 v22, 0x3fb8aa3b, v3, -v4                         // 00000004D7F8: D6130016 841206FF 3FB8AA3B
	v_rndne_f32_e32 v24, v4                                    // 00000004D804: 7E304704
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004D808: BF870112
	v_fmac_f32_e32 v22, 0x32a5705f, v3                         // 00000004D80C: 562C06FF 32A5705F
	v_sub_f32_e32 v4, v4, v24                                  // 00000004D814: 08083104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000004D818: BF8701B1
	v_add_f32_e32 v4, v4, v22                                  // 00000004D81C: 06082D04
	v_cvt_i32_f32_e32 v22, v24                                 // 00000004D820: 7E2C1118
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000004D824: 7C3606FF C2CE8ED0
	v_exp_f32_e32 v4, v4                                       // 00000004D82C: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D830: BF870095
	.long 0xd71c0004                                           // 00000004D834: D71C0004
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 00000004D838: 02022D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 00000004D83C: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000004D840: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(5)                                       // 00000004D848: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D84C: BF870092
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v30, v5// 00000004D850: CA4608FF 03040B1E 7F800000
	.long 0xd5080003                                           // 00000004D85C: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000004D860: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004D864: 8C7E037E
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 00000004D868: CA100080 04040080
	s_mov_b32 s3, exec_lo                                      // 00000004D870: BE83007E
	ds_store_b32 v2, v3 offset:384                             // 00000004D874: D8340180 00000302
	.long 0xd4c9007e                                           // 00000004D87C: D4C9007E
	v_cndmask_b32_e32 v1, v55, v48, vcc_lo                     // 00000004D880: 02026137
	s_cbranch_execz 34                                         // 00000004D884: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1f10>
	s_waitcnt lgkmcnt(9)                                       // 00000004D888: BF89FC97
	v_dual_sub_f32 v3, v20, v12 :: v_dual_mul_f32 v6, v6, v18  // 00000004D88C: C9461914 03062506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D894: BF870121
	v_dual_mul_f32 v5, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v6, v13, v6// 00000004D898: C8C606FF 05060D0D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000004D8A4: 7C3606FF C2CE8ED0
	v_fma_f32 v20, 0x3fb8aa3b, v3, -v5                         // 00000004D8AC: D6130014 841606FF 3FB8AA3B
	v_rndne_f32_e32 v22, v5                                    // 00000004D8B8: 7E2C4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D8BC: BF870091
	v_dual_fmac_f32 v20, 0x32a5705f, v3 :: v_dual_sub_f32 v5, v5, v22// 00000004D8C0: C80A06FF 14042D05 32A5705F
	v_add_f32_e32 v5, v5, v20                                  // 00000004D8CC: 060A2905
	v_cvt_i32_f32_e32 v20, v22                                 // 00000004D8D0: 7E281116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004D8D4: BF870292
	v_exp_f32_e32 v5, v5                                       // 00000004D8D8: 7E0A4B05
	.long 0xd71c0005                                           // 00000004D8DC: D71C0005
	v_cndmask_b32_e32 v1, v5, v20, vcc_lo                      // 00000004D8E0: 02022905
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D8E4: BF870121
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo                        // 00000004D8E8: 020A0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000004D8EC: 7C3C06FF 42B17218
	v_cndmask_b32_e32 v3, 0x7f800000, v5, vcc_lo               // 00000004D8F4: 02060AFF 7F800000
	s_waitcnt lgkmcnt(6)                                       // 00000004D8FC: BF89FC67
	v_mul_f32_e32 v5, v31, v6                                  // 00000004D900: 100A0D1F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004D904: BF870001
	.long 0xd5080005                                           // 00000004D908: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v3, vcc_lo             // 00000004D90C: 42020705
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004D910: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004D914: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000004D918: BE83007E
	ds_store_b32 v2, v5 offset:512                             // 00000004D91C: D8340200 00000502
	.long 0xd4c9007e                                           // 00000004D924: D4C9007E
	v_cndmask_b32_e32 v1, v55, v47, vcc_lo                     // 00000004D928: 02025F37
	s_cbranch_execz 35                                         // 00000004D92C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1fbc>
	v_sub_f32_e32 v3, v21, v12                                 // 00000004D930: 08061915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D934: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 00000004D938: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 00000004D940: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 00000004D94C: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004D950: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 00000004D954: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000004D958: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 00000004D960: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D968: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 00000004D96C: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 00000004D970: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 00000004D974: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004D978: BF8700A5
	.long 0xd71c0004                                           // 00000004D97C: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 00000004D980: 02020B04
	s_waitcnt lgkmcnt(10)                                      // 00000004D984: BF89FCA7
	v_dual_mul_f32 v5, v7, v19 :: v_dual_cndmask_b32 v4, 0, v4 // 00000004D988: C8D22707 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000004D990: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 00000004D994: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000004D998: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(6)                                       // 00000004D9A0: BF89FC67
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v10, v5// 00000004D9A4: CA4608FF 03040B0A 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004D9B0: BF870001
	.long 0xd5080004                                           // 00000004D9B4: D5080004
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000004D9B8: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004D9BC: 8C7E037E
	v_mov_b32_e32 v3, 0                                        // 00000004D9C0: 7E060280
	v_mov_b32_e32 v5, 0                                        // 00000004D9C4: 7E0A0280
	s_mov_b32 s3, exec_lo                                      // 00000004D9C8: BE83007E
	ds_store_b32 v2, v4 offset:640                             // 00000004D9CC: D8340280 00000402
	.long 0xd4c9007e                                           // 00000004D9D4: D4C9007E
	v_cndmask_b32_e32 v1, v55, v46, vcc_lo                     // 00000004D9D8: 02025D37
	s_cbranch_execz 35                                         // 00000004D9DC: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x206c>
	v_sub_f32_e32 v4, v16, v12                                 // 00000004D9E0: 08081910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D9E4: BF870091
	v_mul_f32_e32 v5, 0x3fb8aa3b, v4                           // 00000004D9E8: 100A08FF 3FB8AA3B
	v_fma_f32 v6, 0x3fb8aa3b, v4, -v5                          // 00000004D9F0: D6130006 841608FF 3FB8AA3B
	v_rndne_f32_e32 v7, v5                                     // 00000004D9FC: 7E0E4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004DA00: BF870221
	v_sub_f32_e32 v5, v5, v7                                   // 00000004DA04: 080A0F05
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 00000004DA08: 7C3608FF C2CE8ED0
	v_fmac_f32_e32 v6, 0x32a5705f, v4                          // 00000004DA10: 560C08FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004DA18: BF870121
	v_add_f32_e32 v5, v5, v6                                   // 00000004DA1C: 060A0D05
	v_cvt_i32_f32_e32 v6, v7                                   // 00000004DA20: 7E0C1107
	v_exp_f32_e32 v5, v5                                       // 00000004DA24: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004DA28: BF8700A5
	.long 0xd71c0005                                           // 00000004DA2C: D71C0005
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 00000004DA30: 02020D05
	s_waitcnt lgkmcnt(10)                                      // 00000004DA34: BF89FCA7
	v_dual_mul_f32 v6, v8, v14 :: v_dual_cndmask_b32 v5, 0, v5 // 00000004DA38: C8D21D08 06040A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000004DA40: BF870131
	v_mul_f32_e32 v6, v13, v6                                  // 00000004DA44: 100C0D0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 00000004DA48: 7C3C08FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 00000004DA50: BF89FC77
	v_dual_cndmask_b32 v4, 0x7f800000, v5 :: v_dual_mul_f32 v5, v11, v6// 00000004DA54: CA460AFF 04040D0B 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004DA60: BF870001
	.long 0xd5080005                                           // 00000004DA64: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v4, vcc_lo             // 00000004DA68: 42020905
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004DA6C: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004DA70: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000004DA74: BE83007E
	ds_store_b32 v2, v5 offset:768                             // 00000004DA78: D8340300 00000502
	.long 0xd4c9007e                                           // 00000004DA80: D4C9007E
	v_cndmask_b32_e32 v1, v55, v45, vcc_lo                     // 00000004DA84: 02025B37
	s_cbranch_execz 35                                         // 00000004DA88: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2118>
	v_sub_f32_e32 v3, v17, v12                                 // 00000004DA8C: 08061911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DA90: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 00000004DA94: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 00000004DA9C: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 00000004DAA8: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004DAAC: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 00000004DAB0: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000004DAB4: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 00000004DABC: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004DAC4: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 00000004DAC8: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 00000004DACC: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 00000004DAD0: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004DAD4: BF8700A5
	.long 0xd71c0004                                           // 00000004DAD8: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 00000004DADC: 02020B04
	s_waitcnt lgkmcnt(11)                                      // 00000004DAE0: BF89FCB7
	v_dual_mul_f32 v5, v9, v15 :: v_dual_cndmask_b32 v4, 0, v4 // 00000004DAE4: C8D21F09 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000004DAEC: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 00000004DAF0: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000004DAF4: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 00000004DAFC: BF89FC77
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v62, v5// 00000004DB00: CA4608FF 03040B3E 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004DB0C: BF870001
	.long 0xd5080003                                           // 00000004DB10: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000004DB14: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004DB18: 8C7E037E
	ds_store_b32 v2, v3 offset:896                             // 00000004DB1C: D8340380 00000302
	s_waitcnt lgkmcnt(0)                                       // 00000004DB24: BF89FC07
	s_barrier                                                  // 00000004DB28: BFBD0000
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 00000004DB2C: 916A267E
	s_cbranch_vccz 6                                           // 00000004DB30: BFA30006 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x214c>
	s_and_b32 vcc_lo, exec_lo, s41                             // 00000004DB34: 8B6A297E
	s_mov_b32 s3, -1                                           // 00000004DB38: BE8300C1
	s_cbranch_vccnz 11                                         // 00000004DB3C: BFA4000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x216c>
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 00000004DB40: 916A037E
	s_cbranch_vccz 184                                         // 00000004DB44: BFA300B8 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2428>
	s_branch 716                                               // 00000004DB48: BFA002CC <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c7c>
	s_sendmsg_rtn_b64 s[56:57], sendmsg(MSG_RTN_GET_REALTIME)  // 00000004DB4C: BEB84D83
	s_waitcnt lgkmcnt(0)                                       // 00000004DB50: BF89FC07
	s_sub_i32 s3, s6, s28                                      // 00000004DB54: 81831C06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004DB58: BF870009
	s_add_i32 s6, s3, s56                                      // 00000004DB5C: 81063803
	s_and_b32 vcc_lo, exec_lo, s41                             // 00000004DB60: 8B6A297E
	s_mov_b32 s3, -1                                           // 00000004DB64: BE8300C1
	s_cbranch_vccz 65525                                       // 00000004DB68: BFA3FFF5 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2140>
	s_mov_b32 s3, exec_lo                                      // 00000004DB6C: BE83007E
	v_cmpx_gt_i32_e32 0x120, v44                               // 00000004DB70: 7D8858FF 00000120
	s_cbranch_execz 169                                        // 00000004DB78: BFA500A9 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2420>
	v_add_nc_u32_e32 v2, 0xffffff00, v44                       // 00000004DB7C: 4A0458FF FFFFFF00
	s_mov_b32 s4, 0                                            // 00000004DB84: BE840080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004DB88: BF870001
	v_mov_b32_e32 v3, v2                                       // 00000004DB8C: 7E060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004DB90: BF8700A1
	v_add_nc_u32_e32 v3, 0xe0, v3                              // 00000004DB94: 4A0606FF 000000E0
	s_waitcnt lgkmcnt(0)                                       // 00000004DB9C: BF89FC07
	v_ashrrev_i32_e32 v16, 7, v3                               // 00000004DBA0: 34200687
	v_and_b32_e32 v12, 0x7f, v3                                // 00000004DBA4: 361806FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DBAC: BF870092
	.long 0xd72c0004                                           // 00000004DBB0: D72C0004
	v_cndmask_b32_e32 v1, 0x880, v16, vcc_lo                   // 00000004DBB4: 020220FF 00000880
	v_lshl_add_u32 v4, v12, 1, v4                              // 00000004DBBC: D6460004 0411030C
	ds_load_u16 v20, v4 offset:7776                            // 00000004DBC4: D8F01E60 14000004
	ds_load_u16 v21, v4 offset:7232                            // 00000004DBCC: D8F01C40 15000004
	ds_load_u16 v22, v4 offset:6688                            // 00000004DBD4: D8F01A20 16000004
	ds_load_u16 v23, v4 offset:6144                            // 00000004DBDC: D8F01800 17000004
	ds_load_u16 v24, v4 offset:6416                            // 00000004DBE4: D8F01910 18000004
	s_waitcnt lgkmcnt(3)                                       // 00000004DBEC: BF89FC37
	v_lshlrev_b32_e32 v21, 16, v21                             // 00000004DBF0: 302A2A90
	s_waitcnt lgkmcnt(1)                                       // 00000004DBF4: BF89FC17
	v_lshlrev_b32_e32 v23, 16, v23                             // 00000004DBF8: 302E2E90
	v_lshlrev_b32_e32 v17, 5, v16                              // 00000004DBFC: 30222085
	ds_load_u16 v25, v4 offset:6960                            // 00000004DC00: D8F01B30 19000004
	ds_load_u16 v26, v4 offset:7504                            // 00000004DC08: D8F01D50 1A000004
	ds_load_u16 v27, v4 offset:8048                            // 00000004DC10: D8F01F70 1B000004
	ds_load_b128 v[4:7], v17 offset:24384                      // 00000004DC18: DBFC5F40 04000011
	ds_load_b128 v[8:11], v17 offset:24400                     // 00000004DC20: DBFC5F50 08000011
	v_lshlrev_b32_e32 v20, 16, v20                             // 00000004DC28: 30282890
	s_waitcnt lgkmcnt(0)                                       // 00000004DC2C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DC30: BF870091
	v_dual_mul_f32 v10, v10, v20 :: v_dual_lshlrev_b32 v25, 16, v25// 00000004DC34: C8E2290A 0A183290
	v_dual_mul_f32 v7, v7, v25 :: v_dual_lshlrev_b32 v24, 16, v24// 00000004DC3C: C8E23307 07183090
	v_mul_f32_e32 v8, v8, v21                                  // 00000004DC44: 10102B08
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004DC48: BF870002
	v_dual_mul_f32 v4, v4, v23 :: v_dual_mul_f32 v5, v5, v24   // 00000004DC4C: C8C62F04 04043105
	v_mul_u32_u24_e32 v18, 48, v12                             // 00000004DC54: 162418B0
	ds_load_b128 v[12:15], v17 offset:24192                    // 00000004DC58: DBFC5E80 0C000011
	v_lshlrev_b32_e32 v26, 16, v26                             // 00000004DC60: 30343490
	v_lshlrev_b32_e32 v27, 16, v27                             // 00000004DC64: 30363690
	v_lshl_add_u32 v28, v16, 4, v18                            // 00000004DC68: D646001C 04490910
	ds_load_b128 v[16:19], v17 offset:24208                    // 00000004DC70: DBFC5E90 10000011
	s_waitcnt lgkmcnt(1)                                       // 00000004DC78: BF89FC17
	v_mul_f32_e32 v12, v12, v4                                 // 00000004DC7C: 1018090C
	v_mul_f32_e32 v4, v13, v5                                  // 00000004DC80: 10080B0D
	v_dual_mul_f32 v11, v11, v27 :: v_dual_lshlrev_b32 v22, 16, v22// 00000004DC84: C8E2370B 0B162C90
	v_mul_f32_e32 v5, v15, v7                                  // 00000004DC8C: 100A0F0F
	v_mul_f32_e32 v9, v9, v26                                  // 00000004DC90: 10123509
	s_waitcnt lgkmcnt(0)                                       // 00000004DC94: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000004DC98: BF870243
	v_dual_mul_f32 v7, v16, v8 :: v_dual_mul_f32 v6, v6, v22   // 00000004DC9C: C8C61110 07062D06
	v_cmp_lt_i32_e32 vcc_lo, 31, v3                            // 00000004DCA4: 7C82069F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 00000004DCA8: CC220004 02006104
	v_dual_mul_f32 v8, v17, v9 :: v_dual_mul_f32 v9, v18, v10  // 00000004DCB0: C8C61311 08081512
	v_mul_f32_e32 v6, v14, v6                                  // 00000004DCB8: 100C0D0E
	v_mul_f32_e32 v10, v19, v11                                // 00000004DCBC: 10141713
	v_fma_mixlo_f16 v4, v12, s48, 0                            // 00000004DCC0: CC210004 0200610C
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 00000004DCC8: CC220005 02006105
	s_or_b32 s4, vcc_lo, s4                                    // 00000004DCD0: 8C04046A
	v_fma_mixlo_f16 v5, v6, s48, 0                             // 00000004DCD4: CC210005 02006106
	v_fma_mixhi_f16 v6, v8, s48, 0                             // 00000004DCDC: CC220006 02006108
	v_fma_mixlo_f16 v6, v7, s48, 0                             // 00000004DCE4: CC210006 02006107
	v_fma_mixhi_f16 v7, v10, s48, 0                            // 00000004DCEC: CC220007 0200610A
	v_fma_mixlo_f16 v7, v9, s48, 0                             // 00000004DCF4: CC210007 02006109
	ds_store_b128 v28, v[4:7]                                  // 00000004DCFC: DB7C0000 0000041C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000004DD04: 917E047E
	s_cbranch_execnz 65441                                     // 00000004DD08: BFA6FFA1 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2190>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000004DD0C: 8C7E047E
	v_lshl_add_u32 v3, v44, 3, 0xffffff00                      // 00000004DD10: D6460003 03FD072C FFFFFF00
	s_mov_b32 s4, 0                                            // 00000004DD1C: BE840080
	v_add_nc_u32_e32 v2, 0xe0, v2                              // 00000004DD20: 4A0404FF 000000E0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000004DD28: BF8701A2
	v_and_b32_e32 v4, 0x78, v3                                 // 00000004DD2C: 360806FF 00000078
	v_add_nc_u32_e32 v3, 0x700, v3                             // 00000004DD34: 4A0606FF 00000700
	v_ashrrev_i32_e32 v5, 4, v2                                // 00000004DD3C: 340A0484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004DD40: BF870121
	.long 0xd72c0006                                           // 00000004DD44: D72C0006
	v_cndmask_b32_e32 v1, 0x110, v5, vcc_lo                    // 00000004DD48: 02020AFF 00000110
	v_lshlrev_b32_e32 v8, 2, v5                                // 00000004DD50: 30100A82
	v_lshl_add_u32 v9, v4, 1, v6                               // 00000004DD54: D6460009 04190304
	ds_load_b128 v[4:7], v9 offset:10496                       // 00000004DD5C: DBFC2900 04000009
	ds_load_b32 v8, v8 offset:24448                            // 00000004DD64: D8D85F80 08000008
	s_waitcnt lgkmcnt(1)                                       // 00000004DD6C: BF89FC17
	v_and_b32_e32 v12, 0xffff0000, v6                          // 00000004DD70: 36180CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000004DD78: 300C0C90
	v_and_b32_e32 v13, 0xffff0000, v7                          // 00000004DD7C: 361A0EFF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v4                          // 00000004DD84: 361408FF FFFF0000
	v_lshlrev_b32_e32 v4, 16, v4                               // 00000004DD8C: 30080890
	v_and_b32_e32 v11, 0xffff0000, v5                          // 00000004DD90: 36160AFF FFFF0000
	v_lshlrev_b32_e32 v5, 16, v5                               // 00000004DD98: 300A0A90
	s_waitcnt lgkmcnt(0)                                       // 00000004DD9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000004DDA0: BF8701A3
	v_dual_mul_f32 v14, v8, v4 :: v_dual_lshlrev_b32 v7, 16, v7// 00000004DDA4: C8E20908 0E060E90
	v_mul_f32_e32 v4, v8, v10                                  // 00000004DDAC: 10081508
	v_mul_f32_e32 v10, v8, v5                                  // 00000004DDB0: 10140B08
	v_mul_f32_e32 v5, v8, v11                                  // 00000004DDB4: 100A1708
	v_mul_f32_e32 v11, v8, v6                                  // 00000004DDB8: 10160D08
	v_mul_f32_e32 v6, v8, v12                                  // 00000004DDBC: 100C1908
	v_mul_f32_e32 v12, v8, v7                                  // 00000004DDC0: 10180F08
	v_mul_f32_e32 v7, v8, v13                                  // 00000004DDC4: 100E1B08
	v_cmp_lt_i32_e32 vcc_lo, 31, v2                            // 00000004DDC8: 7C82049F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 00000004DDCC: CC220004 02006104
	v_fma_mixlo_f16 v4, v14, s48, 0                            // 00000004DDD4: CC210004 0200610E
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 00000004DDDC: CC220005 02006105
	v_fma_mixlo_f16 v5, v10, s48, 0                            // 00000004DDE4: CC210005 0200610A
	v_fma_mixhi_f16 v6, v6, s48, 0                             // 00000004DDEC: CC220006 02006106
	v_fma_mixlo_f16 v6, v11, s48, 0                            // 00000004DDF4: CC210006 0200610B
	v_fma_mixhi_f16 v7, v7, s48, 0                             // 00000004DDFC: CC220007 02006107
	v_fma_mixlo_f16 v7, v12, s48, 0                            // 00000004DE04: CC210007 0200610C
	s_or_b32 s4, vcc_lo, s4                                    // 00000004DE0C: 8C04046A
	ds_store_b128 v9, v[4:7] offset:10496                      // 00000004DE10: DB7C2900 00000409
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000004DE18: 917E047E
	s_cbranch_execnz 65472                                     // 00000004DE1C: BFA6FFC0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2320>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004DE20: 8C7E037E
	s_cbranch_execnz 533                                       // 00000004DE24: BFA60215 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c7c>
	s_mov_b32 s3, exec_lo                                      // 00000004DE28: BE83007E
	v_cmpx_gt_u32_e32 16, v43                                  // 00000004DE2C: 7D985690
	s_cbranch_execz 529                                        // 00000004DE30: BFA50211 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c78>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 00000004DE34: 7C945680
	s_waitcnt lgkmcnt(0)                                       // 00000004DE38: BF89FC07
	ds_load_b96 v[14:16], v1 offset:23280                      // 00000004DE3C: DBF85AF0 0E000001
	ds_load_b128 v[59:62], v1 offset:23248                     // 00000004DE44: DBFC5AD0 3B000001
	ds_load_b128 v[63:66], v1 offset:23264                     // 00000004DE4C: DBFC5AE0 3F000001
	ds_load_b128 v[10:13], v1 offset:23168                     // 00000004DE54: DBFC5A80 0A000001
	ds_load_b128 v[6:9], v1 offset:23184                       // 00000004DE5C: DBFC5A90 06000001
	ds_load_b128 v[2:5], v1 offset:23200                       // 00000004DE64: DBFC5AA0 02000001
	ds_load_b64 v[17:18], v1 offset:23216                      // 00000004DE6C: D9D85AB0 11000001
	v_cndmask_b32_e64 v44, 0, 1.0, vcc_lo                      // 00000004DE74: D501002C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 00000004DE7C: 7C945681
	ds_load_b128 v[45:48], v1 offset:23232                     // 00000004DE80: DBFC5AC0 2D000001
	v_cndmask_b32_e64 v33, 0, 1.0, vcc_lo                      // 00000004DE88: D5010021 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 00000004DE90: 7C945682
	v_cndmask_b32_e64 v32, 0, 1.0, vcc_lo                      // 00000004DE94: D5010020 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 00000004DE9C: 7C945683
	v_cndmask_b32_e64 v31, 0, 1.0, vcc_lo                      // 00000004DEA0: D501001F 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 00000004DEA8: 7C945684
	v_cndmask_b32_e64 v29, 0, 1.0, vcc_lo                      // 00000004DEAC: D501001D 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 00000004DEB4: 7C945685
	v_cndmask_b32_e64 v30, 0, 1.0, vcc_lo                      // 00000004DEB8: D501001E 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 00000004DEC0: 7C945686
	v_cndmask_b32_e64 v28, 0, 1.0, vcc_lo                      // 00000004DEC4: D501001C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 00000004DECC: 7C945687
	v_cndmask_b32_e64 v27, 0, 1.0, vcc_lo                      // 00000004DED0: D501001B 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 00000004DED8: 7C945688
	v_cndmask_b32_e64 v25, 0, 1.0, vcc_lo                      // 00000004DEDC: D5010019 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 00000004DEE4: 7C945689
	v_cndmask_b32_e64 v23, 0, 1.0, vcc_lo                      // 00000004DEE8: D5010017 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 00000004DEF0: 7C94568A
	v_cndmask_b32_e64 v26, 0, 1.0, vcc_lo                      // 00000004DEF4: D501001A 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 00000004DEFC: 7C94568B
	v_cndmask_b32_e64 v24, 0, 1.0, vcc_lo                      // 00000004DF00: D5010018 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 00000004DF08: 7C94568C
	v_cndmask_b32_e64 v20, 0, 1.0, vcc_lo                      // 00000004DF0C: D5010014 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 00000004DF14: 7C94568D
	v_cndmask_b32_e64 v22, 0, 1.0, vcc_lo                      // 00000004DF18: D5010016 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 00000004DF20: 7C94568E
	v_cndmask_b32_e64 v21, 0, 1.0, vcc_lo                      // 00000004DF24: D5010015 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 00000004DF2C: 7C94568F
	v_cndmask_b32_e64 v19, 0, 1.0, vcc_lo                      // 00000004DF30: D5010013 01A9E480
	s_waitcnt lgkmcnt(7)                                       // 00000004DF38: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000004DF3C: BF8700B1
	v_fmac_f32_e32 v22, v19, v15                               // 00000004DF40: 562C1F13
	v_fmac_f32_e32 v21, v19, v16                               // 00000004DF44: 562A2113
	s_waitcnt lgkmcnt(1)                                       // 00000004DF48: BF89FC17
	v_dual_fmac_f32 v23, v19, v64 :: v_dual_fmac_f32 v22, v21, v18// 00000004DF4C: C8008113 17162515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000004DF54: BF8700D1
	v_dual_fmac_f32 v26, v19, v65 :: v_dual_fmac_f32 v23, v21, v3// 00000004DF58: C8008313 1A160715
	v_fmac_f32_e32 v25, v19, v63                               // 00000004DF60: 56327F13
	ds_load_b32 v18, v1 offset:22880                           // 00000004DF64: D8D85960 12000001
	v_fmac_f32_e32 v26, v21, v4                                // 00000004DF6C: 56340915
	v_dual_fmac_f32 v28, v19, v61 :: v_dual_fmac_f32 v25, v21, v2// 00000004DF70: C8007B13 1C180515
	v_dual_fmac_f32 v29, v19, v59 :: v_dual_fmac_f32 v28, v21, v8// 00000004DF78: C8007713 1D1C1115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DF80: BF870091
	v_dual_fmac_f32 v30, v19, v60 :: v_dual_fmac_f32 v29, v21, v6// 00000004DF84: C8007913 1E1C0D15
	v_dual_fmac_f32 v27, v19, v62 :: v_dual_fmac_f32 v30, v21, v7// 00000004DF8C: C8007D13 1B1E0F15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DF94: BF870091
	v_dual_fmac_f32 v24, v19, v66 :: v_dual_fmac_f32 v27, v21, v9// 00000004DF98: C8008513 181A1315
	v_fmac_f32_e32 v24, v21, v5                                // 00000004DFA0: 56300B15
	ds_load_b128 v[2:5], v1 offset:23072                       // 00000004DFA4: DBFC5A20 02000001
	s_waitcnt lgkmcnt(2)                                       // 00000004DFAC: BF89FC27
	v_fmac_f32_e32 v31, v19, v48                               // 00000004DFB0: 563E6113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DFB4: BF870091
	v_dual_fmac_f32 v32, v19, v47 :: v_dual_fmac_f32 v31, v21, v13// 00000004DFB8: C8005F13 201E1B15
	v_dual_fmac_f32 v33, v19, v46 :: v_dual_fmac_f32 v32, v21, v12// 00000004DFC0: C8005D13 21201915
	v_fmac_f32_e32 v44, v19, v45                               // 00000004DFC8: 56585B13
	ds_load_b128 v[45:48], v1 offset:24064                     // 00000004DFCC: DBFC5E00 2D000001
	v_dual_fmac_f32 v33, v21, v11 :: v_dual_fmac_f32 v20, v19, v14// 00000004DFD4: C8001715 21141D13
	ds_load_b128 v[59:62], v1 offset:23104                     // 00000004DFDC: DBFC5A40 3B000001
	ds_load_b128 v[63:66], v1 offset:23136                     // 00000004DFE4: DBFC5A60 3F000001
	ds_load_b128 v[67:70], v1 offset:23120                     // 00000004DFEC: DBFC5A50 43000001
	ds_load_b32 v14, v1 offset:23152                           // 00000004DFF4: D8D85A70 0E000001
	v_fmac_f32_e32 v44, v21, v10                               // 00000004DFFC: 56581515
	ds_load_b128 v[6:9], v1 offset:23056                       // 00000004E000: DBFC5A10 06000001
	ds_load_b128 v[10:13], v1 offset:23040                     // 00000004E008: DBFC5A00 0A000001
	s_waitcnt lgkmcnt(5)                                       // 00000004E010: BF89FC57
	v_fmac_f32_e32 v44, v22, v59                               // 00000004E014: 56587716
	v_dual_fmac_f32 v33, v22, v60 :: v_dual_fmac_f32 v20, v21, v17// 00000004E018: C8007916 21142315
	s_waitcnt lgkmcnt(3)                                       // 00000004E020: BF89FC37
	v_fmac_f32_e32 v29, v22, v67                               // 00000004E024: 563A8716
	v_fmac_f32_e32 v31, v22, v62                               // 00000004E028: 563E7D16
	s_waitcnt lgkmcnt(2)                                       // 00000004E02C: BF89FC27
	v_fmac_f32_e32 v20, v22, v14                               // 00000004E030: 56281D16
	ds_load_b128 v[14:17], v1 offset:22976                     // 00000004E034: DBFC59C0 0E000001
	v_fmac_f32_e32 v24, v22, v66                               // 00000004E03C: 56308516
	v_fmac_f32_e32 v32, v22, v61                               // 00000004E040: 56407B16
	ds_load_b64 v[66:67], v1 offset:22944                      // 00000004E044: D9D859A0 42000001
	s_waitcnt lgkmcnt(2)                                       // 00000004E04C: BF89FC27
	v_fmac_f32_e32 v33, v20, v11                               // 00000004E050: 56421714
	v_fmac_f32_e32 v24, v20, v5                                // 00000004E054: 56300B14
	s_waitcnt lgkmcnt(1)                                       // 00000004E058: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000004E05C: BF8701B1
	v_dual_fmac_f32 v33, v24, v15 :: v_dual_fmac_f32 v30, v22, v68// 00000004E060: C8001F18 211E8916
	v_fmac_f32_e32 v29, v20, v6                                // 00000004E068: 563A0D14
	v_dual_fmac_f32 v25, v22, v63 :: v_dual_fmac_f32 v44, v20, v10// 00000004E06C: C8007F16 192C1514
	v_dual_fmac_f32 v23, v22, v64 :: v_dual_fmac_f32 v30, v20, v7// 00000004E074: C8008116 171E0F14
	v_fmac_f32_e32 v26, v22, v65                               // 00000004E07C: 56348316
	ds_load_b128 v[59:62], v1 offset:22992                     // 00000004E080: DBFC59D0 3B000001
	ds_load_b96 v[63:65], v1 offset:23008                      // 00000004E088: DBF859E0 3F000001
	v_dual_fmac_f32 v28, v22, v69 :: v_dual_fmac_f32 v25, v20, v2// 00000004E090: C8008B16 1C180514
	v_dual_fmac_f32 v27, v22, v70 :: v_dual_fmac_f32 v32, v20, v12// 00000004E098: C8008D16 1B201914
	v_fmac_f32_e32 v23, v20, v3                                // 00000004E0A0: 562E0714
	v_fmac_f32_e32 v26, v20, v4                                // 00000004E0A4: 56340914
	v_fmac_f32_e32 v31, v20, v13                               // 00000004E0A8: 563E1B14
	s_delay_alu instid0(VALU_DEP_4)                            // 00000004E0AC: BF870004
	v_fmac_f32_e32 v27, v20, v9                                // 00000004E0B0: 56361314
	ds_load_b128 v[2:5], v1 offset:22848                       // 00000004E0B4: DBFC5940 02000001
	s_waitcnt lgkmcnt(1)                                       // 00000004E0BC: BF89FC17
	v_fmac_f32_e32 v26, v24, v65                               // 00000004E0C0: 56348318
	v_fmac_f32_e32 v28, v20, v8                                // 00000004E0C4: 56381114
	ds_load_b128 v[6:9], v1 offset:22928                       // 00000004E0C8: DBFC5990 06000001
	ds_load_b128 v[10:13], v1 offset:22912                     // 00000004E0D0: DBFC5980 0A000001
	v_fmac_f32_e32 v29, v24, v59                               // 00000004E0D8: 563A7718
	s_waitcnt lgkmcnt(1)                                       // 00000004E0DC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004E0E0: BF870001
	v_fmac_f32_e32 v29, v26, v6                                // 00000004E0E4: 563A0D1A
	v_fmac_f32_e32 v31, v24, v17                               // 00000004E0E8: 563E2318
	v_fmac_f32_e32 v44, v24, v14                               // 00000004E0EC: 56581D18
	v_fmac_f32_e32 v23, v24, v64                               // 00000004E0F0: 562E8118
	v_fmac_f32_e32 v32, v24, v16                               // 00000004E0F4: 56402118
	ds_load_b128 v[14:17], v1 offset:22864                     // 00000004E0F8: DBFC5950 0E000001
	v_fmac_f32_e32 v23, v26, v67                               // 00000004E100: 562E871A
	s_waitcnt lgkmcnt(0)                                       // 00000004E104: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004E108: BF870001
	v_fmac_f32_e32 v29, v23, v14                               // 00000004E10C: 563A1D17
	v_fmac_f32_e32 v27, v24, v62                               // 00000004E110: 56367D18
	v_fmac_f32_e32 v30, v24, v60                               // 00000004E114: 563C7918
	v_fmac_f32_e32 v25, v24, v63                               // 00000004E118: 56327F18
	v_dual_fmac_f32 v33, v26, v11 :: v_dual_fmac_f32 v28, v24, v61// 00000004E11C: C800171A 211C7B18
	ds_load_b128 v[59:62], v1 offset:22800                     // 00000004E124: DBFC5910 3B000001
	v_fmac_f32_e32 v32, v26, v12                               // 00000004E12C: 5640191A
	v_fmac_f32_e32 v31, v26, v13                               // 00000004E130: 563E1B1A
	v_fmac_f32_e32 v44, v26, v10                               // 00000004E134: 5658151A
	ds_load_b128 v[10:13], v1 offset:22784                     // 00000004E138: DBFC5900 0A000001
	ds_load_b96 v[63:65], v1 offset:22736                      // 00000004E140: DBF858D0 3F000001
	v_fmac_f32_e32 v27, v26, v9                                // 00000004E148: 5636131A
	v_fmac_f32_e32 v30, v26, v7                                // 00000004E14C: 563C0F1A
	v_fmac_f32_e32 v25, v26, v66                               // 00000004E150: 5632851A
	v_fmac_f32_e32 v28, v26, v8                                // 00000004E154: 5638111A
	ds_load_b128 v[6:9], v1 offset:22720                       // 00000004E158: DBFC58C0 06000001
	ds_load_b64 v[66:67], v1 offset:22672                      // 00000004E160: D9D85890 42000001
	v_fmac_f32_e32 v33, v23, v3                                // 00000004E168: 56420717
	v_fmac_f32_e32 v25, v23, v18                               // 00000004E16C: 56322517
	v_fmac_f32_e32 v28, v23, v16                               // 00000004E170: 56382117
	v_fmac_f32_e32 v27, v23, v17                               // 00000004E174: 56362317
	v_fmac_f32_e32 v30, v23, v15                               // 00000004E178: 563C1F17
	ds_load_b128 v[14:17], v1 offset:22528                     // 00000004E17C: DBFC5800 0E000001
	s_waitcnt lgkmcnt(5)                                       // 00000004E184: BF89FC57
	v_fmac_f32_e32 v27, v25, v62                               // 00000004E188: 56367D19
	v_fmac_f32_e32 v28, v25, v61                               // 00000004E18C: 56387B19
	v_fmac_f32_e32 v30, v25, v60                               // 00000004E190: 563C7919
	s_waitcnt lgkmcnt(3)                                       // 00000004E194: BF89FC37
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004E198: BF870112
	v_fmac_f32_e32 v28, v27, v65                               // 00000004E19C: 5638831B
	v_fmac_f32_e32 v30, v27, v64                               // 00000004E1A0: 563C811B
	s_waitcnt lgkmcnt(1)                                       // 00000004E1A4: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004E1A8: BF870001
	v_fmac_f32_e32 v30, v28, v67                               // 00000004E1AC: 563C871C
	v_dual_fmac_f32 v44, v23, v2 :: v_dual_fmac_f32 v33, v25, v11// 00000004E1B0: C8000517 2C201719
	v_fmac_f32_e32 v31, v23, v5                                // 00000004E1B8: 563E0B17
	v_fmac_f32_e32 v32, v23, v4                                // 00000004E1BC: 56400917
	ds_load_b128 v[2:5], v1 offset:22656                       // 00000004E1C0: DBFC5880 02000001
	v_fmac_f32_e32 v44, v25, v10                               // 00000004E1C8: 56581519
	v_fmac_f32_e32 v29, v25, v59                               // 00000004E1CC: 563A7719
	v_fmac_f32_e32 v31, v25, v13                               // 00000004E1D0: 563E1B19
	v_fmac_f32_e32 v32, v25, v12                               // 00000004E1D4: 56401919
	ds_load_b128 v[10:13], v1 offset:22592                     // 00000004E1D8: DBFC5840 0A000001
	ds_load_b32 v18, v1 offset:22608                           // 00000004E1E0: D8D85850 12000001
	v_fmac_f32_e32 v33, v27, v7                                // 00000004E1E8: 56420F1B
	v_fmac_f32_e32 v29, v27, v63                               // 00000004E1EC: 563A7F1B
	ds_load_b64 v[59:60], v1 offset:22400                      // 00000004E1F0: D9D85780 3B000001
	v_dual_fmac_f32 v32, v27, v8 :: v_dual_fmac_f32 v29, v28, v66// 00000004E1F8: C800111B 201C851C
	ds_load_b128 v[63:66], v1 offset:24304                     // 00000004E200: DBFC5EF0 3F000001
	s_waitcnt lgkmcnt(2)                                       // 00000004E208: BF89FC27
	v_fmac_f32_e32 v29, v30, v18                               // 00000004E20C: 563A251E
	v_dual_fmac_f32 v44, v27, v6 :: v_dual_fmac_f32 v33, v28, v3// 00000004E210: C8000D1B 2C20071C
	v_fmac_f32_e32 v31, v27, v9                                // 00000004E218: 563E131B
	ds_load_b96 v[6:8], v1 offset:22464                        // 00000004E21C: DBF857C0 06000001
	ds_load_b32 v9, v1 offset:22336                            // 00000004E224: D8D85740 09000001
	v_fmac_f32_e32 v44, v28, v2                                // 00000004E22C: 5658051C
	v_fmac_f32_e32 v32, v28, v4                                // 00000004E230: 5640091C
	v_fmac_f32_e32 v31, v28, v5                                // 00000004E234: 563E0B1C
	v_fmac_f32_e32 v33, v30, v11                               // 00000004E238: 5642171E
	ds_load_b128 v[2:5], v1 offset:24256                       // 00000004E23C: DBFC5EC0 02000001
	v_fmac_f32_e32 v44, v30, v10                               // 00000004E244: 5658151E
	v_fmac_f32_e32 v32, v30, v12                               // 00000004E248: 5640191E
	v_fmac_f32_e32 v31, v30, v13                               // 00000004E24C: 563E1B1E
	v_fmac_f32_e32 v33, v29, v15                               // 00000004E250: 56421F1D
	s_waitcnt lgkmcnt(3)                                       // 00000004E254: BF89FC37
	v_mul_f32_e32 v72, v65, v21                                // 00000004E258: 10902B41
	v_fmac_f32_e32 v44, v29, v14                               // 00000004E25C: 56581D1D
	v_fmac_f32_e32 v32, v29, v16                               // 00000004E260: 5640211D
	v_fmac_f32_e32 v31, v29, v17                               // 00000004E264: 563E231D
	s_waitcnt lgkmcnt(2)                                       // 00000004E268: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004E26C: BF8700A1
	v_fmac_f32_e32 v32, v31, v8                                // 00000004E270: 5640111F
	v_fmac_f32_e32 v33, v31, v7                                // 00000004E274: 56420F1F
	v_dual_fmac_f32 v44, v31, v6 :: v_dual_fmac_f32 v33, v32, v60// 00000004E278: C8000D1F 2C207920
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004E280: BF870001
	v_fmac_f32_e32 v44, v32, v59                               // 00000004E284: 56587720
	ds_load_b128 v[59:62], v1 offset:24288                     // 00000004E288: DBFC5EE0 3B000001
	s_waitcnt lgkmcnt(1)                                       // 00000004E290: BF89FC17
	v_fma_mixlo_f16 v49, v5, v31, 0                            // 00000004E294: CC210031 02023F05
	v_mul_f32_e32 v15, v3, v33                                 // 00000004E29C: 101E4303
	v_fmac_f32_e32 v44, v33, v9                                // 00000004E2A0: 56581321
	ds_load_b128 v[6:9], v1 offset:24272                       // 00000004E2A4: DBFC5ED0 06000001
	ds_load_b128 v[10:13], v1 offset:24112                     // 00000004E2AC: DBFC5E30 0A000001
	v_fma_mixlo_f16 v18, v3, v33, 0                            // 00000004E2B4: CC210012 02024303
	v_mul_f32_e32 v14, v2, v44                                 // 00000004E2BC: 101C5902
	v_fma_mixlo_f16 v2, v2, v44, 0                             // 00000004E2C0: CC210002 02025902
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004E2C8: BF870113
	v_fma_mix_f32 v15, v18, -1.0, v15 op_sel_hi:[1,1,0]        // 00000004E2CC: CC20000F 1C3DE712
	v_fma_mix_f32 v3, v2, -1.0, v14 op_sel_hi:[1,1,0]          // 00000004E2D4: CC200003 1C39E702
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000004E2DC: BF870232
	.long 0x7f1c150f                                           // 00000004E2E0: 7F1C150F
	v_mul_f32_e32 v15, v4, v32                                 // 00000004E2E4: 101E4104
	.long 0x7f043912                                           // 00000004E2E8: 7F043912
	v_cvt_f16_f32_e32 v14, v3                                  // 00000004E2EC: 7E1C1503
	v_fma_mixlo_f16 v3, v4, v32, 0                             // 00000004E2F0: CC210003 02024104
	v_mul_f32_e32 v4, v5, v31                                  // 00000004E2F8: 10083F05
	s_waitcnt lgkmcnt(2)                                       // 00000004E2FC: BF89FC27
	v_fma_mixlo_f16 v69, v60, v23, 0                           // 00000004E300: CC210045 02022F3C
	s_waitcnt lgkmcnt(1)                                       // 00000004E308: BF89FC17
	v_mul_f32_e32 v16, v7, v30                                 // 00000004E30C: 10203D07
	v_fma_mixlo_f16 v67, v7, v30, 0                            // 00000004E310: CC210043 02023D07
	v_fma_mix_f32 v7, v3, -1.0, v15 op_sel_hi:[1,1,0]          // 00000004E318: CC200007 1C3DE703
	v_mul_f32_e32 v5, v6, v29                                  // 00000004E320: 100A3B06
	v_fma_mixlo_f16 v68, v9, v27, 0                            // 00000004E324: CC210044 02023709
	.long 0x7f063931                                           // 00000004E32C: 7F063931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000004E330: BF8701D4
	v_cvt_f16_f32_e32 v15, v7                                  // 00000004E334: 7E1E1507
	v_mul_f32_e32 v7, v8, v28                                  // 00000004E338: 100E3908
	v_fma_mix_f32 v17, v49, -1.0, v4 op_sel_hi:[1,1,0]         // 00000004E33C: CC200011 1C11E731
	v_fma_mixlo_f16 v4, v6, v29, 0                             // 00000004E344: CC210004 02023B06
	v_fma_mix_f32 v6, v67, -1.0, v16 op_sel_hi:[1,1,0]         // 00000004E34C: CC200006 1C41E743
	.long 0x7f1e1511                                           // 00000004E354: 7F1E1511
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000004E358: BF870193
	v_fma_mix_f32 v5, v4, -1.0, v5 op_sel_hi:[1,1,0]           // 00000004E35C: CC200005 1C15E704
	.long 0x7f201506                                           // 00000004E364: 7F201506
	v_fma_mixlo_f16 v6, v59, v25, 0                            // 00000004E368: CC210006 0202333B
	.long 0x7f083943                                           // 00000004E370: 7F083943
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000004E374: BF8701C4
	v_cvt_f16_f32_e32 v16, v5                                  // 00000004E378: 7E201505
	v_fma_mixlo_f16 v5, v8, v28, 0                             // 00000004E37C: CC210005 02023908
	v_dual_mul_f32 v8, v9, v27 :: v_dual_mul_f32 v9, v59, v25  // 00000004E384: C8C63709 0808333B
	v_dual_mul_f32 v59, v60, v23 :: v_dual_mul_f32 v60, v61, v26// 00000004E38C: C8C62F3C 3B3C353D
	v_fma_mix_f32 v7, v5, -1.0, v7 op_sel_hi:[1,1,0]           // 00000004E394: CC200007 1C1DE705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004E39C: BF870213
	v_fma_mix_f32 v8, v68, -1.0, v8 op_sel_hi:[1,1,0]          // 00000004E3A0: CC200008 1C21E744
	v_fma_mix_f32 v9, v6, -1.0, v9 op_sel_hi:[1,1,0]           // 00000004E3A8: CC200009 1C25E706
	s_delay_alu instid0(VALU_DEP_4)                            // 00000004E3B0: BF870004
	v_fma_mix_f32 v70, v69, -1.0, v59 op_sel_hi:[1,1,0]        // 00000004E3B4: CC200046 1CEDE745
	.long 0x7f0c3945                                           // 00000004E3BC: 7F0C3945
	v_cvt_f16_f32_e32 v17, v7                                  // 00000004E3C0: 7E221507
	v_fma_mixlo_f16 v7, v61, v26, 0                            // 00000004E3C4: CC210007 0202353D
	.long 0x7f221508                                           // 00000004E3CC: 7F221508
	v_cvt_f16_f32_e32 v59, v9                                  // 00000004E3D0: 7E761509
	.long 0x7f761546                                           // 00000004E3D4: 7F761546
	v_mul_f32_e32 v9, v62, v24                                 // 00000004E3D8: 1012313E
	v_fma_mix_f32 v8, v7, -1.0, v60 op_sel_hi:[1,1,0]          // 00000004E3DC: CC200008 1CF1E707
	v_fma_mixlo_f16 v70, v62, v24, 0                           // 00000004E3E4: CC210046 0202313E
	v_dual_mul_f32 v61, v63, v20 :: v_dual_mul_f32 v62, v64, v22// 00000004E3EC: C8C6293F 3D3E2D40
	v_fma_mixlo_f16 v64, v64, v22, 0                           // 00000004E3F4: CC210040 02022D40
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004E3FC: BF870214
	v_cvt_f16_f32_e32 v60, v8                                  // 00000004E400: 7E781508
	v_fma_mix_f32 v71, v70, -1.0, v9 op_sel_hi:[1,1,0]         // 00000004E404: CC200047 1C25E746
	v_fma_mixlo_f16 v8, v63, v20, 0                            // 00000004E40C: CC210008 0202293F
	v_fma_mixlo_f16 v9, v65, v21, 0                            // 00000004E414: CC210009 02022B41
	v_fma_mix_f32 v62, v64, -1.0, v62 op_sel_hi:[1,1,0]        // 00000004E41C: CC20003E 1CF9E740
	v_mul_f32_e32 v65, v66, v19                                // 00000004E424: 10822742
	v_fma_mixlo_f16 v66, v66, v19, 0                           // 00000004E428: CC210042 02022742
	v_fma_mix_f32 v61, v8, -1.0, v61 op_sel_hi:[1,1,0]         // 00000004E430: CC20003D 1CF5E708
	v_fma_mix_f32 v63, v9, -1.0, v72 op_sel_hi:[1,1,0]         // 00000004E438: CC20003F 1D21E709
	.long 0x7f781547                                           // 00000004E440: 7F781547
	.long 0x7f103940                                           // 00000004E444: 7F103940
	v_fma_mix_f32 v71, v66, -1.0, v65 op_sel_hi:[1,1,0]        // 00000004E448: CC200047 1D05E742
	v_cvt_f16_f32_e32 v61, v61                                 // 00000004E450: 7E7A153D
	.long 0x7f7a153e                                           // 00000004E454: 7F7A153E
	v_cvt_f16_f32_e32 v62, v63                                 // 00000004E458: 7E7C153F
	.long 0x7f123942                                           // 00000004E45C: 7F123942
	ds_load_b128 v[63:66], v1 offset:24080                     // 00000004E460: DBFC5E10 3F000001
	v_mul_u32_u24_e32 v72, 48, v43                             // 00000004E468: 169056B0
	.long 0x7f0e3946                                           // 00000004E46C: 7F0E3946
	.long 0x7f0a3944                                           // 00000004E470: 7F0A3944
	v_mul_f32_e32 v18, v45, v44                                // 00000004E474: 1024592D
	v_fma_mixlo_f16 v43, v45, v44, 0                           // 00000004E478: CC21002B 0202592D
	v_mul_f32_e32 v44, v46, v33                                // 00000004E480: 1058432E
	v_fma_mixlo_f16 v33, v46, v33, 0                           // 00000004E484: CC210021 0202432E
	ds_store_b128 v72, v[6:9] offset:19216                     // 00000004E48C: DB7C4B10 00000648
	ds_store_b128 v72, v[2:5] offset:19200                     // 00000004E494: DB7C4B00 00000248
	ds_load_b128 v[2:5], v1 offset:24096                       // 00000004E49C: DBFC5E20 02000001
	v_dual_mul_f32 v7, v47, v32 :: v_dual_mul_f32 v8, v48, v31 // 00000004E4A4: C8C6412F 07083F30
	v_fma_mix_f32 v44, v33, -1.0, v44 op_sel_hi:[1,1,0]        // 00000004E4AC: CC20002C 1CB1E721
	.long 0x7f7c1547                                           // 00000004E4B4: 7F7C1547
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004E4B8: BF870002
	.long 0x7f0c152c                                           // 00000004E4BC: 7F0C152C
	v_fma_mixlo_f16 v44, v47, v32, 0                           // 00000004E4C0: CC21002C 0202412F
	s_waitcnt lgkmcnt(3)                                       // 00000004E4C8: BF89FC37
	v_mul_f32_e32 v9, v63, v29                                 // 00000004E4CC: 10123B3F
	v_fma_mix_f32 v18, v43, -1.0, v18 op_sel_hi:[1,1,0]        // 00000004E4D0: CC200012 1C49E72B
	v_fma_mixlo_f16 v45, v63, v29, 0                           // 00000004E4D8: CC21002D 02023B3F
	v_fma_mix_f32 v7, v44, -1.0, v7 op_sel_hi:[1,1,0]          // 00000004E4E0: CC200007 1C1DE72C
	v_fma_mixlo_f16 v46, v65, v28, 0                           // 00000004E4E8: CC21002E 02023941
	.long 0x7f563921                                           // 00000004E4F0: 7F563921
	v_cvt_f16_f32_e32 v6, v18                                  // 00000004E4F4: 7E0C1512
	v_fma_mixlo_f16 v18, v48, v31, 0                           // 00000004E4F8: CC210012 02023F30
	v_mul_f32_e32 v31, v64, v30                                // 00000004E500: 103E3D40
	v_fma_mixlo_f16 v30, v64, v30, 0                           // 00000004E504: CC21001E 02023D40
	v_fma_mix_f32 v9, v45, -1.0, v9 op_sel_hi:[1,1,0]          // 00000004E50C: CC200009 1C25E72D
	v_cvt_f16_f32_e32 v7, v7                                   // 00000004E514: 7E0E1507
	.long 0x7f583912                                           // 00000004E518: 7F583912
	s_delay_alu instid0(VALU_DEP_4)                            // 00000004E51C: BF870004
	v_fma_mix_f32 v29, v30, -1.0, v31 op_sel_hi:[1,1,0]        // 00000004E520: CC20001D 1C7DE71E
	v_mul_f32_e32 v31, v65, v28                                // 00000004E528: 103E3941
	v_fma_mix_f32 v8, v18, -1.0, v8 op_sel_hi:[1,1,0]          // 00000004E52C: CC200008 1C21E712
	v_mul_f32_e32 v28, v66, v27                                // 00000004E534: 10383742
	v_fma_mixlo_f16 v27, v66, v27, 0                           // 00000004E538: CC21001B 02023742
	.long 0x7f5a391e                                           // 00000004E540: 7F5A391E
	s_delay_alu instid0(VALU_DEP_4)                            // 00000004E544: BF870004
	.long 0x7f0e1508                                           // 00000004E548: 7F0E1508
	v_cvt_f16_f32_e32 v8, v9                                   // 00000004E54C: 7E101509
	.long 0x7f10151d                                           // 00000004E550: 7F10151D
	v_fma_mix_f32 v9, v46, -1.0, v31 op_sel_hi:[1,1,0]         // 00000004E554: CC200009 1C7DE72E
	s_waitcnt lgkmcnt(0)                                       // 00000004E55C: BF89FC07
	v_mul_f32_e32 v29, v2, v25                                 // 00000004E560: 103A3302
	v_fma_mixlo_f16 v2, v2, v25, 0                             // 00000004E564: CC210002 02023302
	v_mul_f32_e32 v25, v3, v23                                 // 00000004E56C: 10322F03
	v_fma_mixlo_f16 v31, v3, v23, 0                            // 00000004E570: CC21001F 02022F03
	v_fma_mix_f32 v3, v27, -1.0, v28 op_sel_hi:[1,1,0]         // 00000004E578: CC200003 1C71E71B
	v_cvt_f16_f32_e32 v9, v9                                   // 00000004E580: 7E121509
	v_mul_f32_e32 v23, v4, v26                                 // 00000004E584: 102E3504
	.long 0x7f5c391b                                           // 00000004E588: 7F5C391B
	v_fma_mix_f32 v25, v31, -1.0, v25 op_sel_hi:[1,1,0]        // 00000004E58C: CC200019 1C65E71F
	.long 0x7f121503                                           // 00000004E594: 7F121503
	v_fma_mixlo_f16 v3, v4, v26, 0                             // 00000004E598: CC210003 02023504
	v_mul_f32_e32 v26, v11, v22                                // 00000004E5A0: 10342D0B
	v_fma_mix_f32 v28, v2, -1.0, v29 op_sel_hi:[1,1,0]         // 00000004E5A4: CC20001C 1C75E702
	v_fma_mixlo_f16 v11, v11, v22, 0                           // 00000004E5AC: CC21000B 02022D0B
	.long 0x7f04391f                                           // 00000004E5B4: 7F04391F
	v_fma_mix_f32 v4, v3, -1.0, v23 op_sel_hi:[1,1,0]          // 00000004E5B8: CC200004 1C5DE703
	.long 0x7f2e1519                                           // 00000004E5C0: 7F2E1519
	v_cvt_f16_f32_e32 v23, v28                                 // 00000004E5C4: 7E2E151C
	v_mul_f32_e32 v25, v5, v24                                 // 00000004E5C8: 10323105
	v_fma_mixlo_f16 v28, v5, v24, 0                            // 00000004E5CC: CC21001C 02023105
	v_cvt_f16_f32_e32 v24, v4                                  // 00000004E5D4: 7E301504
	v_mul_f32_e32 v5, v10, v20                                 // 00000004E5D8: 100A290A
	v_fma_mixlo_f16 v4, v10, v20, 0                            // 00000004E5DC: CC210004 0202290A
	v_fma_mix_f32 v20, v11, -1.0, v26 op_sel_hi:[1,1,0]        // 00000004E5E4: CC200014 1C69E70B
	v_fma_mix_f32 v22, v28, -1.0, v25 op_sel_hi:[1,1,0]        // 00000004E5EC: CC200016 1C65E71C
	v_mul_f32_e32 v25, v12, v21                                // 00000004E5F4: 10322B0C
	.long 0x7f06391c                                           // 00000004E5F8: 7F06391C
	v_fma_mix_f32 v10, v4, -1.0, v5 op_sel_hi:[1,1,0]          // 00000004E5FC: CC20000A 1C15E704
	v_fma_mixlo_f16 v5, v12, v21, 0                            // 00000004E604: CC210005 02022B0C
	v_mul_f32_e32 v21, v13, v19                                // 00000004E60C: 102A270D
	v_fma_mixlo_f16 v13, v13, v19, 0                           // 00000004E610: CC21000D 0202270D
	.long 0x7f08390b                                           // 00000004E618: 7F08390B
	.long 0x7f301516                                           // 00000004E61C: 7F301516
	v_fma_mix_f32 v12, v5, -1.0, v25 op_sel_hi:[1,1,0]         // 00000004E620: CC20000C 1C65E705
	v_cvt_f16_f32_e32 v25, v10                                 // 00000004E628: 7E32150A
	v_fma_mix_f32 v10, v13, -1.0, v21 op_sel_hi:[1,1,0]        // 00000004E62C: CC20000A 1C55E70D
	.long 0x7f0a390d                                           // 00000004E634: 7F0A390D
	.long 0x7f321514                                           // 00000004E638: 7F321514
	v_cvt_f16_f32_e32 v26, v12                                 // 00000004E63C: 7E34150C
	s_delay_alu instid0(VALU_DEP_4)                            // 00000004E640: BF870004
	.long 0x7f34150a                                           // 00000004E644: 7F34150A
	ds_store_b128 v72, v[59:62] offset:19984                   // 00000004E648: DB7C4E10 00003B48
	ds_store_b128 v72, v[14:17] offset:19968                   // 00000004E650: DB7C4E00 00000E48
	ds_store_b128 v72, v[2:5] offset:20752                     // 00000004E658: DB7C5110 00000248
	ds_store_b128 v72, v[43:46] offset:20736                   // 00000004E660: DB7C5100 00002B48
	ds_store_b128 v72, v[23:26] offset:21520                   // 00000004E668: DB7C5410 00001748
	ds_store_b128 v72, v[6:9] offset:21504                     // 00000004E670: DB7C5400 00000648
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004E678: 8C7E037E
	v_lshlrev_b32_e32 v59, 1, v153                             // 00000004E67C: 30773281
	s_waitcnt lgkmcnt(0)                                       // 00000004E680: BF89FC07
	s_barrier                                                  // 00000004E684: BFBD0000
	v_cmp_eq_u32_e32 vcc_lo, 0, v34                            // 00000004E688: 7C944480
	v_mul_u32_u24_e32 v60, 48, v55                             // 00000004E68C: 16786EB0
	s_cmp_lt_i32 s54, s39                                      // 00000004E690: BF042736
	ds_load_u16 v2, v59 offset:6416                            // 00000004E694: D8F01910 0200003B
	ds_load_u16 v3, v59 offset:7776                            // 00000004E69C: D8F01E60 0300003B
	ds_load_u16 v4, v59 offset:7232                            // 00000004E6A4: D8F01C40 0400003B
	s_waitcnt lgkmcnt(0)                                       // 00000004E6AC: BF89FC07
	ds_load_u16 v5, v59 offset:6688                            // 00000004E6B0: D8F01A20 0500003B
	ds_load_u16 v6, v59 offset:6144                            // 00000004E6B8: D8F01800 0600003B
	ds_load_b128 v[22:25], v60 offset:19984                    // 00000004E6C0: DBFC4E10 1600003C
	ds_load_b128 v[18:21], v60 offset:19968                    // 00000004E6C8: DBFC4E00 1200003C
	ds_load_b128 v[26:29], v60 offset:19200                    // 00000004E6D0: DBFC4B00 1A00003C
	ds_load_b128 v[30:33], v60 offset:19216                    // 00000004E6D8: DBFC4B10 1E00003C
	s_cselect_b32 s3, -1, 0                                    // 00000004E6E0: 980380C1
	s_or_b32 s4, s54, 1                                        // 00000004E6E4: 8C048136
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000004E6E8: BF870159
	s_cmp_lt_i32 s4, s39                                       // 00000004E6EC: BF042704
	s_cselect_b32 s4, -1, 0                                    // 00000004E6F0: 980480C1
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000004E6F4: 30040490
	s_waitcnt lgkmcnt(4)                                       // 00000004E6F8: BF89FC47
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000004E6FC: 300C0C90
	.long 0x7f141502                                           // 00000004E700: 7F141502
	ds_load_u16 v2, v59 offset:6960                            // 00000004E704: D8F01B30 0200003B
	v_cvt_f16_f32_e32 v10, v6                                  // 00000004E70C: 7E141506
	s_waitcnt lgkmcnt(0)                                       // 00000004E710: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000004E714: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004E718: BF8700A1
	.long 0x7f161502                                           // 00000004E71C: 7F161502
	v_lshlrev_b32_e32 v2, 16, v5                               // 00000004E720: 30040A90
	v_cvt_f16_f32_e32 v11, v2                                  // 00000004E724: 7E161502
	ds_load_u16 v2, v59 offset:7504                            // 00000004E728: D8F01D50 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000004E730: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000004E734: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004E738: BF8700A1
	.long 0x7f181502                                           // 00000004E73C: 7F181502
	v_lshlrev_b32_e32 v2, 16, v4                               // 00000004E740: 30040890
	v_cvt_f16_f32_e32 v12, v2                                  // 00000004E744: 7E181502
	ds_load_u16 v2, v59 offset:8048                            // 00000004E748: D8F01F70 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000004E750: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000004E754: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004E758: BF8700A1
	.long 0x7f1a1502                                           // 00000004E75C: 7F1A1502
	v_lshlrev_b32_e32 v2, 16, v3                               // 00000004E760: 30040690
	v_cvt_f16_f32_e32 v13, v2                                  // 00000004E764: 7E1A1502
	ds_load_u16 v2, v59 offset:8592                            // 00000004E768: D8F02190 0200003B
	ds_load_u16 v3, v59 offset:9952                            // 00000004E770: D8F026E0 0300003B
	ds_load_u16 v4, v59 offset:9408                            // 00000004E778: D8F024C0 0400003B
	ds_load_u16 v5, v59 offset:8864                            // 00000004E780: D8F022A0 0500003B
	ds_load_u16 v6, v59 offset:8320                            // 00000004E788: D8F02080 0600003B
	s_waitcnt lgkmcnt(4)                                       // 00000004E790: BF89FC47
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000004E794: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000004E798: BF8700B1
	.long 0x7f1c1502                                           // 00000004E79C: 7F1C1502
	s_waitcnt lgkmcnt(0)                                       // 00000004E7A0: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v6                               // 00000004E7A4: 30040C90
	v_cvt_f16_f32_e32 v14, v2                                  // 00000004E7A8: 7E1C1502
	ds_load_u16 v2, v59 offset:9136                            // 00000004E7AC: D8F023B0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000004E7B4: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000004E7B8: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004E7BC: BF8700A1
	.long 0x7f1e1502                                           // 00000004E7C0: 7F1E1502
	v_lshlrev_b32_e32 v2, 16, v5                               // 00000004E7C4: 30040A90
	v_cvt_f16_f32_e32 v15, v2                                  // 00000004E7C8: 7E1E1502
	ds_load_u16 v2, v59 offset:9680                            // 00000004E7CC: D8F025D0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000004E7D4: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000004E7D8: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004E7DC: BF8700A1
	.long 0x7f201502                                           // 00000004E7E0: 7F201502
	v_lshlrev_b32_e32 v2, 16, v4                               // 00000004E7E4: 30040890
	v_cvt_f16_f32_e32 v16, v2                                  // 00000004E7E8: 7E201502
	ds_load_u16 v2, v59 offset:10224                           // 00000004E7EC: D8F027F0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000004E7F4: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000004E7F8: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004E7FC: BF8700A1
	.long 0x7f221502                                           // 00000004E800: 7F221502
	v_lshlrev_b32_e32 v2, 16, v3                               // 00000004E804: 30040690
	v_cvt_f16_f32_e32 v17, v2                                  // 00000004E808: 7E221502
	v_dual_mov_b32 v2, s20 :: v_dual_mov_b32 v3, s21           // 00000004E80C: CA100014 02020015
	v_dual_mov_b32 v4, s22 :: v_dual_mov_b32 v5, s23           // 00000004E814: CA100016 04040017
	v_dual_mov_b32 v6, s24 :: v_dual_mov_b32 v7, s25           // 00000004E81C: CA100018 06060019
	v_dual_mov_b32 v8, s26 :: v_dual_mov_b32 v9, s27           // 00000004E824: CA10001A 0808001B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004E82C: BF870121
	v_wmma_f32_16x16x16_f16 v[61:68], v[18:25], v[10:17], v[2:9]// 00000004E830: CC40403D 1C0A1512
	v_mov_b32_e32 v18, 0                                       // 00000004E838: 7E240280
	v_wmma_f32_16x16x16_f16 v[61:68], v[26:33], v[10:17], v[61:68]// 00000004E83C: CC40403D 1CF6151A
	v_dual_mov_b32 v10, 0 :: v_dual_cndmask_b32 v11, 0x7060302, v149// 00000004E844: CA120080 0A0B2AFF 07060302
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 00000004E850: CA100080 0C0C0080
	v_mov_b32_e32 v14, 0                                       // 00000004E858: 7E1C0280
	s_waitcnt vmcnt(7)                                         // 00000004E85C: BF891FF7
	s_delay_alu instid0(VALU_DEP_3)                            // 00000004E860: BF870003
	v_mov_b32_dpp v10, v42 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000004E864: 7E1402FA FF00B12A
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 00000004E86C: CA100080 0F100080
	v_mov_b32_e32 v17, 0                                       // 00000004E874: 7E220280
	s_waitcnt vmcnt(6)                                         // 00000004E878: BF891BF7
	v_mov_b32_dpp v12, v41 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000004E87C: 7E1802FA FF00B129
	v_perm_b32 v10, v42, v10, v11                              // 00000004E884: D644000A 042E152A
	s_waitcnt vmcnt(5)                                         // 00000004E88C: BF8917F7
	v_mov_b32_dpp v13, v40 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000004E890: 7E1A02FA FF00B128
	s_waitcnt vmcnt(4)                                         // 00000004E898: BF8913F7
	v_mov_b32_dpp v14, v39 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000004E89C: 7E1C02FA FF00B127
	s_waitcnt vmcnt(3)                                         // 00000004E8A4: BF890FF7
	v_mov_b32_dpp v15, v38 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000004E8A8: 7E1E02FA FF00B126
	s_waitcnt vmcnt(2)                                         // 00000004E8B0: BF890BF7
	v_mov_b32_dpp v16, v37 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000004E8B4: 7E2002FA FF00B125
	s_waitcnt vmcnt(1)                                         // 00000004E8BC: BF8907F7
	v_mov_b32_dpp v17, v35 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000004E8C0: 7E2202FA FF00B123
	s_waitcnt vmcnt(0)                                         // 00000004E8C8: BF8903F7
	v_mov_b32_dpp v18, v36 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000004E8CC: 7E2402FA FF00B124
	v_perm_b32 v12, v41, v12, v11                              // 00000004E8D4: D644000C 042E1929
	v_perm_b32 v13, v40, v13, v11                              // 00000004E8DC: D644000D 042E1B28
	v_perm_b32 v14, v39, v14, v11                              // 00000004E8E4: D644000E 042E1D27
	v_perm_b32 v15, v38, v15, v11                              // 00000004E8EC: D644000F 042E1F26
	v_perm_b32 v16, v37, v16, v11                              // 00000004E8F4: D6440010 042E2125
	v_perm_b32 v17, v35, v17, v11                              // 00000004E8FC: D6440011 042E2323
	v_perm_b32 v11, v36, v18, v11                              // 00000004E904: D644000B 042E2524
	v_lshlrev_b32_e32 v18, 16, v10                             // 00000004E90C: 30241490
	v_and_b32_e32 v19, 0xffff0000, v10                         // 00000004E910: 362614FF FFFF0000
	ds_load_b128 v[30:33], v60 offset:21520                    // 00000004E918: DBFC5410 1E00003C
	ds_load_b128 v[26:29], v60 offset:21504                    // 00000004E920: DBFC5400 1A00003C
	ds_load_b128 v[38:41], v60 offset:20752                    // 00000004E928: DBFC5110 2600003C
	ds_load_b128 v[34:37], v60 offset:20736                    // 00000004E930: DBFC5100 2200003C
	v_cmp_eq_u32_e32 vcc_lo, 0, v154                           // 00000004E938: 7C953480
	v_cvt_f16_f32_e32 v10, v18                                 // 00000004E93C: 7E141512
	.long 0x7f141513                                           // 00000004E940: 7F141513
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004E944: BF870112
	v_cndmask_b16 v18, 0, v10, s3                              // 00000004E948: D65D0012 000E1480
	v_cndmask_b16 v18, 0, v10, s4                              // 00000004E950: D65D5012 00121480
	v_lshlrev_b32_e32 v10, 16, v12                             // 00000004E958: 30141890
	s_or_b32 s3, s54, 2                                        // 00000004E95C: 8C038236
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E960: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004E964: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000004E968: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004E96C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000004E970: BF870481
	v_cndmask_b16 v19, 0, v10, s3                              // 00000004E974: D65D0013 000E1480
	v_and_b32_e32 v10, 0xffff0000, v12                         // 00000004E97C: 361418FF FFFF0000
	s_or_b32 s3, s54, 3                                        // 00000004E984: 8C038336
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E988: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004E98C: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000004E990: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004E994: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000004E998: BF870481
	v_cndmask_b16 v19, 0, v10, s3                              // 00000004E99C: D65D4013 000E1480
	v_lshlrev_b32_e32 v10, 16, v13                             // 00000004E9A4: 30141A90
	s_or_b32 s3, s54, 4                                        // 00000004E9A8: 8C038436
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E9AC: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004E9B0: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000004E9B4: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004E9B8: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000004E9BC: BF870481
	v_cndmask_b16 v20, 0, v10, s3                              // 00000004E9C0: D65D0014 000E1480
	v_and_b32_e32 v10, 0xffff0000, v13                         // 00000004E9C8: 36141AFF FFFF0000
	s_or_b32 s3, s54, 5                                        // 00000004E9D0: 8C038536
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E9D4: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004E9D8: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000004E9DC: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004E9E0: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000004E9E4: BF870481
	v_cndmask_b16 v20, 0, v10, s3                              // 00000004E9E8: D65D4014 000E1480
	v_lshlrev_b32_e32 v10, 16, v14                             // 00000004E9F0: 30141C90
	s_or_b32 s3, s54, 6                                        // 00000004E9F4: 8C038636
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E9F8: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004E9FC: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000004EA00: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004EA04: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000004EA08: BF870481
	v_cndmask_b16 v21, 0, v10, s3                              // 00000004EA0C: D65D0015 000E1480
	v_and_b32_e32 v10, 0xffff0000, v14                         // 00000004EA14: 36141CFF FFFF0000
	s_or_b32 s3, s54, 7                                        // 00000004EA1C: 8C038736
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EA20: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004EA24: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000004EA28: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004EA2C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000004EA30: BF870481
	v_cndmask_b16 v21, 0, v10, s3                              // 00000004EA34: D65D4015 000E1480
	v_lshlrev_b32_e32 v10, 16, v15                             // 00000004EA3C: 30141E90
	s_or_b32 s3, s54, 8                                        // 00000004EA40: 8C038836
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EA44: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004EA48: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000004EA4C: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004EA50: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000004EA54: BF870481
	v_cndmask_b16 v22, 0, v10, s3                              // 00000004EA58: D65D0016 000E1480
	v_and_b32_e32 v10, 0xffff0000, v15                         // 00000004EA60: 36141EFF FFFF0000
	s_or_b32 s3, s54, 9                                        // 00000004EA68: 8C038936
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EA6C: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004EA70: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000004EA74: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004EA78: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000004EA7C: BF870481
	v_cndmask_b16 v22, 0, v10, s3                              // 00000004EA80: D65D4016 000E1480
	v_lshlrev_b32_e32 v10, 16, v16                             // 00000004EA88: 30142090
	s_or_b32 s3, s54, 10                                       // 00000004EA8C: 8C038A36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EA90: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004EA94: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000004EA98: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004EA9C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000004EAA0: BF870481
	v_cndmask_b16 v23, 0, v10, s3                              // 00000004EAA4: D65D0017 000E1480
	v_and_b32_e32 v10, 0xffff0000, v16                         // 00000004EAAC: 361420FF FFFF0000
	s_or_b32 s3, s54, 11                                       // 00000004EAB4: 8C038B36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EAB8: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004EABC: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000004EAC0: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004EAC4: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000004EAC8: BF870481
	v_cndmask_b16 v23, 0, v10, s3                              // 00000004EACC: D65D4017 000E1480
	v_lshlrev_b32_e32 v10, 16, v17                             // 00000004EAD4: 30142290
	s_or_b32 s3, s54, 12                                       // 00000004EAD8: 8C038C36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EADC: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004EAE0: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000004EAE4: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004EAE8: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000004EAEC: BF870481
	v_cndmask_b16 v24, 0, v10, s3                              // 00000004EAF0: D65D0018 000E1480
	v_and_b32_e32 v10, 0xffff0000, v17                         // 00000004EAF8: 361422FF FFFF0000
	s_or_b32 s3, s54, 13                                       // 00000004EB00: 8C038D36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EB04: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004EB08: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000004EB0C: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004EB10: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000004EB14: BF870481
	v_cndmask_b16 v24, 0, v10, s3                              // 00000004EB18: D65D4018 000E1480
	v_lshlrev_b32_e32 v10, 16, v11                             // 00000004EB20: 30141690
	s_or_b32 s3, s54, 14                                       // 00000004EB24: 8C038E36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EB28: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004EB2C: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000004EB30: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004EB34: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000004EB38: BF870481
	v_cndmask_b16 v25, 0, v10, s3                              // 00000004EB3C: D65D0019 000E1480
	v_and_b32_e32 v10, 0xffff0000, v11                         // 00000004EB44: 361416FF FFFF0000
	s_or_b32 s3, s54, 15                                       // 00000004EB4C: 8C038F36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EB50: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000004EB54: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000004EB58: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000004EB5C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000004EB60: BF870481
	v_cndmask_b16 v25, 0, v10, s3                              // 00000004EB64: D65D4019 000E1480
	s_waitcnt lgkmcnt(2)                                       // 00000004EB6C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004EB70: BF8700A1
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[18:25], v[2:9]// 00000004EB74: CC40400A 1C0A251A
	s_waitcnt lgkmcnt(0)                                       // 00000004EB7C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[34:41], v[18:25], v[10:17]// 00000004EB80: CC40400A 1C2A2522
	v_cvt_f16_f32_e32 v18, v61                                 // 00000004EB88: 7E24153D
	v_mad_u32_u24 v22, 0x110, v154, v59                        // 00000004EB8C: D60B0016 04EF34FF 00000110
	.long 0x7f24153e                                           // 00000004EB98: 7F24153E
	v_cvt_f16_f32_e32 v19, v63                                 // 00000004EB9C: 7E26153F
	.long 0x7f261540                                           // 00000004EBA0: 7F261540
	v_cvt_f16_f32_e32 v20, v65                                 // 00000004EBA4: 7E281541
	.long 0x7f281542                                           // 00000004EBA8: 7F281542
	v_cvt_f16_f32_e32 v21, v67                                 // 00000004EBAC: 7E2A1543
	.long 0x7f2a1544                                           // 00000004EBB0: 7F2A1544
	ds_store_b16 v22, v18 offset:14848                         // 00000004EBB4: D87C3A00 00001216
	ds_store_b16_d16_hi v22, v18 offset:15392                  // 00000004EBBC: DA843C20 00001216
	ds_store_b16 v22, v19 offset:15936                         // 00000004EBC4: D87C3E40 00001316
	ds_store_b16_d16_hi v22, v19 offset:16480                  // 00000004EBCC: DA844060 00001316
	ds_store_b16 v22, v20 offset:17024                         // 00000004EBD4: D87C4280 00001416
	ds_store_b16_d16_hi v22, v20 offset:17568                  // 00000004EBDC: DA8444A0 00001416
	ds_store_b16 v22, v21 offset:18112                         // 00000004EBE4: D87C46C0 00001516
	ds_store_b16_d16_hi v22, v21 offset:18656                  // 00000004EBEC: DA8448E0 00001516
	v_fma_mixlo_f16 v18, v139, s51, 0                          // 00000004EBF4: CC210012 0200678B
	v_fma_mixhi_f16 v18, v138, s51, 0                          // 00000004EBFC: CC220012 0200678A
	v_mov_b32_e32 v20, 0x3020706                               // 00000004EC04: 7E2802FF 03020706
	v_cndmask_b32_e32 v61, 0x5040100, v149, vcc_lo             // 00000004EC0C: 027B2AFF 05040100
	s_waitcnt lgkmcnt(0)                                       // 00000004EC14: BF89FC07
	s_barrier                                                  // 00000004EC18: BFBD0000
	ds_load_b128 v[46:49], v57 offset:14864                    // 00000004EC1C: DBFC3A10 2E000039
	ds_load_b128 v[42:45], v57 offset:14848                    // 00000004EC24: DBFC3A00 2A000039
	ds_load_b128 v[67:70], v57 offset:14896                    // 00000004EC2C: DBFC3A30 43000039
	ds_load_b128 v[63:66], v57 offset:14880                    // 00000004EC34: DBFC3A20 3F000039
	v_dual_mov_b32 v19, v18 :: v_dual_cndmask_b32 v62, 0x7060302, v20// 00000004EC3C: CA120112 133E28FF 07060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EC48: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000004EC4C: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v26, v18, v19, v61                              // 00000004EC58: D644001A 04F62712
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000004EC60: BF8700B3
	v_perm_b32 v27, v18, v19, v62                              // 00000004EC64: D644001B 04FA2712
	v_fma_mixlo_f16 v18, v137, s51, 0                          // 00000004EC6C: CC210012 02006789
	v_fma_mixhi_f16 v18, v136, s51, 0                          // 00000004EC74: CC220012 02006788
	v_mov_b32_e32 v19, v18                                     // 00000004EC7C: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EC80: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000004EC84: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v28, v18, v19, v61                              // 00000004EC90: D644001C 04F62712
	v_perm_b32 v29, v18, v19, v62                              // 00000004EC98: D644001D 04FA2712
	v_fma_mixlo_f16 v18, v135, s51, 0                          // 00000004ECA0: CC210012 02006787
	v_fma_mixhi_f16 v18, v134, s51, 0                          // 00000004ECA8: CC220012 02006786
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ECB0: BF870091
	v_mov_b32_e32 v19, v18                                     // 00000004ECB4: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000004ECB8: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000004ECC4: BF8700C1
	v_perm_b32 v30, v18, v19, v61                              // 00000004ECC8: D644001E 04F62712
	v_perm_b32 v31, v18, v19, v62                              // 00000004ECD0: D644001F 04FA2712
	v_fma_mixlo_f16 v18, v133, s51, 0                          // 00000004ECD8: CC210012 02006785
	v_fma_mixhi_f16 v18, v54, s51, 0                           // 00000004ECE0: CC220012 02006736
	v_mov_b32_e32 v19, v18                                     // 00000004ECE8: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ECEC: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000004ECF0: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v32, v18, v19, v61                              // 00000004ECFC: D6440020 04F62712
	v_perm_b32 v33, v18, v19, v62                              // 00000004ED04: D6440021 04FA2712
	v_fma_mixlo_f16 v18, v132, s51, 0                          // 00000004ED0C: CC210012 02006784
	v_fma_mixhi_f16 v18, v131, s51, 0                          // 00000004ED14: CC220012 02006783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ED1C: BF870091
	v_mov_b32_e32 v19, v18                                     // 00000004ED20: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000004ED24: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000004ED30: BF8700C1
	v_perm_b32 v34, v18, v19, v61                              // 00000004ED34: D6440022 04F62712
	v_perm_b32 v35, v18, v19, v62                              // 00000004ED3C: D6440023 04FA2712
	v_fma_mixlo_f16 v18, v130, s51, 0                          // 00000004ED44: CC210012 02006782
	v_fma_mixhi_f16 v18, v129, s51, 0                          // 00000004ED4C: CC220012 02006781
	v_mov_b32_e32 v19, v18                                     // 00000004ED54: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ED58: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000004ED5C: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v36, v18, v19, v61                              // 00000004ED68: D6440024 04F62712
	v_perm_b32 v37, v18, v19, v62                              // 00000004ED70: D6440025 04FA2712
	v_fma_mixlo_f16 v18, v128, s51, 0                          // 00000004ED78: CC210012 02006780
	v_fma_mixhi_f16 v18, v127, s51, 0                          // 00000004ED80: CC220012 0200677F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ED88: BF870091
	v_mov_b32_e32 v19, v18                                     // 00000004ED8C: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000004ED90: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000004ED9C: BF8700C1
	v_perm_b32 v38, v18, v19, v61                              // 00000004EDA0: D6440026 04F62712
	v_perm_b32 v39, v18, v19, v62                              // 00000004EDA8: D6440027 04FA2712
	v_fma_mixlo_f16 v18, v126, s51, 0                          // 00000004EDB0: CC210012 0200677E
	v_fma_mixhi_f16 v18, v53, s51, 0                           // 00000004EDB8: CC220012 02006735
	v_mov_b32_e32 v19, v18                                     // 00000004EDC0: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EDC4: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000004EDC8: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v40, v18, v19, v61                              // 00000004EDD4: D6440028 04F62712
	v_perm_b32 v41, v18, v19, v62                              // 00000004EDDC: D6440029 04FA2712
	s_waitcnt lgkmcnt(2)                                       // 00000004EDE4: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[26:33], v[2:9]// 00000004EDE8: CC404012 1C0A352A
	s_waitcnt lgkmcnt(0)                                       // 00000004EDF0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004EDF4: BF870001
	v_wmma_f32_16x16x16_f16 v[18:25], v[63:70], v[34:41], v[18:25]// 00000004EDF8: CC404012 1C4A453F
	ds_load_b128 v[63:66], v57 offset:10496                    // 00000004EE00: DBFC2900 3F000039
	ds_load_b128 v[67:70], v57 offset:10512                    // 00000004EE08: DBFC2910 43000039
	s_waitcnt lgkmcnt(0)                                       // 00000004EE10: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[63:70], v[26:33], v[2:9]// 00000004EE14: CC40402A 1C0A353F
	ds_load_b128 v[26:29], v57 offset:10528                    // 00000004EE1C: DBFC2920 1A000039
	ds_load_b128 v[30:33], v57 offset:10544                    // 00000004EE24: DBFC2930 1E000039
	s_waitcnt lgkmcnt(0)                                       // 00000004EE2C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[26:33], v[34:41], v[42:49]// 00000004EE30: CC40402A 1CAA451A
	v_fma_mixlo_f16 v27, v125, s51, 0                          // 00000004EE38: CC21001B 0200677D
	v_fma_mixhi_f16 v27, v124, s51, 0                          // 00000004EE40: CC22001B 0200677C
	v_fma_mixlo_f16 v29, v123, s51, 0                          // 00000004EE48: CC21001D 0200677B
	v_fma_mixhi_f16 v29, v122, s51, 0                          // 00000004EE50: CC22001D 0200677A
	v_fma_mixlo_f16 v31, v121, s51, 0                          // 00000004EE58: CC21001F 02006779
	v_fma_mixhi_f16 v31, v120, s51, 0                          // 00000004EE60: CC22001F 02006778
	v_fma_mixlo_f16 v33, v119, s51, 0                          // 00000004EE68: CC210021 02006777
	v_fma_mixhi_f16 v33, v52, s51, 0                           // 00000004EE70: CC220021 02006734
	v_mov_b32_e32 v28, v27                                     // 00000004EE78: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000004EE7C: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000004EE80: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004EE84: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000004EE88: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000004EE8C: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004EE98: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000004EE9C: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000004EEA8: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004EEB4: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000004EEB8: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000004EEC4: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000004EECC: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000004EED4: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000004EEDC: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000004EEE4: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000004EEEC: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000004EEF4: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000004EEFC: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14928                    // 00000004EF04: DBFC3A50 26000039
	ds_load_b128 v[34:37], v57 offset:14912                    // 00000004EF0C: DBFC3A40 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000004EF14: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000004EF18: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10576                    // 00000004EF20: DBFC2950 26000039
	ds_load_b128 v[34:37], v57 offset:10560                    // 00000004EF28: DBFC2940 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000004EF30: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000004EF34: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v118, s51, 0                          // 00000004EF3C: CC21001B 02006776
	v_fma_mixhi_f16 v27, v117, s51, 0                          // 00000004EF44: CC22001B 02006775
	v_fma_mixlo_f16 v29, v116, s51, 0                          // 00000004EF4C: CC21001D 02006774
	v_fma_mixhi_f16 v29, v115, s51, 0                          // 00000004EF54: CC22001D 02006773
	v_fma_mixlo_f16 v31, v114, s51, 0                          // 00000004EF5C: CC21001F 02006772
	v_fma_mixhi_f16 v31, v113, s51, 0                          // 00000004EF64: CC22001F 02006771
	v_fma_mixlo_f16 v33, v112, s51, 0                          // 00000004EF6C: CC210021 02006770
	v_fma_mixhi_f16 v33, v51, s51, 0                           // 00000004EF74: CC220021 02006733
	v_mov_b32_e32 v28, v27                                     // 00000004EF7C: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000004EF80: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000004EF84: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004EF88: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000004EF8C: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000004EF90: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004EF9C: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000004EFA0: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000004EFAC: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004EFB8: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000004EFBC: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000004EFC8: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000004EFD0: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000004EFD8: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000004EFE0: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000004EFE8: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000004EFF0: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000004EFF8: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000004F000: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14960                    // 00000004F008: DBFC3A70 26000039
	ds_load_b128 v[34:37], v57 offset:14944                    // 00000004F010: DBFC3A60 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000004F018: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000004F01C: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10608                    // 00000004F024: DBFC2970 26000039
	ds_load_b128 v[34:37], v57 offset:10592                    // 00000004F02C: DBFC2960 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000004F034: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000004F038: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v111, s51, 0                          // 00000004F040: CC21001B 0200676F
	v_fma_mixhi_f16 v27, v110, s51, 0                          // 00000004F048: CC22001B 0200676E
	v_fma_mixlo_f16 v29, v109, s51, 0                          // 00000004F050: CC21001D 0200676D
	v_fma_mixhi_f16 v29, v108, s51, 0                          // 00000004F058: CC22001D 0200676C
	v_fma_mixlo_f16 v31, v107, s51, 0                          // 00000004F060: CC21001F 0200676B
	v_fma_mixhi_f16 v31, v106, s51, 0                          // 00000004F068: CC22001F 0200676A
	v_fma_mixlo_f16 v33, v105, s51, 0                          // 00000004F070: CC210021 02006769
	v_fma_mixhi_f16 v33, v50, s51, 0                           // 00000004F078: CC220021 02006732
	v_mov_b32_e32 v28, v27                                     // 00000004F080: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000004F084: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000004F088: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004F08C: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000004F090: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000004F094: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004F0A0: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000004F0A4: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000004F0B0: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004F0BC: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000004F0C0: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000004F0CC: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000004F0D4: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000004F0DC: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000004F0E4: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000004F0EC: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000004F0F4: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000004F0FC: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000004F104: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14992                    // 00000004F10C: DBFC3A90 26000039
	ds_load_b128 v[34:37], v57 offset:14976                    // 00000004F114: DBFC3A80 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000004F11C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000004F120: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10640                    // 00000004F128: DBFC2990 26000039
	ds_load_b128 v[34:37], v57 offset:10624                    // 00000004F130: DBFC2980 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000004F138: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000004F13C: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v104, s51, 0                          // 00000004F144: CC21001B 02006768
	v_fma_mixhi_f16 v27, v103, s51, 0                          // 00000004F14C: CC22001B 02006767
	v_fma_mixlo_f16 v29, v102, s51, 0                          // 00000004F154: CC21001D 02006766
	v_fma_mixhi_f16 v29, v101, s51, 0                          // 00000004F15C: CC22001D 02006765
	v_fma_mixlo_f16 v31, v100, s51, 0                          // 00000004F164: CC21001F 02006764
	v_fma_mixhi_f16 v31, v99, s51, 0                           // 00000004F16C: CC22001F 02006763
	v_fma_mixlo_f16 v33, v98, s51, 0                           // 00000004F174: CC210021 02006762
	v_fma_mixhi_f16 v33, v58, s51, 0                           // 00000004F17C: CC220021 0200673A
	v_mov_b32_e32 v28, v27                                     // 00000004F184: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000004F188: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000004F18C: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004F190: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000004F194: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000004F198: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004F1A4: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000004F1A8: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000004F1B4: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004F1C0: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000004F1C4: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000004F1D0: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000004F1D8: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000004F1E0: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000004F1E8: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000004F1F0: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000004F1F8: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000004F200: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000004F208: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15024                    // 00000004F210: DBFC3AB0 26000039
	ds_load_b128 v[34:37], v57 offset:15008                    // 00000004F218: DBFC3AA0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000004F220: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000004F224: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10672                    // 00000004F22C: DBFC29B0 26000039
	ds_load_b128 v[34:37], v57 offset:10656                    // 00000004F234: DBFC29A0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000004F23C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000004F240: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v97, s51, 0                           // 00000004F248: CC21001B 02006761
	v_fma_mixhi_f16 v27, v96, s51, 0                           // 00000004F250: CC22001B 02006760
	v_fma_mixlo_f16 v29, v95, s51, 0                           // 00000004F258: CC21001D 0200675F
	v_fma_mixhi_f16 v29, v94, s51, 0                           // 00000004F260: CC22001D 0200675E
	v_fma_mixlo_f16 v31, v93, s51, 0                           // 00000004F268: CC21001F 0200675D
	v_fma_mixhi_f16 v31, v92, s51, 0                           // 00000004F270: CC22001F 0200675C
	v_fma_mixlo_f16 v33, v91, s51, 0                           // 00000004F278: CC210021 0200675B
	v_fma_mixhi_f16 v33, v152, s51, 0                          // 00000004F280: CC220021 02006798
	v_mov_b32_e32 v28, v27                                     // 00000004F288: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000004F28C: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000004F290: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004F294: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000004F298: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000004F29C: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004F2A8: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000004F2AC: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000004F2B8: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004F2C4: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000004F2C8: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000004F2D4: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000004F2DC: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000004F2E4: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000004F2EC: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000004F2F4: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000004F2FC: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000004F304: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000004F30C: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15056                    // 00000004F314: DBFC3AD0 26000039
	ds_load_b128 v[34:37], v57 offset:15040                    // 00000004F31C: DBFC3AC0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000004F324: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000004F328: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10704                    // 00000004F330: DBFC29D0 26000039
	ds_load_b128 v[34:37], v57 offset:10688                    // 00000004F338: DBFC29C0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000004F340: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000004F344: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v90, s51, 0                           // 00000004F34C: CC21001B 0200675A
	v_fma_mixhi_f16 v27, v141, s51, 0                          // 00000004F354: CC22001B 0200678D
	v_fma_mixlo_f16 v29, v150, s51, 0                          // 00000004F35C: CC21001D 02006796
	v_fma_mixhi_f16 v29, v142, s51, 0                          // 00000004F364: CC22001D 0200678E
	v_fma_mixlo_f16 v31, v191, s51, 0                          // 00000004F36C: CC21001F 020067BF
	v_fma_mixhi_f16 v31, v189, s51, 0                          // 00000004F374: CC22001F 020067BD
	v_fma_mixlo_f16 v33, v190, s51, 0                          // 00000004F37C: CC210021 020067BE
	v_fma_mixhi_f16 v33, v151, s51, 0                          // 00000004F384: CC220021 02006797
	v_mov_b32_e32 v28, v27                                     // 00000004F38C: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000004F390: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000004F394: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004F398: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000004F39C: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000004F3A0: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004F3AC: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000004F3B0: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000004F3BC: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004F3C8: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000004F3CC: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000004F3D8: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000004F3E0: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000004F3E8: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000004F3F0: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000004F3F8: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000004F400: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000004F408: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000004F410: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15088                    // 00000004F418: DBFC3AF0 26000039
	ds_load_b128 v[34:37], v57 offset:15072                    // 00000004F420: DBFC3AE0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000004F428: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000004F42C: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10736                    // 00000004F434: DBFC29F0 26000039
	ds_load_b128 v[34:37], v57 offset:10720                    // 00000004F43C: DBFC29E0 22000039
	v_dual_mul_f32 v18, 0x3b800000, v18 :: v_dual_mul_f32 v19, 0x3b800000, v19// 00000004F444: C8C624FF 121226FF 3B800000
	v_dual_mul_f32 v20, 0x3b800000, v20 :: v_dual_mul_f32 v21, 0x3b800000, v21// 00000004F450: C8C628FF 14142AFF 3B800000
	v_mul_f32_e32 v22, 0x3b800000, v22                         // 00000004F45C: 102C2CFF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004F464: BF870223
	v_sub_f32_e32 v10, v10, v18                                // 00000004F468: 0814250A
	v_or_b32_e32 v18, s54, v154                                // 00000004F46C: 38253436
	v_dual_sub_f32 v11, v11, v19 :: v_dual_sub_f32 v12, v12, v20// 00000004F470: C94A270B 0B0C290C
	v_sub_f32_e32 v13, v13, v21                                // 00000004F478: 081A2B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004F47C: BF870214
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 00000004F480: CC21000A 0200610A
	v_or_b32_e32 v19, 2, v18                                   // 00000004F488: 38262482
	.long 0xd4440003                                           // 00000004F48C: D4440003
	v_cndmask_b32_e32 v1, s39, v18, vcc_lo                     // 00000004F490: 02022427
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 00000004F494: CC22000A 0200610B
	v_dual_mul_f32 v23, 0x3b800000, v23 :: v_dual_sub_f32 v14, v14, v22// 00000004F49C: C8CA2EFF 170E2D0E 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004F4A8: BF870214
	v_cmp_gt_i32_e32 vcc_lo, s39, v19                          // 00000004F4AC: 7C882627
	v_cndmask_b16 v10, 0, v10, s3                              // 00000004F4B0: D65D000A 000E1480
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000004F4B8: BF8701D3
	v_dual_mul_f32 v24, 0x3b800000, v24 :: v_dual_sub_f32 v15, v15, v23// 00000004F4BC: C8CA30FF 180E2F0F 3B800000
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 00000004F4C8: 103232FF 3B800000
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000004F4D0: D65D500A 01AA1480
	s_waitcnt lgkmcnt(0)                                       // 00000004F4D8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000004F4DC: CC40402A 1CAA3522
	v_dual_sub_f32 v16, v16, v24 :: v_dual_sub_f32 v17, v17, v25// 00000004F4E4: C94A3110 10103311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000004F4EC: BF8700C3
	v_mov_b32_e32 v11, v10                                     // 00000004F4F0: 7E16030A
	ds_load_b128 v[19:22], v60 offset:23296                    // 00000004F4F4: DBFC5B00 1300003C
	ds_load_b128 v[23:26], v60 offset:23312                    // 00000004F4FC: DBFC5B10 1700003C
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000004F504: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v66, v10, v11, v61                              // 00000004F510: D6440042 04F6170A
	v_perm_b32 v67, v10, v11, v62                              // 00000004F518: D6440043 04FA170A
	v_or_b32_e32 v10, 4, v18                                   // 00000004F520: 38142484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004F524: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 00000004F528: 7C881427
	v_or_b32_e32 v10, 6, v18                                   // 00000004F52C: 38142486
	.long 0xd4440004                                           // 00000004F530: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 00000004F534: 02021427
	v_fma_mixlo_f16 v10, v12, s48, 0                           // 00000004F538: CC21000A 0200610C
	v_fma_mixhi_f16 v10, v13, s48, 0                           // 00000004F540: CC22000A 0200610D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004F548: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000004F54C: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s4                              // 00000004F554: D65D500A 00121480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F55C: BF870091
	v_mov_b32_e32 v11, v10                                     // 00000004F560: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000004F564: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000004F570: BF8700B1
	v_perm_b32 v68, v10, v11, v61                              // 00000004F574: D6440044 04F6170A
	v_perm_b32 v69, v10, v11, v62                              // 00000004F57C: D6440045 04FA170A
	v_or_b32_e32 v10, 8, v18                                   // 00000004F584: 38142488
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 00000004F588: 7C881427
	v_or_b32_e32 v10, 10, v18                                  // 00000004F58C: 3814248A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000004F590: BF870131
	.long 0xd4440004                                           // 00000004F594: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 00000004F598: 02021427
	v_fma_mixlo_f16 v10, v14, s48, 0                           // 00000004F59C: CC21000A 0200610E
	v_fma_mixhi_f16 v10, v15, s48, 0                           // 00000004F5A4: CC22000A 0200610F
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000004F5AC: D65D000A 01AA1480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F5B4: BF870092
	v_cndmask_b16 v10, 0, v10, s4                              // 00000004F5B8: D65D500A 00121480
	v_mov_b32_e32 v11, v10                                     // 00000004F5C0: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F5C4: BF870091
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000004F5C8: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v70, v10, v11, v61                              // 00000004F5D4: D6440046 04F6170A
	v_perm_b32 v71, v10, v11, v62                              // 00000004F5DC: D6440047 04FA170A
	v_or_b32_e32 v10, 12, v18                                  // 00000004F5E4: 3814248C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004F5E8: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 00000004F5EC: 7C881427
	v_or_b32_e32 v10, 14, v18                                  // 00000004F5F0: 3814248E
	.long 0xd4440004                                           // 00000004F5F4: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 00000004F5F8: 02021427
	v_fma_mixlo_f16 v10, v16, s48, 0                           // 00000004F5FC: CC21000A 02006110
	v_fma_mixhi_f16 v10, v17, s48, 0                           // 00000004F604: CC22000A 02006111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004F60C: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000004F610: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s4                              // 00000004F618: D65D500A 00121480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F620: BF870091
	v_mov_b32_e32 v11, v10                                     // 00000004F624: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000004F628: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000004F634: BF8700B1
	v_perm_b32 v72, v10, v11, v61                              // 00000004F638: D6440048 04F6170A
	v_perm_b32 v73, v10, v11, v62                              // 00000004F640: D6440049 04FA170A
	s_waitcnt lgkmcnt(0)                                       // 00000004F648: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[19:26], v[66:73], v[2:9]// 00000004F64C: CC40400A 1C0A8513
	.long 0xd7000402                                           // 00000004F654: D7000402
	v_cndmask_b32_e32 v1, s44, v59, vcc_lo                     // 00000004F658: 0202762C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004F65C: BF870001
	v_add_co_ci_u32_e64 v3, null, s45, 0, s4                   // 00000004F660: D5207C03 0011002D
	s_and_saveexec_b32 s4, s3                                  // 00000004F668: BE842003
	s_cbranch_execz 19                                         // 00000004F66C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3cbc>
	ds_load_b32 v4, v56 offset:24320                           // 00000004F670: D8D85F00 04000038
	s_waitcnt lgkmcnt(0)                                       // 00000004F678: BF89FC07
	v_mul_f32_e32 v4, v42, v4                                  // 00000004F67C: 1008092A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F680: BF870091
	v_add_f32_e32 v4, v10, v4                                  // 00000004F684: 0608090A
	v_mul_f32_e32 v6, 0x3b800000, v4                           // 00000004F688: 100C08FF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v18, v[2:3]            // 00000004F690: D6FE7C04 040A24FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F69C: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000004F6A0: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000004F6A8: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000004F6B4: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s4                              // 00000004F6BC: 8C7E047E
	v_or3_b32 v4, v154, s54, 2                                 // 00000004F6C0: D6580004 02086D9A
	s_mov_b32 s3, exec_lo                                      // 00000004F6C8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004F6CC: BF870001
	.long 0xd4c4007e                                           // 00000004F6D0: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000004F6D4: 02020827
	s_cbranch_execz 19                                         // 00000004F6D8: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3d28>
	ds_load_b32 v5, v56 offset:24328                           // 00000004F6DC: D8D85F08 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000004F6E4: BF89FC07
	v_mul_f32_e32 v5, v43, v5                                  // 00000004F6E8: 100A0B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F6EC: BF870091
	v_add_f32_e32 v5, v11, v5                                  // 00000004F6F0: 060A0B0B
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000004F6F4: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000004F6FC: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F708: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000004F70C: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000004F714: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000004F720: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004F728: 8C7E037E
	v_or3_b32 v4, v154, s54, 4                                 // 00000004F72C: D6580004 02106D9A
	s_mov_b32 s3, exec_lo                                      // 00000004F734: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004F738: BF870001
	.long 0xd4c4007e                                           // 00000004F73C: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000004F740: 02020827
	s_cbranch_execz 19                                         // 00000004F744: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3d94>
	ds_load_b32 v5, v56 offset:24336                           // 00000004F748: D8D85F10 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000004F750: BF89FC07
	v_mul_f32_e32 v5, v44, v5                                  // 00000004F754: 100A0B2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F758: BF870091
	v_add_f32_e32 v5, v12, v5                                  // 00000004F75C: 060A0B0C
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000004F760: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000004F768: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F774: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000004F778: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000004F780: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000004F78C: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004F794: 8C7E037E
	v_or3_b32 v4, v154, s54, 6                                 // 00000004F798: D6580004 02186D9A
	s_mov_b32 s3, exec_lo                                      // 00000004F7A0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004F7A4: BF870001
	.long 0xd4c4007e                                           // 00000004F7A8: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000004F7AC: 02020827
	s_cbranch_execz 19                                         // 00000004F7B0: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3e00>
	ds_load_b32 v5, v56 offset:24344                           // 00000004F7B4: D8D85F18 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000004F7BC: BF89FC07
	v_mul_f32_e32 v5, v45, v5                                  // 00000004F7C0: 100A0B2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F7C4: BF870091
	v_add_f32_e32 v5, v13, v5                                  // 00000004F7C8: 060A0B0D
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000004F7CC: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000004F7D4: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F7E0: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000004F7E4: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000004F7EC: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000004F7F8: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004F800: 8C7E037E
	v_or3_b32 v4, v154, s54, 8                                 // 00000004F804: D6580004 02206D9A
	s_mov_b32 s3, exec_lo                                      // 00000004F80C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004F810: BF870001
	.long 0xd4c4007e                                           // 00000004F814: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000004F818: 02020827
	s_cbranch_execz 19                                         // 00000004F81C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3e6c>
	ds_load_b32 v5, v56 offset:24352                           // 00000004F820: D8D85F20 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000004F828: BF89FC07
	v_mul_f32_e32 v5, v46, v5                                  // 00000004F82C: 100A0B2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F830: BF870091
	v_add_f32_e32 v5, v14, v5                                  // 00000004F834: 060A0B0E
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000004F838: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000004F840: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F84C: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000004F850: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000004F858: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000004F864: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004F86C: 8C7E037E
	v_or3_b32 v4, v154, s54, 10                                // 00000004F870: D6580004 02286D9A
	s_mov_b32 s3, exec_lo                                      // 00000004F878: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004F87C: BF870001
	.long 0xd4c4007e                                           // 00000004F880: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000004F884: 02020827
	s_cbranch_execz 19                                         // 00000004F888: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3ed8>
	ds_load_b32 v5, v56 offset:24360                           // 00000004F88C: D8D85F28 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000004F894: BF89FC07
	v_mul_f32_e32 v5, v47, v5                                  // 00000004F898: 100A0B2F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F89C: BF870091
	v_add_f32_e32 v5, v15, v5                                  // 00000004F8A0: 060A0B0F
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000004F8A4: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000004F8AC: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F8B8: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000004F8BC: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000004F8C4: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000004F8D0: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004F8D8: 8C7E037E
	v_or3_b32 v4, v154, s54, 12                                // 00000004F8DC: D6580004 02306D9A
	s_mov_b32 s3, exec_lo                                      // 00000004F8E4: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004F8E8: BF870001
	.long 0xd4c4007e                                           // 00000004F8EC: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000004F8F0: 02020827
	s_cbranch_execz 19                                         // 00000004F8F4: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3f44>
	ds_load_b32 v5, v56 offset:24368                           // 00000004F8F8: D8D85F30 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000004F900: BF89FC07
	v_mul_f32_e32 v5, v48, v5                                  // 00000004F904: 100A0B30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F908: BF870091
	v_add_f32_e32 v5, v16, v5                                  // 00000004F90C: 060A0B10
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000004F910: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000004F918: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F924: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000004F928: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000004F930: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000004F93C: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004F944: 8C7E037E
	v_or3_b32 v4, v154, s54, 14                                // 00000004F948: D6580004 02386D9A
	s_mov_b32 s3, exec_lo                                      // 00000004F950: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004F954: BF870001
	.long 0xd4c4007e                                           // 00000004F958: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000004F95C: 02020827
	s_cbranch_execz 19                                         // 00000004F960: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3fb0>
	ds_load_b32 v5, v56 offset:24376                           // 00000004F964: D8D85F38 05000038
	v_mad_u64_u32 v[2:3], null, 0x3000, v4, v[2:3]             // 00000004F96C: D6FE7C02 040A08FF 00003000
	s_waitcnt lgkmcnt(0)                                       // 00000004F978: BF89FC07
	v_mul_f32_e32 v5, v49, v5                                  // 00000004F97C: 100A0B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F980: BF870091
	v_add_f32_e32 v5, v17, v5                                  // 00000004F984: 060A0B11
	v_mul_f32_e32 v5, 0x3b800000, v5                           // 00000004F988: 100A0AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F990: BF870091
	v_bfe_u32 v6, v5, 16, 1                                    // 00000004F994: D6100006 02052105
	v_add3_u32 v4, v5, v6, 0x7fff                              // 00000004F99C: D6550004 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000004F9A8: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004F9B0: 8C7E037E
	ds_load_b32 v56, v1 offset:24188                           // 00000004F9B4: D8D85E7C 38000001
	v_mad_u32_u24 v2, v55, 48, 0x4b00                          // 00000004F9BC: D60B0002 03FD6137 00004B00
	s_add_i32 s54, s54, 16                                     // 00000004F9C8: 81369036
	v_mov_b32_e32 v178, s27                                    // 00000004F9CC: 7F64021B
	v_dual_mov_b32 v176, s25 :: v_dual_mov_b32 v173, s22       // 00000004F9D0: CA100019 B0AC0016
	s_delay_alu instid0(VALU_DEP_3)                            // 00000004F9D8: BF870003
	v_dual_mov_b32 v174, s23 :: v_dual_add_nc_u32 v55, 0xffffb500, v2// 00000004F9DC: CA200017 AE3604FF FFFFB500
	v_dual_mov_b32 v171, s20 :: v_dual_mov_b32 v172, s21       // 00000004F9E8: CA100014 ABAC0015
	ds_load_b128 v[159:162], v55 offset:2320                   // 00000004F9F0: DBFC0910 9F000037
	ds_load_b128 v[155:158], v55 offset:2304                   // 00000004F9F8: DBFC0900 9B000037
	ds_load_b128 v[167:170], v55 offset:3088                   // 00000004FA00: DBFC0C10 A7000037
	ds_load_b128 v[163:166], v55 offset:3072                   // 00000004FA08: DBFC0C00 A3000037
	ds_load_b128 v[2:5], v55                                   // 00000004FA10: DBFC0000 02000037
	ds_load_b128 v[6:9], v55 offset:16                         // 00000004FA18: DBFC0010 06000037
	ds_load_b128 v[82:85], v55 offset:4608                     // 00000004FA20: DBFC1200 52000037
	ds_load_b128 v[183:186], v55 offset:3856                   // 00000004FA28: DBFC0F10 B7000037
	ds_load_b128 v[179:182], v55 offset:3840                   // 00000004FA30: DBFC0F00 B3000037
	ds_load_b128 v[86:89], v55 offset:4624                     // 00000004FA38: DBFC1210 56000037
	v_mov_b32_e32 v177, s26                                    // 00000004FA40: 7F62021A
	v_mov_b32_e32 v175, s24                                    // 00000004FA44: 7F5E0218
	s_waitcnt lgkmcnt(10)                                      // 00000004FA48: BF89FCA7
	v_readfirstlane_b32 s3, v56                                // 00000004FA4C: 7E060538
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v56                  // 00000004FA50: 7C3670FF C2CE8ED0
	s_mul_f32 s3, s3, 0x3fb8aa3b                               // 00000004FA58: A203FF03 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 00000004FA60: BF87000B
	s_xor_b32 s4, s3, 0x80000000                               // 00000004FA64: 8D04FF03 80000000
	s_cmp_lg_u32 s12, s54                                      // 00000004FA6C: BF07360C
	v_fma_f32 v10, 0x3fb8aa3b, v56, s4                         // 00000004FA70: D613000A 001270FF 3FB8AA3B
	s_rndne_f32 s4, s3                                         // 00000004FA7C: BE846303
	s_waitcnt lgkmcnt(4)                                       // 00000004FA80: BF89FC47
	v_wmma_f32_16x16x16_f16 v[34:41], v[2:9], v[66:73], v[171:178]// 00000004FA84: CC404022 1EAE8502
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004FA8C: BF870002
	v_fmac_f32_e32 v10, 0x32a5705f, v56                        // 00000004FA90: 561470FF 32A5705F
	s_sub_f32 s3, s3, s4                                       // 00000004FA98: A0830403
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_3)    // 00000004FA9C: BF870581
	v_add_f32_e32 v18, s3, v10                                 // 00000004FAA0: 06241403
	s_cvt_i32_f32 s3, s4                                       // 00000004FAA4: BE836604
	ds_load_b128 v[14:17], v55 offset:784                      // 00000004FAA8: DBFC0310 0E000037
	ds_load_b128 v[10:13], v55 offset:768                      // 00000004FAB0: DBFC0300 0A000037
	ds_load_b128 v[46:49], v55 offset:1552                     // 00000004FAB8: DBFC0610 2E000037
	ds_load_b128 v[42:45], v55 offset:1536                     // 00000004FAC0: DBFC0600 2A000037
	v_exp_f32_e32 v18, v18                                     // 00000004FAC8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FACC: BF870095
	.long 0xd71c0012                                           // 00000004FAD0: D71C0012
	v_cndmask_b32_e32 v0, v18, v3, vcc_lo                      // 00000004FAD4: 02000712
	v_cndmask_b32_e32 v2, 0, v18, vcc_lo                       // 00000004FAD8: 02042480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v56                  // 00000004FADC: 7C3C70FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FAE4: BF870092
	v_cndmask_b32_e32 v145, 0x7f800000, v2, vcc_lo             // 00000004FAE8: 032204FF 7F800000
	v_fmac_f32_e32 v41, v54, v145                              // 00000004FAF0: 56532336
	s_waitcnt lgkmcnt(2)                                       // 00000004FAF4: BF89FC27
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[66:73], v[171:178]// 00000004FAF8: CC40401A 1EAE850A
	v_wmma_f32_16x16x16_f16 v[10:17], v[155:162], v[66:73], v[171:178]// 00000004FB00: CC40400A 1EAE859B
	ds_load_b128 v[159:162], v55 offset:5392                   // 00000004FB08: DBFC1510 9F000037
	ds_load_b128 v[155:158], v55 offset:5376                   // 00000004FB10: DBFC1500 9B000037
	s_waitcnt lgkmcnt(2)                                       // 00000004FB18: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[66:73], v[171:178]// 00000004FB1C: CC404012 1EAE852A
	v_wmma_f32_16x16x16_f16 v[2:9], v[163:170], v[66:73], v[171:178]// 00000004FB24: CC404002 1EAE85A3
	v_wmma_f32_16x16x16_f16 v[42:49], v[179:186], v[66:73], v[171:178]// 00000004FB2C: CC40402A 1EAE85B3
	v_fma_f32 v138, v138, v145, v35                            // 00000004FB34: D613008A 048F238A
	v_fma_f32 v136, v136, v145, v37                            // 00000004FB3C: D6130088 04972388
	v_fma_f32 v135, v135, v145, v38                            // 00000004FB44: D6130087 049B2387
	v_fma_f32 v131, v131, v145, v27                            // 00000004FB4C: D6130083 046F2383
	v_fmac_f32_e32 v33, v53, v145                              // 00000004FB54: 56432335
	v_fmac_f32_e32 v25, v52, v145                              // 00000004FB58: 56332334
	v_fmac_f32_e32 v17, v51, v145                              // 00000004FB5C: 56232333
	v_fmac_f32_e32 v9, v50, v145                               // 00000004FB60: 56132332
	v_wmma_f32_16x16x16_f16 v[50:57], v[82:89], v[66:73], v[171:178]// 00000004FB64: CC404032 1EAE8552
	v_fmac_f32_e32 v49, v58, v145                              // 00000004FB6C: 5663233A
	v_fma_f32 v139, v139, v145, v34                            // 00000004FB70: D613008B 048B238B
	v_fma_f32 v137, v137, v145, v36                            // 00000004FB78: D6130089 04932389
	s_waitcnt lgkmcnt(0)                                       // 00000004FB80: BF89FC07
	v_wmma_f32_16x16x16_f16 v[58:65], v[155:162], v[66:73], v[171:178]// 00000004FB84: CC40403A 1EAE859B
	v_fma_f32 v134, v134, v145, v39                            // 00000004FB8C: D6130086 049F2386
	v_fma_f32 v133, v133, v145, v40                            // 00000004FB94: D6130085 04A32385
	v_fma_f32 v132, v132, v145, v26                            // 00000004FB9C: D6130084 046B2384
	v_fma_f32 v130, v130, v145, v28                            // 00000004FBA4: D6130082 04732382
	v_fma_f32 v129, v129, v145, v29                            // 00000004FBAC: D6130081 04772381
	v_fma_f32 v128, v128, v145, v30                            // 00000004FBB4: D6130080 047B2380
	v_fma_f32 v127, v127, v145, v31                            // 00000004FBBC: D613007F 047F237F
	v_fma_f32 v126, v126, v145, v32                            // 00000004FBC4: D613007E 0483237E
	v_fma_f32 v125, v125, v145, v18                            // 00000004FBCC: D613007D 044B237D
	v_fma_f32 v124, v124, v145, v19                            // 00000004FBD4: D613007C 044F237C
	v_fma_f32 v123, v123, v145, v20                            // 00000004FBDC: D613007B 0453237B
	v_fma_f32 v122, v122, v145, v21                            // 00000004FBE4: D613007A 0457237A
	v_fma_f32 v121, v121, v145, v22                            // 00000004FBEC: D6130079 045B2379
	v_fma_f32 v120, v120, v145, v23                            // 00000004FBF4: D6130078 045F2378
	v_fma_f32 v119, v119, v145, v24                            // 00000004FBFC: D6130077 04632377
	v_fma_f32 v118, v118, v145, v10                            // 00000004FC04: D6130076 042B2376
	v_fma_f32 v117, v117, v145, v11                            // 00000004FC0C: D6130075 042F2375
	v_fma_f32 v116, v116, v145, v12                            // 00000004FC14: D6130074 04332374
	v_fma_f32 v115, v115, v145, v13                            // 00000004FC1C: D6130073 04372373
	v_fma_f32 v114, v114, v145, v14                            // 00000004FC24: D6130072 043B2372
	v_fma_f32 v113, v113, v145, v15                            // 00000004FC2C: D6130071 043F2371
	v_fma_f32 v112, v112, v145, v16                            // 00000004FC34: D6130070 04432370
	v_fma_f32 v111, v111, v145, v2                             // 00000004FC3C: D613006F 040B236F
	v_fma_f32 v110, v110, v145, v3                             // 00000004FC44: D613006E 040F236E
	v_fma_f32 v109, v109, v145, v4                             // 00000004FC4C: D613006D 0413236D
	v_fma_f32 v108, v108, v145, v5                             // 00000004FC54: D613006C 0417236C
	v_fma_f32 v107, v107, v145, v6                             // 00000004FC5C: D613006B 041B236B
	v_fma_f32 v106, v106, v145, v7                             // 00000004FC64: D613006A 041F236A
	v_fma_f32 v105, v105, v145, v8                             // 00000004FC6C: D6130069 04232369
	v_fma_f32 v104, v104, v145, v42                            // 00000004FC74: D6130068 04AB2368
	v_fma_f32 v103, v103, v145, v43                            // 00000004FC7C: D6130067 04AF2367
	v_fma_f32 v102, v102, v145, v44                            // 00000004FC84: D6130066 04B32366
	v_fma_f32 v101, v101, v145, v45                            // 00000004FC8C: D6130065 04B72365
	v_fma_f32 v100, v100, v145, v46                            // 00000004FC94: D6130064 04BB2364
	v_fma_f32 v99, v99, v145, v47                              // 00000004FC9C: D6130063 04BF2363
	v_fma_f32 v98, v98, v145, v48                              // 00000004FCA4: D6130062 04C32362
	v_fma_f32 v97, v97, v145, v50                              // 00000004FCAC: D6130061 04CB2361
	v_fma_f32 v96, v96, v145, v51                              // 00000004FCB4: D6130060 04CF2360
	v_fma_f32 v95, v95, v145, v52                              // 00000004FCBC: D613005F 04D3235F
	v_fma_f32 v94, v94, v145, v53                              // 00000004FCC4: D613005E 04D7235E
	v_fma_f32 v93, v93, v145, v54                              // 00000004FCCC: D613005D 04DB235D
	v_fma_f32 v92, v92, v145, v55                              // 00000004FCD4: D613005C 04DF235C
	v_fma_f32 v91, v91, v145, v56                              // 00000004FCDC: D613005B 04E3235B
	v_fmac_f32_e32 v57, v152, v145                             // 00000004FCE4: 56732398
	v_fma_f32 v90, v90, v145, v58                              // 00000004FCE8: D613005A 04EB235A
	v_fma_f32 v141, v141, v145, v59                            // 00000004FCF0: D613008D 04EF238D
	v_fma_f32 v150, v150, v145, v60                            // 00000004FCF8: D6130096 04F32396
	v_fma_f32 v142, v142, v145, v61                            // 00000004FD00: D613008E 04F7238E
	v_fma_f32 v191, v191, v145, v62                            // 00000004FD08: D61300BF 04FB23BF
	v_fma_f32 v189, v189, v145, v63                            // 00000004FD10: D61300BD 04FF23BD
	v_fma_f32 v190, v190, v145, v64                            // 00000004FD18: D61300BE 050323BE
	v_dual_fmac_f32 v65, v151, v145 :: v_dual_mul_f32 v6, 0x3b800000, v128// 00000004FD20: C8072397 410700FF 3B800000
	v_lshl_add_u32 v2, v154, 7, v153                           // 00000004FD2C: D6460002 06650F9A
	v_dual_mul_f32 v69, 0x3b800000, v139 :: v_dual_mul_f32 v152, 0x3b800000, v41// 00000004FD34: C8C716FF 459852FF 3B800000
	v_dual_mul_f32 v70, 0x3b800000, v138 :: v_dual_mul_f32 v71, 0x3b800000, v137// 00000004FD40: C8C714FF 464712FF 3B800000
	v_mul_f32_e32 v64, 0x3b800000, v127                        // 00000004FD4C: 1080FEFF 3B800000
	v_mul_f32_e32 v72, 0x3b800000, v136                        // 00000004FD54: 109110FF 3B800000
	v_dual_mul_f32 v4, 0x3b800000, v135 :: v_dual_mul_f32 v73, 0x3b800000, v134// 00000004FD5C: C8C70EFF 04490CFF 3B800000
	v_dual_mul_f32 v60, 0x3b800000, v123 :: v_dual_mul_f32 v151, 0x3b800000, v133// 00000004FD68: C8C6F6FF 3C970AFF 3B800000
	v_dual_mul_f32 v66, 0x3b800000, v126 :: v_dual_mul_f32 v5, 0x3b800000, v132// 00000004FD74: C8C6FCFF 420508FF 3B800000
	v_mul_f32_e32 v8, 0x3b800000, v121                         // 00000004FD80: 1010F2FF 3B800000
	v_mul_f32_e32 v68, 0x3b800000, v131                        // 00000004FD88: 108906FF 3B800000
	v_dual_mul_f32 v62, 0x3b800000, v130 :: v_dual_mul_f32 v63, 0x3b800000, v129// 00000004FD90: C8C704FF 3E3F02FF 3B800000
	v_dual_mul_f32 v52, 0x3b800000, v120 :: v_dual_mul_f32 v67, 0x3b800000, v33// 00000004FD9C: C8C6F0FF 344242FF 3B800000
	v_dual_mul_f32 v10, 0x3b800000, v118 :: v_dual_mul_f32 v7, 0x3b800000, v125// 00000004FDA8: C8C6ECFF 0A06FAFF 3B800000
	v_mul_f32_e32 v56, 0x3b800000, v116                        // 00000004FDB4: 1070E8FF 3B800000
	v_dual_mul_f32 v59, 0x3b800000, v124 :: v_dual_mul_f32 v54, 0x3b800000, v25// 00000004FDBC: C8C6F8FF 3B3632FF 3B800000
	v_dual_mul_f32 v61, 0x3b800000, v122 :: v_dual_mul_f32 v58, 0x3b800000, v115// 00000004FDC8: C8C6F4FF 3D3AE6FF 3B800000
	v_dual_mul_f32 v53, 0x3b800000, v119 :: v_dual_mul_f32 v50, 0x3b800000, v113// 00000004FDD4: C8C6EEFF 3532E2FF 3B800000
	v_dual_mul_f32 v55, 0x3b800000, v117 :: v_dual_mul_f32 v12, 0x3b800000, v111// 00000004FDE0: C8C6EAFF 370CDEFF 3B800000
	v_dual_mul_f32 v11, 0x3b800000, v114 :: v_dual_mul_f32 v40, 0x3b800000, v17// 00000004FDEC: C8C6E4FF 0B2822FF 3B800000
	v_dual_mul_f32 v51, 0x3b800000, v112 :: v_dual_mul_f32 v44, 0x3b800000, v109// 00000004FDF8: C8C6E0FF 332CDAFF 3B800000
	v_dual_mul_f32 v43, 0x3b800000, v110 :: v_dual_mul_f32 v14, 0x3b800000, v107// 00000004FE04: C8C6DCFF 2B0ED6FF 3B800000
	v_dual_mul_f32 v45, 0x3b800000, v108 :: v_dual_mul_f32 v46, 0x3b800000, v106// 00000004FE10: C8C6D8FF 2D2ED4FF 3B800000
	v_dual_mul_f32 v47, 0x3b800000, v105 :: v_dual_mul_f32 v42, 0x3b800000, v103// 00000004FE1C: C8C6D2FF 2F2ACEFF 3B800000
	v_dual_mul_f32 v48, 0x3b800000, v9 :: v_dual_mul_f32 v15, 0x3b800000, v104// 00000004FE28: C8C612FF 300ED0FF 3B800000
	v_dual_mul_f32 v35, 0x3b800000, v102 :: v_dual_mul_f32 v36, 0x3b800000, v101// 00000004FE34: C8C6CCFF 2324CAFF 3B800000
	v_dual_mul_f32 v27, 0x3b800000, v100 :: v_dual_mul_f32 v38, 0x3b800000, v98// 00000004FE40: C8C6C8FF 1B26C4FF 3B800000
	v_dual_mul_f32 v37, 0x3b800000, v99 :: v_dual_mul_f32 v28, 0x3b800000, v97// 00000004FE4C: C8C6C6FF 251CC2FF 3B800000
	v_dual_mul_f32 v39, 0x3b800000, v49 :: v_dual_mul_f32 v32, 0x3b800000, v95// 00000004FE58: C8C662FF 2720BEFF 3B800000
	v_dual_mul_f32 v31, 0x3b800000, v96 :: v_dual_mul_f32 v34, 0x3b800000, v94// 00000004FE64: C8C6C0FF 1F22BCFF 3B800000
	v_dual_mul_f32 v29, 0x3b800000, v93 :: v_dual_mul_f32 v20, 0x3b800000, v92// 00000004FE70: C8C6BAFF 1D14B8FF 3B800000
	v_dual_mul_f32 v21, 0x3b800000, v91 :: v_dual_mul_f32 v22, 0x3b800000, v57// 00000004FE7C: C8C6B6FF 151672FF 3B800000
	v_dual_mul_f32 v30, 0x3b800000, v90 :: v_dual_mul_f32 v23, 0x3b800000, v141// 00000004FE88: C8C6B4FF 1E171AFF 3B800000
	v_dual_mul_f32 v24, 0x3b800000, v150 :: v_dual_mul_f32 v13, 0x3b800000, v65// 00000004FE94: C8C72CFF 180C82FF 3B800000
	v_mul_f32_e32 v26, 0x3b800000, v142                        // 00000004FEA0: 10351CFF 3B800000
	v_dual_mul_f32 v16, 0x3b800000, v191 :: v_dual_mul_f32 v19, 0x3b800000, v190// 00000004FEA8: C8C77EFF 10137CFF 3B800000
	v_mul_f32_e32 v18, 0x3b800000, v189                        // 00000004FEB4: 10257AFF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 00000004FEBC: BF89FC07
	s_barrier                                                  // 00000004FEC0: BFBD0000
	s_cbranch_scc0 5                                           // 00000004FEC4: BFA10005 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44dc>
	s_cmp_lg_u32 s13, s54                                      // 00000004FEC8: BF07360D
	s_cbranch_scc0 273                                         // 00000004FECC: BFA10111 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4914>
	s_cmp_lg_u32 s14, s54                                      // 00000004FED0: BF07360E
	s_cbranch_scc1 61709                                       // 00000004FED4: BFA2F10D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	s_branch 540                                               // 00000004FED8: BFA0021C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4d4c>
	v_mov_b32_e32 v82, v2                                      // 00000004FEDC: 7EA40302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FEE0: BF870091
	v_ashrrev_i32_e32 v83, 31, v82                             // 00000004FEE4: 34A6A49F
	.long 0xd73c0052                                           // 00000004FEE8: D73C0052
	v_cndmask_b32_e32 v1, 2, v82, vcc_lo                       // 00000004FEEC: 0202A482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FEF0: BF870091
	.long 0xd7006a52                                           // 00000004FEF4: D7006A52
	v_cndmask_b32_e32 v1, s16, v82, vcc_lo                     // 00000004FEF8: 0202A410
	v_add_co_ci_u32_e64 v83, null, s17, v83, vcc_lo            // 00000004FEFC: D5207C53 01AAA611
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FF04: BF870092
	.long 0xd7006a54                                           // 00000004FF08: D7006A54
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 00000004FF0C: 0202A4FF 00001000
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000004FF14: D5207C55 01AAA680
	.long 0xd7006a56                                           // 00000004FF1C: D7006A56
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004FF20: 0201FF52
	.long 0x00002000                                           // 00000004FF24: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004FF28: BF8700A1
	v_add_co_ci_u32_e64 v87, null, 0, v83, vcc_lo              // 00000004FF2C: D5207C57 01AAA680
	.long 0xd7006a58                                           // 00000004FF34: D7006A58
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 00000004FF38: 0202A4FF 00002000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000004FF40: D5207C59 01AAA680
	s_clause 0x7                                               // 00000004FF48: BF850007
	global_store_b32 v[82:83], v69, off                        // 00000004FF4C: DC6A0000 007C4552
	global_store_b32 v[82:83], v70, off offset:1024            // 00000004FF54: DC6A0400 007C4652
	global_store_b32 v[82:83], v71, off offset:2048            // 00000004FF5C: DC6A0800 007C4752
	global_store_b32 v[82:83], v72, off offset:3072            // 00000004FF64: DC6A0C00 007C4852
	global_store_b32 v[84:85], v73, off offset:1024            // 00000004FF6C: DC6A0400 007C4954
	global_store_b32 v[84:85], v151, off offset:2048           // 00000004FF74: DC6A0800 007C9754
	global_store_b32 v[84:85], v152, off offset:3072           // 00000004FF7C: DC6A0C00 007C9854
	global_store_b32 v[88:89], v68, off offset:1024            // 00000004FF84: DC6A0400 007C4458
	.long 0xd7006a54                                           // 00000004FF8C: D7006A54
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 00000004FF90: 0202A4FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004FF98: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000004FF9C: D5207C55 01AAA680
	.long 0xd7006a99                                           // 00000004FFA4: D7006A99
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004FFA8: 0201FF52
	.long 0x00004000                                           // 00000004FFAC: 00004000
	v_add_co_ci_u32_e64 v154, null, 0, v83, vcc_lo             // 00000004FFB0: D5207C9A 01AAA680
	.long 0xd7006a9b                                           // 00000004FFB8: D7006A9B
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 00000004FFBC: 0202A4FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004FFC4: BF870001
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000004FFC8: D5207C9C 01AAA680
	s_clause 0x7                                               // 00000004FFD0: BF850007
	global_store_b32 v[88:89], v62, off offset:2048            // 00000004FFD4: DC6A0800 007C3E58
	global_store_b32 v[88:89], v63, off offset:3072            // 00000004FFDC: DC6A0C00 007C3F58
	global_store_b32 v[84:85], v64, off offset:1024            // 00000004FFE4: DC6A0400 007C4054
	global_store_b32 v[84:85], v66, off offset:2048            // 00000004FFEC: DC6A0800 007C4254
	global_store_b32 v[84:85], v67, off offset:3072            // 00000004FFF4: DC6A0C00 007C4354
	global_store_b32 v[155:156], v59, off offset:1024          // 00000004FFFC: DC6A0400 007C3B9B
	global_store_b32 v[155:156], v60, off offset:2048          // 000000050004: DC6A0800 007C3C9B
	global_store_b32 v[155:156], v61, off offset:3072          // 00000005000C: DC6A0C00 007C3D9B
	.long 0xd7006a54                                           // 000000050014: D7006A54
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 000000050018: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000050020: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000050024: D5207C55 01AAA680
	.long 0xd7006a58                                           // 00000005002C: D7006A58
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000050030: 0201FF52
	.long 0x00006000                                           // 000000050034: 00006000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 000000050038: D5207C59 01AAA680
	.long 0xd7006a9b                                           // 000000050040: D7006A9B
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 000000050044: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005004C: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 000000050050: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 000000050058: D7006A9D
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 00000005005C: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 000000050064: D5207C9E 01AAA680
	.long 0xd7006a9f                                           // 00000005006C: D7006A9F
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000050070: 0201FF52
	.long 0x00008000                                           // 000000050074: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000050078: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v83, vcc_lo             // 00000005007C: D5207CA0 01AAA680
	s_clause 0x7                                               // 000000050084: BF850007
	global_store_b32 v[84:85], v52, off offset:1024            // 000000050088: DC6A0400 007C3454
	global_store_b32 v[84:85], v53, off offset:2048            // 000000050090: DC6A0800 007C3554
	global_store_b32 v[84:85], v54, off offset:3072            // 000000050098: DC6A0C00 007C3654
	global_store_b32 v[155:156], v55, off offset:1024          // 0000000500A0: DC6A0400 007C379B
	global_store_b32 v[155:156], v56, off offset:2048          // 0000000500A8: DC6A0800 007C389B
	global_store_b32 v[155:156], v58, off offset:3072          // 0000000500B0: DC6A0C00 007C3A9B
	global_store_b32 v[157:158], v50, off offset:1024          // 0000000500B8: DC6A0400 007C329D
	global_store_b32 v[157:158], v51, off offset:2048          // 0000000500C0: DC6A0800 007C339D
	.long 0xd7006a54                                           // 0000000500C8: D7006A54
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 0000000500CC: 0202A4FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000500D4: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000500D8: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 0000000500E0: D7006A9B
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 0000000500E4: 0202A4FF 00009000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 0000000500EC: D5207C9C 01AAA680
	.long 0xd7006aa1                                           // 0000000500F4: D7006AA1
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000500F8: 0201FF52
	.long 0x0000a000                                           // 0000000500FC: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000050100: BF8700A1
	v_add_co_ci_u32_e64 v162, null, 0, v83, vcc_lo             // 000000050104: D5207CA2 01AAA680
	.long 0xd7006aa3                                           // 00000005010C: D7006AA3
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 000000050110: 0202A4FF 0000A000
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 000000050118: D5207CA4 01AAA680
	s_clause 0x7                                               // 000000050120: BF850007
	global_store_b32 v[157:158], v40, off offset:3072          // 000000050124: DC6A0C00 007C289D
	global_store_b32 v[84:85], v43, off offset:1024            // 00000005012C: DC6A0400 007C2B54
	global_store_b32 v[84:85], v44, off offset:2048            // 000000050134: DC6A0800 007C2C54
	global_store_b32 v[84:85], v45, off offset:3072            // 00000005013C: DC6A0C00 007C2D54
	global_store_b32 v[155:156], v46, off offset:1024          // 000000050144: DC6A0400 007C2E9B
	global_store_b32 v[155:156], v47, off offset:2048          // 00000005014C: DC6A0800 007C2F9B
	global_store_b32 v[155:156], v48, off offset:3072          // 000000050154: DC6A0C00 007C309B
	global_store_b32 v[163:164], v42, off offset:1024          // 00000005015C: DC6A0400 007C2AA3
	.long 0xd7006a54                                           // 000000050164: D7006A54
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 000000050168: 0202A4FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000050170: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000050174: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 00000005017C: D7006A9B
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000050180: 0201FF52
	.long 0x0000c000                                           // 000000050184: 0000C000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 000000050188: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 000000050190: D7006A9D
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 000000050194: 0202A4FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005019C: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 0000000501A0: D5207C9E 01AAA680
	s_clause 0x7                                               // 0000000501A8: BF850007
	global_store_b32 v[163:164], v35, off offset:2048          // 0000000501AC: DC6A0800 007C23A3
	global_store_b32 v[163:164], v36, off offset:3072          // 0000000501B4: DC6A0C00 007C24A3
	global_store_b32 v[84:85], v37, off offset:1024            // 0000000501BC: DC6A0400 007C2554
	global_store_b32 v[84:85], v38, off offset:2048            // 0000000501C4: DC6A0800 007C2654
	global_store_b32 v[84:85], v39, off offset:3072            // 0000000501CC: DC6A0C00 007C2754
	global_store_b32 v[157:158], v31, off offset:1024          // 0000000501D4: DC6A0400 007C1F9D
	global_store_b32 v[157:158], v32, off offset:2048          // 0000000501DC: DC6A0800 007C209D
	global_store_b32 v[157:158], v34, off offset:3072          // 0000000501E4: DC6A0C00 007C229D
	.long 0xd7006a54                                           // 0000000501EC: D7006A54
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 0000000501F0: 0202A4FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000501F8: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000501FC: D5207C55 01AAA680
	.long 0xd7006a9d                                           // 000000050204: D7006A9D
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000050208: 0201FF52
	.long 0x0000e000                                           // 00000005020C: 0000E000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 000000050210: D5207C9E 01AAA680
	.long 0xd7006aa3                                           // 000000050218: D7006AA3
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 00000005021C: 0202A4FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000050224: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 000000050228: D5207CA4 01AAA680
	.long 0xd7006a52                                           // 000000050230: D7006A52
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 000000050234: 0202A4FF 0000F000
	s_clause 0x7                                               // 00000005023C: BF850007
	global_store_b32 v[159:160], v11, off offset:-4096         // 000000050240: DC6A1000 007C0B9F
	global_store_b32 v[159:160], v12, off                      // 000000050248: DC6A0000 007C0C9F
	global_store_b32 v[161:162], v14, off offset:-4096         // 000000050250: DC6A1000 007C0EA1
	global_store_b32 v[161:162], v15, off                      // 000000050258: DC6A0000 007C0FA1
	global_store_b32 v[155:156], v27, off offset:-4096         // 000000050260: DC6A1000 007C1B9B
	global_store_b32 v[155:156], v28, off                      // 000000050268: DC6A0000 007C1C9B
	global_store_b32 v[157:158], v29, off offset:-4096         // 000000050270: DC6A1000 007C1D9D
	global_store_b32 v[157:158], v30, off                      // 000000050278: DC6A0000 007C1E9D
	v_add_co_ci_u32_e64 v83, null, 0, v83, vcc_lo              // 000000050280: D5207C53 01AAA680
	s_clause 0xf                                               // 000000050288: BF85000F
	global_store_b32 v[84:85], v20, off offset:1024            // 00000005028C: DC6A0400 007C1454
	global_store_b32 v[84:85], v21, off offset:2048            // 000000050294: DC6A0800 007C1554
	global_store_b32 v[84:85], v22, off offset:3072            // 00000005029C: DC6A0C00 007C1654
	global_store_b32 v[163:164], v23, off offset:1024          // 0000000502A4: DC6A0400 007C17A3
	global_store_b32 v[163:164], v24, off offset:2048          // 0000000502AC: DC6A0800 007C18A3
	global_store_b32 v[163:164], v26, off offset:3072          // 0000000502B4: DC6A0C00 007C1AA3
	global_store_b32 v[82:83], v16, off                        // 0000000502BC: DC6A0000 007C1052
	global_store_b32 v[82:83], v18, off offset:1024            // 0000000502C4: DC6A0400 007C1252
	global_store_b32 v[82:83], v19, off offset:2048            // 0000000502CC: DC6A0800 007C1352
	global_store_b32 v[86:87], v4, off offset:-4096            // 0000000502D4: DC6A1000 007C0456
	global_store_b32 v[86:87], v5, off                         // 0000000502DC: DC6A0000 007C0556
	global_store_b32 v[153:154], v6, off offset:-4096          // 0000000502E4: DC6A1000 007C0699
	global_store_b32 v[153:154], v7, off                       // 0000000502EC: DC6A0000 007C0799
	global_store_b32 v[88:89], v8, off offset:-4096            // 0000000502F4: DC6A1000 007C0858
	global_store_b32 v[88:89], v10, off                        // 0000000502FC: DC6A0000 007C0A58
	global_store_b32 v[82:83], v13, off offset:3072            // 000000050304: DC6A0C00 007C0D52
	s_cmp_lg_u32 s13, s54                                      // 00000005030C: BF07360D
	s_cbranch_scc1 65263                                       // 000000050310: BFA2FEEF <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44d0>
	v_mov_b32_e32 v82, v2                                      // 000000050314: 7EA40302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050318: BF870091
	v_ashrrev_i32_e32 v83, 31, v82                             // 00000005031C: 34A6A49F
	.long 0xd73c0052                                           // 000000050320: D73C0052
	v_cndmask_b32_e32 v1, 2, v82, vcc_lo                       // 000000050324: 0202A482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050328: BF870091
	.long 0xd7006a52                                           // 00000005032C: D7006A52
	v_cndmask_b32_e32 v1, s18, v82, vcc_lo                     // 000000050330: 0202A412
	v_add_co_ci_u32_e64 v83, null, s19, v83, vcc_lo            // 000000050334: D5207C53 01AAA613
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005033C: BF870092
	.long 0xd7006a54                                           // 000000050340: D7006A54
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 000000050344: 0202A4FF 00001000
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000005034C: D5207C55 01AAA680
	.long 0xd7006a56                                           // 000000050354: D7006A56
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000050358: 0201FF52
	.long 0x00002000                                           // 00000005035C: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000050360: BF8700A1
	v_add_co_ci_u32_e64 v87, null, 0, v83, vcc_lo              // 000000050364: D5207C57 01AAA680
	.long 0xd7006a58                                           // 00000005036C: D7006A58
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 000000050370: 0202A4FF 00002000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 000000050378: D5207C59 01AAA680
	s_clause 0x7                                               // 000000050380: BF850007
	global_store_b32 v[82:83], v69, off                        // 000000050384: DC6A0000 007C4552
	global_store_b32 v[82:83], v70, off offset:1024            // 00000005038C: DC6A0400 007C4652
	global_store_b32 v[82:83], v71, off offset:2048            // 000000050394: DC6A0800 007C4752
	global_store_b32 v[82:83], v72, off offset:3072            // 00000005039C: DC6A0C00 007C4852
	global_store_b32 v[84:85], v73, off offset:1024            // 0000000503A4: DC6A0400 007C4954
	global_store_b32 v[84:85], v151, off offset:2048           // 0000000503AC: DC6A0800 007C9754
	global_store_b32 v[84:85], v152, off offset:3072           // 0000000503B4: DC6A0C00 007C9854
	global_store_b32 v[88:89], v68, off offset:1024            // 0000000503BC: DC6A0400 007C4458
	.long 0xd7006a54                                           // 0000000503C4: D7006A54
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 0000000503C8: 0202A4FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000503D0: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000503D4: D5207C55 01AAA680
	.long 0xd7006a99                                           // 0000000503DC: D7006A99
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000503E0: 0201FF52
	.long 0x00004000                                           // 0000000503E4: 00004000
	v_add_co_ci_u32_e64 v154, null, 0, v83, vcc_lo             // 0000000503E8: D5207C9A 01AAA680
	.long 0xd7006a9b                                           // 0000000503F0: D7006A9B
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 0000000503F4: 0202A4FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000503FC: BF870001
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 000000050400: D5207C9C 01AAA680
	s_clause 0x7                                               // 000000050408: BF850007
	global_store_b32 v[88:89], v62, off offset:2048            // 00000005040C: DC6A0800 007C3E58
	global_store_b32 v[88:89], v63, off offset:3072            // 000000050414: DC6A0C00 007C3F58
	global_store_b32 v[84:85], v64, off offset:1024            // 00000005041C: DC6A0400 007C4054
	global_store_b32 v[84:85], v66, off offset:2048            // 000000050424: DC6A0800 007C4254
	global_store_b32 v[84:85], v67, off offset:3072            // 00000005042C: DC6A0C00 007C4354
	global_store_b32 v[155:156], v59, off offset:1024          // 000000050434: DC6A0400 007C3B9B
	global_store_b32 v[155:156], v60, off offset:2048          // 00000005043C: DC6A0800 007C3C9B
	global_store_b32 v[155:156], v61, off offset:3072          // 000000050444: DC6A0C00 007C3D9B
	.long 0xd7006a54                                           // 00000005044C: D7006A54
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 000000050450: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000050458: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000005045C: D5207C55 01AAA680
	.long 0xd7006a58                                           // 000000050464: D7006A58
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000050468: 0201FF52
	.long 0x00006000                                           // 00000005046C: 00006000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 000000050470: D5207C59 01AAA680
	.long 0xd7006a9b                                           // 000000050478: D7006A9B
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 00000005047C: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000050484: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 000000050488: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 000000050490: D7006A9D
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 000000050494: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000005049C: D5207C9E 01AAA680
	.long 0xd7006a9f                                           // 0000000504A4: D7006A9F
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000504A8: 0201FF52
	.long 0x00008000                                           // 0000000504AC: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000504B0: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v83, vcc_lo             // 0000000504B4: D5207CA0 01AAA680
	s_clause 0x7                                               // 0000000504BC: BF850007
	global_store_b32 v[84:85], v52, off offset:1024            // 0000000504C0: DC6A0400 007C3454
	global_store_b32 v[84:85], v53, off offset:2048            // 0000000504C8: DC6A0800 007C3554
	global_store_b32 v[84:85], v54, off offset:3072            // 0000000504D0: DC6A0C00 007C3654
	global_store_b32 v[155:156], v55, off offset:1024          // 0000000504D8: DC6A0400 007C379B
	global_store_b32 v[155:156], v56, off offset:2048          // 0000000504E0: DC6A0800 007C389B
	global_store_b32 v[155:156], v58, off offset:3072          // 0000000504E8: DC6A0C00 007C3A9B
	global_store_b32 v[157:158], v50, off offset:1024          // 0000000504F0: DC6A0400 007C329D
	global_store_b32 v[157:158], v51, off offset:2048          // 0000000504F8: DC6A0800 007C339D
	.long 0xd7006a54                                           // 000000050500: D7006A54
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 000000050504: 0202A4FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005050C: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000050510: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 000000050518: D7006A9B
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 00000005051C: 0202A4FF 00009000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 000000050524: D5207C9C 01AAA680
	.long 0xd7006aa1                                           // 00000005052C: D7006AA1
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000050530: 0201FF52
	.long 0x0000a000                                           // 000000050534: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000050538: BF8700A1
	v_add_co_ci_u32_e64 v162, null, 0, v83, vcc_lo             // 00000005053C: D5207CA2 01AAA680
	.long 0xd7006aa3                                           // 000000050544: D7006AA3
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 000000050548: 0202A4FF 0000A000
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 000000050550: D5207CA4 01AAA680
	s_clause 0x7                                               // 000000050558: BF850007
	global_store_b32 v[157:158], v40, off offset:3072          // 00000005055C: DC6A0C00 007C289D
	global_store_b32 v[84:85], v43, off offset:1024            // 000000050564: DC6A0400 007C2B54
	global_store_b32 v[84:85], v44, off offset:2048            // 00000005056C: DC6A0800 007C2C54
	global_store_b32 v[84:85], v45, off offset:3072            // 000000050574: DC6A0C00 007C2D54
	global_store_b32 v[155:156], v46, off offset:1024          // 00000005057C: DC6A0400 007C2E9B
	global_store_b32 v[155:156], v47, off offset:2048          // 000000050584: DC6A0800 007C2F9B
	global_store_b32 v[155:156], v48, off offset:3072          // 00000005058C: DC6A0C00 007C309B
	global_store_b32 v[163:164], v42, off offset:1024          // 000000050594: DC6A0400 007C2AA3
	.long 0xd7006a54                                           // 00000005059C: D7006A54
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 0000000505A0: 0202A4FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000505A8: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000505AC: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 0000000505B4: D7006A9B
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000505B8: 0201FF52
	.long 0x0000c000                                           // 0000000505BC: 0000C000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 0000000505C0: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 0000000505C8: D7006A9D
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 0000000505CC: 0202A4FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000505D4: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 0000000505D8: D5207C9E 01AAA680
	s_clause 0x7                                               // 0000000505E0: BF850007
	global_store_b32 v[163:164], v35, off offset:2048          // 0000000505E4: DC6A0800 007C23A3
	global_store_b32 v[163:164], v36, off offset:3072          // 0000000505EC: DC6A0C00 007C24A3
	global_store_b32 v[84:85], v37, off offset:1024            // 0000000505F4: DC6A0400 007C2554
	global_store_b32 v[84:85], v38, off offset:2048            // 0000000505FC: DC6A0800 007C2654
	global_store_b32 v[84:85], v39, off offset:3072            // 000000050604: DC6A0C00 007C2754
	global_store_b32 v[157:158], v31, off offset:1024          // 00000005060C: DC6A0400 007C1F9D
	global_store_b32 v[157:158], v32, off offset:2048          // 000000050614: DC6A0800 007C209D
	global_store_b32 v[157:158], v34, off offset:3072          // 00000005061C: DC6A0C00 007C229D
	.long 0xd7006a54                                           // 000000050624: D7006A54
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 000000050628: 0202A4FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000050630: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000050634: D5207C55 01AAA680
	.long 0xd7006a9d                                           // 00000005063C: D7006A9D
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000050640: 0201FF52
	.long 0x0000e000                                           // 000000050644: 0000E000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 000000050648: D5207C9E 01AAA680
	.long 0xd7006aa3                                           // 000000050650: D7006AA3
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 000000050654: 0202A4FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005065C: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 000000050660: D5207CA4 01AAA680
	.long 0xd7006a52                                           // 000000050668: D7006A52
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 00000005066C: 0202A4FF 0000F000
	s_clause 0x7                                               // 000000050674: BF850007
	global_store_b32 v[159:160], v11, off offset:-4096         // 000000050678: DC6A1000 007C0B9F
	global_store_b32 v[159:160], v12, off                      // 000000050680: DC6A0000 007C0C9F
	global_store_b32 v[161:162], v14, off offset:-4096         // 000000050688: DC6A1000 007C0EA1
	global_store_b32 v[161:162], v15, off                      // 000000050690: DC6A0000 007C0FA1
	global_store_b32 v[155:156], v27, off offset:-4096         // 000000050698: DC6A1000 007C1B9B
	global_store_b32 v[155:156], v28, off                      // 0000000506A0: DC6A0000 007C1C9B
	global_store_b32 v[157:158], v29, off offset:-4096         // 0000000506A8: DC6A1000 007C1D9D
	global_store_b32 v[157:158], v30, off                      // 0000000506B0: DC6A0000 007C1E9D
	v_add_co_ci_u32_e64 v83, null, 0, v83, vcc_lo              // 0000000506B8: D5207C53 01AAA680
	s_clause 0xf                                               // 0000000506C0: BF85000F
	global_store_b32 v[84:85], v20, off offset:1024            // 0000000506C4: DC6A0400 007C1454
	global_store_b32 v[84:85], v21, off offset:2048            // 0000000506CC: DC6A0800 007C1554
	global_store_b32 v[84:85], v22, off offset:3072            // 0000000506D4: DC6A0C00 007C1654
	global_store_b32 v[163:164], v23, off offset:1024          // 0000000506DC: DC6A0400 007C17A3
	global_store_b32 v[163:164], v24, off offset:2048          // 0000000506E4: DC6A0800 007C18A3
	global_store_b32 v[163:164], v26, off offset:3072          // 0000000506EC: DC6A0C00 007C1AA3
	global_store_b32 v[82:83], v16, off                        // 0000000506F4: DC6A0000 007C1052
	global_store_b32 v[82:83], v18, off offset:1024            // 0000000506FC: DC6A0400 007C1252
	global_store_b32 v[82:83], v19, off offset:2048            // 000000050704: DC6A0800 007C1352
	global_store_b32 v[86:87], v4, off offset:-4096            // 00000005070C: DC6A1000 007C0456
	global_store_b32 v[86:87], v5, off                         // 000000050714: DC6A0000 007C0556
	global_store_b32 v[153:154], v6, off offset:-4096          // 00000005071C: DC6A1000 007C0699
	global_store_b32 v[153:154], v7, off                       // 000000050724: DC6A0000 007C0799
	global_store_b32 v[88:89], v8, off offset:-4096            // 00000005072C: DC6A1000 007C0858
	global_store_b32 v[88:89], v10, off                        // 000000050734: DC6A0000 007C0A58
	global_store_b32 v[82:83], v13, off offset:3072            // 00000005073C: DC6A0C00 007C0D52
	s_cmp_lg_u32 s14, s54                                      // 000000050744: BF07360E
	s_cbranch_scc1 61168                                       // 000000050748: BFA2EEF0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000005074C: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050750: BF870091
	.long 0xd73c0002                                           // 000000050754: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000050758: 02020482
	.long 0xd7006a02                                           // 00000005075C: D7006A02
	v_cndmask_b32_e32 v1, s47, v2, vcc_lo                      // 000000050760: 0202042F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000050764: BF870111
	v_add_co_ci_u32_e64 v3, null, s7, v3, vcc_lo               // 000000050768: D5207C03 01AA0607
	.long 0xd7006a52                                           // 000000050770: D7006A52
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 000000050774: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005077C: BF8700A1
	v_add_co_ci_u32_e64 v83, null, 0, v3, vcc_lo               // 000000050780: D5207C53 01AA0680
	.long 0xd7006a54                                           // 000000050788: D7006A54
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000005078C: 0201FF02
	.long 0x00002000                                           // 000000050790: 00002000
	v_add_co_ci_u32_e64 v85, null, 0, v3, vcc_lo               // 000000050794: D5207C55 01AA0680
	.long 0xd7006a56                                           // 00000005079C: D7006A56
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 0000000507A0: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000507A8: BF870001
	v_add_co_ci_u32_e64 v87, null, 0, v3, vcc_lo               // 0000000507AC: D5207C57 01AA0680
	s_clause 0x7                                               // 0000000507B4: BF850007
	global_store_b32 v[2:3], v69, off                          // 0000000507B8: DC6A0000 007C4502
	global_store_b32 v[2:3], v70, off offset:1024              // 0000000507C0: DC6A0400 007C4602
	global_store_b32 v[2:3], v71, off offset:2048              // 0000000507C8: DC6A0800 007C4702
	global_store_b32 v[2:3], v72, off offset:3072              // 0000000507D0: DC6A0C00 007C4802
	global_store_b32 v[82:83], v73, off offset:1024            // 0000000507D8: DC6A0400 007C4952
	global_store_b32 v[82:83], v151, off offset:2048           // 0000000507E0: DC6A0800 007C9752
	global_store_b32 v[82:83], v152, off offset:3072           // 0000000507E8: DC6A0C00 007C9852
	global_store_b32 v[86:87], v68, off offset:1024            // 0000000507F0: DC6A0400 007C4456
	.long 0xd7006a44                                           // 0000000507F8: D7006A44
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 0000000507FC: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000050804: BF8700A1
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 000000050808: D5207C45 01AA0680
	.long 0xd7006a46                                           // 000000050810: D7006A46
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000050814: 0201FF02
	.long 0x00004000                                           // 000000050818: 00004000
	v_add_co_ci_u32_e64 v71, null, 0, v3, vcc_lo               // 00000005081C: D5207C47 01AA0680
	.long 0xd7006a48                                           // 000000050824: D7006A48
	v_cndmask_b32_e32 v1, 0x4000, v2, vcc_lo                   // 000000050828: 020204FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000050830: BF870001
	v_add_co_ci_u32_e64 v73, null, 0, v3, vcc_lo               // 000000050834: D5207C49 01AA0680
	s_clause 0x7                                               // 00000005083C: BF850007
	global_store_b32 v[86:87], v62, off offset:2048            // 000000050840: DC6A0800 007C3E56
	global_store_b32 v[86:87], v63, off offset:3072            // 000000050848: DC6A0C00 007C3F56
	global_store_b32 v[68:69], v64, off offset:1024            // 000000050850: DC6A0400 007C4044
	global_store_b32 v[68:69], v66, off offset:2048            // 000000050858: DC6A0800 007C4244
	global_store_b32 v[68:69], v67, off offset:3072            // 000000050860: DC6A0C00 007C4344
	global_store_b32 v[72:73], v59, off offset:1024            // 000000050868: DC6A0400 007C3B48
	global_store_b32 v[72:73], v60, off offset:2048            // 000000050870: DC6A0800 007C3C48
	global_store_b32 v[72:73], v61, off offset:3072            // 000000050878: DC6A0C00 007C3D48
	.long 0xd7006a3b                                           // 000000050880: D7006A3B
	v_cndmask_b32_e32 v1, 0x5000, v2, vcc_lo                   // 000000050884: 020204FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005088C: BF8700A1
	v_add_co_ci_u32_e64 v60, null, 0, v3, vcc_lo               // 000000050890: D5207C3C 01AA0680
	.long 0xd7006a3d                                           // 000000050898: D7006A3D
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000005089C: 0201FF02
	.long 0x00006000                                           // 0000000508A0: 00006000
	v_add_co_ci_u32_e64 v62, null, 0, v3, vcc_lo               // 0000000508A4: D5207C3E 01AA0680
	.long 0xd7006a3f                                           // 0000000508AC: D7006A3F
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 0000000508B0: 020204FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000508B8: BF8700A1
	v_add_co_ci_u32_e64 v64, null, 0, v3, vcc_lo               // 0000000508BC: D5207C40 01AA0680
	.long 0xd7006a42                                           // 0000000508C4: D7006A42
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 0000000508C8: 020204FF 00007000
	v_add_co_ci_u32_e64 v67, null, 0, v3, vcc_lo               // 0000000508D0: D5207C43 01AA0680
	.long 0xd7006a44                                           // 0000000508D8: D7006A44
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 0000000508DC: 0201FF02
	.long 0x00008000                                           // 0000000508E0: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000508E4: BF870001
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 0000000508E8: D5207C45 01AA0680
	s_clause 0x7                                               // 0000000508F0: BF850007
	global_store_b32 v[59:60], v52, off offset:1024            // 0000000508F4: DC6A0400 007C343B
	global_store_b32 v[59:60], v53, off offset:2048            // 0000000508FC: DC6A0800 007C353B
	global_store_b32 v[59:60], v54, off offset:3072            // 000000050904: DC6A0C00 007C363B
	global_store_b32 v[63:64], v55, off offset:1024            // 00000005090C: DC6A0400 007C373F
	global_store_b32 v[63:64], v56, off offset:2048            // 000000050914: DC6A0800 007C383F
	global_store_b32 v[63:64], v58, off offset:3072            // 00000005091C: DC6A0C00 007C3A3F
	global_store_b32 v[66:67], v50, off offset:1024            // 000000050924: DC6A0400 007C3242
	global_store_b32 v[66:67], v51, off offset:2048            // 00000005092C: DC6A0800 007C3342
	.long 0xd7006a32                                           // 000000050934: D7006A32
	v_cndmask_b32_e32 v1, 0x8000, v2, vcc_lo                   // 000000050938: 020204FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000050940: BF8700A1
	v_add_co_ci_u32_e64 v51, null, 0, v3, vcc_lo               // 000000050944: D5207C33 01AA0680
	.long 0xd7006a34                                           // 00000005094C: D7006A34
	v_cndmask_b32_e32 v1, 0x9000, v2, vcc_lo                   // 000000050950: 020204FF 00009000
	v_add_co_ci_u32_e64 v53, null, 0, v3, vcc_lo               // 000000050958: D5207C35 01AA0680
	.long 0xd7006a36                                           // 000000050960: D7006A36
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000050964: 0201FF02
	.long 0x0000a000                                           // 000000050968: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005096C: BF8700A1
	v_add_co_ci_u32_e64 v55, null, 0, v3, vcc_lo               // 000000050970: D5207C37 01AA0680
	.long 0xd7006a3a                                           // 000000050978: D7006A3A
	v_cndmask_b32_e32 v1, 0xa000, v2, vcc_lo                   // 00000005097C: 020204FF 0000A000
	v_add_co_ci_u32_e64 v59, null, 0, v3, vcc_lo               // 000000050984: D5207C3B 01AA0680
	s_clause 0x7                                               // 00000005098C: BF850007
	global_store_b32 v[66:67], v40, off offset:3072            // 000000050990: DC6A0C00 007C2842
	global_store_b32 v[50:51], v43, off offset:1024            // 000000050998: DC6A0400 007C2B32
	global_store_b32 v[50:51], v44, off offset:2048            // 0000000509A0: DC6A0800 007C2C32
	global_store_b32 v[50:51], v45, off offset:3072            // 0000000509A8: DC6A0C00 007C2D32
	global_store_b32 v[52:53], v46, off offset:1024            // 0000000509B0: DC6A0400 007C2E34
	global_store_b32 v[52:53], v47, off offset:2048            // 0000000509B8: DC6A0800 007C2F34
	global_store_b32 v[52:53], v48, off offset:3072            // 0000000509C0: DC6A0C00 007C3034
	global_store_b32 v[58:59], v42, off offset:1024            // 0000000509C8: DC6A0400 007C2A3A
	.long 0xd7006a2a                                           // 0000000509D0: D7006A2A
	v_cndmask_b32_e32 v1, 0xb000, v2, vcc_lo                   // 0000000509D4: 020204FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000509DC: BF8700A1
	v_add_co_ci_u32_e64 v43, null, 0, v3, vcc_lo               // 0000000509E0: D5207C2B 01AA0680
	.long 0xd7006a2c                                           // 0000000509E8: D7006A2C
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 0000000509EC: 0201FF02
	.long 0x0000c000                                           // 0000000509F0: 0000C000
	v_add_co_ci_u32_e64 v45, null, 0, v3, vcc_lo               // 0000000509F4: D5207C2D 01AA0680
	.long 0xd7006a2e                                           // 0000000509FC: D7006A2E
	v_cndmask_b32_e32 v1, 0xc000, v2, vcc_lo                   // 000000050A00: 020204FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000050A08: BF870001
	v_add_co_ci_u32_e64 v47, null, 0, v3, vcc_lo               // 000000050A0C: D5207C2F 01AA0680
	s_clause 0x7                                               // 000000050A14: BF850007
	global_store_b32 v[58:59], v35, off offset:2048            // 000000050A18: DC6A0800 007C233A
	global_store_b32 v[58:59], v36, off offset:3072            // 000000050A20: DC6A0C00 007C243A
	global_store_b32 v[42:43], v37, off offset:1024            // 000000050A28: DC6A0400 007C252A
	global_store_b32 v[42:43], v38, off offset:2048            // 000000050A30: DC6A0800 007C262A
	global_store_b32 v[42:43], v39, off offset:3072            // 000000050A38: DC6A0C00 007C272A
	global_store_b32 v[46:47], v31, off offset:1024            // 000000050A40: DC6A0400 007C1F2E
	global_store_b32 v[46:47], v32, off offset:2048            // 000000050A48: DC6A0800 007C202E
	global_store_b32 v[46:47], v34, off offset:3072            // 000000050A50: DC6A0C00 007C222E
	.long 0xd7006a1f                                           // 000000050A58: D7006A1F
	v_cndmask_b32_e32 v1, 0xd000, v2, vcc_lo                   // 000000050A5C: 020204FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000050A64: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v3, vcc_lo               // 000000050A68: D5207C20 01AA0680
	.long 0xd7006a22                                           // 000000050A70: D7006A22
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000050A74: 0201FF02
	.long 0x0000e000                                           // 000000050A78: 0000E000
	v_add_co_ci_u32_e64 v35, null, 0, v3, vcc_lo               // 000000050A7C: D5207C23 01AA0680
	.long 0xd7006a24                                           // 000000050A84: D7006A24
	v_cndmask_b32_e32 v1, 0xe000, v2, vcc_lo                   // 000000050A88: 020204FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000050A90: BF870001
	v_add_co_ci_u32_e64 v37, null, 0, v3, vcc_lo               // 000000050A94: D5207C25 01AA0680
	.long 0xd7006a02                                           // 000000050A9C: D7006A02
	v_cndmask_b32_e32 v1, 0xf000, v2, vcc_lo                   // 000000050AA0: 020204FF 0000F000
	s_clause 0x7                                               // 000000050AA8: BF850007
	global_store_b32 v[68:69], v11, off offset:-4096           // 000000050AAC: DC6A1000 007C0B44
	global_store_b32 v[68:69], v12, off                        // 000000050AB4: DC6A0000 007C0C44
	global_store_b32 v[54:55], v14, off offset:-4096           // 000000050ABC: DC6A1000 007C0E36
	global_store_b32 v[54:55], v15, off                        // 000000050AC4: DC6A0000 007C0F36
	global_store_b32 v[44:45], v27, off offset:-4096           // 000000050ACC: DC6A1000 007C1B2C
	global_store_b32 v[44:45], v28, off                        // 000000050AD4: DC6A0000 007C1C2C
	global_store_b32 v[34:35], v29, off offset:-4096           // 000000050ADC: DC6A1000 007C1D22
	global_store_b32 v[34:35], v30, off                        // 000000050AE4: DC6A0000 007C1E22
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000050AEC: D5207C03 01AA0680
	s_clause 0xf                                               // 000000050AF4: BF85000F
	global_store_b32 v[31:32], v20, off offset:1024            // 000000050AF8: DC6A0400 007C141F
	global_store_b32 v[31:32], v21, off offset:2048            // 000000050B00: DC6A0800 007C151F
	global_store_b32 v[31:32], v22, off offset:3072            // 000000050B08: DC6A0C00 007C161F
	global_store_b32 v[36:37], v23, off offset:1024            // 000000050B10: DC6A0400 007C1724
	global_store_b32 v[36:37], v24, off offset:2048            // 000000050B18: DC6A0800 007C1824
	global_store_b32 v[36:37], v26, off offset:3072            // 000000050B20: DC6A0C00 007C1A24
	global_store_b32 v[2:3], v16, off                          // 000000050B28: DC6A0000 007C1002
	global_store_b32 v[2:3], v18, off offset:1024              // 000000050B30: DC6A0400 007C1202
	global_store_b32 v[2:3], v19, off offset:2048              // 000000050B38: DC6A0800 007C1302
	global_store_b32 v[84:85], v4, off offset:-4096            // 000000050B40: DC6A1000 007C0454
	global_store_b32 v[84:85], v5, off                         // 000000050B48: DC6A0000 007C0554
	global_store_b32 v[70:71], v6, off offset:-4096            // 000000050B50: DC6A1000 007C0646
	global_store_b32 v[70:71], v7, off                         // 000000050B58: DC6A0000 007C0746
	global_store_b32 v[61:62], v8, off offset:-4096            // 000000050B60: DC6A1000 007C083D
	global_store_b32 v[61:62], v10, off                        // 000000050B68: DC6A0000 007C0A3D
	global_store_b32 v[2:3], v13, off offset:3072              // 000000050B70: DC6A0C00 007C0D02
	s_branch 60900                                             // 000000050B78: BFA0EDE4 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	v_mov_b32_e32 v54, v41                                     // 000000050B7C: 7E6C0329
	v_mov_b32_e32 v53, v33                                     // 000000050B80: 7E6A0321
	v_mov_b32_e32 v52, v25                                     // 000000050B84: 7E680319
	v_mov_b32_e32 v51, v17                                     // 000000050B88: 7E660311
	v_mov_b32_e32 v50, v9                                      // 000000050B8C: 7E640309
	v_mov_b32_e32 v58, v49                                     // 000000050B90: 7E740331
	v_mov_b32_e32 v152, v57                                    // 000000050B94: 7F300339
	v_mov_b32_e32 v151, v65                                    // 000000050B98: 7F2E0341
	s_mov_b32 s7, 0                                            // 000000050B9C: BE870080
	s_branch 1                                                 // 000000050BA0: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x51a8>
	s_mov_b64 s[6:7], 0                                        // 000000050BA4: BE860180
	v_dual_mul_f32 v3, 0x3b800000, v139 :: v_dual_mul_f32 v4, 0x3b800000, v138// 000000050BA8: C8C716FF 030514FF 3B800000
	v_dual_mul_f32 v5, 0x3b800000, v137 :: v_dual_mul_f32 v6, 0x3b800000, v136// 000000050BB4: C8C712FF 050710FF 3B800000
	.long 0xd7006a01                                           // 000000050BC0: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000050BC4: 0201FFBB
	.long 0x00002000                                           // 000000050BC8: 00002000
	v_dual_mul_f32 v7, 0x3b800000, v135 :: v_dual_mul_f32 v8, 0x3b800000, v134// 000000050BCC: C8C70EFF 07090CFF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 000000050BD8: D5207C02 01AB7880
	v_dual_mul_f32 v9, 0x3b800000, v133 :: v_dual_mul_f32 v10, 0x3b800000, v54// 000000050BE0: C8C70AFF 090A6CFF 3B800000
	s_clause 0x7                                               // 000000050BEC: BF850007
	global_store_b32 v[187:188], v3, off                       // 000000050BF0: DC6A0000 007C03BB
	global_store_b32 v[187:188], v4, off offset:1024           // 000000050BF8: DC6A0400 007C04BB
	global_store_b32 v[187:188], v5, off offset:2048           // 000000050C00: DC6A0800 007C05BB
	global_store_b32 v[187:188], v6, off offset:3072           // 000000050C08: DC6A0C00 007C06BB
	global_store_b32 v[1:2], v7, off offset:-4096              // 000000050C10: DC6A1000 007C0701
	global_store_b32 v[1:2], v8, off offset:-3072              // 000000050C18: DC6A1400 007C0801
	global_store_b32 v[1:2], v9, off offset:-2048              // 000000050C20: DC6A1800 007C0901
	global_store_b32 v[1:2], v10, off offset:-1024             // 000000050C28: DC6A1C00 007C0A01
	v_dual_mul_f32 v5, 0x3b800000, v132 :: v_dual_mul_f32 v6, 0x3b800000, v131// 000000050C30: C8C708FF 050706FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v130 :: v_dual_mul_f32 v8, 0x3b800000, v129// 000000050C3C: C8C704FF 070902FF 3B800000
	.long 0xd7006a03                                           // 000000050C48: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000050C4C: 0201FFBB
	.long 0x00004000                                           // 000000050C50: 00004000
	v_dual_mul_f32 v9, 0x3b800000, v128 :: v_dual_mul_f32 v10, 0x3b800000, v127// 000000050C54: C8C700FF 090AFEFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000050C60: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v126 :: v_dual_mul_f32 v12, 0x3b800000, v53// 000000050C68: C8C6FCFF 0B0C6AFF 3B800000
	s_clause 0x7                                               // 000000050C74: BF850007
	global_store_b32 v[1:2], v5, off                           // 000000050C78: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 000000050C80: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 000000050C88: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 000000050C90: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 000000050C98: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 000000050CA0: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 000000050CA8: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 000000050CB0: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v125 :: v_dual_mul_f32 v6, 0x3b800000, v124// 000000050CB8: C8C6FAFF 0506F8FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v123 :: v_dual_mul_f32 v8, 0x3b800000, v122// 000000050CC4: C8C6F6FF 0708F4FF 3B800000
	.long 0xd7006a01                                           // 000000050CD0: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000050CD4: 0201FFBB
	.long 0x00006000                                           // 000000050CD8: 00006000
	v_dual_mul_f32 v9, 0x3b800000, v121 :: v_dual_mul_f32 v10, 0x3b800000, v120// 000000050CDC: C8C6F2FF 090AF0FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 000000050CE8: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v119 :: v_dual_mul_f32 v12, 0x3b800000, v52// 000000050CF0: C8C6EEFF 0B0C68FF 3B800000
	s_clause 0x7                                               // 000000050CFC: BF850007
	global_store_b32 v[3:4], v5, off                           // 000000050D00: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 000000050D08: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 000000050D10: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 000000050D18: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 000000050D20: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 000000050D28: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000050D30: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 000000050D38: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v118 :: v_dual_mul_f32 v6, 0x3b800000, v117// 000000050D40: C8C6ECFF 0506EAFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v116 :: v_dual_mul_f32 v8, 0x3b800000, v115// 000000050D4C: C8C6E8FF 0708E6FF 3B800000
	.long 0xd7006a03                                           // 000000050D58: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000050D5C: 0201FFBB
	.long 0x00008000                                           // 000000050D60: 00008000
	v_dual_mul_f32 v9, 0x3b800000, v114 :: v_dual_mul_f32 v10, 0x3b800000, v113// 000000050D64: C8C6E4FF 090AE2FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000050D70: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v112 :: v_dual_mul_f32 v12, 0x3b800000, v51// 000000050D78: C8C6E0FF 0B0C66FF 3B800000
	s_clause 0x7                                               // 000000050D84: BF850007
	global_store_b32 v[1:2], v5, off                           // 000000050D88: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 000000050D90: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 000000050D98: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 000000050DA0: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 000000050DA8: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 000000050DB0: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 000000050DB8: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 000000050DC0: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v111 :: v_dual_mul_f32 v6, 0x3b800000, v110// 000000050DC8: C8C6DEFF 0506DCFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v109 :: v_dual_mul_f32 v8, 0x3b800000, v108// 000000050DD4: C8C6DAFF 0708D8FF 3B800000
	.long 0xd7006a01                                           // 000000050DE0: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000050DE4: 0201FFBB
	.long 0x0000a000                                           // 000000050DE8: 0000A000
	v_dual_mul_f32 v9, 0x3b800000, v107 :: v_dual_mul_f32 v10, 0x3b800000, v106// 000000050DEC: C8C6D6FF 090AD4FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 000000050DF8: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v105 :: v_dual_mul_f32 v12, 0x3b800000, v50// 000000050E00: C8C6D2FF 0B0C64FF 3B800000
	s_clause 0x7                                               // 000000050E0C: BF850007
	global_store_b32 v[3:4], v5, off                           // 000000050E10: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 000000050E18: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 000000050E20: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 000000050E28: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 000000050E30: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 000000050E38: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000050E40: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 000000050E48: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v104 :: v_dual_mul_f32 v6, 0x3b800000, v103// 000000050E50: C8C6D0FF 0506CEFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v102 :: v_dual_mul_f32 v8, 0x3b800000, v101// 000000050E5C: C8C6CCFF 0708CAFF 3B800000
	.long 0xd7006a03                                           // 000000050E68: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000050E6C: 0201FFBB
	.long 0x0000c000                                           // 000000050E70: 0000C000
	v_dual_mul_f32 v9, 0x3b800000, v100 :: v_dual_mul_f32 v10, 0x3b800000, v99// 000000050E74: C8C6C8FF 090AC6FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000050E80: D5207C04 01AB7880
	v_mul_f32_e32 v11, 0x3b800000, v98                         // 000000050E88: 1016C4FF 3B800000
	v_mul_f32_e32 v12, 0x3b800000, v58                         // 000000050E90: 101874FF 3B800000
	s_clause 0x7                                               // 000000050E98: BF850007
	global_store_b32 v[1:2], v5, off                           // 000000050E9C: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 000000050EA4: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 000000050EAC: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 000000050EB4: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 000000050EBC: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 000000050EC4: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 000000050ECC: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 000000050ED4: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v97 :: v_dual_mul_f32 v6, 0x3b800000, v96// 000000050EDC: C8C6C2FF 0506C0FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v95 :: v_dual_mul_f32 v8, 0x3b800000, v94// 000000050EE8: C8C6BEFF 0708BCFF 3B800000
	.long 0xd7006a01                                           // 000000050EF4: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000050EF8: 0201FFBB
	.long 0x0000e000                                           // 000000050EFC: 0000E000
	v_dual_mul_f32 v9, 0x3b800000, v93 :: v_dual_mul_f32 v10, 0x3b800000, v92// 000000050F00: C8C6BAFF 090AB8FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 000000050F0C: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v91 :: v_dual_mul_f32 v12, 0x3b800000, v152// 000000050F14: C8C6B6FF 0B0D30FF 3B800000
	s_clause 0x7                                               // 000000050F20: BF850007
	global_store_b32 v[3:4], v5, off                           // 000000050F24: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 000000050F2C: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 000000050F34: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 000000050F3C: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 000000050F44: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 000000050F4C: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000050F54: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 000000050F5C: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v90 :: v_dual_mul_f32 v6, 0x3b800000, v141// 000000050F64: C8C6B4FF 05071AFF 3B800000
	v_and_or_b32 v0, v0, 31, s5                                // 000000050F70: D6570000 00153F00
	v_dual_mul_f32 v7, 0x3b800000, v150 :: v_dual_mul_f32 v10, 0x3b800000, v189// 000000050F78: C8C72CFF 070B7AFF 3B800000
	.long 0xd7006a03                                           // 000000050F84: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000050F88: 0201FFBB
	.long 0x0000fc00                                           // 000000050F8C: 0000FC00
	v_dual_mul_f32 v8, 0x3b800000, v142 :: v_dual_mul_f32 v9, 0x3b800000, v191// 000000050F90: C8C71CFF 08097EFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000050F9C: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v190 :: v_dual_mul_f32 v12, 0x3b800000, v151// 000000050FA4: C8C77CFF 0B0D2EFF 3B800000
	s_clause 0x7                                               // 000000050FB0: BF850007
	global_store_b32 v[1:2], v5, off                           // 000000050FB4: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 000000050FBC: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 000000050FC4: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 000000050FCC: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-3072              // 000000050FD4: DC6A1400 007C0903
	global_store_b32 v[3:4], v10, off offset:-2048             // 000000050FDC: DC6A1800 007C0A03
	global_store_b32 v[3:4], v11, off offset:-1024             // 000000050FE4: DC6A1C00 007C0B03
	global_store_b32 v[3:4], v12, off                          // 000000050FEC: DC6A0000 007C0C03
	s_mov_b32 s2, exec_lo                                      // 000000050FF4: BE82007E
	v_cmpx_eq_u32_e32 0, v0                                    // 000000050FF8: 7D940080
	s_cbranch_execz 8                                          // 000000050FFC: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi8ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5620>
	s_load_b64 s[0:1], s[0:1], 0x40                            // 000000051000: F4040000 F8000040
	v_mov_b32_e32 v0, s6                                       // 000000051008: 7E000206
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, s7              // 00000005100C: CA100080 02000007
	s_waitcnt lgkmcnt(0)                                       // 000000051014: BF89FC07
	global_store_b64 v2, v[0:1], s[0:1] offset:56              // 000000051018: DC6E0038 00000002
	s_endpgm                                                   // 000000051020: BFB00000
		...

