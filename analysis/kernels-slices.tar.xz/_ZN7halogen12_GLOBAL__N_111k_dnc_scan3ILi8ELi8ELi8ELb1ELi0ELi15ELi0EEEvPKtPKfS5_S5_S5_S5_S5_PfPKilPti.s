000000000012bc00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 00000012BC00: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 00000012BC04: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000012BC0C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 00000012BC14: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 00000012BC18: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000012BC1C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 00000012BC20: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000012BC28: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000012BC2C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 00000012BC30: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 00000012BC34: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000012BC3C: 84928214
	s_add_u32 s25, s16, s18                                    // 00000012BC40: 80191210
	s_addc_u32 s28, s17, s19                                   // 00000012BC44: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 00000012BC48: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000012BC4C: BF870009
	s_add_u32 s25, s25, s20                                    // 00000012BC50: 80191419
	s_addc_u32 s30, s28, s21                                   // 00000012BC54: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 00000012BC58: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000012BC5C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 00000012BC64: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000012BC6C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 00000012BC70: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 00000012BC74: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000012BC78: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000012BC7C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 00000012BC80: 821E191E
	.long 0xd7001f02                                           // 00000012BC84: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 00000012BC88: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000012BC8C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 00000012BC94: BE9E0080
	s_nop 0                                                    // 00000012BC98: BF800000
	s_nop 0                                                    // 00000012BC9C: BF800000
	s_nop 0                                                    // 00000012BCA0: BF800000
	s_nop 0                                                    // 00000012BCA4: BF800000
	s_nop 0                                                    // 00000012BCA8: BF800000
	s_nop 0                                                    // 00000012BCAC: BF800000
	s_nop 0                                                    // 00000012BCB0: BF800000
	s_nop 0                                                    // 00000012BCB4: BF800000
	s_nop 0                                                    // 00000012BCB8: BF800000
	s_nop 0                                                    // 00000012BCBC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 00000012BCC0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 00000012BCC4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BCCC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 00000012BCD0: 300C1089
	.long 0xd7006a06                                           // 00000012BCD4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000012BCD8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012BCDC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 00000012BCE0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000012BCE8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 00000012BCF0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 00000012BCF4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 00000012BCFC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 00000012BD08: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000012BD0C: BF8903F7
	ds_store_b32 v6, v9                                        // 00000012BD10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 00000012BD18: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000012BD1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 00000012BD20: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 00000012BD24: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 00000012BD2C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 00000012BD34: 32040084
	s_mov_b32 s0, 0                                            // 00000012BD38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000012BD3C: BF89FC07
	s_barrier                                                  // 00000012BD40: BFBD0000
	buffer_gl0_inv                                             // 00000012BD44: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000012BD4C: BF02801E
	s_cbranch_scc1 12                                          // 00000012BD50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 00000012BD54: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000012BD5C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 00000012BD64: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 00000012BD68: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 00000012BD70: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000012BD74: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000012BD78: 916A007E
	s_cbranch_vccz 2                                           // 00000012BD7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2600                                              // 00000012BD80: BFA00A28 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a24>
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000012BD84: 304E0A82
	s_add_i32 s0, s30, 63                                      // 00000012BD88: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000012BD8C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 00000012BD94: 85218600
	s_add_u32 s34, s10, s24                                    // 00000012BD98: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000012BD9C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 00000012BDA0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 00000012BDA4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 00000012BDAC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 00000012BDB0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000012BDB4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 00000012BDB8: 301A0488
	s_add_u32 s22, s22, s0                                     // 00000012BDBC: 80160016
	s_addc_u32 s1, s23, s1                                     // 00000012BDC0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 00000012BDC4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 00000012BDC8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 00000012BDD4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 00000012BDD8: 82010B01
	s_movk_i32 s10, 0x204                                      // 00000012BDDC: B00A0204
	.long 0xd7000b2c                                           // 00000012BDE0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 00000012BDE4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000012BDE8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 00000012BDEC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 00000012BDF4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 00000012BE00: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 00000012BE04: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 00000012BE10: 3816500A
	.long 0xd7000a05                                           // 00000012BE14: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 00000012BE18: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012BE1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 00000012BE20: D5207C06 00290001
	.long 0xd7000107                                           // 00000012BE28: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 00000012BE2C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012BE30: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 00000012BE34: D5207C08 0006180D
	.long 0xd7000109                                           // 00000012BE3C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 00000012BE40: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 00000012BE44: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 00000012BE4C: 84848E02
	.long 0xd700010b                                           // 00000012BE50: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 00000012BE54: 02021606
	s_add_u32 s4, s14, s4                                      // 00000012BE58: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 00000012BE5C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 00000012BE64: 8205050F
	.long 0xd700010d                                           // 00000012BE68: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 00000012BE6C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012BE70: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 00000012BE74: D5207C0E 00050005
	.long 0xd700010f                                           // 00000012BE7C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 00000012BE80: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 00000012BE88: D5207C10 00061880
	.long 0xd7000111                                           // 00000012BE90: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 00000012BE94: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012BE9C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 00000012BEA0: D5207C12 00061880
	.long 0xd7000113                                           // 00000012BEA8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 00000012BEAC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 00000012BEB4: D5207C14 00061880
	.long 0xd7000115                                           // 00000012BEBC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 00000012BEC0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012BEC8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 00000012BECC: D5207C16 00061880
	.long 0xd7000117                                           // 00000012BED4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 00000012BED8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 00000012BEE0: D5207C18 00061880
	.long 0xd7000119                                           // 00000012BEE8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 00000012BEEC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012BEF4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 00000012BEF8: D5207C1A 00061880
	.long 0xd700011b                                           // 00000012BF00: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 00000012BF04: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 00000012BF0C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 00000012BF14: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000012BF18: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 00000012BF20: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 00000012BF24: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 00000012BF2C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 00000012BF34: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 00000012BF3C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 00000012BF44: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 00000012BF4C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 00000012BF54: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 00000012BF5C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 00000012BF64: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 00000012BF6C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 00000012BF74: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 00000012BF7C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 00000012BF84: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 00000012BF8C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 00000012BF94: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 00000012BF9C: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 00000012BFA0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 00000012BFA4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000012BFAC: BF870499
	s_add_i32 s6, s31, s1                                      // 00000012BFB0: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 00000012BFB4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000012BFB8: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 00000012BFBC: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 00000012BFC0: 84078605
	s_add_u32 s10, s8, s10                                     // 00000012BFC4: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 00000012BFC8: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 00000012BFCC: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 00000012BFD4: BE84206A
	s_cbranch_execz 77                                         // 00000012BFD8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510>
	v_or_b32_e32 v29, s7, v0                                   // 00000012BFDC: 383A0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BFE0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 00000012BFE4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 00000012BFEC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BFF0: BF870091
	.long 0xd73c001d                                           // 00000012BFF4: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 00000012BFF8: 02023A82
	.long 0xd700011d                                           // 00000012BFFC: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 00000012C000: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012C004: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 00000012C008: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 00000012C010: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012C018: BF890007
	v_sub_f32_e32 v30, s6, v29                                 // 00000012C01C: 083C3A06
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 00000012C020: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000012C02C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 00000012C030: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 00000012C03C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 00000012C040: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 00000012C04C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012C050: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 00000012C054: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 00000012C060: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012C064: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 00000012C068: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 00000012C070: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 00000012C074: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 00000012C07C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 00000012C084: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 00000012C088: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012C08C: BF870193
	v_exp_f32_e32 v32, v32                                     // 00000012C090: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 00000012C094: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012C098: BF870296
	.long 0xd71c0020                                           // 00000012C09C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 00000012C0A0: 02024520
	.long 0xd71c001f                                           // 00000012C0A4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 00000012C0A8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012C0AC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 00000012C0B0: D501001F 00063E80
	.long 0xd41b0001                                           // 00000012C0B8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 00000012C0BC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 00000012C0C4: D5010020 00064080
	.long 0xd41e0001                                           // 00000012C0CC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 00000012C0D0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012C0D8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 00000012C0DC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 00000012C0E8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 00000012C0EC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 00000012C0F4: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 00000012C100: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 00000012C108: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012C110: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 00000012C114: CA100108 1E1C0107
	s_mov_b32 s10, 0                                           // 00000012C11C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000012C120: BF89FC07
	s_barrier                                                  // 00000012C124: BFBD0000
	buffer_gl0_inv                                             // 00000012C128: E0AC0000 00000000
	s_branch 15                                                // 00000012C130: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012C134: 8C7E047E
	.long 0xd700011d                                           // 00000012C138: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 00000012C13C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012C144: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012C148: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 00000012C150: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000012C154: BF08B70A
	s_mov_b32 s10, s1                                          // 00000012C158: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 00000012C15C: BF89FC07
	s_barrier                                                  // 00000012C160: BFBD0000
	buffer_gl0_inv                                             // 00000012C164: E0AC0000 00000000
	s_cbranch_scc1 706                                         // 00000012C16C: BFA202C2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 00000012C170: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 00000012C178: CA100128 21220126
	s_mov_b32 s11, 0                                           // 00000012C180: BE8B0080
	s_nop 0                                                    // 00000012C184: BF800000
	s_nop 0                                                    // 00000012C188: BF800000
	s_nop 0                                                    // 00000012C18C: BF800000
	s_nop 0                                                    // 00000012C190: BF800000
	s_nop 0                                                    // 00000012C194: BF800000
	s_nop 0                                                    // 00000012C198: BF800000
	s_nop 0                                                    // 00000012C19C: BF800000
	s_nop 0                                                    // 00000012C1A0: BF800000
	s_nop 0                                                    // 00000012C1A4: BF800000
	s_nop 0                                                    // 00000012C1A8: BF800000
	s_nop 0                                                    // 00000012C1AC: BF800000
	s_nop 0                                                    // 00000012C1B0: BF800000
	s_nop 0                                                    // 00000012C1B4: BF800000
	s_nop 0                                                    // 00000012C1B8: BF800000
	s_nop 0                                                    // 00000012C1BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 00000012C1C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 00000012C1C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 00000012C1D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 00000012C1D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012C1DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 00000012C1E0: D5207C20 00064080
	.long 0xd4490004                                           // 00000012C1E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 00000012C1EC: 020244FF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000012C1F4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000012C1F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 00000012C1FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 00000012C204: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000012C20C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000012C210: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000012C214: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000012C218: BF89FC07
	s_barrier                                                  // 00000012C21C: BFBD0000
	buffer_gl0_inv                                             // 00000012C220: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000012C228: BE842000
	s_cbranch_execz 65473                                      // 00000012C22C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 00000012C230: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 00000012C238: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 00000012C240: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 00000012C248: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 00000012C250: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 00000012C258: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 00000012C260: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 00000012C268: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v46 offset0:14 offset1:15      // 00000012C270: D8DC0F0E 4800002E
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 00000012C278: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 00000012C280: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 00000012C288: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 00000012C290: D8DCFFEE 50000001
	v_or3_b32 v70, s10, s7, v2                                 // 00000012C298: D6580046 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C2A0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 00000012C2A4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 00000012C2AC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 00000012C2B0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C2B4: BF870091
	.long 0xd7000146                                           // 00000012C2B8: D7000146
	v_cndmask_b32_e32 v1, v44, v70, vcc_lo                     // 00000012C2BC: 02028D2C
	v_add_co_ci_u32_e64 v71, null, v45, v71, s1                // 00000012C2C0: D5207C47 00068F2D
	global_load_b32 v70, v[70:71], off                         // 00000012C2C8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 00000012C2D0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 00000012C2D4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012C2DC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 00000012C2E0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 00000012C2E8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 00000012C2EC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 00000012C2F4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:10 offset1:11      // 00000012C2FC: D8DC0B0A 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:12 offset1:13      // 00000012C304: D8DC0D0C 4600002E
	v_fma_f32 v33, -v34, v65, v33                              // 00000012C30C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 00000012C314: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C318: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 00000012C31C: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 00000012C324: D6130021 24868724
	s_waitcnt lgkmcnt(8)                                       // 00000012C32C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C330: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 00000012C334: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 00000012C33C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 00000012C344: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C348: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 00000012C34C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 00000012C354: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 00000012C35C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012C360: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000012C364: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 00000012C36C: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 00000012C374: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 00000012C37C: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 00000012C384: D8DC1716 3C00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:16 offset1:33      // 00000012C38C: D8DC2110 40000030
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 00000012C394: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:84 offset1:101     // 00000012C39C: D8DC6554 44000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 00000012C3A4: D8DC8776 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 00000012C3AC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 00000012C3B4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C3B8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 00000012C3BC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 00000012C3C4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C3CC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 00000012C3D0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 00000012C3D8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 00000012C3E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C3E4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 00000012C3E8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 00000012C3F0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 00000012C3F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012C3FC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 00000012C400: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 00000012C408: D8DC1918 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 00000012C410: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 00000012C418: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 00000012C420: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:152 offset1:169    // 00000012C428: D8DCA998 48000030
	ds_load_2addr_b32 v[76:77], v48 offset0:186 offset1:203    // 00000012C430: D8DCCBBA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:220 offset1:237    // 00000012C438: D8DCEDDC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:126 offset1:143    // 00000012C440: D8DC8F7E 50000031
	v_fma_f32 v33, -v34, v67, v33                              // 00000012C448: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 00000012C450: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C454: BF870091
	v_fma_f32 v33, -v35, v68, v33                              // 00000012C458: D6130021 24868923
	v_fma_f32 v33, -v36, v69, v33                              // 00000012C460: D6130021 24868B24
	s_waitcnt lgkmcnt(8)                                       // 00000012C468: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C46C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000012C470: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000012C478: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000012C480: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C484: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 00000012C488: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 00000012C490: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 00000012C498: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012C49C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000012C4A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 00000012C4A8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 00000012C4B0: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 00000012C4B8: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 00000012C4C0: D8DC2726 3C00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 00000012C4C8: D8DC3120 42000032
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 00000012C4D0: D8DC5342 44000032
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 00000012C4D8: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 00000012C4E0: D8DC9786 4A000032
	v_fma_f32 v62, -v63, v77, v62                              // 00000012C4E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000012C4F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C4F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000012C4F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000012C500: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000012C508: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C50C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 00000012C510: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 00000012C518: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 00000012C520: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C524: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 00000012C528: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 00000012C530: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 00000012C538: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012C53C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 00000012C540: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 00000012C548: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 00000012C550: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:44 offset1:45      // 00000012C558: D8DC2D2C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:46 offset1:47      // 00000012C560: D8DC2F2E 4200002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 00000012C568: D8DCB9A8 46000032
	ds_load_2addr_b32 v[76:77], v50 offset0:202 offset1:219    // 00000012C570: D8DCDBCA 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:236 offset1:253    // 00000012C578: D8DCFDEC 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:14 offset1:31      // 00000012C580: D8DC1F0E 50000033
	v_fma_f32 v33, -v34, v69, v33                              // 00000012C588: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 00000012C590: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C594: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000012C598: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000012C5A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000012C5A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C5AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000012C5B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000012C5B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000012C5C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C5C4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 00000012C5C8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 00000012C5D0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 00000012C5D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012C5DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000012C5E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 00000012C5E8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 00000012C5F0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 00000012C5F8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 00000012C600: D8DC3736 3C00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:48 offset1:65      // 00000012C608: D8DC4130 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:82 offset1:99      // 00000012C610: D8DC6352 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 00000012C618: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 00000012C620: D8DCA796 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 00000012C628: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000012C630: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C634: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000012C638: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000012C640: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000012C648: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C64C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 00000012C650: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 00000012C658: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 00000012C660: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C664: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 00000012C668: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000012C670: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000012C678: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012C67C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 00000012C680: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 00000012C688: D8DC3938 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:58 offset1:59      // 00000012C690: D8DC3B3A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:60 offset1:61      // 00000012C698: D8DC3D3C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:62 offset1:63      // 00000012C6A0: D8DC3F3E 4200002E
	ds_load_2addr_b32 v[68:69], v51 offset0:184 offset1:201    // 00000012C6A8: D8DCC9B8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:218 offset1:235    // 00000012C6B0: D8DCEBDA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:124 offset1:141    // 00000012C6B8: D8DC8D7C 4E000034
	ds_load_2addr_b32 v[80:81], v53 offset0:30 offset1:47      // 00000012C6C0: D8DC2F1E 50000035
	v_fma_f32 v33, -v34, v71, v33                              // 00000012C6C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 00000012C6D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C6D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000012C6D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000012C6E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000012C6E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C6EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000012C6F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000012C6F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000012C700: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C704: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 00000012C708: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000012C710: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000012C718: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012C71C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000012C720: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 00000012C728: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 00000012C730: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 00000012C738: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 00000012C740: D8DC4746 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:64 offset1:81      // 00000012C748: D8DC5140 44000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 00000012C750: D8DC7362 46000035
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 00000012C758: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 00000012C760: D8DCB7A6 4A000035
	v_fma_f32 v62, -v63, v77, v62                              // 00000012C768: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000012C770: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C774: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000012C778: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000012C780: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000012C788: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C78C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 00000012C790: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 00000012C798: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 00000012C7A0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C7A4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 00000012C7A8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000012C7B0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000012C7B8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012C7BC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 00000012C7C0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 00000012C7C8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 00000012C7D0: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 00000012C7D8: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:78 offset1:79      // 00000012C7E0: D8DC4F4E 4200002E
	ds_load_2addr_b32 v[68:69], v53 offset0:200 offset1:217    // 00000012C7E8: D8DCD9C8 44000035
	ds_load_2addr_b32 v[76:77], v53 offset0:234 offset1:251    // 00000012C7F0: D8DCFBEA 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:12 offset1:29      // 00000012C7F8: D8DC1D0C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:46 offset1:63      // 00000012C800: D8DC3F2E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 00000012C808: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 00000012C810: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C814: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000012C818: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000012C820: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000012C828: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C82C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000012C830: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000012C838: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000012C840: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C844: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 00000012C848: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000012C850: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000012C858: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012C85C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000012C860: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 00000012C868: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 00000012C870: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 00000012C878: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 00000012C880: D8DC5756 3C00002E
	ds_load_2addr_b32 v[68:69], v54 offset0:80 offset1:97      // 00000012C888: D8DC6150 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 00000012C890: D8DC8372 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 00000012C898: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 00000012C8A0: D8DCC7B6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 00000012C8A8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000012C8B0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C8B4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000012C8B8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000012C8C0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000012C8C8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C8CC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 00000012C8D0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 00000012C8D8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 00000012C8E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C8E4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 00000012C8E8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000012C8F0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000012C8F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012C8FC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 00000012C900: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 00000012C908: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 00000012C910: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:92 offset1:93      // 00000012C918: D8DC5D5C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:94 offset1:95      // 00000012C920: D8DC5F5E 4200002E
	ds_load_2addr_b32 v[68:69], v54 offset0:216 offset1:233    // 00000012C928: D8DCE9D8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:122 offset1:139    // 00000012C930: D8DC8B7A 4C000037
	ds_load_2addr_b32 v[78:79], v56 offset0:28 offset1:45      // 00000012C938: D8DC2D1C 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:62 offset1:79      // 00000012C940: D8DC4F3E 50000038
	v_fma_f32 v33, -v34, v71, v33                              // 00000012C948: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 00000012C950: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C954: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000012C958: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000012C960: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000012C968: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C96C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000012C970: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000012C978: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000012C980: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C984: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 00000012C988: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000012C990: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000012C998: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012C99C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000012C9A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 00000012C9A8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 00000012C9B0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 00000012C9B8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 00000012C9C0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:96 offset1:113     // 00000012C9C8: D8DC7160 44000038
	ds_load_2addr_b32 v[70:71], v56 offset0:130 offset1:147    // 00000012C9D0: D8DC9382 46000038
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 00000012C9D8: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 00000012C9E0: D8DCD7C6 4A000038
	v_fma_f32 v62, -v63, v77, v62                              // 00000012C9E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000012C9F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C9F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000012C9F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000012CA00: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000012CA08: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CA0C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 00000012CA10: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 00000012CA18: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 00000012CA20: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CA24: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 00000012CA28: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000012CA30: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000012CA38: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012CA3C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 00000012CA40: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 00000012CA48: D8DC6968 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:106 offset1:107    // 00000012CA50: D8DC6B6A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:108 offset1:109    // 00000012CA58: D8DC6D6C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:110 offset1:111    // 00000012CA60: D8DC6F6E 4200002E
	ds_load_2addr_b32 v[68:69], v56 offset0:232 offset1:249    // 00000012CA68: D8DCF9E8 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:10 offset1:27      // 00000012CA70: D8DC1B0A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:44 offset1:61      // 00000012CA78: D8DC3D2C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:78 offset1:95      // 00000012CA80: D8DC5F4E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 00000012CA88: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 00000012CA90: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CA94: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000012CA98: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000012CAA0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000012CAA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CAAC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000012CAB0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000012CAB8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000012CAC0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CAC4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 00000012CAC8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000012CAD0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000012CAD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012CADC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000012CAE0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 00000012CAE8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 00000012CAF0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 00000012CAF8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 00000012CB00: D8DC7776 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 00000012CB08: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 00000012CB10: D8DCA392 46000039
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 00000012CB18: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 00000012CB20: D8DCE7D6 4A000039
	v_fma_f32 v62, -v63, v77, v62                              // 00000012CB28: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000012CB30: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CB34: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000012CB38: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 00000012CB40: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 00000012CB48: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CB4C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 00000012CB50: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 00000012CB58: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 00000012CB60: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CB64: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 00000012CB68: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000012CB70: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000012CB78: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012CB7C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 00000012CB80: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 00000012CB88: D8DC7978 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 00000012CB90: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 00000012CB98: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:126 offset1:127    // 00000012CBA0: D8DC7F7E 4200002E
	ds_load_2addr_b32 v[68:69], v58 offset0:120 offset1:137    // 00000012CBA8: D8DC8978 4400003A
	ds_load_2addr_b32 v[76:77], v59 offset0:26 offset1:43      // 00000012CBB0: D8DC2B1A 4C00003B
	ds_load_2addr_b32 v[78:79], v59 offset0:60 offset1:77      // 00000012CBB8: D8DC4D3C 4E00003B
	ds_load_2addr_b32 v[80:81], v59 offset0:94 offset1:111     // 00000012CBC0: D8DC6F5E 5000003B
	v_fma_f32 v33, -v34, v71, v33                              // 00000012CBC8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 00000012CBD0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CBD4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 00000012CBD8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 00000012CBE0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 00000012CBE8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CBEC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000012CBF0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000012CBF8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000012CC00: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CC04: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 00000012CC08: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 00000012CC10: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 00000012CC18: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CC1C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 00000012CC20: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 00000012CC28: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 00000012CC30: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CC34: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 00000012CC38: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 00000012CC40: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 00000012CC48: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012CC4C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 00000012CC50: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s10, v[4:5]            // 00000012CC58: D6FE7C1F 041014FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 00000012CC64: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 00000012CC6C: D8340000 0000201F
	s_branch 64815                                             // 00000012CC74: BFA0FD2F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_mov_b32_e32 v30, v14                                     // 00000012CC78: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 00000012CC7C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 00000012CC84: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 00000012CC88: 7E46032B
	s_mov_b32 s10, 0                                           // 00000012CC8C: BE8A0080
	s_branch 21                                                // 00000012CC90: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000012CC94: 8C7E0B7E
	.long 0xd700011f                                           // 00000012CC98: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 00000012CC9C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012CCA4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 00000012CCA8: D5207C20 00064080
	.long 0xd700011d                                           // 00000012CCB0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 00000012CCB4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 00000012CCBC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012CCC0: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 00000012CCC8: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000012CCCC: BF08B70A
	s_mov_b32 s10, s1                                          // 00000012CCD0: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 00000012CCD4: BC7C0000
	s_barrier                                                  // 00000012CCD8: BFBD0000
	buffer_gl0_inv                                             // 00000012CCDC: E0AC0000 00000000
	s_cbranch_scc1 598                                         // 00000012CCE4: BFA20256 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a40>
	s_delay_alu instid0(VALU_DEP_2)                            // 00000012CCE8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 00000012CCEC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 00000012CCF4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 00000012CCF8: 7E780326
	s_mov_b32 s11, 0                                           // 00000012CCFC: BE8B0080
	global_load_b32 v61, v[33:34], off                         // 00000012CD00: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 00000012CD08: 4A7878FF 00000080
	.long 0xd7000121                                           // 00000012CD10: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 00000012CD14: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012CD1C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 00000012CD20: D5207C22 00064480
	.long 0xd4490004                                           // 00000012CD28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 00000012CD2C: 020278FF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000012CD34: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000012CD38: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 00000012CD3C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 00000012CD44: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000012CD4C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000012CD50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000012CD54: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000012CD58: BF89FC07
	s_barrier                                                  // 00000012CD5C: BFBD0000
	buffer_gl0_inv                                             // 00000012CD60: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 00000012CD68: BE8B2000
	s_cbranch_execz 65481                                      // 00000012CD6C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s10, v2                                  // 00000012CD70: 3842040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CD74: BF870091
	v_or_b32_e32 v36, s7, v33                                  // 00000012CD78: 38484207
	.long 0xd4440001                                           // 00000012CD7C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 00000012CD80: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 00000012CD84: 8B7E017E
	s_cbranch_execz 65474                                      // 00000012CD88: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 00000012CD8C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 00000012CD94: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:2 offset1:3        // 00000012CD9C: D8DC0302 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 00000012CDA4: D8DC3322 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:4 offset1:5        // 00000012CDAC: D8DC0504 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:6 offset1:7        // 00000012CDB4: D8DC0706 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 00000012CDBC: D8DC5544 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:102 offset1:119     // 00000012CDC4: D8DC7766 4A000001
	s_mov_b32 s12, 0                                           // 00000012CDCC: BE8C0080
	s_waitcnt lgkmcnt(6)                                       // 00000012CDD0: BF89FC67
	v_fma_f32 v76, v60, v62, 0                                 // 00000012CDD4: D613004C 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012CDDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000012CDE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000012CDE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012CDE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012CDEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000012CDF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000012CDF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000012CDF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012CDFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000012CE00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000012CE04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000012CE08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012CE0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000012CE10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:8 offset1:9        // 00000012CE14: D8DC0908 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 00000012CE1C: D8DC9988 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:10 offset1:11      // 00000012CE24: D8DC0B0A 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:170 offset1:187     // 00000012CE2C: D8DCBBAA 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:12 offset1:13      // 00000012CE34: D8DC0D0C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:14 offset1:15      // 00000012CE3C: D8DC0F0E 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 00000012CE44: D8DCDDCC 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:238 offset1:255     // 00000012CE4C: D8DCFFEE 4A000001
	s_waitcnt lgkmcnt(6)                                       // 00000012CE54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000012CE58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012CE5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000012CE60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000012CE64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012CE68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012CE6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000012CE70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000012CE74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000012CE78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012CE7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000012CE80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000012CE84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000012CE88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012CE8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000012CE90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:16 offset1:17      // 00000012CE94: D8DC1110 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:16 offset1:33      // 00000012CE9C: D8DC2110 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:18 offset1:19      // 00000012CEA4: D8DC1312 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 00000012CEAC: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:20 offset1:21      // 00000012CEB4: D8DC1514 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:22 offset1:23      // 00000012CEBC: D8DC1716 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:84 offset1:101     // 00000012CEC4: D8DC6554 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 00000012CECC: D8DC8776 4A000030
	s_waitcnt lgkmcnt(6)                                       // 00000012CED4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000012CED8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012CEDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000012CEE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000012CEE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012CEE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012CEEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000012CEF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000012CEF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000012CEF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012CEFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000012CF00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000012CF04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000012CF08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012CF0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000012CF10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 00000012CF14: D8DC1918 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:152 offset1:169    // 00000012CF1C: D8DCA998 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:26 offset1:27      // 00000012CF24: D8DC1B1A 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:186 offset1:203    // 00000012CF2C: D8DCCBBA 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:28 offset1:29      // 00000012CF34: D8DC1D1C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 00000012CF3C: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:220 offset1:237    // 00000012CF44: D8DCEDDC 48000030
	ds_load_2addr_b32 v[74:75], v49 offset0:126 offset1:143    // 00000012CF4C: D8DC8F7E 4A000031
	s_waitcnt lgkmcnt(6)                                       // 00000012CF54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000012CF58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012CF5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000012CF60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000012CF64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012CF68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012CF6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000012CF70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000012CF74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000012CF78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012CF7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000012CF80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000012CF84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000012CF88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012CF8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000012CF90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:32 offset1:33      // 00000012CF94: D8DC2120 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:32 offset1:49      // 00000012CF9C: D8DC3120 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 00000012CFA4: D8DC2322 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:66 offset1:83      // 00000012CFAC: D8DC5342 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:36 offset1:37      // 00000012CFB4: D8DC2524 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:38 offset1:39      // 00000012CFBC: D8DC2726 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 00000012CFC4: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 00000012CFCC: D8DC9786 4A000032
	s_waitcnt lgkmcnt(6)                                       // 00000012CFD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000012CFD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012CFDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000012CFE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000012CFE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012CFE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012CFEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000012CFF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000012CFF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000012CFF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012CFFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000012D000: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000012D004: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000012D008: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012D00C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000012D010: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:40 offset1:41      // 00000012D014: D8DC2928 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:168 offset1:185    // 00000012D01C: D8DCB9A8 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:42 offset1:43      // 00000012D024: D8DC2B2A 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:202 offset1:219    // 00000012D02C: D8DCDBCA 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:44 offset1:45      // 00000012D034: D8DC2D2C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:46 offset1:47      // 00000012D03C: D8DC2F2E 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:236 offset1:253    // 00000012D044: D8DCFDEC 48000032
	ds_load_2addr_b32 v[74:75], v51 offset0:14 offset1:31      // 00000012D04C: D8DC1F0E 4A000033
	s_waitcnt lgkmcnt(6)                                       // 00000012D054: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000012D058: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D05C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000012D060: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000012D064: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012D068: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D06C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000012D070: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000012D074: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000012D078: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D07C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000012D080: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000012D084: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000012D088: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012D08C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000012D090: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 00000012D094: D8DC3130 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:48 offset1:65      // 00000012D09C: D8DC4130 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:50 offset1:51      // 00000012D0A4: D8DC3332 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:82 offset1:99      // 00000012D0AC: D8DC6352 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:52 offset1:53      // 00000012D0B4: D8DC3534 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:54 offset1:55      // 00000012D0BC: D8DC3736 4600002E
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 00000012D0C4: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 00000012D0CC: D8DCA796 4A000033
	s_waitcnt lgkmcnt(6)                                       // 00000012D0D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000012D0D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D0DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000012D0E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000012D0E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012D0E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D0EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000012D0F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000012D0F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000012D0F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D0FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000012D100: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000012D104: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000012D108: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012D10C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000012D110: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:56 offset1:57      // 00000012D114: D8DC3938 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:184 offset1:201    // 00000012D11C: D8DCC9B8 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:58 offset1:59      // 00000012D124: D8DC3B3A 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:218 offset1:235    // 00000012D12C: D8DCEBDA 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:60 offset1:61      // 00000012D134: D8DC3D3C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:62 offset1:63      // 00000012D13C: D8DC3F3E 4600002E
	ds_load_2addr_b32 v[72:73], v52 offset0:124 offset1:141    // 00000012D144: D8DC8D7C 48000034
	ds_load_2addr_b32 v[74:75], v53 offset0:30 offset1:47      // 00000012D14C: D8DC2F1E 4A000035
	s_waitcnt lgkmcnt(6)                                       // 00000012D154: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000012D158: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D15C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000012D160: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000012D164: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012D168: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D16C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000012D170: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000012D174: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000012D178: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D17C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000012D180: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000012D184: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000012D188: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012D18C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000012D190: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:64 offset1:65      // 00000012D194: D8DC4140 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:64 offset1:81      // 00000012D19C: D8DC5140 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:66 offset1:67      // 00000012D1A4: D8DC4342 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:98 offset1:115     // 00000012D1AC: D8DC7362 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:68 offset1:69      // 00000012D1B4: D8DC4544 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:70 offset1:71      // 00000012D1BC: D8DC4746 4600002E
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 00000012D1C4: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 00000012D1CC: D8DCB7A6 4A000035
	s_waitcnt lgkmcnt(6)                                       // 00000012D1D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000012D1D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D1DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000012D1E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000012D1E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012D1E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D1EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000012D1F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000012D1F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000012D1F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D1FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000012D200: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000012D204: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000012D208: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012D20C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000012D210: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 00000012D214: D8DC4948 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:200 offset1:217    // 00000012D21C: D8DCD9C8 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:74 offset1:75      // 00000012D224: D8DC4B4A 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:234 offset1:251    // 00000012D22C: D8DCFBEA 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:76 offset1:77      // 00000012D234: D8DC4D4C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:78 offset1:79      // 00000012D23C: D8DC4F4E 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:12 offset1:29      // 00000012D244: D8DC1D0C 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:46 offset1:63      // 00000012D24C: D8DC3F2E 4A000036
	s_waitcnt lgkmcnt(6)                                       // 00000012D254: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000012D258: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D25C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000012D260: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000012D264: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012D268: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D26C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000012D270: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000012D274: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000012D278: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D27C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000012D280: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000012D284: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000012D288: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012D28C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000012D290: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:80 offset1:81      // 00000012D294: D8DC5150 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:80 offset1:97      // 00000012D29C: D8DC6150 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 00000012D2A4: D8DC5352 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:114 offset1:131    // 00000012D2AC: D8DC8372 42000036
	ds_load_2addr_b32 v[68:69], v46 offset0:84 offset1:85      // 00000012D2B4: D8DC5554 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:86 offset1:87      // 00000012D2BC: D8DC5756 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 00000012D2C4: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 00000012D2CC: D8DCC7B6 4A000036
	s_waitcnt lgkmcnt(6)                                       // 00000012D2D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000012D2D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D2DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000012D2E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000012D2E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012D2E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D2EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000012D2F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000012D2F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000012D2F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D2FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000012D300: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000012D304: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000012D308: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012D30C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000012D310: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:88 offset1:89      // 00000012D314: D8DC5958 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:216 offset1:233    // 00000012D31C: D8DCE9D8 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:90 offset1:91      // 00000012D324: D8DC5B5A 4000002E
	ds_load_2addr_b32 v[66:67], v55 offset0:122 offset1:139    // 00000012D32C: D8DC8B7A 42000037
	ds_load_2addr_b32 v[68:69], v46 offset0:92 offset1:93      // 00000012D334: D8DC5D5C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:94 offset1:95      // 00000012D33C: D8DC5F5E 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:28 offset1:45      // 00000012D344: D8DC2D1C 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:62 offset1:79      // 00000012D34C: D8DC4F3E 4A000038
	s_waitcnt lgkmcnt(6)                                       // 00000012D354: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000012D358: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D35C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000012D360: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000012D364: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012D368: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D36C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000012D370: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000012D374: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000012D378: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D37C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000012D380: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000012D384: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000012D388: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012D38C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000012D390: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 00000012D394: D8DC6160 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:96 offset1:113     // 00000012D39C: D8DC7160 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:98 offset1:99      // 00000012D3A4: D8DC6362 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:130 offset1:147    // 00000012D3AC: D8DC9382 42000038
	ds_load_2addr_b32 v[68:69], v46 offset0:100 offset1:101    // 00000012D3B4: D8DC6564 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:102 offset1:103    // 00000012D3BC: D8DC6766 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 00000012D3C4: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 00000012D3CC: D8DCD7C6 4A000038
	s_waitcnt lgkmcnt(6)                                       // 00000012D3D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000012D3D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D3DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000012D3E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000012D3E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012D3E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D3EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000012D3F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000012D3F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000012D3F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D3FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000012D400: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000012D404: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000012D408: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012D40C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000012D410: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:104 offset1:105    // 00000012D414: D8DC6968 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:232 offset1:249    // 00000012D41C: D8DCF9E8 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 00000012D424: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:10 offset1:27      // 00000012D42C: D8DC1B0A 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:108 offset1:109    // 00000012D434: D8DC6D6C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:110 offset1:111    // 00000012D43C: D8DC6F6E 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:44 offset1:61      // 00000012D444: D8DC3D2C 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:78 offset1:95      // 00000012D44C: D8DC5F4E 4A000039
	s_waitcnt lgkmcnt(6)                                       // 00000012D454: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000012D458: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D45C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000012D460: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000012D464: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012D468: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D46C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000012D470: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000012D474: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000012D478: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D47C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000012D480: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000012D484: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000012D488: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012D48C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000012D490: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:112 offset1:113    // 00000012D494: D8DC7170 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:112 offset1:129    // 00000012D49C: D8DC8170 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:114 offset1:115    // 00000012D4A4: D8DC7372 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:146 offset1:163    // 00000012D4AC: D8DCA392 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:116 offset1:117    // 00000012D4B4: D8DC7574 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:118 offset1:119    // 00000012D4BC: D8DC7776 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 00000012D4C4: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 00000012D4CC: D8DCE7D6 4A000039
	s_waitcnt lgkmcnt(6)                                       // 00000012D4D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000012D4D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D4DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 00000012D4E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 00000012D4E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012D4E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D4EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 00000012D4F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 00000012D4F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 00000012D4F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D4FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 00000012D500: 56989345
	s_waitcnt lgkmcnt(0)                                       // 00000012D504: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 00000012D508: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012D50C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 00000012D510: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 00000012D514: D8DC7978 3C00002E
	ds_load_2addr_b32 v[62:63], v58 offset0:120 offset1:137    // 00000012D51C: D8DC8978 3E00003A
	ds_load_2addr_b32 v[64:65], v46 offset0:122 offset1:123    // 00000012D524: D8DC7B7A 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:26 offset1:43      // 00000012D52C: D8DC2B1A 4200003B
	ds_load_2addr_b32 v[68:69], v46 offset0:124 offset1:125    // 00000012D534: D8DC7D7C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:126 offset1:127    // 00000012D53C: D8DC7F7E 4600002E
	ds_load_2addr_b32 v[72:73], v59 offset0:60 offset1:77      // 00000012D544: D8DC4D3C 4800003B
	ds_load_2addr_b32 v[74:75], v59 offset0:94 offset1:111     // 00000012D54C: D8DC6F5E 4A00003B
	v_lshlrev_b32_e32 v33, 2, v33                              // 00000012D554: 30424282
	s_waitcnt lgkmcnt(6)                                       // 00000012D558: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000012D55C: 56987D3C
	ds_load_b32 v60, v33 offset:17440                          // 00000012D560: D8D84420 3C000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 00000012D568: CA10011E 2220011D
	v_mov_b32_e32 v62, v35                                     // 00000012D570: 7E7C0323
	v_fmac_f32_e32 v76, v61, v63                               // 00000012D574: 56987F3D
	v_mov_b32_e32 v61, v1                                      // 00000012D578: 7E7A0301
	s_waitcnt lgkmcnt(5)                                       // 00000012D57C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D580: BF870092
	v_fmac_f32_e32 v76, v64, v66                               // 00000012D584: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 00000012D588: 56988741
	s_waitcnt lgkmcnt(2)                                       // 00000012D58C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D590: BF870091
	v_fmac_f32_e32 v76, v68, v72                               // 00000012D594: 56989144
	v_fmac_f32_e32 v76, v69, v73                               // 00000012D598: 56989345
	s_waitcnt lgkmcnt(1)                                       // 00000012D59C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D5A0: BF870091
	v_fmac_f32_e32 v76, v70, v74                               // 00000012D5A4: 56989546
	v_fmac_f32_e32 v76, v71, v75                               // 00000012D5A8: 56989747
	s_waitcnt lgkmcnt(0)                                       // 00000012D5AC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012D5B0: BF870001
	v_mul_f32_e32 v60, v76, v60                                // 00000012D5B4: 1078794C
	s_nop 0                                                    // 00000012D5B8: BF800000
	s_nop 0                                                    // 00000012D5BC: BF800000
	global_load_b32 v63, v[33:34], off                         // 00000012D5C0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 00000012D5C8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 00000012D5D0: 4A7C7CC1
	.long 0xd7000121                                           // 00000012D5D4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 00000012D5D8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012D5DC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 00000012D5E0: D5207C22 00064480
	.long 0xd44a0004                                           // 00000012D5E8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 00000012D5EC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 00000012D5F0: 4A7A7AFF 00000044
	s_or_b32 s12, s4, s12                                      // 00000012D5F8: 8C0C0C04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012D5FC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 00000012D600: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 00000012D604: 917E0C7E
	s_cbranch_execnz 65517                                     // 00000012D608: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19c0>
	s_or_b32 exec_lo, exec_lo, s12                             // 00000012D60C: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012D610: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 00000012D614: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 00000012D61C: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 00000012D628: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 00000012D634: DC960000 007C2421
	s_branch 64917                                             // 00000012D63C: BFA0FD95 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 00000012D640: A201FF06 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 00000012D648: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000012D64C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 00000012D650: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 00000012D658: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 00000012D65C: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 00000012D664: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 00000012D66C: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000012D670: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 00000012D674: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 00000012D67C: A0010401
	s_mov_b32 s4, 0                                            // 00000012D680: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 00000012D684: BF87000A
	v_exp_f32_e32 v29, s1                                      // 00000012D688: 7E3A4A01
	s_cvt_i32_f32 s1, s7                                       // 00000012D68C: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 00000012D690: BF870585
	.long 0xd71c001d                                           // 00000012D694: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 00000012D698: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 00000012D69C: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 00000012D6A0: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000012D6A8: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 00000012D6AC: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 00000012D6B4: 980180C1
	v_mov_b32_e32 v29, v37                                     // 00000012D6B8: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 00000012D6BC: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 00000012D6C8: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 00000012D6D0: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012D6D8: BF870001
	.long 0xd4490001                                           // 00000012D6DC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 00000012D6E0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 00000012D6E8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 00000012D6EC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 00000012D6F0: 1040411E
	ds_store_b32 v29, v32                                      // 00000012D6F4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 00000012D6FC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012D704: 917E047E
	s_cbranch_execnz 65519                                     // 00000012D708: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ac8>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012D70C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 00000012D710: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 00000012D718: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 00000012D720: 7E420326
	s_mov_b32 s6, 0                                            // 00000012D724: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000012D728: BF89FC07
	s_barrier                                                  // 00000012D72C: BFBD0000
	buffer_gl0_inv                                             // 00000012D730: E0AC0000 00000000
	s_nop 0                                                    // 00000012D738: BF800000
	s_nop 0                                                    // 00000012D73C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000012D740: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 00000012D748: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000012D750: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000012D758: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012D75C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 00000012D764: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012D768: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000012D770: BF870004
	.long 0xd4490004                                           // 00000012D774: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012D778: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000012D780: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012D784: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000012D788: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 00000012D78C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 00000012D794: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012D79C: 917E067E
	s_cbranch_execnz 65511                                     // 00000012D7A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b40>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012D7A4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000012D7A8: BF89FC07
	s_barrier                                                  // 00000012D7AC: BFBD0000
	buffer_gl0_inv                                             // 00000012D7B0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 00000012D7B8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 00000012D7C0: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 00000012D7C8: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 00000012D7D0: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 00000012D7D8: 7E780300
	s_mov_b32 s4, 0                                            // 00000012D7DC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000012D7E0: BF840001
	s_nop 0                                                    // 00000012D7E4: BF800000
	s_nop 0                                                    // 00000012D7E8: BF800000
	s_nop 0                                                    // 00000012D7EC: BF800000
	s_nop 0                                                    // 00000012D7F0: BF800000
	s_nop 0                                                    // 00000012D7F4: BF800000
	s_nop 0                                                    // 00000012D7F8: BF800000
	s_nop 0                                                    // 00000012D7FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012D800: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000012D804: 327A7884
	.long 0xd4490001                                           // 00000012D808: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012D80C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000012D814: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000012D818: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000012D824: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000012D828: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000012D830: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000012D838: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000012D840: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000012D848: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000012D850: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000012D858: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000012D860: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000012D864: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012D870: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000012D874: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000012D878: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000012D880: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000012D884: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000012D888: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000012D88C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D890: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000012D894: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000012D898: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000012D89C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D8A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000012D8A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000012D8B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000012D8B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012D8C0: 917E047E
	s_cbranch_execnz 65486                                     // 00000012D8C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c00>
	s_set_inst_prefetch_distance 0x2                           // 00000012D8C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012D8CC: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 00000012D8D0: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000012D8D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012D8E0: 7E420326
	s_mov_b32 s6, 0                                            // 00000012D8E4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000012D8E8: BF89FC07
	s_barrier                                                  // 00000012D8EC: BFBD0000
	buffer_gl0_inv                                             // 00000012D8F0: E0AC0000 00000000
	s_nop 0                                                    // 00000012D8F8: BF800000
	s_nop 0                                                    // 00000012D8FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000012D900: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 00000012D908: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000012D910: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000012D918: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012D91C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000012D924: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012D928: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000012D930: BF870004
	.long 0xd4490004                                           // 00000012D934: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012D938: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000012D940: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012D944: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000012D948: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000012D94C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012D954: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012D95C: 917E067E
	s_cbranch_execnz 65511                                     // 00000012D960: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d00>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012D964: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000012D968: BF89FC07
	s_barrier                                                  // 00000012D96C: BFBD0000
	buffer_gl0_inv                                             // 00000012D970: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 00000012D978: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 00000012D980: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 00000012D988: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 00000012D990: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 00000012D998: 7E780300
	s_mov_b32 s4, 0                                            // 00000012D99C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000012D9A0: BF840001
	s_nop 0                                                    // 00000012D9A4: BF800000
	s_nop 0                                                    // 00000012D9A8: BF800000
	s_nop 0                                                    // 00000012D9AC: BF800000
	s_nop 0                                                    // 00000012D9B0: BF800000
	s_nop 0                                                    // 00000012D9B4: BF800000
	s_nop 0                                                    // 00000012D9B8: BF800000
	s_nop 0                                                    // 00000012D9BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012D9C0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000012D9C4: 327A7884
	.long 0xd4490001                                           // 00000012D9C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012D9CC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000012D9D4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000012D9D8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000012D9E4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000012D9E8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000012D9F0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000012D9F8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000012DA00: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000012DA08: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000012DA10: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000012DA18: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000012DA20: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000012DA24: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012DA30: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000012DA34: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000012DA38: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000012DA40: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000012DA44: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000012DA48: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000012DA4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DA50: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000012DA54: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000012DA58: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000012DA5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DA60: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000012DA64: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000012DA70: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000012DA78: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012DA80: 917E047E
	s_cbranch_execnz 65486                                     // 00000012DA84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dc0>
	s_set_inst_prefetch_distance 0x2                           // 00000012DA88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012DA8C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 00000012DA90: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000012DA98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012DAA0: 7E420326
	s_mov_b32 s6, 0                                            // 00000012DAA4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000012DAA8: BF89FC07
	s_barrier                                                  // 00000012DAAC: BFBD0000
	buffer_gl0_inv                                             // 00000012DAB0: E0AC0000 00000000
	s_nop 0                                                    // 00000012DAB8: BF800000
	s_nop 0                                                    // 00000012DABC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000012DAC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 00000012DAC8: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000012DAD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000012DAD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012DADC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000012DAE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012DAE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000012DAF0: BF870004
	.long 0xd4490004                                           // 00000012DAF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012DAF8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000012DB00: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012DB04: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000012DB08: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000012DB0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012DB14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012DB1C: 917E067E
	s_cbranch_execnz 65511                                     // 00000012DB20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ec0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012DB24: 8C7E067E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 00000012DB28: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 00000012DB30: BF89FC07
	s_barrier                                                  // 00000012DB34: BFBD0000
	buffer_gl0_inv                                             // 00000012DB38: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 00000012DB40: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 00000012DB44: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 00000012DB4C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 00000012DB54: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 00000012DB5C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 00000012DB64: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000012DB68: BF840001
	s_nop 0                                                    // 00000012DB6C: BF800000
	s_nop 0                                                    // 00000012DB70: BF800000
	s_nop 0                                                    // 00000012DB74: BF800000
	s_nop 0                                                    // 00000012DB78: BF800000
	s_nop 0                                                    // 00000012DB7C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 00000012DB80: 327C7A84
	.long 0xd4490001                                           // 00000012DB84: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000012DB88: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000012DB90: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000012DB94: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000012DB98: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000012DBA4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000012DBA8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000012DBB0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000012DBB8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000012DBC0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000012DBC8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000012DBD0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000012DBD8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000012DBE0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000012DBE4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012DBE8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000012DBEC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000012DBF8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000012DC00: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000012DC04: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000012DC08: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000012DC0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DC10: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000012DC14: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000012DC18: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000012DC1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DC20: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 00000012DC24: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 00000012DC30: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 00000012DC38: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012DC40: 917E047E
	s_cbranch_execnz 65486                                     // 00000012DC44: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f80>
	s_set_inst_prefetch_distance 0x2                           // 00000012DC48: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012DC4C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 00000012DC50: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000012DC58: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012DC60: 7E420326
	s_mov_b32 s6, 0                                            // 00000012DC64: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000012DC68: BF89FC07
	s_barrier                                                  // 00000012DC6C: BFBD0000
	buffer_gl0_inv                                             // 00000012DC70: E0AC0000 00000000
	s_nop 0                                                    // 00000012DC78: BF800000
	s_nop 0                                                    // 00000012DC7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000012DC80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 00000012DC88: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000012DC90: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000012DC98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012DC9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000012DCA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012DCA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000012DCB0: BF870004
	.long 0xd4490004                                           // 00000012DCB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012DCB8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000012DCC0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012DCC4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000012DCC8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000012DCCC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012DCD4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012DCDC: 917E067E
	s_cbranch_execnz 65511                                     // 00000012DCE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2080>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012DCE4: 8C7E067E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 00000012DCE8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 00000012DCF0: BF89FC07
	s_barrier                                                  // 00000012DCF4: BFBD0000
	buffer_gl0_inv                                             // 00000012DCF8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 00000012DD00: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 00000012DD08: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 00000012DD10: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 00000012DD18: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 00000012DD20: 7E780300
	s_mov_b32 s4, 0                                            // 00000012DD24: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000012DD28: BF840001
	s_nop 0                                                    // 00000012DD2C: BF800000
	s_nop 0                                                    // 00000012DD30: BF800000
	s_nop 0                                                    // 00000012DD34: BF800000
	s_nop 0                                                    // 00000012DD38: BF800000
	s_nop 0                                                    // 00000012DD3C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012DD40: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000012DD44: 327A7884
	.long 0xd4490001                                           // 00000012DD48: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012DD4C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000012DD54: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000012DD58: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000012DD64: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000012DD68: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000012DD70: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000012DD78: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000012DD80: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000012DD88: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000012DD90: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000012DD98: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000012DDA0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000012DDA4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012DDB0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000012DDB4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000012DDB8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000012DDC0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000012DDC4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000012DDC8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000012DDCC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DDD0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000012DDD4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000012DDD8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000012DDDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DDE0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000012DDE4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000012DDF0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000012DDF8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012DE00: 917E047E
	s_cbranch_execnz 65486                                     // 00000012DE04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2140>
	s_set_inst_prefetch_distance 0x2                           // 00000012DE08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012DE0C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 00000012DE10: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000012DE18: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012DE20: 7E420326
	s_mov_b32 s6, 0                                            // 00000012DE24: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000012DE28: BF89FC07
	s_barrier                                                  // 00000012DE2C: BFBD0000
	buffer_gl0_inv                                             // 00000012DE30: E0AC0000 00000000
	s_nop 0                                                    // 00000012DE38: BF800000
	s_nop 0                                                    // 00000012DE3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000012DE40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 00000012DE48: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000012DE50: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000012DE58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012DE5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000012DE64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012DE68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000012DE70: BF870004
	.long 0xd4490004                                           // 00000012DE74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012DE78: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000012DE80: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012DE84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000012DE88: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000012DE8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012DE94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012DE9C: 917E067E
	s_cbranch_execnz 65511                                     // 00000012DEA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2240>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012DEA4: 8C7E067E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 00000012DEA8: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 00000012DEB0: BF89FC07
	s_barrier                                                  // 00000012DEB4: BFBD0000
	buffer_gl0_inv                                             // 00000012DEB8: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 00000012DEC0: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 00000012DEC4: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 00000012DECC: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 00000012DED4: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 00000012DEDC: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 00000012DEE4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000012DEE8: BF840001
	s_nop 0                                                    // 00000012DEEC: BF800000
	s_nop 0                                                    // 00000012DEF0: BF800000
	s_nop 0                                                    // 00000012DEF4: BF800000
	s_nop 0                                                    // 00000012DEF8: BF800000
	s_nop 0                                                    // 00000012DEFC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 00000012DF00: 327C7884
	.long 0xd4490001                                           // 00000012DF04: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012DF08: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000012DF10: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000012DF14: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000012DF18: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000012DF24: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000012DF28: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000012DF30: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000012DF38: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000012DF40: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000012DF48: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000012DF50: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000012DF58: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000012DF60: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000012DF64: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012DF68: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000012DF6C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000012DF78: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000012DF80: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000012DF84: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000012DF88: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000012DF8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DF90: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000012DF94: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000012DF98: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000012DF9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DFA0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 00000012DFA4: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 00000012DFB0: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 00000012DFB4: BF870002
	v_mov_b32_e32 v60, v63                                     // 00000012DFB8: 7E78033F
	ds_store_b32 v62, v70                                      // 00000012DFBC: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012DFC4: 917E047E
	s_cbranch_execnz 65485                                     // 00000012DFC8: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2300>
	s_set_inst_prefetch_distance 0x2                           // 00000012DFCC: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012DFD0: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 00000012DFD4: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000012DFDC: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012DFE4: 7E420326
	s_mov_b32 s6, 0                                            // 00000012DFE8: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000012DFEC: BF89FC07
	s_barrier                                                  // 00000012DFF0: BFBD0000
	buffer_gl0_inv                                             // 00000012DFF4: E0AC0000 00000000
	s_nop 0                                                    // 00000012DFFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000012E000: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 00000012E008: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000012E010: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000012E018: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012E01C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000012E024: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012E028: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000012E030: BF870004
	.long 0xd4490004                                           // 00000012E034: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012E038: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000012E040: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012E044: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000012E048: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000012E04C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012E054: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012E05C: 917E067E
	s_cbranch_execnz 65511                                     // 00000012E060: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2400>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012E064: 8C7E067E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 00000012E068: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 00000012E070: BF89FC07
	s_barrier                                                  // 00000012E074: BFBD0000
	buffer_gl0_inv                                             // 00000012E078: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 00000012E080: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 00000012E088: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 00000012E090: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 00000012E098: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 00000012E0A0: 7E7A0300
	s_mov_b32 s4, 0                                            // 00000012E0A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000012E0A8: BF840001
	s_nop 0                                                    // 00000012E0AC: BF800000
	s_nop 0                                                    // 00000012E0B0: BF800000
	s_nop 0                                                    // 00000012E0B4: BF800000
	s_nop 0                                                    // 00000012E0B8: BF800000
	s_nop 0                                                    // 00000012E0BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012E0C0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 00000012E0C4: 327C7A84
	.long 0xd4490001                                           // 00000012E0C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000012E0CC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000012E0D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000012E0D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000012E0E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000012E0E8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000012E0F0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000012E0F8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000012E100: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000012E108: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000012E110: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000012E118: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000012E120: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000012E124: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012E128: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000012E12C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000012E138: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000012E140: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000012E144: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000012E148: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000012E14C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E150: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000012E154: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000012E158: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000012E15C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E160: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 00000012E164: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 00000012E170: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 00000012E178: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012E180: 917E047E
	s_cbranch_execnz 65486                                     // 00000012E184: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x24c0>
	s_set_inst_prefetch_distance 0x2                           // 00000012E188: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012E18C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 00000012E190: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000012E198: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012E1A0: 7E420326
	s_mov_b32 s6, 0                                            // 00000012E1A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000012E1A8: BF89FC07
	s_barrier                                                  // 00000012E1AC: BFBD0000
	buffer_gl0_inv                                             // 00000012E1B0: E0AC0000 00000000
	s_nop 0                                                    // 00000012E1B8: BF800000
	s_nop 0                                                    // 00000012E1BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000012E1C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 00000012E1C8: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000012E1D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000012E1D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012E1DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000012E1E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012E1E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000012E1F0: BF870004
	.long 0xd4490004                                           // 00000012E1F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012E1F8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000012E200: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012E204: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000012E208: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000012E20C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012E214: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012E21C: 917E067E
	s_cbranch_execnz 65511                                     // 00000012E220: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012E224: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000012E228: BF89FC07
	s_barrier                                                  // 00000012E22C: BFBD0000
	buffer_gl0_inv                                             // 00000012E230: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 00000012E238: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 00000012E240: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 00000012E248: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 00000012E250: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 00000012E258: 7E7A0300
	s_mov_b32 s4, 0                                            // 00000012E25C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000012E260: BF840001
	s_nop 0                                                    // 00000012E264: BF800000
	s_nop 0                                                    // 00000012E268: BF800000
	s_nop 0                                                    // 00000012E26C: BF800000
	s_nop 0                                                    // 00000012E270: BF800000
	s_nop 0                                                    // 00000012E274: BF800000
	s_nop 0                                                    // 00000012E278: BF800000
	s_nop 0                                                    // 00000012E27C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012E280: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 00000012E284: 327C7A84
	.long 0xd4490001                                           // 00000012E288: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000012E28C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 00000012E294: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 00000012E298: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000012E2A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 00000012E2A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 00000012E2B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 00000012E2B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 00000012E2C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 00000012E2C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 00000012E2D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 00000012E2D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 00000012E2E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 00000012E2E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012E2E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000012E2EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 00000012E2F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 00000012E300: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 00000012E304: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 00000012E308: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000012E30C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E310: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 00000012E314: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 00000012E318: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000012E31C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E320: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 00000012E324: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 00000012E330: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 00000012E338: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012E340: 917E047E
	s_cbranch_execnz 65486                                     // 00000012E344: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2680>
	s_set_inst_prefetch_distance 0x2                           // 00000012E348: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012E34C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 00000012E350: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 00000012E358: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012E360: 7E420326
	s_mov_b32 s6, 0                                            // 00000012E364: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000012E368: BF89FC07
	s_barrier                                                  // 00000012E36C: BFBD0000
	buffer_gl0_inv                                             // 00000012E370: E0AC0000 00000000
	s_nop 0                                                    // 00000012E378: BF800000
	s_nop 0                                                    // 00000012E37C: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000012E380: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 00000012E388: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000012E390: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000012E398: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012E39C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000012E3A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012E3A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000012E3B0: BF870004
	.long 0xd4490004                                           // 00000012E3B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012E3B8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000012E3C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012E3C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000012E3C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000012E3CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012E3D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012E3DC: 917E067E
	s_cbranch_execnz 65511                                     // 00000012E3E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2780>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012E3E4: 8C7E067E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 00000012E3E8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 00000012E3F0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 00000012E3F8: BF89FC07
	s_barrier                                                  // 00000012E3FC: BFBD0000
	buffer_gl0_inv                                             // 00000012E400: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 00000012E408: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 00000012E410: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 00000012E418: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 00000012E420: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 00000012E428: 7E780300
	s_mov_b32 s4, 0                                            // 00000012E42C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000012E430: BF840001
	s_nop 0                                                    // 00000012E434: BF800000
	s_nop 0                                                    // 00000012E438: BF800000
	s_nop 0                                                    // 00000012E43C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012E440: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000012E444: 327A7884
	.long 0xd4490001                                           // 00000012E448: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012E44C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000012E454: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000012E458: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000012E464: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000012E468: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000012E470: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000012E478: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000012E480: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000012E488: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000012E490: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000012E498: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000012E4A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000012E4A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012E4B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000012E4B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000012E4B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000012E4C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000012E4C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000012E4C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000012E4CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E4D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000012E4D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000012E4D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000012E4DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E4E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000012E4E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000012E4F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000012E4F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012E500: 917E047E
	s_cbranch_execnz 65486                                     // 00000012E504: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2840>
	s_set_inst_prefetch_distance 0x2                           // 00000012E508: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012E50C: 8C7E047E
	.long 0xd7000107                                           // 00000012E510: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 00000012E514: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012E51C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 00000012E520: D5207C08 00061080
	.long 0xd7000109                                           // 00000012E528: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 00000012E52C: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 00000012E534: D5207C0A 00061480
	.long 0xd700010d                                           // 00000012E53C: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 00000012E540: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012E548: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 00000012E54C: D5207C0E 00061C80
	.long 0xd700010b                                           // 00000012E554: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 00000012E558: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 00000012E560: D5207C0C 00061880
	.long 0xd700010f                                           // 00000012E568: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 00000012E56C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012E574: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 00000012E578: D5207C10 00062080
	.long 0xd7000111                                           // 00000012E580: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 00000012E584: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 00000012E58C: D5207C12 00062480
	.long 0xd7000113                                           // 00000012E594: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 00000012E598: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012E5A0: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 00000012E5A4: D5207C14 00062880
	.long 0xd7000115                                           // 00000012E5AC: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 00000012E5B0: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 00000012E5B8: D5207C16 00062C80
	.long 0xd7000117                                           // 00000012E5C0: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 00000012E5C4: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012E5CC: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 00000012E5D0: D5207C18 00063080
	.long 0xd7000119                                           // 00000012E5D8: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 00000012E5DC: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 00000012E5E4: D5207C1A 00063480
	.long 0xd700011b                                           // 00000012E5EC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 00000012E5F0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012E5F8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 00000012E5FC: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 00000012E604: 81058105
	s_waitcnt lgkmcnt(0)                                       // 00000012E608: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 00000012E60C: BF062105
	s_barrier                                                  // 00000012E610: BFBD0000
	buffer_gl0_inv                                             // 00000012E614: E0AC0000 00000000
	s_cbranch_scc0 63073                                       // 00000012E61C: BFA1F661 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a4>
	v_mov_b32_e32 v4, v38                                      // 00000012E620: 7E080326
	s_add_u32 s0, s28, s20                                     // 00000012E624: 8000141C
	.long 0xd73c0000                                           // 00000012E628: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000012E62C: 02020489
	s_addc_u32 s1, s29, s21                                    // 00000012E630: 8201151D
	s_add_u32 s2, s24, s18                                     // 00000012E634: 80021218
	s_addc_u32 s3, s25, s19                                    // 00000012E638: 82031319
	s_add_u32 s0, s2, s0                                       // 00000012E63C: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000012E640: 82010103
	.long 0xd7006a00                                           // 00000012E644: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000012E648: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000012E64C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000012E650: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 00000012E658: BE810080
	.long 0xd7006a00                                           // 00000012E65C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 00000012E660: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000012E664: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E66C: BF870092
	.long 0xd7006a00                                           // 00000012E670: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000012E674: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000012E678: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 00000012E680: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 00000012E688: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 00000012E690: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000012E698: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000012E69C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 00000012E6A4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000012E6A8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 00000012E6AC: DC6A0000 007C0200
	.long 0xd7000000                                           // 00000012E6B4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 00000012E6B8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000012E6C0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000012E6C8: 917E017E
	s_cbranch_execnz 65516                                     // 00000012E6CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a80>
	s_endpgm                                                   // 00000012E6D0: BFB00000
		...

