0000000000048900 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 000000048900: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 000000048904: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 00000004890C: F4080500 F8000050
	v_and_b32_e32 v131, 31, v0                                 // 000000048914: 3706009F
	v_lshrrev_b32_e32 v156, 5, v0                              // 000000048918: 33380085
	s_mov_b32 s24, s3                                          // 00000004891C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000048920: BF870112
	.long 0xd44c0003                                           // 000000048924: D44C0003
	v_cndmask_b32_e32 v1, 16, v131, vcc_lo                     // 000000048928: 02030690
	v_lshlrev_b32_e32 v132, 6, v156                            // 00000004892C: 31093886
	s_waitcnt lgkmcnt(0)                                       // 000000048930: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 000000048934: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 00000004893C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 000000048940: BF870001
	v_lshl_add_u32 v1, v131, 2, v132                           // 000000048944: D6460001 06110583
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 00000004894C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:156 offset1:162// 000000048958: D83CA29C 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 000000048960: 8C7E047E
	v_mul_u32_u24_e32 v1, 0xab, v0                             // 000000048964: 160200FF 000000AB
	.long 0x7f043880                                           // 00000004896C: 7F043880
	v_dual_mov_b32 v141, 0 :: v_dual_and_b32 v154, 15, v0      // 000000048970: CA240080 8D9A008F
	s_cmp_eq_u64 s[14:15], 0                                   // 000000048978: BF10800E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000004897C: BF8704B3
	.long 0x7e043981                                           // 000000048980: 7E043981
	v_mov_b32_e32 v142, 0                                      // 000000048984: 7F1C0280
	s_cselect_b32 s25, -1, 0                                   // 000000048988: 981980C1
	s_and_b32 vcc_lo, exec_lo, s25                             // 00000004898C: 8B6A197E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048990: BF870092
	v_add_lshl_u32 v155, s2, v2, 4                             // 000000048994: D647009B 02120402
	v_or_b32_e32 v129, v155, v154                              // 00000004899C: 3903359B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000489A0: BF870001
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000000489A4: 3505029F
	s_cbranch_vccnz 10                                         // 0000000489A8: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xd4>
	v_mad_i64_i32 v[1:2], null, s23, v129, 0                   // 0000000489AC: D6FF7C01 02030217
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000489B4: BF870091
	.long 0xd73c0001                                           // 0000000489B8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000000489BC: 02020282
	.long 0xd7006a8d                                           // 0000000489C0: D7006A8D
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000000489C4: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000489C8: BF870001
	v_add_co_ci_u32_e64 v142, null, s15, v2, vcc_lo            // 0000000489CC: D5207C8E 01AA040F
	s_clause 0x2                                               // 0000000489D4: BF850002
	s_load_b64 s[14:15], s[0:1], 0x38                          // 0000000489D8: F4040380 F8000038
	s_load_b128 s[16:19], s[0:1], 0x20                         // 0000000489E0: F4080400 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 0000000489E8: F40C0100 F8000000
	v_mov_b32_e32 v158, 0                                      // 0000000489F0: 7F3C0280
	s_xor_b32 s0, s25, -1                                      // 0000000489F4: 8D00C119
	s_waitcnt lgkmcnt(0)                                       // 0000000489F8: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v129                         // 0000000489FC: 7C89020E
	s_and_b32 s23, s0, vcc_lo                                  // 000000048A00: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000048A04: BF870009
	s_and_saveexec_b32 s0, s23                                 // 000000048A08: BE802017
	s_cbranch_execz 9                                          // 000000048A0C: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x134>
	.long 0xd73c0001                                           // 000000048A10: D73C0001
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 000000048A14: 02030282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048A18: BF870091
	.long 0xd7006a01                                           // 000000048A1C: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 000000048A20: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 000000048A24: D5207C02 01AA0415
	global_load_b32 v158, v[1:2], off                          // 000000048A2C: DC520000 9E7C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 000000048A34: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 000000048A38: BF10800C
	s_mov_b64 s[20:21], 0                                      // 000000048A3C: BE940180
	s_cbranch_scc1 10                                          // 000000048A40: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c>
	s_ashr_i32 s0, s22, 31                                     // 000000048A44: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 000000048A48: 96810216
	s_mul_i32 s0, s0, s2                                       // 000000048A4C: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000048A50: BF8704A9
	s_add_i32 s1, s1, s0                                       // 000000048A54: 81010001
	s_mul_i32 s0, s22, s2                                      // 000000048A58: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 000000048A5C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000048A60: BF870009
	s_add_u32 s20, s12, s0                                     // 000000048A64: 8014000C
	s_addc_u32 s21, s13, s1                                    // 000000048A68: 8215010D
	.long 0xd7050001                                           // 000000048A6C: D7050001
	v_cndmask_b32_e32 v0, v156, v150, vcc_lo                   // 000000048A70: 02012D9C
	s_lshl_b32 s0, s2, 4                                       // 000000048A74: 84008402
	s_add_i32 s1, s14, -1                                      // 000000048A78: 8101C10E
	s_or_b32 s0, s0, 15                                        // 000000048A7C: 8C008F00
	v_lshrrev_b32_e32 v157, 4, v131                            // 000000048A80: 333B0684
	.long 0xd7390001                                           // 000000048A84: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 000000048A88: 02020288
	s_min_i32 s0, s0, s1                                       // 000000048A8C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000048A90: BF870499
	s_add_i32 s0, s26, s0                                      // 000000048A94: 8100001A
	s_cmp_lt_i32 s0, -15                                       // 000000048A98: BF04CF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048A9C: BF870091
	.long 0xd7050001                                           // 000000048AA0: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 000000048AA4: 02011901
	.long 0xd7040001                                           // 000000048AA8: D7040001
	v_cndmask_b32_e32 v1, v156, v1, vcc_lo                     // 000000048AAC: 0202039C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000048AB0: BF870091
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 000000048AB4: CA240080 480002FF 000000FF
	v_mov_b32_e32 v71, v72                                     // 000000048AC0: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 000000048AC4: 7E8A0348
	v_mov_b32_e32 v68, v72                                     // 000000048AC8: 7E880348
	v_mov_b32_e32 v67, v72                                     // 000000048ACC: 7E860348
	v_mad_u64_u32 v[138:139], null, s24, 12, v[1:2]            // 000000048AD0: D6FE7C8A 04051818
	v_mov_b32_e32 v70, v72                                     // 000000048AD8: 7E8C0348
	v_mov_b32_e32 v66, v72                                     // 000000048ADC: 7E840348
	v_mov_b32_e32 v65, v72                                     // 000000048AE0: 7E820348
	v_mov_b32_e32 v80, v72                                     // 000000048AE4: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 000000048AE8: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 000000048AEC: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 000000048AF0: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 000000048AF4: CA220148 4C011488
	v_mov_b32_e32 v75, v72                                     // 000000048AFC: 7E960348
	v_mov_b32_e32 v74, v72                                     // 000000048B00: 7E940348
	v_mov_b32_e32 v73, v72                                     // 000000048B04: 7E920348
	s_delay_alu instid0(VALU_DEP_4)                            // 000000048B08: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000048B0C: 3404029F
	v_mov_b32_e32 v88, v72                                     // 000000048B10: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 000000048B14: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 000000048B18: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 000000048B1C: 7EAA0348
	.long 0xd73c008b                                           // 000000048B20: D73C008B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000048B24: 02020281
	v_mov_b32_e32 v84, v72                                     // 000000048B28: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 000000048B2C: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 000000048B30: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 000000048B34: 7EA20348
	v_mov_b32_e32 v96, v72                                     // 000000048B38: 7EC00348
	v_mov_b32_e32 v95, v72                                     // 000000048B3C: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 000000048B40: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 000000048B44: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 000000048B48: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 000000048B4C: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 000000048B50: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 000000048B54: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 000000048B58: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 000000048B5C: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 000000048B60: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 000000048B64: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 000000048B68: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 000000048B6C: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 000000048B70: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 000000048B74: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 000000048B78: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 000000048B7C: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 000000048B80: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 000000048B84: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 000000048B88: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 000000048B8C: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 000000048B90: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 000000048B94: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 000000048B98: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 000000048B9C: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 000000048BA0: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 000000048BA4: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 000000048BA8: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 000000048BAC: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 000000048BB0: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 000000048BB4: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 000000048BB8: 7F000348
	v_mov_b32_e32 v127, v72                                    // 000000048BBC: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 000000048BC0: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 000000048BC4: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 000000048BC8: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 000000048BCC: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 000000048BD0: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 000000048BD4: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 000000048BD8: 7E800348
	v_mov_b32_e32 v63, v72                                     // 000000048BDC: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 000000048BE0: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 000000048BE4: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 000000048BE8: 7E780348
	v_mov_b32_e32 v59, v72                                     // 000000048BEC: 7E760348
	v_mov_b32_e32 v58, v72                                     // 000000048BF0: 7E740348
	v_mov_b32_e32 v57, v72                                     // 000000048BF4: 7E720348
	v_mov_b32_e32 v56, v72                                     // 000000048BF8: 7E700348
	v_mov_b32_e32 v55, v72                                     // 000000048BFC: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 000000048C00: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 000000048C04: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 000000048C08: 7E680348
	v_mov_b32_e32 v51, v72                                     // 000000048C0C: 7E660348
	v_mov_b32_e32 v50, v72                                     // 000000048C10: 7E640348
	v_mov_b32_e32 v49, v72                                     // 000000048C14: 7E620348
	v_mov_b32_e32 v48, v72                                     // 000000048C18: 7E600348
	v_mov_b32_e32 v47, v72                                     // 000000048C1C: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 000000048C20: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 000000048C24: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 000000048C28: 7E580348
	v_mov_b32_e32 v43, v72                                     // 000000048C2C: 7E560348
	v_mov_b32_e32 v42, v72                                     // 000000048C30: 7E540348
	v_mov_b32_e32 v41, v72                                     // 000000048C34: 7E520348
	v_mov_b32_e32 v40, v72                                     // 000000048C38: 7E500348
	v_mov_b32_e32 v39, v72                                     // 000000048C3C: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 000000048C40: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 000000048C44: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 000000048C48: 7E480348
	v_mov_b32_e32 v35, v72                                     // 000000048C4C: 7E460348
	v_mov_b32_e32 v34, v72                                     // 000000048C50: 7E440348
	v_mov_b32_e32 v33, v72                                     // 000000048C54: 7E420348
	v_mov_b32_e32 v32, v72                                     // 000000048C58: 7E400348
	v_mov_b32_e32 v31, v72                                     // 000000048C5C: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 000000048C60: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 000000048C64: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 000000048C68: 7E380348
	v_mov_b32_e32 v27, v72                                     // 000000048C6C: 7E360348
	v_mov_b32_e32 v26, v72                                     // 000000048C70: 7E340348
	v_mov_b32_e32 v25, v72                                     // 000000048C74: 7E320348
	v_mov_b32_e32 v24, v72                                     // 000000048C78: 7E300348
	v_mov_b32_e32 v23, v72                                     // 000000048C7C: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 000000048C80: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 000000048C84: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 000000048C88: 7E280348
	v_mov_b32_e32 v19, v72                                     // 000000048C8C: 7E260348
	v_mov_b32_e32 v18, v72                                     // 000000048C90: 7E240348
	v_mov_b32_e32 v17, v72                                     // 000000048C94: 7E220348
	v_mov_b32_e32 v16, v72                                     // 000000048C98: 7E200348
	v_mov_b32_e32 v15, v72                                     // 000000048C9C: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 000000048CA0: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 000000048CA4: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 000000048CA8: 7E180348
	v_mov_b32_e32 v11, v72                                     // 000000048CAC: 7E160348
	v_mov_b32_e32 v10, v72                                     // 000000048CB0: 7E140348
	v_mov_b32_e32 v9, v72                                      // 000000048CB4: 7E120348
	v_mov_b32_e32 v8, v72                                      // 000000048CB8: 7E100348
	v_mov_b32_e32 v7, v72                                      // 000000048CBC: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 000000048CC0: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 000000048CC4: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 000000048CC8: 7E080348
	v_mov_b32_e32 v3, v72                                      // 000000048CCC: 7E060348
	v_mov_b32_e32 v2, v72                                      // 000000048CD0: 7E040348
	v_mov_b32_e32 v1, v72                                      // 000000048CD4: 7E020348
	s_cbranch_scc1 2920                                        // 000000048CD8: BFA20B68 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x317c>
	v_mad_i64_i32 v[1:2], null, 0x3000, v129, s[4:5]           // 000000048CDC: D6FF7C01 001302FF 00003000
	s_ashr_i32 s1, s0, 31                                      // 000000048CE8: 86019F00
	v_lshlrev_b32_e32 v4, 2, v131                              // 000000048CEC: 30090682
	s_lshr_b32 s1, s1, 28                                      // 000000048CF0: 85019C01
	v_add_nc_u32_e32 v160, s26, v155                           // 000000048CF4: 4B41361A
	s_add_i32 s0, s0, s1                                       // 000000048CF8: 81000100
	s_movk_i32 s1, 0x440                                       // 000000048CFC: B0010440
	s_ashr_i32 s12, s0, 4                                      // 000000048D00: 860C8400
	.long 0xd7006a8f                                           // 000000048D04: D7006A8F
	v_cndmask_b32_e32 v1, v1, v139, vcc_lo                     // 000000048D08: 02031701
	v_add3_u32 v1, v129, s26, 1                                // 000000048D0C: D6550001 02043581
	v_add_co_ci_u32_e64 v144, null, v2, v140, vcc_lo           // 000000048D14: D5207C90 01AB1902
	v_mad_u32_u24 v3, v156, s1, 0x1800                         // 000000048D1C: D60B0003 03FC039C 00001800
	s_cmp_eq_u64 s[20:21], 0                                   // 000000048D28: BF108014
	s_delay_alu instid0(VALU_DEP_3)                            // 000000048D2C: BF870003
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000048D30: 3404029F
	v_mov_b32_e32 v129, 0                                      // 000000048D34: 7F020280
	s_cselect_b32 s13, -1, 0                                   // 000000048D38: 980D80C1
	v_mad_u32_u24 v5, 0x44, v157, v3                           // 000000048D3C: D60B0005 040F3AFF 00000044
	v_mad_u32_u24 v165, 0x44, v131, v3                         // 000000048D48: D60B00A5 040F06FF 00000044
	v_lshrrev_b32_e32 v2, 30, v2                               // 000000048D54: 3204049E
	v_dual_mov_b32 v8, v129 :: v_dual_lshlrev_b32 v3, 4, v0    // 000000048D58: CA220181 08020084
	s_cmp_lg_u64 s[20:21], 0                                   // 000000048D60: BF118014
	v_lshl_add_u32 v161, v154, 2, v5                           // 000000048D64: D64600A1 0415059A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000048D6C: BF870003
	v_add_nc_u32_e32 v1, v1, v2                                // 000000048D70: 4A020501
	v_add_nc_u32_e32 v2, v4, v132                              // 000000048D74: 4A050904
	s_cselect_b32 s22, -1, 0                                   // 000000048D78: 981680C1
	s_ashr_i32 s25, s24, 31                                    // 000000048D7C: 86199F18
	s_add_i32 s15, s15, -1                                     // 000000048D80: 810FC10F
	v_ashrrev_i32_e32 v162, 2, v1                              // 000000048D84: 35440282
	v_lshlrev_b32_e32 v1, 9, v156                              // 000000048D88: 30033889
	s_lshl_b64 s[4:5], s[24:25], 9                             // 000000048D8C: 84848918
	v_dual_mov_b32 v6, v129 :: v_dual_add_nc_u32 v5, 0x9f00, v132// 000000048D90: CA200181 060508FF 00009F00
	s_add_u32 s2, s6, s4                                       // 000000048D9C: 80020406
	s_delay_alu instid0(VALU_DEP_2)                            // 000000048DA0: BF870002
	v_lshl_add_u32 v166, v131, 5, v1                           // 000000048DA4: D64600A6 04050B83
	v_lshl_or_b32 v170, v154, 5, v1                            // 000000048DAC: D65600AA 04050B9A
	v_dual_mov_b32 v12, v129 :: v_dual_and_b32 v1, 0x1f0, v3   // 000000048DB4: CA240181 0C0006FF 000001F0
	v_dual_mov_b32 v3, v129 :: v_dual_add_nc_u32 v164, 0x9c00, v2// 000000048DC0: CA200181 03A404FF 00009C00
	v_dual_mov_b32 v10, v129 :: v_dual_add_nc_u32 v167, 0xa200, v2// 000000048DCC: CA200181 0AA604FF 0000A200
	v_mul_u32_u24_e32 v2, 0x210, v156                          // 000000048DD8: 160538FF 00000210
	s_addc_u32 s1, s7, s5                                      // 000000048DE0: 82010507
	s_movk_i32 s6, 0x210                                       // 000000048DE4: B0060210
	.long 0xd70002ac                                           // 000000048DE8: D70002AC
	v_cndmask_b32_e32 v1, s2, v1, vcc_lo                       // 000000048DEC: 02020202
	.long 0xd44c0000                                           // 000000048DF0: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000048DF4: 020200FF 00000200
	v_mad_u32_u24 v159, v154, s6, 0x7b00                       // 000000048DFC: D60B009F 03FC0D9A 00007B00
	v_dual_mov_b32 v9, 0 :: v_dual_add_nc_u32 v168, v5, v4     // 000000048E08: CA200080 09A80905
	v_lshl_or_b32 v169, v157, 2, v5                            // 000000048E10: D65600A9 0415059D
	v_mad_u32_u24 v171, v154, 48, 0x4b00                       // 000000048E18: D60B00AB 03FD619A 00004B00
	v_add_co_ci_u32_e64 v173, null, s1, 0, s2                  // 000000048E24: D5207CAD 00090001
	v_lshl_or_b32 v174, v154, 1, 0x4b00                        // 000000048E2C: D65600AE 03FD039A 00004B00
	v_dual_mov_b32 v14, v129 :: v_dual_add_nc_u32 v175, 0xfffffe80, v0// 000000048E38: CA200181 0EAE00FF FFFFFE80
	v_lshl_add_u32 v176, v131, 4, v2                           // 000000048E44: D64600B0 04090983
	v_lshrrev_b32_e32 v0, 1, v0                                // 000000048E4C: 32000081
	v_mov_b32_e32 v1, 0                                        // 000000048E50: 7E020280
	v_dual_mov_b32 v4, v129 :: v_dual_add_nc_u32 v163, v160, v131// 000000048E54: CA200181 04A307A0
	v_mov_b32_e32 v2, v129                                     // 000000048E5C: 7E040381
	v_mov_b32_e32 v5, v129                                     // 000000048E60: 7E0A0381
	v_mov_b32_e32 v7, v129                                     // 000000048E64: 7E0E0381
	v_mov_b32_e32 v11, v129                                    // 000000048E68: 7E160381
	v_mov_b32_e32 v13, v129                                    // 000000048E6C: 7E1A0381
	v_mov_b32_e32 v15, v129                                    // 000000048E70: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v17, 0          // 000000048E74: CA100181 10100080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v25, 0          // 000000048E7C: CA100181 12180080
	v_mov_b32_e32 v19, v129                                    // 000000048E84: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v33, 0          // 000000048E88: CA100181 14200080
	v_mov_b32_e32 v21, v129                                    // 000000048E90: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v41, 0          // 000000048E94: CA100181 16280080
	v_mov_b32_e32 v23, v129                                    // 000000048E9C: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v49, 0          // 000000048EA0: CA100181 18300080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v57, 0          // 000000048EA8: CA100181 1A380080
	v_mov_b32_e32 v27, v129                                    // 000000048EB0: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v121, 0         // 000000048EB4: CA100181 1C780080
	v_mov_b32_e32 v29, v129                                    // 000000048EBC: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v113, 0         // 000000048EC0: CA100181 1E700080
	v_mov_b32_e32 v31, v129                                    // 000000048EC8: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v105, 0         // 000000048ECC: CA100181 20680080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v97, 0          // 000000048ED4: CA100181 22600080
	v_mov_b32_e32 v35, v129                                    // 000000048EDC: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v89, 0          // 000000048EE0: CA100181 24580080
	v_mov_b32_e32 v37, v129                                    // 000000048EE8: 7E4A0381
	v_dual_mov_b32 v38, v129 :: v_dual_mov_b32 v81, 0          // 000000048EEC: CA100181 26500080
	v_mov_b32_e32 v39, v129                                    // 000000048EF4: 7E4E0381
	v_dual_mov_b32 v40, v129 :: v_dual_mov_b32 v73, 0          // 000000048EF8: CA100181 28480080
	v_dual_mov_b32 v42, v129 :: v_dual_mov_b32 v65, 0          // 000000048F00: CA100181 2A400080
	v_mov_b32_e32 v43, v129                                    // 000000048F08: 7E560381
	v_dual_mov_b32 v44, v129 :: v_dual_mov_b32 v177, v156      // 000000048F0C: CA100181 2CB0019C
	v_mov_b32_e32 v45, v129                                    // 000000048F14: 7E5A0381
	v_dual_mov_b32 v46, v129 :: v_dual_mov_b32 v145, 0         // 000000048F18: CA100181 2E900080
	v_mov_b32_e32 v47, v129                                    // 000000048F20: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 000000048F24: 7E600381
	v_mov_b32_e32 v50, v129                                    // 000000048F28: 7E640381
	v_mov_b32_e32 v51, v129                                    // 000000048F2C: 7E660381
	v_mov_b32_e32 v52, v129                                    // 000000048F30: 7E680381
	v_mov_b32_e32 v53, v129                                    // 000000048F34: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 000000048F38: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 000000048F3C: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 000000048F40: 7E700381
	v_mov_b32_e32 v58, v129                                    // 000000048F44: 7E740381
	v_mov_b32_e32 v59, v129                                    // 000000048F48: 7E760381
	v_mov_b32_e32 v60, v129                                    // 000000048F4C: 7E780381
	v_mov_b32_e32 v61, v129                                    // 000000048F50: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 000000048F54: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 000000048F58: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 000000048F5C: 7E800381
	v_mov_b32_e32 v122, v129                                   // 000000048F60: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 000000048F64: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 000000048F68: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 000000048F6C: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 000000048F70: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 000000048F74: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 000000048F78: 7F000381
	v_mov_b32_e32 v114, v129                                   // 000000048F7C: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 000000048F80: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 000000048F84: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 000000048F88: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 000000048F8C: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 000000048F90: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 000000048F94: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 000000048F98: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 000000048F9C: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 000000048FA0: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 000000048FA4: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 000000048FA8: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 000000048FAC: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 000000048FB0: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 000000048FB4: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 000000048FB8: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 000000048FBC: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 000000048FC0: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 000000048FC4: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 000000048FC8: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 000000048FCC: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 000000048FD0: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 000000048FD4: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 000000048FD8: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 000000048FDC: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 000000048FE0: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 000000048FE4: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 000000048FE8: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 000000048FEC: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 000000048FF0: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 000000048FF4: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 000000048FF8: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 000000048FFC: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 000000049000: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 000000049004: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 000000049008: 7E940381
	v_mov_b32_e32 v75, v129                                    // 00000004900C: 7E960381
	v_mov_b32_e32 v76, v129                                    // 000000049010: 7E980381
	v_mov_b32_e32 v77, v129                                    // 000000049014: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 000000049018: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 00000004901C: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 000000049020: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 000000049024: 7E840381
	v_mov_b32_e32 v67, v129                                    // 000000049028: 7E860381
	v_mov_b32_e32 v68, v129                                    // 00000004902C: 7E880381
	v_mov_b32_e32 v69, v129                                    // 000000049030: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 000000049034: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 000000049038: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 00000004903C: 7E900381
	s_add_u32 s6, s8, s4                                       // 000000049040: 80060408
	s_addc_u32 s5, s9, s5                                      // 000000049044: 82050509
	s_mov_b32 s7, 0                                            // 000000049048: BE870080
	s_branch 117                                               // 00000004904C: BFA00075 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x924>
	ds_load_b128 v[146:149], v171                              // 000000049050: DBFC0000 920000AB
	ds_load_b128 v[150:153], v171 offset:16                    // 000000049058: DBFC0010 960000AB
	s_waitcnt lgkmcnt(0)                                       // 000000049060: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[146:153], v[121:128]// 000000049064: CC414079 1DE72582
	ds_load_b128 v[150:153], v171 offset:784                   // 00000004906C: DBFC0310 960000AB
	ds_load_b128 v[146:149], v171 offset:768                   // 000000049074: DBFC0300 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000004907C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[146:153], v[113:120]// 000000049080: CC414071 1DC72582
	ds_load_b128 v[150:153], v171 offset:1552                  // 000000049088: DBFC0610 960000AB
	ds_load_b128 v[146:149], v171 offset:1536                  // 000000049090: DBFC0600 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000049098: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[146:153], v[105:112]// 00000004909C: CC414069 1DA72582
	ds_load_b128 v[150:153], v171 offset:2320                  // 0000000490A4: DBFC0910 960000AB
	ds_load_b128 v[146:149], v171 offset:2304                  // 0000000490AC: DBFC0900 920000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000490B4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[146:153], v[97:104]// 0000000490B8: CC414061 1D872582
	ds_load_b128 v[150:153], v171 offset:3088                  // 0000000490C0: DBFC0C10 960000AB
	ds_load_b128 v[146:149], v171 offset:3072                  // 0000000490C8: DBFC0C00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000490D0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[146:153], v[89:96]// 0000000490D4: CC414059 1D672582
	ds_load_b128 v[150:153], v171 offset:3856                  // 0000000490DC: DBFC0F10 960000AB
	ds_load_b128 v[146:149], v171 offset:3840                  // 0000000490E4: DBFC0F00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000490EC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[146:153], v[81:88]// 0000000490F0: CC414051 1D472582
	ds_load_b128 v[150:153], v171 offset:4624                  // 0000000490F8: DBFC1210 960000AB
	ds_load_b128 v[146:149], v171 offset:4608                  // 000000049100: DBFC1200 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000049108: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[146:153], v[73:80]// 00000004910C: CC414049 1D272582
	ds_load_b128 v[150:153], v171 offset:5392                  // 000000049114: DBFC1510 960000AB
	ds_load_b128 v[146:149], v171 offset:5376                  // 00000004911C: DBFC1500 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000049124: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[146:153], v[65:72]// 000000049128: CC414041 1D072582
	ds_load_b128 v[150:153], v171 offset:6160                  // 000000049130: DBFC1810 960000AB
	ds_load_b128 v[146:149], v171 offset:6144                  // 000000049138: DBFC1800 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000049140: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[146:153], v[57:64]// 000000049144: CC414039 1CE72582
	ds_load_b128 v[150:153], v171 offset:6928                  // 00000004914C: DBFC1B10 960000AB
	ds_load_b128 v[146:149], v171 offset:6912                  // 000000049154: DBFC1B00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000004915C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[146:153], v[49:56]// 000000049160: CC414031 1CC72582
	ds_load_b128 v[150:153], v171 offset:7696                  // 000000049168: DBFC1E10 960000AB
	ds_load_b128 v[146:149], v171 offset:7680                  // 000000049170: DBFC1E00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000049178: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[146:153], v[41:48]// 00000004917C: CC414029 1CA72582
	ds_load_b128 v[150:153], v171 offset:8464                  // 000000049184: DBFC2110 960000AB
	ds_load_b128 v[146:149], v171 offset:8448                  // 00000004918C: DBFC2100 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000049194: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[146:153], v[33:40]// 000000049198: CC414021 1C872582
	ds_load_b128 v[150:153], v171 offset:9232                  // 0000000491A0: DBFC2410 960000AB
	ds_load_b128 v[146:149], v171 offset:9216                  // 0000000491A8: DBFC2400 920000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000491B0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[146:153], v[25:32]// 0000000491B4: CC414019 1C672582
	ds_load_b128 v[150:153], v171 offset:10000                 // 0000000491BC: DBFC2710 960000AB
	ds_load_b128 v[146:149], v171 offset:9984                  // 0000000491C4: DBFC2700 920000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000491CC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[146:153], v[17:24]// 0000000491D0: CC414011 1C472582
	ds_load_b128 v[150:153], v171 offset:10768                 // 0000000491D8: DBFC2A10 960000AB
	ds_load_b128 v[146:149], v171 offset:10752                 // 0000000491E0: DBFC2A00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 0000000491E8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[146:153], v[9:16]// 0000000491EC: CC414009 1C272582
	ds_load_b128 v[150:153], v171 offset:11536                 // 0000000491F4: DBFC2D10 960000AB
	ds_load_b128 v[146:149], v171 offset:11520                 // 0000000491FC: DBFC2D00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 000000049204: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[146:153], v[1:8]// 000000049208: CC414001 1C072582
	v_add_nc_u32_e32 v177, 16, v177                            // 000000049210: 4B636290
	s_add_i32 s1, s7, 1                                        // 000000049214: 81018107
	s_cmp_eq_u32 s7, s12                                       // 000000049218: BF060C07
	s_mov_b32 s7, s1                                           // 00000004921C: BE870001
	s_cbranch_scc1 2582                                        // 000000049220: BFA20A16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x317c>
	s_and_not1_b32 vcc_lo, exec_lo, s22                        // 000000049224: 916A167E
	s_mov_b32 s1, s13                                          // 000000049228: BE81000D
	s_cbranch_vccnz 13                                         // 00000004922C: BFA4000D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x964>
	s_lshr_b32 s1, s7, 3                                       // 000000049230: 85018307
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000049234: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 000000049238: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 000000049240: 7F040201
	global_load_b32 v130, v130, s[20:21]                       // 000000049244: DC520000 82140082
	s_waitcnt vmcnt(0)                                         // 00000004924C: BF8903F7
	v_lshrrev_b32_e32 v130, s7, v130                           // 000000049250: 33050407
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049254: BF870091
	v_and_b32_e32 v130, 1, v130                                // 000000049258: 37050481
	.long 0xd44a0001                                           // 00000004925C: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 000000049260: 02030481
	s_delay_alu instid0(VALU_DEP_1)                            // 000000049264: BF870001
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000049268: 916A017E
	s_cbranch_vccnz 65512                                      // 00000004926C: BFA4FFE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x910>
	s_lshl_b32 s2, s7, 4                                       // 000000049270: 84028407
	s_waitcnt vmcnt(0)                                         // 000000049274: BF8903F7
	s_barrier                                                  // 000000049278: BFBD0000
	buffer_gl0_inv                                             // 00000004927C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000049284: BE812000
	s_cbranch_execz 117                                        // 000000049288: BFA50075 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb60>
	v_dual_mov_b32 v130, v177 :: v_dual_mov_b32 v131, v176     // 00000004928C: CA1001B1 828201B0
	v_mov_b32_e32 v132, v175                                   // 000000049294: 7F0803AF
	s_mov_b32 s4, 0                                            // 000000049298: BE840080
	s_nop 0                                                    // 00000004929C: BF800000
	s_nop 0                                                    // 0000000492A0: BF800000
	s_nop 0                                                    // 0000000492A4: BF800000
	s_nop 0                                                    // 0000000492A8: BF800000
	s_nop 0                                                    // 0000000492AC: BF800000
	s_nop 0                                                    // 0000000492B0: BF800000
	s_nop 0                                                    // 0000000492B4: BF800000
	s_nop 0                                                    // 0000000492B8: BF800000
	s_nop 0                                                    // 0000000492BC: BF800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000492C0: BF870112
	v_min_i32_e32 v133, s15, v130                              // 0000000492C4: 230B040F
	v_add_nc_u32_e32 v132, 0x180, v132                         // 0000000492C8: 4B0908FF 00000180
	v_add_nc_u32_e32 v130, 12, v130                            // 0000000492D0: 4B05048C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000492D4: BF8701B3
	v_ashrrev_i32_e32 v135, 31, v133                           // 0000000492D8: 350F0A9F
	.long 0xd72c0088                                           // 0000000492DC: D72C0088
	v_cndmask_b32_e32 v1, s11, v133, vcc_lo                    // 0000000492E0: 02030A0B
	v_mad_u64_u32 v[133:134], null, s10, v133, 0               // 0000000492E4: D6FE7C85 02030A0A
	.long 0xd72c0087                                           // 0000000492EC: D72C0087
	v_cndmask_b32_e32 v1, s10, v135, vcc_lo                    // 0000000492F0: 02030E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000492F4: BF870091
	v_add3_u32 v134, v134, v135, v136                          // 0000000492F8: D6550086 06230F86
	.long 0xd73c0085                                           // 000000049300: D73C0085
	v_cndmask_b32_e32 v1, 1, v133, vcc_lo                      // 000000049304: 02030A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049308: BF870091
	.long 0xd7006a85                                           // 00000004930C: D7006A85
	v_cndmask_b32_e32 v1, v172, v133, vcc_lo                   // 000000049310: 02030BAC
	v_add_co_ci_u32_e64 v134, null, v173, v134, vcc_lo         // 000000049314: D5207C86 01AB0DAD
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v132                        // 00000004931C: 7C9308FF 0000007F
	global_load_b128 v[133:136], v[133:134], off               // 000000049324: DC5E0000 857C0085
	s_or_b32 s4, vcc_lo, s4                                    // 00000004932C: 8C04046A
	s_waitcnt vmcnt(0)                                         // 000000049330: BF8903F7
	ds_store_b128 v131, v[133:136] offset:31488                // 000000049334: DB7C7B00 00008583
	v_add_nc_u32_e32 v131, 0x18c0, v131                        // 00000004933C: 4B0706FF 000018C0
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000049344: 917E047E
	s_cbranch_execnz 65501                                     // 000000049348: BFA6FFDD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000004934C: 8C7E047E
	v_or_b32_e32 v130, s2, v154                                // 000000049350: 39053402
	s_mov_b32 s4, 0                                            // 000000049354: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049358: BF870091
	v_min_i32_e32 v130, s15, v130                              // 00000004935C: 2305040F
	v_ashrrev_i32_e32 v132, 31, v130                           // 000000049360: 3509049F
	.long 0xd72c0085                                           // 000000049364: D72C0085
	v_cndmask_b32_e32 v1, s11, v130, vcc_lo                    // 000000049368: 0203040B
	v_mad_u64_u32 v[130:131], null, s10, v130, 0               // 00000004936C: D6FE7C82 0203040A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049374: BF870093
	.long 0xd72c0084                                           // 000000049378: D72C0084
	v_cndmask_b32_e32 v1, s10, v132, vcc_lo                    // 00000004937C: 0203080A
	v_add3_u32 v131, v131, v132, v133                          // 000000049380: D6550083 06170983
	v_mov_b32_e32 v133, v175                                   // 000000049388: 7F0A03AF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004938C: BF870122
	.long 0xd73c0083                                           // 000000049390: D73C0083
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 000000049394: 02030481
	v_mov_b32_e32 v130, v0                                     // 000000049398: 7F040300
	.long 0xd7006a83                                           // 00000004939C: D7006A83
	v_cndmask_b32_e32 v1, s6, v131, vcc_lo                     // 0000000493A0: 02030606
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000493A4: BF870001
	v_add_co_ci_u32_e64 v132, null, s5, v132, vcc_lo           // 0000000493A8: D5207C84 01AB0805
	s_set_inst_prefetch_distance 0x1                           // 0000000493B0: BF840001
	s_nop 0                                                    // 0000000493B4: BF800000
	s_nop 0                                                    // 0000000493B8: BF800000
	s_nop 0                                                    // 0000000493BC: BF800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000493C0: BF8701B3
	v_and_b32_e32 v146, 0xf8, v130                             // 0000000493C4: 372504FF 000000F8
	v_add_nc_u32_e32 v133, 0x180, v133                         // 0000000493CC: 4B0B0AFF 00000180
	v_add_nc_u32_e32 v130, 0xc0, v130                          // 0000000493D4: 4B0504FF 000000C0
	v_lshlrev_b32_e32 v134, 1, v146                            // 0000000493DC: 310D2481
	v_mad_u32_u24 v146, v146, 48, v174                         // 0000000493E0: D60B0092 06B96192
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000493E8: BF870092
	.long 0xd7006a86                                           // 0000000493EC: D7006A86
	v_cndmask_b32_e32 v1, v131, v134, vcc_lo                   // 0000000493F0: 02030D83
	v_add_co_ci_u32_e64 v135, null, 0, v132, vcc_lo            // 0000000493F4: D5207C87 01AB0880
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v133                        // 0000000493FC: 7C930AFF 0000007F
	global_load_b128 v[134:137], v[134:135], off               // 000000049404: DC5E0000 867C0086
	s_waitcnt vmcnt(0)                                         // 00000004940C: BF8903F7
	ds_store_b16 v146, v134                                    // 000000049410: D87C0000 00008692
	ds_store_b16_d16_hi v146, v134 offset:48                   // 000000049418: DA840030 00008692
	ds_store_b16 v146, v135 offset:96                          // 000000049420: D87C0060 00008792
	ds_store_b16_d16_hi v146, v135 offset:144                  // 000000049428: DA840090 00008792
	ds_store_b16 v146, v136 offset:192                         // 000000049430: D87C00C0 00008892
	ds_store_b16_d16_hi v146, v136 offset:240                  // 000000049438: DA8400F0 00008892
	ds_store_b16 v146, v137 offset:288                         // 000000049440: D87C0120 00008992
	ds_store_b16_d16_hi v146, v137 offset:336                  // 000000049448: DA840150 00008992
	s_or_b32 s4, vcc_lo, s4                                    // 000000049450: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049454: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000049458: 917E047E
	s_cbranch_execnz 65496                                     // 00000004945C: BFA6FFD8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac0>
	s_set_inst_prefetch_distance 0x2                           // 000000049460: BF840002
	s_or_b32 exec_lo, exec_lo, s1                              // 000000049464: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 000000049468: BF89FC07
	s_barrier                                                  // 00000004946C: BFBD0000
	buffer_gl0_inv                                             // 000000049470: E0AC0000 00000000
	s_clause 0x3                                               // 000000049478: BF850003
	global_load_b128 v[150:153], v[143:144], off offset:16     // 00000004947C: DC5E0010 967C008F
	global_load_b128 v[146:149], v[143:144], off               // 000000049484: DC5E0000 927C008F
	global_load_b128 v[182:185], v[143:144], off offset:48     // 00000004948C: DC5E0030 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:32     // 000000049494: DC5E0020 B27C008F
	ds_load_b128 v[186:189], v159                              // 00000004949C: DBFC0000 BA00009F
	ds_load_b128 v[190:193], v159 offset:16                    // 0000000494A4: DBFC0010 BE00009F
	v_mov_b32_e32 v136, v129                                   // 0000000494AC: 7F100381
	v_mov_b32_e32 v130, v129                                   // 0000000494B0: 7F040381
	v_mov_b32_e32 v131, v129                                   // 0000000494B4: 7F060381
	v_mov_b32_e32 v132, v129                                   // 0000000494B8: 7F080381
	v_mov_b32_e32 v133, v129                                   // 0000000494BC: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 0000000494C0: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 0000000494C4: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 0000000494C8: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000494CC: BF870212
	v_mov_b32_e32 v136, v135                                   // 0000000494D0: 7F100387
	v_mov_b32_e32 v135, v134                                   // 0000000494D4: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 0000000494D8: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 0000000494DC: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 0000000494E0: 7F080383
	v_mov_b32_e32 v131, v130                                   // 0000000494E4: 7F060382
	v_mov_b32_e32 v130, v129                                   // 0000000494E8: 7F040381
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000494EC: BF890807
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000494F0: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 0000000494F4: CC414082 1E0B7592
	s_clause 0x1                                               // 0000000494FC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:80     // 000000049500: DC5E0050 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:64     // 000000049508: DC5E0040 927C008F
	ds_load_b128 v[186:189], v159 offset:32                    // 000000049510: DBFC0020 BA00009F
	ds_load_b128 v[190:193], v159 offset:48                    // 000000049518: DBFC0030 BE00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000049520: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 000000049524: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000004952C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:112    // 000000049530: DC5E0070 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:96     // 000000049538: DC5E0060 B27C008F
	ds_load_b128 v[190:193], v159 offset:80                    // 000000049540: DBFC0050 BE00009F
	ds_load_b128 v[186:189], v159 offset:64                    // 000000049548: DBFC0040 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000049550: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 000000049554: CC414082 1E0B7592
	s_clause 0x1                                               // 00000004955C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:144    // 000000049560: DC5E0090 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:128    // 000000049568: DC5E0080 927C008F
	ds_load_b128 v[190:193], v159 offset:112                   // 000000049570: DBFC0070 BE00009F
	ds_load_b128 v[186:189], v159 offset:96                    // 000000049578: DBFC0060 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000049580: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 000000049584: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000004958C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:176    // 000000049590: DC5E00B0 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:160    // 000000049598: DC5E00A0 B27C008F
	ds_load_b128 v[190:193], v159 offset:144                   // 0000000495A0: DBFC0090 BE00009F
	ds_load_b128 v[186:189], v159 offset:128                   // 0000000495A8: DBFC0080 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000495B0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 0000000495B4: CC414082 1E0B7592
	s_clause 0x1                                               // 0000000495BC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:208    // 0000000495C0: DC5E00D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:192    // 0000000495C8: DC5E00C0 927C008F
	ds_load_b128 v[190:193], v159 offset:176                   // 0000000495D0: DBFC00B0 BE00009F
	ds_load_b128 v[186:189], v159 offset:160                   // 0000000495D8: DBFC00A0 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000495E0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 0000000495E4: CC414082 1E0B75B2
	s_clause 0x1                                               // 0000000495EC: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:240    // 0000000495F0: DC5E00F0 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:224    // 0000000495F8: DC5E00E0 B27C008F
	ds_load_b128 v[190:193], v159 offset:208                   // 000000049600: DBFC00D0 BE00009F
	ds_load_b128 v[186:189], v159 offset:192                   // 000000049608: DBFC00C0 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000049610: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 000000049614: CC414082 1E0B7592
	s_clause 0x1                                               // 00000004961C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:272    // 000000049620: DC5E0110 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:256    // 000000049628: DC5E0100 927C008F
	ds_load_b128 v[190:193], v159 offset:240                   // 000000049630: DBFC00F0 BE00009F
	ds_load_b128 v[186:189], v159 offset:224                   // 000000049638: DBFC00E0 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000049640: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 000000049644: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000004964C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:304    // 000000049650: DC5E0130 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:288    // 000000049658: DC5E0120 B27C008F
	ds_load_b128 v[190:193], v159 offset:272                   // 000000049660: DBFC0110 BE00009F
	ds_load_b128 v[186:189], v159 offset:256                   // 000000049668: DBFC0100 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000049670: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 000000049674: CC414082 1E0B7592
	s_clause 0x1                                               // 00000004967C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:336    // 000000049680: DC5E0150 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:320    // 000000049688: DC5E0140 927C008F
	ds_load_b128 v[190:193], v159 offset:304                   // 000000049690: DBFC0130 BE00009F
	ds_load_b128 v[186:189], v159 offset:288                   // 000000049698: DBFC0120 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000496A0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 0000000496A4: CC414082 1E0B75B2
	s_clause 0x1                                               // 0000000496AC: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:368    // 0000000496B0: DC5E0170 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:352    // 0000000496B8: DC5E0160 B27C008F
	ds_load_b128 v[190:193], v159 offset:336                   // 0000000496C0: DBFC0150 BE00009F
	ds_load_b128 v[186:189], v159 offset:320                   // 0000000496C8: DBFC0140 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000496D0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 0000000496D4: CC414082 1E0B7592
	s_clause 0x1                                               // 0000000496DC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:400    // 0000000496E0: DC5E0190 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:384    // 0000000496E8: DC5E0180 927C008F
	ds_load_b128 v[190:193], v159 offset:368                   // 0000000496F0: DBFC0170 BE00009F
	ds_load_b128 v[186:189], v159 offset:352                   // 0000000496F8: DBFC0160 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000049700: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 000000049704: CC414082 1E0B75B2
	ds_load_b128 v[182:185], v159 offset:400                   // 00000004970C: DBFC0190 B600009F
	ds_load_b128 v[178:181], v159 offset:384                   // 000000049714: DBFC0180 B200009F
	s_clause 0x1                                               // 00000004971C: BF850001
	global_load_b128 v[190:193], v[143:144], off offset:432    // 000000049720: DC5E01B0 BE7C008F
	global_load_b128 v[186:189], v[143:144], off offset:416    // 000000049728: DC5E01A0 BA7C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000049730: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[178:185], v[130:137]// 000000049734: CC414082 1E0B6592
	s_clause 0x1                                               // 00000004973C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:464    // 000000049740: DC5E01D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:448    // 000000049748: DC5E01C0 927C008F
	ds_load_b128 v[182:185], v159 offset:432                   // 000000049750: DBFC01B0 B600009F
	ds_load_b128 v[178:181], v159 offset:416                   // 000000049758: DBFC01A0 B200009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000049760: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[186:193], v[178:185], v[130:137]// 000000049764: CC414082 1E0B65BA
	ds_load_b128 v[182:185], v159 offset:464                   // 00000004976C: DBFC01D0 B600009F
	ds_load_b128 v[178:181], v159 offset:448                   // 000000049774: DBFC01C0 B200009F
	s_clause 0x1                                               // 00000004977C: BF850001
	global_load_b128 v[190:193], v[143:144], off offset:496    // 000000049780: DC5E01F0 BE7C008F
	global_load_b128 v[186:189], v[143:144], off offset:480    // 000000049788: DC5E01E0 BA7C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 000000049790: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[178:185], v[130:137]// 000000049794: CC414082 1E0B6592
	ds_load_b128 v[150:153], v159 offset:496                   // 00000004979C: DBFC01F0 9600009F
	ds_load_b128 v[146:149], v159 offset:480                   // 0000000497A4: DBFC01E0 9200009F
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000497AC: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[186:193], v[146:153], v[130:137]// 0000000497B0: CC414082 1E0B25BA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000497B8: BF870111
	v_dual_mul_f32 v130, 0x3d800000, v130 :: v_dual_mul_f32 v131, 0x3d800000, v131// 0000000497BC: C8C704FF 828306FF 3D800000
	v_mul_f32_e32 v146, 0x3d800000, v133                       // 0000000497C8: 11250AFF 3D800000
	v_mov_b32_e32 v133, 0xffff                                 // 0000000497D0: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000497D8: BF870004
	v_mul_f32_e32 v132, 0x3d800000, v132                       // 0000000497DC: 110908FF 3D800000
	v_dual_mul_f32 v134, 0x3d800000, v134 :: v_dual_mul_f32 v135, 0x3d800000, v135// 0000000497E4: C8C70CFF 86870EFF 3D800000
	v_dual_mul_f32 v136, 0x3d800000, v136 :: v_dual_mul_f32 v137, 0x3d800000, v137// 0000000497F0: C8C710FF 888912FF 3D800000
	ds_store_2addr_b32 v161, v130, v131 offset1:34             // 0000000497FC: D8382200 008382A1
	ds_store_2addr_b32 v161, v132, v146 offset0:68 offset1:102 // 000000049804: D8386644 009284A1
	ds_store_2addr_b32 v161, v134, v135 offset0:136 offset1:170// 00000004980C: D838AA88 008786A1
	ds_store_2addr_b32 v161, v136, v137 offset0:204 offset1:238// 000000049814: D838EECC 008988A1
	s_waitcnt lgkmcnt(0)                                       // 00000004981C: BF89FC07
	s_barrier                                                  // 000000049820: BFBD0000
	buffer_gl0_inv                                             // 000000049824: E0AC0000 00000000
	s_and_saveexec_b32 s4, s23                                 // 00000004982C: BE842017
	s_cbranch_execz 359                                        // 000000049830: BFA50167 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14d0>
	s_lshl_b32 s8, s7, 2                                       // 000000049834: 84088207
	s_mov_b32 s9, exec_lo                                      // 000000049838: BE89007E
	.long 0xd4c1007e                                           // 00000004983C: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 000000049840: 02033D91
	s_cbranch_execz 44                                         // 000000049844: BFA5002C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xff8>
	v_ashrrev_i32_e32 v146, 31, v145                           // 000000049848: 3525229F
	s_mov_b32 s24, 0                                           // 00000004984C: BE980080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049850: BF870091
	.long 0xd73c0082                                           // 000000049854: D73C0082
	v_cndmask_b32_e32 v1, 2, v145, vcc_lo                      // 000000049858: 02032282
	.long 0xd7006a82                                           // 00000004985C: D7006A82
	v_cndmask_b32_e32 v1, v141, v130, vcc_lo                   // 000000049860: 0203058D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000049864: BF870001
	v_add_co_ci_u32_e64 v131, null, v142, v131, vcc_lo         // 000000049868: D5207C83 01AB078E
	s_branch 11                                                // 000000049870: BFA0000B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xfa0>
	s_nop 0                                                    // 000000049874: BF800000
	s_nop 0                                                    // 000000049878: BF800000
	s_nop 0                                                    // 00000004987C: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 000000049880: 8C7E1A7E
	v_mov_b32_e32 v133, v145                                   // 000000049884: 7F0A0391
	v_mov_b32_e32 v145, v132                                   // 000000049888: 7F220384
	s_and_b32 s1, exec_lo, s25                                 // 00000004988C: 8B01197E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000049890: BF870499
	s_or_b32 s24, s1, s24                                      // 000000049894: 8C181801
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 000000049898: 917E187E
	s_cbranch_execz 20                                         // 00000004989C: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xff0>
	global_load_b32 v132, v[130:131], off                      // 0000000498A0: DC520000 847C0082
	s_or_b32 s25, s25, exec_lo                                 // 0000000498A8: 8C197E19
	s_waitcnt vmcnt(0)                                         // 0000000498AC: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s8, v132                          // 0000000498B0: 7C890808
	s_and_saveexec_b32 s26, vcc_lo                             // 0000000498B4: BE9A206A
	s_cbranch_execz 65521                                      // 0000000498B8: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	v_dual_mov_b32 v145, v158 :: v_dual_add_nc_u32 v132, 1, v145// 0000000498BC: CA20019E 91852281
	.long 0xd7000182                                           // 0000000498C4: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 0000000498C8: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000498CC: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 0000000498D0: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v158, v132                        // 0000000498D8: 7C95099E
	s_and_not1_b32 s1, s25, exec_lo                            // 0000000498DC: 91017E19
	s_and_b32 s25, vcc_lo, exec_lo                             // 0000000498E0: 8B197E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000498E4: BF870009
	s_or_b32 s25, s1, s25                                      // 0000000498E8: 8C191901
	s_branch 65508                                             // 0000000498EC: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000498F0: 8C7E187E
	v_mov_b32_e32 v145, v133                                   // 0000000498F4: 7F220385
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000498F8: 8C7E097E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000498FC: BF870001
	v_dual_mov_b32 v133, 15 :: v_dual_mov_b32 v130, v145       // 000000049900: CA10008F 85820191
	s_mov_b32 s1, exec_lo                                      // 000000049908: BE81007E
	.long 0xd4c1007e                                           // 00000004990C: D4C1007E
	v_cndmask_b32_e32 v1, s8, v162, vcc_lo                     // 000000049910: 02034408
	s_cbranch_execz 62                                         // 000000049914: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1110>
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v145        // 000000049918: CA100080 85820191
	s_mov_b32 s9, exec_lo                                      // 000000049920: BE89007E
	.long 0xd4c1007e                                           // 000000049924: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 000000049928: 02033D91
	s_cbranch_execz 54                                         // 00000004992C: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1108>
	v_mov_b32_e32 v130, v145                                   // 000000049930: 7F040391
	s_mov_b32 s25, 0                                           // 000000049934: BE990080
	s_set_inst_prefetch_distance 0x1                           // 000000049938: BF840001
	s_branch 10                                                // 00000004993C: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1068>
	s_or_b32 exec_lo, exec_lo, s28                             // 000000049940: 8C7E1C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000049944: BF870499
	s_and_b32 s28, exec_lo, s27                                // 000000049948: 8B1C1B7E
	s_or_b32 s25, s28, s25                                     // 00000004994C: 8C19191C
	s_and_not1_b32 s24, s24, exec_lo                           // 000000049950: 91187E18
	s_and_b32 s28, s26, exec_lo                                // 000000049954: 8B1C7E1A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049958: BF870009
	s_or_b32 s24, s24, s28                                     // 00000004995C: 8C181C18
	s_and_not1_b32 exec_lo, exec_lo, s25                       // 000000049960: 917E197E
	s_cbranch_execz 28                                         // 000000049964: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10d8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000049968: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 00000004996C: 7F060382
	s_or_b32 s26, s26, exec_lo                                 // 000000049970: 8C1A7E1A
	s_or_b32 s27, s27, exec_lo                                 // 000000049974: 8C1B7E1B
	s_mov_b32 s28, exec_lo                                     // 000000049978: BE9C007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000004997C: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049980: BF870091
	.long 0xd73c0084                                           // 000000049984: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 000000049988: 02030682
	.long 0xd7006a84                                           // 00000004998C: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 000000049990: 0203098D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000049994: BF870001
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 000000049998: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 0000000499A0: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 0000000499A8: BF8903F7
	.long 0xd4c4007e                                           // 0000000499AC: D4C4007E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 0000000499B0: 02030808
	s_cbranch_execz 65506                                      // 0000000499B4: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000499B8: 4B050681
	s_and_not1_b32 s27, s27, exec_lo                           // 0000000499BC: 911B7E1B
	s_and_not1_b32 s26, s26, exec_lo                           // 0000000499C0: 911A7E1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000499C4: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 0000000499C8: 7C95059E
	s_and_b32 s29, vcc_lo, exec_lo                             // 0000000499CC: 8B1D7E6A
	s_or_b32 s27, s27, s29                                     // 0000000499D0: 8C1B1D1B
	s_branch 65498                                             // 0000000499D4: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	s_set_inst_prefetch_distance 0x2                           // 0000000499D8: BF840002
	s_or_b32 exec_lo, exec_lo, s25                             // 0000000499DC: 8C7E197E
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v158        // 0000000499E0: CA100080 8582019E
	s_and_saveexec_b32 s25, s24                                // 0000000499E8: BE992018
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000499EC: BF870009
	s_xor_b32 s24, exec_lo, s25                                // 0000000499F0: 8D18197E
	v_cmp_eq_u32_e32 vcc_lo, s8, v132                          // 0000000499F4: 7C950808
	v_mov_b32_e32 v130, v131                                   // 0000000499F8: 7F040383
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 0000000499FC: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s24                             // 000000049A04: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049A08: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 000000049A0C: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049A10: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000049A14: 8C7E017E
	s_or_b32 s9, s8, 1                                         // 000000049A18: 8C098108
	s_mov_b32 s1, exec_lo                                      // 000000049A1C: BE81007E
	.long 0xd4c6007e                                           // 000000049A20: D4C6007E
	v_cndmask_b32_e32 v1, s9, v162, vcc_lo                     // 000000049A24: 02034409
	s_xor_b32 s1, exec_lo, s1                                  // 000000049A28: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 000000049A2C: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 000000049A34: BE813001
	s_cbranch_execz 70                                         // 000000049A38: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1254>
	s_mov_b32 s24, exec_lo                                     // 000000049A3C: BE98007E
	.long 0xd4c1007e                                           // 000000049A40: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 000000049A44: 02033D82
	s_cbranch_execz 64                                         // 000000049A48: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x124c>
	s_mov_b32 s26, 0                                           // 000000049A4C: BE9A0080
	s_set_inst_prefetch_distance 0x1                           // 000000049A50: BF840001
	s_branch 20                                                // 000000049A54: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11a8>
	s_nop 0                                                    // 000000049A58: BF800000
	s_nop 0                                                    // 000000049A5C: BF800000
	s_nop 0                                                    // 000000049A60: BF800000
	s_nop 0                                                    // 000000049A64: BF800000
	s_nop 0                                                    // 000000049A68: BF800000
	s_nop 0                                                    // 000000049A6C: BF800000
	s_nop 0                                                    // 000000049A70: BF800000
	s_nop 0                                                    // 000000049A74: BF800000
	s_nop 0                                                    // 000000049A78: BF800000
	s_nop 0                                                    // 000000049A7C: BF800000
	s_or_b32 exec_lo, exec_lo, s29                             // 000000049A80: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000049A84: BF870499
	s_and_b32 s29, exec_lo, s28                                // 000000049A88: 8B1D1C7E
	s_or_b32 s26, s29, s26                                     // 000000049A8C: 8C1A1A1D
	s_and_not1_b32 s25, s25, exec_lo                           // 000000049A90: 91197E19
	s_and_b32 s29, s27, exec_lo                                // 000000049A94: 8B1D7E1B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049A98: BF870009
	s_or_b32 s25, s25, s29                                     // 000000049A9C: 8C191D19
	s_and_not1_b32 exec_lo, exec_lo, s26                       // 000000049AA0: 917E1A7E
	s_cbranch_execz 27                                         // 000000049AA4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1214>
	v_mov_b32_e32 v131, v130                                   // 000000049AA8: 7F060382
	s_or_b32 s27, s27, exec_lo                                 // 000000049AAC: 8C1B7E1B
	s_or_b32 s28, s28, exec_lo                                 // 000000049AB0: 8C1C7E1C
	s_mov_b32 s29, exec_lo                                     // 000000049AB4: BE9D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049AB8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 000000049ABC: 3509069F
	.long 0xd73c0086                                           // 000000049AC0: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 000000049AC4: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049AC8: BF870091
	.long 0xd7006a86                                           // 000000049ACC: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 000000049AD0: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 000000049AD4: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 000000049ADC: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 000000049AE4: BF8903F7
	.long 0xd4c6007e                                           // 000000049AE8: D4C6007E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 000000049AEC: 02030808
	s_cbranch_execz 65507                                      // 000000049AF0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	v_add_nc_u32_e32 v130, 1, v131                             // 000000049AF4: 4B050681
	s_and_not1_b32 s28, s28, exec_lo                           // 000000049AF8: 911C7E1C
	s_and_not1_b32 s27, s27, exec_lo                           // 000000049AFC: 911B7E1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000049B00: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 000000049B04: 7C95059E
	s_and_b32 s30, vcc_lo, exec_lo                             // 000000049B08: 8B1E7E6A
	s_or_b32 s28, s28, s30                                     // 000000049B0C: 8C1C1E1C
	s_branch 65499                                             // 000000049B10: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	s_set_inst_prefetch_distance 0x2                           // 000000049B14: BF840002
	s_or_b32 exec_lo, exec_lo, s26                             // 000000049B18: 8C7E1A7E
	v_mov_b32_e32 v130, v158                                   // 000000049B1C: 7F04039E
	s_and_saveexec_b32 s26, s25                                // 000000049B20: BE9A2019
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049B24: BF870009
	s_xor_b32 s25, exec_lo, s26                                // 000000049B28: 8D191A7E
	v_cmp_eq_u32_e32 vcc_lo, s9, v132                          // 000000049B2C: 7C950809
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 000000049B30: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 000000049B3C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 000000049B40: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 000000049B44: 7F040383
	s_or_b32 exec_lo, exec_lo, s25                             // 000000049B48: 8C7E197E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049B4C: BF870009
	s_or_b32 exec_lo, exec_lo, s24                             // 000000049B50: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049B54: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000049B58: 8C7E017E
	s_or_b32 s9, s8, 2                                         // 000000049B5C: 8C098208
	s_mov_b32 s1, exec_lo                                      // 000000049B60: BE81007E
	.long 0xd4c6007e                                           // 000000049B64: D4C6007E
	v_cndmask_b32_e32 v1, s9, v162, vcc_lo                     // 000000049B68: 02034409
	s_xor_b32 s1, exec_lo, s1                                  // 000000049B6C: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 000000049B70: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 000000049B78: BE813001
	s_cbranch_execz 69                                         // 000000049B7C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1394>
	s_mov_b32 s24, exec_lo                                     // 000000049B80: BE98007E
	.long 0xd4c1007e                                           // 000000049B84: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 000000049B88: 02033D82
	s_cbranch_execz 63                                         // 000000049B8C: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x138c>
	s_mov_b32 s26, 0                                           // 000000049B90: BE9A0080
	s_set_inst_prefetch_distance 0x1                           // 000000049B94: BF840001
	s_branch 19                                                // 000000049B98: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12e8>
	s_nop 0                                                    // 000000049B9C: BF800000
	s_nop 0                                                    // 000000049BA0: BF800000
	s_nop 0                                                    // 000000049BA4: BF800000
	s_nop 0                                                    // 000000049BA8: BF800000
	s_nop 0                                                    // 000000049BAC: BF800000
	s_nop 0                                                    // 000000049BB0: BF800000
	s_nop 0                                                    // 000000049BB4: BF800000
	s_nop 0                                                    // 000000049BB8: BF800000
	s_nop 0                                                    // 000000049BBC: BF800000
	s_or_b32 exec_lo, exec_lo, s29                             // 000000049BC0: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000049BC4: BF870499
	s_and_b32 s29, exec_lo, s28                                // 000000049BC8: 8B1D1C7E
	s_or_b32 s26, s29, s26                                     // 000000049BCC: 8C1A1A1D
	s_and_not1_b32 s25, s25, exec_lo                           // 000000049BD0: 91197E19
	s_and_b32 s29, s27, exec_lo                                // 000000049BD4: 8B1D7E1B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049BD8: BF870009
	s_or_b32 s25, s25, s29                                     // 000000049BDC: 8C191D19
	s_and_not1_b32 exec_lo, exec_lo, s26                       // 000000049BE0: 917E1A7E
	s_cbranch_execz 27                                         // 000000049BE4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1354>
	v_mov_b32_e32 v131, v130                                   // 000000049BE8: 7F060382
	s_or_b32 s27, s27, exec_lo                                 // 000000049BEC: 8C1B7E1B
	s_or_b32 s28, s28, exec_lo                                 // 000000049BF0: 8C1C7E1C
	s_mov_b32 s29, exec_lo                                     // 000000049BF4: BE9D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049BF8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 000000049BFC: 3509069F
	.long 0xd73c0086                                           // 000000049C00: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 000000049C04: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049C08: BF870091
	.long 0xd7006a86                                           // 000000049C0C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 000000049C10: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 000000049C14: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 000000049C1C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 000000049C24: BF8903F7
	.long 0xd4c4007e                                           // 000000049C28: D4C4007E
	v_cndmask_b32_e32 v1, s9, v132, vcc_lo                     // 000000049C2C: 02030809
	s_cbranch_execz 65507                                      // 000000049C30: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12c0>
	v_add_nc_u32_e32 v130, 1, v131                             // 000000049C34: 4B050681
	s_and_not1_b32 s28, s28, exec_lo                           // 000000049C38: 911C7E1C
	s_and_not1_b32 s27, s27, exec_lo                           // 000000049C3C: 911B7E1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000049C40: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 000000049C44: 7C95059E
	s_and_b32 s30, vcc_lo, exec_lo                             // 000000049C48: 8B1E7E6A
	s_or_b32 s28, s28, s30                                     // 000000049C4C: 8C1C1E1C
	s_branch 65499                                             // 000000049C50: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12c0>
	s_set_inst_prefetch_distance 0x2                           // 000000049C54: BF840002
	s_or_b32 exec_lo, exec_lo, s26                             // 000000049C58: 8C7E1A7E
	v_mov_b32_e32 v130, v158                                   // 000000049C5C: 7F04039E
	s_and_saveexec_b32 s26, s25                                // 000000049C60: BE9A2019
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049C64: BF870009
	s_xor_b32 s25, exec_lo, s26                                // 000000049C68: 8D191A7E
	v_cmp_eq_u32_e32 vcc_lo, s9, v132                          // 000000049C6C: 7C950809
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 000000049C70: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 000000049C7C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 000000049C80: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 000000049C84: 7F040383
	s_or_b32 exec_lo, exec_lo, s25                             // 000000049C88: 8C7E197E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049C8C: BF870009
	s_or_b32 exec_lo, exec_lo, s24                             // 000000049C90: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049C94: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000049C98: 8C7E017E
	s_or_b32 s8, s8, 3                                         // 000000049C9C: 8C088308
	s_mov_b32 s1, exec_lo                                      // 000000049CA0: BE81007E
	.long 0xd4c6007e                                           // 000000049CA4: D4C6007E
	v_cndmask_b32_e32 v1, s8, v162, vcc_lo                     // 000000049CA8: 02034408
	s_xor_b32 s1, exec_lo, s1                                  // 000000049CAC: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 000000049CB0: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 000000049CB8: BE813001
	s_cbranch_execz 66                                         // 000000049CBC: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c8>
	s_mov_b32 s9, exec_lo                                      // 000000049CC0: BE89007E
	.long 0xd4c1007e                                           // 000000049CC4: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 000000049CC8: 02033D82
	s_cbranch_execz 60                                         // 000000049CCC: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	s_mov_b32 s25, 0                                           // 000000049CD0: BE990080
	s_set_inst_prefetch_distance 0x1                           // 000000049CD4: BF840001
	s_branch 19                                                // 000000049CD8: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1428>
	s_nop 0                                                    // 000000049CDC: BF800000
	s_nop 0                                                    // 000000049CE0: BF800000
	s_nop 0                                                    // 000000049CE4: BF800000
	s_nop 0                                                    // 000000049CE8: BF800000
	s_nop 0                                                    // 000000049CEC: BF800000
	s_nop 0                                                    // 000000049CF0: BF800000
	s_nop 0                                                    // 000000049CF4: BF800000
	s_nop 0                                                    // 000000049CF8: BF800000
	s_nop 0                                                    // 000000049CFC: BF800000
	s_or_b32 exec_lo, exec_lo, s28                             // 000000049D00: 8C7E1C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000049D04: BF870499
	s_and_b32 s28, exec_lo, s27                                // 000000049D08: 8B1C1B7E
	s_or_b32 s25, s28, s25                                     // 000000049D0C: 8C19191C
	s_and_not1_b32 s24, s24, exec_lo                           // 000000049D10: 91187E18
	s_and_b32 s28, s26, exec_lo                                // 000000049D14: 8B1C7E1A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049D18: BF870009
	s_or_b32 s24, s24, s28                                     // 000000049D1C: 8C181C18
	s_and_not1_b32 exec_lo, exec_lo, s25                       // 000000049D20: 917E197E
	s_cbranch_execz 26                                         // 000000049D24: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1490>
	v_ashrrev_i32_e32 v131, 31, v130                           // 000000049D28: 3507049F
	s_or_b32 s26, s26, exec_lo                                 // 000000049D2C: 8C1A7E1A
	s_or_b32 s27, s27, exec_lo                                 // 000000049D30: 8C1B7E1B
	s_mov_b32 s28, exec_lo                                     // 000000049D34: BE9C007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000049D38: BF870091
	.long 0xd73c0083                                           // 000000049D3C: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 000000049D40: 02030482
	.long 0xd7006a83                                           // 000000049D44: D7006A83
	v_cndmask_b32_e32 v1, v141, v131, vcc_lo                   // 000000049D48: 0203078D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000049D4C: BF870001
	v_add_co_ci_u32_e64 v132, null, v142, v132, vcc_lo         // 000000049D50: D5207C84 01AB098E
	global_load_b32 v131, v[131:132], off                      // 000000049D58: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 000000049D60: BF8903F7
	.long 0xd4c4007e                                           // 000000049D64: D4C4007E
	v_cndmask_b32_e32 v1, s8, v131, vcc_lo                     // 000000049D68: 02030608
	s_cbranch_execz 65508                                      // 000000049D6C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	v_add_nc_u32_e32 v130, 1, v130                             // 000000049D70: 4B050481
	s_and_not1_b32 s27, s27, exec_lo                           // 000000049D74: 911B7E1B
	s_and_not1_b32 s26, s26, exec_lo                           // 000000049D78: 911A7E1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000049D7C: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 000000049D80: 7C95059E
	s_and_b32 s29, vcc_lo, exec_lo                             // 000000049D84: 8B1D7E6A
	s_or_b32 s27, s27, s29                                     // 000000049D88: 8C1B1D1B
	s_branch 65500                                             // 000000049D8C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	s_set_inst_prefetch_distance 0x2                           // 000000049D90: BF840002
	s_or_b32 exec_lo, exec_lo, s25                             // 000000049D94: 8C7E197E
	s_and_saveexec_b32 s25, s24                                // 000000049D98: BE992018
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049D9C: BF870009
	s_xor_b32 s24, exec_lo, s25                                // 000000049DA0: 8D18197E
	v_cmp_eq_u32_e32 vcc_lo, s8, v131                          // 000000049DA4: 7C950608
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 000000049DA8: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000049DB4: BF870001
	v_or_b32_e32 v133, v130, v133                              // 000000049DB8: 390B0B82
	s_or_b32 exec_lo, exec_lo, s24                             // 000000049DBC: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049DC0: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 000000049DC4: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049DC8: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000049DCC: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000049DD0: BF8704C9
	s_or_b32 exec_lo, exec_lo, s4                              // 000000049DD4: 8C7E047E
	v_cmp_eq_u32_e32 vcc_lo, 0xffff, v133                      // 000000049DD8: 7C950AFF 0000FFFF
	s_cmp_eq_u32 vcc_lo, -1                                    // 000000049DE0: BF06C16A
	s_cselect_b32 s1, -1, 0                                    // 000000049DE4: 980180C1
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 000000049DE8: D5010082 00050280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000049DF0: BF870001
	v_readfirstlane_b32 s1, v130                               // 000000049DF4: 7E020582
	s_bitcmp0_b32 s1, 0                                        // 000000049DF8: BF0C8001
	s_mov_b32 s1, 0                                            // 000000049DFC: BE810080
	s_cbranch_scc1 8                                           // 000000049E00: BFA20008 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1524>
	s_or_b32 s1, s2, 15                                        // 000000049E04: 8C018F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000049E08: BF8700A9
	v_cmp_le_i32_e32 vcc_lo, s1, v160                          // 000000049E0C: 7C874001
	v_cndmask_b32_e64 v130, 0, 1, vcc_lo                       // 000000049E10: D5010082 01A90280
	v_readfirstlane_b32 s1, v130                               // 000000049E18: 7E020582
	s_bitcmp1_b32 s1, 0                                        // 000000049E1C: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 000000049E20: 980180C1
	s_and_saveexec_b32 s4, s3                                  // 000000049E24: BE842003
	s_cbranch_execz 1626                                       // 000000049E28: BFA5065A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2e94>
	ds_load_b32 v130, v164                                     // 000000049E2C: D8D80000 820000A4
	s_xor_b32 s1, s1, -1                                       // 000000049E34: 8D01C101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049E38: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000049E3C: 916A017E
	s_mov_b32 s1, -1                                           // 000000049E40: BE8100C1
	s_cbranch_vccnz 990                                        // 000000049E44: BFA403DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x24c0>
	v_and_b32_e32 v131, 1, v133                                // 000000049E48: 37070A81
	v_cmp_le_i32_e32 vcc_lo, s2, v163                          // 000000049E4C: 7C874602
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000049E50: BF8704C2
	.long 0xd44a0001                                           // 000000049E54: D44A0001
	v_cndmask_b32_e32 v1, 1, v131, vcc_lo                      // 000000049E58: 02030681
	s_waitcnt lgkmcnt(0)                                       // 000000049E5C: BF89FC07
	v_mov_b32_e32 v131, v130                                   // 000000049E60: 7F060382
	s_and_b32 s37, vcc_lo, s1                                  // 000000049E64: 8B25016A
	s_and_saveexec_b32 s1, s37                                 // 000000049E68: BE812025
	s_cbranch_execz 7                                          // 000000049E6C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x158c>
	ds_load_b32 v131, v165                                     // 000000049E70: D8D80000 830000A5
	s_waitcnt lgkmcnt(0)                                       // 000000049E78: BF89FC07
	v_dual_max_f32 v132, v130, v130 :: v_dual_max_f32 v131, v131, v131// 000000049E7C: CA950582 84830783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000049E84: BF870001
	v_max_f32_e32 v131, v132, v131                             // 000000049E88: 21070784
	s_or_b32 exec_lo, exec_lo, s1                              // 000000049E8C: 8C7E017E
	v_and_b32_e32 v132, 2, v133                                // 000000049E90: 37090A82
	v_cmp_lt_i32_e32 vcc_lo, s2, v163                          // 000000049E94: 7C834602
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000049E98: BF8704A2
	.long 0xd44d0001                                           // 000000049E9C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000049EA0: 02030880
	s_and_b32 s36, vcc_lo, s1                                  // 000000049EA4: 8B24016A
	s_and_saveexec_b32 s1, s36                                 // 000000049EA8: BE812024
	s_cbranch_execz 7                                          // 000000049EAC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15cc>
	ds_load_b32 v132, v165 offset:4                            // 000000049EB0: D8D80004 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000049EB8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000049EBC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000049EC4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000049EC8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000049ECC: 8C7E017E
	v_and_b32_e32 v132, 4, v133                                // 000000049ED0: 37090A84
	s_or_b32 s1, s2, 2                                         // 000000049ED4: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000049ED8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000049EDC: 7C874601
	.long 0xd44d0001                                           // 000000049EE0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000049EE4: 02030880
	s_and_b32 s35, vcc_lo, s1                                  // 000000049EE8: 8B23016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049EEC: BF870009
	s_and_saveexec_b32 s1, s35                                 // 000000049EF0: BE812023
	s_cbranch_execz 7                                          // 000000049EF4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1614>
	ds_load_b32 v132, v165 offset:8                            // 000000049EF8: D8D80008 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000049F00: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000049F04: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000049F0C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000049F10: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000049F14: 8C7E017E
	v_and_b32_e32 v132, 8, v133                                // 000000049F18: 37090A88
	s_or_b32 s1, s2, 3                                         // 000000049F1C: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000049F20: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000049F24: 7C874601
	.long 0xd44d0001                                           // 000000049F28: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000049F2C: 02030880
	s_and_b32 s34, vcc_lo, s1                                  // 000000049F30: 8B22016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049F34: BF870009
	s_and_saveexec_b32 s1, s34                                 // 000000049F38: BE812022
	s_cbranch_execz 7                                          // 000000049F3C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x165c>
	ds_load_b32 v132, v165 offset:12                           // 000000049F40: D8D8000C 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000049F48: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000049F4C: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000049F54: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000049F58: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000049F5C: 8C7E017E
	v_and_b32_e32 v132, 16, v133                               // 000000049F60: 37090A90
	s_or_b32 s1, s2, 4                                         // 000000049F64: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000049F68: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000049F6C: 7C874601
	.long 0xd44d0001                                           // 000000049F70: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000049F74: 02030880
	s_and_b32 s33, vcc_lo, s1                                  // 000000049F78: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049F7C: BF870009
	s_and_saveexec_b32 s1, s33                                 // 000000049F80: BE812021
	s_cbranch_execz 7                                          // 000000049F84: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16a4>
	ds_load_b32 v132, v165 offset:16                           // 000000049F88: D8D80010 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000049F90: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000049F94: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000049F9C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000049FA0: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000049FA4: 8C7E017E
	v_and_b32_e32 v132, 32, v133                               // 000000049FA8: 37090AA0
	s_or_b32 s1, s2, 5                                         // 000000049FAC: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000049FB0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000049FB4: 7C874601
	.long 0xd44d0001                                           // 000000049FB8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 000000049FBC: 02030880
	s_and_b32 s31, vcc_lo, s1                                  // 000000049FC0: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000049FC4: BF870009
	s_and_saveexec_b32 s1, s31                                 // 000000049FC8: BE81201F
	s_cbranch_execz 7                                          // 000000049FCC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16ec>
	ds_load_b32 v132, v165 offset:20                           // 000000049FD0: D8D80014 840000A5
	s_waitcnt lgkmcnt(0)                                       // 000000049FD8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 000000049FDC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 000000049FE4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 000000049FE8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 000000049FEC: 8C7E017E
	v_and_b32_e32 v132, 64, v133                               // 000000049FF0: 37090AC0
	s_or_b32 s1, s2, 6                                         // 000000049FF4: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000049FF8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 000000049FFC: 7C874601
	.long 0xd44d0001                                           // 00000004A000: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000004A004: 02030880
	s_and_b32 s30, vcc_lo, s1                                  // 00000004A008: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004A00C: BF870009
	s_and_saveexec_b32 s1, s30                                 // 00000004A010: BE81201E
	s_cbranch_execz 7                                          // 00000004A014: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1734>
	ds_load_b32 v132, v165 offset:24                           // 00000004A018: D8D80018 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A020: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000004A024: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A02C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000004A030: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000004A034: 8C7E017E
	v_and_b32_e32 v132, 0x80, v133                             // 00000004A038: 37090AFF 00000080
	s_or_b32 s1, s2, 7                                         // 00000004A040: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004A044: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000004A048: 7C874601
	.long 0xd44d0001                                           // 00000004A04C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000004A050: 02030880
	s_and_b32 s29, vcc_lo, s1                                  // 00000004A054: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004A058: BF870009
	s_and_saveexec_b32 s1, s29                                 // 00000004A05C: BE81201D
	s_cbranch_execz 7                                          // 00000004A060: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1780>
	ds_load_b32 v132, v165 offset:28                           // 00000004A064: D8D8001C 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A06C: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000004A070: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A078: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000004A07C: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000004A080: 8C7E017E
	v_and_b32_e32 v132, 0x100, v133                            // 00000004A084: 37090AFF 00000100
	s_or_b32 s1, s2, 8                                         // 00000004A08C: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004A090: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000004A094: 7C874601
	.long 0xd44d0001                                           // 00000004A098: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000004A09C: 02030880
	s_and_b32 s28, vcc_lo, s1                                  // 00000004A0A0: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004A0A4: BF870009
	s_and_saveexec_b32 s1, s28                                 // 00000004A0A8: BE81201C
	s_cbranch_execz 7                                          // 00000004A0AC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17cc>
	ds_load_b32 v132, v165 offset:32                           // 00000004A0B0: D8D80020 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A0B8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000004A0BC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A0C4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000004A0C8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000004A0CC: 8C7E017E
	v_and_b32_e32 v132, 0x200, v133                            // 00000004A0D0: 37090AFF 00000200
	s_or_b32 s1, s2, 9                                         // 00000004A0D8: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004A0DC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000004A0E0: 7C874601
	.long 0xd44d0001                                           // 00000004A0E4: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000004A0E8: 02030880
	s_and_b32 s27, vcc_lo, s1                                  // 00000004A0EC: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004A0F0: BF870009
	s_and_saveexec_b32 s1, s27                                 // 00000004A0F4: BE81201B
	s_cbranch_execz 7                                          // 00000004A0F8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1818>
	ds_load_b32 v132, v165 offset:36                           // 00000004A0FC: D8D80024 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A104: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000004A108: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A110: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000004A114: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000004A118: 8C7E017E
	v_and_b32_e32 v132, 0x400, v133                            // 00000004A11C: 37090AFF 00000400
	s_or_b32 s1, s2, 10                                        // 00000004A124: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004A128: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000004A12C: 7C874601
	.long 0xd44d0001                                           // 00000004A130: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000004A134: 02030880
	s_and_b32 s26, vcc_lo, s1                                  // 00000004A138: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004A13C: BF870009
	s_and_saveexec_b32 s1, s26                                 // 00000004A140: BE81201A
	s_cbranch_execz 7                                          // 00000004A144: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1864>
	ds_load_b32 v132, v165 offset:40                           // 00000004A148: D8D80028 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A150: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000004A154: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A15C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000004A160: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000004A164: 8C7E017E
	v_and_b32_e32 v132, 0x800, v133                            // 00000004A168: 37090AFF 00000800
	s_or_b32 s1, s2, 11                                        // 00000004A170: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004A174: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000004A178: 7C874601
	.long 0xd44d0001                                           // 00000004A17C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000004A180: 02030880
	s_and_b32 s25, vcc_lo, s1                                  // 00000004A184: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004A188: BF870009
	s_and_saveexec_b32 s1, s25                                 // 00000004A18C: BE812019
	s_cbranch_execz 7                                          // 00000004A190: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18b0>
	ds_load_b32 v132, v165 offset:44                           // 00000004A194: D8D8002C 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A19C: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000004A1A0: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A1A8: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000004A1AC: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000004A1B0: 8C7E017E
	v_and_b32_e32 v132, 0x1000, v133                           // 00000004A1B4: 37090AFF 00001000
	s_or_b32 s1, s2, 12                                        // 00000004A1BC: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004A1C0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000004A1C4: 7C874601
	.long 0xd44d0001                                           // 00000004A1C8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000004A1CC: 02030880
	s_and_b32 s24, vcc_lo, s1                                  // 00000004A1D0: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004A1D4: BF870009
	s_and_saveexec_b32 s1, s24                                 // 00000004A1D8: BE812018
	s_cbranch_execz 7                                          // 00000004A1DC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18fc>
	ds_load_b32 v132, v165 offset:48                           // 00000004A1E0: D8D80030 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A1E8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000004A1EC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A1F4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000004A1F8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000004A1FC: 8C7E017E
	v_and_b32_e32 v132, 0x2000, v133                           // 00000004A200: 37090AFF 00002000
	s_or_b32 s1, s2, 13                                        // 00000004A208: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004A20C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000004A210: 7C874601
	.long 0xd44d0001                                           // 00000004A214: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000004A218: 02030880
	s_and_b32 s9, vcc_lo, s1                                   // 00000004A21C: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004A220: BF870009
	s_and_saveexec_b32 s1, s9                                  // 00000004A224: BE812009
	s_cbranch_execz 7                                          // 00000004A228: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1948>
	ds_load_b32 v132, v165 offset:52                           // 00000004A22C: D8D80034 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A234: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000004A238: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A240: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000004A244: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000004A248: 8C7E017E
	v_and_b32_e32 v132, 0x4000, v133                           // 00000004A24C: 37090AFF 00004000
	s_or_b32 s1, s2, 14                                        // 00000004A254: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004A258: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000004A25C: 7C874601
	.long 0xd44d0001                                           // 00000004A260: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000004A264: 02030880
	s_and_b32 s8, vcc_lo, s1                                   // 00000004A268: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004A26C: BF870009
	s_and_saveexec_b32 s1, s8                                  // 00000004A270: BE812008
	s_cbranch_execz 7                                          // 00000004A274: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1994>
	ds_load_b32 v132, v165 offset:56                           // 00000004A278: D8D80038 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A280: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000004A284: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A28C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000004A290: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000004A294: 8C7E017E
	v_and_b32_e32 v132, 0x8000, v133                           // 00000004A298: 37090AFF 00008000
	s_or_b32 s2, s2, 15                                        // 00000004A2A0: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004A2A4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v163                          // 00000004A2A8: 7C874602
	.long 0xd44d0001                                           // 00000004A2AC: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000004A2B0: 02030880
	s_and_b32 s1, vcc_lo, s1                                   // 00000004A2B4: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004A2B8: BF870009
	s_and_saveexec_b32 s2, s1                                  // 00000004A2BC: BE822001
	s_cbranch_execz 7                                          // 00000004A2C0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19e0>
	ds_load_b32 v132, v165 offset:60                           // 00000004A2C4: D8D8003C 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A2CC: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000004A2D0: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004A2D8: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000004A2DC: 21070983
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004A2E0: 8C7E027E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v133, 0           // 00000004A2E4: CA100080 84840080
	s_and_saveexec_b32 s2, s37                                 // 00000004A2EC: BE822025
	s_cbranch_execz 30                                         // 00000004A2F0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a6c>
	ds_load_b32 v133, v165                                     // 00000004A2F4: D8D80000 850000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A2FC: BF89FC07
	v_sub_f32_e32 v133, v133, v131                             // 00000004A300: 090B0785
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A304: BF870091
	v_mul_f32_e32 v134, 0x3fb8aa3b, v133                       // 00000004A308: 110D0AFF 3FB8AA3B
	v_fma_f32 v135, 0x3fb8aa3b, v133, -v134                    // 00000004A310: D6130087 861B0AFF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 00000004A31C: 7F104786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004A320: BF870221
	v_sub_f32_e32 v134, v134, v136                             // 00000004A324: 090D1186
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 00000004A328: 7C370AFF C2CE8ED0
	v_fmac_f32_e32 v135, 0x32a5705f, v133                      // 00000004A330: 570F0AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A338: BF870121
	v_add_f32_e32 v134, v134, v135                             // 00000004A33C: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 00000004A340: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 00000004A344: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A348: BF870095
	.long 0xd71c0086                                           // 00000004A34C: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 00000004A350: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 00000004A354: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 00000004A358: 7C3D0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004A360: BF870002
	v_cndmask_b32_e32 v133, 0x7f800000, v134, vcc_lo           // 00000004A364: 030B0CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004A36C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A370: BF870091
	v_bfe_u32 v134, v133, 16, 1                                // 00000004A374: D6100086 02052185
	v_add3_u32 v134, v133, v134, 0x7fff                        // 00000004A37C: D6550086 03FF0D85 00007FFF
	ds_store_b16_d16_hi v166, v134                             // 00000004A388: DA840000 000086A6
	s_and_saveexec_b32 s2, s36                                 // 00000004A390: BE822024
	s_cbranch_execz 30                                         // 00000004A394: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b10>
	ds_load_b32 v132, v165 offset:4                            // 00000004A398: D8D80004 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A3A0: BF89FC07
	v_sub_f32_e32 v132, v132, v131                             // 00000004A3A4: 09090784
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A3A8: BF870121
	v_mul_f32_e32 v134, 0x3fb8aa3b, v132                       // 00000004A3AC: 110D08FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v132                 // 00000004A3B4: 7C3708FF C2CE8ED0
	v_fma_f32 v135, 0x3fb8aa3b, v132, -v134                    // 00000004A3BC: D6130087 861B08FF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 00000004A3C8: 7F104786
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004A3CC: BF870112
	v_fmac_f32_e32 v135, 0x32a5705f, v132                      // 00000004A3D0: 570F08FF 32A5705F
	v_sub_f32_e32 v134, v134, v136                             // 00000004A3D8: 090D1186
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A3DC: BF870121
	v_add_f32_e32 v134, v134, v135                             // 00000004A3E0: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 00000004A3E4: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 00000004A3E8: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A3EC: BF870095
	.long 0xd71c0086                                           // 00000004A3F0: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 00000004A3F4: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 00000004A3F8: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v132                 // 00000004A3FC: 7C3D08FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004A404: BF870002
	v_cndmask_b32_e32 v132, 0x7f800000, v134, vcc_lo           // 00000004A408: 03090CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004A410: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A414: BF870121
	v_bfe_u32 v134, v132, 16, 1                                // 00000004A418: D6100086 02052184
	v_mov_b32_e32 v135, 0                                      // 00000004A420: 7F0E0280
	v_add3_u32 v136, v132, v134, 0x7fff                        // 00000004A424: D6550088 03FF0D84 00007FFF
	v_mov_b32_e32 v134, 0                                      // 00000004A430: 7F0C0280
	ds_store_b16_d16_hi v166, v136 offset:2                    // 00000004A434: DA840002 000088A6
	s_and_saveexec_b32 s2, s35                                 // 00000004A43C: BE822023
	s_cbranch_execz 30                                         // 00000004A440: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1bbc>
	ds_load_b32 v135, v165 offset:8                            // 00000004A444: D8D80008 870000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A44C: BF89FC07
	v_sub_f32_e32 v135, v135, v131                             // 00000004A450: 090F0787
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A454: BF870091
	v_mul_f32_e32 v136, 0x3fb8aa3b, v135                       // 00000004A458: 11110EFF 3FB8AA3B
	v_fma_f32 v137, 0x3fb8aa3b, v135, -v136                    // 00000004A460: D6130089 86230EFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 00000004A46C: 7F244788
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004A470: BF870221
	v_sub_f32_e32 v136, v136, v146                             // 00000004A474: 09112588
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 00000004A478: 7C370EFF C2CE8ED0
	v_fmac_f32_e32 v137, 0x32a5705f, v135                      // 00000004A480: 57130EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A488: BF870121
	v_add_f32_e32 v136, v136, v137                             // 00000004A48C: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 00000004A490: 7F121192
	v_exp_f32_e32 v136, v136                                   // 00000004A494: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A498: BF870095
	.long 0xd71c0088                                           // 00000004A49C: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 00000004A4A0: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 00000004A4A4: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 00000004A4A8: 7C3D0EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004A4B0: BF870002
	v_cndmask_b32_e32 v135, 0x7f800000, v136, vcc_lo           // 00000004A4B4: 030F10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004A4BC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A4C0: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 00000004A4C4: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 00000004A4CC: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v166, v136 offset:4                    // 00000004A4D8: DA840004 000088A6
	s_and_saveexec_b32 s2, s34                                 // 00000004A4E0: BE822022
	s_cbranch_execz 30                                         // 00000004A4E4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c60>
	ds_load_b32 v134, v165 offset:12                           // 00000004A4E8: D8D8000C 860000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A4F0: BF89FC07
	v_sub_f32_e32 v134, v134, v131                             // 00000004A4F4: 090D0786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A4F8: BF870121
	v_mul_f32_e32 v136, 0x3fb8aa3b, v134                       // 00000004A4FC: 11110CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 00000004A504: 7C370CFF C2CE8ED0
	v_fma_f32 v137, 0x3fb8aa3b, v134, -v136                    // 00000004A50C: D6130089 86230CFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 00000004A518: 7F244788
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004A51C: BF870112
	v_fmac_f32_e32 v137, 0x32a5705f, v134                      // 00000004A520: 57130CFF 32A5705F
	v_sub_f32_e32 v136, v136, v146                             // 00000004A528: 09112588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A52C: BF870121
	v_add_f32_e32 v136, v136, v137                             // 00000004A530: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 00000004A534: 7F121192
	v_exp_f32_e32 v136, v136                                   // 00000004A538: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A53C: BF870095
	.long 0xd71c0088                                           // 00000004A540: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 00000004A544: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 00000004A548: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 00000004A54C: 7C3D0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004A554: BF870002
	v_cndmask_b32_e32 v134, 0x7f800000, v136, vcc_lo           // 00000004A558: 030D10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004A560: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A564: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 00000004A568: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 00000004A570: 7F120280
	v_add3_u32 v146, v134, v136, 0x7fff                        // 00000004A574: D6550092 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 00000004A580: 7F100280
	ds_store_b16_d16_hi v166, v146 offset:6                    // 00000004A584: DA840006 000092A6
	s_and_saveexec_b32 s2, s33                                 // 00000004A58C: BE822021
	s_cbranch_execz 30                                         // 00000004A590: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d0c>
	ds_load_b32 v137, v165 offset:16                           // 00000004A594: D8D80010 890000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A59C: BF89FC07
	v_sub_f32_e32 v137, v137, v131                             // 00000004A5A0: 09130789
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A5A4: BF870091
	v_mul_f32_e32 v146, 0x3fb8aa3b, v137                       // 00000004A5A8: 112512FF 3FB8AA3B
	v_fma_f32 v147, 0x3fb8aa3b, v137, -v146                    // 00000004A5B0: D6130093 864B12FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 00000004A5BC: 7F284792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004A5C0: BF870221
	v_sub_f32_e32 v146, v146, v148                             // 00000004A5C4: 09252992
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v137                 // 00000004A5C8: 7C3712FF C2CE8ED0
	v_fmac_f32_e32 v147, 0x32a5705f, v137                      // 00000004A5D0: 572712FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A5D8: BF870121
	v_add_f32_e32 v146, v146, v147                             // 00000004A5DC: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 00000004A5E0: 7F261194
	v_exp_f32_e32 v146, v146                                   // 00000004A5E4: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A5E8: BF870095
	.long 0xd71c0092                                           // 00000004A5EC: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 00000004A5F0: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 00000004A5F4: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v137                 // 00000004A5F8: 7C3D12FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004A600: BF870002
	v_cndmask_b32_e32 v137, 0x7f800000, v146, vcc_lo           // 00000004A604: 031324FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004A60C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A610: BF870091
	v_bfe_u32 v146, v137, 16, 1                                // 00000004A614: D6100092 02052189
	v_add3_u32 v146, v137, v146, 0x7fff                        // 00000004A61C: D6550092 03FF2589 00007FFF
	ds_store_b16_d16_hi v166, v146 offset:8                    // 00000004A628: DA840008 000092A6
	s_and_saveexec_b32 s2, s31                                 // 00000004A630: BE82201F
	s_cbranch_execz 30                                         // 00000004A634: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1db0>
	ds_load_b32 v136, v165 offset:20                           // 00000004A638: D8D80014 880000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A640: BF89FC07
	v_sub_f32_e32 v136, v136, v131                             // 00000004A644: 09110788
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A648: BF870121
	v_mul_f32_e32 v146, 0x3fb8aa3b, v136                       // 00000004A64C: 112510FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 00000004A654: 7C3710FF C2CE8ED0
	v_fma_f32 v147, 0x3fb8aa3b, v136, -v146                    // 00000004A65C: D6130093 864B10FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 00000004A668: 7F284792
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004A66C: BF870112
	v_fmac_f32_e32 v147, 0x32a5705f, v136                      // 00000004A670: 572710FF 32A5705F
	v_sub_f32_e32 v146, v146, v148                             // 00000004A678: 09252992
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A67C: BF870121
	v_add_f32_e32 v146, v146, v147                             // 00000004A680: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 00000004A684: 7F261194
	v_exp_f32_e32 v146, v146                                   // 00000004A688: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A68C: BF870095
	.long 0xd71c0092                                           // 00000004A690: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 00000004A694: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 00000004A698: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 00000004A69C: 7C3D10FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004A6A4: BF870002
	v_cndmask_b32_e32 v136, 0x7f800000, v146, vcc_lo           // 00000004A6A8: 031124FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004A6B0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A6B4: BF870121
	v_bfe_u32 v146, v136, 16, 1                                // 00000004A6B8: D6100092 02052188
	v_mov_b32_e32 v147, 0                                      // 00000004A6C0: 7F260280
	v_add3_u32 v148, v136, v146, 0x7fff                        // 00000004A6C4: D6550094 03FF2588 00007FFF
	v_mov_b32_e32 v146, 0                                      // 00000004A6D0: 7F240280
	ds_store_b16_d16_hi v166, v148 offset:10                   // 00000004A6D4: DA84000A 000094A6
	s_and_saveexec_b32 s2, s30                                 // 00000004A6DC: BE82201E
	s_cbranch_execz 30                                         // 00000004A6E0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e5c>
	ds_load_b32 v147, v165 offset:24                           // 00000004A6E4: D8D80018 930000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A6EC: BF89FC07
	v_sub_f32_e32 v147, v147, v131                             // 00000004A6F0: 09270793
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A6F4: BF870091
	v_mul_f32_e32 v148, 0x3fb8aa3b, v147                       // 00000004A6F8: 112926FF 3FB8AA3B
	v_fma_f32 v149, 0x3fb8aa3b, v147, -v148                    // 00000004A700: D6130095 865326FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 00000004A70C: 7F2C4794
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004A710: BF870221
	v_sub_f32_e32 v148, v148, v150                             // 00000004A714: 09292D94
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v147                 // 00000004A718: 7C3726FF C2CE8ED0
	v_fmac_f32_e32 v149, 0x32a5705f, v147                      // 00000004A720: 572B26FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A728: BF870121
	v_add_f32_e32 v148, v148, v149                             // 00000004A72C: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 00000004A730: 7F2A1196
	v_exp_f32_e32 v148, v148                                   // 00000004A734: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A738: BF870095
	.long 0xd71c0094                                           // 00000004A73C: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 00000004A740: 02032B94
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 00000004A744: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v147                 // 00000004A748: 7C3D26FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004A750: BF870002
	v_cndmask_b32_e32 v147, 0x7f800000, v148, vcc_lo           // 00000004A754: 032728FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004A75C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A760: BF870091
	v_bfe_u32 v148, v147, 16, 1                                // 00000004A764: D6100094 02052193
	v_add3_u32 v148, v147, v148, 0x7fff                        // 00000004A76C: D6550094 03FF2993 00007FFF
	ds_store_b16_d16_hi v166, v148 offset:12                   // 00000004A778: DA84000C 000094A6
	s_and_saveexec_b32 s2, s29                                 // 00000004A780: BE82201D
	s_cbranch_execz 30                                         // 00000004A784: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f00>
	ds_load_b32 v146, v165 offset:28                           // 00000004A788: D8D8001C 920000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A790: BF89FC07
	v_sub_f32_e32 v146, v146, v131                             // 00000004A794: 09250792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A798: BF870121
	v_mul_f32_e32 v148, 0x3fb8aa3b, v146                       // 00000004A79C: 112924FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 00000004A7A4: 7C3724FF C2CE8ED0
	v_fma_f32 v149, 0x3fb8aa3b, v146, -v148                    // 00000004A7AC: D6130095 865324FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 00000004A7B8: 7F2C4794
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004A7BC: BF870112
	v_fmac_f32_e32 v149, 0x32a5705f, v146                      // 00000004A7C0: 572B24FF 32A5705F
	v_sub_f32_e32 v148, v148, v150                             // 00000004A7C8: 09292D94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A7CC: BF870121
	v_add_f32_e32 v148, v148, v149                             // 00000004A7D0: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 00000004A7D4: 7F2A1196
	v_exp_f32_e32 v148, v148                                   // 00000004A7D8: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A7DC: BF870095
	.long 0xd71c0094                                           // 00000004A7E0: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 00000004A7E4: 02032B94
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 00000004A7E8: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 00000004A7EC: 7C3D24FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004A7F4: BF870002
	v_cndmask_b32_e32 v146, 0x7f800000, v148, vcc_lo           // 00000004A7F8: 032528FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004A800: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A804: BF870121
	v_bfe_u32 v148, v146, 16, 1                                // 00000004A808: D6100094 02052192
	v_mov_b32_e32 v149, 0                                      // 00000004A810: 7F2A0280
	v_add3_u32 v150, v146, v148, 0x7fff                        // 00000004A814: D6550096 03FF2992 00007FFF
	v_mov_b32_e32 v148, 0                                      // 00000004A820: 7F280280
	ds_store_b16_d16_hi v166, v150 offset:14                   // 00000004A824: DA84000E 000096A6
	s_and_saveexec_b32 s2, s28                                 // 00000004A82C: BE82201C
	s_cbranch_execz 30                                         // 00000004A830: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1fac>
	ds_load_b32 v149, v165 offset:32                           // 00000004A834: D8D80020 950000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A83C: BF89FC07
	v_sub_f32_e32 v149, v149, v131                             // 00000004A840: 092B0795
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A844: BF870091
	v_mul_f32_e32 v150, 0x3fb8aa3b, v149                       // 00000004A848: 112D2AFF 3FB8AA3B
	v_fma_f32 v151, 0x3fb8aa3b, v149, -v150                    // 00000004A850: D6130097 865B2AFF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 00000004A85C: 7F304796
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004A860: BF870221
	v_sub_f32_e32 v150, v150, v152                             // 00000004A864: 092D3196
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 00000004A868: 7C372AFF C2CE8ED0
	v_fmac_f32_e32 v151, 0x32a5705f, v149                      // 00000004A870: 572F2AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A878: BF870121
	v_add_f32_e32 v150, v150, v151                             // 00000004A87C: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 00000004A880: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 00000004A884: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A888: BF870095
	.long 0xd71c0096                                           // 00000004A88C: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 00000004A890: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 00000004A894: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 00000004A898: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004A8A0: BF870002
	v_cndmask_b32_e32 v149, 0x7f800000, v150, vcc_lo           // 00000004A8A4: 032B2CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004A8AC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A8B0: BF870091
	v_bfe_u32 v150, v149, 16, 1                                // 00000004A8B4: D6100096 02052195
	v_add3_u32 v150, v149, v150, 0x7fff                        // 00000004A8BC: D6550096 03FF2D95 00007FFF
	ds_store_b16_d16_hi v166, v150 offset:16                   // 00000004A8C8: DA840010 000096A6
	s_and_saveexec_b32 s2, s27                                 // 00000004A8D0: BE82201B
	s_cbranch_execz 30                                         // 00000004A8D4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2050>
	ds_load_b32 v148, v165 offset:36                           // 00000004A8D8: D8D80024 940000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A8E0: BF89FC07
	v_sub_f32_e32 v148, v148, v131                             // 00000004A8E4: 09290794
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A8E8: BF870121
	v_mul_f32_e32 v150, 0x3fb8aa3b, v148                       // 00000004A8EC: 112D28FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v148                 // 00000004A8F4: 7C3728FF C2CE8ED0
	v_fma_f32 v151, 0x3fb8aa3b, v148, -v150                    // 00000004A8FC: D6130097 865B28FF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 00000004A908: 7F304796
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004A90C: BF870112
	v_fmac_f32_e32 v151, 0x32a5705f, v148                      // 00000004A910: 572F28FF 32A5705F
	v_sub_f32_e32 v150, v150, v152                             // 00000004A918: 092D3196
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A91C: BF870121
	v_add_f32_e32 v150, v150, v151                             // 00000004A920: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 00000004A924: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 00000004A928: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A92C: BF870095
	.long 0xd71c0096                                           // 00000004A930: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 00000004A934: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 00000004A938: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v148                 // 00000004A93C: 7C3D28FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004A944: BF870002
	v_cndmask_b32_e32 v148, 0x7f800000, v150, vcc_lo           // 00000004A948: 03292CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004A950: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A954: BF870121
	v_bfe_u32 v150, v148, 16, 1                                // 00000004A958: D6100096 02052194
	v_mov_b32_e32 v151, 0                                      // 00000004A960: 7F2E0280
	v_add3_u32 v152, v148, v150, 0x7fff                        // 00000004A964: D6550098 03FF2D94 00007FFF
	v_mov_b32_e32 v150, 0                                      // 00000004A970: 7F2C0280
	ds_store_b16_d16_hi v166, v152 offset:18                   // 00000004A974: DA840012 000098A6
	s_and_saveexec_b32 s2, s26                                 // 00000004A97C: BE82201A
	s_cbranch_execz 30                                         // 00000004A980: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x20fc>
	ds_load_b32 v151, v165 offset:40                           // 00000004A984: D8D80028 970000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004A98C: BF89FC07
	v_sub_f32_e32 v151, v151, v131                             // 00000004A990: 092F0797
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A994: BF870091
	v_mul_f32_e32 v152, 0x3fb8aa3b, v151                       // 00000004A998: 11312EFF 3FB8AA3B
	v_fma_f32 v153, 0x3fb8aa3b, v151, -v152                    // 00000004A9A0: D6130099 86632EFF 3FB8AA3B
	v_rndne_f32_e32 v178, v152                                 // 00000004A9AC: 7F644798
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004A9B0: BF870221
	v_sub_f32_e32 v152, v152, v178                             // 00000004A9B4: 09316598
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 00000004A9B8: 7C372EFF C2CE8ED0
	v_fmac_f32_e32 v153, 0x32a5705f, v151                      // 00000004A9C0: 57332EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004A9C8: BF870121
	v_add_f32_e32 v152, v152, v153                             // 00000004A9CC: 07313398
	v_cvt_i32_f32_e32 v153, v178                               // 00000004A9D0: 7F3211B2
	v_exp_f32_e32 v152, v152                                   // 00000004A9D4: 7F304B98
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004A9D8: BF870095
	.long 0xd71c0098                                           // 00000004A9DC: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 00000004A9E0: 02033398
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 00000004A9E4: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 00000004A9E8: 7C3D2EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004A9F0: BF870002
	v_cndmask_b32_e32 v151, 0x7f800000, v152, vcc_lo           // 00000004A9F4: 032F30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004A9FC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004AA00: BF870091
	v_bfe_u32 v152, v151, 16, 1                                // 00000004AA04: D6100098 02052197
	v_add3_u32 v152, v151, v152, 0x7fff                        // 00000004AA0C: D6550098 03FF3197 00007FFF
	ds_store_b16_d16_hi v166, v152 offset:20                   // 00000004AA18: DA840014 000098A6
	s_and_saveexec_b32 s2, s25                                 // 00000004AA20: BE822019
	s_cbranch_execz 30                                         // 00000004AA24: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21a0>
	ds_load_b32 v150, v165 offset:44                           // 00000004AA28: D8D8002C 960000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004AA30: BF89FC07
	v_sub_f32_e32 v150, v150, v131                             // 00000004AA34: 092D0796
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004AA38: BF870121
	v_mul_f32_e32 v152, 0x3fb8aa3b, v150                       // 00000004AA3C: 11312CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 00000004AA44: 7C372CFF C2CE8ED0
	v_fma_f32 v153, 0x3fb8aa3b, v150, -v152                    // 00000004AA4C: D6130099 86632CFF 3FB8AA3B
	v_rndne_f32_e32 v178, v152                                 // 00000004AA58: 7F644798
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004AA5C: BF870112
	v_fmac_f32_e32 v153, 0x32a5705f, v150                      // 00000004AA60: 57332CFF 32A5705F
	v_sub_f32_e32 v152, v152, v178                             // 00000004AA68: 09316598
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004AA6C: BF870121
	v_add_f32_e32 v152, v152, v153                             // 00000004AA70: 07313398
	v_cvt_i32_f32_e32 v153, v178                               // 00000004AA74: 7F3211B2
	v_exp_f32_e32 v152, v152                                   // 00000004AA78: 7F304B98
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004AA7C: BF870095
	.long 0xd71c0098                                           // 00000004AA80: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 00000004AA84: 02033398
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 00000004AA88: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 00000004AA8C: 7C3D2CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004AA94: BF870002
	v_cndmask_b32_e32 v150, 0x7f800000, v152, vcc_lo           // 00000004AA98: 032D30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004AAA0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004AAA4: BF870121
	v_bfe_u32 v152, v150, 16, 1                                // 00000004AAA8: D6100098 02052196
	v_mov_b32_e32 v153, 0                                      // 00000004AAB0: 7F320280
	v_add3_u32 v178, v150, v152, 0x7fff                        // 00000004AAB4: D65500B2 03FF3196 00007FFF
	v_mov_b32_e32 v152, 0                                      // 00000004AAC0: 7F300280
	ds_store_b16_d16_hi v166, v178 offset:22                   // 00000004AAC4: DA840016 0000B2A6
	s_and_saveexec_b32 s2, s24                                 // 00000004AACC: BE822018
	s_cbranch_execz 30                                         // 00000004AAD0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x224c>
	ds_load_b32 v153, v165 offset:48                           // 00000004AAD4: D8D80030 990000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004AADC: BF89FC07
	v_sub_f32_e32 v153, v153, v131                             // 00000004AAE0: 09330799
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004AAE4: BF870091
	v_mul_f32_e32 v178, 0x3fb8aa3b, v153                       // 00000004AAE8: 116532FF 3FB8AA3B
	v_fma_f32 v179, 0x3fb8aa3b, v153, -v178                    // 00000004AAF0: D61300B3 86CB32FF 3FB8AA3B
	v_rndne_f32_e32 v180, v178                                 // 00000004AAFC: 7F6847B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004AB00: BF870221
	v_sub_f32_e32 v178, v178, v180                             // 00000004AB04: 096569B2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 00000004AB08: 7C3732FF C2CE8ED0
	v_fmac_f32_e32 v179, 0x32a5705f, v153                      // 00000004AB10: 576732FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004AB18: BF870121
	v_add_f32_e32 v178, v178, v179                             // 00000004AB1C: 076567B2
	v_cvt_i32_f32_e32 v179, v180                               // 00000004AB20: 7F6611B4
	v_exp_f32_e32 v178, v178                                   // 00000004AB24: 7F644BB2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004AB28: BF870095
	.long 0xd71c00b2                                           // 00000004AB2C: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 00000004AB30: 020367B2
	v_cndmask_b32_e32 v178, 0, v178, vcc_lo                    // 00000004AB34: 03656480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 00000004AB38: 7C3D32FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004AB40: BF870002
	v_cndmask_b32_e32 v153, 0x7f800000, v178, vcc_lo           // 00000004AB44: 033364FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004AB4C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004AB50: BF870091
	v_bfe_u32 v178, v153, 16, 1                                // 00000004AB54: D61000B2 02052199
	v_add3_u32 v178, v153, v178, 0x7fff                        // 00000004AB5C: D65500B2 03FF6599 00007FFF
	ds_store_b16_d16_hi v166, v178 offset:24                   // 00000004AB68: DA840018 0000B2A6
	s_and_saveexec_b32 s2, s9                                  // 00000004AB70: BE822009
	s_cbranch_execz 30                                         // 00000004AB74: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x22f0>
	ds_load_b32 v152, v165 offset:52                           // 00000004AB78: D8D80034 980000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004AB80: BF89FC07
	v_sub_f32_e32 v152, v152, v131                             // 00000004AB84: 09310798
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004AB88: BF870121
	v_mul_f32_e32 v178, 0x3fb8aa3b, v152                       // 00000004AB8C: 116530FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 00000004AB94: 7C3730FF C2CE8ED0
	v_fma_f32 v179, 0x3fb8aa3b, v152, -v178                    // 00000004AB9C: D61300B3 86CB30FF 3FB8AA3B
	v_rndne_f32_e32 v180, v178                                 // 00000004ABA8: 7F6847B2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004ABAC: BF870112
	v_fmac_f32_e32 v179, 0x32a5705f, v152                      // 00000004ABB0: 576730FF 32A5705F
	v_sub_f32_e32 v178, v178, v180                             // 00000004ABB8: 096569B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004ABBC: BF870121
	v_add_f32_e32 v178, v178, v179                             // 00000004ABC0: 076567B2
	v_cvt_i32_f32_e32 v179, v180                               // 00000004ABC4: 7F6611B4
	v_exp_f32_e32 v178, v178                                   // 00000004ABC8: 7F644BB2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ABCC: BF870095
	.long 0xd71c00b2                                           // 00000004ABD0: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 00000004ABD4: 020367B2
	v_cndmask_b32_e32 v178, 0, v178, vcc_lo                    // 00000004ABD8: 03656480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 00000004ABDC: 7C3D30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004ABE4: BF870002
	v_cndmask_b32_e32 v152, 0x7f800000, v178, vcc_lo           // 00000004ABE8: 033164FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004ABF0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004ABF4: BF870121
	v_bfe_u32 v178, v152, 16, 1                                // 00000004ABF8: D61000B2 02052198
	v_mov_b32_e32 v179, 0                                      // 00000004AC00: 7F660280
	v_add3_u32 v180, v152, v178, 0x7fff                        // 00000004AC04: D65500B4 03FF6598 00007FFF
	v_mov_b32_e32 v178, 0                                      // 00000004AC10: 7F640280
	ds_store_b16_d16_hi v166, v180 offset:26                   // 00000004AC14: DA84001A 0000B4A6
	s_and_saveexec_b32 s2, s8                                  // 00000004AC1C: BE822008
	s_cbranch_execz 30                                         // 00000004AC20: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x239c>
	ds_load_b32 v179, v165 offset:56                           // 00000004AC24: D8D80038 B30000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004AC2C: BF89FC07
	v_sub_f32_e32 v179, v179, v131                             // 00000004AC30: 096707B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004AC34: BF870091
	v_mul_f32_e32 v180, 0x3fb8aa3b, v179                       // 00000004AC38: 116966FF 3FB8AA3B
	v_fma_f32 v181, 0x3fb8aa3b, v179, -v180                    // 00000004AC40: D61300B5 86D366FF 3FB8AA3B
	v_rndne_f32_e32 v182, v180                                 // 00000004AC4C: 7F6C47B4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004AC50: BF870221
	v_sub_f32_e32 v180, v180, v182                             // 00000004AC54: 09696DB4
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v179                 // 00000004AC58: 7C3766FF C2CE8ED0
	v_fmac_f32_e32 v181, 0x32a5705f, v179                      // 00000004AC60: 576B66FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004AC68: BF870121
	v_add_f32_e32 v180, v180, v181                             // 00000004AC6C: 07696BB4
	v_cvt_i32_f32_e32 v181, v182                               // 00000004AC70: 7F6A11B6
	v_exp_f32_e32 v180, v180                                   // 00000004AC74: 7F684BB4
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004AC78: BF870095
	.long 0xd71c00b4                                           // 00000004AC7C: D71C00B4
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                   // 00000004AC80: 02036BB4
	v_cndmask_b32_e32 v180, 0, v180, vcc_lo                    // 00000004AC84: 03696880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v179                 // 00000004AC88: 7C3D66FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004AC90: BF870002
	v_cndmask_b32_e32 v179, 0x7f800000, v180, vcc_lo           // 00000004AC94: 036768FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004AC9C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ACA0: BF870091
	v_bfe_u32 v180, v179, 16, 1                                // 00000004ACA4: D61000B4 020521B3
	v_add3_u32 v180, v179, v180, 0x7fff                        // 00000004ACAC: D65500B4 03FF69B3 00007FFF
	ds_store_b16_d16_hi v166, v180 offset:28                   // 00000004ACB8: DA84001C 0000B4A6
	s_and_saveexec_b32 s2, s1                                  // 00000004ACC0: BE822001
	s_cbranch_execz 30                                         // 00000004ACC4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2440>
	ds_load_b32 v178, v165 offset:60                           // 00000004ACC8: D8D8003C B20000A5
	s_waitcnt lgkmcnt(0)                                       // 00000004ACD0: BF89FC07
	v_sub_f32_e32 v178, v178, v131                             // 00000004ACD4: 096507B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004ACD8: BF870121
	v_mul_f32_e32 v180, 0x3fb8aa3b, v178                       // 00000004ACDC: 116964FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v178                 // 00000004ACE4: 7C3764FF C2CE8ED0
	v_fma_f32 v181, 0x3fb8aa3b, v178, -v180                    // 00000004ACEC: D61300B5 86D364FF 3FB8AA3B
	v_rndne_f32_e32 v182, v180                                 // 00000004ACF8: 7F6C47B4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004ACFC: BF870112
	v_fmac_f32_e32 v181, 0x32a5705f, v178                      // 00000004AD00: 576B64FF 32A5705F
	v_sub_f32_e32 v180, v180, v182                             // 00000004AD08: 09696DB4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004AD0C: BF870121
	v_add_f32_e32 v180, v180, v181                             // 00000004AD10: 07696BB4
	v_cvt_i32_f32_e32 v181, v182                               // 00000004AD14: 7F6A11B6
	v_exp_f32_e32 v180, v180                                   // 00000004AD18: 7F684BB4
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004AD1C: BF870095
	.long 0xd71c00b4                                           // 00000004AD20: D71C00B4
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                   // 00000004AD24: 02036BB4
	v_cndmask_b32_e32 v180, 0, v180, vcc_lo                    // 00000004AD28: 03696880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v178                 // 00000004AD2C: 7C3D64FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000004AD34: BF870002
	v_cndmask_b32_e32 v178, 0x7f800000, v180, vcc_lo           // 00000004AD38: 036568FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004AD40: 8C7E027E
	v_add_f32_e32 v132, v133, v132                             // 00000004AD44: 07090985
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004AD48: BF870122
	v_bfe_u32 v133, v178, 16, 1                                // 00000004AD4C: D6100085 020521B2
	s_mov_b32 s1, 0                                            // 00000004AD54: BE810080
	v_add_f32_e32 v132, v132, v135                             // 00000004AD58: 07090F84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004AD5C: BF870112
	v_add3_u32 v133, v178, v133, 0x7fff                        // 00000004AD60: D6550085 03FF0BB2 00007FFF
	v_add_f32_e32 v132, v132, v134                             // 00000004AD6C: 07090D84
	ds_store_b16_d16_hi v166, v133 offset:30                   // 00000004AD70: DA84001E 000085A6
	v_add_f32_e32 v132, v132, v137                             // 00000004AD78: 07091384
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004AD7C: BF870091
	v_add_f32_e32 v132, v132, v136                             // 00000004AD80: 07091184
	v_add_f32_e32 v132, v132, v147                             // 00000004AD84: 07092784
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004AD88: BF870091
	v_add_f32_e32 v132, v132, v146                             // 00000004AD8C: 07092584
	v_add_f32_e32 v132, v132, v149                             // 00000004AD90: 07092B84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004AD94: BF870091
	v_add_f32_e32 v132, v132, v148                             // 00000004AD98: 07092984
	v_add_f32_e32 v132, v132, v151                             // 00000004AD9C: 07092F84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ADA0: BF870091
	v_add_f32_e32 v132, v132, v150                             // 00000004ADA4: 07092D84
	v_add_f32_e32 v132, v132, v153                             // 00000004ADA8: 07093384
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ADAC: BF870091
	v_add_f32_e32 v132, v132, v152                             // 00000004ADB0: 07093184
	v_add_f32_e32 v132, v132, v179                             // 00000004ADB4: 07096784
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004ADB8: BF870001
	v_add_f32_e32 v132, v132, v178                             // 00000004ADBC: 07096584
	s_and_b32 vcc_lo, exec_lo, s1                              // 00000004ADC0: 8B6A017E
	s_cbranch_vccz 584                                         // 00000004ADC4: BFA30248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2de8>
	ds_load_2addr_b32 v[133:134], v165 offset1:1               // 00000004ADC8: D8DC0100 850000A5
	ds_load_2addr_b32 v[135:136], v165 offset0:2 offset1:3     // 00000004ADD0: D8DC0302 870000A5
	ds_load_2addr_b32 v[146:147], v165 offset0:4 offset1:5     // 00000004ADD8: D8DC0504 920000A5
	ds_load_2addr_b32 v[148:149], v165 offset0:6 offset1:7     // 00000004ADE0: D8DC0706 940000A5
	ds_load_2addr_b32 v[150:151], v165 offset0:8 offset1:9     // 00000004ADE8: D8DC0908 960000A5
	ds_load_2addr_b32 v[152:153], v165 offset0:10 offset1:11   // 00000004ADF0: D8DC0B0A 980000A5
	ds_load_2addr_b32 v[178:179], v165 offset0:12 offset1:13   // 00000004ADF8: D8DC0D0C B20000A5
	ds_load_2addr_b32 v[180:181], v165 offset0:14 offset1:15   // 00000004AE00: D8DC0F0E B40000A5
	.long 0xd59c4084                                           // 00000004AE08: D59C4084
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 00000004AE0C: 02010080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000004AE10: BF8700D1
	.long 0xd59c4889                                           // 00000004AE14: D59C4889
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000004AE18: 02010184
	.long 0xd59c48b6                                           // 00000004AE1C: D59C48B6
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000004AE20: 02010184
	s_waitcnt lgkmcnt(7)                                       // 00000004AE24: BF89FC77
	v_max3_f32 v131, v130, v133, v134                          // 00000004AE28: D61C0083 061B0B82
	s_waitcnt lgkmcnt(6)                                       // 00000004AE30: BF89FC67
	v_max3_f32 v131, v131, v135, v136                          // 00000004AE34: D61C0083 06230F83
	s_waitcnt lgkmcnt(5)                                       // 00000004AE3C: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004AE40: BF8700A1
	v_max3_f32 v131, v131, v146, v147                          // 00000004AE44: D61C0083 064F2583
	s_waitcnt lgkmcnt(4)                                       // 00000004AE4C: BF89FC47
	v_max3_f32 v131, v131, v148, v149                          // 00000004AE50: D61C0083 06572983
	s_waitcnt lgkmcnt(3)                                       // 00000004AE58: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004AE5C: BF8700A1
	v_max3_f32 v131, v131, v150, v151                          // 00000004AE60: D61C0083 065F2D83
	s_waitcnt lgkmcnt(2)                                       // 00000004AE68: BF89FC27
	v_max3_f32 v131, v131, v152, v153                          // 00000004AE6C: D61C0083 06673183
	s_waitcnt lgkmcnt(1)                                       // 00000004AE74: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004AE78: BF8700A1
	v_max3_f32 v131, v131, v178, v179                          // 00000004AE7C: D61C0083 06CF6583
	s_waitcnt lgkmcnt(0)                                       // 00000004AE84: BF89FC07
	v_max3_f32 v131, v131, v180, v181                          // 00000004AE88: D61C0083 06D76983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000004AE90: BF870241
	v_sub_f32_e32 v133, v133, v131                             // 00000004AE94: 090B0785
	v_sub_f32_e32 v134, v134, v131                             // 00000004AE98: 090D0786
	v_sub_f32_e32 v150, v150, v131                             // 00000004AE9C: 092D0796
	v_sub_f32_e32 v153, v153, v131                             // 00000004AEA0: 09330799
	v_dual_sub_f32 v152, v152, v131 :: v_dual_mul_f32 v183, 0x3fb8aa3b, v133// 00000004AEA4: C9470798 98B70AFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 00000004AEB0: BF870004
	v_mul_f32_e32 v184, 0x3fb8aa3b, v134                       // 00000004AEB4: 11710CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 00000004AEBC: 7C370AFF C2CE8ED0
	v_sub_f32_e32 v151, v151, v131                             // 00000004AEC4: 092F0797
	v_sub_f32_e32 v178, v178, v131                             // 00000004AEC8: 096507B2
	v_fma_f32 v191, 0x3fb8aa3b, v133, -v183                    // 00000004AECC: D61300BF 86DF0AFF 3FB8AA3B
	v_rndne_f32_e32 v194, v184                                 // 00000004AED8: 7F8447B8
	v_sub_f32_e32 v149, v149, v131                             // 00000004AEDC: 092B0795
	v_fma_f32 v193, 0x3fb8aa3b, v134, -v184                    // 00000004AEE0: D61300C1 86E30CFF 3FB8AA3B
	v_rndne_f32_e32 v192, v183                                 // 00000004AEEC: 7F8047B7
	v_dual_sub_f32 v148, v148, v131 :: v_dual_fmac_f32 v191, 0x32a5705f, v133// 00000004AEF0: C9410794 94BF0AFF 32A5705F
	v_sub_f32_e32 v184, v184, v194                             // 00000004AEFC: 097185B8
	v_dual_sub_f32 v136, v136, v131 :: v_dual_mul_f32 v189, 0x3fb8aa3b, v149// 00000004AF00: C9470788 88BD2AFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000004AF0C: BF8701A4
	v_dual_sub_f32 v146, v146, v131 :: v_dual_sub_f32 v183, v183, v192// 00000004AF10: C94B0792 92B781B7
	v_cvt_i32_f32_e32 v192, v192                               // 00000004AF18: 7F8011C0
	v_mul_f32_e32 v185, 0x3fb8aa3b, v136                       // 00000004AF1C: 117310FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004AF24: BF870213
	v_dual_sub_f32 v135, v135, v131 :: v_dual_mul_f32 v188, 0x3fb8aa3b, v146// 00000004AF28: C9470787 87BD24FF 3FB8AA3B
	v_add_f32_e32 v183, v183, v191                             // 00000004AF34: 076F7FB7
	v_dual_sub_f32 v147, v147, v131 :: v_dual_mul_f32 v190, 0x3fb8aa3b, v148// 00000004AF38: C9470793 93BF28FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004AF44: BF870223
	v_mul_f32_e32 v186, 0x3fb8aa3b, v135                       // 00000004AF48: 11750EFF 3FB8AA3B
	v_fma_f32 v195, 0x3fb8aa3b, v136, -v185                    // 00000004AF50: D61300C3 86E710FF 3FB8AA3B
	v_exp_f32_e32 v183, v183                                   // 00000004AF5C: 7F6E4BB7
	v_fma_f32 v201, 0x3fb8aa3b, v146, -v188                    // 00000004AF60: D61300C9 86F324FF 3FB8AA3B
	v_rndne_f32_e32 v202, v188                                 // 00000004AF6C: 7F9447BC
	v_fma_f32 v197, 0x3fb8aa3b, v135, -v186                    // 00000004AF70: D61300C5 86EB0EFF 3FB8AA3B
	v_rndne_f32_e32 v198, v186                                 // 00000004AF7C: 7F8C47BA
	v_fmac_f32_e32 v195, 0x32a5705f, v136                      // 00000004AF80: 578710FF 32A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004AF88: BF870224
	v_dual_mul_f32 v187, 0x3fb8aa3b, v147 :: v_dual_sub_f32 v188, v188, v202// 00000004AF8C: C8CB26FF BBBD95BC 3FB8AA3B
	v_rndne_f32_e32 v196, v185                                 // 00000004AF98: 7F8847B9
	v_sub_f32_e32 v186, v186, v198                             // 00000004AF9C: 09758DBA
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000004AFA0: BF870005
	.long 0xd71c00b7                                           // 00000004AFA4: D71C00B7
	v_cndmask_b32_e32 v1, v183, v192, vcc_lo                   // 00000004AFA8: 020381B7
	v_cvt_i32_f32_e32 v194, v194                               // 00000004AFAC: 7F8411C2
	v_fma_f32 v199, 0x3fb8aa3b, v147, -v187                    // 00000004AFB0: D61300C7 86EF26FF 3FB8AA3B
	v_rndne_f32_e32 v200, v187                                 // 00000004AFBC: 7F9047BB
	v_cvt_i32_f32_e32 v198, v198                               // 00000004AFC0: 7F8C11C6
	v_cndmask_b32_e32 v183, 0, v183, vcc_lo                    // 00000004AFC4: 036F6E80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 00000004AFC8: 7C370CFF C2CE8ED0
	v_fmac_f32_e32 v201, 0x32a5705f, v146                      // 00000004AFD0: 579324FF 32A5705F
	v_fmac_f32_e32 v197, 0x32a5705f, v135                      // 00000004AFD8: 578B0EFF 32A5705F
	v_rndne_f32_e32 v206, v190                                 // 00000004AFE0: 7F9C47BE
	v_fmac_f32_e32 v199, 0x32a5705f, v147                      // 00000004AFE4: 578F26FF 32A5705F
	v_fma_f32 v205, 0x3fb8aa3b, v148, -v190                    // 00000004AFEC: D61300CD 86FB28FF 3FB8AA3B
	v_dual_add_f32 v188, v188, v201 :: v_dual_fmac_f32 v193, 0x32a5705f, v134// 00000004AFF8: C90193BC BCC10CFF 32A5705F
	v_dual_add_f32 v186, v186, v197 :: v_dual_sub_f32 v185, v185, v196// 00000004B004: C90B8BBA BAB989B9
	v_cvt_i32_f32_e32 v196, v196                               // 00000004B00C: 7F8811C4
	v_sub_f32_e32 v190, v190, v206                             // 00000004B010: 097D9DBE
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004B014: BF870214
	v_add_f32_e32 v184, v184, v193                             // 00000004B018: 077183B8
	v_exp_f32_e32 v186, v186                                   // 00000004B01C: 7F744BBA
	v_add_f32_e32 v185, v185, v195                             // 00000004B020: 077387B9
	v_exp_f32_e32 v188, v188                                   // 00000004B024: 7F784BBC
	v_cvt_i32_f32_e32 v202, v202                               // 00000004B028: 7F9411CA
	v_exp_f32_e32 v184, v184                                   // 00000004B02C: 7F704BB8
	v_fma_f32 v203, 0x3fb8aa3b, v149, -v189                    // 00000004B030: D61300CB 86F72AFF 3FB8AA3B
	v_exp_f32_e32 v185, v185                                   // 00000004B03C: 7F724BB9
	v_rndne_f32_e32 v204, v189                                 // 00000004B040: 7F9847BD
	v_sub_f32_e32 v180, v180, v131                             // 00000004B044: 096907B4
	.long 0xd71c00ba                                           // 00000004B048: D71C00BA
	v_cndmask_b32_e32 v1, v186, v198, vcc_lo                   // 00000004B04C: 02038DBA
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000004B050: BF870317
	.long 0xd71c00bc                                           // 00000004B054: D71C00BC
	v_cndmask_b32_e32 v1, v188, v202, vcc_lo                   // 00000004B058: 020395BC
	.long 0xd71c00b8                                           // 00000004B05C: D71C00B8
	v_cndmask_b32_e32 v1, v184, v194, vcc_lo                   // 00000004B060: 020385B8
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004B064: BF870115
	.long 0xd71c00b9                                           // 00000004B068: D71C00B9
	v_cndmask_b32_e32 v1, v185, v196, vcc_lo                   // 00000004B06C: 020389B9
	v_cndmask_b32_e32 v184, 0, v184, vcc_lo                    // 00000004B070: 03717080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 00000004B074: 7C3710FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000004B07C: BF870143
	v_cndmask_b32_e32 v185, 0, v185, vcc_lo                    // 00000004B080: 03737280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 00000004B084: 7C370EFF C2CE8ED0
	v_sub_f32_e32 v187, v187, v200                             // 00000004B08C: 097791BB
	v_cvt_i32_f32_e32 v200, v200                               // 00000004B090: 7F9011C8
	v_dual_cndmask_b32 v186, 0, v186 :: v_dual_add_f32 v187, v187, v199// 00000004B094: CA497480 BABB8FBB
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v147                 // 00000004B09C: 7C3726FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004B0A4: BF870292
	v_exp_f32_e32 v187, v187                                   // 00000004B0A8: 7F764BBB
	.long 0xd71c00bb                                           // 00000004B0AC: D71C00BB
	v_cndmask_b32_e32 v1, v187, v200, vcc_lo                   // 00000004B0B0: 020391BB
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000004B0B4: BF870141
	v_cndmask_b32_e32 v187, 0, v187, vcc_lo                    // 00000004B0B8: 03777680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 00000004B0BC: 7C3D0CFF 42B17218
	v_cndmask_b32_e32 v134, 0x7f800000, v184, vcc_lo           // 00000004B0C4: 030D70FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 00000004B0CC: 7C3D0AFF 42B17218
	.long 0xd59c0884                                           // 00000004B0D4: D59C0884
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 00000004B0D8: 02010186
	v_cndmask_b32_e32 v133, 0x7f800000, v183, vcc_lo           // 00000004B0DC: 030B6EFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 00000004B0E4: 7C3D0EFF 42B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000004B0EC: BF870193
	v_and_b32_e32 v184, 1, v132                                // 00000004B0F0: 37710881
	.long 0xd59c0889                                           // 00000004B0F4: D59C0889
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 00000004B0F8: 02010185
	v_cndmask_b32_e32 v135, 0x7f800000, v186, vcc_lo           // 00000004B0FC: 030F74FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 00000004B104: 7C3D10FF 42B17218
	v_add_f32_e32 v183, v133, v134                             // 00000004B10C: 076F0D85
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004B110: BF870214
	v_and_b32_e32 v137, 1, v137                                // 00000004B114: 37131281
	.long 0xd59c08b6                                           // 00000004B118: D59C08B6
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 00000004B11C: 02010187
	v_cndmask_b32_e32 v136, 0x7f800000, v185, vcc_lo           // 00000004B120: 031172FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 00000004B128: 7C3724FF C2CE8ED0
	v_fmac_f32_e32 v203, 0x32a5705f, v149                      // 00000004B130: 57972AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000004B138: BF870004
	v_dual_add_f32 v183, v183, v135 :: v_dual_and_b32 v182, 1, v182// 00000004B13C: C9250FB7 B7B76C81
	v_fmac_f32_e32 v205, 0x32a5705f, v148                      // 00000004B144: 579B28FF 32A5705F
	v_sub_f32_e32 v189, v189, v204                             // 00000004B14C: 097B99BD
	v_cndmask_b32_e32 v185, 0, v188, vcc_lo                    // 00000004B150: 03737880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 00000004B154: 7C3D24FF 42B17218
	.long 0xd59c0884                                           // 00000004B15C: D59C0884
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 00000004B160: 02010188
	v_add3_u32 v137, v133, v137, 0x7fff                        // 00000004B164: D6550089 03FF1385 00007FFF
	v_add3_u32 v133, v134, v184, 0x7fff                        // 00000004B170: D6550085 03FF7186 00007FFF
	v_add3_u32 v182, v135, v182, 0x7fff                        // 00000004B17C: D65500B6 03FF6D87 00007FFF
	v_cndmask_b32_e32 v135, 0x7f800000, v185, vcc_lo           // 00000004B188: 030F72FF 7F800000
	v_add_f32_e32 v184, v190, v205                             // 00000004B190: 07719BBE
	v_add_f32_e32 v146, v189, v203                             // 00000004B194: 072597BD
	v_and_b32_e32 v186, 1, v132                                // 00000004B198: 37750881
	.long 0xd59c48b9                                           // 00000004B19C: D59C48B9
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000004B1A0: 02010184
	.long 0xd59c08b9                                           // 00000004B1A4: D59C08B9
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 00000004B1A8: 02010187
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v147                 // 00000004B1AC: 7C3D26FF 42B17218
	v_exp_f32_e32 v146, v146                                   // 00000004B1B4: 7F244B92
	v_add3_u32 v134, v136, v186, 0x7fff                        // 00000004B1B8: D6550086 03FF7588 00007FFF
	v_exp_f32_e32 v184, v184                                   // 00000004B1C4: 7F704BB8
	v_add_f32_e32 v136, v183, v136                             // 00000004B1C8: 071111B7
	v_cvt_i32_f32_e32 v183, v204                               // 00000004B1CC: 7F6E11CC
	v_and_b32_e32 v185, 1, v185                                // 00000004B1D0: 37737281
	.long 0xd59c0885                                           // 00000004B1D4: D59C0885
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 00000004B1D8: 02010189
	.long 0xd59c0886                                           // 00000004B1DC: D59C0886
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                   // 00000004B1E0: 020101B6
	v_add_f32_e32 v136, v136, v135                             // 00000004B1E4: 07110F88
	s_delay_alu instid0(TRANS32_DEP_2)                         // 00000004B1E8: BF870006
	.long 0xd71c0092                                           // 00000004B1EC: D71C0092
	v_cndmask_b32_e32 v1, v146, v183, vcc_lo                   // 00000004B1F0: 02036F92
	v_add3_u32 v183, v135, v185, 0x7fff                        // 00000004B1F4: D65500B7 03FF7387 00007FFF
	.long 0xd59c48b9                                           // 00000004B200: D59C48B9
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000004B204: 02010184
	v_cndmask_b32_e32 v147, 0x7f800000, v187, vcc_lo           // 00000004B208: 032776FF 7F800000
	v_cvt_i32_f32_e32 v187, v206                               // 00000004B210: 7F7611CE
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 00000004B214: 7C372AFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000004B21C: BF870193
	.long 0xd59c0884                                           // 00000004B220: D59C0884
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 00000004B224: 02010193
	.long 0xd71c00b8                                           // 00000004B228: D71C00B8
	v_cndmask_b32_e32 v1, v184, v187, vcc_lo                   // 00000004B22C: 020377B8
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 00000004B230: 03252480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v148                 // 00000004B234: 7C3728FF C2CE8ED0
	v_add_f32_e32 v136, v136, v147                             // 00000004B23C: 07112788
	v_and_b32_e32 v186, 1, v132                                // 00000004B240: 37750881
	v_cndmask_b32_e32 v184, 0, v184, vcc_lo                    // 00000004B244: 03717080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 00000004B248: 7C3D2AFF 42B17218
	v_mul_f32_e32 v149, 0x3fb8aa3b, v151                       // 00000004B250: 112B2EFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000004B258: BF8701D4
	v_add3_u32 v135, v147, v186, 0x7fff                        // 00000004B25C: D6550087 03FF7593 00007FFF
	.long 0xd59c0887                                           // 00000004B268: D59C0887
	v_cndmask_b32_e32 v0, v183, v128, vcc_lo                   // 00000004B26C: 020101B7
	v_cndmask_b32_e32 v146, 0x7f800000, v146, vcc_lo           // 00000004B270: 032524FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v148                 // 00000004B278: 7C3D28FF 42B17218
	v_fma_f32 v148, 0x3fb8aa3b, v151, -v149                    // 00000004B280: D6130094 86572EFF 3FB8AA3B
	.long 0xd59c0884                                           // 00000004B28C: D59C0884
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                   // 00000004B290: 02010192
	v_cndmask_b32_e32 v147, 0x7f800000, v184, vcc_lo           // 00000004B294: 032770FF 7F800000
	v_rndne_f32_e32 v184, v149                                 // 00000004B29C: 7F704795
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000004B2A0: BF870194
	v_fmac_f32_e32 v148, 0x32a5705f, v151                      // 00000004B2A4: 57292EFF 32A5705F
	.long 0xd59c08b9                                           // 00000004B2AC: D59C08B9
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 00000004B2B0: 02010193
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004B2B4: BF870113
	v_dual_sub_f32 v149, v149, v184 :: v_dual_mul_f32 v186, 0x3fb8aa3b, v150// 00000004B2B8: C9477195 95BB2CFF 3FB8AA3B
	v_dual_add_f32 v187, v136, v147 :: v_dual_and_b32 v136, 1, v185// 00000004B2C4: C9252788 BB897281
	v_and_b32_e32 v185, 1, v132                                // 00000004B2CC: 37730881
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004B2D0: BF870213
	v_add_f32_e32 v148, v149, v148                             // 00000004B2D4: 07292995
	v_fma_f32 v149, 0x3fb8aa3b, v150, -v186                    // 00000004B2D8: D6130095 86EB2CFF 3FB8AA3B
	v_rndne_f32_e32 v188, v186                                 // 00000004B2E4: 7F7847BA
	v_add3_u32 v147, v147, v136, 0x7fff                        // 00000004B2E8: D6550093 03FF1193 00007FFF
	v_add3_u32 v136, v146, v185, 0x7fff                        // 00000004B2F4: D6550088 03FF7392 00007FFF
	v_exp_f32_e32 v148, v148                                   // 00000004B300: 7F284B94
	v_fmac_f32_e32 v149, 0x32a5705f, v150                      // 00000004B304: 572B2CFF 32A5705F
	v_sub_f32_e32 v185, v186, v188                             // 00000004B30C: 097379BA
	.long 0xd59c0888                                           // 00000004B310: D59C0888
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 00000004B314: 02010193
	v_cvt_i32_f32_e32 v147, v184                               // 00000004B318: 7F2611B8
	v_cvt_i32_f32_e32 v182, v188                               // 00000004B31C: 7F6C11BC
	s_delay_alu instid0(VALU_DEP_4)                            // 00000004B320: BF870004
	v_add_f32_e32 v149, v185, v149                             // 00000004B324: 072B2BB9
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 00000004B328: BF870185
	.long 0xd71c0089                                           // 00000004B32C: D71C0089
	v_cndmask_b32_e32 v1, v148, v147, vcc_lo                   // 00000004B330: 02032794
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000004B334: BF870132
	v_exp_f32_e32 v147, v149                                   // 00000004B338: 7F264B95
	v_dual_mul_f32 v149, 0x3fb8aa3b, v153 :: v_dual_mul_f32 v148, 0x3fb8aa3b, v152// 00000004B33C: C8C732FF 959530FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 00000004B348: 7C372EFF C2CE8ED0
	v_fma_f32 v185, 0x3fb8aa3b, v153, -v149                    // 00000004B350: D61300B9 865732FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 00000004B35C: BF8702B3
	v_fma_f32 v183, 0x3fb8aa3b, v152, -v148                    // 00000004B360: D61300B7 865330FF 3FB8AA3B
	v_cndmask_b32_e32 v137, 0, v137, vcc_lo                    // 00000004B36C: 03131280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 00000004B370: 7C372CFF C2CE8ED0
	.long 0xd71c0093                                           // 00000004B378: D71C0093
	v_cndmask_b32_e32 v1, v147, v182, vcc_lo                   // 00000004B37C: 02036D93
	v_rndne_f32_e32 v184, v148                                 // 00000004B380: 7F704794
	v_rndne_f32_e32 v186, v149                                 // 00000004B384: 7F744795
	v_fmac_f32_e32 v183, 0x32a5705f, v152                      // 00000004B388: 576F30FF 32A5705F
	v_fmac_f32_e32 v185, 0x32a5705f, v153                      // 00000004B390: 577332FF 32A5705F
	v_cndmask_b32_e32 v147, 0, v147, vcc_lo                    // 00000004B398: 03272680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 00000004B39C: 7C3D2EFF 42B17218
	v_dual_sub_f32 v148, v148, v184 :: v_dual_sub_f32 v149, v149, v186// 00000004B3A4: C94B7194 94957595
	v_cvt_i32_f32_e32 v151, v184                               // 00000004B3AC: 7F2E11B8
	v_cvt_i32_f32_e32 v182, v186                               // 00000004B3B0: 7F6C11BA
	v_cndmask_b32_e32 v137, 0x7f800000, v137, vcc_lo           // 00000004B3B4: 031312FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 00000004B3BC: 7C3D2CFF 42B17218
	v_dual_add_f32 v148, v148, v183 :: v_dual_add_f32 v149, v149, v185// 00000004B3C4: C9096F94 94957395
	.long 0xd59c4896                                           // 00000004B3CC: D59C4896
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000004B3D0: 02010184
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004B3D4: BF870224
	.long 0xd59c0884                                           // 00000004B3D8: D59C0884
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 00000004B3DC: 02010189
	v_cndmask_b32_e32 v147, 0x7f800000, v147, vcc_lo           // 00000004B3E0: 032726FF 7F800000
	v_exp_f32_e32 v148, v148                                   // 00000004B3E8: 7F284B94
	v_exp_f32_e32 v149, v149                                   // 00000004B3EC: 7F2A4B95
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 00000004B3F0: 7C3730FF C2CE8ED0
	v_and_b32_e32 v183, 1, v132                                // 00000004B3F8: 376F0881
	.long 0xd59c0896                                           // 00000004B3FC: D59C0896
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 00000004B400: 02010193
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 00000004B404: BF870321
	v_dual_mul_f32 v185, 0x3fb8aa3b, v180 :: v_dual_and_b32 v150, 1, v150// 00000004B408: C8E568FF B9972C81 3FB8AA3B
	v_add_f32_e32 v146, v187, v146                             // 00000004B414: 072525BB
	.long 0xd71c0094                                           // 00000004B418: D71C0094
	v_cndmask_b32_e32 v1, v148, v151, vcc_lo                   // 00000004B41C: 02032F94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004B420: BF870215
	.long 0xd71c0095                                           // 00000004B424: D71C0095
	v_cndmask_b32_e32 v1, v149, v182, vcc_lo                   // 00000004B428: 02036D95
	v_fma_f32 v187, 0x3fb8aa3b, v180, -v185                    // 00000004B42C: D61300BB 86E768FF 3FB8AA3B
	v_add3_u32 v150, v147, v150, 0x7fff                        // 00000004B438: D6550096 03FF2D93 00007FFF
	v_add_f32_e32 v146, v146, v147                             // 00000004B444: 07252792
	v_rndne_f32_e32 v188, v185                                 // 00000004B448: 7F7847B9
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000004B44C: BF870194
	v_fmac_f32_e32 v187, 0x32a5705f, v180                      // 00000004B450: 577768FF 32A5705F
	v_dual_add_f32 v151, v146, v137 :: v_dual_cndmask_b32 v146, 0, v148// 00000004B458: C9131392 97932880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 00000004B460: 7C3732FF C2CE8ED0
	v_dual_cndmask_b32 v148, 0, v149 :: v_dual_sub_f32 v149, v179, v131// 00000004B468: CA4B2A80 949507B3
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 00000004B470: 7C3D30FF 42B17218
	.long 0xd59c48b3                                           // 00000004B478: D59C48B3
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000004B47C: 02010184
	v_cndmask_b32_e32 v152, 0x7f800000, v146, vcc_lo           // 00000004B480: 033124FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 00000004B488: 7C3D32FF 42B17218
	v_mul_f32_e32 v153, 0x3fb8aa3b, v149                       // 00000004B490: 11332AFF 3FB8AA3B
	v_add3_u32 v146, v137, v183, 0x7fff                        // 00000004B498: D6550092 03FF6F89 00007FFF
	v_mul_f32_e32 v183, 0x3fb8aa3b, v178                       // 00000004B4A4: 116F64FF 3FB8AA3B
	v_add_f32_e32 v137, v151, v152                             // 00000004B4AC: 07133197
	.long 0xd59c08b3                                           // 00000004B4B0: D59C08B3
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                   // 00000004B4B4: 02010198
	v_fma_f32 v147, 0x3fb8aa3b, v149, -v153                    // 00000004B4B8: D6130093 86672AFF 3FB8AA3B
	v_rndne_f32_e32 v151, v153                                 // 00000004B4C4: 7F2E4799
	v_rndne_f32_e32 v184, v183                                 // 00000004B4C8: 7F7047B7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004B4CC: BF870214
	v_dual_cndmask_b32 v148, 0x7f800000, v148 :: v_dual_and_b32 v179, 1, v179// 00000004B4D0: CA6528FF 94B36681 7F800000
	v_fmac_f32_e32 v147, 0x32a5705f, v149                      // 00000004B4DC: 57272AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000004B4E4: BF870004
	v_sub_f32_e32 v153, v153, v151                             // 00000004B4E8: 09332F99
	v_cvt_i32_f32_e32 v151, v151                               // 00000004B4EC: 7F2E1197
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 00000004B4F0: 7C372AFF C2CE8ED0
	v_add3_u32 v152, v152, v179, 0x7fff                        // 00000004B4F8: D6550098 03FF6798 00007FFF
	.long 0xd59c0884                                           // 00000004B504: D59C0884
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                   // 00000004B508: 02010194
	v_add_f32_e32 v147, v153, v147                             // 00000004B50C: 07272799
	v_sub_f32_e32 v153, v181, v131                             // 00000004B510: 093307B5
	v_fma_f32 v181, 0x3fb8aa3b, v178, -v183                    // 00000004B514: D61300B5 86DF64FF 3FB8AA3B
	v_sub_f32_e32 v183, v183, v184                             // 00000004B520: 096F71B7
	v_add_f32_e32 v137, v137, v148                             // 00000004B524: 07132989
	v_exp_f32_e32 v147, v147                                   // 00000004B528: 7F264B93
	v_mul_f32_e32 v186, 0x3fb8aa3b, v153                       // 00000004B52C: 117532FF 3FB8AA3B
	v_dual_fmac_f32 v181, 0x32a5705f, v178 :: v_dual_and_b32 v182, 1, v132// 00000004B534: C82564FF B5B70881 32A5705F
	.long 0xd59c0892                                           // 00000004B540: D59C0892
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                   // 00000004B544: 02010196
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000004B548: BF870193
	v_fma_f32 v189, 0x3fb8aa3b, v153, -v186                    // 00000004B54C: D61300BD 86EB32FF 3FB8AA3B
	v_add_f32_e32 v181, v183, v181                             // 00000004B558: 076B6BB7
	v_sub_f32_e32 v183, v185, v188                             // 00000004B55C: 096F79B9
	v_rndne_f32_e32 v190, v186                                 // 00000004B560: 7F7C47BA
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000004B564: BF870005
	.long 0xd71c0093                                           // 00000004B568: D71C0093
	v_cndmask_b32_e32 v1, v147, v151, vcc_lo                   // 00000004B56C: 02032F93
	v_fmac_f32_e32 v189, 0x32a5705f, v153                      // 00000004B570: 577B32FF 32A5705F
	v_exp_f32_e32 v181, v181                                   // 00000004B578: 7F6A4BB5
	v_add_f32_e32 v179, v183, v187                             // 00000004B57C: 076777B7
	v_sub_f32_e32 v185, v186, v190                             // 00000004B580: 09737DBA
	v_cndmask_b32_e32 v147, 0, v147, vcc_lo                    // 00000004B584: 03272680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 00000004B588: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 00000004B590: BF870004
	v_exp_f32_e32 v151, v179                                   // 00000004B594: 7F2E4BB3
	v_cvt_i32_f32_e32 v179, v184                               // 00000004B598: 7F6611B8
	v_add_f32_e32 v183, v185, v189                             // 00000004B59C: 076F7BB9
	v_cvt_i32_f32_e32 v184, v188                               // 00000004B5A0: 7F7011BC
	v_cndmask_b32_e32 v149, 0x7f800000, v147, vcc_lo           // 00000004B5A4: 032B26FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v178                 // 00000004B5AC: 7C3764FF C2CE8ED0
	.long 0xd71c00b3                                           // 00000004B5B4: D71C00B3
	v_cndmask_b32_e32 v1, v181, v179, vcc_lo                   // 00000004B5B8: 020367B5
	v_exp_f32_e32 v183, v183                                   // 00000004B5BC: 7F6E4BB7
	v_cvt_i32_f32_e32 v181, v190                               // 00000004B5C0: 7F6A11BE
	.long 0xd59c0884                                           // 00000004B5C4: D59C0884
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                   // 00000004B5C8: 02010195
	.long 0xd71c0093                                           // 00000004B5CC: D71C0093
	v_cndmask_b32_e32 v1, v151, v184, vcc_lo                   // 00000004B5D0: 02037197
	v_cndmask_b32_e32 v151, 0, v179, vcc_lo                    // 00000004B5D4: 032F6680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v180                 // 00000004B5D8: 7C3768FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 00000004B5E0: BF8702A3
	v_cndmask_b32_e32 v147, 0, v147, vcc_lo                    // 00000004B5E4: 03272680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v178                 // 00000004B5E8: 7C3D64FF 42B17218
	.long 0xd71c00b3                                           // 00000004B5F0: D71C00B3
	v_cndmask_b32_e32 v1, v183, v181, vcc_lo                   // 00000004B5F4: 02036BB7
	v_cndmask_b32_e32 v151, 0x7f800000, v151, vcc_lo           // 00000004B5F8: 032F2EFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 00000004B600: 7C3732FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004B608: BF870212
	v_add_f32_e32 v137, v137, v151                             // 00000004B60C: 07132F89
	v_cndmask_b32_e32 v178, 0, v179, vcc_lo                    // 00000004B610: 03656680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v180                 // 00000004B614: 7C3D68FF 42B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000004B61C: BF870253
	v_dual_add_f32 v137, v137, v149 :: v_dual_and_b32 v180, 1, v132// 00000004B620: C9252B89 89B50881
	v_cndmask_b32_e32 v179, 0x7f800000, v147, vcc_lo           // 00000004B628: 036726FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 00000004B630: 7C3D32FF 42B17218
	.long 0xd59c0893                                           // 00000004B638: D59C0893
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                   // 00000004B63C: 02010197
	.long 0xd59c4893                                           // 00000004B640: D59C4893
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000004B644: 02010184
	v_add_f32_e32 v137, v137, v179                             // 00000004B648: 07136789
	v_cndmask_b32_e32 v153, 0x7f800000, v178, vcc_lo           // 00000004B64C: 033364FF 7F800000
	.long 0xd59c08b2                                           // 00000004B654: D59C08B2
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 00000004B658: 020101B3
	.long 0xd59c48b2                                           // 00000004B65C: D59C48B2
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000004B660: 02010184
	v_and_b32_e32 v181, 1, v147                                // 00000004B664: 376B2681
	v_add3_u32 v147, v148, v182, 0x7fff                        // 00000004B668: D6550093 03FF6D94 00007FFF
	.long 0xd59c0884                                           // 00000004B674: D59C0884
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                   // 00000004B678: 02010199
	v_add3_u32 v148, v149, v180, 0x7fff                        // 00000004B67C: D6550094 03FF6995 00007FFF
	v_and_b32_e32 v178, 1, v178                                // 00000004B688: 37656481
	v_add3_u32 v151, v151, v181, 0x7fff                        // 00000004B68C: D6550097 03FF6B97 00007FFF
	.long 0xd59c0893                                           // 00000004B698: D59C0893
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                   // 00000004B69C: 02010198
	v_and_b32_e32 v132, 1, v132                                // 00000004B6A0: 37090881
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004B6A4: BF870214
	v_add3_u32 v178, v179, v178, 0x7fff                        // 00000004B6A8: D65500B2 03FF65B3 00007FFF
	.long 0xd59c0894                                           // 00000004B6B4: D59C0894
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                   // 00000004B6B8: 02010197
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004B6BC: BF870223
	v_add3_u32 v149, v153, v132, 0x7fff                        // 00000004B6C0: D6550095 03FF0999 00007FFF
	v_add_f32_e32 v132, v137, v153                             // 00000004B6CC: 07093389
	.long 0xd59c0895                                           // 00000004B6D0: D59C0895
	v_cndmask_b32_e32 v0, v178, v128, vcc_lo                   // 00000004B6D4: 020101B2
	ds_store_b128 v166, v[133:136]                             // 00000004B6D8: DB7C0000 000085A6
	ds_store_b128 v166, v[146:149] offset:16                   // 00000004B6E0: DB7C0010 000092A6
	v_mov_b32_e32 v133, 0                                      // 00000004B6E8: 7F0A0280
	s_mov_b32 s1, exec_lo                                      // 00000004B6EC: BE81007E
	s_waitcnt lgkmcnt(0)                                       // 00000004B6F0: BF89FC07
	v_cmpx_lt_f32_e32 0xefa18f08, v130                         // 00000004B6F4: 7D2304FF EFA18F08
	s_cbranch_execz 26                                         // 00000004B6FC: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2e68>
	v_sub_f32_e32 v130, v130, v131                             // 00000004B700: 09050782
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004B704: BF870091
	v_mul_f32_e32 v133, 0x3fb8aa3b, v130                       // 00000004B708: 110B04FF 3FB8AA3B
	v_fma_f32 v134, 0x3fb8aa3b, v130, -v133                    // 00000004B710: D6130086 861704FF 3FB8AA3B
	v_rndne_f32_e32 v135, v133                                 // 00000004B71C: 7F0E4785
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004B720: BF870091
	v_dual_fmac_f32 v134, 0x32a5705f, v130 :: v_dual_sub_f32 v133, v133, v135// 00000004B724: C80B04FF 86850F85 32A5705F
	v_add_f32_e32 v133, v133, v134                             // 00000004B730: 070B0D85
	v_cvt_i32_f32_e32 v134, v135                               // 00000004B734: 7F0C1187
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 00000004B738: 7C3704FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004B740: BF870293
	v_exp_f32_e32 v133, v133                                   // 00000004B744: 7F0A4B85
	.long 0xd71c0085                                           // 00000004B748: D71C0085
	v_cndmask_b32_e32 v1, v133, v134, vcc_lo                   // 00000004B74C: 02030D85
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004B750: BF870121
	v_cndmask_b32_e32 v133, 0, v133, vcc_lo                    // 00000004B754: 030B0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 00000004B758: 7C3D04FF 42B17218
	v_cndmask_b32_e32 v133, 0x7f800000, v133, vcc_lo           // 00000004B760: 030B0AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000004B768: 8C7E017E
	ds_load_b32 v130, v167                                     // 00000004B76C: D8D80000 820000A7
	s_waitcnt lgkmcnt(0)                                       // 00000004B774: BF89FC07
	v_fmac_f32_e32 v132, v133, v130                            // 00000004B778: 57090585
	ds_store_b32 v164, v131                                    // 00000004B77C: D8340000 000083A4
	ds_store_b32 v167, v132                                    // 00000004B784: D8340000 000084A7
	ds_store_b32 v168, v133                                    // 00000004B78C: D8340000 000085A8
	s_or_b32 exec_lo, exec_lo, s4                              // 00000004B794: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 00000004B798: BF89FC07
	s_barrier                                                  // 00000004B79C: BFBD0000
	buffer_gl0_inv                                             // 00000004B7A0: E0AC0000 00000000
	ds_load_2addr_b32 v[152:153], v169 offset1:2               // 00000004B7A8: D8DC0200 980000A9
	ds_load_2addr_b32 v[150:151], v169 offset0:4 offset1:6     // 00000004B7B0: D8DC0604 960000A9
	ds_load_2addr_b32 v[148:149], v169 offset0:8 offset1:10    // 00000004B7B8: D8DC0A08 940000A9
	ds_load_2addr_b32 v[146:147], v169 offset0:12 offset1:14   // 00000004B7C0: D8DC0E0C 920000A9
	s_waitcnt lgkmcnt(3)                                       // 00000004B7C8: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v152                         // 00000004B7CC: 7C2530F2
	.long 0xd4120001                                           // 00000004B7D0: D4120001
	v_cndmask_b32_e32 v1, 1.0, v153, vcc_lo                    // 00000004B7D4: 020332F2
	s_waitcnt lgkmcnt(2)                                       // 00000004B7D8: BF89FC27
	.long 0xd4120002                                           // 00000004B7DC: D4120002
	v_cndmask_b32_e32 v1, 1.0, v150, vcc_lo                    // 00000004B7E0: 02032CF2
	.long 0xd4120004                                           // 00000004B7E4: D4120004
	v_cndmask_b32_e32 v1, 1.0, v151, vcc_lo                    // 00000004B7E8: 02032EF2
	s_and_b32 s1, vcc_lo, s1                                   // 00000004B7EC: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 00000004B7F0: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v148                         // 00000004B7F4: 7C2528F2
	s_and_b32 s2, s1, s2                                       // 00000004B7F8: 8B020201
	.long 0xd4120001                                           // 00000004B7FC: D4120001
	v_cndmask_b32_e32 v1, 1.0, v149, vcc_lo                    // 00000004B800: 02032AF2
	s_and_b32 s4, s2, s4                                       // 00000004B804: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 00000004B808: BF89FC07
	.long 0xd4120002                                           // 00000004B80C: D4120002
	v_cndmask_b32_e32 v1, 1.0, v146, vcc_lo                    // 00000004B810: 020324F2
	s_and_b32 s4, s4, vcc_lo                                   // 00000004B814: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v147                         // 00000004B818: 7C2526F2
	s_and_b32 s1, s4, s1                                       // 00000004B81C: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000004B820: BF870499
	s_and_b32 s1, s1, s2                                       // 00000004B824: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 00000004B828: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004B82C: BF870099
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 00000004B830: D5010082 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v130                           // 00000004B838: 7C9B0480
	ds_load_b128 v[130:133], v170                              // 00000004B83C: DBFC0000 820000AA
	ds_load_b128 v[134:137], v170 offset:16                    // 00000004B844: DBFC0010 860000AA
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 00000004B84C: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 00000004B850: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004B854: BF870099
	v_cndmask_b32_e64 v178, 0, 1, s1                           // 00000004B858: D50100B2 00050280
	v_readfirstlane_b32 s1, v178                               // 00000004B860: 7E0205B2
	s_bitcmp1_b32 s1, 0                                        // 00000004B864: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 00000004B868: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000004B86C: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 00000004B870: 8B6A017E
	s_cbranch_vccnz 62966                                      // 00000004B874: BFA4F5F6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x750>
	v_dual_mul_f32 v121, v152, v121 :: v_dual_mul_f32 v122, v153, v122// 00000004B878: C8C6F398 797AF599
	v_dual_mul_f32 v123, v150, v123 :: v_dual_mul_f32 v124, v151, v124// 00000004B880: C8C6F796 7B7CF997
	v_dual_mul_f32 v125, v148, v125 :: v_dual_mul_f32 v126, v149, v126// 00000004B888: C8C6FB94 7D7EFD95
	v_dual_mul_f32 v127, v146, v127 :: v_dual_mul_f32 v128, v147, v128// 00000004B890: C8C6FF92 7F810193
	v_dual_mul_f32 v113, v152, v113 :: v_dual_mul_f32 v114, v153, v114// 00000004B898: C8C6E398 7172E599
	v_dual_mul_f32 v115, v150, v115 :: v_dual_mul_f32 v116, v151, v116// 00000004B8A0: C8C6E796 7374E997
	v_dual_mul_f32 v117, v148, v117 :: v_dual_mul_f32 v118, v149, v118// 00000004B8A8: C8C6EB94 7576ED95
	v_dual_mul_f32 v119, v146, v119 :: v_dual_mul_f32 v120, v147, v120// 00000004B8B0: C8C6EF92 7778F193
	v_dual_mul_f32 v105, v152, v105 :: v_dual_mul_f32 v106, v153, v106// 00000004B8B8: C8C6D398 696AD599
	v_dual_mul_f32 v107, v150, v107 :: v_dual_mul_f32 v108, v151, v108// 00000004B8C0: C8C6D796 6B6CD997
	v_dual_mul_f32 v109, v148, v109 :: v_dual_mul_f32 v110, v149, v110// 00000004B8C8: C8C6DB94 6D6EDD95
	v_dual_mul_f32 v111, v146, v111 :: v_dual_mul_f32 v112, v147, v112// 00000004B8D0: C8C6DF92 6F70E193
	v_dual_mul_f32 v97, v152, v97 :: v_dual_mul_f32 v98, v153, v98// 00000004B8D8: C8C6C398 6162C599
	v_dual_mul_f32 v99, v150, v99 :: v_dual_mul_f32 v100, v151, v100// 00000004B8E0: C8C6C796 6364C997
	v_dual_mul_f32 v101, v148, v101 :: v_dual_mul_f32 v102, v149, v102// 00000004B8E8: C8C6CB94 6566CD95
	v_dual_mul_f32 v103, v146, v103 :: v_dual_mul_f32 v104, v147, v104// 00000004B8F0: C8C6CF92 6768D193
	v_dual_mul_f32 v89, v152, v89 :: v_dual_mul_f32 v90, v153, v90// 00000004B8F8: C8C6B398 595AB599
	v_dual_mul_f32 v91, v150, v91 :: v_dual_mul_f32 v92, v151, v92// 00000004B900: C8C6B796 5B5CB997
	v_dual_mul_f32 v93, v148, v93 :: v_dual_mul_f32 v94, v149, v94// 00000004B908: C8C6BB94 5D5EBD95
	v_dual_mul_f32 v95, v146, v95 :: v_dual_mul_f32 v96, v147, v96// 00000004B910: C8C6BF92 5F60C193
	v_dual_mul_f32 v81, v152, v81 :: v_dual_mul_f32 v82, v153, v82// 00000004B918: C8C6A398 5152A599
	v_dual_mul_f32 v83, v150, v83 :: v_dual_mul_f32 v84, v151, v84// 00000004B920: C8C6A796 5354A997
	v_dual_mul_f32 v85, v148, v85 :: v_dual_mul_f32 v86, v149, v86// 00000004B928: C8C6AB94 5556AD95
	v_dual_mul_f32 v87, v146, v87 :: v_dual_mul_f32 v88, v147, v88// 00000004B930: C8C6AF92 5758B193
	v_dual_mul_f32 v73, v152, v73 :: v_dual_mul_f32 v74, v153, v74// 00000004B938: C8C69398 494A9599
	v_dual_mul_f32 v75, v150, v75 :: v_dual_mul_f32 v76, v151, v76// 00000004B940: C8C69796 4B4C9997
	v_dual_mul_f32 v77, v148, v77 :: v_dual_mul_f32 v78, v149, v78// 00000004B948: C8C69B94 4D4E9D95
	v_dual_mul_f32 v79, v146, v79 :: v_dual_mul_f32 v80, v147, v80// 00000004B950: C8C69F92 4F50A193
	v_dual_mul_f32 v65, v152, v65 :: v_dual_mul_f32 v66, v153, v66// 00000004B958: C8C68398 41428599
	v_dual_mul_f32 v67, v150, v67 :: v_dual_mul_f32 v68, v151, v68// 00000004B960: C8C68796 43448997
	v_dual_mul_f32 v69, v148, v69 :: v_dual_mul_f32 v70, v149, v70// 00000004B968: C8C68B94 45468D95
	v_dual_mul_f32 v71, v146, v71 :: v_dual_mul_f32 v72, v147, v72// 00000004B970: C8C68F92 47489193
	v_dual_mul_f32 v57, v152, v57 :: v_dual_mul_f32 v58, v153, v58// 00000004B978: C8C67398 393A7599
	v_dual_mul_f32 v59, v150, v59 :: v_dual_mul_f32 v60, v151, v60// 00000004B980: C8C67796 3B3C7997
	v_dual_mul_f32 v61, v148, v61 :: v_dual_mul_f32 v62, v149, v62// 00000004B988: C8C67B94 3D3E7D95
	v_dual_mul_f32 v63, v146, v63 :: v_dual_mul_f32 v64, v147, v64// 00000004B990: C8C67F92 3F408193
	v_dual_mul_f32 v49, v152, v49 :: v_dual_mul_f32 v50, v153, v50// 00000004B998: C8C66398 31326599
	v_dual_mul_f32 v51, v150, v51 :: v_dual_mul_f32 v52, v151, v52// 00000004B9A0: C8C66796 33346997
	v_dual_mul_f32 v53, v148, v53 :: v_dual_mul_f32 v54, v149, v54// 00000004B9A8: C8C66B94 35366D95
	v_dual_mul_f32 v55, v146, v55 :: v_dual_mul_f32 v56, v147, v56// 00000004B9B0: C8C66F92 37387193
	v_dual_mul_f32 v41, v152, v41 :: v_dual_mul_f32 v42, v153, v42// 00000004B9B8: C8C65398 292A5599
	v_dual_mul_f32 v43, v150, v43 :: v_dual_mul_f32 v44, v151, v44// 00000004B9C0: C8C65796 2B2C5997
	v_dual_mul_f32 v45, v148, v45 :: v_dual_mul_f32 v46, v149, v46// 00000004B9C8: C8C65B94 2D2E5D95
	v_dual_mul_f32 v47, v146, v47 :: v_dual_mul_f32 v48, v147, v48// 00000004B9D0: C8C65F92 2F306193
	v_dual_mul_f32 v33, v152, v33 :: v_dual_mul_f32 v34, v153, v34// 00000004B9D8: C8C64398 21224599
	v_dual_mul_f32 v35, v150, v35 :: v_dual_mul_f32 v36, v151, v36// 00000004B9E0: C8C64796 23244997
	v_dual_mul_f32 v37, v148, v37 :: v_dual_mul_f32 v38, v149, v38// 00000004B9E8: C8C64B94 25264D95
	v_dual_mul_f32 v39, v146, v39 :: v_dual_mul_f32 v40, v147, v40// 00000004B9F0: C8C64F92 27285193
	v_dual_mul_f32 v25, v152, v25 :: v_dual_mul_f32 v26, v153, v26// 00000004B9F8: C8C63398 191A3599
	v_dual_mul_f32 v27, v150, v27 :: v_dual_mul_f32 v28, v151, v28// 00000004BA00: C8C63796 1B1C3997
	v_dual_mul_f32 v29, v148, v29 :: v_dual_mul_f32 v30, v149, v30// 00000004BA08: C8C63B94 1D1E3D95
	v_dual_mul_f32 v31, v146, v31 :: v_dual_mul_f32 v32, v147, v32// 00000004BA10: C8C63F92 1F204193
	v_dual_mul_f32 v17, v152, v17 :: v_dual_mul_f32 v18, v153, v18// 00000004BA18: C8C62398 11122599
	v_dual_mul_f32 v19, v150, v19 :: v_dual_mul_f32 v20, v151, v20// 00000004BA20: C8C62796 13142997
	v_dual_mul_f32 v21, v148, v21 :: v_dual_mul_f32 v22, v149, v22// 00000004BA28: C8C62B94 15162D95
	v_dual_mul_f32 v23, v146, v23 :: v_dual_mul_f32 v24, v147, v24// 00000004BA30: C8C62F92 17183193
	v_dual_mul_f32 v9, v152, v9 :: v_dual_mul_f32 v10, v153, v10// 00000004BA38: C8C61398 090A1599
	v_dual_mul_f32 v11, v150, v11 :: v_dual_mul_f32 v12, v151, v12// 00000004BA40: C8C61796 0B0C1997
	v_dual_mul_f32 v13, v148, v13 :: v_dual_mul_f32 v14, v149, v14// 00000004BA48: C8C61B94 0D0E1D95
	v_dual_mul_f32 v15, v146, v15 :: v_dual_mul_f32 v16, v147, v16// 00000004BA50: C8C61F92 0F102193
	v_dual_mul_f32 v1, v152, v1 :: v_dual_mul_f32 v2, v153, v2 // 00000004BA58: C8C60398 01020599
	v_dual_mul_f32 v3, v150, v3 :: v_dual_mul_f32 v4, v151, v4 // 00000004BA60: C8C60796 03040997
	v_dual_mul_f32 v5, v148, v5 :: v_dual_mul_f32 v6, v149, v6 // 00000004BA68: C8C60B94 05060D95
	v_dual_mul_f32 v7, v146, v7 :: v_dual_mul_f32 v8, v147, v8 // 00000004BA70: C8C60F92 07081193
	s_branch 62837                                             // 00000004BA78: BFA0F575 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x750>
	v_lshlrev_b32_e32 v0, 2, v157                              // 00000004BA7C: 30013A82
	.long 0xd700008b                                           // 00000004BA80: D700008B
	v_cndmask_b32_e32 v1, s18, v139, vcc_lo                    // 00000004BA84: 02031612
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000004BA88: BF870191
	v_add_co_ci_u32_e64 v140, null, s19, v140, s0              // 00000004BA8C: D5207C8C 00031813
	v_lshl_or_b32 v0, v156, 6, v0                              // 00000004BA94: D6560000 04010D9C
	v_lshlrev_b32_e32 v147, 1, v154                            // 00000004BA9C: 31273481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000004BAA0: BF870152
	v_add_nc_u32_e32 v133, 0xa000, v0                          // 00000004BAA4: 4B0A00FF 0000A000
	ds_load_2addr_b32 v[141:142], v133 offset0:128 offset1:130 // 00000004BAAC: D8DC8280 8D000085
	s_waitcnt lgkmcnt(0)                                       // 00000004BAB4: BF89FC07
	v_div_scale_f32 v143, null, v141, v141, 1.0                // 00000004BAB8: D6FC7C8F 03CB1B8D
	v_div_scale_f32 v145, vcc_lo, 1.0, v141, 1.0               // 00000004BAC0: D6FC6A91 03CB1AF2
	v_rcp_f32_e32 v144, v143                                   // 00000004BAC8: 7F20558F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000004BACC: BF870005
	v_fma_f32 v0, -v143, v144, 1.0                             // 00000004BAD0: D6130000 23CB218F
	v_lshlrev_b32_e32 v129, 9, v138                            // 00000004BAD8: 31031489
	ds_load_2addr_b32 v[137:138], v133 offset0:132 offset1:134 // 00000004BADC: D8DC8684 89000085
	ds_load_2addr_b32 v[135:136], v133 offset0:136 offset1:138 // 00000004BAE4: D8DC8A88 87000085
	ds_load_2addr_b32 v[133:134], v133 offset0:140 offset1:142 // 00000004BAEC: D8DC8E8C 85000085
	v_fmac_f32_e32 v144, v0, v144                              // 00000004BAF4: 57212100
	v_ashrrev_i32_e32 v130, 31, v129                           // 00000004BAF8: 3505029F
	v_or_b32_e32 v0, v155, v157                                // 00000004BAFC: 38013B9B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000004BB00: BF870193
	v_mul_f32_e32 v146, v145, v144                             // 00000004BB04: 11252191
	.long 0xd73c0083                                           // 00000004BB08: D73C0083
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 00000004BB0C: 02030281
	.long 0xd7000081                                           // 00000004BB10: D7000081
	v_cndmask_b32_e32 v1, v139, v147, vcc_lo                   // 00000004BB14: 0203278B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004BB18: BF870211
	v_add_co_ci_u32_e64 v130, null, 0, v140, s0                // 00000004BB1C: D5207C82 00031880
	v_fma_f32 v148, -v143, v146, v145                          // 00000004BB24: D6130094 2647258F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BB2C: BF870094
	.long 0xd7000083                                           // 00000004BB30: D7000083
	v_cndmask_b32_e32 v1, s16, v131, vcc_lo                    // 00000004BB34: 02030610
	v_add_co_ci_u32_e64 v132, null, s17, v132, s0              // 00000004BB38: D5207C84 00030811
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004BB40: BF870123
	v_fmac_f32_e32 v146, v148, v144                            // 00000004BB44: 57252194
	.long 0xd4440000                                           // 00000004BB48: D4440000
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 00000004BB4C: 0202000E
	v_fma_f32 v139, -v143, v146, v145                          // 00000004BB50: D613008B 2647258F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004BB58: BF8700A1
	v_div_fmas_f32 v139, v139, v144, v146                      // 00000004BB5C: D637008B 064B218B
	.long 0xd7006a83                                           // 00000004BB64: D7006A83
	v_cndmask_b32_e32 v1, v131, v147, vcc_lo                   // 00000004BB68: 02032783
	v_add_co_ci_u32_e64 v132, null, 0, v132, vcc_lo            // 00000004BB6C: D5207C84 01AB0880
	s_delay_alu instid0(VALU_DEP_3)                            // 00000004BB74: BF870003
	v_div_fixup_f32 v139, v139, v141, 1.0                      // 00000004BB78: D627008B 03CB1B8B
	s_and_saveexec_b32 s1, s0                                  // 00000004BB80: BE812000
	s_cbranch_execz 70                                         // 00000004BB84: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33a0>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004BB88: BF870112
	v_mad_i64_i32 v[140:141], null, 0x6000, v0, v[131:132]     // 00000004BB8C: D6FF7C8C 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 00000004BB98: 10F2F38B
	global_load_u16 v140, v[140:141], off offset:512           // 00000004BB9C: DC4A0200 8C7C008C
	s_waitcnt vmcnt(0)                                         // 00000004BBA4: BF8903F7
	v_lshlrev_b32_e32 v140, 16, v140                           // 00000004BBA8: 31191890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BBAC: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v140                       // 00000004BBB0: 111B18FF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v140, -v141                    // 00000004BBB8: D613008F 863718FF BFB8AA3B
	v_rndne_f32_e32 v144, v141                                 // 00000004BBC4: 7F20478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004BBC8: BF870112
	v_fmamk_f32 v143, v140, 0xb2a5705f, v143                   // 00000004BBCC: 591F1F8C B2A5705F
	v_sub_f32_e32 v141, v141, v144                             // 00000004BBD4: 091B218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000004BBD8: BF8701B1
	v_add_f32_e32 v141, v141, v143                             // 00000004BBDC: 071B1F8D
	v_cvt_i32_f32_e32 v143, v144                               // 00000004BBE0: 7F1E1190
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v140                 // 00000004BBE4: 7C3D18FF 42CE8ED0
	v_exp_f32_e32 v141, v141                                   // 00000004BBEC: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BBF0: BF870095
	.long 0xd71c008d                                           // 00000004BBF4: D71C008D
	v_cndmask_b32_e32 v1, v141, v143, vcc_lo                   // 00000004BBF8: 02031F8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 00000004BBFC: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v140                 // 00000004BC00: 7C3718FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BC08: BF870092
	v_cndmask_b32_e32 v140, 0x7f800000, v141, vcc_lo           // 00000004BC0C: 03191AFF 7F800000
	v_add_f32_e32 v140, 1.0, v140                              // 00000004BC14: 071918F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BC18: BF870091
	v_div_scale_f32 v141, null, v140, v140, v121               // 00000004BC1C: D6FC7C8D 05E7198C
	v_rcp_f32_e32 v143, v141                                   // 00000004BC24: 7F1E558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BC28: BF870095
	v_fma_f32 v144, -v141, v143, 1.0                           // 00000004BC2C: D6130090 23CB1F8D
	v_fmac_f32_e32 v143, v144, v143                            // 00000004BC34: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v140, v121             // 00000004BC38: D6FC6A90 05E71979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BC40: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000004BC44: 11231F90
	v_fma_f32 v146, -v141, v145, v144                          // 00000004BC48: D6130092 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BC50: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000004BC54: 57231F92
	v_fma_f32 v141, -v141, v145, v144                          // 00000004BC58: D613008D 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BC60: BF870091
	v_div_fmas_f32 v141, v141, v143, v145                      // 00000004BC64: D637008D 06471F8D
	v_div_fixup_f32 v121, v141, v140, v121                     // 00000004BC6C: D6270079 05E7198D
	v_mad_i64_i32 v[140:141], null, 0x3000, v0, v[129:130]     // 00000004BC74: D6FF7C8C 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BC80: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 00000004BC84: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 00000004BC8C: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[140:141], v121, off              // 00000004BC98: DC960000 007C798C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000004BCA0: 8C7E017E
	v_div_scale_f32 v121, null, v142, v142, 1.0                // 00000004BCA4: D6FC7C79 03CB1D8E
	v_div_scale_f32 v143, vcc_lo, 1.0, v142, 1.0               // 00000004BCAC: D6FC6A8F 03CB1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004BCB4: BF870292
	v_rcp_f32_e32 v140, v121                                   // 00000004BCB8: 7F185579
	v_fma_f32 v141, -v121, v140, 1.0                           // 00000004BCBC: D613008D 23CB1979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BCC4: BF870091
	v_fmac_f32_e32 v140, v141, v140                            // 00000004BCC8: 5719198D
	v_mul_f32_e32 v141, v143, v140                             // 00000004BCCC: 111B198F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BCD0: BF870091
	v_fma_f32 v144, -v121, v141, v143                          // 00000004BCD4: D6130090 263F1B79
	v_fmac_f32_e32 v141, v144, v140                            // 00000004BCDC: 571B1990
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BCE0: BF870091
	v_fma_f32 v121, -v121, v141, v143                          // 00000004BCE4: D6130079 263F1B79
	v_div_fmas_f32 v140, v121, v140, v141                      // 00000004BCEC: D637008C 06371979
	v_or_b32_e32 v121, 2, v0                                   // 00000004BCF4: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004BCF8: BF870112
	v_div_fixup_f32 v140, v140, v142, 1.0                      // 00000004BCFC: D627008C 03CB1D8C
	.long 0xd4440001                                           // 00000004BD04: D4440001
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 00000004BD08: 0202F20E
	s_and_saveexec_b32 s2, s1                                  // 00000004BD0C: BE822001
	s_cbranch_execz 69                                         // 00000004BD10: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3528>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 00000004BD14: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 00000004BD20: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 00000004BD24: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000004BD2C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000004BD30: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BD34: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000004BD38: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000004BD40: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000004BD4C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004BD50: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000004BD54: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000004BD58: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000004BD60: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004BD68: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000004BD6C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000004BD70: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000004BD74: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BD78: BF870095
	.long 0xd71c008e                                           // 00000004BD7C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000004BD80: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000004BD84: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000004BD88: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BD90: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000004BD94: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000004BD9C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BDA0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 00000004BDA4: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000004BDAC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BDB0: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000004BDB4: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000004BDBC: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 00000004BDC0: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BDC8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000004BDCC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000004BDD0: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BDD8: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000004BDDC: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000004BDE0: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BDE8: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000004BDEC: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 00000004BDF4: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 00000004BDFC: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BE08: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 00000004BE0C: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 00000004BE14: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 00000004BE20: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 00000004BE28: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 00000004BE2C: BF89FC27
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 00000004BE30: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 00000004BE38: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004BE40: BF870292
	v_rcp_f32_e32 v141, v122                                   // 00000004BE44: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 00000004BE48: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BE50: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000004BE54: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000004BE58: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BE5C: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 00000004BE60: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 00000004BE68: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BE6C: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 00000004BE70: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 00000004BE78: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 00000004BE80: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004BE84: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 00000004BE88: D6270089 03CB138D
	.long 0xd4440002                                           // 00000004BE90: D4440002
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 00000004BE94: 0202F40E
	s_and_saveexec_b32 s3, s2                                  // 00000004BE98: BE832002
	s_cbranch_execz 69                                         // 00000004BE9C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36b4>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 00000004BEA0: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 00000004BEAC: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 00000004BEB0: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000004BEB8: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000004BEBC: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BEC0: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000004BEC4: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000004BECC: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000004BED8: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004BEDC: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000004BEE0: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000004BEE4: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000004BEEC: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004BEF4: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000004BEF8: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000004BEFC: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000004BF00: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BF04: BF870095
	.long 0xd71c008e                                           // 00000004BF08: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000004BF0C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000004BF10: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000004BF14: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BF1C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000004BF20: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000004BF28: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BF2C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 00000004BF30: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000004BF38: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BF3C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000004BF40: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000004BF48: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 00000004BF4C: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BF54: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000004BF58: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000004BF5C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BF64: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000004BF68: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000004BF6C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BF74: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000004BF78: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 00000004BF80: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 00000004BF88: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BF94: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 00000004BF98: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 00000004BFA0: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 00000004BFAC: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004BFB4: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 00000004BFB8: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 00000004BFC0: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004BFC8: BF870292
	v_rcp_f32_e32 v141, v123                                   // 00000004BFCC: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 00000004BFD0: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BFD8: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000004BFDC: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000004BFE0: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BFE4: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 00000004BFE8: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 00000004BFF0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004BFF4: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 00000004BFF8: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 00000004C000: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 00000004C008: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004C00C: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 00000004C010: D627008A 03CB158D
	.long 0xd4440003                                           // 00000004C018: D4440003
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 00000004C01C: 0202F60E
	s_and_saveexec_b32 s4, s3                                  // 00000004C020: BE842003
	s_cbranch_execz 69                                         // 00000004C024: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x383c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 00000004C028: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 00000004C034: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 00000004C038: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000004C040: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000004C044: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C048: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000004C04C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000004C054: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000004C060: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004C064: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000004C068: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000004C06C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000004C074: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004C07C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000004C080: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000004C084: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000004C088: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C08C: BF870095
	.long 0xd71c008e                                           // 00000004C090: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000004C094: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000004C098: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000004C09C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C0A4: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000004C0A8: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000004C0B0: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C0B4: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 00000004C0B8: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 00000004C0C0: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C0C4: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000004C0C8: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000004C0D0: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 00000004C0D4: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C0DC: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000004C0E0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000004C0E4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C0EC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000004C0F0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000004C0F4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C0FC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000004C100: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 00000004C108: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 00000004C110: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C11C: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 00000004C120: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 00000004C128: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 00000004C134: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000004C13C: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 00000004C140: BF89FC17
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 00000004C144: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 00000004C14C: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004C154: BF870292
	v_rcp_f32_e32 v141, v124                                   // 00000004C158: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 00000004C15C: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C164: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000004C168: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000004C16C: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C170: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 00000004C174: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 00000004C17C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C180: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 00000004C184: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 00000004C18C: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 00000004C194: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004C198: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 00000004C19C: D6270087 03CB0F8D
	.long 0xd4440004                                           // 00000004C1A4: D4440004
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 00000004C1A8: 0202F80E
	s_and_saveexec_b32 s5, s4                                  // 00000004C1AC: BE852004
	s_cbranch_execz 69                                         // 00000004C1B0: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39c8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 00000004C1B4: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 00000004C1C0: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 00000004C1C4: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000004C1CC: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000004C1D0: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C1D4: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000004C1D8: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000004C1E0: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000004C1EC: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004C1F0: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000004C1F4: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000004C1F8: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000004C200: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004C208: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000004C20C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000004C210: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000004C214: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C218: BF870095
	.long 0xd71c008e                                           // 00000004C21C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000004C220: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000004C224: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000004C228: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C230: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000004C234: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000004C23C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C240: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 00000004C244: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 00000004C24C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C250: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000004C254: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000004C25C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 00000004C260: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C268: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000004C26C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000004C270: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C278: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000004C27C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000004C280: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C288: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000004C28C: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 00000004C294: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 00000004C29C: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C2A8: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 00000004C2AC: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 00000004C2B4: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 00000004C2C0: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 00000004C2C8: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 00000004C2CC: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 00000004C2D4: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004C2DC: BF870292
	v_rcp_f32_e32 v141, v125                                   // 00000004C2E0: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 00000004C2E4: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C2EC: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000004C2F0: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000004C2F4: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C2F8: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 00000004C2FC: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 00000004C304: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C308: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 00000004C30C: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 00000004C314: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 00000004C31C: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004C320: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 00000004C324: D6270088 03CB118D
	.long 0xd4440005                                           // 00000004C32C: D4440005
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 00000004C330: 0202FA0E
	s_and_saveexec_b32 s6, s5                                  // 00000004C334: BE862005
	s_cbranch_execz 69                                         // 00000004C338: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b50>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 00000004C33C: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 00000004C348: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 00000004C34C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000004C354: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000004C358: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C35C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000004C360: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000004C368: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000004C374: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004C378: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000004C37C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000004C380: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000004C388: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004C390: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000004C394: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000004C398: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000004C39C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C3A0: BF870095
	.long 0xd71c008e                                           // 00000004C3A4: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000004C3A8: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000004C3AC: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000004C3B0: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C3B8: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000004C3BC: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000004C3C4: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C3C8: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 00000004C3CC: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000004C3D4: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C3D8: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000004C3DC: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000004C3E4: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 00000004C3E8: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C3F0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000004C3F4: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000004C3F8: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C400: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000004C404: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000004C408: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C410: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000004C414: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 00000004C41C: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 00000004C424: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C430: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 00000004C434: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 00000004C43C: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 00000004C448: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 00000004C450: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000004C454: BF89FC07
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 00000004C458: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 00000004C460: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004C468: BF870292
	v_rcp_f32_e32 v141, v126                                   // 00000004C46C: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 00000004C470: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C478: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000004C47C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000004C480: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C484: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 00000004C488: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 00000004C490: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C494: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 00000004C498: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 00000004C4A0: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 00000004C4A8: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004C4AC: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 00000004C4B0: D6270085 03CB0B8D
	.long 0xd4440006                                           // 00000004C4B8: D4440006
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 00000004C4BC: 0202FC0E
	s_and_saveexec_b32 s7, s6                                  // 00000004C4C0: BE872006
	s_cbranch_execz 69                                         // 00000004C4C4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cdc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 00000004C4C8: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 00000004C4D4: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 00000004C4D8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000004C4E0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000004C4E4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C4E8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000004C4EC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000004C4F4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000004C500: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004C504: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000004C508: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000004C50C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000004C514: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004C51C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000004C520: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000004C524: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000004C528: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C52C: BF870095
	.long 0xd71c008e                                           // 00000004C530: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000004C534: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000004C538: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000004C53C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C544: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000004C548: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000004C550: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C554: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 00000004C558: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000004C560: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C564: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000004C568: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000004C570: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 00000004C574: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C57C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000004C580: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000004C584: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C58C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000004C590: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000004C594: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C59C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000004C5A0: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 00000004C5A8: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 00000004C5B0: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C5BC: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 00000004C5C0: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 00000004C5C8: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 00000004C5D4: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 00000004C5DC: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 00000004C5E0: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 00000004C5E8: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004C5F0: BF870292
	v_rcp_f32_e32 v141, v127                                   // 00000004C5F4: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 00000004C5F8: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C600: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000004C604: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000004C608: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C60C: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 00000004C610: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 00000004C618: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004C61C: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 00000004C620: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 00000004C628: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 00000004C630: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004C634: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 00000004C638: D6270086 03CB0D8D
	.long 0xd4440007                                           // 00000004C640: D4440007
	v_cndmask_b32_e32 v1, s14, v127, vcc_lo                    // 00000004C644: 0202FE0E
	s_and_saveexec_b32 s8, s7                                  // 00000004C648: BE882007
	s_cbranch_execnz 363                                       // 00000004C64C: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C650: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004C654: BE882000
	s_cbranch_execnz 432                                       // 00000004C658: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x441c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C65C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004C660: BE882001
	s_cbranch_execnz 501                                       // 00000004C664: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x453c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C668: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004C66C: BE882002
	s_cbranch_execnz 570                                       // 00000004C670: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x465c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C674: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004C678: BE882003
	s_cbranch_execnz 639                                       // 00000004C67C: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x477c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C680: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004C684: BE882004
	s_cbranch_execnz 708                                       // 00000004C688: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x489c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C68C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004C690: BE882005
	s_cbranch_execnz 777                                       // 00000004C694: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x49bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C698: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004C69C: BE882006
	s_cbranch_execnz 846                                       // 00000004C6A0: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4adc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C6A4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004C6A8: BE882007
	s_cbranch_execnz 915                                       // 00000004C6AC: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4bfc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C6B0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004C6B4: BE882000
	s_cbranch_execnz 984                                       // 00000004C6B8: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4d1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C6BC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004C6C0: BE882001
	s_cbranch_execnz 1053                                      // 00000004C6C4: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4e3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C6C8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004C6CC: BE882002
	s_cbranch_execnz 1122                                      // 00000004C6D0: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4f5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C6D4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004C6D8: BE882003
	s_cbranch_execnz 1191                                      // 00000004C6DC: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x507c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C6E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004C6E4: BE882004
	s_cbranch_execnz 1260                                      // 00000004C6E8: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x519c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C6EC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004C6F0: BE882005
	s_cbranch_execnz 1329                                      // 00000004C6F4: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x52bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C6F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004C6FC: BE882006
	s_cbranch_execnz 1398                                      // 00000004C700: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x53dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C704: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004C708: BE882007
	s_cbranch_execnz 1467                                      // 00000004C70C: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x54fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C710: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004C714: BE882000
	s_cbranch_execnz 1536                                      // 00000004C718: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x561c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C71C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004C720: BE882001
	s_cbranch_execnz 1605                                      // 00000004C724: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x573c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C728: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004C72C: BE882002
	s_cbranch_execnz 1674                                      // 00000004C730: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x585c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C734: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004C738: BE882003
	s_cbranch_execnz 1743                                      // 00000004C73C: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x597c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C740: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004C744: BE882004
	s_cbranch_execnz 1812                                      // 00000004C748: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5a9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C74C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004C750: BE882005
	s_cbranch_execnz 1881                                      // 00000004C754: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5bbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C758: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004C75C: BE882006
	s_cbranch_execnz 1950                                      // 00000004C760: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5cdc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C764: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004C768: BE882007
	s_cbranch_execnz 2019                                      // 00000004C76C: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5dfc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C770: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004C774: BE882000
	s_cbranch_execnz 2088                                      // 00000004C778: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5f1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C77C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004C780: BE882001
	s_cbranch_execnz 2157                                      // 00000004C784: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x603c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C788: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004C78C: BE882002
	s_cbranch_execnz 2226                                      // 00000004C790: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x615c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C794: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004C798: BE882003
	s_cbranch_execnz 2295                                      // 00000004C79C: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x627c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C7A0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004C7A4: BE882004
	s_cbranch_execnz 2364                                      // 00000004C7A8: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x639c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C7AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004C7B0: BE882005
	s_cbranch_execnz 2433                                      // 00000004C7B4: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x64bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C7B8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004C7BC: BE882006
	s_cbranch_execnz 2502                                      // 00000004C7C0: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x65dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C7C4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004C7C8: BE882007
	s_cbranch_execnz 2571                                      // 00000004C7CC: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x66fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C7D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004C7D4: BE882000
	s_cbranch_execnz 2640                                      // 00000004C7D8: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x681c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C7DC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004C7E0: BE882001
	s_cbranch_execnz 2709                                      // 00000004C7E4: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x693c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C7E8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004C7EC: BE882002
	s_cbranch_execnz 2778                                      // 00000004C7F0: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6a5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C7F4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004C7F8: BE882003
	s_cbranch_execnz 2847                                      // 00000004C7FC: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6b7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C800: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004C804: BE882004
	s_cbranch_execnz 2916                                      // 00000004C808: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6c9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C80C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004C810: BE882005
	s_cbranch_execnz 2985                                      // 00000004C814: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6dbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C818: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004C81C: BE882006
	s_cbranch_execnz 3054                                      // 00000004C820: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6edc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C824: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004C828: BE882007
	s_cbranch_execnz 3123                                      // 00000004C82C: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6ffc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C830: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004C834: BE882000
	s_cbranch_execnz 3192                                      // 00000004C838: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x711c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C83C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004C840: BE882001
	s_cbranch_execnz 3261                                      // 00000004C844: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x723c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C848: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004C84C: BE882002
	s_cbranch_execnz 3330                                      // 00000004C850: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x735c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C854: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004C858: BE882003
	s_cbranch_execnz 3399                                      // 00000004C85C: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x747c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C860: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004C864: BE882004
	s_cbranch_execnz 3468                                      // 00000004C868: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x759c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C86C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004C870: BE882005
	s_cbranch_execnz 3537                                      // 00000004C874: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x76bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C878: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004C87C: BE882006
	s_cbranch_execnz 3606                                      // 00000004C880: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x77dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C884: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004C888: BE882007
	s_cbranch_execnz 3675                                      // 00000004C88C: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x78fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C890: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004C894: BE882000
	s_cbranch_execnz 3744                                      // 00000004C898: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7a1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C89C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004C8A0: BE882001
	s_cbranch_execnz 3813                                      // 00000004C8A4: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7b3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C8A8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004C8AC: BE882002
	s_cbranch_execnz 3882                                      // 00000004C8B0: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7c5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C8B4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004C8B8: BE882003
	s_cbranch_execnz 3951                                      // 00000004C8BC: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7d7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C8C0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004C8C4: BE882004
	s_cbranch_execnz 4020                                      // 00000004C8C8: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7e9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C8CC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004C8D0: BE882005
	s_cbranch_execnz 4089                                      // 00000004C8D4: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7fbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C8D8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004C8DC: BE882006
	s_cbranch_execnz 4158                                      // 00000004C8E0: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x80dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C8E4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004C8E8: BE882007
	s_cbranch_execnz 4227                                      // 00000004C8EC: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x81fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C8F0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004C8F4: BE882000
	s_cbranch_execnz 4296                                      // 00000004C8F8: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x831c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C8FC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004C900: BE882001
	s_cbranch_execnz 4365                                      // 00000004C904: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x843c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C908: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004C90C: BE882002
	s_cbranch_execnz 4434                                      // 00000004C910: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x855c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C914: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004C918: BE882003
	s_cbranch_execnz 4503                                      // 00000004C91C: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x867c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C920: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004C924: BE882004
	s_cbranch_execnz 4572                                      // 00000004C928: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x879c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C92C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004C930: BE882005
	s_cbranch_execnz 4641                                      // 00000004C934: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x88bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C938: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004C93C: BE882006
	s_cbranch_execnz 4710                                      // 00000004C940: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x89dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C944: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004C948: BE882007
	s_cbranch_execnz 4779                                      // 00000004C94C: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8afc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C950: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004C954: BE882000
	s_cbranch_execnz 4848                                      // 00000004C958: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8c1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C95C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004C960: BE882001
	s_cbranch_execnz 4917                                      // 00000004C964: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8d3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C968: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004C96C: BE882002
	s_cbranch_execnz 4986                                      // 00000004C970: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8e5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C974: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004C978: BE882003
	s_cbranch_execnz 5055                                      // 00000004C97C: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8f7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C980: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004C984: BE882004
	s_cbranch_execnz 5124                                      // 00000004C988: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x909c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C98C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004C990: BE882005
	s_cbranch_execnz 5193                                      // 00000004C994: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x91bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C998: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004C99C: BE882006
	s_cbranch_execnz 5262                                      // 00000004C9A0: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x92dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C9A4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004C9A8: BE882007
	s_cbranch_execnz 5331                                      // 00000004C9AC: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x93fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C9B0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004C9B4: BE882000
	s_cbranch_execnz 5400                                      // 00000004C9B8: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x951c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C9BC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004C9C0: BE882001
	s_cbranch_execnz 5469                                      // 00000004C9C4: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x963c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C9C8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004C9CC: BE882002
	s_cbranch_execnz 5538                                      // 00000004C9D0: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x975c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C9D4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004C9D8: BE882003
	s_cbranch_execnz 5607                                      // 00000004C9DC: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x987c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C9E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004C9E4: BE882004
	s_cbranch_execnz 5676                                      // 00000004C9E8: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x999c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C9EC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004C9F0: BE882005
	s_cbranch_execnz 5745                                      // 00000004C9F4: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9abc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004C9F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004C9FC: BE882006
	s_cbranch_execnz 5814                                      // 00000004CA00: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9bdc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CA04: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004CA08: BE882007
	s_cbranch_execnz 5883                                      // 00000004CA0C: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9cfc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CA10: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004CA14: BE882000
	s_cbranch_execnz 5952                                      // 00000004CA18: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9e1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CA1C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004CA20: BE882001
	s_cbranch_execnz 6021                                      // 00000004CA24: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9f3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CA28: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004CA2C: BE882002
	s_cbranch_execnz 6090                                      // 00000004CA30: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa05c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CA34: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004CA38: BE882003
	s_cbranch_execnz 6159                                      // 00000004CA3C: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa17c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CA40: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004CA44: BE882004
	s_cbranch_execnz 6228                                      // 00000004CA48: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa29c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CA4C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004CA50: BE882005
	s_cbranch_execnz 6297                                      // 00000004CA54: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa3bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CA58: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004CA5C: BE882006
	s_cbranch_execnz 6366                                      // 00000004CA60: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa4dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CA64: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004CA68: BE882007
	s_cbranch_execnz 6435                                      // 00000004CA6C: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa5fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CA70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004CA74: BE882000
	s_cbranch_execnz 6504                                      // 00000004CA78: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa71c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CA7C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004CA80: BE882001
	s_cbranch_execnz 6573                                      // 00000004CA84: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa83c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CA88: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004CA8C: BE882002
	s_cbranch_execnz 6642                                      // 00000004CA90: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa95c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CA94: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004CA98: BE882003
	s_cbranch_execnz 6711                                      // 00000004CA9C: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaa7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CAA0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004CAA4: BE882004
	s_cbranch_execnz 6780                                      // 00000004CAA8: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xab9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CAAC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004CAB0: BE882005
	s_cbranch_execnz 6849                                      // 00000004CAB4: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xacbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CAB8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004CABC: BE882006
	s_cbranch_execnz 6918                                      // 00000004CAC0: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaddc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CAC4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004CAC8: BE882007
	s_cbranch_execnz 6987                                      // 00000004CACC: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaefc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CAD0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004CAD4: BE882000
	s_cbranch_execnz 7056                                      // 00000004CAD8: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb01c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CADC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004CAE0: BE882001
	s_cbranch_execnz 7125                                      // 00000004CAE4: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb13c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CAE8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004CAEC: BE882002
	s_cbranch_execnz 7194                                      // 00000004CAF0: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb25c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CAF4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004CAF8: BE882003
	s_cbranch_execnz 7263                                      // 00000004CAFC: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb37c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CB00: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004CB04: BE882004
	s_cbranch_execnz 7332                                      // 00000004CB08: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb49c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CB0C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004CB10: BE882005
	s_cbranch_execnz 7401                                      // 00000004CB14: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb5bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CB18: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004CB1C: BE882006
	s_cbranch_execnz 7470                                      // 00000004CB20: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb6dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CB24: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004CB28: BE882007
	s_cbranch_execnz 7539                                      // 00000004CB2C: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb7fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CB30: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004CB34: BE882000
	s_cbranch_execnz 7608                                      // 00000004CB38: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb91c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CB3C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004CB40: BE882001
	s_cbranch_execnz 7677                                      // 00000004CB44: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xba3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CB48: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004CB4C: BE882002
	s_cbranch_execnz 7746                                      // 00000004CB50: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbb5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CB54: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004CB58: BE882003
	s_cbranch_execnz 7815                                      // 00000004CB5C: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbc7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CB60: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004CB64: BE882004
	s_cbranch_execnz 7884                                      // 00000004CB68: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbd9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CB6C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004CB70: BE882005
	s_cbranch_execnz 7953                                      // 00000004CB74: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbebc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CB78: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004CB7C: BE882006
	s_cbranch_execnz 8022                                      // 00000004CB80: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbfdc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CB84: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004CB88: BE882007
	s_cbranch_execnz 8091                                      // 00000004CB8C: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc0fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CB90: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004CB94: BE882000
	s_cbranch_execnz 8160                                      // 00000004CB98: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc21c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CB9C: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 00000004CBA0: BE802001
	s_cbranch_execnz 8229                                      // 00000004CBA4: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc33c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000004CBA8: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 00000004CBAC: BE802002
	s_cbranch_execnz 8298                                      // 00000004CBB0: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc45c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000004CBB4: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 00000004CBB8: BE802003
	s_cbranch_execnz 8367                                      // 00000004CBBC: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc57c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000004CBC0: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000004CBC4: BE802004
	s_cbranch_execnz 8436                                      // 00000004CBC8: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc69c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000004CBCC: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000004CBD0: BE802005
	s_cbranch_execnz 8505                                      // 00000004CBD4: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc7bc>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000004CBD8: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000004CBDC: BE802006
	s_cbranch_execnz 8574                                      // 00000004CBE0: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc8dc>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000004CBE4: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000004CBE8: BE802007
	s_cbranch_execnz 8643                                      // 00000004CBEC: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc9fc>
	s_nop 0                                                    // 00000004CBF0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000004CBF4: BFB60003
	s_endpgm                                                   // 00000004CBF8: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 00000004CBFC: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 00000004CC08: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 00000004CC0C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000004CC14: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000004CC18: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CC1C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000004CC20: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000004CC28: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000004CC34: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004CC38: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000004CC3C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000004CC40: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000004CC48: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004CC50: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000004CC54: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000004CC58: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000004CC5C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CC60: BF870095
	.long 0xd71c008e                                           // 00000004CC64: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000004CC68: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000004CC6C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000004CC70: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CC78: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000004CC7C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000004CC84: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CC88: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 00000004CC8C: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 00000004CC94: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CC98: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000004CC9C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000004CCA4: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 00000004CCA8: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CCB0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000004CCB4: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000004CCB8: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CCC0: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000004CCC4: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000004CCC8: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CCD0: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000004CCD4: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 00000004CCDC: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 00000004CCE4: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CCF0: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 00000004CCF4: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 00000004CCFC: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 00000004CD08: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CD10: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004CD14: BE882000
	s_cbranch_execz 65104                                      // 00000004CD18: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d5c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 00000004CD1C: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 00000004CD28: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 00000004CD2C: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 00000004CD34: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 00000004CD38: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CD3C: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 00000004CD40: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 00000004CD48: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 00000004CD54: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004CD58: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 00000004CD5C: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 00000004CD60: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 00000004CD68: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004CD70: BF870121
	v_add_f32_e32 v141, v141, v142                             // 00000004CD74: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 00000004CD78: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 00000004CD7C: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CD80: BF870095
	.long 0xd71c008d                                           // 00000004CD84: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 00000004CD88: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 00000004CD8C: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 00000004CD90: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CD98: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 00000004CD9C: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 00000004CDA4: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CDA8: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 00000004CDAC: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 00000004CDB4: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CDB8: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 00000004CDBC: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 00000004CDC4: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 00000004CDC8: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CDD0: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 00000004CDD4: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 00000004CDD8: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CDE0: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 00000004CDE4: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 00000004CDE8: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CDF0: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 00000004CDF4: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 00000004CDFC: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 00000004CE04: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CE10: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 00000004CE14: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 00000004CE1C: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 00000004CE28: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CE30: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004CE34: BE882001
	s_cbranch_execz 65035                                      // 00000004CE38: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d68>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 00000004CE3C: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 00000004CE48: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 00000004CE4C: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 00000004CE54: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000004CE58: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CE5C: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 00000004CE60: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 00000004CE68: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 00000004CE74: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004CE78: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 00000004CE7C: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000004CE80: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 00000004CE88: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004CE90: BF870121
	v_add_f32_e32 v128, v128, v141                             // 00000004CE94: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 00000004CE98: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 00000004CE9C: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CEA0: BF870095
	.long 0xd71c0080                                           // 00000004CEA4: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 00000004CEA8: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 00000004CEAC: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000004CEB0: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CEB8: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 00000004CEBC: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000004CEC4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CEC8: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 00000004CECC: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 00000004CED4: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CED8: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 00000004CEDC: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 00000004CEE4: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 00000004CEE8: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CEF0: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 00000004CEF4: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 00000004CEF8: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CF00: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 00000004CF04: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 00000004CF08: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CF10: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 00000004CF14: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 00000004CF1C: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 00000004CF24: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CF30: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 00000004CF34: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 00000004CF3C: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 00000004CF48: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004CF50: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004CF54: BE882002
	s_cbranch_execz 64966                                      // 00000004CF58: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d74>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 00000004CF5C: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000004CF68: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000004CF70: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000004CF74: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CF78: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000004CF7C: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 00000004CF84: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 00000004CF90: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004CF94: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 00000004CF98: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 00000004CFA0: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000004CFA4: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 00000004CFA8: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 00000004CFAC: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000004CFB0: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 00000004CFB8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CFBC: BF870095
	.long 0xd71c0072                                           // 00000004CFC0: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 00000004CFC4: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000004CFC8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000004CFCC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CFD4: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 00000004CFD8: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000004CFE4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CFE8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000004CFEC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 00000004CFF4: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004CFF8: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 00000004CFFC: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 00000004D004: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 00000004D008: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D010: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 00000004D014: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 00000004D018: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D020: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 00000004D024: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 00000004D028: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D030: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 00000004D034: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000004D03C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 00000004D044: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D050: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 00000004D054: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 00000004D05C: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000004D068: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004D070: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004D074: BE882003
	s_cbranch_execz 64897                                      // 00000004D078: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d80>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 00000004D07C: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000004D088: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000004D090: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000004D094: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D098: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000004D09C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000004D0A4: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 00000004D0B0: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004D0B4: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 00000004D0B8: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000004D0BC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000004D0C4: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D0CC: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000004D0D0: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 00000004D0D4: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 00000004D0D8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D0DC: BF870095
	.long 0xd71c0072                                           // 00000004D0E0: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000004D0E4: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000004D0E8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000004D0EC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D0F4: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 00000004D0F8: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000004D104: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D108: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000004D10C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000004D114: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D118: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 00000004D11C: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 00000004D124: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 00000004D128: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D130: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 00000004D134: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 00000004D138: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D140: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 00000004D144: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 00000004D148: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D150: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 00000004D154: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000004D15C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 00000004D164: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D170: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000004D174: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000004D17C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000004D188: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004D190: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004D194: BE882004
	s_cbranch_execz 64828                                      // 00000004D198: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d8c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 00000004D19C: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000004D1A8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000004D1B0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000004D1B4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D1B8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000004D1BC: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000004D1C4: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000004D1D0: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004D1D4: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000004D1D8: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000004D1DC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000004D1E4: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D1EC: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000004D1F0: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000004D1F4: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000004D1F8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D1FC: BF870095
	.long 0xd71c0072                                           // 00000004D200: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000004D204: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000004D208: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000004D20C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D214: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 00000004D218: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000004D224: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D228: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000004D22C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000004D234: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D238: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000004D23C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000004D244: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000004D248: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D250: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 00000004D254: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 00000004D258: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D260: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 00000004D264: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 00000004D268: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D270: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 00000004D274: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000004D27C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 00000004D284: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D290: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000004D294: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000004D29C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000004D2A8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004D2B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004D2B4: BE882005
	s_cbranch_execz 64759                                      // 00000004D2B8: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d98>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 00000004D2BC: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000004D2C8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000004D2D0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000004D2D4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D2D8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000004D2DC: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000004D2E4: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000004D2F0: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004D2F4: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000004D2F8: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000004D2FC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000004D304: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D30C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000004D310: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000004D314: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000004D318: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D31C: BF870095
	.long 0xd71c0072                                           // 00000004D320: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000004D324: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000004D328: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000004D32C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D334: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 00000004D338: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 00000004D340: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D348: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000004D34C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000004D354: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D358: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000004D35C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000004D364: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000004D368: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D370: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 00000004D374: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 00000004D378: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D380: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 00000004D384: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 00000004D388: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D390: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 00000004D394: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000004D39C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 00000004D3A4: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D3B0: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000004D3B4: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000004D3BC: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000004D3C8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004D3D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004D3D4: BE882006
	s_cbranch_execz 64690                                      // 00000004D3D8: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3da4>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 00000004D3DC: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000004D3E8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000004D3F0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000004D3F4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D3F8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000004D3FC: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000004D404: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000004D410: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004D414: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000004D418: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000004D41C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000004D424: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D42C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000004D430: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000004D434: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000004D438: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D43C: BF870095
	.long 0xd71c0072                                           // 00000004D440: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000004D444: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000004D448: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000004D44C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D454: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 00000004D458: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000004D464: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D468: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000004D46C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000004D474: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D478: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000004D47C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000004D484: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000004D488: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D490: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 00000004D494: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 00000004D498: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D4A0: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 00000004D4A4: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 00000004D4A8: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D4B0: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 00000004D4B4: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000004D4BC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 00000004D4C4: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D4D0: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000004D4D4: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000004D4DC: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000004D4E8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004D4F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004D4F4: BE882007
	s_cbranch_execz 64621                                      // 00000004D4F8: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3db0>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 00000004D4FC: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000004D508: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000004D510: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000004D514: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D518: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000004D51C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000004D524: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000004D530: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004D534: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000004D538: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000004D53C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000004D544: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D54C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000004D550: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000004D554: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000004D558: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D55C: BF870095
	.long 0xd71c0072                                           // 00000004D560: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000004D564: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000004D568: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000004D56C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D574: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 00000004D578: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000004D584: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D588: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000004D58C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000004D594: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D598: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000004D59C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000004D5A4: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000004D5A8: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D5B0: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 00000004D5B4: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 00000004D5B8: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D5C0: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 00000004D5C4: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 00000004D5C8: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D5D0: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 00000004D5D4: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000004D5DC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 00000004D5E4: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D5F0: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000004D5F4: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000004D5FC: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000004D608: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004D610: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004D614: BE882000
	s_cbranch_execz 64552                                      // 00000004D618: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dbc>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 00000004D61C: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 00000004D628: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 00000004D62C: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 00000004D634: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000004D638: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D63C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000004D640: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000004D648: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000004D654: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004D658: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000004D65C: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000004D660: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000004D668: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D670: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000004D674: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000004D678: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000004D67C: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D680: BF870095
	.long 0xd71c0072                                           // 00000004D684: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000004D688: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000004D68C: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000004D690: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D698: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 00000004D69C: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000004D6A4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D6A8: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 00000004D6AC: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 00000004D6B4: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D6B8: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 00000004D6BC: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 00000004D6C4: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 00000004D6C8: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D6D0: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 00000004D6D4: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 00000004D6D8: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D6E0: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 00000004D6E4: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 00000004D6E8: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D6F0: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 00000004D6F4: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 00000004D6FC: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 00000004D704: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D710: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 00000004D714: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 00000004D71C: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 00000004D728: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004D730: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004D734: BE882001
	s_cbranch_execz 64483                                      // 00000004D738: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dc8>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 00000004D73C: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 00000004D748: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 00000004D74C: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 00000004D754: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000004D758: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D75C: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 00000004D760: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000004D768: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 00000004D770: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 00000004D77C: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004D780: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 00000004D784: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 00000004D78C: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D790: BF870121
	v_add_f32_e32 v113, v113, v114                             // 00000004D794: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 00000004D798: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 00000004D79C: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D7A0: BF870095
	.long 0xd71c0071                                           // 00000004D7A4: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 00000004D7A8: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 00000004D7AC: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000004D7B0: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D7B8: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 00000004D7BC: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000004D7C4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D7C8: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 00000004D7CC: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 00000004D7D4: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D7D8: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 00000004D7DC: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 00000004D7E4: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 00000004D7E8: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D7F0: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 00000004D7F4: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 00000004D7F8: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D800: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 00000004D804: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 00000004D808: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D810: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 00000004D814: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 00000004D81C: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 00000004D824: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D830: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 00000004D834: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 00000004D83C: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 00000004D848: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004D850: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004D854: BE882002
	s_cbranch_execz 64414                                      // 00000004D858: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dd4>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 00000004D85C: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000004D868: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000004D870: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000004D874: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D878: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000004D87C: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 00000004D884: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 00000004D890: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004D894: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 00000004D898: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000004D89C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 00000004D8A4: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D8AC: BF870121
	v_add_f32_e32 v106, v106, v113                             // 00000004D8B0: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 00000004D8B4: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 00000004D8B8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D8BC: BF870095
	.long 0xd71c006a                                           // 00000004D8C0: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 00000004D8C4: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000004D8C8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000004D8CC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D8D4: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 00000004D8D8: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000004D8E4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D8E8: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000004D8EC: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 00000004D8F4: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D8F8: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 00000004D8FC: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 00000004D904: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 00000004D908: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D910: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 00000004D914: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 00000004D918: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D920: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 00000004D924: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 00000004D928: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D930: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 00000004D934: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000004D93C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 00000004D944: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D950: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 00000004D954: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 00000004D95C: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000004D968: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004D970: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004D974: BE882003
	s_cbranch_execz 64345                                      // 00000004D978: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3de0>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 00000004D97C: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000004D988: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000004D990: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000004D994: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D998: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000004D99C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000004D9A4: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 00000004D9B0: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004D9B4: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 00000004D9B8: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 00000004D9C4: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 00000004D9C8: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000004D9CC: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004D9D4: BF870293
	v_exp_f32_e32 v106, v106                                   // 00000004D9D8: 7ED44B6A
	.long 0xd71c006a                                           // 00000004D9DC: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000004D9E0: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004D9E4: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000004D9E8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000004D9EC: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 00000004D9F4: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DA00: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 00000004DA04: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000004DA08: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004DA10: BF870291
	v_rcp_f32_e32 v108, v107                                   // 00000004DA14: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 00000004DA18: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004DA20: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 00000004DA24: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 00000004DA28: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 00000004DA30: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DA34: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 00000004DA38: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 00000004DA40: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DA44: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 00000004DA48: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 00000004DA50: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004DA58: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000004DA5C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 00000004DA64: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 00000004DA70: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004DA78: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000004DA7C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000004DA88: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004DA90: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004DA94: BE882004
	s_cbranch_execz 64276                                      // 00000004DA98: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dec>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 00000004DA9C: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000004DAA8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000004DAB0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000004DAB4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DAB8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000004DABC: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000004DAC4: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000004DAD0: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004DAD4: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000004DAD8: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000004DADC: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000004DAE4: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004DAEC: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000004DAF0: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000004DAF4: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000004DAF8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DAFC: BF870095
	.long 0xd71c006a                                           // 00000004DB00: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000004DB04: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000004DB08: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000004DB0C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DB14: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 00000004DB18: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000004DB24: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DB28: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000004DB2C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000004DB34: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DB38: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000004DB3C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000004DB44: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000004DB48: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DB50: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 00000004DB54: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 00000004DB58: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DB60: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 00000004DB64: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 00000004DB68: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DB70: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 00000004DB74: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000004DB7C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 00000004DB84: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DB90: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000004DB94: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000004DB9C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000004DBA8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004DBB0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004DBB4: BE882005
	s_cbranch_execz 64207                                      // 00000004DBB8: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3df8>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 00000004DBBC: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000004DBC8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000004DBD0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000004DBD4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DBD8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000004DBDC: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000004DBE4: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000004DBF0: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004DBF4: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000004DBF8: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000004DBFC: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000004DC04: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004DC0C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000004DC10: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000004DC14: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000004DC18: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DC1C: BF870095
	.long 0xd71c006a                                           // 00000004DC20: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000004DC24: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000004DC28: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000004DC2C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DC34: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 00000004DC38: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 00000004DC40: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DC48: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000004DC4C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000004DC54: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DC58: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000004DC5C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000004DC64: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000004DC68: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DC70: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 00000004DC74: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 00000004DC78: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DC80: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 00000004DC84: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 00000004DC88: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DC90: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 00000004DC94: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000004DC9C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 00000004DCA4: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DCB0: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000004DCB4: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000004DCBC: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000004DCC8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004DCD0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004DCD4: BE882006
	s_cbranch_execz 64138                                      // 00000004DCD8: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e04>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 00000004DCDC: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000004DCE8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000004DCF0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000004DCF4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DCF8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000004DCFC: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000004DD04: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000004DD10: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004DD14: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000004DD18: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000004DD1C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000004DD24: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004DD2C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000004DD30: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000004DD34: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000004DD38: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DD3C: BF870095
	.long 0xd71c006a                                           // 00000004DD40: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000004DD44: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000004DD48: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000004DD4C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DD54: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 00000004DD58: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000004DD64: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DD68: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000004DD6C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000004DD74: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DD78: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000004DD7C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000004DD84: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000004DD88: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DD90: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 00000004DD94: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 00000004DD98: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DDA0: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 00000004DDA4: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 00000004DDA8: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DDB0: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 00000004DDB4: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000004DDBC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 00000004DDC4: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DDD0: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000004DDD4: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000004DDDC: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000004DDE8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004DDF0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004DDF4: BE882007
	s_cbranch_execz 64069                                      // 00000004DDF8: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e10>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 00000004DDFC: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000004DE08: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000004DE10: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000004DE14: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DE18: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000004DE1C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000004DE24: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000004DE30: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004DE34: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000004DE38: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000004DE3C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000004DE44: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004DE4C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000004DE50: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000004DE54: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000004DE58: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DE5C: BF870095
	.long 0xd71c006a                                           // 00000004DE60: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000004DE64: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000004DE68: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000004DE6C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DE74: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 00000004DE78: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000004DE84: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DE88: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000004DE8C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000004DE94: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DE98: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000004DE9C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000004DEA4: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000004DEA8: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DEB0: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 00000004DEB4: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 00000004DEB8: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DEC0: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 00000004DEC4: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 00000004DEC8: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DED0: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 00000004DED4: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000004DEDC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 00000004DEE4: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DEF0: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000004DEF4: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000004DEFC: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000004DF08: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004DF10: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004DF14: BE882000
	s_cbranch_execz 64000                                      // 00000004DF18: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e1c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 00000004DF1C: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 00000004DF28: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 00000004DF2C: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 00000004DF34: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000004DF38: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DF3C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000004DF40: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000004DF48: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000004DF54: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004DF58: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000004DF5C: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000004DF60: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000004DF68: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004DF70: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000004DF74: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000004DF78: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000004DF7C: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DF80: BF870095
	.long 0xd71c006a                                           // 00000004DF84: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000004DF88: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000004DF8C: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000004DF90: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DF98: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 00000004DF9C: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000004DFA4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DFA8: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 00000004DFAC: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 00000004DFB4: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DFB8: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 00000004DFBC: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 00000004DFC4: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 00000004DFC8: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DFD0: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 00000004DFD4: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 00000004DFD8: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DFE0: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 00000004DFE4: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 00000004DFE8: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004DFF0: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 00000004DFF4: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 00000004DFFC: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 00000004E004: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E010: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 00000004E014: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 00000004E01C: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 00000004E028: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004E030: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004E034: BE882001
	s_cbranch_execz 63931                                      // 00000004E038: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e28>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 00000004E03C: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 00000004E048: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 00000004E04C: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 00000004E054: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000004E058: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004E05C: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 00000004E060: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000004E068: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 00000004E070: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 00000004E07C: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004E080: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 00000004E084: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 00000004E08C: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004E090: BF870121
	v_add_f32_e32 v105, v105, v106                             // 00000004E094: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 00000004E098: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 00000004E09C: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E0A0: BF870095
	.long 0xd71c0069                                           // 00000004E0A4: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 00000004E0A8: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 00000004E0AC: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000004E0B0: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E0B8: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 00000004E0BC: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000004E0C4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E0C8: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 00000004E0CC: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 00000004E0D4: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E0D8: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 00000004E0DC: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 00000004E0E4: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 00000004E0E8: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E0F0: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 00000004E0F4: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 00000004E0F8: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E100: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 00000004E104: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 00000004E108: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E110: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 00000004E114: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 00000004E11C: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 00000004E124: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E130: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 00000004E134: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 00000004E13C: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 00000004E148: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004E150: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004E154: BE882002
	s_cbranch_execz 63862                                      // 00000004E158: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e34>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 00000004E15C: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000004E168: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000004E170: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000004E174: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E178: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000004E17C: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 00000004E184: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 00000004E190: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004E194: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 00000004E198: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000004E19C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 00000004E1A4: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004E1AC: BF870121
	v_add_f32_e32 v98, v98, v105                               // 00000004E1B0: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 00000004E1B4: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 00000004E1B8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E1BC: BF870095
	.long 0xd71c0062                                           // 00000004E1C0: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 00000004E1C4: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000004E1C8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000004E1CC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E1D4: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 00000004E1D8: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000004E1E4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E1E8: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000004E1EC: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 00000004E1F4: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E1F8: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 00000004E1FC: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 00000004E204: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 00000004E208: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E210: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 00000004E214: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 00000004E218: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E220: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 00000004E224: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 00000004E228: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E230: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 00000004E234: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000004E23C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 00000004E244: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E250: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 00000004E254: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 00000004E25C: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000004E268: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004E270: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004E274: BE882003
	s_cbranch_execz 63793                                      // 00000004E278: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e40>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 00000004E27C: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000004E288: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000004E290: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000004E294: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E298: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000004E29C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000004E2A4: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 00000004E2B0: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E2B4: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 00000004E2B8: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 00000004E2C4: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 00000004E2C8: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000004E2CC: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004E2D4: BF870293
	v_exp_f32_e32 v98, v98                                     // 00000004E2D8: 7EC44B62
	.long 0xd71c0062                                           // 00000004E2DC: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000004E2E0: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004E2E4: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000004E2E8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000004E2EC: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 00000004E2F4: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E300: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 00000004E304: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000004E308: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004E310: BF870291
	v_rcp_f32_e32 v100, v99                                    // 00000004E314: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 00000004E318: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004E320: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 00000004E324: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 00000004E328: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 00000004E330: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E334: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 00000004E338: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 00000004E340: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E344: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 00000004E348: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 00000004E350: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004E358: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000004E35C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 00000004E364: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 00000004E370: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004E378: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000004E37C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000004E388: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004E390: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004E394: BE882004
	s_cbranch_execz 63724                                      // 00000004E398: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e4c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 00000004E39C: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000004E3A8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000004E3B0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000004E3B4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E3B8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000004E3BC: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000004E3C4: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000004E3D0: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004E3D4: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000004E3D8: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000004E3DC: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000004E3E4: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004E3EC: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000004E3F0: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000004E3F4: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000004E3F8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E3FC: BF870095
	.long 0xd71c0062                                           // 00000004E400: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000004E404: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000004E408: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000004E40C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E414: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 00000004E418: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000004E424: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E428: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000004E42C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 00000004E434: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E438: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000004E43C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 00000004E444: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000004E448: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E450: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 00000004E454: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 00000004E458: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E460: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 00000004E464: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 00000004E468: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E470: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 00000004E474: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000004E47C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 00000004E484: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E490: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 00000004E494: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000004E49C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000004E4A8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004E4B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004E4B4: BE882005
	s_cbranch_execz 63655                                      // 00000004E4B8: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e58>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 00000004E4BC: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000004E4C8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000004E4D0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000004E4D4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E4D8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000004E4DC: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000004E4E4: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000004E4F0: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004E4F4: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000004E4F8: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000004E4FC: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000004E504: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004E50C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000004E510: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000004E514: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000004E518: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E51C: BF870095
	.long 0xd71c0062                                           // 00000004E520: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000004E524: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000004E528: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000004E52C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E534: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 00000004E538: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 00000004E540: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E548: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000004E54C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 00000004E554: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E558: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000004E55C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 00000004E564: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000004E568: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E570: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 00000004E574: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 00000004E578: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E580: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 00000004E584: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 00000004E588: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E590: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 00000004E594: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000004E59C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 00000004E5A4: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E5B0: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 00000004E5B4: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000004E5BC: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000004E5C8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004E5D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004E5D4: BE882006
	s_cbranch_execz 63586                                      // 00000004E5D8: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e64>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 00000004E5DC: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000004E5E8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000004E5F0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000004E5F4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E5F8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000004E5FC: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000004E604: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000004E610: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004E614: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000004E618: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000004E61C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000004E624: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004E62C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000004E630: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000004E634: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000004E638: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E63C: BF870095
	.long 0xd71c0062                                           // 00000004E640: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000004E644: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000004E648: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000004E64C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E654: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 00000004E658: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000004E664: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E668: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000004E66C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 00000004E674: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E678: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000004E67C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 00000004E684: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000004E688: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E690: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 00000004E694: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 00000004E698: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E6A0: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 00000004E6A4: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 00000004E6A8: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E6B0: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 00000004E6B4: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000004E6BC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 00000004E6C4: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E6D0: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 00000004E6D4: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000004E6DC: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000004E6E8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004E6F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004E6F4: BE882007
	s_cbranch_execz 63517                                      // 00000004E6F8: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e70>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 00000004E6FC: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000004E708: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000004E710: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000004E714: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E718: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000004E71C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000004E724: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000004E730: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004E734: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000004E738: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000004E73C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000004E744: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004E74C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000004E750: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000004E754: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000004E758: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E75C: BF870095
	.long 0xd71c0062                                           // 00000004E760: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000004E764: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000004E768: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000004E76C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E774: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 00000004E778: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000004E784: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E788: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000004E78C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 00000004E794: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E798: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000004E79C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 00000004E7A4: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000004E7A8: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E7B0: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 00000004E7B4: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 00000004E7B8: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E7C0: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 00000004E7C4: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 00000004E7C8: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E7D0: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 00000004E7D4: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000004E7DC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 00000004E7E4: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E7F0: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 00000004E7F4: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000004E7FC: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000004E808: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004E810: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004E814: BE882000
	s_cbranch_execz 63448                                      // 00000004E818: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e7c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 00000004E81C: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 00000004E828: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 00000004E82C: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 00000004E834: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000004E838: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E83C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000004E840: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000004E848: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000004E854: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004E858: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000004E85C: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000004E860: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000004E868: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004E870: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000004E874: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000004E878: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000004E87C: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E880: BF870095
	.long 0xd71c0062                                           // 00000004E884: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000004E888: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000004E88C: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000004E890: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E898: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 00000004E89C: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000004E8A4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E8A8: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 00000004E8AC: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 00000004E8B4: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E8B8: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 00000004E8BC: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 00000004E8C4: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 00000004E8C8: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E8D0: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 00000004E8D4: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 00000004E8D8: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E8E0: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 00000004E8E4: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 00000004E8E8: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E8F0: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 00000004E8F4: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 00000004E8FC: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 00000004E904: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E910: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 00000004E914: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 00000004E91C: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 00000004E928: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004E930: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004E934: BE882001
	s_cbranch_execz 63379                                      // 00000004E938: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e88>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 00000004E93C: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 00000004E948: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 00000004E94C: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 00000004E954: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000004E958: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004E95C: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 00000004E960: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000004E968: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 00000004E970: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 00000004E97C: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004E980: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 00000004E984: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 00000004E98C: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004E990: BF870121
	v_add_f32_e32 v97, v97, v98                                // 00000004E994: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 00000004E998: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 00000004E99C: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E9A0: BF870095
	.long 0xd71c0061                                           // 00000004E9A4: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 00000004E9A8: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 00000004E9AC: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000004E9B0: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E9B8: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 00000004E9BC: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000004E9C4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E9C8: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 00000004E9CC: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 00000004E9D4: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E9D8: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 00000004E9DC: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 00000004E9E4: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 00000004E9E8: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004E9F0: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 00000004E9F4: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 00000004E9F8: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EA00: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 00000004EA04: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 00000004EA08: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EA10: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 00000004EA14: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 00000004EA1C: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 00000004EA24: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EA30: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 00000004EA34: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 00000004EA3C: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 00000004EA48: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004EA50: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004EA54: BE882002
	s_cbranch_execz 63310                                      // 00000004EA58: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e94>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 00000004EA5C: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000004EA68: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000004EA70: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000004EA74: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EA78: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000004EA7C: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 00000004EA84: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 00000004EA90: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004EA94: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 00000004EA98: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000004EA9C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 00000004EAA4: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004EAAC: BF870121
	v_add_f32_e32 v90, v90, v97                                // 00000004EAB0: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 00000004EAB4: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 00000004EAB8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EABC: BF870095
	.long 0xd71c005a                                           // 00000004EAC0: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 00000004EAC4: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000004EAC8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000004EACC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EAD4: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 00000004EAD8: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000004EAE4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EAE8: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000004EAEC: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 00000004EAF4: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EAF8: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 00000004EAFC: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 00000004EB04: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 00000004EB08: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EB10: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 00000004EB14: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 00000004EB18: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EB20: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 00000004EB24: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 00000004EB28: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EB30: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 00000004EB34: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000004EB3C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 00000004EB44: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EB50: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 00000004EB54: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 00000004EB5C: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000004EB68: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004EB70: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004EB74: BE882003
	s_cbranch_execz 63241                                      // 00000004EB78: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ea0>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 00000004EB7C: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000004EB88: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000004EB90: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000004EB94: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EB98: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000004EB9C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000004EBA4: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 00000004EBB0: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EBB4: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 00000004EBB8: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 00000004EBC4: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 00000004EBC8: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000004EBCC: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004EBD4: BF870293
	v_exp_f32_e32 v90, v90                                     // 00000004EBD8: 7EB44B5A
	.long 0xd71c005a                                           // 00000004EBDC: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000004EBE0: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004EBE4: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000004EBE8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000004EBEC: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 00000004EBF4: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EC00: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 00000004EC04: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000004EC08: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004EC10: BF870291
	v_rcp_f32_e32 v92, v91                                     // 00000004EC14: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 00000004EC18: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004EC20: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 00000004EC24: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 00000004EC28: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 00000004EC30: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EC34: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 00000004EC38: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 00000004EC40: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EC44: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 00000004EC48: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 00000004EC50: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004EC58: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000004EC5C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 00000004EC64: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 00000004EC70: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004EC78: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000004EC7C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000004EC88: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004EC90: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004EC94: BE882004
	s_cbranch_execz 63172                                      // 00000004EC98: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3eac>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 00000004EC9C: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000004ECA8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000004ECB0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000004ECB4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ECB8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000004ECBC: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000004ECC4: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000004ECD0: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004ECD4: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000004ECD8: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000004ECDC: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000004ECE4: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004ECEC: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000004ECF0: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000004ECF4: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000004ECF8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ECFC: BF870095
	.long 0xd71c005a                                           // 00000004ED00: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000004ED04: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000004ED08: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000004ED0C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ED14: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 00000004ED18: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000004ED24: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ED28: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000004ED2C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000004ED34: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ED38: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000004ED3C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000004ED44: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 00000004ED48: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ED50: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 00000004ED54: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 00000004ED58: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ED60: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 00000004ED64: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 00000004ED68: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ED70: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 00000004ED74: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000004ED7C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 00000004ED84: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004ED90: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000004ED94: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000004ED9C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000004EDA8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004EDB0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004EDB4: BE882005
	s_cbranch_execz 63103                                      // 00000004EDB8: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3eb8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 00000004EDBC: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000004EDC8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000004EDD0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000004EDD4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EDD8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000004EDDC: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000004EDE4: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000004EDF0: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004EDF4: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000004EDF8: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000004EDFC: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000004EE04: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004EE0C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000004EE10: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000004EE14: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000004EE18: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EE1C: BF870095
	.long 0xd71c005a                                           // 00000004EE20: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000004EE24: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000004EE28: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000004EE2C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EE34: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 00000004EE38: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 00000004EE40: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EE48: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000004EE4C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000004EE54: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EE58: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000004EE5C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000004EE64: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 00000004EE68: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EE70: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 00000004EE74: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 00000004EE78: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EE80: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 00000004EE84: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 00000004EE88: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EE90: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 00000004EE94: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000004EE9C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 00000004EEA4: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EEB0: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000004EEB4: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000004EEBC: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000004EEC8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004EED0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004EED4: BE882006
	s_cbranch_execz 63034                                      // 00000004EED8: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ec4>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 00000004EEDC: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000004EEE8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000004EEF0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000004EEF4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EEF8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000004EEFC: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000004EF04: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000004EF10: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004EF14: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000004EF18: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000004EF1C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000004EF24: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004EF2C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000004EF30: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000004EF34: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000004EF38: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EF3C: BF870095
	.long 0xd71c005a                                           // 00000004EF40: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000004EF44: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000004EF48: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000004EF4C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EF54: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 00000004EF58: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000004EF64: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EF68: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000004EF6C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000004EF74: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EF78: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000004EF7C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000004EF84: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 00000004EF88: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EF90: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 00000004EF94: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 00000004EF98: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EFA0: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 00000004EFA4: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 00000004EFA8: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EFB0: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 00000004EFB4: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000004EFBC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 00000004EFC4: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004EFD0: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000004EFD4: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000004EFDC: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000004EFE8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004EFF0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004EFF4: BE882007
	s_cbranch_execz 62965                                      // 00000004EFF8: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ed0>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 00000004EFFC: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000004F008: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 00000004F010: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000004F014: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F018: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000004F01C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000004F024: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000004F030: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004F034: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000004F038: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000004F03C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000004F044: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004F04C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000004F050: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000004F054: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000004F058: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F05C: BF870095
	.long 0xd71c005a                                           // 00000004F060: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000004F064: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000004F068: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000004F06C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F074: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 00000004F078: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000004F084: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F088: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000004F08C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 00000004F094: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F098: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000004F09C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 00000004F0A4: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 00000004F0A8: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F0B0: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 00000004F0B4: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 00000004F0B8: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F0C0: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 00000004F0C4: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 00000004F0C8: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F0D0: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 00000004F0D4: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000004F0DC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 00000004F0E4: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F0F0: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 00000004F0F4: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000004F0FC: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000004F108: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004F110: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004F114: BE882000
	s_cbranch_execz 62896                                      // 00000004F118: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3edc>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 00000004F11C: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 00000004F128: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 00000004F12C: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 00000004F134: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000004F138: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F13C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000004F140: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000004F148: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 00000004F154: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004F158: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000004F15C: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000004F160: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000004F168: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004F170: BF870121
	v_add_f32_e32 v90, v90, v91                                // 00000004F174: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 00000004F178: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000004F17C: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F180: BF870095
	.long 0xd71c005a                                           // 00000004F184: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 00000004F188: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000004F18C: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 00000004F190: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F198: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 00000004F19C: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 00000004F1A4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F1A8: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 00000004F1AC: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 00000004F1B4: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F1B8: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 00000004F1BC: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 00000004F1C4: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 00000004F1C8: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F1D0: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 00000004F1D4: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 00000004F1D8: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F1E0: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 00000004F1E4: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 00000004F1E8: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F1F0: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 00000004F1F4: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 00000004F1FC: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 00000004F204: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F210: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 00000004F214: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 00000004F21C: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 00000004F228: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004F230: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004F234: BE882001
	s_cbranch_execz 62827                                      // 00000004F238: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ee8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 00000004F23C: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 00000004F248: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 00000004F24C: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 00000004F254: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000004F258: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004F25C: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 00000004F260: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000004F268: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 00000004F270: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 00000004F27C: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004F280: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 00000004F284: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 00000004F28C: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004F290: BF870121
	v_add_f32_e32 v89, v89, v90                                // 00000004F294: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 00000004F298: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 00000004F29C: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F2A0: BF870095
	.long 0xd71c0059                                           // 00000004F2A4: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 00000004F2A8: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 00000004F2AC: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000004F2B0: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F2B8: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 00000004F2BC: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000004F2C4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F2C8: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 00000004F2CC: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 00000004F2D4: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F2D8: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 00000004F2DC: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 00000004F2E4: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 00000004F2E8: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F2F0: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 00000004F2F4: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 00000004F2F8: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F300: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 00000004F304: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 00000004F308: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F310: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 00000004F314: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 00000004F31C: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 00000004F324: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F330: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 00000004F334: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 00000004F33C: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 00000004F348: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004F350: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004F354: BE882002
	s_cbranch_execz 62758                                      // 00000004F358: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ef4>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 00000004F35C: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000004F368: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000004F370: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000004F374: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F378: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000004F37C: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 00000004F384: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 00000004F390: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004F394: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 00000004F398: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000004F39C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 00000004F3A4: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004F3AC: BF870121
	v_add_f32_e32 v82, v82, v89                                // 00000004F3B0: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 00000004F3B4: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 00000004F3B8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F3BC: BF870095
	.long 0xd71c0052                                           // 00000004F3C0: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 00000004F3C4: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000004F3C8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000004F3CC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F3D4: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 00000004F3D8: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000004F3E4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F3E8: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000004F3EC: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 00000004F3F4: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F3F8: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 00000004F3FC: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 00000004F404: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 00000004F408: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F410: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 00000004F414: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 00000004F418: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F420: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 00000004F424: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 00000004F428: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F430: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 00000004F434: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000004F43C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 00000004F444: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F450: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 00000004F454: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 00000004F45C: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000004F468: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004F470: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004F474: BE882003
	s_cbranch_execz 62689                                      // 00000004F478: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f00>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 00000004F47C: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000004F488: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000004F490: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000004F494: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F498: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000004F49C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000004F4A4: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 00000004F4B0: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F4B4: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 00000004F4B8: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 00000004F4C4: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 00000004F4C8: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000004F4CC: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004F4D4: BF870293
	v_exp_f32_e32 v82, v82                                     // 00000004F4D8: 7EA44B52
	.long 0xd71c0052                                           // 00000004F4DC: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000004F4E0: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004F4E4: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000004F4E8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000004F4EC: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 00000004F4F4: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F500: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 00000004F504: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000004F508: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004F510: BF870291
	v_rcp_f32_e32 v84, v83                                     // 00000004F514: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 00000004F518: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004F520: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 00000004F524: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 00000004F528: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 00000004F530: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F534: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 00000004F538: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 00000004F540: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F544: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 00000004F548: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 00000004F550: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004F558: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000004F55C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 00000004F564: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 00000004F570: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004F578: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000004F57C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000004F588: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004F590: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004F594: BE882004
	s_cbranch_execz 62620                                      // 00000004F598: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f0c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 00000004F59C: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000004F5A8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000004F5B0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000004F5B4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F5B8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000004F5BC: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000004F5C4: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000004F5D0: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004F5D4: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000004F5D8: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000004F5DC: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000004F5E4: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004F5EC: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000004F5F0: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000004F5F4: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000004F5F8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F5FC: BF870095
	.long 0xd71c0052                                           // 00000004F600: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000004F604: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000004F608: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000004F60C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F614: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 00000004F618: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000004F624: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F628: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000004F62C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000004F634: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F638: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000004F63C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000004F644: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000004F648: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F650: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 00000004F654: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 00000004F658: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F660: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 00000004F664: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 00000004F668: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F670: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 00000004F674: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000004F67C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 00000004F684: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F690: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000004F694: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000004F69C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000004F6A8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004F6B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004F6B4: BE882005
	s_cbranch_execz 62551                                      // 00000004F6B8: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f18>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 00000004F6BC: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000004F6C8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000004F6D0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000004F6D4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F6D8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000004F6DC: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000004F6E4: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000004F6F0: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004F6F4: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000004F6F8: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000004F6FC: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000004F704: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004F70C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000004F710: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000004F714: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000004F718: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F71C: BF870095
	.long 0xd71c0052                                           // 00000004F720: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000004F724: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000004F728: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000004F72C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F734: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 00000004F738: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 00000004F740: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F748: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000004F74C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000004F754: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F758: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000004F75C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000004F764: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000004F768: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F770: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 00000004F774: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 00000004F778: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F780: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 00000004F784: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 00000004F788: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F790: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 00000004F794: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000004F79C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 00000004F7A4: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F7B0: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000004F7B4: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000004F7BC: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000004F7C8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004F7D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000004F7D4: BE882006
	s_cbranch_execz 62482                                      // 00000004F7D8: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f24>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 00000004F7DC: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000004F7E8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000004F7F0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000004F7F4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F7F8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000004F7FC: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000004F804: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000004F810: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004F814: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000004F818: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000004F81C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000004F824: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004F82C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000004F830: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000004F834: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000004F838: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F83C: BF870095
	.long 0xd71c0052                                           // 00000004F840: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000004F844: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000004F848: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000004F84C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F854: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 00000004F858: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000004F864: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F868: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000004F86C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000004F874: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F878: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000004F87C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000004F884: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000004F888: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F890: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 00000004F894: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 00000004F898: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F8A0: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 00000004F8A4: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 00000004F8A8: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F8B0: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 00000004F8B4: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000004F8BC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 00000004F8C4: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F8D0: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000004F8D4: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000004F8DC: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000004F8E8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004F8F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000004F8F4: BE882007
	s_cbranch_execz 62413                                      // 00000004F8F8: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f30>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 00000004F8FC: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000004F908: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000004F910: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000004F914: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F918: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000004F91C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000004F924: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000004F930: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004F934: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000004F938: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000004F93C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000004F944: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004F94C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000004F950: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000004F954: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000004F958: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F95C: BF870095
	.long 0xd71c0052                                           // 00000004F960: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000004F964: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000004F968: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000004F96C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F974: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 00000004F978: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000004F984: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F988: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000004F98C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 00000004F994: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F998: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000004F99C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 00000004F9A4: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000004F9A8: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F9B0: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 00000004F9B4: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 00000004F9B8: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F9C0: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 00000004F9C4: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 00000004F9C8: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F9D0: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 00000004F9D4: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000004F9DC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 00000004F9E4: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004F9F0: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 00000004F9F4: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000004F9FC: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000004FA08: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004FA10: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000004FA14: BE882000
	s_cbranch_execz 62344                                      // 00000004FA18: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f3c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 00000004FA1C: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 00000004FA28: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 00000004FA2C: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 00000004FA34: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000004FA38: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FA3C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000004FA40: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 00000004FA48: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 00000004FA54: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004FA58: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000004FA5C: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000004FA60: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 00000004FA68: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004FA70: BF870121
	v_add_f32_e32 v82, v82, v83                                // 00000004FA74: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 00000004FA78: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000004FA7C: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FA80: BF870095
	.long 0xd71c0052                                           // 00000004FA84: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 00000004FA88: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000004FA8C: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000004FA90: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FA98: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 00000004FA9C: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 00000004FAA4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FAA8: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 00000004FAAC: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 00000004FAB4: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FAB8: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 00000004FABC: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 00000004FAC4: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 00000004FAC8: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FAD0: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 00000004FAD4: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 00000004FAD8: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FAE0: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 00000004FAE4: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 00000004FAE8: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FAF0: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 00000004FAF4: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 00000004FAFC: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 00000004FB04: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FB10: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 00000004FB14: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 00000004FB1C: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 00000004FB28: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004FB30: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000004FB34: BE882001
	s_cbranch_execz 62275                                      // 00000004FB38: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f48>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 00000004FB3C: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 00000004FB48: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 00000004FB4C: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 00000004FB54: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000004FB58: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004FB5C: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 00000004FB60: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000004FB68: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 00000004FB70: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 00000004FB7C: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004FB80: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 00000004FB84: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 00000004FB8C: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004FB90: BF870121
	v_add_f32_e32 v81, v81, v82                                // 00000004FB94: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 00000004FB98: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 00000004FB9C: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FBA0: BF870095
	.long 0xd71c0051                                           // 00000004FBA4: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 00000004FBA8: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000004FBAC: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000004FBB0: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FBB8: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 00000004FBBC: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000004FBC4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FBC8: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 00000004FBCC: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 00000004FBD4: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FBD8: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 00000004FBDC: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 00000004FBE4: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 00000004FBE8: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FBF0: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 00000004FBF4: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 00000004FBF8: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FC00: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 00000004FC04: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 00000004FC08: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FC10: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 00000004FC14: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 00000004FC1C: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 00000004FC24: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FC30: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 00000004FC34: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 00000004FC3C: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 00000004FC48: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004FC50: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000004FC54: BE882002
	s_cbranch_execz 62206                                      // 00000004FC58: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f54>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 00000004FC5C: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000004FC68: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000004FC70: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000004FC74: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FC78: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000004FC7C: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 00000004FC84: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 00000004FC90: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004FC94: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 00000004FC98: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000004FC9C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 00000004FCA4: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004FCAC: BF870121
	v_add_f32_e32 v74, v74, v81                                // 00000004FCB0: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 00000004FCB4: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 00000004FCB8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FCBC: BF870095
	.long 0xd71c004a                                           // 00000004FCC0: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 00000004FCC4: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000004FCC8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000004FCCC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FCD4: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 00000004FCD8: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000004FCE4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FCE8: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000004FCEC: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 00000004FCF4: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FCF8: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 00000004FCFC: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 00000004FD04: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 00000004FD08: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FD10: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 00000004FD14: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 00000004FD18: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FD20: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 00000004FD24: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 00000004FD28: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FD30: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 00000004FD34: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000004FD3C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 00000004FD44: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FD50: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 00000004FD54: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 00000004FD5C: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000004FD68: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004FD70: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000004FD74: BE882003
	s_cbranch_execz 62137                                      // 00000004FD78: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f60>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 00000004FD7C: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000004FD88: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000004FD90: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000004FD94: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FD98: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000004FD9C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000004FDA4: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 00000004FDB0: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FDB4: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 00000004FDB8: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 00000004FDC4: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 00000004FDC8: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000004FDCC: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004FDD4: BF870293
	v_exp_f32_e32 v74, v74                                     // 00000004FDD8: 7E944B4A
	.long 0xd71c004a                                           // 00000004FDDC: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000004FDE0: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004FDE4: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000004FDE8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000004FDEC: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 00000004FDF4: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FE00: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 00000004FE04: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000004FE08: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004FE10: BF870291
	v_rcp_f32_e32 v76, v75                                     // 00000004FE14: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 00000004FE18: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004FE20: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 00000004FE24: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 00000004FE28: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 00000004FE30: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FE34: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 00000004FE38: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 00000004FE40: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FE44: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 00000004FE48: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 00000004FE50: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004FE58: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000004FE5C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 00000004FE64: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 00000004FE70: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004FE78: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000004FE7C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000004FE88: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004FE90: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000004FE94: BE882004
	s_cbranch_execz 62068                                      // 00000004FE98: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f6c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 00000004FE9C: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000004FEA8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000004FEB0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000004FEB4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FEB8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000004FEBC: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000004FEC4: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000004FED0: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004FED4: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000004FED8: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000004FEDC: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000004FEE4: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004FEEC: BF870121
	v_add_f32_e32 v74, v74, v75                                // 00000004FEF0: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 00000004FEF4: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000004FEF8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FEFC: BF870095
	.long 0xd71c004a                                           // 00000004FF00: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 00000004FF04: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000004FF08: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000004FF0C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FF14: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 00000004FF18: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 00000004FF24: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FF28: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000004FF2C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 00000004FF34: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FF38: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 00000004FF3C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 00000004FF44: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 00000004FF48: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FF50: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 00000004FF54: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 00000004FF58: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FF60: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 00000004FF64: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 00000004FF68: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FF70: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 00000004FF74: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000004FF7C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 00000004FF84: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FF90: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 00000004FF94: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 00000004FF9C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000004FFA8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 00000004FFB0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000004FFB4: BE882005
	s_cbranch_execz 61999                                      // 00000004FFB8: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f78>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 00000004FFBC: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000004FFC8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 00000004FFD0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000004FFD4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004FFD8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000004FFDC: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000004FFE4: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 00000004FFF0: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000004FFF4: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000004FFF8: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000004FFFC: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000050004: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005000C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000050010: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000050014: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000050018: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005001C: BF870095
	.long 0xd71c004a                                           // 000000050020: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000050024: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000050028: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000005002C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050034: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 000000050038: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 000000050040: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050048: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000005004C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000050054: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050058: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 00000005005C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000050064: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000050068: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050070: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 000000050074: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 000000050078: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050080: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 000000050084: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 000000050088: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050090: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 000000050094: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000005009C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 0000000500A4: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000500B0: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000500B4: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000500BC: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000500C8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000500D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000500D4: BE882006
	s_cbranch_execz 61930                                      // 0000000500D8: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f84>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 0000000500DC: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000500E8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000500F0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000500F4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000500F8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000500FC: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000050104: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000050110: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000050114: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000050118: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000005011C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000050124: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005012C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000050130: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000050134: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000050138: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005013C: BF870095
	.long 0xd71c004a                                           // 000000050140: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000050144: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000050148: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000005014C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050154: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 000000050158: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000050164: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050168: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000005016C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000050174: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050178: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 00000005017C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000050184: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000050188: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050190: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 000000050194: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 000000050198: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000501A0: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000501A4: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000501A8: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000501B0: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000501B4: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000501BC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 0000000501C4: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000501D0: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000501D4: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000501DC: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000501E8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000501F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000501F4: BE882007
	s_cbranch_execz 61861                                      // 0000000501F8: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f90>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 0000000501FC: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000050208: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000050210: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000050214: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050218: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000005021C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000050224: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000050230: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000050234: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000050238: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000005023C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000050244: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005024C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000050250: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000050254: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000050258: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005025C: BF870095
	.long 0xd71c004a                                           // 000000050260: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000050264: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000050268: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 00000005026C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050274: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 000000050278: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000050284: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050288: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 00000005028C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000050294: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050298: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 00000005029C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000502A4: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000502A8: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000502B0: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000502B4: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000000502B8: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000502C0: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000502C4: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000502C8: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000502D0: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000502D4: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000502DC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 0000000502E4: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000502F0: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000502F4: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000502FC: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000050308: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000050310: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000050314: BE882000
	s_cbranch_execz 61792                                      // 000000050318: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f9c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 00000005031C: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 000000050328: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 00000005032C: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000050334: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000050338: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005033C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000050340: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000050348: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000050354: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000050358: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000005035C: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000050360: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000050368: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000050370: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000050374: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000050378: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000005037C: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050380: BF870095
	.long 0xd71c004a                                           // 000000050384: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000050388: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000005038C: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000050390: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050398: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 00000005039C: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000503A4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000503A8: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 0000000503AC: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 0000000503B4: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000503B8: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 0000000503BC: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 0000000503C4: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 0000000503C8: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000503D0: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 0000000503D4: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 0000000503D8: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000503E0: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 0000000503E4: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 0000000503E8: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000503F0: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 0000000503F4: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 0000000503FC: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 000000050404: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050410: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 000000050414: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 00000005041C: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 000000050428: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 000000050430: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000050434: BE882001
	s_cbranch_execz 61723                                      // 000000050438: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fa8>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 00000005043C: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 000000050448: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 00000005044C: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 000000050454: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000050458: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005045C: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 000000050460: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000050468: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 000000050470: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 00000005047C: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000050480: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 000000050484: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 00000005048C: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000050490: BF870121
	v_add_f32_e32 v73, v73, v74                                // 000000050494: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 000000050498: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 00000005049C: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000504A0: BF870095
	.long 0xd71c0049                                           // 0000000504A4: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000000504A8: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000504AC: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000504B0: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000504B8: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 0000000504BC: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000504C4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000504C8: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 0000000504CC: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 0000000504D4: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000504D8: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 0000000504DC: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 0000000504E4: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 0000000504E8: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000504F0: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 0000000504F4: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 0000000504F8: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050500: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 000000050504: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 000000050508: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050510: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 000000050514: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 00000005051C: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 000000050524: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050530: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 000000050534: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 00000005053C: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 000000050548: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 000000050550: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000050554: BE882002
	s_cbranch_execz 61654                                      // 000000050558: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fb4>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 00000005055C: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000050568: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000050570: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000050574: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050578: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000005057C: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 000000050584: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 000000050590: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000050594: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 000000050598: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000005059C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 0000000505A4: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000505AC: BF870121
	v_add_f32_e32 v66, v66, v73                                // 0000000505B0: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 0000000505B4: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 0000000505B8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000505BC: BF870095
	.long 0xd71c0042                                           // 0000000505C0: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 0000000505C4: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000505C8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000505CC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000505D4: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 0000000505D8: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000505E4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000505E8: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000505EC: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 0000000505F4: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000505F8: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 0000000505FC: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 000000050604: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 000000050608: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050610: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 000000050614: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 000000050618: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050620: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 000000050624: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 000000050628: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050630: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 000000050634: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000005063C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 000000050644: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050650: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 000000050654: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 00000005065C: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000050668: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000050670: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000050674: BE882003
	s_cbranch_execz 61585                                      // 000000050678: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fc0>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 00000005067C: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000050688: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000050690: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000050694: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050698: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000005069C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000506A4: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 0000000506B0: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000506B4: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 0000000506B8: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 0000000506C4: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 0000000506C8: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000506CC: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000506D4: BF870293
	v_exp_f32_e32 v66, v66                                     // 0000000506D8: 7E844B42
	.long 0xd71c0042                                           // 0000000506DC: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000506E0: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000506E4: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000506E8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000506EC: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 0000000506F4: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050700: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 000000050704: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000050708: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000050710: BF870291
	v_rcp_f32_e32 v68, v67                                     // 000000050714: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 000000050718: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000050720: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 000000050724: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 000000050728: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 000000050730: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050734: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 000000050738: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 000000050740: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050744: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 000000050748: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 000000050750: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000050758: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000005075C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 000000050764: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 000000050770: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 000000050778: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000005077C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000050788: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000050790: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000050794: BE882004
	s_cbranch_execz 61516                                      // 000000050798: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fcc>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 00000005079C: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000507A8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000507B0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000507B4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000507B8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000507BC: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000507C4: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000507D0: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000507D4: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000507D8: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000507DC: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000507E4: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000507EC: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000507F0: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000507F4: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000507F8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000507FC: BF870095
	.long 0xd71c0042                                           // 000000050800: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000050804: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000050808: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000005080C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050814: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 000000050818: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000050824: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050828: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000005082C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000050834: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050838: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000005083C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000050844: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000050848: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050850: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 000000050854: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 000000050858: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050860: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 000000050864: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 000000050868: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050870: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 000000050874: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000005087C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 000000050884: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050890: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000050894: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000005089C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000508A8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000508B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000508B4: BE882005
	s_cbranch_execz 61447                                      // 0000000508B8: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fd8>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 0000000508BC: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000508C8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000508D0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000508D4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000508D8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000508DC: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000508E4: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000508F0: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000508F4: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000508F8: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000508FC: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000050904: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005090C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000050910: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000050914: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000050918: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005091C: BF870095
	.long 0xd71c0042                                           // 000000050920: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000050924: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000050928: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000005092C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050934: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000050938: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 000000050940: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050948: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000005094C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000050954: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050958: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000005095C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000050964: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000050968: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050970: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000050974: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 000000050978: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050980: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 000000050984: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 000000050988: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050990: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000050994: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000005099C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 0000000509A4: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000509B0: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000509B4: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000509BC: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000509C8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000509D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000509D4: BE882006
	s_cbranch_execz 61378                                      // 0000000509D8: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fe4>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 0000000509DC: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000509E8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000509F0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000509F4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000509F8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000509FC: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000050A04: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000050A10: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000050A14: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000050A18: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000050A1C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000050A24: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000050A2C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000050A30: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000050A34: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000050A38: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050A3C: BF870095
	.long 0xd71c0042                                           // 000000050A40: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000050A44: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000050A48: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000050A4C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050A54: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 000000050A58: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000050A64: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050A68: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000050A6C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000050A74: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050A78: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000050A7C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000050A84: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000050A88: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050A90: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000050A94: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000050A98: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050AA0: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 000000050AA4: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 000000050AA8: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050AB0: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000050AB4: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000050ABC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 000000050AC4: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050AD0: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000050AD4: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000050ADC: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000050AE8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000050AF0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000050AF4: BE882007
	s_cbranch_execz 61309                                      // 000000050AF8: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ff0>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 000000050AFC: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000050B08: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000050B10: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000050B14: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050B18: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000050B1C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000050B24: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000050B30: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000050B34: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000050B38: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000050B3C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000050B44: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000050B4C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000050B50: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000050B54: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000050B58: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050B5C: BF870095
	.long 0xd71c0042                                           // 000000050B60: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000050B64: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000050B68: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000050B6C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050B74: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 000000050B78: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000050B84: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050B88: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000050B8C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000050B94: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050B98: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000050B9C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000050BA4: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000050BA8: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050BB0: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000050BB4: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000050BB8: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050BC0: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 000000050BC4: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 000000050BC8: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050BD0: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000050BD4: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000050BDC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 000000050BE4: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050BF0: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000050BF4: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000050BFC: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000050C08: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000050C10: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000050C14: BE882000
	s_cbranch_execz 61240                                      // 000000050C18: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ffc>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 000000050C1C: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 000000050C28: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 000000050C2C: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 000000050C34: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000050C38: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050C3C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000050C40: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000050C48: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000050C54: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000050C58: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000050C5C: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000050C60: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000050C68: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000050C70: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000050C74: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000050C78: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000050C7C: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050C80: BF870095
	.long 0xd71c0042                                           // 000000050C84: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000050C88: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000050C8C: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000050C90: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050C98: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000050C9C: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000050CA4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050CA8: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 000000050CAC: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 000000050CB4: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050CB8: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 000000050CBC: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 000000050CC4: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 000000050CC8: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050CD0: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 000000050CD4: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 000000050CD8: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050CE0: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 000000050CE4: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 000000050CE8: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050CF0: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 000000050CF4: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 000000050CFC: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 000000050D04: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050D10: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 000000050D14: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 000000050D1C: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 000000050D28: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 000000050D30: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000050D34: BE882001
	s_cbranch_execz 61171                                      // 000000050D38: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4008>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 000000050D3C: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 000000050D48: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 000000050D4C: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 000000050D54: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000050D58: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000050D5C: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 000000050D60: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000050D68: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 000000050D70: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 000000050D7C: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000050D80: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 000000050D84: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 000000050D8C: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000050D90: BF870121
	v_add_f32_e32 v65, v65, v66                                // 000000050D94: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000050D98: 7E841143
	v_exp_f32_e32 v65, v65                                     // 000000050D9C: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050DA0: BF870095
	.long 0xd71c0041                                           // 000000050DA4: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000050DA8: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 000000050DAC: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000050DB0: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050DB8: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 000000050DBC: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000050DC4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050DC8: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 000000050DCC: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 000000050DD4: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050DD8: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 000000050DDC: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 000000050DE4: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 000000050DE8: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050DF0: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 000000050DF4: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 000000050DF8: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050E00: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 000000050E04: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 000000050E08: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050E10: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 000000050E14: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 000000050E1C: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 000000050E24: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050E30: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 000000050E34: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 000000050E3C: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 000000050E48: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 000000050E50: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000050E54: BE882002
	s_cbranch_execz 61102                                      // 000000050E58: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4014>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 000000050E5C: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000050E68: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000050E70: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000050E74: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050E78: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000050E7C: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 000000050E84: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 000000050E90: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000050E94: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 000000050E98: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000050E9C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 000000050EA4: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000050EAC: BF870121
	v_add_f32_e32 v58, v58, v65                                // 000000050EB0: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 000000050EB4: 7E821142
	v_exp_f32_e32 v58, v58                                     // 000000050EB8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050EBC: BF870095
	.long 0xd71c003a                                           // 000000050EC0: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 000000050EC4: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000050EC8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000050ECC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050ED4: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 000000050ED8: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000050EE4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050EE8: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000050EEC: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 000000050EF4: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050EF8: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 000000050EFC: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 000000050F04: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 000000050F08: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050F10: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 000000050F14: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 000000050F18: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050F20: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 000000050F24: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 000000050F28: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050F30: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 000000050F34: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000050F3C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 000000050F44: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050F50: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 000000050F54: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 000000050F5C: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000050F68: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000050F70: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000050F74: BE882003
	s_cbranch_execz 61033                                      // 000000050F78: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4020>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 000000050F7C: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000050F88: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000050F90: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000050F94: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050F98: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000050F9C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000050FA4: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 000000050FB0: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000050FB4: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 000000050FB8: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 000000050FC4: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 000000050FC8: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000050FCC: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000050FD4: BF870293
	v_exp_f32_e32 v58, v58                                     // 000000050FD8: 7E744B3A
	.long 0xd71c003a                                           // 000000050FDC: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000050FE0: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000050FE4: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000050FE8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000050FEC: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 000000050FF4: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051000: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 000000051004: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000051008: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000051010: BF870291
	v_rcp_f32_e32 v60, v59                                     // 000000051014: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 000000051018: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000051020: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 000000051024: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 000000051028: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 000000051030: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051034: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 000000051038: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 000000051040: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051044: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 000000051048: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 000000051050: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000051058: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000005105C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 000000051064: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 000000051070: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000051078: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000005107C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000051088: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000051090: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000051094: BE882004
	s_cbranch_execz 60964                                      // 000000051098: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x402c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 00000005109C: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000510A8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000510B0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000510B4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000510B8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000510BC: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000510C4: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000510D0: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000510D4: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000510D8: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000510DC: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000510E4: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000510EC: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000510F0: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000510F4: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000510F8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000510FC: BF870095
	.long 0xd71c003a                                           // 000000051100: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000051104: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000051108: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000005110C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051114: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 000000051118: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000051124: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051128: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000005112C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000051134: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051138: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000005113C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 000000051144: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000051148: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051150: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 000000051154: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 000000051158: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051160: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 000000051164: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 000000051168: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051170: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 000000051174: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000005117C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 000000051184: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051190: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 000000051194: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 00000005119C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000511A8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000511B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000511B4: BE882005
	s_cbranch_execz 60895                                      // 0000000511B8: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4038>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 0000000511BC: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000511C8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000511D0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000511D4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000511D8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000511DC: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000511E4: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000511F0: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000511F4: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000511F8: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000511FC: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000051204: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005120C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000051210: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000051214: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000051218: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005121C: BF870095
	.long 0xd71c003a                                           // 000000051220: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000051224: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000051228: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000005122C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051234: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 000000051238: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 000000051240: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051248: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000005124C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000051254: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051258: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000005125C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 000000051264: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000051268: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051270: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 000000051274: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 000000051278: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051280: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 000000051284: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 000000051288: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051290: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 000000051294: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 00000005129C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 0000000512A4: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000512B0: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000512B4: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000512BC: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000512C8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000512D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000512D4: BE882006
	s_cbranch_execz 60826                                      // 0000000512D8: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4044>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 0000000512DC: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000512E8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000512F0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000512F4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000512F8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000512FC: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000051304: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000051310: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000051314: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000051318: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000005131C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000051324: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005132C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000051330: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000051334: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000051338: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005133C: BF870095
	.long 0xd71c003a                                           // 000000051340: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000051344: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000051348: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000005134C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051354: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 000000051358: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000051364: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051368: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000005136C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000051374: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051378: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000005137C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 000000051384: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000051388: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051390: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 000000051394: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 000000051398: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000513A0: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000513A4: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000513A8: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000513B0: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000513B4: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000513BC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 0000000513C4: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000513D0: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000513D4: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000513DC: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000513E8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000513F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000513F4: BE882007
	s_cbranch_execz 60757                                      // 0000000513F8: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4050>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 0000000513FC: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000051408: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000051410: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000051414: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051418: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000005141C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000051424: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000051430: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000051434: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000051438: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000005143C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000051444: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005144C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000051450: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000051454: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000051458: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005145C: BF870095
	.long 0xd71c003a                                           // 000000051460: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000051464: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000051468: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000005146C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051474: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 000000051478: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000051484: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051488: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000005148C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000051494: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051498: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000005149C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000514A4: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000514A8: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000514B0: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000514B4: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000000514B8: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000514C0: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000514C4: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000514C8: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000514D0: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000514D4: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000514DC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 0000000514E4: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000514F0: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000514F4: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000514FC: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000051508: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000051510: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000051514: BE882000
	s_cbranch_execz 60688                                      // 000000051518: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x405c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 00000005151C: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 000000051528: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 00000005152C: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 000000051534: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000051538: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005153C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000051540: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000051548: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000051554: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000051558: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000005155C: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000051560: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000051568: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000051570: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000051574: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000051578: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000005157C: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051580: BF870095
	.long 0xd71c003a                                           // 000000051584: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000051588: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000005158C: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000051590: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051598: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 00000005159C: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000515A4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000515A8: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 0000000515AC: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 0000000515B4: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000515B8: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 0000000515BC: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 0000000515C4: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 0000000515C8: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000515D0: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 0000000515D4: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 0000000515D8: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000515E0: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 0000000515E4: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 0000000515E8: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000515F0: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 0000000515F4: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 0000000515FC: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 000000051604: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051610: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 000000051614: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 00000005161C: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 000000051628: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 000000051630: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000051634: BE882001
	s_cbranch_execz 60619                                      // 000000051638: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4068>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 00000005163C: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 000000051648: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 00000005164C: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 000000051654: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000051658: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005165C: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 000000051660: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000051668: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 000000051670: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000005167C: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000051680: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 000000051684: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 00000005168C: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000051690: BF870121
	v_add_f32_e32 v57, v57, v58                                // 000000051694: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 000000051698: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000005169C: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000516A0: BF870095
	.long 0xd71c0039                                           // 0000000516A4: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 0000000516A8: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000000516AC: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000516B0: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000516B8: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 0000000516BC: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000516C4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000516C8: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 0000000516CC: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 0000000516D4: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000516D8: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 0000000516DC: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 0000000516E4: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 0000000516E8: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000516F0: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 0000000516F4: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 0000000516F8: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051700: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 000000051704: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 000000051708: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051710: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 000000051714: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 00000005171C: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 000000051724: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051730: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 000000051734: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 00000005173C: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 000000051748: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 000000051750: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000051754: BE882002
	s_cbranch_execz 60550                                      // 000000051758: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4074>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 00000005175C: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000051768: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000051770: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000051774: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051778: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000005177C: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 000000051784: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 000000051790: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000051794: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 000000051798: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000005179C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 0000000517A4: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000517AC: BF870121
	v_add_f32_e32 v50, v50, v57                                // 0000000517B0: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 0000000517B4: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 0000000517B8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000517BC: BF870095
	.long 0xd71c0032                                           // 0000000517C0: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 0000000517C4: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000517C8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000517CC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000517D4: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 0000000517D8: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000517E4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000517E8: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000517EC: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 0000000517F4: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000517F8: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 0000000517FC: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 000000051804: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 000000051808: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051810: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 000000051814: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 000000051818: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051820: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 000000051824: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 000000051828: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051830: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 000000051834: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000005183C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 000000051844: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051850: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 000000051854: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 00000005185C: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000051868: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000051870: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000051874: BE882003
	s_cbranch_execz 60481                                      // 000000051878: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4080>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 00000005187C: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000051888: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000051890: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000051894: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051898: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000005189C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000518A4: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 0000000518B0: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000518B4: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 0000000518B8: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 0000000518C4: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 0000000518C8: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000518CC: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000518D4: BF870293
	v_exp_f32_e32 v50, v50                                     // 0000000518D8: 7E644B32
	.long 0xd71c0032                                           // 0000000518DC: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000518E0: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000518E4: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000518E8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000518EC: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 0000000518F4: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051900: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 000000051904: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000051908: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000051910: BF870291
	v_rcp_f32_e32 v52, v51                                     // 000000051914: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 000000051918: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000051920: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 000000051924: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 000000051928: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 000000051930: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051934: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 000000051938: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 000000051940: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051944: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 000000051948: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 000000051950: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000051958: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000005195C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 000000051964: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 000000051970: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 000000051978: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000005197C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000051988: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000051990: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000051994: BE882004
	s_cbranch_execz 60412                                      // 000000051998: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x408c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 00000005199C: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000519A8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000519B0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000519B4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000519B8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000519BC: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000519C4: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000519D0: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000519D4: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000519D8: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000519DC: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000519E4: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000519EC: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000519F0: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000519F4: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000519F8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000519FC: BF870095
	.long 0xd71c0032                                           // 000000051A00: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000051A04: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000051A08: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000051A0C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051A14: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 000000051A18: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000051A24: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051A28: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000051A2C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000051A34: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051A38: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000051A3C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000051A44: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000051A48: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051A50: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 000000051A54: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 000000051A58: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051A60: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 000000051A64: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 000000051A68: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051A70: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 000000051A74: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000051A7C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 000000051A84: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051A90: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000051A94: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000051A9C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000051AA8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000051AB0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000051AB4: BE882005
	s_cbranch_execz 60343                                      // 000000051AB8: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4098>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 000000051ABC: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000051AC8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000051AD0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000051AD4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051AD8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000051ADC: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000051AE4: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000051AF0: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000051AF4: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000051AF8: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000051AFC: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000051B04: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000051B0C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000051B10: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000051B14: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000051B18: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051B1C: BF870095
	.long 0xd71c0032                                           // 000000051B20: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000051B24: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000051B28: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000051B2C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051B34: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 000000051B38: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 000000051B40: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051B48: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000051B4C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000051B54: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051B58: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000051B5C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000051B64: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000051B68: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051B70: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000051B74: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 000000051B78: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051B80: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 000000051B84: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 000000051B88: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051B90: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000051B94: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000051B9C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 000000051BA4: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051BB0: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000051BB4: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000051BBC: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000051BC8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000051BD0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000051BD4: BE882006
	s_cbranch_execz 60274                                      // 000000051BD8: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40a4>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 000000051BDC: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000051BE8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000051BF0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000051BF4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051BF8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000051BFC: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000051C04: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000051C10: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000051C14: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000051C18: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000051C1C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000051C24: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000051C2C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000051C30: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000051C34: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000051C38: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051C3C: BF870095
	.long 0xd71c0032                                           // 000000051C40: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000051C44: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000051C48: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000051C4C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051C54: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 000000051C58: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000051C64: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051C68: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000051C6C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000051C74: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051C78: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000051C7C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000051C84: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000051C88: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051C90: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000051C94: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 000000051C98: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051CA0: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 000000051CA4: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 000000051CA8: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051CB0: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000051CB4: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000051CBC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 000000051CC4: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051CD0: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000051CD4: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000051CDC: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000051CE8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000051CF0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000051CF4: BE882007
	s_cbranch_execz 60205                                      // 000000051CF8: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40b0>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 000000051CFC: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000051D08: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000051D10: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000051D14: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051D18: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000051D1C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000051D24: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000051D30: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000051D34: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000051D38: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000051D3C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000051D44: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000051D4C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000051D50: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000051D54: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000051D58: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051D5C: BF870095
	.long 0xd71c0032                                           // 000000051D60: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000051D64: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000051D68: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000051D6C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051D74: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 000000051D78: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000051D84: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051D88: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000051D8C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000051D94: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051D98: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000051D9C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000051DA4: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000051DA8: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051DB0: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000051DB4: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 000000051DB8: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051DC0: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 000000051DC4: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 000000051DC8: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051DD0: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000051DD4: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000051DDC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 000000051DE4: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051DF0: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000051DF4: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000051DFC: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000051E08: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000051E10: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000051E14: BE882000
	s_cbranch_execz 60136                                      // 000000051E18: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40bc>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 000000051E1C: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 000000051E28: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 000000051E2C: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 000000051E34: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000051E38: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051E3C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000051E40: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000051E48: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000051E54: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000051E58: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000051E5C: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000051E60: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000051E68: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000051E70: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000051E74: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000051E78: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000051E7C: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051E80: BF870095
	.long 0xd71c0032                                           // 000000051E84: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000051E88: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000051E8C: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000051E90: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051E98: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 000000051E9C: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000051EA4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051EA8: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 000000051EAC: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 000000051EB4: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051EB8: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 000000051EBC: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 000000051EC4: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 000000051EC8: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051ED0: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 000000051ED4: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 000000051ED8: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051EE0: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 000000051EE4: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 000000051EE8: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051EF0: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 000000051EF4: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 000000051EFC: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 000000051F04: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051F10: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 000000051F14: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 000000051F1C: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 000000051F28: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 000000051F30: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000051F34: BE882001
	s_cbranch_execz 60067                                      // 000000051F38: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40c8>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 000000051F3C: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 000000051F48: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 000000051F4C: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 000000051F54: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000051F58: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000051F5C: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 000000051F60: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000051F68: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 000000051F70: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 000000051F7C: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000051F80: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 000000051F84: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 000000051F8C: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000051F90: BF870121
	v_add_f32_e32 v49, v49, v50                                // 000000051F94: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 000000051F98: 7E641133
	v_exp_f32_e32 v49, v49                                     // 000000051F9C: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051FA0: BF870095
	.long 0xd71c0031                                           // 000000051FA4: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 000000051FA8: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 000000051FAC: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000051FB0: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051FB8: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 000000051FBC: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000051FC4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051FC8: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 000000051FCC: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 000000051FD4: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051FD8: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 000000051FDC: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 000000051FE4: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 000000051FE8: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000051FF0: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 000000051FF4: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 000000051FF8: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052000: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 000000052004: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 000000052008: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052010: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 000000052014: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 00000005201C: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 000000052024: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052030: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 000000052034: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 00000005203C: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 000000052048: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 000000052050: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000052054: BE882002
	s_cbranch_execz 59998                                      // 000000052058: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40d4>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 00000005205C: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000052068: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000052070: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000052074: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052078: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000005207C: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 000000052084: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 000000052090: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000052094: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 000000052098: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000005209C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 0000000520A4: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000520AC: BF870121
	v_add_f32_e32 v42, v42, v49                                // 0000000520B0: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 0000000520B4: 7E621132
	v_exp_f32_e32 v42, v42                                     // 0000000520B8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000520BC: BF870095
	.long 0xd71c002a                                           // 0000000520C0: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 0000000520C4: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000520C8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000520CC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000520D4: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 0000000520D8: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000520E4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000520E8: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000520EC: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 0000000520F4: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000520F8: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 0000000520FC: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 000000052104: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 000000052108: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052110: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 000000052114: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 000000052118: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052120: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 000000052124: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 000000052128: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052130: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 000000052134: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000005213C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 000000052144: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052150: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 000000052154: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 00000005215C: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000052168: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000052170: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000052174: BE882003
	s_cbranch_execz 59929                                      // 000000052178: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40e0>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 00000005217C: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000052188: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000052190: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000052194: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052198: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000005219C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000521A4: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 0000000521B0: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000521B4: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 0000000521B8: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 0000000521C4: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 0000000521C8: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000521CC: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000521D4: BF870293
	v_exp_f32_e32 v42, v42                                     // 0000000521D8: 7E544B2A
	.long 0xd71c002a                                           // 0000000521DC: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000521E0: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000521E4: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000521E8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000521EC: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 0000000521F4: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052200: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 000000052204: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000052208: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000052210: BF870291
	v_rcp_f32_e32 v44, v43                                     // 000000052214: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 000000052218: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000052220: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 000000052224: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 000000052228: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 000000052230: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052234: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 000000052238: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 000000052240: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052244: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 000000052248: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 000000052250: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052258: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000005225C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 000000052264: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 000000052270: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000052278: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000005227C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000052288: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000052290: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000052294: BE882004
	s_cbranch_execz 59860                                      // 000000052298: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40ec>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 00000005229C: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000522A8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000522B0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000522B4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000522B8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000522BC: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000522C4: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000522D0: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000522D4: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000522D8: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000522DC: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000522E4: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000522EC: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000522F0: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000522F4: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000522F8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000522FC: BF870095
	.long 0xd71c002a                                           // 000000052300: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000052304: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000052308: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000005230C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052314: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 000000052318: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000052324: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052328: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000005232C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000052334: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052338: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000005233C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000052344: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000052348: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052350: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 000000052354: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 000000052358: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052360: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 000000052364: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 000000052368: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052370: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 000000052374: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000005237C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 000000052384: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052390: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000052394: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 00000005239C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000523A8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000523B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000523B4: BE882005
	s_cbranch_execz 59791                                      // 0000000523B8: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40f8>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 0000000523BC: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000523C8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000523D0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000523D4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000523D8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000523DC: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000523E4: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000523F0: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000523F4: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000523F8: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000523FC: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000052404: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005240C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000052410: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000052414: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000052418: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005241C: BF870095
	.long 0xd71c002a                                           // 000000052420: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000052424: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000052428: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000005242C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052434: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 000000052438: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 000000052440: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052448: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000005244C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000052454: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052458: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000005245C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000052464: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000052468: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052470: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 000000052474: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 000000052478: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052480: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 000000052484: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 000000052488: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052490: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 000000052494: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000005249C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 0000000524A4: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000524B0: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000524B4: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000524BC: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000524C8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000524D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000524D4: BE882006
	s_cbranch_execz 59722                                      // 0000000524D8: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4104>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 0000000524DC: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000524E8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000524F0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000524F4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000524F8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000524FC: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000052504: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000052510: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000052514: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000052518: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000005251C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000052524: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005252C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000052530: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000052534: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000052538: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005253C: BF870095
	.long 0xd71c002a                                           // 000000052540: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000052544: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000052548: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000005254C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052554: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 000000052558: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000052564: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052568: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000005256C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000052574: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052578: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000005257C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000052584: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000052588: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052590: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 000000052594: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 000000052598: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000525A0: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000000525A4: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000000525A8: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000525B0: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000525B4: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000525BC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 0000000525C4: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000525D0: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000525D4: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000525DC: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000525E8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000525F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000525F4: BE882007
	s_cbranch_execz 59653                                      // 0000000525F8: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4110>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 0000000525FC: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000052608: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000052610: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000052614: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052618: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000005261C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000052624: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000052630: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000052634: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000052638: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000005263C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000052644: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005264C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000052650: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000052654: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000052658: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005265C: BF870095
	.long 0xd71c002a                                           // 000000052660: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000052664: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000052668: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000005266C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052674: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 000000052678: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000052684: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052688: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000005268C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000052694: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052698: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000005269C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000526A4: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000526A8: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000526B0: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000526B4: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000000526B8: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000526C0: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000000526C4: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000000526C8: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000526D0: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000526D4: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000526DC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 0000000526E4: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000526F0: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000526F4: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000526FC: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000052708: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000052710: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000052714: BE882000
	s_cbranch_execz 59584                                      // 000000052718: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x411c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 00000005271C: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 000000052728: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 00000005272C: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 000000052734: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000052738: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005273C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000052740: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000052748: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000052754: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000052758: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000005275C: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000052760: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000052768: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052770: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000052774: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000052778: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000005277C: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052780: BF870095
	.long 0xd71c002a                                           // 000000052784: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000052788: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000005278C: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000052790: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052798: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 00000005279C: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000527A4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000527A8: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 0000000527AC: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 0000000527B4: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000527B8: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 0000000527BC: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 0000000527C4: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 0000000527C8: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000527D0: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 0000000527D4: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 0000000527D8: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000527E0: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 0000000527E4: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 0000000527E8: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000527F0: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 0000000527F4: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 0000000527FC: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 000000052804: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052810: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 000000052814: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 00000005281C: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 000000052828: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 000000052830: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000052834: BE882001
	s_cbranch_execz 59515                                      // 000000052838: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4128>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 00000005283C: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 000000052848: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 00000005284C: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 000000052854: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000052858: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005285C: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 000000052860: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000052868: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 000000052870: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 00000005287C: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000052880: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 000000052884: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 00000005288C: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052890: BF870121
	v_add_f32_e32 v41, v41, v42                                // 000000052894: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 000000052898: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 00000005289C: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000528A0: BF870095
	.long 0xd71c0029                                           // 0000000528A4: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000000528A8: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000000528AC: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000528B0: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000528B8: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 0000000528BC: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000528C4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000528C8: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 0000000528CC: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 0000000528D4: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000528D8: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 0000000528DC: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 0000000528E4: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 0000000528E8: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000528F0: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 0000000528F4: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 0000000528F8: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052900: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 000000052904: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 000000052908: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052910: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 000000052914: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 00000005291C: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 000000052924: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052930: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 000000052934: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 00000005293C: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 000000052948: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 000000052950: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000052954: BE882002
	s_cbranch_execz 59446                                      // 000000052958: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4134>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 00000005295C: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000052968: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000052970: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000052974: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052978: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000005297C: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 000000052984: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 000000052990: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000052994: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 000000052998: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000005299C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 0000000529A4: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000529AC: BF870121
	v_add_f32_e32 v34, v34, v41                                // 0000000529B0: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 0000000529B4: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 0000000529B8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000529BC: BF870095
	.long 0xd71c0022                                           // 0000000529C0: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 0000000529C4: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000529C8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000529CC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000529D4: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 0000000529D8: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000529E4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000529E8: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000529EC: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 0000000529F4: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000529F8: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 0000000529FC: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 000000052A04: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 000000052A08: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052A10: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 000000052A14: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 000000052A18: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052A20: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 000000052A24: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 000000052A28: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052A30: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 000000052A34: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000052A3C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 000000052A44: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052A50: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 000000052A54: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 000000052A5C: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000052A68: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000052A70: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000052A74: BE882003
	s_cbranch_execz 59377                                      // 000000052A78: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4140>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 000000052A7C: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000052A88: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000052A90: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000052A94: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052A98: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000052A9C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000052AA4: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 000000052AB0: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052AB4: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 000000052AB8: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 000000052AC4: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 000000052AC8: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000052ACC: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000052AD4: BF870293
	v_exp_f32_e32 v34, v34                                     // 000000052AD8: 7E444B22
	.long 0xd71c0022                                           // 000000052ADC: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000052AE0: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052AE4: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000052AE8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000052AEC: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 000000052AF4: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052B00: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 000000052B04: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000052B08: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000052B10: BF870291
	v_rcp_f32_e32 v36, v35                                     // 000000052B14: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 000000052B18: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000052B20: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 000000052B24: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 000000052B28: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 000000052B30: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052B34: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 000000052B38: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 000000052B40: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052B44: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 000000052B48: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 000000052B50: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052B58: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000052B5C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 000000052B64: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 000000052B70: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 000000052B78: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000052B7C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000052B88: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000052B90: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000052B94: BE882004
	s_cbranch_execz 59308                                      // 000000052B98: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x414c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 000000052B9C: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000052BA8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000052BB0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000052BB4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052BB8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000052BBC: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000052BC4: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000052BD0: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000052BD4: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000052BD8: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000052BDC: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000052BE4: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052BEC: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000052BF0: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000052BF4: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000052BF8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052BFC: BF870095
	.long 0xd71c0022                                           // 000000052C00: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000052C04: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000052C08: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000052C0C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052C14: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 000000052C18: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000052C24: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052C28: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000052C2C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000052C34: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052C38: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000052C3C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000052C44: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000052C48: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052C50: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 000000052C54: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 000000052C58: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052C60: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 000000052C64: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 000000052C68: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052C70: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 000000052C74: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000052C7C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 000000052C84: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052C90: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000052C94: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000052C9C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000052CA8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000052CB0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000052CB4: BE882005
	s_cbranch_execz 59239                                      // 000000052CB8: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4158>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 000000052CBC: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000052CC8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000052CD0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000052CD4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052CD8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000052CDC: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000052CE4: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000052CF0: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000052CF4: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000052CF8: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000052CFC: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000052D04: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052D0C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000052D10: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000052D14: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000052D18: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052D1C: BF870095
	.long 0xd71c0022                                           // 000000052D20: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000052D24: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000052D28: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000052D2C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052D34: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 000000052D38: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 000000052D40: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052D48: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000052D4C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000052D54: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052D58: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000052D5C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000052D64: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000052D68: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052D70: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000052D74: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 000000052D78: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052D80: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 000000052D84: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 000000052D88: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052D90: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000052D94: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000052D9C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 000000052DA4: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052DB0: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000052DB4: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000052DBC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000052DC8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000052DD0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000052DD4: BE882006
	s_cbranch_execz 59170                                      // 000000052DD8: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4164>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 000000052DDC: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000052DE8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000052DF0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000052DF4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052DF8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000052DFC: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000052E04: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000052E10: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000052E14: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000052E18: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000052E1C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000052E24: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052E2C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000052E30: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000052E34: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000052E38: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052E3C: BF870095
	.long 0xd71c0022                                           // 000000052E40: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000052E44: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000052E48: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000052E4C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052E54: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 000000052E58: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000052E64: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052E68: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000052E6C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000052E74: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052E78: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000052E7C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000052E84: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000052E88: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052E90: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000052E94: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 000000052E98: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052EA0: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 000000052EA4: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 000000052EA8: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052EB0: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000052EB4: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000052EBC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 000000052EC4: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052ED0: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000052ED4: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000052EDC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000052EE8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000052EF0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000052EF4: BE882007
	s_cbranch_execz 59101                                      // 000000052EF8: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4170>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 000000052EFC: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000052F08: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000052F10: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000052F14: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052F18: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000052F1C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000052F24: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000052F30: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000052F34: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000052F38: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000052F3C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000052F44: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000052F4C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000052F50: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000052F54: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000052F58: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052F5C: BF870095
	.long 0xd71c0022                                           // 000000052F60: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000052F64: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000052F68: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000052F6C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052F74: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 000000052F78: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000052F84: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052F88: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000052F8C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000052F94: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052F98: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000052F9C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000052FA4: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000052FA8: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052FB0: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000052FB4: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 000000052FB8: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052FC0: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 000000052FC4: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 000000052FC8: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052FD0: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000052FD4: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000052FDC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 000000052FE4: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000052FF0: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000052FF4: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000052FFC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000053008: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000053010: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000053014: BE882000
	s_cbranch_execz 59032                                      // 000000053018: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x417c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 00000005301C: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 000000053028: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 00000005302C: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 000000053034: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000053038: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005303C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000053040: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000053048: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000053054: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000053058: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000005305C: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000053060: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000053068: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000053070: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000053074: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000053078: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000005307C: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053080: BF870095
	.long 0xd71c0022                                           // 000000053084: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000053088: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000005308C: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000053090: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053098: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 00000005309C: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000530A4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000530A8: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 0000000530AC: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 0000000530B4: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000530B8: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000000530BC: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 0000000530C4: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 0000000530C8: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000530D0: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 0000000530D4: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 0000000530D8: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000530E0: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 0000000530E4: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 0000000530E8: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000530F0: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 0000000530F4: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 0000000530FC: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 000000053104: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053110: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 000000053114: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 00000005311C: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 000000053128: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 000000053130: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000053134: BE882001
	s_cbranch_execz 58963                                      // 000000053138: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4188>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 00000005313C: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 000000053148: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 00000005314C: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 000000053154: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000053158: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005315C: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 000000053160: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000053168: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 000000053170: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000005317C: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000053180: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 000000053184: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 00000005318C: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000053190: BF870121
	v_add_f32_e32 v33, v33, v34                                // 000000053194: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 000000053198: 7E441123
	v_exp_f32_e32 v33, v33                                     // 00000005319C: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000531A0: BF870095
	.long 0xd71c0021                                           // 0000000531A4: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000000531A8: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000000531AC: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000531B0: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000531B8: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 0000000531BC: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000531C4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000531C8: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 0000000531CC: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 0000000531D4: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000531D8: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 0000000531DC: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 0000000531E4: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 0000000531E8: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000531F0: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 0000000531F4: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 0000000531F8: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053200: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 000000053204: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 000000053208: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053210: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 000000053214: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 00000005321C: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 000000053224: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053230: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 000000053234: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 00000005323C: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 000000053248: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 000000053250: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000053254: BE882002
	s_cbranch_execz 58894                                      // 000000053258: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4194>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 00000005325C: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000053268: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000053270: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000053274: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053278: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000005327C: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 000000053284: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 000000053290: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000053294: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 000000053298: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000005329C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 0000000532A4: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000532AC: BF870121
	v_add_f32_e32 v26, v26, v33                                // 0000000532B0: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000532B4: 7E421122
	v_exp_f32_e32 v26, v26                                     // 0000000532B8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000532BC: BF870095
	.long 0xd71c001a                                           // 0000000532C0: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 0000000532C4: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000532C8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000532CC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000532D4: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 0000000532D8: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000532E4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000532E8: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000532EC: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 0000000532F4: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000532F8: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 0000000532FC: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 000000053304: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 000000053308: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053310: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 000000053314: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 000000053318: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053320: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 000000053324: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 000000053328: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053330: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 000000053334: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000005333C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 000000053344: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053350: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 000000053354: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 00000005335C: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000053368: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000053370: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000053374: BE882003
	s_cbranch_execz 58825                                      // 000000053378: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41a0>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 00000005337C: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000053388: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000053390: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000053394: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053398: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000005339C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000533A4: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 0000000533B0: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000533B4: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 0000000533B8: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 0000000533C4: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 0000000533C8: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000533CC: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000533D4: BF870293
	v_exp_f32_e32 v26, v26                                     // 0000000533D8: 7E344B1A
	.long 0xd71c001a                                           // 0000000533DC: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000533E0: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000533E4: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000533E8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000533EC: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 0000000533F4: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053400: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 000000053404: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000053408: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000053410: BF870291
	v_rcp_f32_e32 v28, v27                                     // 000000053414: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 000000053418: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000053420: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 000000053424: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 000000053428: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 000000053430: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053434: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 000000053438: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 000000053440: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053444: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 000000053448: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 000000053450: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000053458: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000005345C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 000000053464: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 000000053470: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000053478: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000005347C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000053488: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000053490: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000053494: BE882004
	s_cbranch_execz 58756                                      // 000000053498: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41ac>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 00000005349C: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000534A8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000534B0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000534B4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000534B8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000534BC: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000534C4: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000534D0: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000534D4: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000534D8: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000534DC: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000534E4: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000534EC: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000534F0: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000534F4: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000534F8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000534FC: BF870095
	.long 0xd71c001a                                           // 000000053500: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000053504: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000053508: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000005350C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053514: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 000000053518: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000053524: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053528: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000005352C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000053534: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053538: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000005353C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000053544: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000053548: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053550: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 000000053554: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 000000053558: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053560: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 000000053564: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 000000053568: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053570: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 000000053574: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000005357C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 000000053584: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053590: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000053594: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000005359C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000535A8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000535B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000535B4: BE882005
	s_cbranch_execz 58687                                      // 0000000535B8: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41b8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 0000000535BC: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000535C8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000535D0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000535D4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000535D8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000535DC: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000535E4: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000535F0: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000535F4: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000535F8: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000535FC: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000053604: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005360C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000053610: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000053614: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000053618: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005361C: BF870095
	.long 0xd71c001a                                           // 000000053620: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000053624: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000053628: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000005362C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053634: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 000000053638: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 000000053640: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053648: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000005364C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000053654: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053658: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000005365C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000053664: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000053668: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053670: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 000000053674: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 000000053678: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053680: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 000000053684: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 000000053688: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053690: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 000000053694: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000005369C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 0000000536A4: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000536B0: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000536B4: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000536BC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000536C8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000536D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000536D4: BE882006
	s_cbranch_execz 58618                                      // 0000000536D8: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41c4>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 0000000536DC: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000536E8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000536F0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000536F4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000536F8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000536FC: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000053704: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000053710: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000053714: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000053718: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000005371C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000053724: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005372C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000053730: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000053734: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000053738: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005373C: BF870095
	.long 0xd71c001a                                           // 000000053740: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000053744: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000053748: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000005374C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053754: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 000000053758: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000053764: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053768: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000005376C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000053774: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053778: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000005377C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000053784: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000053788: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053790: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 000000053794: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 000000053798: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000537A0: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000000537A4: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000000537A8: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000537B0: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000537B4: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000537BC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 0000000537C4: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000537D0: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000537D4: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000537DC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000537E8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000537F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000537F4: BE882007
	s_cbranch_execz 58549                                      // 0000000537F8: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41d0>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 0000000537FC: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000053808: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000053810: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000053814: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053818: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000005381C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000053824: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000053830: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000053834: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000053838: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000005383C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000053844: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005384C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000053850: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000053854: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000053858: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005385C: BF870095
	.long 0xd71c001a                                           // 000000053860: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000053864: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000053868: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000005386C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053874: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 000000053878: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000053884: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053888: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000005388C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000053894: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053898: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000005389C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000538A4: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000538A8: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000538B0: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000538B4: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000000538B8: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000538C0: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000000538C4: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000000538C8: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000538D0: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000538D4: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000538DC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 0000000538E4: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000538F0: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000538F4: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000538FC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000053908: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000053910: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000053914: BE882000
	s_cbranch_execz 58480                                      // 000000053918: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41dc>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 00000005391C: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 000000053928: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 00000005392C: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 000000053934: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000053938: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005393C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000053940: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000053948: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000053954: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000053958: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000005395C: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000053960: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000053968: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000053970: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000053974: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000053978: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000005397C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053980: BF870095
	.long 0xd71c001a                                           // 000000053984: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000053988: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000005398C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000053990: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053998: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 00000005399C: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000539A4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000539A8: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 0000000539AC: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 0000000539B4: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000539B8: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 0000000539BC: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 0000000539C4: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 0000000539C8: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000539D0: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 0000000539D4: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 0000000539D8: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000539E0: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 0000000539E4: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 0000000539E8: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000539F0: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 0000000539F4: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 0000000539FC: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 000000053A04: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053A10: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 000000053A14: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 000000053A1C: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 000000053A28: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 000000053A30: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000053A34: BE882001
	s_cbranch_execz 58411                                      // 000000053A38: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41e8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 000000053A3C: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 000000053A48: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 000000053A4C: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 000000053A54: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000053A58: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000053A5C: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 000000053A60: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000053A68: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 000000053A70: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 000000053A7C: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000053A80: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 000000053A84: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 000000053A8C: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000053A90: BF870121
	v_add_f32_e32 v25, v25, v26                                // 000000053A94: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 000000053A98: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 000000053A9C: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053AA0: BF870095
	.long 0xd71c0019                                           // 000000053AA4: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000053AA8: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 000000053AAC: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000053AB0: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053AB8: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 000000053ABC: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000053AC4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053AC8: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 000000053ACC: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 000000053AD4: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053AD8: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 000000053ADC: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 000000053AE4: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 000000053AE8: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053AF0: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 000000053AF4: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 000000053AF8: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053B00: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 000000053B04: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 000000053B08: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053B10: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 000000053B14: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 000000053B1C: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 000000053B24: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053B30: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 000000053B34: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 000000053B3C: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 000000053B48: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 000000053B50: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000053B54: BE882002
	s_cbranch_execz 58342                                      // 000000053B58: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41f4>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 000000053B5C: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000053B68: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000053B70: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000053B74: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053B78: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000053B7C: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 000000053B84: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 000000053B90: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000053B94: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 000000053B98: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000053B9C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 000000053BA4: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000053BAC: BF870121
	v_add_f32_e32 v18, v18, v25                                // 000000053BB0: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 000000053BB4: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 000000053BB8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053BBC: BF870095
	.long 0xd71c0012                                           // 000000053BC0: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 000000053BC4: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000053BC8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000053BCC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053BD4: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 000000053BD8: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000053BE4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053BE8: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000053BEC: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 000000053BF4: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053BF8: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 000000053BFC: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 000000053C04: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 000000053C08: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053C10: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 000000053C14: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 000000053C18: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053C20: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 000000053C24: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 000000053C28: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053C30: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 000000053C34: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000053C3C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 000000053C44: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053C50: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 000000053C54: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 000000053C5C: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000053C68: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000053C70: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000053C74: BE882003
	s_cbranch_execz 58273                                      // 000000053C78: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4200>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 000000053C7C: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000053C88: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000053C90: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000053C94: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053C98: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000053C9C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000053CA4: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 000000053CB0: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053CB4: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 000000053CB8: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 000000053CC4: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 000000053CC8: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000053CCC: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000053CD4: BF870293
	v_exp_f32_e32 v18, v18                                     // 000000053CD8: 7E244B12
	.long 0xd71c0012                                           // 000000053CDC: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000053CE0: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000053CE4: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000053CE8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000053CEC: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 000000053CF4: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053D00: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 000000053D04: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000053D08: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000053D10: BF870291
	v_rcp_f32_e32 v20, v19                                     // 000000053D14: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 000000053D18: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000053D20: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 000000053D24: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 000000053D28: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 000000053D30: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053D34: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 000000053D38: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 000000053D40: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053D44: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 000000053D48: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 000000053D50: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000053D58: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000053D5C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 000000053D64: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 000000053D70: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000053D78: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000053D7C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000053D88: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000053D90: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000053D94: BE882004
	s_cbranch_execz 58204                                      // 000000053D98: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x420c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 000000053D9C: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000053DA8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000053DB0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000053DB4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053DB8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000053DBC: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000053DC4: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000053DD0: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000053DD4: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000053DD8: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000053DDC: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000053DE4: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000053DEC: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000053DF0: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000053DF4: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000053DF8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053DFC: BF870095
	.long 0xd71c0012                                           // 000000053E00: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000053E04: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000053E08: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000053E0C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053E14: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 000000053E18: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000053E24: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053E28: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000053E2C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000053E34: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053E38: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000053E3C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 000000053E44: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000053E48: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053E50: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 000000053E54: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 000000053E58: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053E60: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 000000053E64: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 000000053E68: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053E70: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 000000053E74: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000053E7C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 000000053E84: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053E90: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000053E94: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000053E9C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000053EA8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000053EB0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000053EB4: BE882005
	s_cbranch_execz 58135                                      // 000000053EB8: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4218>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 000000053EBC: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000053EC8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000053ED0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000053ED4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053ED8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000053EDC: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000053EE4: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000053EF0: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000053EF4: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000053EF8: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000053EFC: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000053F04: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000053F0C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000053F10: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000053F14: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000053F18: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053F1C: BF870095
	.long 0xd71c0012                                           // 000000053F20: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000053F24: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000053F28: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000053F2C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053F34: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 000000053F38: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 000000053F40: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053F48: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000053F4C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000053F54: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053F58: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000053F5C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 000000053F64: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000053F68: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053F70: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 000000053F74: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 000000053F78: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053F80: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 000000053F84: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 000000053F88: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053F90: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 000000053F94: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000053F9C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 000000053FA4: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053FB0: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000053FB4: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000053FBC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000053FC8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000053FD0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000053FD4: BE882006
	s_cbranch_execz 58066                                      // 000000053FD8: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4224>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 000000053FDC: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000053FE8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000053FF0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000053FF4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000053FF8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000053FFC: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000054004: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000054010: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000054014: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000054018: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000005401C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000054024: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005402C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000054030: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000054034: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000054038: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005403C: BF870095
	.long 0xd71c0012                                           // 000000054040: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000054044: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000054048: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000005404C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054054: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 000000054058: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000054064: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054068: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000005406C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000054074: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054078: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000005407C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 000000054084: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000054088: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054090: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 000000054094: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 000000054098: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000540A0: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000000540A4: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000540A8: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000540B0: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000540B4: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000540BC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 0000000540C4: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000540D0: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000540D4: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000540DC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000540E8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000540F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000540F4: BE882007
	s_cbranch_execz 57997                                      // 0000000540F8: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4230>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 0000000540FC: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000054108: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000054110: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000054114: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054118: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000005411C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000054124: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000054130: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000054134: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000054138: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000005413C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000054144: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005414C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000054150: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000054154: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000054158: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005415C: BF870095
	.long 0xd71c0012                                           // 000000054160: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000054164: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000054168: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 00000005416C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054174: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 000000054178: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000054184: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054188: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 00000005418C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000054194: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054198: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 00000005419C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000541A4: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000541A8: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000541B0: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000541B4: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000000541B8: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000541C0: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000000541C4: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000541C8: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000541D0: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000541D4: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000541DC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 0000000541E4: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000541F0: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000541F4: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000541FC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000054208: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000054210: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000054214: BE882000
	s_cbranch_execz 57928                                      // 000000054218: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x423c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 00000005421C: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 000000054228: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 00000005422C: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000054234: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000054238: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005423C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000054240: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000054248: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000054254: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000054258: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000005425C: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000054260: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000054268: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000054270: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000054274: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000054278: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000005427C: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054280: BF870095
	.long 0xd71c0012                                           // 000000054284: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000054288: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000005428C: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000054290: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054298: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 00000005429C: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000542A4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000542A8: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 0000000542AC: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 0000000542B4: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000542B8: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 0000000542BC: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 0000000542C4: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 0000000542C8: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000542D0: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 0000000542D4: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 0000000542D8: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000542E0: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 0000000542E4: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 0000000542E8: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000542F0: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 0000000542F4: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 0000000542FC: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 000000054304: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054310: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 000000054314: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 00000005431C: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 000000054328: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 000000054330: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000054334: BE882001
	s_cbranch_execz 57859                                      // 000000054338: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4248>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 00000005433C: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 000000054348: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 00000005434C: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 000000054354: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000054358: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005435C: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 000000054360: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000054368: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 000000054370: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000005437C: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000054380: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 000000054384: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 00000005438C: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000054390: BF870121
	v_add_f32_e32 v17, v17, v18                                // 000000054394: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 000000054398: 7E241113
	v_exp_f32_e32 v17, v17                                     // 00000005439C: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000543A0: BF870095
	.long 0xd71c0011                                           // 0000000543A4: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000000543A8: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000000543AC: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000543B0: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000543B8: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 0000000543BC: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000543C4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000543C8: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 0000000543CC: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 0000000543D4: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000543D8: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 0000000543DC: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 0000000543E4: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 0000000543E8: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000543F0: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 0000000543F4: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 0000000543F8: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054400: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 000000054404: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 000000054408: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054410: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 000000054414: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 00000005441C: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 000000054424: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054430: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 000000054434: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 00000005443C: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 000000054448: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 000000054450: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000054454: BE882002
	s_cbranch_execz 57790                                      // 000000054458: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4254>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 00000005445C: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000054468: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000054470: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000054474: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054478: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000005447C: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 000000054484: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 000000054490: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000054494: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 000000054498: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000005449C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 0000000544A4: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000544AC: BF870121
	v_add_f32_e32 v10, v10, v17                                // 0000000544B0: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 0000000544B4: 7E221112
	v_exp_f32_e32 v10, v10                                     // 0000000544B8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000544BC: BF870095
	.long 0xd71c000a                                           // 0000000544C0: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 0000000544C4: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000544C8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000544CC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000544D4: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 0000000544D8: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000544E4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000544E8: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000544EC: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 0000000544F4: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000544F8: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 0000000544FC: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 000000054504: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 000000054508: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054510: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 000000054514: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 000000054518: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054520: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 000000054524: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 000000054528: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054530: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 000000054534: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000005453C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 000000054544: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054550: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 000000054554: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 00000005455C: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000054568: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000054570: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000054574: BE882003
	s_cbranch_execz 57721                                      // 000000054578: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4260>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 00000005457C: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000054588: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000054590: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000054594: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054598: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000005459C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000545A4: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 0000000545B0: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000545B4: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 0000000545B8: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 0000000545C4: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 0000000545C8: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000545CC: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000545D4: BF870293
	v_exp_f32_e32 v10, v10                                     // 0000000545D8: 7E144B0A
	.long 0xd71c000a                                           // 0000000545DC: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000545E0: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000545E4: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000545E8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000545EC: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 0000000545F4: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054600: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 000000054604: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000054608: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000054610: BF870291
	v_rcp_f32_e32 v12, v11                                     // 000000054614: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 000000054618: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000054620: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 000000054624: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 000000054628: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 000000054630: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054634: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 000000054638: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 000000054640: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054644: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 000000054648: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 000000054650: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000054658: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000005465C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 000000054664: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 000000054670: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000054678: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000005467C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000054688: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000054690: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000054694: BE882004
	s_cbranch_execz 57652                                      // 000000054698: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x426c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 00000005469C: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000546A8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000546B0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000546B4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000546B8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000546BC: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000546C4: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000546D0: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000546D4: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000546D8: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000546DC: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000546E4: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000546EC: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000546F0: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000546F4: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000546F8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000546FC: BF870095
	.long 0xd71c000a                                           // 000000054700: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000054704: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000054708: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000005470C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054714: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 000000054718: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000054724: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054728: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000005472C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000054734: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054738: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000005473C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000054744: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000054748: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054750: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 000000054754: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 000000054758: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054760: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 000000054764: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 000000054768: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054770: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 000000054774: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000005477C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 000000054784: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054790: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000054794: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000005479C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000547A8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000547B0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000547B4: BE882005
	s_cbranch_execz 57583                                      // 0000000547B8: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4278>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 0000000547BC: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000547C8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000547D0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000547D4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000547D8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000547DC: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000547E4: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000547F0: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000547F4: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000547F8: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000547FC: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000054804: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005480C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000054810: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000054814: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000054818: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005481C: BF870095
	.long 0xd71c000a                                           // 000000054820: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000054824: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000054828: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000005482C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054834: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 000000054838: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 000000054840: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054848: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000005484C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000054854: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054858: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000005485C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000054864: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000054868: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054870: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000054874: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 000000054878: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054880: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 000000054884: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 000000054888: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054890: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000054894: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000005489C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 0000000548A4: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000548B0: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000548B4: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000548BC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000548C8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000548D0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000548D4: BE882006
	s_cbranch_execz 57514                                      // 0000000548D8: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4284>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 0000000548DC: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000548E8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000548F0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000548F4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000548F8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000548FC: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000054904: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000054910: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000054914: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000054918: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000005491C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000054924: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005492C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000054930: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000054934: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000054938: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005493C: BF870095
	.long 0xd71c000a                                           // 000000054940: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000054944: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000054948: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000005494C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054954: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 000000054958: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000054964: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054968: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000005496C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000054974: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054978: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000005497C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000054984: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000054988: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054990: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000054994: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 000000054998: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000549A0: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000000549A4: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 0000000549A8: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000549B0: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000549B4: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000549BC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 0000000549C4: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000549D0: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000549D4: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000549DC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000549E8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000549F0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000549F4: BE882007
	s_cbranch_execz 57445                                      // 0000000549F8: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4290>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 0000000549FC: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000054A08: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000054A10: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000054A14: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054A18: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000054A1C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000054A24: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000054A30: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000054A34: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000054A38: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000054A3C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000054A44: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000054A4C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000054A50: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000054A54: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000054A58: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054A5C: BF870095
	.long 0xd71c000a                                           // 000000054A60: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000054A64: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000054A68: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000054A6C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054A74: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 000000054A78: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000054A84: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054A88: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000054A8C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000054A94: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054A98: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000054A9C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000054AA4: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000054AA8: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054AB0: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000054AB4: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 000000054AB8: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054AC0: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 000000054AC4: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 000000054AC8: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054AD0: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000054AD4: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000054ADC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 000000054AE4: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054AF0: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000054AF4: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000054AFC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000054B08: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000054B10: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000054B14: BE882000
	s_cbranch_execz 57376                                      // 000000054B18: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x429c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 000000054B1C: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 000000054B28: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 000000054B2C: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000054B34: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000054B38: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054B3C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000054B40: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000054B48: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000054B54: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000054B58: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000054B5C: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000054B60: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000054B68: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000054B70: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000054B74: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000054B78: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000054B7C: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054B80: BF870095
	.long 0xd71c000a                                           // 000000054B84: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000054B88: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000054B8C: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000054B90: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054B98: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 000000054B9C: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000054BA4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054BA8: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 000000054BAC: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 000000054BB4: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054BB8: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 000000054BBC: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 000000054BC4: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 000000054BC8: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054BD0: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 000000054BD4: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 000000054BD8: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054BE0: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 000000054BE4: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 000000054BE8: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054BF0: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 000000054BF4: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 000000054BFC: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 000000054C04: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054C10: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 000000054C14: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 000000054C1C: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 000000054C28: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 000000054C30: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 000000054C34: BE802001
	s_cbranch_execz 57307                                      // 000000054C38: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42a8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 000000054C3C: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000054C48: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000054C50: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000054C54: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054C58: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000054C5C: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 000000054C64: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 000000054C70: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000054C74: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 000000054C78: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 000000054C7C: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000054C84: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000054C8C: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 000000054C90: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 000000054C94: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 000000054C98: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054C9C: BF870095
	.long 0xd71c0001                                           // 000000054CA0: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 000000054CA4: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000054CA8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000054CAC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054CB4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 000000054CB8: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000054CC4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054CC8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000054CCC: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 000000054CD4: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054CD8: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 000000054CDC: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 000000054CE4: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 000000054CE8: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054CF0: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 000000054CF4: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 000000054CF8: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054D00: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 000000054D04: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 000000054D08: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054D10: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 000000054D14: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000054D1C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 000000054D24: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054D30: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 000000054D34: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 000000054D3C: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000054D48: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000054D50: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 000000054D54: BE802002
	s_cbranch_execz 57238                                      // 000000054D58: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42b4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 000000054D5C: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000054D68: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000054D70: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000054D74: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054D78: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000054D7C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000054D84: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 000000054D90: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000054D94: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 000000054D98: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000054D9C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000054DA4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000054DAC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000054DB0: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 000000054DB4: 7E041109
	v_exp_f32_e32 v1, v1                                       // 000000054DB8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054DBC: BF870095
	.long 0xd71c0001                                           // 000000054DC0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000054DC4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000054DC8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000054DCC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054DD4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 000000054DD8: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000054DE4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054DE8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000054DEC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000054DF4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054DF8: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 000000054DFC: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 000000054E04: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 000000054E08: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054E10: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 000000054E14: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 000000054E18: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054E20: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 000000054E24: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 000000054E28: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054E30: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 000000054E34: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000054E3C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 000000054E44: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054E50: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000054E54: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000054E5C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000054E68: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000054E70: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 000000054E74: BE802003
	s_cbranch_execz 57169                                      // 000000054E78: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42c0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 000000054E7C: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000054E88: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000054E90: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000054E94: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054E98: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000054E9C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000054EA4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000054EB0: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000054EB4: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000054EB8: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000054EBC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000054EC4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000054ECC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000054ED0: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000054ED4: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000054ED8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054EDC: BF870095
	.long 0xd71c0001                                           // 000000054EE0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000054EE4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000054EE8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000054EEC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054EF4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 000000054EF8: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000054F04: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054F08: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000054F0C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000054F14: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054F18: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000054F1C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000054F24: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000054F28: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054F30: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 000000054F34: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 000000054F38: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054F40: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 000000054F44: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 000000054F48: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054F50: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 000000054F54: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000054F5C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 000000054F64: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054F70: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000054F74: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000054F7C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000054F88: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000054F90: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000054F94: BE802004
	s_cbranch_execz 57100                                      // 000000054F98: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42cc>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 000000054F9C: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000054FA8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000054FB0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000054FB4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054FB8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000054FBC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000054FC4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000054FD0: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000054FD4: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000054FD8: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000054FDC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000054FE4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000054FEC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000054FF0: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000054FF4: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000054FF8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000054FFC: BF870095
	.long 0xd71c0001                                           // 000000055000: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000055004: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000055008: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000005500C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055014: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 000000055018: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 000000055020: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055028: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000005502C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000055034: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055038: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000005503C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000055044: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000055048: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055050: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000055054: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 000000055058: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055060: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 000000055064: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 000000055068: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055070: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000055074: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000005507C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 000000055084: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055090: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000055094: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000005509C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000550A8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000550B0: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000000550B4: BE802005
	s_cbranch_execz 57031                                      // 0000000550B8: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42d8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 0000000550BC: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000550C8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000550D0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000550D4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000550D8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000550DC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000550E4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000550F0: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000550F4: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000550F8: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000550FC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000055104: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005510C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000055110: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000055114: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000055118: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005511C: BF870095
	.long 0xd71c0001                                           // 000000055120: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000055124: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000055128: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000005512C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055134: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 000000055138: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000055144: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055148: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000005514C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000055154: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055158: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000005515C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000055164: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000055168: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055170: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000055174: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 000000055178: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055180: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 000000055184: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 000000055188: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055190: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000055194: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000005519C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 0000000551A4: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000551B0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000551B4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000551BC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000551C8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000551D0: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000000551D4: BE802006
	s_cbranch_execz 56962                                      // 0000000551D8: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42e4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 0000000551DC: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000551E8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000551F0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000551F4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000551F8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000551FC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000055204: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000055210: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000055214: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000055218: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000005521C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000055224: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005522C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000055230: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000055234: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000055238: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005523C: BF870095
	.long 0xd71c0001                                           // 000000055240: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000055244: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000055248: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000005524C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055254: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 000000055258: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000055264: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055268: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000005526C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000055274: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055278: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000005527C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000055284: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000055288: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055290: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000055294: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 000000055298: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000552A0: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000552A4: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000552A8: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000552B0: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000552B4: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000552BC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 0000000552C4: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000552D0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000552D4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000552DC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000552E8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000552F0: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000000552F4: BE802007
	s_cbranch_execz 56893                                      // 0000000552F8: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi1ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42f0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 0000000552FC: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000055308: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000055310: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000055314: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055318: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000005531C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000055324: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000055330: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000055334: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000055338: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000005533C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000055344: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005534C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000055350: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000055354: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000055358: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005535C: BF870095
	.long 0xd71c0001                                           // 000000055360: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000055364: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000055368: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000005536C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055374: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 000000055378: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000055384: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055388: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000005538C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000055394: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000055398: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000005539C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000553A4: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000553A8: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000553B0: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000553B4: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000553B8: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000553C0: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000553C4: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000553C8: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000553D0: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000553D4: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000553DC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 0000000553E4: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000553F0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000553F4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000553FC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000055408: DC9601E0 007C0200
	s_nop 0                                                    // 000000055410: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000055414: BFB60003
	s_endpgm                                                   // 000000055418: BFB00000
		...

