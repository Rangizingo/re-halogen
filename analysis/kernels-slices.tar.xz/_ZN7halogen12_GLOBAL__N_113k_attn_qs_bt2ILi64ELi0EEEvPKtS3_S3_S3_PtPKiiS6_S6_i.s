00000000001adf00 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_clause 0x1                                               // 0000001ADF00: BF850001
	s_load_b64 s[4:5], s[0:1], 0x28                            // 0000001ADF04: F4040100 F8000028
	s_load_b32 s17, s[0:1], 0x48                               // 0000001ADF0C: F4000440 F8000048
	s_mov_b32 s16, s3                                          // 0000001ADF14: BE900003
	s_ashr_i32 s3, s2, 31                                      // 0000001ADF18: 86039F02
	s_waitcnt lgkmcnt(0)                                       // 0000001ADF1C: BF89FC07
	s_load_b32 s10, s[4:5], null                               // 0000001ADF20: F4000282 F8000000
	s_clause 0x1                                               // 0000001ADF28: BF850001
	s_load_b128 s[4:7], s[0:1], 0x38                           // 0000001ADF2C: F4080100 F8000038
	s_load_b128 s[12:15], s[0:1], 0x18                         // 0000001ADF34: F4080300 F8000018
	s_lshl_b64 s[8:9], s[2:3], 2                               // 0000001ADF3C: 84888202
	s_waitcnt lgkmcnt(0)                                       // 0000001ADF40: BF89FC07
	s_add_i32 s3, s10, s2                                      // 0000001ADF44: 8103020A
	s_add_u32 s6, s6, s8                                       // 0000001ADF48: 80060806
	s_addc_u32 s7, s7, s9                                      // 0000001ADF4C: 82070907
	s_add_i32 s9, s3, 1                                        // 0000001ADF50: 81098103
	s_load_b32 s8, s[6:7], null                                // 0000001ADF54: F4000203 F8000000
	s_ashr_i32 s6, s9, 31                                      // 0000001ADF5C: 86069F09
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001ADF60: BF870499
	s_lshr_b32 s6, s6, 30                                      // 0000001ADF64: 85069E06
	s_add_i32 s6, s9, s6                                       // 0000001ADF68: 81060609
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001ADF6C: BF870009
	s_and_b32 s7, s6, -4                                       // 0000001ADF70: 8B07C406
	s_ashr_i32 s11, s6, 2                                      // 0000001ADF74: 860B8206
	s_sub_i32 s9, s3, s7                                       // 0000001ADF78: 81890703
	s_mul_hi_i32 s7, s17, s2                                   // 0000001ADF7C: 97070211
	s_cmp_gt_i32 s9, -1                                        // 0000001ADF80: BF02C109
	s_mul_i32 s6, s17, s2                                      // 0000001ADF84: 96060211
	s_cselect_b32 s3, -1, 0                                    // 0000001ADF88: 980380C1
	s_mov_b32 s17, s11                                         // 0000001ADF8C: BE91000B
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000001ADF90: 8B6A037E
	s_cbranch_vccnz 15                                         // 0000001ADF94: BFA4000F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd4>
	s_lshl_b64 s[18:19], s[6:7], 2                             // 0000001ADF98: 84928206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001ADF9C: BF8704D9
	s_add_u32 s10, s4, s18                                     // 0000001ADFA0: 800A1204
	s_addc_u32 s17, s5, s19                                    // 0000001ADFA4: 82111305
	s_waitcnt lgkmcnt(0)                                       // 0000001ADFA8: BF89FC07
	s_max_i32 s18, s8, 1                                       // 0000001ADFAC: 8A128108
	s_mov_b32 s19, 0                                           // 0000001ADFB0: BE930080
	s_lshl_b64 s[18:19], s[18:19], 2                           // 0000001ADFB4: 84928212
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001ADFB8: BF870009
	s_add_u32 s10, s10, s18                                    // 0000001ADFBC: 800A120A
	s_addc_u32 s17, s17, s19                                   // 0000001ADFC0: 82111311
	s_add_u32 s18, s10, -4                                     // 0000001ADFC4: 8012C40A
	s_addc_u32 s19, s17, -1                                    // 0000001ADFC8: 8213C111
	s_load_b32 s17, s[18:19], null                             // 0000001ADFCC: F4000449 F8000000
	v_cndmask_b32_e64 v1, 0, 1, s3                             // 0000001ADFD4: D5010001 000D0280
	s_mov_b32 s20, exec_lo                                     // 0000001ADFDC: BE94007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001ADFE0: BF8704B1
	v_readfirstlane_b32 s3, v1                                 // 0000001ADFE4: 7E060501
	s_waitcnt lgkmcnt(0)                                       // 0000001ADFE8: BF89FC07
	s_add_i32 s18, s8, s3                                      // 0000001ADFEC: 81120308
	s_add_i32 s10, s18, 3                                      // 0000001ADFF0: 810A8312
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001ADFF4: BF870499
	s_and_b32 s19, s10, -4                                     // 0000001ADFF8: 8B13C40A
	.long 0xd4c4007e                                           // 0000001ADFFC: D4C4007E
	v_cndmask_b32_e32 v1, s19, v0, vcc_lo                      // 0000001AE000: 02020013
	s_cbranch_execz 44                                         // 0000001AE004: BFA5002C <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1b8>
	v_dual_mov_b32 v4, v0 :: v_dual_lshlrev_b32 v3, 2, v0      // 0000001AE008: CA220100 04020082
	s_lshl_b64 s[6:7], s[6:7], 2                               // 0000001AE010: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AE014: BF8700A9
	s_add_u32 s3, s4, s6                                       // 0000001AE018: 80030604
	s_addc_u32 s4, s5, s7                                      // 0000001AE01C: 82040705
	.long 0xd7000301                                           // 0000001AE020: D7000301
	v_cndmask_b32_e32 v1, s3, v3, vcc_lo                       // 0000001AE024: 02020603
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AE028: BF870001
	v_add_co_ci_u32_e64 v2, null, s4, 0, s3                    // 0000001AE02C: D5207C02 000D0004
	s_mov_b32 s4, 0                                            // 0000001AE034: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001AE038: BF840001
	s_branch 17                                                // 0000001AE03C: BFA00011 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x184>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000001AE040: 8C7E037E
	v_add_nc_u32_e32 v4, 64, v4                                // 0000001AE044: 4A0808C0
	.long 0xd7000301                                           // 0000001AE048: D7000301
	v_cndmask_b32_e32 v1, 0x100, v1, vcc_lo                    // 0000001AE04C: 020202FF 00000100
	s_waitcnt vmcnt(0)                                         // 0000001AE054: BF8903F7
	ds_store_b32 v3, v5 offset:1024                            // 0000001AE058: D8340400 00000503
	v_add_co_ci_u32_e64 v2, null, 0, v2, s3                    // 0000001AE060: D5207C02 000E0480
	v_cmp_le_i32_e32 vcc_lo, s19, v4                           // 0000001AE068: 7C860813
	v_add_nc_u32_e32 v3, 0x100, v3                             // 0000001AE06C: 4A0606FF 00000100
	s_or_b32 s4, vcc_lo, s4                                    // 0000001AE074: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AE078: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001AE07C: 917E047E
	s_cbranch_execz 13                                         // 0000001AE080: BFA5000D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1b8>
	s_mov_b32 s3, exec_lo                                      // 0000001AE084: BE83007E
	.long 0xd4c3007e                                           // 0000001AE088: D4C3007E
	v_cndmask_b32_e32 v1, s8, v4, vcc_lo                       // 0000001AE08C: 02020808
	s_xor_b32 s3, exec_lo, s3                                  // 0000001AE090: 8D03037E
	v_mov_b32_e32 v5, s11                                      // 0000001AE094: 7E0A020B
	v_cmp_gt_i32_e32 vcc_lo, s18, v4                           // 0000001AE098: 7C880812
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AE09C: BF870002
	v_cndmask_b32_e32 v5, s17, v5, vcc_lo                      // 0000001AE0A0: 020A0A11
	s_and_not1_saveexec_b32 s3, s3                             // 0000001AE0A4: BE833003
	s_cbranch_execz 65509                                      // 0000001AE0A8: BFA5FFE5 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	global_load_b32 v5, v[1:2], off                            // 0000001AE0AC: DC520000 057C0001
	s_branch 65506                                             // 0000001AE0B4: BFA0FFE2 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	s_set_inst_prefetch_distance 0x2                           // 0000001AE0B8: BF840002
	s_or_b32 exec_lo, exec_lo, s20                             // 0000001AE0BC: 8C7E147E
	s_load_b128 s[4:7], s[0:1], null                           // 0000001AE0C0: F4080100 F8000000
	v_lshrrev_b32_e32 v90, 5, v0                               // 0000001AE0C8: 32B40085
	s_mov_b32 s1, exec_lo                                      // 0000001AE0CC: BE81007E
	v_cmpx_gt_u32_e32 0x180, v0                                // 0000001AE0D0: 7D9800FF 00000180
	s_cbranch_execz 62                                         // 0000001AE0D8: BFA5003E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x2d4>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AE0DC: BF870002
	v_mul_u32_u24_e32 v1, 0x210, v90                           // 0000001AE0E0: 1602B4FF 00000210
	v_and_b32_e32 v2, 31, v0                                   // 0000001AE0E8: 3604009F
	s_mul_i32 s18, s16, 0xc00                                  // 0000001AE0EC: 9612FF10 00000C00
	s_mul_i32 s3, s2, 0x3000                                   // 0000001AE0F4: 9603FF02 00003000
	s_ashr_i32 s19, s18, 31                                    // 0000001AE0FC: 86139F12
	s_mul_hi_i32 s0, s2, 0x3000                                // 0000001AE100: 9700FF02 00003000
	s_lshl_b64 s[18:19], s[18:19], 1                           // 0000001AE108: 84928112
	v_lshl_add_u32 v4, v2, 4, v1                               // 0000001AE10C: D6460004 04050902
	v_lshlrev_b32_e32 v1, 4, v0                                // 0000001AE114: 30020084
	s_waitcnt lgkmcnt(0)                                       // 0000001AE118: BF89FC07
	s_add_u32 s4, s4, s18                                      // 0000001AE11C: 80041204
	s_addc_u32 s5, s5, s19                                     // 0000001AE120: 82051305
	s_add_u32 s3, s4, s3                                       // 0000001AE124: 80030304
	s_addc_u32 s0, s5, s0                                      // 0000001AE128: 82000005
	.long 0xd7000301                                           // 0000001AE12C: D7000301
	v_cndmask_b32_e32 v1, s3, v1, vcc_lo                       // 0000001AE130: 02020203
	v_lshl_or_b32 v3, v0, 3, 0xfffffe00                        // 0000001AE134: D6560003 03FD0700 FFFFFE00
	v_add_co_ci_u32_e64 v2, null, s0, 0, s3                    // 0000001AE140: D5207C02 000D0000
	s_mov_b32 s3, 0                                            // 0000001AE148: BE830080
	s_nop 0                                                    // 0000001AE14C: BF800000
	s_nop 0                                                    // 0000001AE150: BF800000
	s_nop 0                                                    // 0000001AE154: BF800000
	s_nop 0                                                    // 0000001AE158: BF800000
	s_nop 0                                                    // 0000001AE15C: BF800000
	s_nop 0                                                    // 0000001AE160: BF800000
	s_nop 0                                                    // 0000001AE164: BF800000
	s_nop 0                                                    // 0000001AE168: BF800000
	s_nop 0                                                    // 0000001AE16C: BF800000
	s_nop 0                                                    // 0000001AE170: BF800000
	s_nop 0                                                    // 0000001AE174: BF800000
	s_nop 0                                                    // 0000001AE178: BF800000
	s_nop 0                                                    // 0000001AE17C: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 0000001AE180: DC5E0000 057C0001
	v_add_nc_u32_e32 v3, 0x200, v3                             // 0000001AE188: 4A0606FF 00000200
	.long 0xd7006a01                                           // 0000001AE190: D7006A01
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001AE194: 020202FF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AE19C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000001AE1A0: D5207C02 01AA0480
	.long 0xd4490000                                           // 0000001AE1A8: D4490000
	v_cndmask_b32_e32 v1, 0x9ff, v3, vcc_lo                    // 0000001AE1AC: 020206FF 000009FF
	s_or_b32 s3, s0, s3                                        // 0000001AE1B4: 8C030300
	s_waitcnt vmcnt(0)                                         // 0000001AE1B8: BF8903F7
	ds_store_b128 v4, v[5:8] offset:9232                       // 0000001AE1BC: DB7C2410 00000504
	v_add_nc_u32_e32 v4, 0x420, v4                             // 0000001AE1C4: 4A0808FF 00000420
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 0000001AE1CC: 917E037E
	s_cbranch_execnz 65515                                     // 0000001AE1D0: BFA6FFEB <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x280>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001AE1D4: 8C7E017E
	v_and_b32_e32 v88, 15, v0                                  // 0000001AE1D8: 36B0008F
	v_bfe_u32 v91, v0, 4, 1                                    // 0000001AE1DC: D610005B 02050900
	s_ashr_i32 s1, s10, 2                                      // 0000001AE1E4: 8601820A
	s_mov_b32 s18, 0                                           // 0000001AE1E8: BE920080
	s_cmp_gt_i32 s1, 0                                         // 0000001AE1EC: BF028001
	s_waitcnt lgkmcnt(0)                                       // 0000001AE1F0: BF89FC07
	s_barrier                                                  // 0000001AE1F4: BFBD0000
	buffer_gl0_inv                                             // 0000001AE1F8: E0AC0000 00000000
	s_cbranch_scc0 1386                                        // 0000001AE200: BFA1056A <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x18ac>
	s_ashr_i32 s17, s16, 31                                    // 0000001AE204: 86119F10
	v_dual_mov_b32 v64, 0 :: v_dual_lshlrev_b32 v1, 2, v88     // 0000001AE208: CA220080 4000B082
	s_lshl2_add_u32 s0, s8, s9                                 // 0000001AE210: 87800908
	v_dual_mov_b32 v115, 0xf149f2ca :: v_dual_lshlrev_b32 v0, 5, v0// 0000001AE214: CA2200FF 73000085 F149F2CA
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AE220: BF870002
	v_dual_mov_b32 v66, v64 :: v_dual_lshlrev_b32 v3, 10, v90  // 0000001AE224: CA220140 4202B48A
	s_lshl_b64 s[4:5], s[16:17], 11                            // 0000001AE22C: 84848B10
	v_cmp_gt_u32_e32 vcc_lo, 12, v88                           // 0000001AE230: 7C98B08C
	s_add_i32 s3, s0, 1                                        // 0000001AE234: 81038100
	s_add_u32 s0, s6, s4                                       // 0000001AE238: 80000406
	s_addc_u32 s4, s7, s5                                      // 0000001AE23C: 82040507
	v_dual_mov_b32 v67, v64 :: v_dual_and_b32 v0, 0x60, v0     // 0000001AE240: CA240140 430000FF 00000060
	.long 0xd7000005                                           // 0000001AE24C: D7000005
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000001AE250: 02020600
	v_lshl_or_b32 v1, v91, 6, v1                               // 0000001AE254: D6560001 04050D5B
	v_cndmask_b32_e32 v2, 0, v88, vcc_lo                       // 0000001AE25C: 0204B080
	v_add_co_ci_u32_e64 v6, null, s4, 0, s0                    // 0000001AE260: D5207C06 00010004
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AE268: BF870004
	.long 0xd7006a5c                                           // 0000001AE26C: D7006A5C
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 0000001AE270: 02020105
	s_movk_i32 s0, 0x210                                       // 0000001AE274: B0000210
	v_add_nc_u32_e32 v1, 0x3cd0, v1                            // 0000001AE278: 4A0202FF 00003CD0
	v_dual_mov_b32 v65, v64 :: v_dual_lshlrev_b32 v4, 9, v90   // 0000001AE280: CA220140 4104B489
	v_add_co_ci_u32_e64 v93, null, 0, v6, vcc_lo               // 0000001AE288: D5207C5D 01AA0C80
	v_xor_b32_e32 v0, 1, v90                                   // 0000001AE290: 3A00B481
	v_dual_mov_b32 v68, v64 :: v_dual_lshlrev_b32 v5, 5, v91   // 0000001AE294: CA220140 4404B685
	v_dual_mov_b32 v69, v64 :: v_dual_lshlrev_b32 v6, 1, v88   // 0000001AE29C: CA220140 4506B081
	v_mad_u32_u24 v2, v2, s0, 0x2410                           // 0000001AE2A4: D60B0002 03FC0102 00002410
	v_dual_mov_b32 v70, v64 :: v_dual_lshlrev_b32 v7, 8, v90   // 0000001AE2B0: CA220140 4606B488
	v_dual_mov_b32 v71, v64 :: v_dual_add_nc_u32 v94, v1, v3   // 0000001AE2B8: CA200140 475E0701
	v_lshl_add_u32 v95, v0, 10, v1                             // 0000001AE2C0: D646005F 04051500
	v_or3_b32 v96, v4, v5, v6                                  // 0000001AE2C8: D6580060 041A0B04
	v_lshl_or_b32 v97, v88, 5, v4                              // 0000001AE2D0: D6560061 04110B58
	v_dual_mov_b32 v111, 0xf149f2ca :: v_dual_and_b32 v98, 12, v88// 0000001AE2D8: CA2400FF 6F62B08C F149F2CA
	v_dual_mov_b32 v116, 0xf149f2ca :: v_dual_add_nc_u32 v99, v2, v7// 0000001AE2E4: CA2000FF 74620F02 F149F2CA
	v_dual_mov_b32 v114, 0xf149f2ca :: v_dual_mov_b32 v109, 0xf149f2ca// 0000001AE2F0: CA1000FF 726C00FF F149F2CA
	v_dual_mov_b32 v112, 0xf149f2ca :: v_dual_mov_b32 v101, v64// 0000001AE2FC: CA1000FF 70640140 F149F2CA
	v_dual_mov_b32 v110, 0xf149f2ca :: v_dual_mov_b32 v103, v64// 0000001AE308: CA1000FF 6E660140 F149F2CA
	v_dual_mov_b32 v108, 0xf149f2ca :: v_dual_mov_b32 v105, v64// 0000001AE314: CA1000FF 6C680140 F149F2CA
	v_mov_b32_e32 v102, v64                                    // 0000001AE320: 7ECC0340
	v_mov_b32_e32 v104, v64                                    // 0000001AE324: 7ED00340
	v_mov_b32_e32 v106, v64                                    // 0000001AE328: 7ED40340
	v_mov_b32_e32 v107, v64                                    // 0000001AE32C: 7ED60340
	v_mov_b32_e32 v100, v64                                    // 0000001AE330: 7EC80340
	v_mov_b32_e32 v56, v64                                     // 0000001AE334: 7E700340
	v_mov_b32_e32 v57, v64                                     // 0000001AE338: 7E720340
	v_mov_b32_e32 v58, v64                                     // 0000001AE33C: 7E740340
	v_mov_b32_e32 v59, v64                                     // 0000001AE340: 7E760340
	v_mov_b32_e32 v60, v64                                     // 0000001AE344: 7E780340
	v_mov_b32_e32 v61, v64                                     // 0000001AE348: 7E7A0340
	v_mov_b32_e32 v62, v64                                     // 0000001AE34C: 7E7C0340
	v_mov_b32_e32 v63, v64                                     // 0000001AE350: 7E7E0340
	v_mov_b32_e32 v48, v64                                     // 0000001AE354: 7E600340
	v_mov_b32_e32 v49, v64                                     // 0000001AE358: 7E620340
	v_mov_b32_e32 v50, v64                                     // 0000001AE35C: 7E640340
	v_mov_b32_e32 v51, v64                                     // 0000001AE360: 7E660340
	v_mov_b32_e32 v52, v64                                     // 0000001AE364: 7E680340
	v_mov_b32_e32 v53, v64                                     // 0000001AE368: 7E6A0340
	v_mov_b32_e32 v54, v64                                     // 0000001AE36C: 7E6C0340
	v_mov_b32_e32 v55, v64                                     // 0000001AE370: 7E6E0340
	v_mov_b32_e32 v40, v64                                     // 0000001AE374: 7E500340
	v_mov_b32_e32 v41, v64                                     // 0000001AE378: 7E520340
	v_mov_b32_e32 v42, v64                                     // 0000001AE37C: 7E540340
	v_mov_b32_e32 v43, v64                                     // 0000001AE380: 7E560340
	v_mov_b32_e32 v44, v64                                     // 0000001AE384: 7E580340
	v_mov_b32_e32 v45, v64                                     // 0000001AE388: 7E5A0340
	v_mov_b32_e32 v46, v64                                     // 0000001AE38C: 7E5C0340
	v_mov_b32_e32 v47, v64                                     // 0000001AE390: 7E5E0340
	v_mov_b32_e32 v32, v64                                     // 0000001AE394: 7E400340
	v_mov_b32_e32 v33, v64                                     // 0000001AE398: 7E420340
	v_mov_b32_e32 v34, v64                                     // 0000001AE39C: 7E440340
	v_mov_b32_e32 v35, v64                                     // 0000001AE3A0: 7E460340
	v_mov_b32_e32 v36, v64                                     // 0000001AE3A4: 7E480340
	v_mov_b32_e32 v37, v64                                     // 0000001AE3A8: 7E4A0340
	v_mov_b32_e32 v38, v64                                     // 0000001AE3AC: 7E4C0340
	v_mov_b32_e32 v39, v64                                     // 0000001AE3B0: 7E4E0340
	v_mov_b32_e32 v24, v64                                     // 0000001AE3B4: 7E300340
	v_mov_b32_e32 v25, v64                                     // 0000001AE3B8: 7E320340
	v_mov_b32_e32 v26, v64                                     // 0000001AE3BC: 7E340340
	v_mov_b32_e32 v27, v64                                     // 0000001AE3C0: 7E360340
	v_mov_b32_e32 v28, v64                                     // 0000001AE3C4: 7E380340
	v_mov_b32_e32 v29, v64                                     // 0000001AE3C8: 7E3A0340
	v_mov_b32_e32 v30, v64                                     // 0000001AE3CC: 7E3C0340
	v_mov_b32_e32 v31, v64                                     // 0000001AE3D0: 7E3E0340
	v_mov_b32_e32 v16, v64                                     // 0000001AE3D4: 7E200340
	v_mov_b32_e32 v17, v64                                     // 0000001AE3D8: 7E220340
	v_mov_b32_e32 v18, v64                                     // 0000001AE3DC: 7E240340
	v_mov_b32_e32 v19, v64                                     // 0000001AE3E0: 7E260340
	v_mov_b32_e32 v20, v64                                     // 0000001AE3E4: 7E280340
	v_mov_b32_e32 v21, v64                                     // 0000001AE3E8: 7E2A0340
	v_mov_b32_e32 v22, v64                                     // 0000001AE3EC: 7E2C0340
	v_mov_b32_e32 v23, v64                                     // 0000001AE3F0: 7E2E0340
	v_mov_b32_e32 v8, v64                                      // 0000001AE3F4: 7E100340
	v_mov_b32_e32 v9, v64                                      // 0000001AE3F8: 7E120340
	v_mov_b32_e32 v10, v64                                     // 0000001AE3FC: 7E140340
	v_mov_b32_e32 v11, v64                                     // 0000001AE400: 7E160340
	v_mov_b32_e32 v12, v64                                     // 0000001AE404: 7E180340
	v_mov_b32_e32 v13, v64                                     // 0000001AE408: 7E1A0340
	v_mov_b32_e32 v14, v64                                     // 0000001AE40C: 7E1C0340
	v_mov_b32_e32 v15, v64                                     // 0000001AE410: 7E1E0340
	v_mov_b32_e32 v0, v64                                      // 0000001AE414: 7E000340
	v_mov_b32_e32 v1, v64                                      // 0000001AE418: 7E020340
	v_mov_b32_e32 v2, v64                                      // 0000001AE41C: 7E040340
	v_mov_b32_e32 v3, v64                                      // 0000001AE420: 7E060340
	v_mov_b32_e32 v4, v64                                      // 0000001AE424: 7E080340
	v_mov_b32_e32 v5, v64                                      // 0000001AE428: 7E0A0340
	v_mov_b32_e32 v6, v64                                      // 0000001AE42C: 7E0C0340
	v_mov_b32_e32 v7, v64                                      // 0000001AE430: 7E0E0340
	s_mov_b32 s5, 0x3f803f80                                   // 0000001AE434: BE8500FF 3F803F80
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AE43C: BF870009
	s_mov_b32 s7, s5                                           // 0000001AE440: BE870005
	s_mov_b32 s9, s5                                           // 0000001AE444: BE890005
	s_mov_b32 s11, s5                                          // 0000001AE448: BE8B0005
	s_branch 274                                               // 0000001AE44C: BFA00112 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x998>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001AE450: 8C7E007E
	v_bfe_u32 v108, v110, 16, 1                                // 0000001AE454: D610006C 0205216E
	s_add_i32 s8, s18, 3                                       // 0000001AE45C: 81088312
	s_add_i32 s6, s18, 2                                       // 0000001AE460: 81068212
	s_add_i32 s0, s18, 1                                       // 0000001AE464: 81008112
	s_and_b32 s10, s18, 7                                      // 0000001AE468: 8B0A8712
	v_add3_u32 v108, v110, v108, 0x7fff                        // 0000001AE46C: D655006C 03FED96E 00007FFF
	s_add_i32 s17, s18, 5                                      // 0000001AE478: 81118512
	s_add_i32 s19, s18, 6                                      // 0000001AE47C: 81138612
	s_add_i32 s18, s18, -1                                     // 0000001AE480: 8112C112
	s_and_b32 s22, s8, 7                                       // 0000001AE484: 8B168708
	ds_store_b16_d16_hi v96, v108 offset:448                   // 0000001AE488: DA8401C0 00006C60
	ds_load_b128 v[117:120], v97                               // 0000001AE490: DBFC0000 75000061
	ds_load_b128 v[121:124], v97 offset:16                     // 0000001AE498: DBFC0010 79000061
	s_and_b32 s20, s0, 7                                       // 0000001AE4A0: 8B148700
	s_and_b32 s21, s6, 7                                       // 0000001AE4A4: 8B158706
	v_dual_fmac_f32 v89, v102, v115 :: v_dual_fmac_f32 v74, v104, v114// 0000001AE4A8: C800E766 594AE568
	v_dual_fmac_f32 v83, v107, v80 :: v_dual_mul_f32 v56, v56, v113// 0000001AE4B0: C806A16B 5338E338
	s_or_b32 s4, s10, 0x3f803f80                               // 0000001AE4B8: 8C04FF0A 3F803F80
	s_xor_b32 s28, s10, 0x3f803f84                             // 0000001AE4C0: 8D1CFF0A 3F803F84
	s_and_b32 s17, s17, 7                                      // 0000001AE4C8: 8B118711
	s_and_b32 s19, s19, 7                                      // 0000001AE4CC: 8B138713
	s_and_b32 s23, s18, 7                                      // 0000001AE4D0: 8B178712
	s_or_b32 s10, s22, 0x3f803f80                              // 0000001AE4D4: 8C0AFF16 3F803F80
	v_dual_fmac_f32 v75, v105, v112 :: v_dual_fmac_f32 v76, v106, v111// 0000001AE4DC: C800E169 4B4CDF6A
	s_or_b32 s6, s20, 0x3f803f80                               // 0000001AE4E4: 8C06FF14 3F803F80
	s_or_b32 s8, s21, 0x3f803f80                               // 0000001AE4EC: 8C08FF15 3F803F80
	s_or_b32 s17, s17, 0x3f803f80                              // 0000001AE4F4: 8C11FF11 3F803F80
	s_or_b32 s19, s19, 0x3f803f80                              // 0000001AE4FC: 8C13FF13 3F803F80
	s_or_b32 s29, s23, 0x3f803f80                              // 0000001AE504: 8C1DFF17 3F803F80
	s_mov_b64 s[26:27], s[10:11]                               // 0000001AE50C: BE9A010A
	s_mov_b64 s[42:43], s[10:11]                               // 0000001AE510: BEAA010A
	s_mov_b64 s[50:51], s[10:11]                               // 0000001AE514: BEB2010A
	s_mov_b64 s[58:59], s[10:11]                               // 0000001AE518: BEBA010A
	s_mov_b64 s[66:67], s[10:11]                               // 0000001AE51C: BEC2010A
	s_mov_b64 s[74:75], s[10:11]                               // 0000001AE520: BECA010A
	s_mov_b64 s[82:83], s[10:11]                               // 0000001AE524: BED2010A
	s_mov_b64 s[24:25], s[8:9]                                 // 0000001AE528: BE980108
	s_mov_b64 s[22:23], s[6:7]                                 // 0000001AE52C: BE960106
	s_mov_b64 s[20:21], s[4:5]                                 // 0000001AE530: BE940104
	s_mov_b64 s[40:41], s[8:9]                                 // 0000001AE534: BEA80108
	s_mov_b64 s[38:39], s[6:7]                                 // 0000001AE538: BEA60106
	s_mov_b64 s[36:37], s[4:5]                                 // 0000001AE53C: BEA40104
	s_mov_b64 s[48:49], s[8:9]                                 // 0000001AE540: BEB00108
	s_mov_b64 s[46:47], s[6:7]                                 // 0000001AE544: BEAE0106
	s_mov_b64 s[44:45], s[4:5]                                 // 0000001AE548: BEAC0104
	s_mov_b64 s[56:57], s[8:9]                                 // 0000001AE54C: BEB80108
	s_mov_b64 s[54:55], s[6:7]                                 // 0000001AE550: BEB60106
	s_mov_b64 s[52:53], s[4:5]                                 // 0000001AE554: BEB40104
	s_mov_b64 s[64:65], s[8:9]                                 // 0000001AE558: BEC00108
	s_mov_b64 s[62:63], s[6:7]                                 // 0000001AE55C: BEBE0106
	s_mov_b64 s[60:61], s[4:5]                                 // 0000001AE560: BEBC0104
	s_mov_b64 s[72:73], s[8:9]                                 // 0000001AE564: BEC80108
	s_mov_b64 s[70:71], s[6:7]                                 // 0000001AE568: BEC60106
	s_mov_b64 s[68:69], s[4:5]                                 // 0000001AE56C: BEC40104
	s_mov_b64 s[80:81], s[8:9]                                 // 0000001AE570: BED00108
	s_mov_b64 s[78:79], s[6:7]                                 // 0000001AE574: BECE0106
	s_mov_b64 s[76:77], s[4:5]                                 // 0000001AE578: BECC0104
	s_mov_b32 s20, s6                                          // 0000001AE57C: BE940006
	s_mov_b32 s22, s8                                          // 0000001AE580: BE960008
	s_mov_b32 s24, s10                                         // 0000001AE584: BE98000A
	s_mov_b32 s26, s28                                         // 0000001AE588: BE9A001C
	s_mov_b32 s36, s8                                          // 0000001AE58C: BEA40008
	s_mov_b32 s38, s10                                         // 0000001AE590: BEA6000A
	s_mov_b32 s40, s28                                         // 0000001AE594: BEA8001C
	s_mov_b32 s42, s17                                         // 0000001AE598: BEAA0011
	s_mov_b32 s44, s10                                         // 0000001AE59C: BEAC000A
	s_mov_b32 s46, s28                                         // 0000001AE5A0: BEAE001C
	s_mov_b32 s48, s17                                         // 0000001AE5A4: BEB00011
	s_mov_b32 s50, s19                                         // 0000001AE5A8: BEB20013
	s_mov_b32 s52, s28                                         // 0000001AE5AC: BEB4001C
	s_mov_b32 s54, s17                                         // 0000001AE5B0: BEB60011
	s_mov_b32 s56, s19                                         // 0000001AE5B4: BEB80013
	s_mov_b32 s58, s29                                         // 0000001AE5B8: BEBA001D
	s_mov_b32 s60, s17                                         // 0000001AE5BC: BEBC0011
	s_mov_b32 s62, s19                                         // 0000001AE5C0: BEBE0013
	s_mov_b32 s64, s29                                         // 0000001AE5C4: BEC0001D
	s_mov_b32 s66, s4                                          // 0000001AE5C8: BEC20004
	s_mov_b32 s68, s19                                         // 0000001AE5CC: BEC40013
	s_mov_b32 s70, s29                                         // 0000001AE5D0: BEC6001D
	s_mov_b32 s72, s4                                          // 0000001AE5D4: BEC80004
	s_mov_b32 s74, s6                                          // 0000001AE5D8: BECA0006
	s_mov_b32 s76, s29                                         // 0000001AE5DC: BECC001D
	s_mov_b32 s78, s4                                          // 0000001AE5E0: BECE0004
	s_mov_b32 s80, s6                                          // 0000001AE5E4: BED00006
	s_mov_b32 s82, s8                                          // 0000001AE5E8: BED20008
	v_dual_fmac_f32 v87, v101, v113 :: v_dual_fmac_f32 v86, v103, v116// 0000001AE5EC: C800E365 5756E967
	v_fma_f32 v100, v100, v81, v110                            // 0000001AE5F4: D6130064 05BAA364
	v_dual_mul_f32 v59, v59, v114 :: v_dual_mul_f32 v60, v60, v112// 0000001AE5FC: C8C6E53B 3B3CE13C
	v_dual_mul_f32 v61, v61, v111 :: v_dual_mul_f32 v62, v62, v80// 0000001AE604: C8C6DF3D 3D3EA13E
	v_dual_mul_f32 v63, v63, v81 :: v_dual_mul_f32 v50, v50, v116// 0000001AE60C: C8C6A33F 3F32E932
	v_dual_mul_f32 v51, v51, v114 :: v_dual_mul_f32 v52, v52, v112// 0000001AE614: C8C6E533 3334E134
	v_dual_mul_f32 v53, v53, v111 :: v_dual_mul_f32 v54, v54, v80// 0000001AE61C: C8C6DF35 3536A136
	v_dual_mul_f32 v55, v55, v81 :: v_dual_mul_f32 v42, v42, v116// 0000001AE624: C8C6A337 372AE92A
	v_dual_mul_f32 v43, v43, v114 :: v_dual_mul_f32 v44, v44, v112// 0000001AE62C: C8C6E52B 2B2CE12C
	v_dual_mul_f32 v45, v45, v111 :: v_dual_mul_f32 v46, v46, v80// 0000001AE634: C8C6DF2D 2D2EA12E
	v_dual_mul_f32 v47, v47, v81 :: v_dual_mul_f32 v34, v34, v116// 0000001AE63C: C8C6A32F 2F22E922
	v_dual_mul_f32 v35, v35, v114 :: v_dual_mul_f32 v36, v36, v112// 0000001AE644: C8C6E523 2324E124
	v_dual_mul_f32 v37, v37, v111 :: v_dual_mul_f32 v38, v38, v80// 0000001AE64C: C8C6DF25 2526A126
	v_dual_mul_f32 v39, v39, v81 :: v_dual_mul_f32 v26, v26, v116// 0000001AE654: C8C6A327 271AE91A
	v_dual_mul_f32 v27, v27, v114 :: v_dual_mul_f32 v28, v28, v112// 0000001AE65C: C8C6E51B 1B1CE11C
	v_dual_mul_f32 v29, v29, v111 :: v_dual_mul_f32 v30, v30, v80// 0000001AE664: C8C6DF1D 1D1EA11E
	v_dual_mul_f32 v31, v31, v81 :: v_dual_mul_f32 v18, v18, v116// 0000001AE66C: C8C6A31F 1F12E912
	v_dual_mul_f32 v19, v19, v114 :: v_dual_mul_f32 v20, v20, v112// 0000001AE674: C8C6E513 1314E114
	v_dual_mul_f32 v21, v21, v111 :: v_dual_mul_f32 v22, v22, v80// 0000001AE67C: C8C6DF15 1516A116
	v_dual_mul_f32 v23, v23, v81 :: v_dual_mul_f32 v10, v10, v116// 0000001AE684: C8C6A317 170AE90A
	v_dual_mul_f32 v11, v11, v114 :: v_dual_mul_f32 v12, v12, v112// 0000001AE68C: C8C6E50B 0B0CE10C
	v_dual_mul_f32 v13, v13, v111 :: v_dual_mul_f32 v14, v14, v80// 0000001AE694: C8C6DF0D 0D0EA10E
	v_dual_mul_f32 v15, v15, v81 :: v_dual_mul_f32 v2, v2, v116// 0000001AE69C: C8C6A30F 0F02E902
	v_dual_mul_f32 v3, v3, v114 :: v_dual_mul_f32 v4, v4, v112 // 0000001AE6A4: C8C6E503 0304E104
	v_dual_mul_f32 v5, v5, v111 :: v_dual_mul_f32 v6, v6, v80  // 0000001AE6AC: C8C6DF05 0506A106
	v_dual_mul_f32 v7, v7, v81 :: v_dual_add_nc_u32 v98, 16, v98// 0000001AE6B4: C8E0A307 0762C490
	v_dual_mov_b32 v114, v84 :: v_dual_mov_b32 v111, v82       // 0000001AE6BC: CA100154 726E0152
	v_dual_mov_b32 v112, v85 :: v_dual_mov_b32 v109, v78       // 0000001AE6C4: CA100155 706C014E
	v_dual_mov_b32 v110, v77 :: v_dual_mov_b32 v101, v87       // 0000001AE6CC: CA10014D 6E640157
	v_dual_mov_b32 v108, v79 :: v_dual_mov_b32 v103, v86       // 0000001AE6D4: CA10014F 6C660156
	v_dual_mov_b32 v104, v74 :: v_dual_mov_b32 v107, v83       // 0000001AE6DC: CA10014A 686A0153
	v_dual_mov_b32 v84, s11 :: v_dual_mov_b32 v81, s8          // 0000001AE6E4: CA10000B 54500008
	v_dual_mov_b32 v132, s27 :: v_dual_mov_b32 v129, s24       // 0000001AE6EC: CA10001B 84800018
	v_dual_mov_b32 v140, s43 :: v_dual_mov_b32 v137, s40       // 0000001AE6F4: CA10002B 8C880028
	v_dual_mov_b32 v148, s51 :: v_dual_mov_b32 v145, s48       // 0000001AE6FC: CA100033 94900030
	v_dual_mov_b32 v156, s59 :: v_dual_mov_b32 v153, s56       // 0000001AE704: CA10003B 9C980038
	v_dual_mov_b32 v164, s67 :: v_dual_mov_b32 v161, s64       // 0000001AE70C: CA100043 A4A00040
	v_dual_mov_b32 v172, s75 :: v_dual_mov_b32 v169, s72       // 0000001AE714: CA10004B ACA80048
	v_dual_mov_b32 v180, s83 :: v_dual_mov_b32 v177, s80       // 0000001AE71C: CA100053 B4B00050
	v_dual_mul_f32 v57, v57, v115 :: v_dual_mul_f32 v58, v58, v116// 0000001AE724: C8C6E739 393AE93A
	v_dual_mul_f32 v48, v48, v113 :: v_dual_mul_f32 v49, v49, v115// 0000001AE72C: C8C6E330 3030E731
	v_dual_mul_f32 v40, v40, v113 :: v_dual_mul_f32 v41, v41, v115// 0000001AE734: C8C6E328 2828E729
	v_dual_mul_f32 v32, v32, v113 :: v_dual_mul_f32 v33, v33, v115// 0000001AE73C: C8C6E320 2020E721
	v_dual_mul_f32 v24, v24, v113 :: v_dual_mul_f32 v25, v25, v115// 0000001AE744: C8C6E318 1818E719
	v_dual_mul_f32 v16, v16, v113 :: v_dual_mul_f32 v17, v17, v115// 0000001AE74C: C8C6E310 1010E711
	v_dual_mul_f32 v8, v8, v113 :: v_dual_mul_f32 v9, v9, v115 // 0000001AE754: C8C6E308 0808E709
	v_dual_mul_f32 v0, v0, v113 :: v_dual_mul_f32 v1, v1, v115 // 0000001AE75C: C8C6E300 0000E701
	v_dual_mov_b32 v106, v76 :: v_dual_mov_b32 v83, s10        // 0000001AE764: CA10014C 6A52000A
	v_dual_mov_b32 v82, s9 :: v_dual_mov_b32 v79, s6           // 0000001AE76C: CA100009 524E0006
	v_dual_mov_b32 v80, s7 :: v_dual_mov_b32 v77, s4           // 0000001AE774: CA100007 504C0004
	v_dual_mov_b32 v78, s5 :: v_dual_mov_b32 v131, s26         // 0000001AE77C: CA100005 4E82001A
	v_dual_mov_b32 v130, s25 :: v_dual_mov_b32 v127, s22       // 0000001AE784: CA100019 827E0016
	v_dual_mov_b32 v128, s23 :: v_dual_mov_b32 v125, s20       // 0000001AE78C: CA100017 807C0014
	v_dual_mov_b32 v126, s21 :: v_dual_mov_b32 v139, s42       // 0000001AE794: CA100015 7E8A002A
	v_dual_mov_b32 v138, s41 :: v_dual_mov_b32 v135, s38       // 0000001AE79C: CA100029 8A860026
	v_dual_mov_b32 v136, s39 :: v_dual_mov_b32 v133, s36       // 0000001AE7A4: CA100027 88840024
	v_dual_mov_b32 v134, s37 :: v_dual_mov_b32 v147, s50       // 0000001AE7AC: CA100025 86920032
	v_dual_mov_b32 v146, s49 :: v_dual_mov_b32 v143, s46       // 0000001AE7B4: CA100031 928E002E
	v_dual_mov_b32 v144, s47 :: v_dual_mov_b32 v141, s44       // 0000001AE7BC: CA10002F 908C002C
	v_dual_mov_b32 v142, s45 :: v_dual_mov_b32 v155, s58       // 0000001AE7C4: CA10002D 8E9A003A
	v_dual_mov_b32 v154, s57 :: v_dual_mov_b32 v151, s54       // 0000001AE7CC: CA100039 9A960036
	v_dual_mov_b32 v152, s55 :: v_dual_mov_b32 v149, s52       // 0000001AE7D4: CA100037 98940034
	v_dual_mov_b32 v150, s53 :: v_dual_mov_b32 v163, s66       // 0000001AE7DC: CA100035 96A20042
	v_dual_mov_b32 v162, s65 :: v_dual_mov_b32 v159, s62       // 0000001AE7E4: CA100041 A29E003E
	v_dual_mov_b32 v160, s63 :: v_dual_mov_b32 v157, s60       // 0000001AE7EC: CA10003F A09C003C
	v_dual_mov_b32 v158, s61 :: v_dual_mov_b32 v171, s74       // 0000001AE7F4: CA10003D 9EAA004A
	v_dual_mov_b32 v170, s73 :: v_dual_mov_b32 v167, s70       // 0000001AE7FC: CA100049 AAA60046
	v_dual_mov_b32 v168, s71 :: v_dual_mov_b32 v165, s68       // 0000001AE804: CA100047 A8A40044
	v_dual_mov_b32 v166, s69 :: v_dual_mov_b32 v179, s82       // 0000001AE80C: CA100045 A6B20052
	v_dual_mov_b32 v178, s81 :: v_dual_mov_b32 v175, s78       // 0000001AE814: CA100051 B2AE004E
	v_dual_mov_b32 v176, s79 :: v_dual_mov_b32 v173, s76       // 0000001AE81C: CA10004F B0AC004C
	v_dual_mov_b32 v174, s77 :: v_dual_mov_b32 v115, v72       // 0000001AE824: CA10004D AE720148
	v_mov_b32_e32 v116, v73                                    // 0000001AE82C: 7EE80349
	v_dual_mov_b32 v102, v89 :: v_dual_mov_b32 v105, v75       // 0000001AE830: CA100159 6668014B
	s_waitcnt lgkmcnt(0)                                       // 0000001AE838: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[56:63], v[117:124], v[77:84], v[56:63]// 0000001AE83C: CC414038 1CE29B75
	v_wmma_f32_16x16x16_bf16 v[48:55], v[117:124], v[125:132], v[48:55]// 0000001AE844: CC414030 1CC2FB75
	v_wmma_f32_16x16x16_bf16 v[40:47], v[117:124], v[133:140], v[40:47]// 0000001AE84C: CC414028 1CA30B75
	v_wmma_f32_16x16x16_bf16 v[32:39], v[117:124], v[141:148], v[32:39]// 0000001AE854: CC414020 1C831B75
	v_wmma_f32_16x16x16_bf16 v[24:31], v[117:124], v[149:156], v[24:31]// 0000001AE85C: CC414018 1C632B75
	v_wmma_f32_16x16x16_bf16 v[16:23], v[117:124], v[157:164], v[16:23]// 0000001AE864: CC414010 1C433B75
	v_wmma_f32_16x16x16_bf16 v[8:15], v[117:124], v[165:172], v[8:15]// 0000001AE86C: CC414008 1C234B75
	v_wmma_f32_16x16x16_bf16 v[0:7], v[117:124], v[173:180], v[0:7]// 0000001AE874: CC414000 1C035B75
	s_add_i32 s3, s3, -16                                      // 0000001AE87C: 8103D003
	s_mov_b32 s18, s0                                          // 0000001AE880: BE920000
	s_cmp_lg_u32 s1, s0                                        // 0000001AE884: BF070001
	s_barrier                                                  // 0000001AE888: BFBD0000
	buffer_gl0_inv                                             // 0000001AE88C: E0AC0000 00000000
	s_cbranch_scc0 1020                                        // 0000001AE894: BFA103FC <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1988>
	ds_load_b32 v72, v98 offset:1024                           // 0000001AE898: D8D80400 48000062
	ds_load_b128 v[80:83], v99                                 // 0000001AE8A0: DBFC0000 50000063
	ds_load_b128 v[84:87], v99 offset:16                       // 0000001AE8A8: DBFC0010 54000063
	ds_load_b128 v[117:120], v99 offset:32                     // 0000001AE8B0: DBFC0020 75000063
	ds_load_b128 v[121:124], v99 offset:48                     // 0000001AE8B8: DBFC0030 79000063
	ds_load_b128 v[129:132], v99 offset:80                     // 0000001AE8C0: DBFC0050 81000063
	ds_load_b128 v[125:128], v99 offset:64                     // 0000001AE8C8: DBFC0040 7D000063
	ds_load_b128 v[137:140], v99 offset:112                    // 0000001AE8D0: DBFC0070 89000063
	ds_load_b128 v[133:136], v99 offset:96                     // 0000001AE8D8: DBFC0060 85000063
	ds_load_b128 v[145:148], v99 offset:144                    // 0000001AE8E0: DBFC0090 91000063
	ds_load_b128 v[141:144], v99 offset:128                    // 0000001AE8E8: DBFC0080 8D000063
	ds_load_b128 v[153:156], v99 offset:176                    // 0000001AE8F0: DBFC00B0 99000063
	ds_load_b128 v[149:152], v99 offset:160                    // 0000001AE8F8: DBFC00A0 95000063
	ds_load_b128 v[161:164], v99 offset:208                    // 0000001AE900: DBFC00D0 A1000063
	ds_load_b128 v[157:160], v99 offset:192                    // 0000001AE908: DBFC00C0 9D000063
	ds_load_b128 v[169:172], v99 offset:240                    // 0000001AE910: DBFC00F0 A9000063
	ds_load_b128 v[165:168], v99 offset:224                    // 0000001AE918: DBFC00E0 A5000063
	s_waitcnt lgkmcnt(16)                                      // 0000001AE920: BF89FD07
	v_ashrrev_i32_e32 v73, 31, v72                             // 0000001AE924: 3492909F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AE928: BF870091
	.long 0xd73c0048                                           // 0000001AE92C: D73C0048
	v_cndmask_b32_e32 v1, 12, v72, vcc_lo                      // 0000001AE930: 0202908C
	.long 0xd7006a48                                           // 0000001AE934: D7006A48
	v_cndmask_b32_e32 v1, v92, v72, vcc_lo                     // 0000001AE938: 0202915C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AE93C: BF870001
	v_add_co_ci_u32_e64 v73, null, v93, v73, vcc_lo            // 0000001AE940: D5207C49 01AA935D
	v_cmp_gt_i32_e32 vcc_lo, s3, v88                           // 0000001AE948: 7C88B003
	s_clause 0xf                                               // 0000001AE94C: BF85000F
	global_load_b128 v[177:180], v[72:73], off offset:16       // 0000001AE950: DC5E0010 B17C0048
	global_load_b128 v[173:176], v[72:73], off                 // 0000001AE958: DC5E0000 AD7C0048
	global_load_b128 v[185:188], v[72:73], off offset:144      // 0000001AE960: DC5E0090 B97C0048
	global_load_b128 v[181:184], v[72:73], off offset:128      // 0000001AE968: DC5E0080 B57C0048
	global_load_b128 v[193:196], v[72:73], off offset:272      // 0000001AE970: DC5E0110 C17C0048
	global_load_b128 v[189:192], v[72:73], off offset:256      // 0000001AE978: DC5E0100 BD7C0048
	global_load_b128 v[201:204], v[72:73], off offset:400      // 0000001AE980: DC5E0190 C97C0048
	global_load_b128 v[197:200], v[72:73], off offset:384      // 0000001AE988: DC5E0180 C57C0048
	global_load_b128 v[209:212], v[72:73], off offset:528      // 0000001AE990: DC5E0210 D17C0048
	global_load_b128 v[205:208], v[72:73], off offset:512      // 0000001AE998: DC5E0200 CD7C0048
	global_load_b128 v[217:220], v[72:73], off offset:656      // 0000001AE9A0: DC5E0290 D97C0048
	global_load_b128 v[213:216], v[72:73], off offset:640      // 0000001AE9A8: DC5E0280 D57C0048
	global_load_b128 v[225:228], v[72:73], off offset:784      // 0000001AE9B0: DC5E0310 E17C0048
	global_load_b128 v[221:224], v[72:73], off offset:768      // 0000001AE9B8: DC5E0300 DD7C0048
	global_load_b128 v[233:236], v[72:73], off offset:912      // 0000001AE9C0: DC5E0390 E97C0048
	global_load_b128 v[229:232], v[72:73], off offset:896      // 0000001AE9C8: DC5E0380 E57C0048
	s_waitcnt vmcnt(14) lgkmcnt(14)                            // 0000001AE9D0: BF8938E7
	v_wmma_f32_16x16x16_bf16 v[72:79], v[80:87], v[173:180], v[64:71]// 0000001AE9D4: CC414048 1D035B50
	s_waitcnt vmcnt(12) lgkmcnt(12)                            // 0000001AE9DC: BF8930C7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AE9E0: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[72:79], v[117:124], v[181:188], v[72:79]// 0000001AE9E4: CC414048 1D236B75
	s_waitcnt vmcnt(10) lgkmcnt(10)                            // 0000001AE9EC: BF8928A7
	v_wmma_f32_16x16x16_bf16 v[72:79], v[125:132], v[189:196], v[72:79]// 0000001AE9F0: CC414048 1D237B7D
	s_waitcnt vmcnt(8) lgkmcnt(8)                              // 0000001AE9F8: BF892087
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AE9FC: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[72:79], v[133:140], v[197:204], v[72:79]// 0000001AEA00: CC414048 1D238B85
	s_waitcnt vmcnt(6) lgkmcnt(6)                              // 0000001AEA08: BF891867
	v_wmma_f32_16x16x16_bf16 v[72:79], v[141:148], v[205:212], v[72:79]// 0000001AEA0C: CC414048 1D239B8D
	s_waitcnt vmcnt(4) lgkmcnt(4)                              // 0000001AEA14: BF891047
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AEA18: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[72:79], v[149:156], v[213:220], v[72:79]// 0000001AEA1C: CC414048 1D23AB95
	s_waitcnt vmcnt(2) lgkmcnt(2)                              // 0000001AEA24: BF890827
	v_wmma_f32_16x16x16_bf16 v[72:79], v[157:164], v[221:228], v[72:79]// 0000001AEA28: CC414048 1D23BB9D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001AEA30: BF890007
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AEA34: BF870001
	v_wmma_f32_16x16x16_bf16 v[72:79], v[165:172], v[229:236], v[72:79]// 0000001AEA38: CC414048 1D23CBA5
	ds_store_2addr_b32 v94, v72, v73 offset1:32                // 0000001AEA40: D8382000 0049485E
	ds_store_2addr_b32 v94, v74, v75 offset0:64 offset1:96     // 0000001AEA48: D8386040 004B4A5E
	ds_store_2addr_b32 v94, v76, v77 offset0:128 offset1:160   // 0000001AEA50: D838A080 004D4C5E
	ds_store_2addr_b32 v94, v78, v79 offset0:192 offset1:224   // 0000001AEA58: D838E0C0 004F4E5E
	s_waitcnt lgkmcnt(0)                                       // 0000001AEA60: BF89FC07
	s_barrier                                                  // 0000001AEA64: BFBD0000
	buffer_gl0_inv                                             // 0000001AEA68: E0AC0000 00000000
	ds_load_2addr_b32 v[85:86], v95 offset1:32                 // 0000001AEA70: D8DC2000 5500005F
	s_waitcnt lgkmcnt(0)                                       // 0000001AEA78: BF89FC07
	v_add_f32_e32 v72, v72, v85                                // 0000001AEA7C: 0690AB48
	ds_load_2addr_b32 v[84:85], v95 offset0:64 offset1:96      // 0000001AEA80: D8DC6040 5400005F
	ds_load_2addr_b32 v[82:83], v95 offset0:128 offset1:160    // 0000001AEA88: D8DCA080 5200005F
	v_mul_f32_e32 v89, 0x3d800000, v72                         // 0000001AEA90: 10B290FF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEA98: BF870091
	v_cndmask_b32_e32 v72, 0xf149f2ca, v89, vcc_lo             // 0000001AEA9C: 0290B2FF F149F2CA
	v_mov_b32_dpp v80, v72 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AEAA4: 7EA002FA FF096148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEAAC: BF870091
	v_max_f32_e32 v80, v80, v80                                // 0000001AEAB0: 20A0A150
	v_max_f32_e32 v72, v72, v80                                // 0000001AEAB4: 2090A148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEAB8: BF870091
	v_mov_b32_dpp v80, v72 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AEABC: 7EA002FA FF096248
	v_max_f32_e32 v80, v80, v80                                // 0000001AEAC4: 20A0A150
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEAC8: BF870091
	v_max_f32_e32 v72, v72, v80                                // 0000001AEACC: 2090A148
	v_mov_b32_dpp v80, v72 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AEAD0: 7EA002FA FF096448
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001AEAD8: BF8700B1
	v_max_f32_e32 v87, v80, v80                                // 0000001AEADC: 20AEA150
	ds_load_2addr_b32 v[80:81], v95 offset0:192 offset1:224    // 0000001AEAE0: D8DCE0C0 5000005F
	v_max_f32_e32 v72, v72, v87                                // 0000001AEAE8: 2090AF48
	v_mov_b32_dpp v87, v72 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AEAEC: 7EAE02FA FF096848
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AEAF4: BF870001
	v_max3_f32 v72, v115, v72, v87                             // 0000001AEAF8: D61C0048 055E9173
	v_mov_b32_e32 v87, 0                                       // 0000001AEB00: 7EAE0280
	s_and_saveexec_b32 s4, vcc_lo                              // 0000001AEB04: BE84206A
	s_cbranch_execz 31                                         // 0000001AEB08: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xc88>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEB0C: BF870092
	v_sub_f32_e32 v87, v89, v72                                // 0000001AEB10: 08AE9159
	v_mul_f32_e32 v89, 0x3fb8aa3b, v87                         // 0000001AEB14: 10B2AEFF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AEB1C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v87, vcc_lo              // 0000001AEB20: 0202AEFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AEB28: BF870122
	v_fma_f32 v113, 0x3fb8aa3b, v87, -v89                      // 0000001AEB2C: D6130071 8566AEFF 3FB8AA3B
	v_rndne_f32_e32 v117, v89                                  // 0000001AEB38: 7EEA4759
	v_fmac_f32_e32 v113, 0x32a5705f, v87                       // 0000001AEB3C: 56E2AEFF 32A5705F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEB44: BF870092
	v_sub_f32_e32 v89, v89, v117                               // 0000001AEB48: 08B2EB59
	v_add_f32_e32 v89, v89, v113                               // 0000001AEB4C: 06B2E359
	v_cvt_i32_f32_e32 v113, v117                               // 0000001AEB50: 7EE21175
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AEB54: BF870292
	v_exp_f32_e32 v89, v89                                     // 0000001AEB58: 7EB24B59
	.long 0xd71c0059                                           // 0000001AEB5C: D71C0059
	v_cndmask_b32_e32 v1, v89, v113, vcc_lo                    // 0000001AEB60: 0202E359
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AEB64: BF8700A1
	v_cndmask_b32_e64 v89, 0, v89, s0                          // 0000001AEB68: D5010059 0002B280
	.long 0xd41e0000                                           // 0000001AEB70: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v87, vcc_lo              // 0000001AEB74: 0202AEFF 42B17218
	v_cndmask_b32_e64 v87, 0x7f800000, v89, s0                 // 0000001AEB7C: D5010057 0002B2FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001AEB88: 8C7E047E
	v_mov_b32_e32 v89, 0                                       // 0000001AEB8C: 7EB20280
	v_mov_b32_e32 v113, 0                                      // 0000001AEB90: 7EE20280
	s_mov_b32 s4, exec_lo                                      // 0000001AEB94: BE84007E
	v_cmpx_lt_f32_e32 0xefa18f08, v115                         // 0000001AEB98: 7D22E6FF EFA18F08
	s_cbranch_execz 31                                         // 0000001AEBA0: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd20>
	v_sub_f32_e32 v113, v115, v72                              // 0000001AEBA4: 08E29173
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AEBA8: BF870121
	v_mul_f32_e32 v115, 0x3fb8aa3b, v113                       // 0000001AEBAC: 10E6E2FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AEBB4: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v113, vcc_lo             // 0000001AEBB8: 0202E2FF C2CE8ED0
	v_fma_f32 v117, 0x3fb8aa3b, v113, -v115                    // 0000001AEBC0: D6130075 85CEE2FF 3FB8AA3B
	v_rndne_f32_e32 v118, v115                                 // 0000001AEBCC: 7EEC4773
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AEBD0: BF870112
	v_fmac_f32_e32 v117, 0x32a5705f, v113                      // 0000001AEBD4: 56EAE2FF 32A5705F
	v_sub_f32_e32 v115, v115, v118                             // 0000001AEBDC: 08E6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AEBE0: BF870121
	v_add_f32_e32 v115, v115, v117                             // 0000001AEBE4: 06E6EB73
	v_cvt_i32_f32_e32 v117, v118                               // 0000001AEBE8: 7EEA1176
	v_exp_f32_e32 v115, v115                                   // 0000001AEBEC: 7EE64B73
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEBF0: BF870095
	.long 0xd71c0073                                           // 0000001AEBF4: D71C0073
	v_cndmask_b32_e32 v1, v115, v117, vcc_lo                   // 0000001AEBF8: 0202EB73
	v_cndmask_b32_e64 v115, 0, v115, s0                        // 0000001AEBFC: D5010073 0002E680
	.long 0xd41e0000                                           // 0000001AEC04: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v113, vcc_lo             // 0000001AEC08: 0202E2FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AEC10: BF870001
	v_cndmask_b32_e64 v113, 0x7f800000, v115, s0               // 0000001AEC14: D5010071 0002E6FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001AEC20: 8C7E047E
	v_add_f32_e32 v73, v73, v86                                // 0000001AEC24: 0692AD49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEC28: BF870091
	v_mul_f32_e32 v86, 0x3d800000, v73                         // 0000001AEC2C: 10AC92FF 3D800000
	v_cndmask_b32_e32 v73, 0xf149f2ca, v86, vcc_lo             // 0000001AEC34: 0292ACFF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEC3C: BF870091
	v_mov_b32_dpp v115, v73 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AEC40: 7EE602FA FF096149
	v_max_f32_e32 v115, v115, v115                             // 0000001AEC48: 20E6E773
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEC4C: BF870091
	v_max_f32_e32 v73, v73, v115                               // 0000001AEC50: 2092E749
	v_mov_b32_dpp v115, v73 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AEC54: 7EE602FA FF096249
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEC5C: BF870091
	v_max_f32_e32 v115, v115, v115                             // 0000001AEC60: 20E6E773
	v_max_f32_e32 v73, v73, v115                               // 0000001AEC64: 2092E749
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEC68: BF870091
	v_mov_b32_dpp v115, v73 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AEC6C: 7EE602FA FF096449
	v_max_f32_e32 v115, v115, v115                             // 0000001AEC74: 20E6E773
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AEC78: BF870121
	v_max_f32_e32 v73, v73, v115                               // 0000001AEC7C: 2092E749
	v_bfe_u32 v115, v87, 16, 1                                 // 0000001AEC80: D6100073 02052157
	v_mov_b32_dpp v117, v73 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AEC88: 7EEA02FA FF096849
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AEC90: BF870112
	v_add3_u32 v115, v87, v115, 0x7fff                         // 0000001AEC94: D6550073 03FEE757 00007FFF
	v_max3_f32 v73, v116, v73, v117                            // 0000001AECA0: D61C0049 05D69374
	ds_store_b16_d16_hi v96, v115                              // 0000001AECA8: DA840000 00007360
	s_and_saveexec_b32 s4, vcc_lo                              // 0000001AECB0: BE84206A
	s_cbranch_execz 31                                         // 0000001AECB4: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xe34>
	v_sub_f32_e32 v86, v86, v73                                // 0000001AECB8: 08AC9356
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AECBC: BF870091
	v_mul_f32_e32 v89, 0x3fb8aa3b, v86                         // 0000001AECC0: 10B2ACFF 3FB8AA3B
	v_fma_f32 v115, 0x3fb8aa3b, v86, -v89                      // 0000001AECC8: D6130073 8566ACFF 3FB8AA3B
	v_rndne_f32_e32 v117, v89                                  // 0000001AECD4: 7EEA4759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AECD8: BF870112
	v_fmac_f32_e32 v115, 0x32a5705f, v86                       // 0000001AECDC: 56E6ACFF 32A5705F
	v_sub_f32_e32 v89, v89, v117                               // 0000001AECE4: 08B2EB59
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AECE8: BF8701B1
	v_add_f32_e32 v89, v89, v115                               // 0000001AECEC: 06B2E759
	v_cvt_i32_f32_e32 v115, v117                               // 0000001AECF0: 7EE61175
	.long 0xd41b0000                                           // 0000001AECF4: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v86, vcc_lo              // 0000001AECF8: 0202ACFF C2CE8ED0
	v_exp_f32_e32 v89, v89                                     // 0000001AED00: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AED04: BF870095
	.long 0xd71c0059                                           // 0000001AED08: D71C0059
	v_cndmask_b32_e32 v1, v89, v115, vcc_lo                    // 0000001AED0C: 0202E759
	v_cndmask_b32_e64 v89, 0, v89, s0                          // 0000001AED10: D5010059 0002B280
	.long 0xd41e0000                                           // 0000001AED18: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v86, vcc_lo              // 0000001AED1C: 0202ACFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AED24: BF870001
	v_cndmask_b32_e64 v89, 0x7f800000, v89, s0                 // 0000001AED28: D5010059 0002B2FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001AED34: 8C7E047E
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v115, 0            // 0000001AED38: CA100080 56720080
	s_mov_b32 s4, exec_lo                                      // 0000001AED40: BE84007E
	v_cmpx_lt_f32_e32 0xefa18f08, v116                         // 0000001AED44: 7D22E8FF EFA18F08
	s_cbranch_execz 30                                         // 0000001AED4C: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xec8>
	v_sub_f32_e32 v115, v116, v73                              // 0000001AED50: 08E69374
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AED54: BF870121
	v_mul_f32_e32 v116, 0x3fb8aa3b, v115                       // 0000001AED58: 10E8E6FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AED60: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v115, vcc_lo             // 0000001AED64: 0202E6FF C2CE8ED0
	v_fma_f32 v117, 0x3fb8aa3b, v115, -v116                    // 0000001AED6C: D6130075 85D2E6FF 3FB8AA3B
	v_rndne_f32_e32 v118, v116                                 // 0000001AED78: 7EEC4774
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AED7C: BF870091
	v_dual_fmac_f32 v117, 0x32a5705f, v115 :: v_dual_sub_f32 v116, v116, v118// 0000001AED80: C80AE6FF 7574ED74 32A5705F
	v_add_f32_e32 v116, v116, v117                             // 0000001AED8C: 06E8EB74
	v_cvt_i32_f32_e32 v117, v118                               // 0000001AED90: 7EEA1176
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AED94: BF870292
	v_exp_f32_e32 v116, v116                                   // 0000001AED98: 7EE84B74
	.long 0xd71c0074                                           // 0000001AED9C: D71C0074
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                   // 0000001AEDA0: 0202EB74
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AEDA4: BF8700A1
	v_cndmask_b32_e64 v116, 0, v116, s0                        // 0000001AEDA8: D5010074 0002E880
	.long 0xd41e0000                                           // 0000001AEDB0: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v115, vcc_lo             // 0000001AEDB4: 0202E6FF 42B17218
	v_cndmask_b32_e64 v115, 0x7f800000, v116, s0               // 0000001AEDBC: D5010073 0002E8FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001AEDC8: 8C7E047E
	s_waitcnt lgkmcnt(3)                                       // 0000001AEDCC: BF89FC37
	v_add_f32_e32 v74, v74, v84                                // 0000001AEDD0: 0694A94A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEDD4: BF870091
	v_mul_f32_e32 v74, 0x3d800000, v74                         // 0000001AEDD8: 109494FF 3D800000
	v_cndmask_b32_e32 v84, 0xf149f2ca, v74, vcc_lo             // 0000001AEDE0: 02A894FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEDE8: BF870091
	v_mov_b32_dpp v116, v84 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AEDEC: 7EE802FA FF096154
	v_max_f32_e32 v116, v116, v116                             // 0000001AEDF4: 20E8E974
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEDF8: BF870091
	v_max_f32_e32 v84, v84, v116                               // 0000001AEDFC: 20A8E954
	v_mov_b32_dpp v116, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AEE00: 7EE802FA FF096254
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEE08: BF870091
	v_max_f32_e32 v116, v116, v116                             // 0000001AEE0C: 20E8E974
	v_max_f32_e32 v84, v84, v116                               // 0000001AEE10: 20A8E954
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEE14: BF870091
	v_mov_b32_dpp v116, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AEE18: 7EE802FA FF096454
	v_max_f32_e32 v116, v116, v116                             // 0000001AEE20: 20E8E974
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AEE24: BF870121
	v_max_f32_e32 v84, v84, v116                               // 0000001AEE28: 20A8E954
	v_bfe_u32 v116, v89, 16, 1                                 // 0000001AEE2C: D6100074 02052159
	v_mov_b32_dpp v117, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AEE34: 7EEA02FA FF096854
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AEE3C: BF870112
	v_add3_u32 v116, v89, v116, 0x7fff                         // 0000001AEE40: D6550074 03FEE959 00007FFF
	v_max3_f32 v84, v114, v84, v117                            // 0000001AEE4C: D61C0054 05D6A972
	ds_store_b16_d16_hi v96, v116 offset:64                    // 0000001AEE54: DA840040 00007460
	s_and_saveexec_b32 s4, vcc_lo                              // 0000001AEE5C: BE84206A
	s_cbranch_execz 31                                         // 0000001AEE60: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xfe0>
	v_sub_f32_e32 v74, v74, v84                                // 0000001AEE64: 0894A94A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AEE68: BF870121
	v_mul_f32_e32 v86, 0x3fb8aa3b, v74                         // 0000001AEE6C: 10AC94FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AEE74: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v74, vcc_lo              // 0000001AEE78: 020294FF C2CE8ED0
	v_fma_f32 v116, 0x3fb8aa3b, v74, -v86                      // 0000001AEE80: D6130074 855A94FF 3FB8AA3B
	v_rndne_f32_e32 v117, v86                                  // 0000001AEE8C: 7EEA4756
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AEE90: BF870112
	v_fmac_f32_e32 v116, 0x32a5705f, v74                       // 0000001AEE94: 56E894FF 32A5705F
	v_sub_f32_e32 v86, v86, v117                               // 0000001AEE9C: 08ACEB56
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AEEA0: BF870121
	v_add_f32_e32 v86, v86, v116                               // 0000001AEEA4: 06ACE956
	v_cvt_i32_f32_e32 v116, v117                               // 0000001AEEA8: 7EE81175
	v_exp_f32_e32 v86, v86                                     // 0000001AEEAC: 7EAC4B56
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEEB0: BF870095
	.long 0xd71c0056                                           // 0000001AEEB4: D71C0056
	v_cndmask_b32_e32 v1, v86, v116, vcc_lo                    // 0000001AEEB8: 0202E956
	v_cndmask_b32_e64 v86, 0, v86, s0                          // 0000001AEEBC: D5010056 0002AC80
	.long 0xd41e0000                                           // 0000001AEEC4: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v74, vcc_lo              // 0000001AEEC8: 020294FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AEED0: BF870001
	v_cndmask_b32_e64 v86, 0x7f800000, v86, s0                 // 0000001AEED4: D5010056 0002ACFF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001AEEE0: 8C7E047E
	v_mov_b32_e32 v74, 0                                       // 0000001AEEE4: 7E940280
	v_mov_b32_e32 v116, 0                                      // 0000001AEEE8: 7EE80280
	s_mov_b32 s4, exec_lo                                      // 0000001AEEEC: BE84007E
	v_cmpx_lt_f32_e32 0xefa18f08, v114                         // 0000001AEEF0: 7D22E4FF EFA18F08
	s_cbranch_execz 31                                         // 0000001AEEF8: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1078>
	v_sub_f32_e32 v114, v114, v84                              // 0000001AEEFC: 08E4A972
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AEF00: BF870121
	v_mul_f32_e32 v116, 0x3fb8aa3b, v114                       // 0000001AEF04: 10E8E4FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AEF0C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v114, vcc_lo             // 0000001AEF10: 0202E4FF C2CE8ED0
	v_fma_f32 v117, 0x3fb8aa3b, v114, -v116                    // 0000001AEF18: D6130075 85D2E4FF 3FB8AA3B
	v_rndne_f32_e32 v118, v116                                 // 0000001AEF24: 7EEC4774
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AEF28: BF870112
	v_fmac_f32_e32 v117, 0x32a5705f, v114                      // 0000001AEF2C: 56EAE4FF 32A5705F
	v_sub_f32_e32 v116, v116, v118                             // 0000001AEF34: 08E8ED74
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AEF38: BF870121
	v_add_f32_e32 v116, v116, v117                             // 0000001AEF3C: 06E8EB74
	v_cvt_i32_f32_e32 v117, v118                               // 0000001AEF40: 7EEA1176
	v_exp_f32_e32 v116, v116                                   // 0000001AEF44: 7EE84B74
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEF48: BF870095
	.long 0xd71c0074                                           // 0000001AEF4C: D71C0074
	v_cndmask_b32_e32 v1, v116, v117, vcc_lo                   // 0000001AEF50: 0202EB74
	v_cndmask_b32_e64 v116, 0, v116, s0                        // 0000001AEF54: D5010074 0002E880
	.long 0xd41e0000                                           // 0000001AEF5C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v114, vcc_lo             // 0000001AEF60: 0202E4FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AEF68: BF870001
	v_cndmask_b32_e64 v116, 0x7f800000, v116, s0               // 0000001AEF6C: D5010074 0002E8FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001AEF78: 8C7E047E
	v_add_f32_e32 v75, v75, v85                                // 0000001AEF7C: 0696AB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEF80: BF870091
	v_mul_f32_e32 v75, 0x3d800000, v75                         // 0000001AEF84: 109696FF 3D800000
	v_cndmask_b32_e32 v85, 0xf149f2ca, v75, vcc_lo             // 0000001AEF8C: 02AA96FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEF94: BF870091
	v_mov_b32_dpp v114, v85 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AEF98: 7EE402FA FF096155
	v_max_f32_e32 v114, v114, v114                             // 0000001AEFA0: 20E4E572
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEFA4: BF870091
	v_max_f32_e32 v85, v85, v114                               // 0000001AEFA8: 20AAE555
	v_mov_b32_dpp v114, v85 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AEFAC: 7EE402FA FF096255
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEFB4: BF870091
	v_max_f32_e32 v114, v114, v114                             // 0000001AEFB8: 20E4E572
	v_max_f32_e32 v85, v85, v114                               // 0000001AEFBC: 20AAE555
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AEFC0: BF870091
	v_mov_b32_dpp v114, v85 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AEFC4: 7EE402FA FF096455
	v_max_f32_e32 v114, v114, v114                             // 0000001AEFCC: 20E4E572
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AEFD0: BF870121
	v_max_f32_e32 v85, v85, v114                               // 0000001AEFD4: 20AAE555
	v_bfe_u32 v114, v86, 16, 1                                 // 0000001AEFD8: D6100072 02052156
	v_mov_b32_dpp v117, v85 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AEFE0: 7EEA02FA FF096855
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AEFE8: BF870112
	v_add3_u32 v114, v86, v114, 0x7fff                         // 0000001AEFEC: D6550072 03FEE556 00007FFF
	v_max3_f32 v85, v112, v85, v117                            // 0000001AEFF8: D61C0055 05D6AB70
	ds_store_b16_d16_hi v96, v114 offset:128                   // 0000001AF000: DA840080 00007260
	s_and_saveexec_b32 s4, vcc_lo                              // 0000001AF008: BE84206A
	s_cbranch_execz 30                                         // 0000001AF00C: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1188>
	v_sub_f32_e32 v74, v75, v85                                // 0000001AF010: 0894AB4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF014: BF870121
	v_mul_f32_e32 v75, 0x3fb8aa3b, v74                         // 0000001AF018: 109694FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AF020: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v74, vcc_lo              // 0000001AF024: 020294FF C2CE8ED0
	v_fma_f32 v114, 0x3fb8aa3b, v74, -v75                      // 0000001AF02C: D6130072 852E94FF 3FB8AA3B
	v_rndne_f32_e32 v117, v75                                  // 0000001AF038: 7EEA474B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF03C: BF870091
	v_dual_fmac_f32 v114, 0x32a5705f, v74 :: v_dual_sub_f32 v75, v75, v117// 0000001AF040: C80A94FF 724AEB4B 32A5705F
	v_add_f32_e32 v75, v75, v114                               // 0000001AF04C: 0696E54B
	v_cvt_i32_f32_e32 v114, v117                               // 0000001AF050: 7EE41175
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AF054: BF870292
	v_exp_f32_e32 v75, v75                                     // 0000001AF058: 7E964B4B
	.long 0xd71c004b                                           // 0000001AF05C: D71C004B
	v_cndmask_b32_e32 v1, v75, v114, vcc_lo                    // 0000001AF060: 0202E54B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AF064: BF8700A1
	v_cndmask_b32_e64 v75, 0, v75, s0                          // 0000001AF068: D501004B 00029680
	.long 0xd41e0000                                           // 0000001AF070: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v74, vcc_lo              // 0000001AF074: 020294FF 42B17218
	v_cndmask_b32_e64 v74, 0x7f800000, v75, s0                 // 0000001AF07C: D501004A 000296FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001AF088: 8C7E047E
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v114, 0            // 0000001AF08C: CA100080 4B720080
	s_mov_b32 s4, exec_lo                                      // 0000001AF094: BE84007E
	v_cmpx_lt_f32_e32 0xefa18f08, v112                         // 0000001AF098: 7D22E0FF EFA18F08
	s_cbranch_execz 30                                         // 0000001AF0A0: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x121c>
	v_sub_f32_e32 v112, v112, v85                              // 0000001AF0A4: 08E0AB70
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF0A8: BF870121
	v_mul_f32_e32 v114, 0x3fb8aa3b, v112                       // 0000001AF0AC: 10E4E0FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AF0B4: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v112, vcc_lo             // 0000001AF0B8: 0202E0FF C2CE8ED0
	v_fma_f32 v117, 0x3fb8aa3b, v112, -v114                    // 0000001AF0C0: D6130075 85CAE0FF 3FB8AA3B
	v_rndne_f32_e32 v118, v114                                 // 0000001AF0CC: 7EEC4772
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF0D0: BF870091
	v_dual_fmac_f32 v117, 0x32a5705f, v112 :: v_dual_sub_f32 v114, v114, v118// 0000001AF0D4: C80AE0FF 7572ED72 32A5705F
	v_add_f32_e32 v114, v114, v117                             // 0000001AF0E0: 06E4EB72
	v_cvt_i32_f32_e32 v117, v118                               // 0000001AF0E4: 7EEA1176
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AF0E8: BF870292
	v_exp_f32_e32 v114, v114                                   // 0000001AF0EC: 7EE44B72
	.long 0xd71c0072                                           // 0000001AF0F0: D71C0072
	v_cndmask_b32_e32 v1, v114, v117, vcc_lo                   // 0000001AF0F4: 0202EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AF0F8: BF8700A1
	v_cndmask_b32_e64 v114, 0, v114, s0                        // 0000001AF0FC: D5010072 0002E480
	.long 0xd41e0000                                           // 0000001AF104: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v112, vcc_lo             // 0000001AF108: 0202E0FF 42B17218
	v_cndmask_b32_e64 v114, 0x7f800000, v114, s0               // 0000001AF110: D5010072 0002E4FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001AF11C: 8C7E047E
	s_waitcnt lgkmcnt(4)                                       // 0000001AF120: BF89FC47
	v_add_f32_e32 v76, v76, v82                                // 0000001AF124: 0698A54C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF128: BF870091
	v_mul_f32_e32 v76, 0x3d800000, v76                         // 0000001AF12C: 109898FF 3D800000
	v_cndmask_b32_e32 v82, 0xf149f2ca, v76, vcc_lo             // 0000001AF134: 02A498FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF13C: BF870091
	v_mov_b32_dpp v112, v82 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF140: 7EE002FA FF096152
	v_max_f32_e32 v112, v112, v112                             // 0000001AF148: 20E0E170
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF14C: BF870091
	v_max_f32_e32 v82, v82, v112                               // 0000001AF150: 20A4E152
	v_mov_b32_dpp v112, v82 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF154: 7EE002FA FF096252
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF15C: BF870091
	v_max_f32_e32 v112, v112, v112                             // 0000001AF160: 20E0E170
	v_max_f32_e32 v82, v82, v112                               // 0000001AF164: 20A4E152
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF168: BF870091
	v_mov_b32_dpp v112, v82 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF16C: 7EE002FA FF096452
	v_max_f32_e32 v112, v112, v112                             // 0000001AF174: 20E0E170
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF178: BF870121
	v_max_f32_e32 v82, v82, v112                               // 0000001AF17C: 20A4E152
	v_bfe_u32 v112, v74, 16, 1                                 // 0000001AF180: D6100070 0205214A
	v_mov_b32_dpp v117, v82 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF188: 7EEA02FA FF096852
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AF190: BF870112
	v_add3_u32 v112, v74, v112, 0x7fff                         // 0000001AF194: D6550070 03FEE14A 00007FFF
	v_max3_f32 v82, v111, v82, v117                            // 0000001AF1A0: D61C0052 05D6A56F
	ds_store_b16_d16_hi v96, v112 offset:192                   // 0000001AF1A8: DA8400C0 00007060
	s_and_saveexec_b32 s4, vcc_lo                              // 0000001AF1B0: BE84206A
	s_cbranch_execz 31                                         // 0000001AF1B4: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1334>
	v_sub_f32_e32 v75, v76, v82                                // 0000001AF1B8: 0896A54C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF1BC: BF870121
	v_mul_f32_e32 v76, 0x3fb8aa3b, v75                         // 0000001AF1C0: 109896FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AF1C8: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v75, vcc_lo              // 0000001AF1CC: 020296FF C2CE8ED0
	v_fma_f32 v112, 0x3fb8aa3b, v75, -v76                      // 0000001AF1D4: D6130070 853296FF 3FB8AA3B
	v_rndne_f32_e32 v117, v76                                  // 0000001AF1E0: 7EEA474C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AF1E4: BF870112
	v_fmac_f32_e32 v112, 0x32a5705f, v75                       // 0000001AF1E8: 56E096FF 32A5705F
	v_sub_f32_e32 v76, v76, v117                               // 0000001AF1F0: 0898EB4C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF1F4: BF870121
	v_add_f32_e32 v76, v76, v112                               // 0000001AF1F8: 0698E14C
	v_cvt_i32_f32_e32 v112, v117                               // 0000001AF1FC: 7EE01175
	v_exp_f32_e32 v76, v76                                     // 0000001AF200: 7E984B4C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF204: BF870095
	.long 0xd71c004c                                           // 0000001AF208: D71C004C
	v_cndmask_b32_e32 v1, v76, v112, vcc_lo                    // 0000001AF20C: 0202E14C
	v_cndmask_b32_e64 v76, 0, v76, s0                          // 0000001AF210: D501004C 00029880
	.long 0xd41e0000                                           // 0000001AF218: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v75, vcc_lo              // 0000001AF21C: 020296FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AF224: BF870001
	v_cndmask_b32_e64 v75, 0x7f800000, v76, s0                 // 0000001AF228: D501004B 000298FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001AF234: 8C7E047E
	v_mov_b32_e32 v76, 0                                       // 0000001AF238: 7E980280
	v_mov_b32_e32 v112, 0                                      // 0000001AF23C: 7EE00280
	s_mov_b32 s4, exec_lo                                      // 0000001AF240: BE84007E
	v_cmpx_lt_f32_e32 0xefa18f08, v111                         // 0000001AF244: 7D22DEFF EFA18F08
	s_cbranch_execz 30                                         // 0000001AF24C: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x13c8>
	v_sub_f32_e32 v111, v111, v82                              // 0000001AF250: 08DEA56F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF254: BF870091
	v_mul_f32_e32 v112, 0x3fb8aa3b, v111                       // 0000001AF258: 10E0DEFF 3FB8AA3B
	v_fma_f32 v117, 0x3fb8aa3b, v111, -v112                    // 0000001AF260: D6130075 85C2DEFF 3FB8AA3B
	v_rndne_f32_e32 v118, v112                                 // 0000001AF26C: 7EEC4770
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF270: BF870091
	v_dual_fmac_f32 v117, 0x32a5705f, v111 :: v_dual_sub_f32 v112, v112, v118// 0000001AF274: C80ADEFF 7570ED70 32A5705F
	v_add_f32_e32 v112, v112, v117                             // 0000001AF280: 06E0EB70
	v_cvt_i32_f32_e32 v117, v118                               // 0000001AF284: 7EEA1176
	.long 0xd41b0000                                           // 0000001AF288: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v111, vcc_lo             // 0000001AF28C: 0202DEFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AF294: BF870293
	v_exp_f32_e32 v112, v112                                   // 0000001AF298: 7EE04B70
	.long 0xd71c0070                                           // 0000001AF29C: D71C0070
	v_cndmask_b32_e32 v1, v112, v117, vcc_lo                   // 0000001AF2A0: 0202EB70
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AF2A4: BF8700A1
	v_cndmask_b32_e64 v112, 0, v112, s0                        // 0000001AF2A8: D5010070 0002E080
	.long 0xd41e0000                                           // 0000001AF2B0: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v111, vcc_lo             // 0000001AF2B4: 0202DEFF 42B17218
	v_cndmask_b32_e64 v112, 0x7f800000, v112, s0               // 0000001AF2BC: D5010070 0002E0FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001AF2C8: 8C7E047E
	v_add_f32_e32 v77, v77, v83                                // 0000001AF2CC: 069AA74D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF2D0: BF870091
	v_mul_f32_e32 v83, 0x3d800000, v77                         // 0000001AF2D4: 10A69AFF 3D800000
	v_cndmask_b32_e32 v77, 0xf149f2ca, v83, vcc_lo             // 0000001AF2DC: 029AA6FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF2E4: BF870091
	v_mov_b32_dpp v111, v77 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF2E8: 7EDE02FA FF09614D
	v_max_f32_e32 v111, v111, v111                             // 0000001AF2F0: 20DEDF6F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF2F4: BF870091
	v_max_f32_e32 v77, v77, v111                               // 0000001AF2F8: 209ADF4D
	v_mov_b32_dpp v111, v77 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF2FC: 7EDE02FA FF09624D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF304: BF870091
	v_max_f32_e32 v111, v111, v111                             // 0000001AF308: 20DEDF6F
	v_max_f32_e32 v77, v77, v111                               // 0000001AF30C: 209ADF4D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF310: BF870091
	v_mov_b32_dpp v111, v77 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF314: 7EDE02FA FF09644D
	v_max_f32_e32 v111, v111, v111                             // 0000001AF31C: 20DEDF6F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF320: BF870121
	v_max_f32_e32 v77, v77, v111                               // 0000001AF324: 209ADF4D
	v_bfe_u32 v111, v75, 16, 1                                 // 0000001AF328: D610006F 0205214B
	v_mov_b32_dpp v117, v77 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF330: 7EEA02FA FF09684D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AF338: BF870112
	v_add3_u32 v111, v75, v111, 0x7fff                         // 0000001AF33C: D655006F 03FEDF4B 00007FFF
	v_max3_f32 v77, v110, v77, v117                            // 0000001AF348: D61C004D 05D69B6E
	ds_store_b16_d16_hi v96, v111 offset:256                   // 0000001AF350: DA840100 00006F60
	s_and_saveexec_b32 s4, vcc_lo                              // 0000001AF358: BE84206A
	s_cbranch_execz 31                                         // 0000001AF35C: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x14dc>
	v_sub_f32_e32 v76, v83, v77                                // 0000001AF360: 08989B53
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF364: BF870121
	v_mul_f32_e32 v83, 0x3fb8aa3b, v76                         // 0000001AF368: 10A698FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AF370: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v76, vcc_lo              // 0000001AF374: 020298FF C2CE8ED0
	v_fma_f32 v111, 0x3fb8aa3b, v76, -v83                      // 0000001AF37C: D613006F 854E98FF 3FB8AA3B
	v_rndne_f32_e32 v117, v83                                  // 0000001AF388: 7EEA4753
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AF38C: BF870112
	v_fmac_f32_e32 v111, 0x32a5705f, v76                       // 0000001AF390: 56DE98FF 32A5705F
	v_sub_f32_e32 v83, v83, v117                               // 0000001AF398: 08A6EB53
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF39C: BF870121
	v_add_f32_e32 v83, v83, v111                               // 0000001AF3A0: 06A6DF53
	v_cvt_i32_f32_e32 v111, v117                               // 0000001AF3A4: 7EDE1175
	v_exp_f32_e32 v83, v83                                     // 0000001AF3A8: 7EA64B53
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF3AC: BF870095
	.long 0xd71c0053                                           // 0000001AF3B0: D71C0053
	v_cndmask_b32_e32 v1, v83, v111, vcc_lo                    // 0000001AF3B4: 0202DF53
	v_cndmask_b32_e64 v83, 0, v83, s0                          // 0000001AF3B8: D5010053 0002A680
	.long 0xd41e0000                                           // 0000001AF3C0: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v76, vcc_lo              // 0000001AF3C4: 020298FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AF3CC: BF870001
	v_cndmask_b32_e64 v76, 0x7f800000, v83, s0                 // 0000001AF3D0: D501004C 0002A6FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001AF3DC: 8C7E047E
	v_mov_b32_e32 v83, 0                                       // 0000001AF3E0: 7EA60280
	v_mov_b32_e32 v111, 0                                      // 0000001AF3E4: 7EDE0280
	s_mov_b32 s4, exec_lo                                      // 0000001AF3E8: BE84007E
	v_cmpx_lt_f32_e32 0xefa18f08, v110                         // 0000001AF3EC: 7D22DCFF EFA18F08
	s_cbranch_execz 31                                         // 0000001AF3F4: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1574>
	v_sub_f32_e32 v110, v110, v77                              // 0000001AF3F8: 08DC9B6E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF3FC: BF870091
	v_mul_f32_e32 v111, 0x3fb8aa3b, v110                       // 0000001AF400: 10DEDCFF 3FB8AA3B
	v_fma_f32 v117, 0x3fb8aa3b, v110, -v111                    // 0000001AF408: D6130075 85BEDCFF 3FB8AA3B
	v_rndne_f32_e32 v118, v111                                 // 0000001AF414: 7EEC476F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AF418: BF870191
	v_sub_f32_e32 v111, v111, v118                             // 0000001AF41C: 08DEED6F
	v_fmac_f32_e32 v117, 0x32a5705f, v110                      // 0000001AF420: 56EADCFF 32A5705F
	.long 0xd41b0000                                           // 0000001AF428: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v110, vcc_lo             // 0000001AF42C: 0202DCFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF434: BF870122
	v_add_f32_e32 v111, v111, v117                             // 0000001AF438: 06DEEB6F
	v_cvt_i32_f32_e32 v117, v118                               // 0000001AF43C: 7EEA1176
	v_exp_f32_e32 v111, v111                                   // 0000001AF440: 7EDE4B6F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF444: BF870095
	.long 0xd71c006f                                           // 0000001AF448: D71C006F
	v_cndmask_b32_e32 v1, v111, v117, vcc_lo                   // 0000001AF44C: 0202EB6F
	v_cndmask_b32_e64 v111, 0, v111, s0                        // 0000001AF450: D501006F 0002DE80
	.long 0xd41e0000                                           // 0000001AF458: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v110, vcc_lo             // 0000001AF45C: 0202DCFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AF464: BF870001
	v_cndmask_b32_e64 v111, 0x7f800000, v111, s0               // 0000001AF468: D501006F 0002DEFF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001AF474: 8C7E047E
	s_waitcnt lgkmcnt(5)                                       // 0000001AF478: BF89FC57
	v_add_f32_e32 v78, v78, v80                                // 0000001AF47C: 069CA14E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF480: BF870091
	v_mul_f32_e32 v80, 0x3d800000, v78                         // 0000001AF484: 10A09CFF 3D800000
	v_cndmask_b32_e32 v78, 0xf149f2ca, v80, vcc_lo             // 0000001AF48C: 029CA0FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF494: BF870091
	v_mov_b32_dpp v110, v78 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF498: 7EDC02FA FF09614E
	v_max_f32_e32 v110, v110, v110                             // 0000001AF4A0: 20DCDD6E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF4A4: BF870091
	v_max_f32_e32 v78, v78, v110                               // 0000001AF4A8: 209CDD4E
	v_mov_b32_dpp v110, v78 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF4AC: 7EDC02FA FF09624E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF4B4: BF870091
	v_max_f32_e32 v110, v110, v110                             // 0000001AF4B8: 20DCDD6E
	v_max_f32_e32 v78, v78, v110                               // 0000001AF4BC: 209CDD4E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF4C0: BF870091
	v_mov_b32_dpp v110, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF4C4: 7EDC02FA FF09644E
	v_max_f32_e32 v110, v110, v110                             // 0000001AF4CC: 20DCDD6E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF4D0: BF870121
	v_max_f32_e32 v78, v78, v110                               // 0000001AF4D4: 209CDD4E
	v_bfe_u32 v110, v76, 16, 1                                 // 0000001AF4D8: D610006E 0205214C
	v_mov_b32_dpp v117, v78 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF4E0: 7EEA02FA FF09684E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AF4E8: BF870112
	v_add3_u32 v110, v76, v110, 0x7fff                         // 0000001AF4EC: D655006E 03FEDD4C 00007FFF
	v_max3_f32 v78, v109, v78, v117                            // 0000001AF4F8: D61C004E 05D69D6D
	ds_store_b16_d16_hi v96, v110 offset:320                   // 0000001AF500: DA840140 00006E60
	s_and_saveexec_b32 s4, vcc_lo                              // 0000001AF508: BE84206A
	s_cbranch_execz 30                                         // 0000001AF50C: BFA5001E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1688>
	v_sub_f32_e32 v80, v80, v78                                // 0000001AF510: 08A09D50
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF514: BF870091
	v_mul_f32_e32 v83, 0x3fb8aa3b, v80                         // 0000001AF518: 10A6A0FF 3FB8AA3B
	v_fma_f32 v110, 0x3fb8aa3b, v80, -v83                      // 0000001AF520: D613006E 854EA0FF 3FB8AA3B
	v_rndne_f32_e32 v117, v83                                  // 0000001AF52C: 7EEA4753
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF530: BF870121
	v_dual_sub_f32 v83, v83, v117 :: v_dual_fmac_f32 v110, 0x32a5705f, v80// 0000001AF534: C940EB53 536EA0FF 32A5705F
	.long 0xd41b0000                                           // 0000001AF540: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v80, vcc_lo              // 0000001AF544: 0202A0FF C2CE8ED0
	v_add_f32_e32 v83, v83, v110                               // 0000001AF54C: 06A6DD53
	v_cvt_i32_f32_e32 v110, v117                               // 0000001AF550: 7EDC1175
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AF554: BF870292
	v_exp_f32_e32 v83, v83                                     // 0000001AF558: 7EA64B53
	.long 0xd71c0053                                           // 0000001AF55C: D71C0053
	v_cndmask_b32_e32 v1, v83, v110, vcc_lo                    // 0000001AF560: 0202DD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AF564: BF8700A1
	v_cndmask_b32_e64 v83, 0, v83, s0                          // 0000001AF568: D5010053 0002A680
	.long 0xd41e0000                                           // 0000001AF570: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v80, vcc_lo              // 0000001AF574: 0202A0FF 42B17218
	v_cndmask_b32_e64 v83, 0x7f800000, v83, s0                 // 0000001AF57C: D5010053 0002A6FF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001AF588: 8C7E047E
	v_mov_b32_e32 v110, 0                                      // 0000001AF58C: 7EDC0280
	v_mov_b32_e32 v80, 0                                       // 0000001AF590: 7EA00280
	s_mov_b32 s4, exec_lo                                      // 0000001AF594: BE84007E
	v_cmpx_lt_f32_e32 0xefa18f08, v109                         // 0000001AF598: 7D22DAFF EFA18F08
	s_cbranch_execz 31                                         // 0000001AF5A0: BFA5001F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1720>
	v_sub_f32_e32 v80, v109, v78                               // 0000001AF5A4: 08A09D6D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF5A8: BF870121
	v_mul_f32_e32 v109, 0x3fb8aa3b, v80                        // 0000001AF5AC: 10DAA0FF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001AF5B4: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v80, vcc_lo              // 0000001AF5B8: 0202A0FF C2CE8ED0
	v_fma_f32 v117, 0x3fb8aa3b, v80, -v109                     // 0000001AF5C0: D6130075 85B6A0FF 3FB8AA3B
	v_rndne_f32_e32 v118, v109                                 // 0000001AF5CC: 7EEC476D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AF5D0: BF870112
	v_fmac_f32_e32 v117, 0x32a5705f, v80                       // 0000001AF5D4: 56EAA0FF 32A5705F
	v_sub_f32_e32 v109, v109, v118                             // 0000001AF5DC: 08DAED6D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF5E0: BF870121
	v_add_f32_e32 v109, v109, v117                             // 0000001AF5E4: 06DAEB6D
	v_cvt_i32_f32_e32 v117, v118                               // 0000001AF5E8: 7EEA1176
	v_exp_f32_e32 v109, v109                                   // 0000001AF5EC: 7EDA4B6D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF5F0: BF870095
	.long 0xd71c006d                                           // 0000001AF5F4: D71C006D
	v_cndmask_b32_e32 v1, v109, v117, vcc_lo                   // 0000001AF5F8: 0202EB6D
	v_cndmask_b32_e64 v109, 0, v109, s0                        // 0000001AF5FC: D501006D 0002DA80
	.long 0xd41e0000                                           // 0000001AF604: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v80, vcc_lo              // 0000001AF608: 0202A0FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AF610: BF870001
	v_cndmask_b32_e64 v80, 0x7f800000, v109, s0                // 0000001AF614: D5010050 0002DAFF 7F800000
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001AF620: 8C7E047E
	v_add_f32_e32 v79, v79, v81                                // 0000001AF624: 069EA34F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF628: BF870091
	v_mul_f32_e32 v81, 0x3d800000, v79                         // 0000001AF62C: 10A29EFF 3D800000
	v_cndmask_b32_e32 v79, 0xf149f2ca, v81, vcc_lo             // 0000001AF634: 029EA2FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF63C: BF870091
	v_mov_b32_dpp v109, v79 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF640: 7EDA02FA FF09614F
	v_max_f32_e32 v109, v109, v109                             // 0000001AF648: 20DADB6D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF64C: BF870091
	v_max_f32_e32 v79, v79, v109                               // 0000001AF650: 209EDB4F
	v_mov_b32_dpp v109, v79 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF654: 7EDA02FA FF09624F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF65C: BF870091
	v_max_f32_e32 v109, v109, v109                             // 0000001AF660: 20DADB6D
	v_max_f32_e32 v79, v79, v109                               // 0000001AF664: 209EDB4F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF668: BF870091
	v_mov_b32_dpp v109, v79 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF66C: 7EDA02FA FF09644F
	v_max_f32_e32 v109, v109, v109                             // 0000001AF674: 20DADB6D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF678: BF870121
	v_max_f32_e32 v79, v79, v109                               // 0000001AF67C: 209EDB4F
	v_bfe_u32 v109, v83, 16, 1                                 // 0000001AF680: D610006D 02052153
	v_mov_b32_dpp v117, v79 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF688: 7EEA02FA FF09684F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AF690: BF870112
	v_add3_u32 v109, v83, v109, 0x7fff                         // 0000001AF694: D655006D 03FEDB53 00007FFF
	v_max3_f32 v79, v108, v79, v117                            // 0000001AF6A0: D61C004F 05D69F6C
	ds_store_b16_d16_hi v96, v109 offset:384                   // 0000001AF6A8: DA840180 00006D60
	s_and_saveexec_b32 s0, vcc_lo                              // 0000001AF6B0: BE80206A
	s_cbranch_execz 27                                         // 0000001AF6B4: BFA5001B <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1824>
	v_sub_f32_e32 v81, v81, v79                                // 0000001AF6B8: 08A29F51
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF6BC: BF870121
	v_mul_f32_e32 v109, 0x3fb8aa3b, v81                        // 0000001AF6C0: 10DAA2FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v81                  // 0000001AF6C8: 7C36A2FF C2CE8ED0
	v_fma_f32 v110, 0x3fb8aa3b, v81, -v109                     // 0000001AF6D0: D613006E 85B6A2FF 3FB8AA3B
	v_rndne_f32_e32 v117, v109                                 // 0000001AF6DC: 7EEA476D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AF6E0: BF870112
	v_fmac_f32_e32 v110, 0x32a5705f, v81                       // 0000001AF6E4: 56DCA2FF 32A5705F
	v_sub_f32_e32 v109, v109, v117                             // 0000001AF6EC: 08DAEB6D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF6F0: BF870121
	v_add_f32_e32 v109, v109, v110                             // 0000001AF6F4: 06DADD6D
	v_cvt_i32_f32_e32 v110, v117                               // 0000001AF6F8: 7EDC1175
	v_exp_f32_e32 v109, v109                                   // 0000001AF6FC: 7EDA4B6D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF700: BF870095
	.long 0xd71c006d                                           // 0000001AF704: D71C006D
	v_cndmask_b32_e32 v1, v109, v110, vcc_lo                   // 0000001AF708: 0202DD6D
	v_cndmask_b32_e32 v109, 0, v109, vcc_lo                    // 0000001AF70C: 02DADA80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v81                  // 0000001AF710: 7C3CA2FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AF718: BF870002
	v_cndmask_b32_e32 v110, 0x7f800000, v109, vcc_lo           // 0000001AF71C: 02DCDAFF 7F800000
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001AF724: 8C7E007E
	v_mov_b32_e32 v81, 0                                       // 0000001AF728: 7EA20280
	s_mov_b32 s0, exec_lo                                      // 0000001AF72C: BE80007E
	v_cmpx_lt_f32_e32 0xefa18f08, v108                         // 0000001AF730: 7D22D8FF EFA18F08
	s_cbranch_execz 64325                                      // 0000001AF738: BFA5FB45 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x550>
	v_sub_f32_e32 v81, v108, v79                               // 0000001AF73C: 08A29F6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF740: BF870121
	v_mul_f32_e32 v108, 0x3fb8aa3b, v81                        // 0000001AF744: 10D8A2FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v81                  // 0000001AF74C: 7C36A2FF C2CE8ED0
	v_fma_f32 v109, 0x3fb8aa3b, v81, -v108                     // 0000001AF754: D613006D 85B2A2FF 3FB8AA3B
	v_rndne_f32_e32 v117, v108                                 // 0000001AF760: 7EEA476C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AF764: BF870112
	v_fmac_f32_e32 v109, 0x32a5705f, v81                       // 0000001AF768: 56DAA2FF 32A5705F
	v_sub_f32_e32 v108, v108, v117                             // 0000001AF770: 08D8EB6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AF774: BF870121
	v_add_f32_e32 v108, v108, v109                             // 0000001AF778: 06D8DB6C
	v_cvt_i32_f32_e32 v109, v117                               // 0000001AF77C: 7EDA1175
	v_exp_f32_e32 v108, v108                                   // 0000001AF780: 7ED84B6C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AF784: BF870095
	.long 0xd71c006c                                           // 0000001AF788: D71C006C
	v_cndmask_b32_e32 v1, v108, v109, vcc_lo                   // 0000001AF78C: 0202DB6C
	v_cndmask_b32_e32 v108, 0, v108, vcc_lo                    // 0000001AF790: 02D8D880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v81                  // 0000001AF794: 7C3CA2FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AF79C: BF870002
	v_cndmask_b32_e32 v81, 0x7f800000, v108, vcc_lo            // 0000001AF7A0: 02A2D8FF 7F800000
	s_branch 64297                                             // 0000001AF7A8: BFA0FB29 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi64ELi0EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x550>
	v_mov_b32_e32 v5, 0                                        // 0000001AF7AC: 7E0A0280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AF7B0: BF870001
	v_mov_b32_e32 v4, v5                                       // 0000001AF7B4: 7E080305
	v_mov_b32_e32 v3, v5                                       // 0000001AF7B8: 7E060305
	v_mov_b32_e32 v2, v5                                       // 0000001AF7BC: 7E040305
	v_mov_b32_e32 v1, v5                                       // 0000001AF7C0: 7E020305
	v_mov_b32_e32 v0, v5                                       // 0000001AF7C4: 7E000305
	v_mov_b32_e32 v13, v5                                      // 0000001AF7C8: 7E1A0305
	v_mov_b32_e32 v12, v5                                      // 0000001AF7CC: 7E180305
	v_mov_b32_e32 v11, v5                                      // 0000001AF7D0: 7E160305
	v_mov_b32_e32 v10, v5                                      // 0000001AF7D4: 7E140305
	v_mov_b32_e32 v9, v5                                       // 0000001AF7D8: 7E120305
	v_mov_b32_e32 v8, v5                                       // 0000001AF7DC: 7E100305
	v_mov_b32_e32 v21, v5                                      // 0000001AF7E0: 7E2A0305
	v_mov_b32_e32 v20, v5                                      // 0000001AF7E4: 7E280305
	v_mov_b32_e32 v19, v5                                      // 0000001AF7E8: 7E260305
	v_mov_b32_e32 v18, v5                                      // 0000001AF7EC: 7E240305
	v_mov_b32_e32 v17, v5                                      // 0000001AF7F0: 7E220305
	v_mov_b32_e32 v16, v5                                      // 0000001AF7F4: 7E200305
	v_mov_b32_e32 v29, v5                                      // 0000001AF7F8: 7E3A0305
	v_mov_b32_e32 v28, v5                                      // 0000001AF7FC: 7E380305
	v_mov_b32_e32 v27, v5                                      // 0000001AF800: 7E360305
	v_mov_b32_e32 v26, v5                                      // 0000001AF804: 7E340305
	v_mov_b32_e32 v25, v5                                      // 0000001AF808: 7E320305
	v_mov_b32_e32 v24, v5                                      // 0000001AF80C: 7E300305
	v_mov_b32_e32 v37, v5                                      // 0000001AF810: 7E4A0305
	v_mov_b32_e32 v36, v5                                      // 0000001AF814: 7E480305
	v_mov_b32_e32 v35, v5                                      // 0000001AF818: 7E460305
	v_mov_b32_e32 v34, v5                                      // 0000001AF81C: 7E440305
	v_mov_b32_e32 v33, v5                                      // 0000001AF820: 7E420305
	v_mov_b32_e32 v32, v5                                      // 0000001AF824: 7E400305
	v_mov_b32_e32 v45, v5                                      // 0000001AF828: 7E5A0305
	v_mov_b32_e32 v44, v5                                      // 0000001AF82C: 7E580305
	v_mov_b32_e32 v43, v5                                      // 0000001AF830: 7E560305
	v_mov_b32_e32 v42, v5                                      // 0000001AF834: 7E540305
	v_mov_b32_e32 v41, v5                                      // 0000001AF838: 7E520305
	v_mov_b32_e32 v40, v5                                      // 0000001AF83C: 7E500305
	v_mov_b32_e32 v53, v5                                      // 0000001AF840: 7E6A0305
	v_mov_b32_e32 v52, v5                                      // 0000001AF844: 7E680305
	v_mov_b32_e32 v51, v5                                      // 0000001AF848: 7E660305
	v_mov_b32_e32 v50, v5                                      // 0000001AF84C: 7E640305
	v_mov_b32_e32 v49, v5                                      // 0000001AF850: 7E620305
	v_mov_b32_e32 v48, v5                                      // 0000001AF854: 7E600305
	v_mov_b32_e32 v61, v5                                      // 0000001AF858: 7E7A0305
	v_mov_b32_e32 v60, v5                                      // 0000001AF85C: 7E780305
	v_mov_b32_e32 v59, v5                                      // 0000001AF860: 7E760305
	v_mov_b32_e32 v58, v5                                      // 0000001AF864: 7E740305
	v_mov_b32_e32 v57, v5                                      // 0000001AF868: 7E720305
	v_mov_b32_e32 v56, v5                                      // 0000001AF86C: 7E700305
	v_mov_b32_e32 v76, v5                                      // 0000001AF870: 7E980305
	v_mov_b32_e32 v75, v5                                      // 0000001AF874: 7E960305
	v_mov_b32_e32 v74, v5                                      // 0000001AF878: 7E940305
	v_mov_b32_e32 v86, v5                                      // 0000001AF87C: 7EAC0305
	v_mov_b32_e32 v89, v5                                      // 0000001AF880: 7EB20305
	v_mov_b32_e32 v87, v5                                      // 0000001AF884: 7EAE0305
	s_mul_i32 s0, s16, 12                                      // 0000001AF888: 96008C10
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AF88C: BF870001
	v_mov_b32_dpp v77, v87 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF890: 7E9A02FA FF096157
	v_or_b32_e32 v6, s0, v91                                   // 0000001AF898: 380CB600
	s_mul_hi_i32 s0, s2, 0x1800                                // 0000001AF89C: 9700FF02 00001800
	s_mul_i32 s1, s2, 0x1800                                   // 0000001AF8A4: 9601FF02 00001800
	v_mov_b32_dpp v83, v74 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF8AC: 7EA602FA FF09614A
	v_mov_b32_dpp v81, v86 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF8B4: 7EA202FA FF096156
	v_dual_mov_b32 v47, s0 :: v_dual_lshlrev_b32 v30, 8, v6    // 0000001AF8BC: CA220000 2F1E0C88
	v_dual_add_f32 v87, v87, v77 :: v_dual_lshlrev_b32 v6, 7, v90// 0000001AF8C4: C9229B57 5706B487
	v_mov_b32_dpp v84, v75 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF8CC: 7EA802FA FF09614B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001AF8D4: BF870223
	v_ashrrev_i32_e32 v7, 31, v30                              // 0000001AF8D8: 340E3C9F
	v_dual_add_f32 v83, v74, v83 :: v_dual_add_nc_u32 v14, 0x400, v30// 0000001AF8DC: C920A74A 530E3CFF 00000400
	v_or3_b32 v46, v6, v88, s1                                 // 0000001AF8E8: D658002E 0006B106
	v_dual_add_f32 v81, v86, v81 :: v_dual_add_nc_u32 v22, 0x600, v30// 0000001AF8F0: C920A356 51163CFF 00000600
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001AF8FC: BF870223
	v_ashrrev_i32_e32 v15, 31, v14                             // 0000001AF900: 341E1C9F
	v_dual_add_f32 v84, v75, v84 :: v_dual_add_nc_u32 v31, 0x800, v30// 0000001AF904: C920A94B 541E3CFF 00000800
	.long 0xd7006a06                                           // 0000001AF910: D7006A06
	v_cndmask_b32_e32 v1, v46, v30, vcc_lo                     // 0000001AF914: 02023D2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AF918: BF8700A1
	v_add_co_ci_u32_e64 v7, null, v47, v7, vcc_lo              // 0000001AF91C: D5207C07 01AA0F2F
	.long 0xd7006a0e                                           // 0000001AF924: D7006A0E
	v_cndmask_b32_e32 v1, v46, v14, vcc_lo                     // 0000001AF928: 02021D2E
	v_add_co_ci_u32_e64 v15, null, v47, v15, vcc_lo            // 0000001AF92C: D5207C0F 01AA1F2F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001AF934: BF870233
	.long 0xd73c0006                                           // 0000001AF938: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000001AF93C: 02020C81
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000001AF940: 342E2C9F
	v_mov_b32_dpp v85, v76 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AF944: 7EAA02FA FF09614C
	.long 0xd73c000e                                           // 0000001AF94C: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000001AF950: 02021C81
	v_add_nc_u32_e32 v38, 0xa00, v30                           // 0000001AF954: 4A4C3CFF 00000A00
	v_ashrrev_i32_e32 v39, 31, v31                             // 0000001AF95C: 344E3E9F
	.long 0xd7006a36                                           // 0000001AF960: D7006A36
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 0000001AF964: 02020C0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AF968: BF8700A1
	v_add_co_ci_u32_e64 v55, null, s13, v7, vcc_lo             // 0000001AF96C: D5207C37 01AA0E0D
	.long 0xd7006a16                                           // 0000001AF974: D7006A16
	v_cndmask_b32_e32 v1, v46, v22, vcc_lo                     // 0000001AF978: 02022D2E
	v_add_co_ci_u32_e64 v23, null, v47, v23, vcc_lo            // 0000001AF97C: D5207C17 01AA2F2F
	global_load_u16 v73, v[54:55], off offset:1024             // 0000001AF984: DC4A0400 497C0036
	v_or_b32_e32 v66, 0x200, v30                               // 0000001AF98C: 38843CFF 00000200
	.long 0xd7006a3e                                           // 0000001AF994: D7006A3E
	v_cndmask_b32_e32 v1, s12, v14, vcc_lo                     // 0000001AF998: 02021C0C
	.long 0xd73c0016                                           // 0000001AF99C: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000001AF9A0: 02022C81
	v_add_f32_e32 v85, v76, v85                                // 0000001AF9A4: 06AAAB4C
	v_ashrrev_i32_e32 v64, 31, v38                             // 0000001AF9A8: 34804C9F
	v_add_co_ci_u32_e64 v63, null, s13, v15, vcc_lo            // 0000001AF9AC: D5207C3F 01AA1E0D
	.long 0xd7006a1e                                           // 0000001AF9B4: D7006A1E
	v_cndmask_b32_e32 v1, v46, v31, vcc_lo                     // 0000001AF9B8: 02023F2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001AF9BC: BF8700D1
	v_add_co_ci_u32_e64 v31, null, v47, v39, vcc_lo            // 0000001AF9C0: D5207C1F 01AA4F2F
	.long 0xd7006a26                                           // 0000001AF9C8: D7006A26
	v_cndmask_b32_e32 v1, v46, v38, vcc_lo                     // 0000001AF9CC: 02024D2E
	v_ashrrev_i32_e32 v67, 31, v66                             // 0000001AF9D0: 3486849F
	v_add_co_ci_u32_e64 v39, null, v47, v64, vcc_lo            // 0000001AF9D4: D5207C27 01AA812F
	.long 0xd7006a40                                           // 0000001AF9DC: D7006A40
	v_cndmask_b32_e32 v1, s12, v22, vcc_lo                     // 0000001AF9E0: 02022C0C
	v_add_co_ci_u32_e64 v65, null, s13, v23, vcc_lo            // 0000001AF9E4: D5207C41 01AA2E0D
	.long 0xd7006a2e                                           // 0000001AF9EC: D7006A2E
	v_cndmask_b32_e32 v1, v46, v66, vcc_lo                     // 0000001AF9F0: 0202852E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AF9F4: BF870001
	v_add_co_ci_u32_e64 v47, null, v47, v67, vcc_lo            // 0000001AF9F8: D5207C2F 01AA872F
	s_clause 0x2                                               // 0000001AFA00: BF850002
	global_load_u16 v80, v[54:55], off                         // 0000001AFA04: DC4A0000 507C0036
	global_load_u16 v82, v[54:55], off offset:32               // 0000001AFA0C: DC4A0020 527C0036
	global_load_u16 v103, v[54:55], off offset:64              // 0000001AFA14: DC4A0040 677C0036
	.long 0xd73c001e                                           // 0000001AFA1C: D73C001E
	v_cndmask_b32_e32 v1, 1, v30, vcc_lo                       // 0000001AFA20: 02023C81
	.long 0xd73c0026                                           // 0000001AFA24: D73C0026
	v_cndmask_b32_e32 v1, 1, v38, vcc_lo                       // 0000001AFA28: 02024C81
	.long 0xd73c002e                                           // 0000001AFA2C: D73C002E
	v_cndmask_b32_e32 v1, 1, v46, vcc_lo                       // 0000001AFA30: 02025C81
	v_mov_b32_dpp v78, v89 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFA34: 7E9C02FA FF096159
	v_add_f32_dpp v86, v87, v87 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFA3C: 06ACAEFA FF096257
	v_add_f32_dpp v83, v83, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFA44: 06A6A6FA FF096253
	.long 0xd7006a44                                           // 0000001AFA4C: D7006A44
	v_cndmask_b32_e32 v1, s12, v30, vcc_lo                     // 0000001AFA50: 02023C0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AFA54: BF8700A1
	v_add_co_ci_u32_e64 v69, null, s13, v31, vcc_lo            // 0000001AFA58: D5207C45 01AA3E0D
	.long 0xd7006a42                                           // 0000001AFA60: D7006A42
	v_cndmask_b32_e32 v1, s12, v38, vcc_lo                     // 0000001AFA64: 02024C0C
	v_add_co_ci_u32_e64 v67, null, s13, v39, vcc_lo            // 0000001AFA68: D5207C43 01AA4E0D
	.long 0xd7006a46                                           // 0000001AFA70: D7006A46
	v_cndmask_b32_e32 v1, s12, v46, vcc_lo                     // 0000001AFA74: 02025C0C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AFA78: BF870001
	v_add_co_ci_u32_e64 v71, null, s13, v47, vcc_lo            // 0000001AFA7C: D5207C47 01AA5E0D
	s_clause 0x9                                               // 0000001AFA84: BF850009
	global_load_u16 v99, v[64:65], off                         // 0000001AFA88: DC4A0000 637C0040
	global_load_u16 v98, v[62:63], off                         // 0000001AFA90: DC4A0000 627C003E
	global_load_u16 v101, v[66:67], off                        // 0000001AFA98: DC4A0000 657C0042
	global_load_u16 v100, v[68:69], off                        // 0000001AFAA0: DC4A0000 647C0044
	global_load_u16 v102, v[70:71], off offset:32              // 0000001AFAA8: DC4A0020 667C0046
	global_load_u16 v94, v[64:65], off offset:32               // 0000001AFAB0: DC4A0020 5E7C0040
	global_load_u16 v93, v[62:63], off offset:32               // 0000001AFAB8: DC4A0020 5D7C003E
	global_load_u16 v96, v[66:67], off offset:32               // 0000001AFAC0: DC4A0020 607C0042
	global_load_u16 v95, v[68:69], off offset:32               // 0000001AFAC8: DC4A0020 5F7C0044
	global_load_u16 v97, v[70:71], off offset:64               // 0000001AFAD0: DC4A0040 617C0046
	v_add_f32_e32 v78, v89, v78                                // 0000001AFAD8: 069C9D59
	v_add_f32_dpp v86, v86, v86 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFADC: 06ACACFA FF096456
	v_add_f32_dpp v81, v81, v81 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFAE4: 06A2A2FA FF096251
	v_add_f32_dpp v85, v85, v85 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFAEC: 06AAAAFA FF096255
	v_add_f32_dpp v84, v84, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFAF4: 06A8A8FA FF096254
	v_add_f32_dpp v78, v78, v78 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFAFC: 069C9CFA FF09624E
	v_add_f32_dpp v108, v86, v86 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFB04: 06D8ACFA FF096856
	v_add_f32_dpp v83, v83, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFB0C: 06A6A6FA FF096453
	v_add_f32_dpp v81, v81, v81 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFB14: 06A2A2FA FF096451
	v_add_f32_dpp v85, v85, v85 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFB1C: 06AAAAFA FF096455
	v_add_f32_dpp v78, v78, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFB24: 069C9CFA FF09644E
	v_div_scale_f32 v117, null, v108, v108, 1.0                // 0000001AFB2C: D6FC7C75 03CAD96C
	v_add_f32_dpp v84, v84, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFB34: 06A8A8FA FF096454
	v_add_f32_dpp v88, v83, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFB3C: 06B0A6FA FF096853
	v_add_f32_dpp v89, v81, v81 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFB44: 06B2A2FA FF096851
	v_add_f32_dpp v107, v78, v78 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFB4C: 06D69CFA FF09684E
	v_add_f32_dpp v81, v85, v85 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFB54: 06A2AAFA FF096855
	v_rcp_f32_e32 v122, v117                                   // 0000001AFB5C: 7EF45575
	v_add_f32_dpp v83, v84, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001AFB60: 06A6A8FA FF096854
	v_div_scale_f32 v109, null, v89, v89, 1.0                  // 0000001AFB68: D6FC7C6D 03CAB359
	v_div_scale_f32 v118, null, v107, v107, 1.0                // 0000001AFB70: D6FC7C76 03CAD76B
	v_div_scale_f32 v110, null, v88, v88, 1.0                  // 0000001AFB78: D6FC7C6E 03CAB158
	v_div_scale_f32 v115, null, v81, v81, 1.0                  // 0000001AFB80: D6FC7C73 03CAA351
	s_clause 0x1f                                              // 0000001AFB88: BF85001F
	global_load_u16 v78, v[54:55], off offset:96               // 0000001AFB8C: DC4A0060 4E7C0036
	global_load_u16 v85, v[54:55], off offset:128              // 0000001AFB94: DC4A0080 557C0036
	global_load_u16 v87, v[54:55], off offset:160              // 0000001AFB9C: DC4A00A0 577C0036
	global_load_u16 v92, v[54:55], off offset:192              // 0000001AFBA4: DC4A00C0 5C7C0036
	global_load_u16 v54, v[54:55], off offset:224              // 0000001AFBAC: DC4A00E0 367C0036
	global_load_u16 v138, v[62:63], off offset:64              // 0000001AFBB4: DC4A0040 8A7C003E
	global_load_u16 v133, v[62:63], off offset:96              // 0000001AFBBC: DC4A0060 857C003E
	global_load_u16 v128, v[62:63], off offset:128             // 0000001AFBC4: DC4A0080 807C003E
	global_load_u16 v124, v[62:63], off offset:160             // 0000001AFBCC: DC4A00A0 7C7C003E
	global_load_u16 v105, v[62:63], off offset:192             // 0000001AFBD4: DC4A00C0 697C003E
	global_load_u16 v137, v[64:65], off offset:64              // 0000001AFBDC: DC4A0040 897C0040
	global_load_u16 v132, v[64:65], off offset:96              // 0000001AFBE4: DC4A0060 847C0040
	global_load_u16 v127, v[64:65], off offset:128             // 0000001AFBEC: DC4A0080 7F7C0040
	global_load_u16 v123, v[64:65], off offset:160             // 0000001AFBF4: DC4A00A0 7B7C0040
	global_load_u16 v104, v[64:65], off offset:192             // 0000001AFBFC: DC4A00C0 687C0040
	global_load_u16 v62, v[62:63], off offset:224              // 0000001AFC04: DC4A00E0 3E7C003E
	global_load_u16 v140, v[68:69], off offset:64              // 0000001AFC0C: DC4A0040 8C7C0044
	global_load_u16 v135, v[68:69], off offset:96              // 0000001AFC14: DC4A0060 877C0044
	global_load_u16 v130, v[68:69], off offset:128             // 0000001AFC1C: DC4A0080 827C0044
	global_load_u16 v126, v[68:69], off offset:160             // 0000001AFC24: DC4A00A0 7E7C0044
	global_load_u16 v106, v[68:69], off offset:192             // 0000001AFC2C: DC4A00C0 6A7C0044
	global_load_u16 v55, v[64:65], off offset:224              // 0000001AFC34: DC4A00E0 377C0040
	global_load_u16 v139, v[66:67], off offset:64              // 0000001AFC3C: DC4A0040 8B7C0042
	global_load_u16 v134, v[66:67], off offset:96              // 0000001AFC44: DC4A0060 867C0042
	global_load_u16 v129, v[66:67], off offset:128             // 0000001AFC4C: DC4A0080 817C0042
	global_load_u16 v125, v[66:67], off offset:160             // 0000001AFC54: DC4A00A0 7D7C0042
	global_load_u16 v65, v[66:67], off offset:192              // 0000001AFC5C: DC4A00C0 417C0042
	global_load_u16 v63, v[68:69], off offset:224              // 0000001AFC64: DC4A00E0 3F7C0044
	global_load_u16 v141, v[70:71], off offset:96              // 0000001AFC6C: DC4A0060 8D7C0046
	global_load_u16 v136, v[70:71], off offset:128             // 0000001AFC74: DC4A0080 887C0046
	global_load_u16 v131, v[70:71], off offset:160             // 0000001AFC7C: DC4A00A0 837C0046
	global_load_u16 v69, v[70:71], off offset:192              // 0000001AFC84: DC4A00C0 457C0046
	s_clause 0x1                                               // 0000001AFC8C: BF850001
	global_load_u16 v68, v[70:71], off offset:224              // 0000001AFC90: DC4A00E0 447C0046
	global_load_u16 v64, v[66:67], off offset:224              // 0000001AFC98: DC4A00E0 407C0042
	v_div_scale_f32 v120, s4, 1.0, v107, 1.0                   // 0000001AFCA0: D6FC0478 03CAD6F2
	v_rcp_f32_e32 v121, v118                                   // 0000001AFCA8: 7EF25576
	v_div_scale_f32 v111, null, v83, v83, 1.0                  // 0000001AFCAC: D6FC7C6F 03CAA753
	v_rcp_f32_e32 v91, v109                                    // 0000001AFCB4: 7EB6556D
	v_rcp_f32_e32 v90, v110                                    // 0000001AFCB8: 7EB4556E
	v_rcp_f32_e32 v84, v115                                    // 0000001AFCBC: 7EA85573
	v_fma_f32 v66, -v117, v122, 1.0                            // 0000001AFCC0: D6130042 23CAF575
	v_div_scale_f32 v119, vcc_lo, 1.0, v108, 1.0               // 0000001AFCC8: D6FC6A77 03CAD8F2
	v_rcp_f32_e32 v86, v111                                    // 0000001AFCD0: 7EAC556F
	v_div_scale_f32 v113, s3, 1.0, v88, 1.0                    // 0000001AFCD4: D6FC0371 03CAB0F2
	v_div_scale_f32 v116, s1, 1.0, v81, 1.0                    // 0000001AFCDC: D6FC0174 03CAA2F2
	v_fma_f32 v67, -v118, v121, 1.0                            // 0000001AFCE4: D6130043 23CAF376
	v_div_scale_f32 v114, s0, 1.0, v83, 1.0                    // 0000001AFCEC: D6FC0072 03CAA6F2
	v_fma_f32 v70, -v109, v91, 1.0                             // 0000001AFCF4: D6130046 23CAB76D
	v_fma_f32 v71, -v110, v90, 1.0                             // 0000001AFCFC: D6130047 23CAB56E
	v_fma_f32 v143, -v115, v84, 1.0                            // 0000001AFD04: D613008F 23CAA973
	v_dual_fmac_f32 v121, v67, v121 :: v_dual_fmac_f32 v122, v66, v122// 0000001AFD0C: C800F343 797AF542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AFD14: BF870215
	v_fma_f32 v142, -v111, v86, 1.0                            // 0000001AFD18: D613008E 23CAAD6F
	v_dual_fmac_f32 v91, v70, v91 :: v_dual_fmac_f32 v90, v71, v90// 0000001AFD20: C800B746 5B5AB547
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AFD28: BF8701B3
	v_dual_mul_f32 v67, v120, v121 :: v_dual_fmac_f32 v84, v143, v84// 0000001AFD2C: C8C0F378 4354A98F
	v_div_scale_f32 v112, s2, 1.0, v89, 1.0                    // 0000001AFD34: D6FC0270 03CAB2F2
	.long 0xd7000506                                           // 0000001AFD3C: D7000506
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 0000001AFD40: 02020C0E
	v_fma_f32 v145, -v118, v67, v120                           // 0000001AFD44: D6130091 25E28776
	v_mul_f32_e32 v66, v119, v122                              // 0000001AFD4C: 1084F577
	v_mul_f32_e32 v71, v113, v90                               // 0000001AFD50: 108EB571
	v_dual_fmac_f32 v86, v142, v86 :: v_dual_mul_f32 v143, v116, v84// 0000001AFD54: C806AD8E 568EA974
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AFD5C: BF870214
	v_fmac_f32_e32 v67, v145, v121                             // 0000001AFD60: 5686F391
	v_fma_f32 v144, -v117, v66, v119                           // 0000001AFD64: D6130090 25DE8575
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001AFD6C: BF870234
	v_fma_f32 v147, -v110, v71, v113                           // 0000001AFD70: D6130093 25C68F6E
	v_mul_f32_e32 v70, v112, v91                               // 0000001AFD78: 108CB770
	v_add_co_ci_u32_e64 v7, null, s15, v7, s5                  // 0000001AFD7C: D5207C07 00160E0F
	v_fmac_f32_e32 v66, v144, v122                             // 0000001AFD84: 5684F590
	v_fma_f32 v144, -v115, v143, v116                          // 0000001AFD88: D6130090 25D31F73
	v_mul_f32_e32 v142, v114, v86                              // 0000001AFD90: 111CAD72
	v_fma_f32 v118, -v118, v67, v120                           // 0000001AFD94: D6130076 25E28776
	v_fmac_f32_e32 v71, v147, v90                              // 0000001AFD9C: 568EB593
	v_fma_f32 v146, -v109, v70, v112                           // 0000001AFDA0: D6130092 25C28D6D
	v_fmac_f32_e32 v143, v144, v84                             // 0000001AFDA8: 571EA990
	v_fma_f32 v148, -v111, v142, v114                          // 0000001AFDAC: D6130094 25CB1D6F
	.long 0xd700050e                                           // 0000001AFDB4: D700050E
	v_cndmask_b32_e32 v1, s14, v14, vcc_lo                     // 0000001AFDB8: 02021C0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AFDBC: BF870191
	v_add_co_ci_u32_e64 v15, null, s15, v15, s5                // 0000001AFDC0: D5207C0F 00161E0F
	v_fmac_f32_e32 v142, v148, v86                             // 0000001AFDC8: 571CAD94
	.long 0xd7000516                                           // 0000001AFDCC: D7000516
	v_cndmask_b32_e32 v1, s14, v22, vcc_lo                     // 0000001AFDD0: 02022C0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AFDD4: BF8700A1
	v_add_co_ci_u32_e64 v23, null, s15, v23, s5                // 0000001AFDD8: D5207C17 00162E0F
	.long 0xd700051e                                           // 0000001AFDE0: D700051E
	v_cndmask_b32_e32 v1, s14, v30, vcc_lo                     // 0000001AFDE4: 02023C0E
	v_add_co_ci_u32_e64 v31, null, s15, v31, s5                // 0000001AFDE8: D5207C1F 00163E0F
	.long 0xd7000526                                           // 0000001AFDF0: D7000526
	v_cndmask_b32_e32 v1, s14, v38, vcc_lo                     // 0000001AFDF4: 02024C0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AFDF8: BF8700A1
	v_add_co_ci_u32_e64 v39, null, s15, v39, s5                // 0000001AFDFC: D5207C27 00164E0F
	.long 0xd700052e                                           // 0000001AFE04: D700052E
	v_cndmask_b32_e32 v1, s14, v46, vcc_lo                     // 0000001AFE08: 02025C0E
	v_add_co_ci_u32_e64 v47, null, s15, v47, s5                // 0000001AFE0C: D5207C2F 00165E0F
	.long 0x7f903880                                           // 0000001AFE14: 7F903880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AFE18: BF870001
	.long 0x7f9e39c8                                           // 0000001AFE1C: 7F9E39C8
	.long 0x7f9439c8                                           // 0000001AFE20: 7F9439C8
	.long 0x7f9a39c8                                           // 0000001AFE24: 7F9A39C8
	.long 0x7f9839c8                                           // 0000001AFE28: 7F9839C8
	.long 0x7f9639c8                                           // 0000001AFE2C: 7F9639C8
	s_waitcnt vmcnt(47)                                        // 0000001AFE30: BF89BFF7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000001AFE34: 30929290
	v_fma_f32 v117, -v117, v66, v119                           // 0000001AFE38: D6130075 25DE8575
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001AFE40: BF870131
	v_div_fmas_f32 v66, v117, v122, v66                        // 0000001AFE44: D6370042 050AF575
	s_mov_b32 vcc_lo, s4                                       // 0000001AFE4C: BEEA0004
	v_div_fmas_f32 v117, v118, v121, v67                       // 0000001AFE50: D6370075 050EF376
	v_div_fixup_f32 v67, v66, v108, 1.0                        // 0000001AFE58: D6270043 03CAD942
	v_fma_f32 v108, -v110, v71, v113                           // 0000001AFE60: D613006C 25C68F6E
	v_fma_f32 v110, -v115, v143, v116                          // 0000001AFE68: D613006E 25D31F73
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001AFE70: BF870244
	v_div_fixup_f32 v66, v117, v107, 1.0                       // 0000001AFE74: D6270042 03CAD775
	v_fma_f32 v107, -v111, v142, v114                          // 0000001AFE7C: D613006B 25CB1D6F
	v_mul_f32_e32 v111, v48, v67                               // 0000001AFE84: 10DE8730
	v_fmac_f32_e32 v70, v146, v91                              // 0000001AFE88: 568CB792
	v_dual_mul_f32 v56, v56, v67 :: v_dual_mul_f32 v57, v57, v66// 0000001AFE8C: C8C68738 38388539
	v_mul_f32_e32 v41, v41, v66                                // 0000001AFE94: 10528529
	v_mul_f32_e32 v33, v33, v66                                // 0000001AFE98: 10428521
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AFE9C: BF870004
	v_fma_f32 v109, -v109, v70, v112                           // 0000001AFEA0: D613006D 25C28D6D
	v_mul_f32_e32 v112, 0xbfb8aa3b, v73                        // 0000001AFEA8: 10E092FF BFB8AA3B
	s_waitcnt vmcnt(46)                                        // 0000001AFEB0: BF89BBF7
	v_lshlrev_b32_e32 v48, 16, v80                             // 0000001AFEB4: 3060A090
	v_mul_f32_e32 v80, v49, v66                                // 0000001AFEB8: 10A08531
	s_waitcnt vmcnt(45)                                        // 0000001AFEBC: BF89B7F7
	v_lshlrev_b32_e32 v49, 16, v82                             // 0000001AFEC0: 3062A490
	s_waitcnt vmcnt(44)                                        // 0000001AFEC4: BF89B3F7
	v_dual_mul_f32 v25, v25, v66 :: v_dual_lshlrev_b32 v82, 16, v103// 0000001AFEC8: C8E28519 1952CE90
	v_mul_f32_e32 v103, 0xbfb8aa3b, v48                        // 0000001AFED0: 10CE60FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 0000001AFED8: 7C3C60FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001AFEE0: BF870223
	v_dual_mul_f32 v113, 0xbfb8aa3b, v49 :: v_dual_mul_f32 v114, 0xbfb8aa3b, v82// 0000001AFEE4: C8C662FF 7172A4FF BFB8AA3B
	v_mul_f32_e32 v8, v8, v67                                  // 0000001AFEF0: 10108708
	v_fma_f32 v115, 0xbfb8aa3b, v48, -v103                     // 0000001AFEF4: D6130073 859E60FF BFB8AA3B
	v_rndne_f32_e32 v116, v103                                 // 0000001AFF00: 7EE84767
	s_waitcnt vmcnt(43)                                        // 0000001AFF04: BF89AFF7
	v_lshlrev_b32_e32 v99, 16, v99                             // 0000001AFF08: 30C6C690
	v_fma_f32 v151, 0xbfb8aa3b, v82, -v114                     // 0000001AFF0C: D6130097 85CAA4FF BFB8AA3B
	s_waitcnt vmcnt(41)                                        // 0000001AFF18: BF89A7F7
	v_lshlrev_b32_e32 v101, 16, v101                           // 0000001AFF1C: 30CACA90
	s_waitcnt vmcnt(40)                                        // 0000001AFF20: BF89A3F7
	v_lshlrev_b32_e32 v100, 16, v100                           // 0000001AFF24: 30C8C890
	v_dual_sub_f32 v103, v103, v116 :: v_dual_lshlrev_b32 v98, 16, v98// 0000001AFF28: C962E967 6762C490
	v_cvt_i32_f32_e32 v116, v116                               // 0000001AFF30: 7EE81174
	s_waitcnt vmcnt(35)                                        // 0000001AFF34: BF898FF7
	v_dual_mul_f32 v122, 0xbfb8aa3b, v101 :: v_dual_lshlrev_b32 v95, 16, v95// 0000001AFF38: C8E2CAFF 7A5EBE90 BFB8AA3B
	v_lshlrev_b32_e32 v94, 16, v94                             // 0000001AFF44: 30BCBC90
	v_fma_f32 v117, 0xbfb8aa3b, v73, -v112                     // 0000001AFF48: D6130075 85C292FF BFB8AA3B
	v_rndne_f32_e32 v118, v112                                 // 0000001AFF54: 7EEC4770
	v_fmac_f32_e32 v115, 0xb2a5705f, v48                       // 0000001AFF58: 56E660FF B2A5705F
	v_dual_mul_f32 v149, 0xbfb8aa3b, v95 :: v_dual_lshlrev_b32 v96, 16, v96// 0000001AFF60: C8E2BEFF 9560C090 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AFF6C: BF870193
	v_dual_fmac_f32 v117, 0xb2a5705f, v73 :: v_dual_sub_f32 v112, v112, v118// 0000001AFF70: C80A92FF 7570ED70 B2A5705F
	v_dual_mul_f32 v148, 0xbfb8aa3b, v94 :: v_dual_add_f32 v103, v103, v115// 0000001AFF7C: C8C8BCFF 9466E767 BFB8AA3B
	v_fmac_f32_e32 v151, 0xb2a5705f, v82                       // 0000001AFF88: 572EA4FF B2A5705F
	v_dual_mul_f32 v120, 0xbfb8aa3b, v99 :: v_dual_lshlrev_b32 v93, 16, v93// 0000001AFF90: C8E2C6FF 785CBA90 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AFF9C: BF870214
	v_add_f32_e32 v112, v112, v117                             // 0000001AFFA0: 06E0EB70
	v_exp_f32_e32 v103, v103                                   // 0000001AFFA4: 7ECE4B67
	v_mul_f32_e32 v121, 0xbfb8aa3b, v100                       // 0000001AFFA8: 10F2C8FF BFB8AA3B
	v_mul_f32_e32 v119, 0xbfb8aa3b, v98                        // 0000001AFFB0: 10EEC4FF BFB8AA3B
	v_fma_f32 v145, 0xbfb8aa3b, v49, -v113                     // 0000001AFFB8: D6130091 85C662FF BFB8AA3B
	v_exp_f32_e32 v112, v112                                   // 0000001AFFC4: 7EE04B70
	v_rndne_f32_e32 v146, v113                                 // 0000001AFFC8: 7F244771
	v_mul_f32_e32 v150, 0xbfb8aa3b, v96                        // 0000001AFFCC: 112CC0FF BFB8AA3B
	v_cvt_i32_f32_e32 v118, v118                               // 0000001AFFD4: 7EEC1176
	v_dual_mul_f32 v147, 0xbfb8aa3b, v93 :: v_dual_lshlrev_b32 v102, 16, v102// 0000001AFFD8: C8E2BAFF 9366CC90 BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_2)                         // 0000001AFFE4: BF870006
	.long 0xd71c0067                                           // 0000001AFFE8: D71C0067
	v_cndmask_b32_e32 v1, v103, v116, vcc_lo                   // 0000001AFFEC: 0202E967
	v_rndne_f32_e32 v152, v114                                 // 0000001AFFF0: 7F304772
	v_fma_f32 v153, 0xbfb8aa3b, v98, -v119                     // 0000001AFFF4: D6130099 85DEC4FF BFB8AA3B
	v_rndne_f32_e32 v154, v119                                 // 0000001B0000: 7F344777
	v_rndne_f32_e32 v156, v120                                 // 0000001B0004: 7F384778
	v_fma_f32 v159, 0xbfb8aa3b, v101, -v122                    // 0000001B0008: D613009F 85EACAFF BFB8AA3B
	v_rndne_f32_e32 v160, v122                                 // 0000001B0014: 7F40477A
	v_dual_fmac_f32 v145, 0xb2a5705f, v49 :: v_dual_sub_f32 v114, v114, v152// 0000001B0018: C80A62FF 91733172 B2A5705F
	v_sub_f32_e32 v113, v113, v146                             // 0000001B0024: 08E32571
	v_fma_f32 v169, 0xbfb8aa3b, v96, -v150                     // 0000001B0028: D61300A9 865AC0FF BFB8AA3B
	v_rndne_f32_e32 v170, v150                                 // 0000001B0034: 7F544796
	.long 0xd71c0070                                           // 0000001B0038: D71C0070
	v_cndmask_b32_e32 v1, v112, v118, vcc_lo                   // 0000001B003C: 0202ED70
	v_cndmask_b32_e32 v103, 0, v103, vcc_lo                    // 0000001B0040: 02CECE80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000001B0044: 7C3C92FF 42CE8ED0
	v_rndne_f32_e32 v164, v147                                 // 0000001B004C: 7F484793
	v_dual_fmac_f32 v153, 0xb2a5705f, v98 :: v_dual_sub_f32 v122, v122, v160// 0000001B0050: C80AC4FF 997B417A B2A5705F
	v_dual_fmac_f32 v159, 0xb2a5705f, v101 :: v_dual_cndmask_b32 v112, 0, v112// 0000001B005C: C812CAFF 9F70E080 B2A5705F
	v_sub_f32_e32 v115, v119, v154                             // 0000001B0068: 08E73577
	v_dual_sub_f32 v119, v120, v156 :: v_dual_sub_f32 v150, v150, v170// 0000001B006C: C94B3978 77975596
	v_add_f32_e32 v113, v113, v145                             // 0000001B0074: 06E32371
	v_fmac_f32_e32 v169, 0xb2a5705f, v96                       // 0000001B0078: 5752C0FF B2A5705F
	v_sub_f32_e32 v145, v147, v164                             // 0000001B0080: 09234993
	s_waitcnt vmcnt(34)                                        // 0000001B0084: BF898BF7
	v_dual_mul_f32 v144, 0xbfb8aa3b, v102 :: v_dual_lshlrev_b32 v97, 16, v97// 0000001B0088: C8E2CCFF 9060C290 BFB8AA3B
	v_exp_f32_e32 v113, v113                                   // 0000001B0094: 7EE24B71
	v_add_f32_e32 v150, v150, v169                             // 0000001B0098: 072D5396
	v_fma_f32 v155, 0xbfb8aa3b, v99, -v120                     // 0000001B009C: D613009B 85E2C6FF BFB8AA3B
	v_cvt_i32_f32_e32 v146, v146                               // 0000001B00A8: 7F241192
	v_rndne_f32_e32 v162, v144                                 // 0000001B00AC: 7F444790
	v_fma_f32 v163, 0xbfb8aa3b, v93, -v147                     // 0000001B00B0: D61300A3 864EBAFF BFB8AA3B
	v_exp_f32_e32 v116, v150                                   // 0000001B00BC: 7EE84B96
	v_fmac_f32_e32 v155, 0xb2a5705f, v99                       // 0000001B00C0: 5736C6FF B2A5705F
	v_cvt_i32_f32_e32 v147, v164                               // 0000001B00C8: 7F2611A4
	v_cvt_i32_f32_e32 v164, v170                               // 0000001B00CC: 7F4811AA
	v_dual_add_f32 v122, v122, v159 :: v_dual_add_f32 v115, v115, v153// 0000001B00D0: C9093F7A 7A733373
	.long 0xd71c0071                                           // 0000001B00D8: D71C0071
	v_cndmask_b32_e32 v1, v113, v146, vcc_lo                   // 0000001B00DC: 02032571
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001B00E0: 7C3C62FF 42CE8ED0
	v_fma_f32 v161, 0xbfb8aa3b, v102, -v144                    // 0000001B00E8: D61300A1 8642CCFF BFB8AA3B
	v_sub_f32_e32 v144, v144, v162                             // 0000001B00F4: 09214590
	v_exp_f32_e32 v115, v115                                   // 0000001B00F8: 7EE64B73
	.long 0xd71c0074                                           // 0000001B00FC: D71C0074
	v_cndmask_b32_e32 v1, v116, v164, vcc_lo                   // 0000001B0100: 02034974
	v_add_f32_e32 v119, v119, v155                             // 0000001B0104: 06EF3777
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000001B0108: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 0000001B010C: 7C3660FF C2B17218
	v_cvt_i32_f32_e32 v117, v154                               // 0000001B0114: 7EEA119A
	v_fma_f32 v157, 0xbfb8aa3b, v100, -v121                    // 0000001B0118: D613009D 85E6C8FF BFB8AA3B
	v_exp_f32_e32 v119, v119                                   // 0000001B0124: 7EEE4B77
	v_fma_f32 v165, 0xbfb8aa3b, v94, -v148                     // 0000001B0128: D61300A5 8652BCFF BFB8AA3B
	v_cndmask_b32_e32 v48, 0x7f800000, v103, vcc_lo            // 0000001B0134: 0260CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000001B013C: 7C3692FF C2B17218
	v_rndne_f32_e32 v166, v148                                 // 0000001B0144: 7F4C4794
	v_cvt_i32_f32_e32 v120, v156                               // 0000001B0148: 7EF0119C
	.long 0xd71c0073                                           // 0000001B014C: D71C0073
	v_cndmask_b32_e32 v1, v115, v117, vcc_lo                   // 0000001B0150: 0202EB73
	v_rndne_f32_e32 v158, v121                                 // 0000001B0154: 7F3C4779
	v_cndmask_b32_e32 v73, 0x7f800000, v112, vcc_lo            // 0000001B0158: 0292E0FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v98                  // 0000001B0160: 7C3CC4FF 42CE8ED0
	v_dual_fmac_f32 v157, 0xb2a5705f, v100 :: v_dual_sub_f32 v148, v148, v166// 0000001B0168: C80AC8FF 9D954D94 B2A5705F
	.long 0xd71c0075                                           // 0000001B0174: D71C0075
	v_cndmask_b32_e32 v1, v119, v120, vcc_lo                   // 0000001B0178: 0202F177
	v_cvt_i32_f32_e32 v154, v158                               // 0000001B017C: 7F34119E
	v_cndmask_b32_e32 v103, 0, v115, vcc_lo                    // 0000001B0180: 02CEE680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v99                  // 0000001B0184: 7C3CC6FF 42CE8ED0
	v_fmac_f32_e32 v165, 0xb2a5705f, v94                       // 0000001B018C: 574ABCFF B2A5705F
	v_exp_f32_e32 v122, v122                                   // 0000001B0194: 7EF44B7A
	v_cvt_i32_f32_e32 v156, v160                               // 0000001B0198: 7F3811A0
	v_fma_f32 v167, 0xbfb8aa3b, v95, -v149                     // 0000001B019C: D61300A7 8656BEFF BFB8AA3B
	v_dual_cndmask_b32 v112, 0, v117 :: v_dual_fmac_f32 v161, 0xb2a5705f, v102// 0000001B01A8: CA40EA80 70A0CCFF B2A5705F
	v_dual_add_f32 v148, v148, v165 :: v_dual_sub_f32 v121, v121, v158// 0000001B01B4: C90B4B94 94793D79
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v100                 // 0000001B01BC: 7C3CC8FF 42CE8ED0
	v_cvt_i32_f32_e32 v158, v162                               // 0000001B01C4: 7F3C11A2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B01C8: BF870294
	v_add_f32_e32 v144, v144, v161                             // 0000001B01CC: 07214390
	.long 0xd71c0077                                           // 0000001B01D0: D71C0077
	v_cndmask_b32_e32 v1, v122, v156, vcc_lo                   // 0000001B01D4: 0203397A
	v_add_f32_e32 v121, v121, v157                             // 0000001B01D8: 06F33B79
	v_rndne_f32_e32 v168, v149                                 // 0000001B01DC: 7F504795
	v_fmac_f32_e32 v167, 0xb2a5705f, v95                       // 0000001B01E0: 574EBEFF B2A5705F
	v_exp_f32_e32 v144, v144                                   // 0000001B01E8: 7F204B90
	v_exp_f32_e32 v148, v148                                   // 0000001B01EC: 7F284B94
	v_exp_f32_e32 v121, v121                                   // 0000001B01F0: 7EF24B79
	v_sub_f32_e32 v149, v149, v168                             // 0000001B01F4: 092B5195
	v_cvt_i32_f32_e32 v160, v166                               // 0000001B01F8: 7F4011A6
	v_cvt_i32_f32_e32 v162, v168                               // 0000001B01FC: 7F4411A8
	.long 0xd41b0005                                           // 0000001B0200: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v94, vcc_lo              // 0000001B0204: 0202BCFF C2B17218
	v_mul_f32_e32 v0, v0, v67                                  // 0000001B020C: 10008700
	v_mul_f32_e32 v40, v40, v67                                // 0000001B0210: 10508728
	v_mul_f32_e32 v32, v32, v67                                // 0000001B0214: 10408720
	.long 0xd71c0078                                           // 0000001B0218: D71C0078
	v_cndmask_b32_e32 v1, v144, v158, vcc_lo                   // 0000001B021C: 02033D90
	.long 0xd71c007a                                           // 0000001B0220: D71C007A
	v_cndmask_b32_e32 v1, v148, v160, vcc_lo                   // 0000001B0224: 02034194
	.long 0xd71c0076                                           // 0000001B0228: D71C0076
	v_cndmask_b32_e32 v1, v121, v154, vcc_lo                   // 0000001B022C: 02033579
	v_mul_f32_e32 v24, v24, v67                                // 0000001B0230: 10308718
	v_dual_mul_f32 v16, v16, v67 :: v_dual_mul_f32 v17, v17, v66// 0000001B0234: C8C68710 10108511
	v_mul_f32_e32 v9, v9, v66                                  // 0000001B023C: 10128509
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B0240: BF870004
	v_cndmask_b32_e32 v115, 0, v118, vcc_lo                    // 0000001B0244: 02E6EC80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v101                 // 0000001B0248: 7C3CCAFF 42CE8ED0
	v_mul_f32_e32 v1, v1, v66                                  // 0000001B0250: 10028501
	v_cndmask_b32_e32 v117, 0, v119, vcc_lo                    // 0000001B0254: 02EAEE80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v102                 // 0000001B0258: 7C3CCCFF 42CE8ED0
	v_dual_fmac_f32 v163, 0xb2a5705f, v93 :: v_dual_cndmask_b32 v118, 0, v120// 0000001B0260: C812BAFF A376F080 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B026C: BF8701B1
	v_add_f32_e32 v145, v145, v163                             // 0000001B0270: 07234791
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001B0274: 7C3662FF C2B17218
	v_dual_add_f32 v120, 1.0, v48 :: v_dual_add_f32 v149, v149, v167// 0000001B027C: C90860F2 78954F95
	v_exp_f32_e32 v145, v145                                   // 0000001B0284: 7F224B91
	v_cndmask_b32_e32 v49, 0x7f800000, v113, vcc_lo            // 0000001B0288: 0262E2FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v93                  // 0000001B0290: 7C3CBAFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001B0298: BF870313
	v_exp_f32_e32 v149, v149                                   // 0000001B029C: 7F2A4B95
	.long 0xd71c0079                                           // 0000001B02A0: D71C0079
	v_cndmask_b32_e32 v1, v145, v147, vcc_lo                   // 0000001B02A4: 02032791
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B02A8: BF870115
	.long 0xd71c0090                                           // 0000001B02AC: D71C0090
	v_cndmask_b32_e32 v1, v149, v162, vcc_lo                   // 0000001B02B0: 02034595
	v_cndmask_b32_e32 v113, 0, v121, vcc_lo                    // 0000001B02B4: 02E2F280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v94                  // 0000001B02B8: 7C3CBCFF 42CE8ED0
	v_div_scale_f32 v121, null, v120, v120, v56                // 0000001B02C0: D6FC7C79 04E2F178
	v_cndmask_b32_e32 v119, 0, v122, vcc_lo                    // 0000001B02C8: 02EEF480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v95                  // 0000001B02CC: 7C3CBEFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001B02D4: BF870242
	v_cndmask_b32_e64 v94, 0x7f800000, v119, s5                // 0000001B02D8: D501005E 0016EEFF 7F800000
	v_cndmask_b32_e32 v48, 0, v144, vcc_lo                     // 0000001B02E4: 02612080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000001B02E8: 7C3CC0FF 42CE8ED0
	.long 0xd41b0005                                           // 0000001B02F0: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v95, vcc_lo              // 0000001B02F4: 0202BEFF C2B17218
	v_add_f32_e32 v94, 1.0, v94                                // 0000001B02FC: 06BCBCF2
	v_cndmask_b32_e32 v116, 0, v116, vcc_lo                    // 0000001B0300: 02E8E880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v98                  // 0000001B0304: 7C36C4FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000001B030C: BF8701D4
	v_cndmask_b32_e64 v95, 0x7f800000, v48, s5                 // 0000001B0310: D501005F 001660FF 7F800000
	.long 0xd41b0005                                           // 0000001B031C: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v96, vcc_lo              // 0000001B0320: 0202C0FF C2B17218
	v_cndmask_b32_e32 v98, 0x7f800000, v103, vcc_lo            // 0000001B0328: 02C4CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v99                  // 0000001B0330: 7C36C6FF C2B17218
	v_rcp_f32_e32 v103, v121                                   // 0000001B0338: 7ECE5579
	v_cndmask_b32_e64 v96, 0x7f800000, v116, s5                // 0000001B033C: D5010060 0016E8FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001B0348: BF870233
	v_dual_add_f32 v95, 1.0, v95 :: v_dual_add_f32 v98, 1.0, v98// 0000001B034C: C908BEF2 5F62C4F2
	v_cndmask_b32_e32 v99, 0x7f800000, v112, vcc_lo            // 0000001B0354: 02C6E0FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v100                 // 0000001B035C: 7C36C8FF C2B17218
	v_add_f32_e32 v96, 1.0, v96                                // 0000001B0364: 06C0C0F2
	v_cndmask_b32_e32 v100, 0x7f800000, v115, vcc_lo           // 0000001B0368: 02C8E6FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v101                 // 0000001B0370: 7C36CAFF C2B17218
	v_add_f32_e32 v115, 1.0, v49                               // 0000001B0378: 06E662F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B037C: BF8701B5
	v_fma_f32 v49, -v121, v103, 1.0                            // 0000001B0380: D6130031 23CACF79
	v_cndmask_b32_e32 v101, 0x7f800000, v117, vcc_lo           // 0000001B0388: 02CAEAFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v102                 // 0000001B0390: 7C36CCFF C2B17218
	v_fmac_f32_e32 v103, v49, v103                             // 0000001B0398: 56CECF31
	v_div_scale_f32 v116, s5, v111, v115, v111                 // 0000001B039C: D6FC0574 05BEE76F
	v_cndmask_b32_e32 v102, 0x7f800000, v118, vcc_lo           // 0000001B03A4: 02CCECFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v93                  // 0000001B03AC: 7C36BAFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B03B4: BF870122
	v_dual_add_f32 v102, 1.0, v102 :: v_dual_cndmask_b32 v93, 0x7f800000, v113// 0000001B03B8: C912CCF2 665CE2FF 7F800000
	v_div_scale_f32 v117, vcc_lo, v56, v120, v56               // 0000001B03C4: D6FC6A75 04E2F138
	v_div_scale_f32 v119, null, v102, v102, v80                // 0000001B03CC: D6FC7C77 0542CD66
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B03D4: BF870112
	v_mul_f32_e32 v49, v117, v103                              // 0000001B03D8: 1062CF75
	v_rcp_f32_e32 v146, v119                                   // 0000001B03DC: 7F245577
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B03E0: BF870091
	v_fma_f32 v48, -v121, v49, v117                            // 0000001B03E4: D6130030 25D66379
	v_fmac_f32_e32 v49, v48, v103                              // 0000001B03EC: 5662CF30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B03F0: BF870291
	v_fma_f32 v117, -v121, v49, v117                           // 0000001B03F4: D6130075 25D66379
	v_fma_f32 v121, -v119, v146, 1.0                           // 0000001B03FC: D6130079 23CB2577
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B0404: BF870112
	v_div_fmas_f32 v103, v117, v103, v49                       // 0000001B0408: D6370067 04C6CF75
	v_dual_fmac_f32 v146, v121, v146 :: v_dual_add_f32 v73, 1.0, v73// 0000001B0410: C8092579 924892F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B0418: BF870112
	v_div_fixup_f32 v56, v103, v120, v56                       // 0000001B041C: D6270038 04E2F167
	v_div_scale_f32 v122, null, v73, v73, v57                  // 0000001B0424: D6FC7C7A 04E69349
	v_div_scale_f32 v118, s4, v57, v73, v57                    // 0000001B042C: D6FC0476 04E69339
	s_mov_b32 vcc_lo, s4                                       // 0000001B0434: BEEA0004
	.long 0x7e9e39b8                                           // 0000001B0438: 7E9E39B8
	v_rcp_f32_e32 v112, v122                                   // 0000001B043C: 7EE0557A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B0440: BF870091
	v_and_b32_e32 v79, 1, v79                                  // 0000001B0444: 369E9E81
	v_add3_u32 v56, v56, v79, 0x7fff                           // 0000001B0448: D6550038 03FE9F38 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B0454: BF870095
	v_fma_f32 v113, -v122, v112, 1.0                           // 0000001B0458: D6130071 23CAE17A
	v_fmac_f32_e32 v112, v113, v112                            // 0000001B0460: 56E0E171
	v_div_scale_f32 v113, null, v115, v115, v111               // 0000001B0464: D6FC7C71 05BEE773
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B046C: BF870112
	v_mul_f32_e32 v144, v118, v112                             // 0000001B0470: 1120E176
	v_rcp_f32_e32 v145, v113                                   // 0000001B0474: 7F225571
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B0478: BF870091
	v_fma_f32 v147, -v122, v144, v118                          // 0000001B047C: D6130093 25DB217A
	v_fmac_f32_e32 v144, v147, v112                            // 0000001B0484: 5720E193
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B0488: BF870115
	v_fma_f32 v48, -v113, v145, 1.0                            // 0000001B048C: D6130030 23CB2371
	v_fma_f32 v118, -v122, v144, v118                          // 0000001B0494: D6130076 25DB217A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B049C: BF870112
	v_fmac_f32_e32 v145, v48, v145                             // 0000001B04A0: 57232330
	v_div_fmas_f32 v112, v118, v112, v144                      // 0000001B04A4: D6370070 0642E176
	s_mov_b32 vcc_lo, s2                                       // 0000001B04AC: BEEA0002
	v_div_fmas_f32 v49, v109, v91, v70                         // 0000001B04B0: D6370031 051AB76D
	s_mov_b32 vcc_lo, s3                                       // 0000001B04B8: BEEA0003
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001B04BC: BF870002
	v_div_fixup_f32 v57, v112, v73, v57                        // 0000001B04C0: D6270039 04E69370
	v_div_fmas_f32 v70, v108, v90, v71                         // 0000001B04C8: D6370046 051EB56C
	v_div_scale_f32 v71, s2, v80, v102, v80                    // 0000001B04D0: D6FC0247 0542CD50
	v_div_fixup_f32 v49, v49, v89, 1.0                         // 0000001B04D8: D6270031 03CAB331
	v_add_f32_e32 v90, 1.0, v100                               // 0000001B04E0: 06B4C8F2
	.long 0x7e9039b9                                           // 0000001B04E4: 7E9039B9
	v_div_fixup_f32 v48, v70, v88, 1.0                         // 0000001B04E8: D6270030 03CAB146
	v_mul_f32_e32 v88, v116, v145                              // 0000001B04F0: 10B12374
	v_dual_mul_f32 v58, v58, v49 :: v_dual_mul_f32 v89, v71, v146// 0000001B04F4: C8C6633A 3A592547
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B04FC: BF870193
	v_dual_add_f32 v70, 1.0, v101 :: v_dual_mul_f32 v59, v59, v48// 0000001B0500: C906CAF2 463A613B
	v_fma_f32 v91, -v113, v88, v116                            // 0000001B0508: D613005B 25D2B171
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B0510: BF870213
	v_div_scale_f32 v100, null, v98, v98, v58                  // 0000001B0514: D6FC7C64 04EAC562
	v_fma_f32 v101, -v119, v89, v71                            // 0000001B051C: D6130065 251EB377
	v_mul_f32_e32 v103, v50, v49                               // 0000001B0524: 10CE6332
	v_mul_f32_e32 v42, v42, v49                                // 0000001B0528: 1054632A
	v_dual_fmac_f32 v88, v91, v145 :: v_dual_add_f32 v99, 1.0, v99// 0000001B052C: C809235B 5862C6F2
	v_rcp_f32_e32 v91, v100                                    // 0000001B0534: 7EB65564
	v_fmac_f32_e32 v89, v101, v146                             // 0000001B0538: 56B32565
	v_mul_f32_e32 v43, v43, v48                                // 0000001B053C: 1056612B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B0540: BF870003
	v_fma_f32 v109, -v113, v88, v116                           // 0000001B0544: D613006D 25D2B171
	v_div_scale_f32 v108, null, v99, v99, v59                  // 0000001B054C: D6FC7C6C 04EEC763
	v_mul_f32_e32 v113, v51, v48                               // 0000001B0554: 10E26133
	v_div_scale_f32 v116, vcc_lo, v58, v98, v58                // 0000001B0558: D6FC6A74 04EAC53A
	v_fma_f32 v71, -v119, v89, v71                             // 0000001B0560: D6130047 251EB377
	v_mul_f32_e32 v34, v34, v49                                // 0000001B0568: 10446322
	v_rcp_f32_e32 v101, v108                                   // 0000001B056C: 7ECA556C
	v_fma_f32 v50, -v100, v91, 1.0                             // 0000001B0570: D6130032 23CAB764
	v_div_scale_f32 v73, null, v94, v94, v113                  // 0000001B0578: D6FC7C49 05C6BD5E
	v_dual_mul_f32 v35, v35, v48 :: v_dual_mul_f32 v26, v26, v49// 0000001B0580: C8C66123 231A631A
	v_mul_f32_e32 v27, v27, v48                                // 0000001B0588: 1036611B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(TRANS32_DEP_2)// 0000001B058C: BF870344
	v_fmac_f32_e32 v91, v50, v91                               // 0000001B0590: 56B6B732
	v_div_scale_f32 v50, s3, v59, v99, v59                     // 0000001B0594: D6FC0332 04EEC73B
	v_rcp_f32_e32 v119, v73                                    // 0000001B059C: 7EEE5549
	v_mul_f32_e32 v19, v19, v48                                // 0000001B05A0: 10266113
	v_fma_f32 v51, -v108, v101, 1.0                            // 0000001B05A4: D6130033 23CACB6C
	v_dual_mul_f32 v11, v11, v48 :: v_dual_mul_f32 v10, v10, v49// 0000001B05AC: C8C6610B 0B0A630A
	v_dual_mul_f32 v2, v2, v49 :: v_dual_mul_f32 v3, v3, v48   // 0000001B05B4: C8C66302 02026103
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001B05BC: BF8702A3
	v_fmac_f32_e32 v101, v51, v101                             // 0000001B05C0: 56CACB33
	v_mul_f32_e32 v51, v116, v91                               // 0000001B05C4: 1066B774
	v_fma_f32 v144, -v73, v119, 1.0                            // 0000001B05C8: D6130090 23CAEF49
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B05D0: BF870193
	v_mul_f32_e32 v118, v50, v101                              // 0000001B05D4: 10ECCB32
	v_fma_f32 v120, -v100, v51, v116                           // 0000001B05D8: D6130078 25D26764
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B05E0: BF870193
	v_fmac_f32_e32 v119, v144, v119                            // 0000001B05E4: 56EEEF90
	v_fma_f32 v121, -v108, v118, v50                           // 0000001B05E8: D6130079 24CAED6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B05F0: BF870091
	v_dual_fmac_f32 v51, v120, v91 :: v_dual_fmac_f32 v118, v121, v101// 0000001B05F4: C800B778 3376CB79
	v_fma_f32 v100, -v100, v51, v116                           // 0000001B05FC: D6130064 25D26764
	v_div_scale_f32 v121, s6, v113, v94, v113                  // 0000001B0604: D6FC0679 05C6BD71
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B060C: BF870193
	v_fma_f32 v50, -v108, v118, v50                            // 0000001B0610: D6130032 24CAED6C
	v_div_fmas_f32 v91, v100, v91, v51                         // 0000001B0618: D637005B 04CEB764
	s_mov_b32 vcc_lo, s3                                       // 0000001B0620: BEEA0003
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B0624: BF870122
	v_div_fmas_f32 v100, v50, v101, v118                       // 0000001B0628: D6370064 05DACB32
	s_mov_b32 vcc_lo, s0                                       // 0000001B0630: BEEA0000
	v_div_fixup_f32 v58, v91, v98, v58                         // 0000001B0634: D627003A 04EAC55B
	v_div_fmas_f32 v50, v107, v86, v142                        // 0000001B063C: D6370032 063AAD6B
	s_mov_b32 vcc_lo, s1                                       // 0000001B0644: BEEA0001
	v_and_b32_e32 v86, 1, v72                                  // 0000001B0648: 36AC9081
	v_div_fmas_f32 v84, v110, v84, v143                        // 0000001B064C: D6370054 063EA96E
	.long 0x7e9a39ba                                           // 0000001B0654: 7E9A39BA
	v_div_fixup_f32 v51, v50, v83, 1.0                         // 0000001B0658: D6270033 03CAA732
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B0660: BF870214
	v_add3_u32 v57, v57, v86, 0x7fff                           // 0000001B0664: D6550039 03FEAD39 00007FFF
	v_div_fixup_f32 v50, v84, v81, 1.0                         // 0000001B0670: D6270032 03CAA354
	v_mul_f32_e32 v81, v121, v119                              // 0000001B0678: 10A2EF79
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B067C: BF870004
	v_dual_mul_f32 v60, v60, v51 :: v_dual_add_f32 v93, 1.0, v93// 0000001B0680: C8C8673C 3C5CBAF2
	s_clause 0x1                                               // 0000001B0688: BF850001
	global_store_d16_hi_b16 v[6:7], v56, off                   // 0000001B068C: DC960000 007C3806
	global_store_d16_hi_b16 v[6:7], v57, off offset:1024       // 0000001B0694: DC960400 007C3906
	v_mul_f32_e32 v61, v61, v50                                // 0000001B069C: 107A653D
	v_fma_f32 v84, -v73, v81, v121                             // 0000001B06A0: D6130054 25E6A349
	v_div_scale_f32 v86, null, v90, v90, v60                   // 0000001B06A8: D6FC7C56 04F2B55A
	v_div_scale_f32 v117, null, v93, v93, v103                 // 0000001B06B0: D6FC7C75 059EBB5D
	v_div_scale_f32 v122, s4, v103, v93, v103                  // 0000001B06B8: D6FC047A 059EBB67
	v_mul_f32_e32 v52, v52, v51                                // 0000001B06C0: 10686734
	v_fmac_f32_e32 v81, v84, v119                              // 0000001B06C4: 56A2EF54
	v_rcp_f32_e32 v84, v86                                     // 0000001B06C8: 7EA85556
	v_rcp_f32_e32 v112, v117                                   // 0000001B06CC: 7EE05575
	v_dual_mul_f32 v44, v44, v51 :: v_dual_and_b32 v77, 1, v77 // 0000001B06D0: C8E4672C 2C4C9A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001B06D8: BF870232
	v_fma_f32 v57, -v73, v81, v121                             // 0000001B06DC: D6130039 25E6A349
	v_mul_f32_e32 v36, v36, v51                                // 0000001B06E4: 10486724
	v_mul_f32_e32 v28, v28, v51                                // 0000001B06E8: 1038671C
	v_add3_u32 v58, v58, v77, 0x7fff                           // 0000001B06EC: D655003A 03FE9B3A 00007FFF
	v_mul_f32_e32 v21, v21, v50                                // 0000001B06F8: 102A6515
	v_mul_f32_e32 v13, v13, v50                                // 0000001B06FC: 101A650D
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B0700: BF870296
	v_fma_f32 v73, -v86, v84, 1.0                              // 0000001B0704: D6130049 23CAA956
	v_fma_f32 v120, -v117, v112, 1.0                           // 0000001B070C: D6130078 23CAE175
	global_store_d16_hi_b16 v[14:15], v58, off                 // 0000001B0714: DC960000 007C3A0E
	v_mul_f32_e32 v12, v12, v51                                // 0000001B071C: 1018670C
	v_mul_f32_e32 v4, v4, v51                                  // 0000001B0720: 10086704
	v_fmac_f32_e32 v84, v73, v84                               // 0000001B0724: 56A8A949
	v_fmac_f32_e32 v112, v120, v112                            // 0000001B0728: 56E0E178
	v_div_scale_f32 v73, s0, v61, v70, v61                     // 0000001B072C: D6FC0049 04F68D3D
	v_mul_f32_e32 v5, v5, v50                                  // 0000001B0734: 100A6505
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B0738: BF870093
	v_mul_f32_e32 v83, v122, v112                              // 0000001B073C: 10A6E17A
	v_fma_f32 v79, -v117, v83, v122                            // 0000001B0740: D613004F 25EAA775
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B0748: BF870121
	v_fmac_f32_e32 v83, v79, v112                              // 0000001B074C: 56A6E14F
	v_div_scale_f32 v79, null, v70, v70, v61                   // 0000001B0750: D6FC7C4F 04F68D46
	v_fma_f32 v56, -v117, v83, v122                            // 0000001B0758: D6130038 25EAA775
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B0760: BF870292
	v_rcp_f32_e32 v91, v79                                     // 0000001B0764: 7EB6554F
	v_fma_f32 v98, -v79, v91, 1.0                              // 0000001B0768: D6130062 23CAB74F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B0770: BF870091
	v_fmac_f32_e32 v91, v98, v91                               // 0000001B0774: 56B6B762
	v_mul_f32_e32 v108, v73, v91                               // 0000001B0778: 10D8B749
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B077C: BF870091
	v_fma_f32 v117, -v79, v108, v73                            // 0000001B0780: D6130075 2526D94F
	v_fmac_f32_e32 v108, v117, v91                             // 0000001B0788: 56D8B775
	v_div_fixup_f32 v59, v100, v99, v59                        // 0000001B078C: D627003B 04EEC764
	v_div_scale_f32 v99, vcc_lo, v60, v90, v60                 // 0000001B0794: D6FC6A63 04F2B53C
	v_div_scale_f32 v100, null, v95, v95, v52                  // 0000001B079C: D6FC7C64 04D2BF5F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B07A4: BF870193
	.long 0x7e9039bb                                           // 0000001B07A8: 7E9039BB
	v_mul_f32_e32 v101, v99, v84                               // 0000001B07AC: 10CAA963
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B07B0: BF870113
	v_rcp_f32_e32 v107, v100                                   // 0000001B07B4: 7ED65564
	v_and_b32_e32 v98, 1, v72                                  // 0000001B07B8: 36C49081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B07BC: BF870112
	v_fma_f32 v77, -v86, v101, v99                             // 0000001B07C0: D613004D 258ECB56
	v_add3_u32 v59, v59, v98, 0x7fff                           // 0000001B07C8: D655003B 03FEC53B 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B07D4: BF870292
	v_fmac_f32_e32 v101, v77, v84                              // 0000001B07D8: 56CAA94D
	v_fma_f32 v58, -v100, v107, 1.0                            // 0000001B07DC: D613003A 23CAD764
	global_store_d16_hi_b16 v[22:23], v59, off                 // 0000001B07E4: DC960000 007C3B16
	v_fma_f32 v59, -v86, v101, v99                             // 0000001B07EC: D613003B 258ECB56
	v_fmac_f32_e32 v107, v58, v107                             // 0000001B07F4: 56D6D73A
	v_fma_f32 v58, -v79, v108, v73                             // 0000001B07F8: D613003A 2526D94F
	s_waitcnt vmcnt(23)                                        // 0000001B0800: BF895FF7
	v_lshlrev_b32_e32 v79, 16, v137                            // 0000001B0804: 309F1290
	v_div_fmas_f32 v59, v59, v84, v101                         // 0000001B0808: D637003B 0596A93B
	s_mov_b32 vcc_lo, s0                                       // 0000001B0810: BEEA0000
	v_div_fmas_f32 v58, v58, v91, v108                         // 0000001B0814: D637003A 05B2B73A
	s_mov_b32 vcc_lo, s2                                       // 0000001B081C: BEEA0002
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B0820: BF870112
	v_div_fixup_f32 v59, v59, v90, v60                         // 0000001B0824: D627003B 04F2B53B
	v_div_fixup_f32 v58, v58, v70, v61                         // 0000001B082C: D627003A 04F68D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B0834: BF870112
	.long 0x7e9839bb                                           // 0000001B0838: 7E9839BB
	.long 0x7e9039ba                                           // 0000001B083C: 7E9039BA
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000001B0840: BF870151
	v_and_b32_e32 v70, 1, v72                                  // 0000001B0844: 368C9081
	v_div_fmas_f32 v71, v71, v146, v89                         // 0000001B0848: D6370047 05672547
	s_mov_b32 vcc_lo, s5                                       // 0000001B0850: BEEA0005
	v_div_fmas_f32 v60, v109, v145, v88                        // 0000001B0854: D637003C 0563236D
	s_mov_b32 vcc_lo, s4                                       // 0000001B085C: BEEA0004
	v_div_fixup_f32 v61, v71, v102, v80                        // 0000001B0860: D627003D 0542CD47
	v_mul_f32_e32 v80, 0xbfb8aa3b, v79                         // 0000001B0868: 10A09EFF BFB8AA3B
	v_div_fmas_f32 v56, v56, v112, v83                         // 0000001B0870: D6370038 054EE138
	v_div_fixup_f32 v60, v60, v115, v111                       // 0000001B0878: D627003C 05BEE73C
	s_mov_b32 vcc_lo, s6                                       // 0000001B0880: BEEA0006
	.long 0x7e9639bd                                           // 0000001B0884: 7E9639BD
	v_rndne_f32_e32 v83, v80                                   // 0000001B0888: 7EA64750
	v_mul_f32_e32 v53, v53, v50                                // 0000001B088C: 106A6535
	.long 0x7e9039bc                                           // 0000001B0890: 7E9039BC
	v_div_fmas_f32 v57, v57, v119, v81                         // 0000001B0894: D6370039 0546EF39
	v_and_b32_e32 v71, 1, v76                                  // 0000001B089C: 368E9881
	v_and_b32_e32 v75, 1, v75                                  // 0000001B08A0: 36969681
	v_div_scale_f32 v116, null, v96, v96, v53                  // 0000001B08A4: D6FC7C74 04D6C160
	v_and_b32_e32 v73, 1, v72                                  // 0000001B08AC: 36929081
	v_add3_u32 v58, v58, v70, 0x7fff                           // 0000001B08B0: D655003A 03FE8D3A 00007FFF
	v_add3_u32 v59, v59, v71, 0x7fff                           // 0000001B08BC: D655003B 03FE8F3B 00007FFF
	v_add_f32_e32 v70, v114, v151                              // 0000001B08C8: 068D2F72
	v_rcp_f32_e32 v77, v116                                    // 0000001B08CC: 7E9A5574
	v_div_fixup_f32 v57, v57, v94, v113                        // 0000001B08D0: D6270039 05C6BD39
	v_add3_u32 v60, v60, v73, 0x7fff                           // 0000001B08D8: D655003C 03FE933C 00007FFF
	v_add3_u32 v61, v61, v75, 0x7fff                           // 0000001B08E4: D655003D 03FE973D 00007FFF
	s_clause 0x3                                               // 0000001B08F0: BF850003
	global_store_d16_hi_b16 v[30:31], v59, off                 // 0000001B08F4: DC960000 007C3B1E
	global_store_d16_hi_b16 v[38:39], v58, off                 // 0000001B08FC: DC960000 007C3A26
	global_store_d16_hi_b16 v[6:7], v60, off offset:32         // 0000001B0904: DC960020 007C3C06
	global_store_d16_hi_b16 v[46:47], v61, off offset:32       // 0000001B090C: DC960020 007C3D2E
	.long 0x7e9039b9                                           // 0000001B0914: 7E9039B9
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v82                  // 0000001B0918: 7C3CA4FF 42CE8ED0
	v_fma_f32 v61, -v116, v77, 1.0                             // 0000001B0920: D613003D 23CA9B74
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B0928: BF870113
	v_dual_mul_f32 v59, 0xbfb8aa3b, v97 :: v_dual_and_b32 v58, 1, v72// 0000001B092C: C8E4C2FF 3B3A9081 BFB8AA3B
	v_fmac_f32_e32 v77, v61, v77                               // 0000001B0938: 569A9B3D
	v_exp_f32_e32 v61, v70                                     // 0000001B093C: 7E7A4B46
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B0940: BF870192
	v_fma_f32 v73, 0xbfb8aa3b, v97, -v59                       // 0000001B0944: D6130049 84EEC2FF BFB8AA3B
	v_add3_u32 v57, v57, v58, 0x7fff                           // 0000001B0950: D6550039 03FE7539 00007FFF
	v_cvt_i32_f32_e32 v58, v152                                // 0000001B095C: 7E741198
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B0960: BF870003
	v_fmac_f32_e32 v73, 0xb2a5705f, v97                        // 0000001B0964: 5692C2FF B2A5705F
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)   // 0000001B096C: BF870105
	.long 0xd71c003a                                           // 0000001B0970: D71C003A
	v_cndmask_b32_e32 v1, v61, v58, vcc_lo                     // 0000001B0974: 0202753D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B0978: BF870001
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000001B097C: 02747480
	v_div_fixup_f32 v56, v56, v93, v103                        // 0000001B0980: D6270038 059EBB38
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v82                  // 0000001B0988: 7C36A4FF C2B17218
	v_fma_f32 v82, 0xbfb8aa3b, v79, -v80                       // 0000001B0990: D6130052 85429EFF BFB8AA3B
	v_sub_f32_e32 v80, v80, v83                                // 0000001B099C: 08A0A750
	v_div_scale_f32 v70, s0, v53, v96, v53                     // 0000001B09A0: D6FC0046 04D6C135
	.long 0x7e9439b8                                           // 0000001B09A8: 7E9439B8
	v_cndmask_b32_e32 v58, 0x7f800000, v58, vcc_lo             // 0000001B09AC: 027474FF 7F800000
	v_fmac_f32_e32 v82, 0xb2a5705f, v79                        // 0000001B09B4: 56A49EFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B09BC: BF870214
	v_mul_f32_e32 v76, v70, v77                                // 0000001B09C0: 10989B46
	v_and_b32_e32 v60, 1, v74                                  // 0000001B09C4: 36789481
	v_div_scale_f32 v110, s1, v52, v95, v52                    // 0000001B09C8: D6FC016E 04D2BF34
	v_rndne_f32_e32 v74, v59                                   // 0000001B09D0: 7E94473B
	s_mov_b32 vcc_lo, s1                                       // 0000001B09D4: BEEA0001
	v_add_f32_e32 v58, 1.0, v58                                // 0000001B09D8: 067474F2
	v_add3_u32 v56, v56, v60, 0x7fff                           // 0000001B09DC: D6550038 03FE7938 00007FFF
	v_mul_f32_e32 v71, v110, v107                              // 0000001B09E8: 108ED76E
	v_sub_f32_e32 v59, v59, v74                                // 0000001B09EC: 0876953B
	v_fma_f32 v60, -v116, v76, v70                             // 0000001B09F0: D613003C 251A9974
	v_add_f32_e32 v80, v80, v82                                // 0000001B09F8: 06A0A550
	global_store_d16_hi_b16 v[14:15], v56, off offset:32       // 0000001B09FC: DC960020 007C380E
	v_fma_f32 v75, -v100, v71, v110                            // 0000001B0A04: D613004B 25BA8F64
	v_add_f32_e32 v59, v59, v73                                // 0000001B0A0C: 0676933B
	v_fmac_f32_e32 v76, v60, v77                               // 0000001B0A10: 56989B3C
	v_cvt_i32_f32_e32 v60, v74                                 // 0000001B0A14: 7E78114A
	global_store_d16_hi_b16 v[22:23], v57, off offset:32       // 0000001B0A18: DC960020 007C3916
	v_fmac_f32_e32 v71, v75, v107                              // 0000001B0A20: 568ED74B
	v_exp_f32_e32 v59, v59                                     // 0000001B0A24: 7E764B3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B0A28: BF870091
	v_fma_f32 v61, -v100, v71, v110                            // 0000001B0A2C: D613003D 25BA8F64
	v_div_fmas_f32 v61, v61, v107, v71                         // 0000001B0A34: D637003D 051ED73D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001B0A3C: BF870005
	.long 0xd71c003b                                           // 0000001B0A40: D71C003B
	v_cndmask_b32_e32 v1, v59, v60, vcc_lo                     // 0000001B0A44: 0202793B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000001B0A48: 7C3CC2FF 42CE8ED0
	v_fma_f32 v60, -v116, v76, v70                             // 0000001B0A50: D613003C 251A9974
	v_div_scale_f32 v70, null, v58, v58, v40                   // 0000001B0A58: D6FC7C46 04A2753A
	v_div_fixup_f32 v52, v61, v95, v52                         // 0000001B0A60: D6270034 04D2BF3D
	.long 0x7f8e39c8                                           // 0000001B0A68: 7F8E39C8
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 0000001B0A6C: 02767680
	s_mov_b32 vcc_lo, s0                                       // 0000001B0A70: BEEA0000
	v_rcp_f32_e32 v56, v70                                     // 0000001B0A74: 7E705546
	v_div_fmas_f32 v60, v60, v77, v76                          // 0000001B0A78: D637003C 05329B3C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001B0A80: 7C36C2FF C2B17218
	.long 0x7e8e39b4                                           // 0000001B0A88: 7E8E39B4
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B0A8C: BF8701A3
	v_div_fixup_f32 v53, v60, v96, v53                         // 0000001B0A90: D6270035 04D6C13C
	v_dual_cndmask_b32 v59, 0x7f800000, v59 :: v_dual_lshlrev_b32 v60, 16, v138// 0000001B0A98: CA6276FF 3B3D1490 7F800000
	v_and_b32_e32 v71, 1, v71                                  // 0000001B0AA4: 368E8E81
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B0AA8: BF870215
	v_fma_f32 v73, -v70, v56, 1.0                              // 0000001B0AAC: D6130049 23CA7146
	.long 0x7e9039b5                                           // 0000001B0AB4: 7E9039B5
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B0AB8: BF870004
	v_add_f32_e32 v59, 1.0, v59                                // 0000001B0ABC: 067676F2
	v_mul_f32_e32 v61, 0xbfb8aa3b, v60                         // 0000001B0AC0: 107A78FF BFB8AA3B
	v_add3_u32 v52, v52, v71, 0x7fff                           // 0000001B0AC8: D6550034 03FE8F34 00007FFF
	v_fmac_f32_e32 v56, v73, v56                               // 0000001B0AD4: 56707149
	v_div_scale_f32 v73, vcc_lo, v40, v58, v40                 // 0000001B0AD8: D6FC6A49 04A27528
	v_div_scale_f32 v57, null, v59, v59, v41                   // 0000001B0AE0: D6FC7C39 04A6773B
	v_fma_f32 v75, 0xbfb8aa3b, v60, -v61                       // 0000001B0AE8: D613004B 84F678FF BFB8AA3B
	v_rndne_f32_e32 v76, v61                                   // 0000001B0AF4: 7E98473D
	v_and_b32_e32 v77, 1, v72                                  // 0000001B0AF8: 369A9081
	.long 0xd41e0001                                           // 0000001B0AFC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v60, vcc_lo              // 0000001B0B00: 020278FF 42CE8ED0
	v_rcp_f32_e32 v74, v57                                     // 0000001B0B08: 7E945539
	v_fmac_f32_e32 v75, 0xb2a5705f, v60                        // 0000001B0B0C: 569678FF B2A5705F
	v_sub_f32_e32 v61, v61, v76                                // 0000001B0B14: 087A993D
	v_add3_u32 v53, v53, v77, 0x7fff                           // 0000001B0B18: D6550035 03FE9B35 00007FFF
	v_cvt_i32_f32_e32 v76, v76                                 // 0000001B0B24: 7E98114C
	global_store_d16_hi_b16 v[30:31], v52, off offset:32       // 0000001B0B28: DC960020 007C341E
	v_add_f32_e32 v61, v61, v75                                // 0000001B0B30: 067A973D
	v_mul_f32_e32 v75, v73, v56                                // 0000001B0B34: 10967149
	global_store_d16_hi_b16 v[38:39], v53, off offset:32       // 0000001B0B38: DC960020 007C3526
	v_fma_f32 v81, -v57, v74, 1.0                              // 0000001B0B40: D6130051 23CA9539
	v_exp_f32_e32 v61, v61                                     // 0000001B0B48: 7E7A4B3D
	v_fma_f32 v77, -v70, v75, v73                              // 0000001B0B4C: D613004D 25269746
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B0B54: BF8701A2
	v_fmac_f32_e32 v74, v81, v74                               // 0000001B0B58: 56949551
	v_div_scale_f32 v81, s0, v41, v59, v41                     // 0000001B0B5C: D6FC0051 04A67729
	v_fmac_f32_e32 v75, v77, v56                               // 0000001B0B64: 5696714D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B0B68: BF870292
	v_mul_f32_e32 v84, v81, v74                                // 0000001B0B6C: 10A89551
	.long 0xd71c003d                                           // 0000001B0B70: D71C003D
	v_cndmask_b32_e32 v1, v61, v76, vcc_lo                     // 0000001B0B74: 0202993D
	v_exp_f32_e32 v76, v80                                     // 0000001B0B78: 7E984B50
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B0B7C: BF870193
	v_fma_f32 v70, -v70, v75, v73                              // 0000001B0B80: D6130046 25269746
	v_fma_f32 v71, -v57, v84, v81                              // 0000001B0B88: D6130047 2546A939
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B0B90: BF870223
	v_cndmask_b32_e64 v61, 0, v61, s1                          // 0000001B0B94: D501003D 00067A80
	.long 0xd41b0001                                           // 0000001B0B9C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v60, vcc_lo              // 0000001B0BA0: 020278FF C2B17218
	v_div_fmas_f32 v56, v70, v56, v75                          // 0000001B0BA8: D6370038 052E7146
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v79                  // 0000001B0BB0: 7C3C9EFF 42CE8ED0
	v_fmac_f32_e32 v84, v71, v74                               // 0000001B0BB8: 56A89547
	v_cvt_i32_f32_e32 v71, v83                                 // 0000001B0BBC: 7E8E1153
	v_cndmask_b32_e64 v60, 0x7f800000, v61, s1                 // 0000001B0BC0: D501003C 00067AFF 7F800000
	v_div_fixup_f32 v40, v56, v58, v40                         // 0000001B0BCC: D6270028 04A27538
	.long 0x7f7439c8                                           // 0000001B0BD4: 7F7439C8
	v_fma_f32 v57, -v57, v84, v81                              // 0000001B0BD8: D6130039 2546A939
	.long 0xd71c003d                                           // 0000001B0BE0: D71C003D
	v_cndmask_b32_e32 v1, v76, v71, vcc_lo                     // 0000001B0BE4: 02028F4C
	v_add_f32_e32 v60, 1.0, v60                                // 0000001B0BE8: 067878F2
	s_waitcnt vmcnt(11)                                        // 0000001B0BEC: BF892FF7
	v_lshlrev_b32_e32 v76, 16, v139                            // 0000001B0BF0: 30991690
	.long 0x7e7439a8                                           // 0000001B0BF4: 7E7439A8
	v_cndmask_b32_e32 v61, 0, v61, vcc_lo                      // 0000001B0BF8: 027A7A80
	s_mov_b32 vcc_lo, s0                                       // 0000001B0BFC: BEEA0000
	v_div_scale_f32 v70, null, v60, v60, v42                   // 0000001B0C00: D6FC7C46 04AA793C
	v_div_fmas_f32 v57, v57, v74, v84                          // 0000001B0C08: D6370039 05529539
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v79                  // 0000001B0C10: 7C369EFF C2B17218
	v_dual_mul_f32 v77, 0xbfb8aa3b, v76 :: v_dual_and_b32 v58, 1, v58// 0000001B0C18: C8E498FF 4D3A7481 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B0C24: BF870194
	v_rcp_f32_e32 v52, v70                                     // 0000001B0C28: 7E685546
	v_div_fixup_f32 v41, v57, v59, v41                         // 0000001B0C2C: D6270029 04A67739
	v_cndmask_b32_e32 v61, 0x7f800000, v61, vcc_lo             // 0000001B0C34: 027A7AFF 7F800000
	v_lshlrev_b32_e32 v59, 16, v140                            // 0000001B0C3C: 30771890
	v_fma_f32 v80, 0xbfb8aa3b, v76, -v77                       // 0000001B0C40: D6130050 853698FF BFB8AA3B
	v_rndne_f32_e32 v81, v77                                   // 0000001B0C4C: 7EA2474D
	.long 0x7e9039a9                                           // 0000001B0C50: 7E9039A9
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B0C54: BF870214
	v_dual_add_f32 v57, 1.0, v61 :: v_dual_mul_f32 v56, 0xbfb8aa3b, v59// 0000001B0C58: C9067AF2 393876FF BFB8AA3B
	v_fmac_f32_e32 v80, 0xb2a5705f, v76                        // 0000001B0C64: 56A098FF B2A5705F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B0C6C: BF870215
	v_fma_f32 v61, -v70, v52, 1.0                              // 0000001B0C70: D613003D 23CA6946
	v_and_b32_e32 v75, 1, v72                                  // 0000001B0C78: 36969081
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B0C7C: BF870004
	v_div_scale_f32 v53, null, v57, v57, v43                   // 0000001B0C80: D6FC7C35 04AE7339
	v_fma_f32 v73, 0xbfb8aa3b, v59, -v56                       // 0000001B0C88: D6130049 84E276FF BFB8AA3B
	v_rndne_f32_e32 v74, v56                                   // 0000001B0C94: 7E944738
	v_fmac_f32_e32 v52, v61, v52                               // 0000001B0C98: 5668693D
	v_div_scale_f32 v61, vcc_lo, v42, v60, v42                 // 0000001B0C9C: D6FC6A3D 04AA792A
	v_rcp_f32_e32 v71, v53                                     // 0000001B0CA4: 7E8E5535
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B0CA8: BF870003
	v_dual_fmac_f32 v73, 0xb2a5705f, v59 :: v_dual_sub_f32 v56, v56, v74// 0000001B0CAC: C80A76FF 49389538 B2A5705F
	v_sub_f32_e32 v77, v77, v81                                // 0000001B0CB8: 089AA34D
	v_add3_u32 v41, v41, v75, 0x7fff                           // 0000001B0CBC: D6550029 03FE9729 00007FFF
	v_cvt_i32_f32_e32 v74, v74                                 // 0000001B0CC8: 7E94114A
	v_add3_u32 v40, v40, v58, 0x7fff                           // 0000001B0CCC: D6550028 03FE7528 00007FFF
	v_dual_add_f32 v56, v56, v73 :: v_dual_mul_f32 v73, v61, v52// 0000001B0CD8: C9069338 3848693D
	v_add_f32_e32 v77, v77, v80                                // 0000001B0CE0: 069AA14D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B0CE4: BF870225
	v_fma_f32 v79, -v53, v71, 1.0                              // 0000001B0CE8: D613004F 23CA8F35
	.long 0xd41e0001                                           // 0000001B0CF0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v59, vcc_lo              // 0000001B0CF4: 020276FF 42CE8ED0
	v_exp_f32_e32 v56, v56                                     // 0000001B0CFC: 7E704B38
	v_fma_f32 v75, -v70, v73, v61                              // 0000001B0D00: D613004B 24F69346
	global_store_d16_hi_b16 v[6:7], v40, off offset:64         // 0000001B0D08: DC960040 007C2806
	v_fmac_f32_e32 v71, v79, v71                               // 0000001B0D10: 568E8F4F
	v_div_scale_f32 v79, s0, v43, v57, v43                     // 0000001B0D14: D6FC004F 04AE732B
	global_store_d16_hi_b16 v[46:47], v41, off offset:64       // 0000001B0D1C: DC960040 007C292E
	v_fmac_f32_e32 v73, v75, v52                               // 0000001B0D24: 5692694B
	v_mul_f32_e32 v82, v79, v71                                // 0000001B0D28: 10A48F4F
	.long 0xd71c0038                                           // 0000001B0D2C: D71C0038
	v_cndmask_b32_e32 v1, v56, v74, vcc_lo                     // 0000001B0D30: 02029538
	v_exp_f32_e32 v74, v77                                     // 0000001B0D34: 7E944B4D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B0D38: BF870193
	v_fma_f32 v61, -v70, v73, v61                              // 0000001B0D3C: D613003D 24F69346
	v_fma_f32 v58, -v53, v82, v79                              // 0000001B0D44: D613003A 253EA535
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B0D4C: BF870223
	v_cndmask_b32_e64 v56, 0, v56, s1                          // 0000001B0D50: D5010038 00067080
	.long 0xd41b0001                                           // 0000001B0D58: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v59, vcc_lo              // 0000001B0D5C: 020276FF C2B17218
	v_div_fmas_f32 v52, v61, v52, v73                          // 0000001B0D64: D6370034 0526693D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v76                  // 0000001B0D6C: 7C3C98FF 42CE8ED0
	v_fmac_f32_e32 v82, v58, v71                               // 0000001B0D74: 56A48F3A
	v_cvt_i32_f32_e32 v58, v81                                 // 0000001B0D78: 7E741151
	v_cndmask_b32_e64 v56, 0x7f800000, v56, s1                 // 0000001B0D7C: D5010038 000670FF 7F800000
	v_div_fixup_f32 v42, v52, v60, v42                         // 0000001B0D88: D627002A 04AA7934
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B0D90: BF870214
	v_fma_f32 v53, -v53, v82, v79                              // 0000001B0D94: D6130035 253EA535
	.long 0xd71c003a                                           // 0000001B0D9C: D71C003A
	v_cndmask_b32_e32 v1, v74, v58, vcc_lo                     // 0000001B0DA0: 0202754A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B0DA4: BF8701B4
	v_add_f32_e32 v56, 1.0, v56                                // 0000001B0DA8: 067070F2
	s_waitcnt vmcnt(5)                                         // 0000001B0DAC: BF8917F7
	v_lshlrev_b32_e32 v74, 16, v141                            // 0000001B0DB0: 30951A90
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000001B0DB4: 02747480
	s_mov_b32 vcc_lo, s0                                       // 0000001B0DB8: BEEA0000
	v_div_scale_f32 v59, null, v56, v56, v44                   // 0000001B0DBC: D6FC7C3B 04B27138
	v_div_fmas_f32 v53, v53, v71, v82                          // 0000001B0DC4: D6370035 054A8F35
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v76                  // 0000001B0DCC: 7C3698FF C2B17218
	v_mul_f32_e32 v75, 0xbfb8aa3b, v74                         // 0000001B0DD4: 109694FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B0DDC: BF870003
	v_div_fixup_f32 v40, v53, v57, v43                         // 0000001B0DE0: D6270028 04AE7335
	v_cndmask_b32_e32 v58, 0x7f800000, v58, vcc_lo             // 0000001B0DE8: 027474FF 7F800000
	v_mul_f32_e32 v43, v45, v50                                // 0000001B0DF0: 1056652D
	v_lshlrev_b32_e32 v57, 16, v78                             // 0000001B0DF4: 30729C90
	v_rcp_f32_e32 v45, v59                                     // 0000001B0DF8: 7E5A553B
	.long 0x7e9039a8                                           // 0000001B0DFC: 7E9039A8
	v_add_f32_e32 v53, 1.0, v58                                // 0000001B0E00: 066A74F2
	v_fma_f32 v77, 0xbfb8aa3b, v74, -v75                       // 0000001B0E04: D613004D 852E94FF BFB8AA3B
	v_mul_f32_e32 v52, 0xbfb8aa3b, v57                         // 0000001B0E10: 106872FF BFB8AA3B
	v_rndne_f32_e32 v78, v75                                   // 0000001B0E18: 7E9C474B
	.long 0x7e7439aa                                           // 0000001B0E1C: 7E7439AA
	v_div_scale_f32 v41, null, v53, v53, v43                   // 0000001B0E20: D6FC7C29 04AE6B35
	.long 0x7f7439c8                                           // 0000001B0E28: 7F7439C8
	v_fma_f32 v70, 0xbfb8aa3b, v57, -v52                       // 0000001B0E2C: D6130046 84D272FF BFB8AA3B
	v_rndne_f32_e32 v71, v52                                   // 0000001B0E38: 7E8E4734
	v_fma_f32 v60, -v59, v45, 1.0                              // 0000001B0E3C: D613003C 23CA5B3B
	v_rcp_f32_e32 v61, v41                                     // 0000001B0E44: 7E7A5529
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B0E48: BF870193
	v_dual_fmac_f32 v70, 0xb2a5705f, v57 :: v_dual_and_b32 v73, 1, v72// 0000001B0E4C: C82472FF 46489081 B2A5705F
	v_sub_f32_e32 v52, v52, v71                                // 0000001B0E58: 08688F34
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B0E5C: BF870003
	v_fmac_f32_e32 v45, v60, v45                               // 0000001B0E60: 565A5B3C
	v_div_scale_f32 v60, vcc_lo, v44, v56, v44                 // 0000001B0E64: D6FC6A3C 04B2712C
	v_fmac_f32_e32 v77, 0xb2a5705f, v74                        // 0000001B0E6C: 569A94FF B2A5705F
	v_sub_f32_e32 v75, v75, v78                                // 0000001B0E74: 08969D4B
	v_add_f32_e32 v52, v52, v70                                // 0000001B0E78: 06688D34
	v_and_b32_e32 v58, 1, v58                                  // 0000001B0E7C: 36747481
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001B0E80: BF870005
	v_fma_f32 v76, -v41, v61, 1.0                              // 0000001B0E84: D613004C 23CA7B29
	v_mul_f32_e32 v70, v60, v45                                // 0000001B0E8C: 108C5B3C
	v_add3_u32 v40, v40, v73, 0x7fff                           // 0000001B0E90: D6550028 03FE9328 00007FFF
	v_exp_f32_e32 v52, v52                                     // 0000001B0E9C: 7E684B34
	v_cvt_i32_f32_e32 v71, v71                                 // 0000001B0EA0: 7E8E1147
	v_fmac_f32_e32 v61, v76, v61                               // 0000001B0EA4: 567A7B4C
	v_div_scale_f32 v76, s0, v43, v53, v43                     // 0000001B0EA8: D6FC004C 04AE6B2B
	v_fma_f32 v73, -v59, v70, v60                              // 0000001B0EB0: D6130049 24F28D3B
	v_add_f32_e32 v75, v75, v77                                // 0000001B0EB8: 06969B4B
	v_add3_u32 v42, v42, v58, 0x7fff                           // 0000001B0EBC: D655002A 03FE752A 00007FFF
	.long 0xd41e0001                                           // 0000001B0EC8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v57, vcc_lo              // 0000001B0ECC: 020272FF 42CE8ED0
	v_mul_f32_e32 v79, v76, v61                                // 0000001B0ED4: 109E7B4C
	v_fmac_f32_e32 v70, v73, v45                               // 0000001B0ED8: 568C5B49
	.long 0xd71c0034                                           // 0000001B0EDC: D71C0034
	v_cndmask_b32_e32 v1, v52, v71, vcc_lo                     // 0000001B0EE0: 02028F34
	v_exp_f32_e32 v71, v75                                     // 0000001B0EE4: 7E8E4B4B
	global_store_d16_hi_b16 v[14:15], v42, off offset:64       // 0000001B0EE8: DC960040 007C2A0E
	v_fma_f32 v58, -v41, v79, v76                              // 0000001B0EF0: D613003A 25329F29
	v_fma_f32 v59, -v59, v70, v60                              // 0000001B0EF8: D613003B 24F28D3B
	v_cndmask_b32_e64 v52, 0, v52, s1                          // 0000001B0F00: D5010034 00066880
	.long 0xd41b0001                                           // 0000001B0F08: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v57, vcc_lo              // 0000001B0F0C: 020272FF C2B17218
	global_store_d16_hi_b16 v[22:23], v40, off offset:64       // 0000001B0F14: DC960040 007C2816
	v_fmac_f32_e32 v79, v58, v61                               // 0000001B0F1C: 569E7B3A
	v_cvt_i32_f32_e32 v58, v78                                 // 0000001B0F20: 7E74114E
	v_div_fmas_f32 v45, v59, v45, v70                          // 0000001B0F24: D637002D 051A5B3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v74                  // 0000001B0F2C: 7C3C94FF 42CE8ED0
	v_cndmask_b32_e64 v52, 0x7f800000, v52, s1                 // 0000001B0F34: D5010034 000668FF 7F800000
	v_fma_f32 v41, -v41, v79, v76                              // 0000001B0F40: D6130029 25329F29
	.long 0xd71c0039                                           // 0000001B0F48: D71C0039
	v_cndmask_b32_e32 v1, v71, v58, vcc_lo                     // 0000001B0F4C: 02027547
	v_div_fixup_f32 v44, v45, v56, v44                         // 0000001B0F50: D627002C 04B2712D
	v_lshlrev_b32_e32 v71, 16, v132                            // 0000001B0F58: 308F0890
	v_add_f32_e32 v52, 1.0, v52                                // 0000001B0F5C: 066868F2
	.long 0x7f7039c8                                           // 0000001B0F60: 7F7039C8
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000001B0F64: 02727280
	s_mov_b32 vcc_lo, s0                                       // 0000001B0F68: BEEA0000
	v_mul_f32_e32 v73, 0xbfb8aa3b, v71                         // 0000001B0F6C: 10928EFF BFB8AA3B
	v_div_fmas_f32 v41, v41, v61, v79                          // 0000001B0F74: D6370029 053E7B29
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v74                  // 0000001B0F7C: 7C3694FF C2B17218
	v_div_scale_f32 v58, null, v52, v52, v32                   // 0000001B0F84: D6FC7C3A 04826934
	.long 0x7e7039ac                                           // 0000001B0F8C: 7E7039AC
	v_fma_f32 v75, 0xbfb8aa3b, v71, -v73                       // 0000001B0F90: D613004B 85268EFF BFB8AA3B
	v_div_fixup_f32 v41, v41, v53, v43                         // 0000001B0F9C: D6270029 04AE6B29
	v_cndmask_b32_e32 v57, 0x7f800000, v57, vcc_lo             // 0000001B0FA4: 027272FF 7F800000
	v_lshlrev_b32_e32 v53, 16, v133                            // 0000001B0FAC: 306B0A90
	v_rcp_f32_e32 v42, v58                                     // 0000001B0FB0: 7E54553A
	v_rndne_f32_e32 v76, v73                                   // 0000001B0FB4: 7E984749
	.long 0x7e9039a9                                           // 0000001B0FB8: 7E9039A9
	v_add_f32_e32 v43, 1.0, v57                                // 0000001B0FBC: 065672F2
	v_mul_f32_e32 v45, 0xbfb8aa3b, v53                         // 0000001B0FC0: 105A6AFF BFB8AA3B
	v_fmac_f32_e32 v75, 0xb2a5705f, v71                        // 0000001B0FC8: 56968EFF B2A5705F
	v_sub_f32_e32 v73, v73, v76                                // 0000001B0FD0: 08929949
	v_and_b32_e32 v70, 1, v72                                  // 0000001B0FD4: 368C9081
	v_div_scale_f32 v40, null, v43, v43, v33                   // 0000001B0FD8: D6FC7C28 0486572B
	v_fma_f32 v60, 0xbfb8aa3b, v53, -v45                       // 0000001B0FE0: D613003C 84B66AFF BFB8AA3B
	v_rndne_f32_e32 v61, v45                                   // 0000001B0FEC: 7E7A472D
	v_fma_f32 v57, -v58, v42, 1.0                              // 0000001B0FF0: D6130039 23CA553A
	v_and_b32_e32 v56, 1, v56                                  // 0000001B0FF8: 36707081
	v_rcp_f32_e32 v59, v40                                     // 0000001B0FFC: 7E765528
	v_fmac_f32_e32 v60, 0xb2a5705f, v53                        // 0000001B1000: 56786AFF B2A5705F
	v_sub_f32_e32 v45, v45, v61                                // 0000001B1008: 085A7B2D
	v_fmac_f32_e32 v42, v57, v42                               // 0000001B100C: 56545539
	v_div_scale_f32 v57, vcc_lo, v32, v52, v32                 // 0000001B1010: D6FC6A39 04826920
	v_add3_u32 v41, v41, v70, 0x7fff                           // 0000001B1018: D6550029 03FE8D29 00007FFF
	v_cvt_i32_f32_e32 v61, v61                                 // 0000001B1024: 7E7A113D
	v_add_f32_e32 v45, v45, v60                                // 0000001B1028: 065A792D
	v_add_f32_e32 v73, v73, v75                                // 0000001B102C: 06929749
	v_mul_f32_e32 v60, v57, v42                                // 0000001B1030: 10785539
	v_fma_f32 v74, -v40, v59, 1.0                              // 0000001B1034: D613004A 23CA7728
	v_add3_u32 v44, v44, v56, 0x7fff                           // 0000001B103C: D655002C 03FE712C 00007FFF
	v_exp_f32_e32 v45, v45                                     // 0000001B1048: 7E5A4B2D
	.long 0xd41e0001                                           // 0000001B104C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v53, vcc_lo              // 0000001B1050: 02026AFF 42CE8ED0
	v_fma_f32 v70, -v58, v60, v57                              // 0000001B1058: D6130046 24E6793A
	v_fmac_f32_e32 v59, v74, v59                               // 0000001B1060: 5676774A
	v_div_scale_f32 v74, s0, v33, v43, v33                     // 0000001B1064: D6FC004A 04865721
	global_store_d16_hi_b16 v[30:31], v44, off offset:64       // 0000001B106C: DC960040 007C2C1E
	v_lshlrev_b32_e32 v44, 16, v135                            // 0000001B1074: 30590E90
	v_fmac_f32_e32 v60, v70, v42                               // 0000001B1078: 56785546
	global_store_d16_hi_b16 v[38:39], v41, off offset:64       // 0000001B107C: DC960040 007C2926
	v_mul_f32_e32 v77, v74, v59                                // 0000001B1084: 109A774A
	.long 0xd71c002d                                           // 0000001B1088: D71C002D
	v_cndmask_b32_e32 v1, v45, v61, vcc_lo                     // 0000001B108C: 02027B2D
	v_exp_f32_e32 v61, v73                                     // 0000001B1090: 7E7A4B49
	v_fma_f32 v57, -v58, v60, v57                              // 0000001B1094: D6130039 24E6793A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B109C: BF870193
	v_fma_f32 v56, -v40, v77, v74                              // 0000001B10A0: D6130038 252A9B28
	v_cndmask_b32_e64 v45, 0, v45, s1                          // 0000001B10A8: D501002D 00065A80
	.long 0xd41b0001                                           // 0000001B10B0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v53, vcc_lo              // 0000001B10B4: 02026AFF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B10BC: BF870004
	v_div_fmas_f32 v42, v57, v42, v60                          // 0000001B10C0: D637002A 04F25539
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v71                  // 0000001B10C8: 7C3C8EFF 42CE8ED0
	v_fmac_f32_e32 v77, v56, v59                               // 0000001B10D0: 569A7738
	v_cvt_i32_f32_e32 v56, v76                                 // 0000001B10D4: 7E70114C
	v_cndmask_b32_e64 v45, 0x7f800000, v45, s1                 // 0000001B10D8: D501002D 00065AFF 7F800000
	v_div_fixup_f32 v32, v42, v52, v32                         // 0000001B10E4: D6270020 0482692A
	v_mul_f32_e32 v42, 0xbfb8aa3b, v44                         // 0000001B10EC: 105458FF BFB8AA3B
	v_fma_f32 v40, -v40, v77, v74                              // 0000001B10F4: D6130028 252A9B28
	.long 0xd71c0035                                           // 0000001B10FC: D71C0035
	v_cndmask_b32_e32 v1, v61, v56, vcc_lo                     // 0000001B1100: 0202713D
	v_add_f32_e32 v45, 1.0, v45                                // 0000001B1104: 065A5AF2
	v_lshlrev_b32_e32 v61, 16, v134                            // 0000001B1108: 307B0C90
	v_fma_f32 v58, 0xbfb8aa3b, v44, -v42                       // 0000001B110C: D613003A 84AA58FF BFB8AA3B
	.long 0x7e6839a0                                           // 0000001B1118: 7E6839A0
	v_cndmask_b32_e32 v53, 0, v53, vcc_lo                      // 0000001B111C: 026A6A80
	s_mov_b32 vcc_lo, s0                                       // 0000001B1120: BEEA0000
	v_div_scale_f32 v56, null, v45, v45, v34                   // 0000001B1124: D6FC7C38 048A5B2D
	v_div_fmas_f32 v40, v40, v59, v77                          // 0000001B112C: D6370028 05367728
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v71                  // 0000001B1134: 7C368EFF C2B17218
	v_rndne_f32_e32 v59, v42                                   // 0000001B113C: 7E76472A
	v_fmac_f32_e32 v58, 0xb2a5705f, v44                        // 0000001B1140: 567458FF B2A5705F
	v_mul_f32_e32 v70, 0xbfb8aa3b, v61                         // 0000001B1148: 108C7AFF BFB8AA3B
	v_div_fixup_f32 v33, v40, v43, v33                         // 0000001B1150: D6270021 04865728
	v_cndmask_b32_e32 v53, 0x7f800000, v53, vcc_lo             // 0000001B1158: 026A6AFF 7F800000
	v_rcp_f32_e32 v40, v56                                     // 0000001B1160: 7E505538
	v_sub_f32_e32 v42, v42, v59                                // 0000001B1164: 0854772A
	v_fma_f32 v73, 0xbfb8aa3b, v61, -v70                       // 0000001B1168: D6130049 851A7AFF BFB8AA3B
	.long 0x7e9039a1                                           // 0000001B1174: 7E9039A1
	v_add_f32_e32 v43, 1.0, v53                                // 0000001B1178: 06566AF2
	v_rndne_f32_e32 v74, v70                                   // 0000001B117C: 7E944746
	v_add_f32_e32 v42, v42, v58                                // 0000001B1180: 0654752A
	.long 0x7f6839c8                                           // 0000001B1184: 7F6839C8
	v_and_b32_e32 v60, 1, v72                                  // 0000001B1188: 36789081
	v_div_scale_f32 v41, null, v43, v43, v35                   // 0000001B118C: D6FC7C29 048E572B
	v_fma_f32 v53, -v56, v40, 1.0                              // 0000001B1194: D6130035 23CA5138
	v_exp_f32_e32 v42, v42                                     // 0000001B119C: 7E544B2A
	v_dual_fmac_f32 v73, 0xb2a5705f, v61 :: v_dual_sub_f32 v70, v70, v74// 0000001B11A0: C80A7AFF 49469546 B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B11AC: BF870113
	v_rcp_f32_e32 v57, v41                                     // 0000001B11B0: 7E725529
	v_fmac_f32_e32 v40, v53, v40                               // 0000001B11B4: 56505135
	v_div_scale_f32 v53, vcc_lo, v34, v45, v34                 // 0000001B11B8: D6FC6A35 048A5B22
	v_and_b32_e32 v52, 1, v52                                  // 0000001B11C0: 36686881
	v_add3_u32 v33, v33, v60, 0x7fff                           // 0000001B11C4: D6550021 03FE7921 00007FFF
	v_cvt_i32_f32_e32 v59, v59                                 // 0000001B11D0: 7E76113B
	v_add_f32_e32 v70, v70, v73                                // 0000001B11D4: 068C9346
	v_mul_f32_e32 v58, v53, v40                                // 0000001B11D8: 10745135
	v_add3_u32 v32, v32, v52, 0x7fff                           // 0000001B11DC: D6550020 03FE6920 00007FFF
	.long 0xd41e0001                                           // 0000001B11E8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v44, vcc_lo              // 0000001B11EC: 020258FF 42CE8ED0
	v_fma_f32 v71, -v41, v57, 1.0                              // 0000001B11F4: D6130047 23CA7329
	.long 0xd71c002a                                           // 0000001B11FC: D71C002A
	v_cndmask_b32_e32 v1, v42, v59, vcc_lo                     // 0000001B1200: 0202772A
	v_fma_f32 v60, -v56, v58, v53                              // 0000001B1204: D613003C 24D67538
	v_exp_f32_e32 v59, v70                                     // 0000001B120C: 7E764B46
	global_store_d16_hi_b16 v[6:7], v32, off offset:96         // 0000001B1210: DC960060 007C2006
	v_fmac_f32_e32 v57, v71, v57                               // 0000001B1218: 56727347
	v_div_scale_f32 v71, s0, v35, v43, v35                     // 0000001B121C: D6FC0047 048E5723
	v_fmac_f32_e32 v58, v60, v40                               // 0000001B1224: 5674513C
	v_cndmask_b32_e64 v42, 0, v42, s1                          // 0000001B1228: D501002A 00065480
	.long 0xd41b0001                                           // 0000001B1230: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v44, vcc_lo              // 0000001B1234: 020258FF C2B17218
	global_store_d16_hi_b16 v[46:47], v33, off offset:96       // 0000001B123C: DC960060 007C212E
	v_mul_f32_e32 v75, v71, v57                                // 0000001B1244: 10967347
	v_fma_f32 v53, -v56, v58, v53                              // 0000001B1248: D6130035 24D67538
	v_cndmask_b32_e64 v42, 0x7f800000, v42, s1                 // 0000001B1250: D501002A 000654FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B125C: BF870193
	v_fma_f32 v52, -v41, v75, v71                              // 0000001B1260: D6130034 251E9729
	v_div_fmas_f32 v40, v53, v40, v58                          // 0000001B1268: D6370028 04EA5135
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v61                  // 0000001B1270: 7C3C7AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B1278: BF870223
	v_dual_add_f32 v42, 1.0, v42 :: v_dual_fmac_f32 v75, v52, v57// 0000001B127C: C90054F2 2A4A7334
	v_cvt_i32_f32_e32 v52, v74                                 // 0000001B1284: 7E68114A
	v_div_fixup_f32 v34, v40, v45, v34                         // 0000001B1288: D6270022 048A5B28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B1290: BF870193
	v_fma_f32 v41, -v41, v75, v71                              // 0000001B1294: D6130029 251E9729
	.long 0xd71c002c                                           // 0000001B129C: D71C002C
	v_cndmask_b32_e32 v1, v59, v52, vcc_lo                     // 0000001B12A0: 0202693B
	v_div_scale_f32 v52, null, v42, v42, v36                   // 0000001B12A4: D6FC7C34 0492552A
	s_waitcnt vmcnt(4)                                         // 0000001B12AC: BF8913F7
	v_lshlrev_b32_e32 v59, 16, v136                            // 0000001B12B0: 30771090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B12B4: BF870123
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo                      // 0000001B12B8: 02585880
	s_mov_b32 vcc_lo, s0                                       // 0000001B12BC: BEEA0000
	v_mul_f32_e32 v60, 0xbfb8aa3b, v59                         // 0000001B12C0: 107876FF BFB8AA3B
	v_div_fmas_f32 v41, v41, v57, v75                          // 0000001B12C8: D6370029 052E7329
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v61                  // 0000001B12D0: 7C367AFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B12D8: BF870193
	v_fma_f32 v70, 0xbfb8aa3b, v59, -v60                       // 0000001B12DC: D6130046 84F276FF BFB8AA3B
	v_div_fixup_f32 v32, v41, v43, v35                         // 0000001B12E8: D6270020 048E5729
	v_dual_cndmask_b32 v44, 0x7f800000, v44 :: v_dual_mul_f32 v35, v37, v50// 0000001B12F0: CA4658FF 2C226525 7F800000
	v_lshlrev_b32_e32 v43, 16, v85                             // 0000001B12FC: 3056AA90
	v_rcp_f32_e32 v37, v52                                     // 0000001B1300: 7E4A5534
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B1304: BF870193
	.long 0x7e9039a0                                           // 0000001B1308: 7E9039A0
	v_add_f32_e32 v41, 1.0, v44                                // 0000001B130C: 065258F2
	v_rndne_f32_e32 v71, v60                                   // 0000001B1310: 7E8E473C
	v_mul_f32_e32 v40, 0xbfb8aa3b, v43                         // 0000001B1314: 105056FF BFB8AA3B
	.long 0x7e5839a2                                           // 0000001B131C: 7E5839A2
	.long 0x7f5839c8                                           // 0000001B1320: 7F5839C8
	v_div_scale_f32 v33, null, v41, v41, v35                   // 0000001B1324: D6FC7C21 048E5329
	v_and_b32_e32 v58, 1, v72                                  // 0000001B132C: 36749081
	v_fma_f32 v56, 0xbfb8aa3b, v43, -v40                       // 0000001B1330: D6130038 84A256FF BFB8AA3B
	v_rndne_f32_e32 v57, v40                                   // 0000001B133C: 7E724728
	v_fma_f32 v45, -v52, v37, 1.0                              // 0000001B1340: D613002D 23CA4B34
	v_rcp_f32_e32 v53, v33                                     // 0000001B1348: 7E6A5521
	v_fmac_f32_e32 v70, 0xb2a5705f, v59                        // 0000001B134C: 568C76FF B2A5705F
	v_fmac_f32_e32 v56, 0xb2a5705f, v43                        // 0000001B1354: 567056FF B2A5705F
	v_sub_f32_e32 v40, v40, v57                                // 0000001B135C: 08507328
	v_fmac_f32_e32 v37, v45, v37                               // 0000001B1360: 564A4B2D
	v_div_scale_f32 v45, vcc_lo, v36, v42, v36                 // 0000001B1364: D6FC6A2D 04925524
	v_sub_f32_e32 v60, v60, v71                                // 0000001B136C: 08788F3C
	v_and_b32_e32 v44, 1, v44                                  // 0000001B1370: 36585881
	v_add_f32_e32 v40, v40, v56                                // 0000001B1374: 06507128
	v_add3_u32 v32, v32, v58, 0x7fff                           // 0000001B1378: D6550020 03FE7520 00007FFF
	v_fma_f32 v61, -v33, v53, 1.0                              // 0000001B1384: D613003D 23CA6B21
	v_mul_f32_e32 v56, v45, v37                                // 0000001B138C: 10704B2D
	v_cvt_i32_f32_e32 v57, v57                                 // 0000001B1390: 7E721139
	v_exp_f32_e32 v40, v40                                     // 0000001B1394: 7E504B28
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001B1398: BF870253
	v_dual_add_f32 v60, v60, v70 :: v_dual_fmac_f32 v53, v61, v53// 0000001B139C: C9008D3C 3C346B3D
	v_div_scale_f32 v61, s0, v35, v41, v35                     // 0000001B13A4: D6FC003D 048E5323
	v_fma_f32 v58, -v52, v56, v45                              // 0000001B13AC: D613003A 24B67134
	v_add3_u32 v34, v34, v44, 0x7fff                           // 0000001B13B4: D6550022 03FE5922 00007FFF
	.long 0xd41e0001                                           // 0000001B13C0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v43, vcc_lo              // 0000001B13C4: 020256FF 42CE8ED0
	v_mul_f32_e32 v73, v61, v53                                // 0000001B13CC: 10926B3D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B13D0: BF870294
	v_fmac_f32_e32 v56, v58, v37                               // 0000001B13D4: 56704B3A
	.long 0xd71c0028                                           // 0000001B13D8: D71C0028
	v_cndmask_b32_e32 v1, v40, v57, vcc_lo                     // 0000001B13DC: 02027328
	v_exp_f32_e32 v57, v60                                     // 0000001B13E0: 7E724B3C
	global_store_d16_hi_b16 v[14:15], v34, off offset:96       // 0000001B13E4: DC960060 007C220E
	v_fma_f32 v44, -v33, v73, v61                              // 0000001B13EC: D613002C 24F69321
	v_fma_f32 v45, -v52, v56, v45                              // 0000001B13F4: D613002D 24B67134
	v_cndmask_b32_e64 v40, 0, v40, s1                          // 0000001B13FC: D5010028 00065080
	.long 0xd41b0001                                           // 0000001B1404: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v43, vcc_lo              // 0000001B1408: 020256FF C2B17218
	global_store_d16_hi_b16 v[22:23], v32, off offset:96       // 0000001B1410: DC960060 007C2016
	v_fmac_f32_e32 v73, v44, v53                               // 0000001B1418: 56926B2C
	v_cvt_i32_f32_e32 v44, v71                                 // 0000001B141C: 7E581147
	v_div_fmas_f32 v37, v45, v37, v56                          // 0000001B1420: D6370025 04E24B2D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v59                  // 0000001B1428: 7C3C76FF 42CE8ED0
	v_cndmask_b32_e64 v40, 0x7f800000, v40, s1                 // 0000001B1430: D5010028 000650FF 7F800000
	v_fma_f32 v33, -v33, v73, v61                              // 0000001B143C: D6130021 24F69321
	.long 0xd71c002b                                           // 0000001B1444: D71C002B
	v_cndmask_b32_e32 v1, v57, v44, vcc_lo                     // 0000001B1448: 02025939
	v_lshlrev_b32_e32 v57, 16, v127                            // 0000001B144C: 3072FE90
	v_div_fixup_f32 v36, v37, v42, v36                         // 0000001B1450: D6270024 04925525
	v_add_f32_e32 v40, 1.0, v40                                // 0000001B1458: 065050F2
	.long 0x7f5439c8                                           // 0000001B145C: 7F5439C8
	v_cndmask_b32_e32 v43, 0, v43, vcc_lo                      // 0000001B1460: 02565680
	s_mov_b32 vcc_lo, s0                                       // 0000001B1464: BEEA0000
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000001B1468: 107472FF BFB8AA3B
	v_div_fmas_f32 v33, v33, v53, v73                          // 0000001B1470: D6370021 05266B21
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v59                  // 0000001B1478: 7C3676FF C2B17218
	v_div_scale_f32 v44, null, v40, v40, v24                   // 0000001B1480: D6FC7C2C 04625128
	.long 0x7e5439a4                                           // 0000001B1488: 7E5439A4
	v_rndne_f32_e32 v61, v58                                   // 0000001B148C: 7E7A473A
	v_fma_f32 v60, 0xbfb8aa3b, v57, -v58                       // 0000001B1490: D613003C 84EA72FF BFB8AA3B
	v_cndmask_b32_e32 v43, 0x7f800000, v43, vcc_lo             // 0000001B149C: 025656FF 7F800000
	v_rcp_f32_e32 v34, v44                                     // 0000001B14A4: 7E44552C
	v_and_b32_e32 v42, 1, v42                                  // 0000001B14A8: 36545481
	v_sub_f32_e32 v58, v58, v61                                // 0000001B14AC: 08747B3A
	v_div_fixup_f32 v33, v33, v41, v35                         // 0000001B14B0: D6270021 048E5321
	v_add_f32_e32 v35, 1.0, v43                                // 0000001B14B8: 064656F2
	v_dual_fmac_f32 v60, 0xb2a5705f, v57 :: v_dual_lshlrev_b32 v41, 16, v128// 0000001B14BC: C82272FF 3C290090 B2A5705F
	v_add3_u32 v36, v36, v42, 0x7fff                           // 0000001B14C8: D6550024 03FE5524 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B14D4: BF870214
	.long 0x7e9039a1                                           // 0000001B14D8: 7E9039A1
	v_div_scale_f32 v32, null, v35, v35, v25                   // 0000001B14DC: D6FC7C20 04664723
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B14E4: BF870004
	v_mul_f32_e32 v37, 0xbfb8aa3b, v41                         // 0000001B14E8: 104A52FF BFB8AA3B
	v_fma_f32 v43, -v44, v34, 1.0                              // 0000001B14F0: D613002B 23CA452C
	v_add_f32_e32 v58, v58, v60                                // 0000001B14F8: 0674793A
	v_and_b32_e32 v56, 1, v72                                  // 0000001B14FC: 36709081
	v_rcp_f32_e32 v45, v32                                     // 0000001B1500: 7E5A5520
	v_fma_f32 v52, 0xbfb8aa3b, v41, -v37                       // 0000001B1504: D6130034 849652FF BFB8AA3B
	v_rndne_f32_e32 v53, v37                                   // 0000001B1510: 7E6A4725
	v_fmac_f32_e32 v34, v43, v34                               // 0000001B1514: 5644452B
	v_div_scale_f32 v43, vcc_lo, v24, v40, v24                 // 0000001B1518: D6FC6A2B 04625118
	v_add3_u32 v33, v33, v56, 0x7fff                           // 0000001B1520: D6550021 03FE7121 00007FFF
	v_fmac_f32_e32 v52, 0xb2a5705f, v41                        // 0000001B152C: 566852FF B2A5705F
	v_sub_f32_e32 v37, v37, v53                                // 0000001B1534: 084A6B25
	v_cvt_i32_f32_e32 v53, v53                                 // 0000001B1538: 7E6A1135
	.long 0xd41e0001                                           // 0000001B153C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v41, vcc_lo              // 0000001B1540: 020252FF 42CE8ED0
	v_fma_f32 v59, -v32, v45, 1.0                              // 0000001B1548: D613003B 23CA5B20
	global_store_d16_hi_b16 v[30:31], v36, off offset:96       // 0000001B1550: DC960060 007C241E
	v_dual_add_f32 v37, v37, v52 :: v_dual_mul_f32 v52, v43, v34// 0000001B1558: C9066925 2534452B
	v_dual_fmac_f32 v45, v59, v45 :: v_dual_lshlrev_b32 v36, 16, v130// 0000001B1560: C8225B3B 2D250490
	v_div_scale_f32 v59, s0, v25, v35, v25                     // 0000001B1568: D6FC003B 04664719
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B1570: BF870193
	v_exp_f32_e32 v37, v37                                     // 0000001B1574: 7E4A4B25
	v_fma_f32 v56, -v44, v52, v43                              // 0000001B1578: D6130038 24AE692C
	global_store_d16_hi_b16 v[38:39], v33, off offset:96       // 0000001B1580: DC960060 007C2126
	v_mul_f32_e32 v70, v59, v45                                // 0000001B1588: 108C5B3B
	v_fmac_f32_e32 v52, v56, v34                               // 0000001B158C: 56684538
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B1590: BF8701B2
	v_fma_f32 v42, -v32, v70, v59                              // 0000001B1594: D613002A 24EE8D20
	.long 0xd71c0025                                           // 0000001B159C: D71C0025
	v_cndmask_b32_e32 v1, v37, v53, vcc_lo                     // 0000001B15A0: 02026B25
	v_exp_f32_e32 v53, v58                                     // 0000001B15A4: 7E6A4B3A
	v_fma_f32 v43, -v44, v52, v43                              // 0000001B15A8: D613002B 24AE692C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001B15B0: BF870233
	v_fmac_f32_e32 v70, v42, v45                               // 0000001B15B4: 568C5B2A
	v_cvt_i32_f32_e32 v42, v61                                 // 0000001B15B8: 7E54113D
	v_cndmask_b32_e64 v37, 0, v37, s1                          // 0000001B15BC: D5010025 00064A80
	v_div_fmas_f32 v34, v43, v34, v52                          // 0000001B15C4: D6370022 04D2452B
	.long 0xd41b0001                                           // 0000001B15CC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v41, vcc_lo              // 0000001B15D0: 020252FF C2B17218
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000001B15D8: 7C3C72FF 42CE8ED0
	v_fma_f32 v32, -v32, v70, v59                              // 0000001B15E0: D6130020 24EE8D20
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001B15E8: BF870005
	.long 0xd71c0029                                           // 0000001B15EC: D71C0029
	v_cndmask_b32_e32 v1, v53, v42, vcc_lo                     // 0000001B15F0: 02025535
	v_div_fixup_f32 v24, v34, v40, v24                         // 0000001B15F4: D6270018 04625122
	v_mul_f32_e32 v34, 0xbfb8aa3b, v36                         // 0000001B15FC: 104448FF BFB8AA3B
	v_cndmask_b32_e64 v37, 0x7f800000, v37, s1                 // 0000001B1604: D5010025 00064AFF 7F800000
	.long 0xd41e0001                                           // 0000001B1610: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v36, vcc_lo              // 0000001B1614: 020248FF 42CE8ED0
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000001B161C: 02525280
	s_mov_b32 vcc_lo, s0                                       // 0000001B1620: BEEA0000
	v_fma_f32 v44, 0xbfb8aa3b, v36, -v34                       // 0000001B1624: D613002C 848A48FF BFB8AA3B
	v_div_fmas_f32 v32, v32, v45, v70                          // 0000001B1630: D6370020 051A5B20
	v_rndne_f32_e32 v45, v34                                   // 0000001B1638: 7E5A4722
	v_lshlrev_b32_e32 v53, 16, v129                            // 0000001B163C: 306B0290
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B1640: BF870224
	v_dual_add_f32 v37, 1.0, v37 :: v_dual_fmac_f32 v44, 0xb2a5705f, v36// 0000001B1644: C9004AF2 252C48FF B2A5705F
	.long 0x7e503998                                           // 0000001B1650: 7E503998
	v_sub_f32_e32 v34, v34, v45                                // 0000001B1654: 08445B22
	v_cvt_i32_f32_e32 v45, v45                                 // 0000001B1658: 7E5A112D
	v_mul_f32_e32 v56, 0xbfb8aa3b, v53                         // 0000001B165C: 10706AFF BFB8AA3B
	v_div_scale_f32 v42, null, v37, v37, v26                   // 0000001B1664: D6FC7C2A 046A4B25
	.long 0x7f5039c8                                           // 0000001B166C: 7F5039C8
	v_add_f32_e32 v34, v34, v44                                // 0000001B1670: 06445922
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B1674: BF870224
	v_fma_f32 v58, 0xbfb8aa3b, v53, -v56                       // 0000001B1678: D613003A 84E26AFF BFB8AA3B
	v_rndne_f32_e32 v59, v56                                   // 0000001B1684: 7E764738
	v_and_b32_e32 v40, 1, v40                                  // 0000001B1688: 36505081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B168C: BF870194
	v_exp_f32_e32 v34, v34                                     // 0000001B1690: 7E444B22
	v_fmac_f32_e32 v58, 0xb2a5705f, v53                        // 0000001B1694: 56746AFF B2A5705F
	v_div_fixup_f32 v25, v32, v35, v25                         // 0000001B169C: D6270019 04664720
	v_rcp_f32_e32 v32, v42                                     // 0000001B16A4: 7E40552A
	v_sub_f32_e32 v56, v56, v59                                // 0000001B16A8: 08707738
	v_add3_u32 v24, v24, v40, 0x7fff                           // 0000001B16AC: D6550018 03FE5118 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001B16B8: BF870313
	.long 0x7e903999                                           // 0000001B16BC: 7E903999
	.long 0xd71c0022                                           // 0000001B16C0: D71C0022
	v_cndmask_b32_e32 v1, v34, v45, vcc_lo                     // 0000001B16C4: 02025B22
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B16C8: BF870004
	v_add_f32_e32 v56, v56, v58                                // 0000001B16CC: 06707538
	global_store_d16_hi_b16 v[6:7], v24, off offset:128        // 0000001B16D0: DC960080 007C1806
	v_and_b32_e32 v52, 1, v72                                  // 0000001B16D8: 36689081
	v_cndmask_b32_e64 v34, 0, v34, s1                          // 0000001B16DC: D5010022 00064480
	.long 0xd41b0001                                           // 0000001B16E4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v36, vcc_lo              // 0000001B16E8: 020248FF C2B17218
	v_exp_f32_e32 v45, v56                                     // 0000001B16F0: 7E5A4B38
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B16F4: BF870113
	v_add3_u32 v25, v25, v52, 0x7fff                           // 0000001B16F8: D6550019 03FE6919 00007FFF
	v_cndmask_b32_e64 v34, 0x7f800000, v34, s1                 // 0000001B1704: D5010022 000644FF 7F800000
	global_store_d16_hi_b16 v[46:47], v25, off offset:128      // 0000001B1710: DC960080 007C192E
	v_add_f32_e32 v34, 1.0, v34                                // 0000001B1718: 064444F2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000001B171C: 7C3672FF C2B17218
	v_cndmask_b32_e32 v41, 0x7f800000, v41, vcc_lo             // 0000001B1724: 025252FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B172C: BF870121
	v_add_f32_e32 v35, 1.0, v41                                // 0000001B1730: 064652F2
	v_fma_f32 v41, -v42, v32, 1.0                              // 0000001B1734: D6130029 23CA412A
	v_div_scale_f32 v33, null, v35, v35, v27                   // 0000001B173C: D6FC7C21 046E4723
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B1744: BF8701A2
	v_fmac_f32_e32 v32, v41, v32                               // 0000001B1748: 56404129
	v_div_scale_f32 v41, vcc_lo, v26, v37, v26                 // 0000001B174C: D6FC6A29 046A4B1A
	v_rcp_f32_e32 v43, v33                                     // 0000001B1754: 7E565521
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B1758: BF870091
	v_mul_f32_e32 v44, v41, v32                                // 0000001B175C: 10584129
	v_fma_f32 v52, -v42, v44, v41                              // 0000001B1760: D6130034 24A6592A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B1768: BF870095
	v_fma_f32 v57, -v33, v43, 1.0                              // 0000001B176C: D6130039 23CA5721
	v_dual_fmac_f32 v44, v52, v32 :: v_dual_fmac_f32 v43, v57, v43// 0000001B1774: C8004134 2C2A5739
	v_div_scale_f32 v57, s0, v27, v35, v27                     // 0000001B177C: D6FC0039 046E471B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B1784: BF870112
	v_fma_f32 v41, -v42, v44, v41                              // 0000001B1788: D6130029 24A6592A
	v_mul_f32_e32 v60, v57, v43                                // 0000001B1790: 10785739
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B1794: BF8701A2
	v_div_fmas_f32 v32, v41, v32, v44                          // 0000001B1798: D6370020 04B24129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v53                  // 0000001B17A0: 7C3C6AFF 42CE8ED0
	v_fma_f32 v40, -v33, v60, v57                              // 0000001B17A8: D6130028 24E67921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B17B0: BF870121
	v_fmac_f32_e32 v60, v40, v43                               // 0000001B17B4: 56785728
	v_cvt_i32_f32_e32 v40, v59                                 // 0000001B17B8: 7E50113B
	v_fma_f32 v33, -v33, v60, v57                              // 0000001B17BC: D6130021 24E67921
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001B17C4: BF8701C2
	.long 0xd71c0024                                           // 0000001B17C8: D71C0024
	v_cndmask_b32_e32 v1, v45, v40, vcc_lo                     // 0000001B17CC: 0202512D
	s_waitcnt vmcnt(3)                                         // 0000001B17D0: BF890FF7
	v_lshlrev_b32_e32 v45, 16, v131                            // 0000001B17D4: 305B0690
	v_div_scale_f32 v40, null, v34, v34, v28                   // 0000001B17D8: D6FC7C28 04724522
	v_cndmask_b32_e32 v36, 0, v36, vcc_lo                      // 0000001B17E0: 02484880
	s_mov_b32 vcc_lo, s0                                       // 0000001B17E4: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B17E8: BF8701B3
	v_mul_f32_e32 v52, 0xbfb8aa3b, v45                         // 0000001B17EC: 10685AFF BFB8AA3B
	v_div_fmas_f32 v33, v33, v43, v60                          // 0000001B17F4: D6370021 04F25721
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v53                  // 0000001B17FC: 7C366AFF C2B17218
	v_rndne_f32_e32 v57, v52                                   // 0000001B1804: 7E724734
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001B1808: BF870253
	v_div_fixup_f32 v24, v33, v35, v27                         // 0000001B180C: D6270018 046E4721
	v_cndmask_b32_e32 v36, 0x7f800000, v36, vcc_lo             // 0000001B1814: 024848FF 7F800000
	v_div_fixup_f32 v26, v32, v37, v26                         // 0000001B181C: D627001A 046A4B20
	v_fma_f32 v56, 0xbfb8aa3b, v45, -v52                       // 0000001B1824: D6130038 84D25AFF BFB8AA3B
	v_dual_sub_f32 v52, v52, v57 :: v_dual_lshlrev_b32 v35, 16, v87// 0000001B1830: C9627334 3422AE90
	v_add_f32_e32 v33, 1.0, v36                                // 0000001B1838: 064248F2
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B183C: BF870004
	.long 0x7e48399a                                           // 0000001B1840: 7E48399A
	.long 0x7f4839c8                                           // 0000001B1844: 7F4839C8
	v_mul_f32_e32 v27, v29, v50                                // 0000001B1848: 1036651D
	v_rcp_f32_e32 v29, v40                                     // 0000001B184C: 7E3A5528
	v_fmac_f32_e32 v56, 0xb2a5705f, v45                        // 0000001B1850: 56705AFF B2A5705F
	v_mul_f32_e32 v32, 0xbfb8aa3b, v35                         // 0000001B1858: 104046FF BFB8AA3B
	.long 0x7e903998                                           // 0000001B1860: 7E903998
	v_and_b32_e32 v36, 1, v36                                  // 0000001B1864: 36484881
	.long 0xd41e0001                                           // 0000001B1868: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v35, vcc_lo              // 0000001B186C: 020246FF 42CE8ED0
	v_add_f32_e32 v52, v52, v56                                // 0000001B1874: 06687134
	v_fma_f32 v42, 0xbfb8aa3b, v35, -v32                       // 0000001B1878: D613002A 848246FF BFB8AA3B
	v_rndne_f32_e32 v43, v32                                   // 0000001B1884: 7E564720
	v_and_b32_e32 v44, 1, v72                                  // 0000001B1888: 36589081
	v_fma_f32 v37, -v40, v29, 1.0                              // 0000001B188C: D6130025 23CA3B28
	v_add3_u32 v26, v26, v36, 0x7fff                           // 0000001B1894: D655001A 03FE491A 00007FFF
	v_fmac_f32_e32 v42, 0xb2a5705f, v35                        // 0000001B18A0: 565446FF B2A5705F
	v_sub_f32_e32 v32, v32, v43                                // 0000001B18A8: 08405720
	v_add3_u32 v24, v24, v44, 0x7fff                           // 0000001B18AC: D6550018 03FE5918 00007FFF
	v_fmac_f32_e32 v29, v37, v29                               // 0000001B18B8: 563A3B25
	v_div_scale_f32 v37, vcc_lo, v28, v34, v28                 // 0000001B18BC: D6FC6A25 0472451C
	v_cvt_i32_f32_e32 v43, v43                                 // 0000001B18C4: 7E56112B
	v_add_f32_e32 v32, v32, v42                                // 0000001B18C8: 06405520
	s_clause 0x1                                               // 0000001B18CC: BF850001
	global_store_d16_hi_b16 v[14:15], v26, off offset:128      // 0000001B18D0: DC960080 007C1A0E
	global_store_d16_hi_b16 v[22:23], v24, off offset:128      // 0000001B18D8: DC960080 007C1816
	v_mul_f32_e32 v42, v37, v29                                // 0000001B18E0: 10543B25
	v_div_scale_f32 v25, null, v33, v33, v27                   // 0000001B18E4: D6FC7C19 046E4321
	v_exp_f32_e32 v32, v32                                     // 0000001B18EC: 7E404B20
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B18F0: BF870112
	v_fma_f32 v44, -v40, v42, v37                              // 0000001B18F4: D613002C 24965528
	v_rcp_f32_e32 v41, v25                                     // 0000001B18FC: 7E525519
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001B1900: BF870311
	v_fmac_f32_e32 v42, v44, v29                               // 0000001B1904: 56543B2C
	.long 0xd71c0020                                           // 0000001B1908: D71C0020
	v_cndmask_b32_e32 v1, v32, v43, vcc_lo                     // 0000001B190C: 02025720
	v_exp_f32_e32 v43, v52                                     // 0000001B1910: 7E564B34
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001B1914: BF870312
	v_fma_f32 v37, -v40, v42, v37                              // 0000001B1918: D6130025 24965528
	v_fma_f32 v53, -v25, v41, 1.0                              // 0000001B1920: D6130035 23CA5319
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B1928: BF870223
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000001B192C: D5010020 00064080
	.long 0xd41b0001                                           // 0000001B1934: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v35, vcc_lo              // 0000001B1938: 020246FF C2B17218
	v_div_fmas_f32 v29, v37, v29, v42                          // 0000001B1940: D637001D 04AA3B25
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B1948: BF870004
	v_fmac_f32_e32 v41, v53, v41                               // 0000001B194C: 56525335
	v_div_scale_f32 v53, s0, v27, v33, v27                     // 0000001B1950: D6FC0035 046E431B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v45                  // 0000001B1958: 7C3C5AFF 42CE8ED0
	v_cndmask_b32_e64 v32, 0x7f800000, v32, s1                 // 0000001B1960: D5010020 000640FF 7F800000
	v_div_fixup_f32 v28, v29, v34, v28                         // 0000001B196C: D627001C 0472451D
	.long 0x7f4439c8                                           // 0000001B1974: 7F4439C8
	v_mul_f32_e32 v58, v53, v41                                // 0000001B1978: 10745335
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B197C: BF870113
	.long 0x7e44399c                                           // 0000001B1980: 7E44399C
	v_fma_f32 v36, -v25, v58, v53                              // 0000001B1984: D6130024 24D67519
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B198C: BF870121
	v_fmac_f32_e32 v58, v36, v41                               // 0000001B1990: 56745324
	v_cvt_i32_f32_e32 v36, v57                                 // 0000001B1994: 7E481139
	v_fma_f32 v25, -v25, v58, v53                              // 0000001B1998: D6130019 24D67519
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B19A0: BF870092
	.long 0xd71c0023                                           // 0000001B19A4: D71C0023
	v_cndmask_b32_e32 v1, v43, v36, vcc_lo                     // 0000001B19A8: 0202492B
	v_cndmask_b32_e32 v35, 0, v35, vcc_lo                      // 0000001B19AC: 02464680
	s_mov_b32 vcc_lo, s0                                       // 0000001B19B0: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B19B4: BF870123
	v_div_fmas_f32 v25, v25, v41, v58                          // 0000001B19B8: D6370019 04EA5319
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v45                  // 0000001B19C0: 7C365AFF C2B17218
	v_div_fixup_f32 v25, v25, v33, v27                         // 0000001B19C8: D6270019 046E4319
	v_dual_cndmask_b32 v35, 0x7f800000, v35 :: v_dual_add_f32 v32, 1.0, v32// 0000001B19D0: CA4846FF 232040F2 7F800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B19DC: BF870112
	.long 0x7e903999                                           // 0000001B19E0: 7E903999
	v_add_f32_e32 v27, 1.0, v35                                // 0000001B19E4: 063646F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B19E8: BF870193
	v_div_scale_f32 v36, null, v32, v32, v16                   // 0000001B19EC: D6FC7C24 04424120
	v_and_b32_e32 v42, 1, v72                                  // 0000001B19F4: 36549081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B19F8: BF870193
	v_div_scale_f32 v24, null, v27, v27, v17                   // 0000001B19FC: D6FC7C18 0446371B
	v_rcp_f32_e32 v26, v36                                     // 0000001B1A04: 7E345524
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B1A08: BF870112
	v_add3_u32 v25, v25, v42, 0x7fff                           // 0000001B1A0C: D6550019 03FE5519 00007FFF
	v_rcp_f32_e32 v37, v24                                     // 0000001B1A18: 7E4A5518
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001B1A1C: BF8702A6
	v_fma_f32 v35, -v36, v26, 1.0                              // 0000001B1A20: D6130023 23CA3524
	v_lshlrev_b32_e32 v33, 16, v124                            // 0000001B1A28: 3042F890
	v_fma_f32 v45, -v24, v37, 1.0                              // 0000001B1A2C: D613002D 23CA4B18
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001B1A34: BF870232
	v_dual_fmac_f32 v26, v35, v26 :: v_dual_mul_f32 v29, 0xbfb8aa3b, v33// 0000001B1A38: C8063523 1A1C42FF BFB8AA3B
	v_div_scale_f32 v35, vcc_lo, v16, v32, v16                 // 0000001B1A44: D6FC6A23 04424110
	.long 0xd41e0001                                           // 0000001B1A4C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v33, vcc_lo              // 0000001B1A50: 020242FF 42CE8ED0
	v_fmac_f32_e32 v37, v45, v37                               // 0000001B1A58: 564A4B2D
	v_div_scale_f32 v45, s0, v17, v27, v17                     // 0000001B1A5C: D6FC002D 04463711
	v_fma_f32 v40, 0xbfb8aa3b, v33, -v29                       // 0000001B1A64: D6130028 847642FF BFB8AA3B
	v_rndne_f32_e32 v41, v29                                   // 0000001B1A70: 7E52471D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B1A74: BF870193
	v_dual_mul_f32 v56, v45, v37 :: v_dual_lshlrev_b32 v43, 16, v123// 0000001B1A78: C8E24B2D 382AF690
	v_fmac_f32_e32 v40, 0xb2a5705f, v33                        // 0000001B1A80: 565042FF B2A5705F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B1A88: BF8701B2
	v_dual_sub_f32 v29, v29, v41 :: v_dual_mul_f32 v44, 0xbfb8aa3b, v43// 0000001B1A8C: C946531D 1D2C56FF BFB8AA3B
	v_and_b32_e32 v34, 1, v34                                  // 0000001B1A98: 36444481
	v_cvt_i32_f32_e32 v41, v41                                 // 0000001B1A9C: 7E521129
	v_dual_add_f32 v29, v29, v40 :: v_dual_mul_f32 v40, v35, v26// 0000001B1AA0: C906511D 1D283523
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001B1AA8: BF870234
	v_fma_f32 v52, 0xbfb8aa3b, v43, -v44                       // 0000001B1AAC: D6130034 84B256FF BFB8AA3B
	v_rndne_f32_e32 v53, v44                                   // 0000001B1AB8: 7E6A472C
	v_add3_u32 v28, v28, v34, 0x7fff                           // 0000001B1ABC: D655001C 03FE451C 00007FFF
	v_exp_f32_e32 v29, v29                                     // 0000001B1AC8: 7E3A4B1D
	v_fma_f32 v42, -v36, v40, v35                              // 0000001B1ACC: D613002A 248E5124
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B1AD4: BF870003
	v_sub_f32_e32 v44, v44, v53                                // 0000001B1AD8: 08586B2C
	s_clause 0x1                                               // 0000001B1ADC: BF850001
	global_store_d16_hi_b16 v[30:31], v28, off offset:128      // 0000001B1AE0: DC960080 007C1C1E
	global_store_d16_hi_b16 v[38:39], v25, off offset:128      // 0000001B1AE8: DC960080 007C1926
	v_fmac_f32_e32 v40, v42, v26                               // 0000001B1AF0: 5650352A
	v_lshlrev_b32_e32 v25, 16, v126                            // 0000001B1AF4: 3032FC90
	v_fma_f32 v34, -v24, v56, v45                              // 0000001B1AF8: D6130022 24B67118
	.long 0x7f3839c8                                           // 0000001B1B00: 7F3839C8
	.long 0xd71c001d                                           // 0000001B1B04: D71C001D
	v_cndmask_b32_e32 v1, v29, v41, vcc_lo                     // 0000001B1B08: 0202531D
	v_fma_f32 v35, -v36, v40, v35                              // 0000001B1B0C: D6130023 248E5124
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B1B14: BF870224
	v_fmac_f32_e32 v56, v34, v37                               // 0000001B1B18: 56704B22
	v_cvt_i32_f32_e32 v34, v53                                 // 0000001B1B1C: 7E441135
	v_cndmask_b32_e64 v29, 0, v29, s1                          // 0000001B1B20: D501001D 00063A80
	.long 0xd41b0001                                           // 0000001B1B28: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v33, vcc_lo              // 0000001B1B2C: 020242FF C2B17218
	v_div_fmas_f32 v26, v35, v26, v40                          // 0000001B1B34: D637001A 04A23523
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v43                  // 0000001B1B3C: 7C3C56FF 42CE8ED0
	v_fma_f32 v24, -v24, v56, v45                              // 0000001B1B44: D6130018 24B67118
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001B1B4C: BF8701C4
	v_cndmask_b32_e64 v29, 0x7f800000, v29, s1                 // 0000001B1B50: D501001D 00063AFF 7F800000
	v_fmac_f32_e32 v52, 0xb2a5705f, v43                        // 0000001B1B5C: 566856FF B2A5705F
	v_div_fixup_f32 v16, v26, v32, v16                         // 0000001B1B64: D6270010 0442411A
	.long 0xd41e0001                                           // 0000001B1B6C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001B1B70: 020232FF 42CE8ED0
	v_dual_add_f32 v29, 1.0, v29 :: v_dual_add_f32 v44, v44, v52// 0000001B1B78: C9083AF2 1D2C692C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B1B80: BF870113
	.long 0x7e383990                                           // 0000001B1B84: 7E383990
	v_exp_f32_e32 v41, v44                                     // 0000001B1B88: 7E524B2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B1B8C: BF870091
	v_and_b32_e32 v28, 1, v28                                  // 0000001B1B90: 36383881
	v_add3_u32 v16, v16, v28, 0x7fff                           // 0000001B1B94: D6550010 03FE3910 00007FFF
	v_lshlrev_b32_e32 v28, 16, v92                             // 0000001B1BA0: 3038B890
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001B1BA4: BF870005
	.long 0xd71c0021                                           // 0000001B1BA8: D71C0021
	v_cndmask_b32_e32 v1, v41, v34, vcc_lo                     // 0000001B1BAC: 02024529
	global_store_d16_hi_b16 v[6:7], v16, off offset:160        // 0000001B1BB0: DC9600A0 007C1006
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000001B1BB8: 02424280
	s_mov_b32 vcc_lo, s0                                       // 0000001B1BBC: BEEA0000
	v_div_fmas_f32 v24, v24, v37, v56                          // 0000001B1BC0: D6370018 04E24B18
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v43                  // 0000001B1BC8: 7C3656FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B1BD0: BF870122
	v_div_fixup_f32 v17, v24, v27, v17                         // 0000001B1BD4: D6270011 04463718
	v_cndmask_b32_e32 v33, 0x7f800000, v33, vcc_lo             // 0000001B1BDC: 024242FF 7F800000
	.long 0x7e903991                                           // 0000001B1BE4: 7E903991
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B1BE8: BF870091
	v_dual_add_f32 v27, 1.0, v33 :: v_dual_and_b32 v36, 1, v72 // 0000001B1BEC: C92442F2 1B249081
	v_div_scale_f32 v26, null, v27, v27, v19                   // 0000001B1BF4: D6FC7C1A 044E371B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B1BFC: BF870112
	v_add3_u32 v17, v17, v36, 0x7fff                           // 0000001B1C00: D6550011 03FE4911 00007FFF
	v_rcp_f32_e32 v35, v26                                     // 0000001B1C0C: 7E46551A
	global_store_d16_hi_b16 v[46:47], v17, off offset:160      // 0000001B1C10: DC9600A0 007C112E
	v_fma_f32 v43, -v26, v35, 1.0                              // 0000001B1C18: D613002B 23CA471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B1C20: BF870091
	v_dual_fmac_f32 v35, v43, v35 :: v_dual_mul_f32 v32, 0xbfb8aa3b, v25// 0000001B1C24: C806472B 232032FF BFB8AA3B
	v_fma_f32 v40, 0xbfb8aa3b, v25, -v32                       // 0000001B1C30: D6130028 848232FF BFB8AA3B
	v_rndne_f32_e32 v41, v32                                   // 0000001B1C3C: 7E524720
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B1C40: BF870112
	v_fmac_f32_e32 v40, 0xb2a5705f, v25                        // 0000001B1C44: 565032FF B2A5705F
	v_sub_f32_e32 v32, v32, v41                                // 0000001B1C4C: 08405320
	v_cvt_i32_f32_e32 v41, v41                                 // 0000001B1C50: 7E521129
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B1C54: BF8701B2
	v_add_f32_e32 v32, v32, v40                                // 0000001B1C58: 06405120
	v_div_scale_f32 v40, s0, v19, v27, v19                     // 0000001B1C5C: D6FC0028 044E3713
	v_mul_f32_e32 v18, v18, v49                                // 0000001B1C64: 10246312
	v_exp_f32_e32 v32, v32                                     // 0000001B1C68: 7E404B20
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B1C6C: BF870112
	v_mul_f32_e32 v53, v40, v35                                // 0000001B1C70: 106A4728
	v_div_scale_f32 v34, null, v29, v29, v18                   // 0000001B1C74: D6FC7C22 044A3B1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001B1C7C: BF870311
	v_rcp_f32_e32 v24, v34                                     // 0000001B1C80: 7E305522
	.long 0xd71c0020                                           // 0000001B1C84: D71C0020
	v_cndmask_b32_e32 v1, v32, v41, vcc_lo                     // 0000001B1C88: 02025320
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B1C8C: BF870291
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000001B1C90: D5010020 00064080
	v_fma_f32 v33, -v34, v24, 1.0                              // 0000001B1C98: D6130021 23CA3122
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B1CA0: BF870121
	v_dual_fmac_f32 v24, v33, v24 :: v_dual_lshlrev_b32 v37, 16, v125// 0000001B1CA4: C8223121 1824FA90
	v_div_scale_f32 v33, vcc_lo, v18, v29, v18                 // 0000001B1CAC: D6FC6A21 044A3B12
	v_mul_f32_e32 v42, 0xbfb8aa3b, v37                         // 0000001B1CB4: 10544AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B1CBC: BF870191
	v_fma_f32 v45, 0xbfb8aa3b, v37, -v42                       // 0000001B1CC0: D613002D 84AA4AFF BFB8AA3B
	v_mul_f32_e32 v44, v33, v24                                // 0000001B1CCC: 10583121
	v_rndne_f32_e32 v52, v42                                   // 0000001B1CD0: 7E68472A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B1CD4: BF870193
	v_fmac_f32_e32 v45, 0xb2a5705f, v37                        // 0000001B1CD8: 565A4AFF B2A5705F
	v_fma_f32 v43, -v34, v44, v33                              // 0000001B1CE0: D613002B 24865922
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B1CE8: BF870121
	v_fmac_f32_e32 v44, v43, v24                               // 0000001B1CEC: 5658312B
	v_fma_f32 v43, -v26, v53, v40                              // 0000001B1CF0: D613002B 24A26B1A
	v_fma_f32 v33, -v34, v44, v33                              // 0000001B1CF8: D6130021 24865922
	v_cvt_i32_f32_e32 v34, v52                                 // 0000001B1D00: 7E441134
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B1D04: BF870193
	v_fmac_f32_e32 v53, v43, v35                               // 0000001B1D08: 566A472B
	v_div_fmas_f32 v24, v33, v24, v44                          // 0000001B1D0C: D6370018 04B23121
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001B1D14: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B1D1C: BF870193
	v_fma_f32 v26, -v26, v53, v40                              // 0000001B1D20: D613001A 24A26B1A
	v_div_fixup_f32 v16, v24, v29, v18                         // 0000001B1D28: D6270010 044A3B18
	.long 0x7f3a39c8                                           // 0000001B1D30: 7F3A39C8
	v_cndmask_b32_e32 v25, 0x7f800000, v32, vcc_lo             // 0000001B1D34: 023240FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v37                  // 0000001B1D3C: 7C3C4AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B1D44: BF870194
	.long 0x7e3a3990                                           // 0000001B1D48: 7E3A3990
	v_dual_sub_f32 v42, v42, v52 :: v_dual_add_f32 v25, 1.0, v25// 0000001B1D4C: C948692A 2A1832F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B1D54: BF870112
	v_and_b32_e32 v29, 1, v29                                  // 0000001B1D58: 363A3A81
	v_add_f32_e32 v42, v42, v45                                // 0000001B1D5C: 06545B2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B1D60: BF870112
	v_add3_u32 v16, v16, v29, 0x7fff                           // 0000001B1D64: D6550010 03FE3B10 00007FFF
	v_exp_f32_e32 v36, v42                                     // 0000001B1D70: 7E484B2A
	global_store_d16_hi_b16 v[14:15], v16, off offset:160      // 0000001B1D74: DC9600A0 007C100E
	.long 0xd71c0021                                           // 0000001B1D7C: D71C0021
	v_cndmask_b32_e32 v1, v36, v34, vcc_lo                     // 0000001B1D80: 02024524
	v_mul_f32_e32 v34, 0xbfb8aa3b, v28                         // 0000001B1D84: 104438FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001B1D8C: BF870002
	v_cndmask_b32_e32 v32, 0, v33, vcc_lo                      // 0000001B1D90: 02404280
	s_mov_b32 vcc_lo, s0                                       // 0000001B1D94: BEEA0000
	v_div_fmas_f32 v26, v26, v35, v53                          // 0000001B1D98: D637001A 04D6471A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v37                  // 0000001B1DA0: 7C364AFF C2B17218
	v_rndne_f32_e32 v35, v34                                   // 0000001B1DA8: 7E464722
	s_waitcnt vmcnt(2)                                         // 0000001B1DAC: BF890BF7
	v_lshlrev_b32_e32 v37, 16, v69                             // 0000001B1DB0: 304A8A90
	v_div_fixup_f32 v19, v26, v27, v19                         // 0000001B1DB4: D6270013 044E371A
	v_cndmask_b32_e32 v32, 0x7f800000, v32, vcc_lo             // 0000001B1DBC: 024040FF 7F800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B1DC4: BF870112
	.long 0x7e903993                                           // 0000001B1DC8: 7E903993
	v_add_f32_e32 v27, 1.0, v32                                // 0000001B1DCC: 063640F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B1DD0: BF870112
	v_and_b32_e32 v32, 1, v72                                  // 0000001B1DD4: 36409081
	v_div_scale_f32 v24, null, v27, v27, v21                   // 0000001B1DD8: D6FC7C18 0456371B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B1DE0: BF870112
	v_add3_u32 v19, v19, v32, 0x7fff                           // 0000001B1DE4: D6550013 03FE4113 00007FFF
	v_rcp_f32_e32 v33, v24                                     // 0000001B1DF0: 7E425518
	v_fma_f32 v32, 0xbfb8aa3b, v28, -v34                       // 0000001B1DF4: D6130020 848A38FF BFB8AA3B
	v_sub_f32_e32 v34, v34, v35                                // 0000001B1E00: 08444722
	v_cvt_i32_f32_e32 v35, v35                                 // 0000001B1E04: 7E461123
	global_store_d16_hi_b16 v[22:23], v19, off offset:160      // 0000001B1E08: DC9600A0 007C1316
	v_fmac_f32_e32 v32, 0xb2a5705f, v28                        // 0000001B1E10: 564038FF B2A5705F
	v_fma_f32 v36, -v24, v33, 1.0                              // 0000001B1E18: D6130024 23CA4318
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B1E20: BF8701A2
	v_add_f32_e32 v32, v34, v32                                // 0000001B1E24: 06404122
	v_mul_f32_e32 v34, 0xbfb8aa3b, v37                         // 0000001B1E28: 10444AFF BFB8AA3B
	v_fmac_f32_e32 v33, v36, v33                               // 0000001B1E30: 56424324
	v_div_scale_f32 v36, s0, v21, v27, v21                     // 0000001B1E34: D6FC0024 04563715
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B1E3C: BF8701B3
	v_fma_f32 v42, 0xbfb8aa3b, v37, -v34                       // 0000001B1E40: D613002A 848A4AFF BFB8AA3B
	v_rndne_f32_e32 v43, v34                                   // 0000001B1E4C: 7E564722
	v_exp_f32_e32 v32, v32                                     // 0000001B1E50: 7E404B20
	v_mul_f32_e32 v41, v36, v33                                // 0000001B1E54: 10524324
	v_mul_f32_e32 v20, v20, v51                                // 0000001B1E58: 10286714
	v_fmac_f32_e32 v42, 0xb2a5705f, v37                        // 0000001B1E5C: 56544AFF B2A5705F
	v_sub_f32_e32 v34, v34, v43                                // 0000001B1E64: 08445722
	v_cvt_i32_f32_e32 v19, v43                                 // 0000001B1E68: 7E26112B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B1E6C: BF870094
	v_div_scale_f32 v26, null, v25, v25, v20                   // 0000001B1E70: D6FC7C1A 04523319
	v_rcp_f32_e32 v18, v26                                     // 0000001B1E78: 7E24551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B1E7C: BF870095
	v_fma_f32 v17, -v26, v18, 1.0                              // 0000001B1E80: D6130011 23CA251A
	v_fmac_f32_e32 v18, v17, v18                               // 0000001B1E88: 56242511
	v_div_scale_f32 v17, vcc_lo, v20, v25, v20                 // 0000001B1E8C: D6FC6A11 04523314
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B1E94: BF870091
	v_mul_f32_e32 v40, v17, v18                                // 0000001B1E98: 10502511
	v_fma_f32 v29, -v26, v40, v17                              // 0000001B1E9C: D613001D 2446511A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B1EA4: BF870121
	v_fmac_f32_e32 v40, v29, v18                               // 0000001B1EA8: 5650251D
	v_fma_f32 v29, -v24, v41, v36                              // 0000001B1EAC: D613001D 24925318
	v_fma_f32 v16, -v26, v40, v17                              // 0000001B1EB4: D6130010 2446511A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B1EBC: BF8701A2
	v_dual_fmac_f32 v41, v29, v33 :: v_dual_add_f32 v26, v34, v42// 0000001B1EC0: C808431D 291A5522
	.long 0xd71c0011                                           // 0000001B1EC8: D71C0011
	v_cndmask_b32_e32 v1, v32, v35, vcc_lo                     // 0000001B1ECC: 02024720
	v_div_fmas_f32 v16, v16, v18, v40                          // 0000001B1ED0: D6370010 04A22510
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v28                  // 0000001B1ED8: 7C3C38FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B1EE0: BF8701A4
	v_fma_f32 v18, -v24, v41, v36                              // 0000001B1EE4: D6130012 24925318
	v_exp_f32_e32 v24, v26                                     // 0000001B1EEC: 7E304B1A
	v_div_fixup_f32 v16, v16, v25, v20                         // 0000001B1EF0: D6270010 04523310
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000001B1EF8: 02222280
	s_mov_b32 vcc_lo, s0                                       // 0000001B1EFC: BEEA0000
	.long 0x7f2839c8                                           // 0000001B1F00: 7F2839C8
	v_div_fmas_f32 v18, v18, v33, v41                          // 0000001B1F04: D6370012 04A64312
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v28                  // 0000001B1F0C: 7C3638FF C2B17218
	.long 0x7e283990                                           // 0000001B1F14: 7E283990
	v_lshlrev_b32_e32 v33, 16, v104                            // 0000001B1F18: 3042D090
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001B1F1C: BF870005
	.long 0xd71c0013                                           // 0000001B1F20: D71C0013
	v_cndmask_b32_e32 v1, v24, v19, vcc_lo                     // 0000001B1F24: 02022718
	v_div_fixup_f32 v18, v18, v27, v21                         // 0000001B1F28: D6270012 04563712
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 0000001B1F30: 022222FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v37                  // 0000001B1F38: 7C3C4AFF 42CE8ED0
	v_and_b32_e32 v20, 1, v20                                  // 0000001B1F40: 36282881
	v_mul_f32_e32 v36, 0xbfb8aa3b, v33                         // 0000001B1F44: 104842FF BFB8AA3B
	.long 0x7e903992                                           // 0000001B1F4C: 7E903992
	v_add_f32_e32 v17, 1.0, v17                                // 0000001B1F50: 062222F2
	v_cndmask_b32_e32 v19, 0, v19, vcc_lo                      // 0000001B1F54: 02262680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v37                  // 0000001B1F58: 7C364AFF C2B17218
	v_add3_u32 v16, v16, v20, 0x7fff                           // 0000001B1F60: D6550010 03FE2910 00007FFF
	v_and_b32_e32 v27, 1, v72                                  // 0000001B1F6C: 36369081
	v_div_scale_f32 v21, null, v17, v17, v8                    // 0000001B1F70: D6FC7C15 04222311
	v_cndmask_b32_e32 v19, 0x7f800000, v19, vcc_lo             // 0000001B1F78: 022626FF 7F800000
	global_store_d16_hi_b16 v[30:31], v16, off offset:160      // 0000001B1F80: DC9600A0 007C101E
	v_add3_u32 v18, v18, v27, 0x7fff                           // 0000001B1F88: D6550012 03FE3712 00007FFF
	v_rcp_f32_e32 v25, v21                                     // 0000001B1F94: 7E325515
	v_rndne_f32_e32 v27, v36                                   // 0000001B1F98: 7E364724
	v_add_f32_e32 v19, 1.0, v19                                // 0000001B1F9C: 062626F2
	global_store_d16_hi_b16 v[38:39], v18, off offset:160      // 0000001B1FA0: DC9600A0 007C1226
	v_lshlrev_b32_e32 v18, 16, v106                            // 0000001B1FA8: 3024D490
	v_div_scale_f32 v32, null, v19, v19, v9                    // 0000001B1FAC: D6FC7C20 04262713
	v_fma_f32 v34, -v21, v25, 1.0                              // 0000001B1FB4: D6130022 23CA3315
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B1FBC: BF870092
	v_rcp_f32_e32 v35, v32                                     // 0000001B1FC0: 7E465520
	v_fmac_f32_e32 v25, v34, v25                               // 0000001B1FC4: 56323322
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B1FC8: BF870095
	v_fma_f32 v34, -v32, v35, 1.0                              // 0000001B1FCC: D6130022 23CA4720
	v_fmac_f32_e32 v35, v34, v35                               // 0000001B1FD4: 56464722
	v_div_scale_f32 v34, s0, v9, v19, v9                       // 0000001B1FD8: D6FC0022 04262709
	v_lshlrev_b32_e32 v24, 16, v105                            // 0000001B1FE0: 3030D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B1FE4: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v24                         // 0000001B1FE8: 103430FF BFB8AA3B
	v_fma_f32 v28, 0xbfb8aa3b, v24, -v26                       // 0000001B1FF0: D613001C 846A30FF BFB8AA3B
	v_rndne_f32_e32 v29, v26                                   // 0000001B1FFC: 7E3A471A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B2000: BF870112
	v_fmac_f32_e32 v28, 0xb2a5705f, v24                        // 0000001B2004: 563830FF B2A5705F
	v_sub_f32_e32 v26, v26, v29                                // 0000001B200C: 08343B1A
	v_cvt_i32_f32_e32 v29, v29                                 // 0000001B2010: 7E3A111D
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001B2014: BF870002
	v_add_f32_e32 v20, v26, v28                                // 0000001B2018: 0628391A
	v_fma_f32 v26, 0xbfb8aa3b, v33, -v36                       // 0000001B201C: D613001A 849242FF BFB8AA3B
	v_div_scale_f32 v28, vcc_lo, v8, v17, v8                   // 0000001B2028: D6FC6A1C 04222308
	v_sub_f32_e32 v36, v36, v27                                // 0000001B2030: 08483724
	v_cvt_i32_f32_e32 v27, v27                                 // 0000001B2034: 7E36111B
	v_exp_f32_e32 v20, v20                                     // 0000001B2038: 7E284B14
	v_fmac_f32_e32 v26, 0xb2a5705f, v33                        // 0000001B203C: 563442FF B2A5705F
	v_mul_f32_e32 v37, v28, v25                                // 0000001B2044: 104A331C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B2048: BF870292
	v_add_f32_e32 v26, v36, v26                                // 0000001B204C: 06343524
	.long 0xd71c0010                                           // 0000001B2050: D71C0010
	v_cndmask_b32_e32 v1, v20, v29, vcc_lo                     // 0000001B2054: 02023B14
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001B2058: BF8701C3
	v_fma_f32 v20, -v21, v37, v28                              // 0000001B205C: D6130014 24724B15
	v_mul_f32_e32 v29, v34, v35                                // 0000001B2064: 103A4722
	.long 0xd41e0001                                           // 0000001B2068: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v24, vcc_lo              // 0000001B206C: 020230FF 42CE8ED0
	v_exp_f32_e32 v26, v26                                     // 0000001B2074: 7E344B1A
	v_fmac_f32_e32 v37, v20, v25                               // 0000001B2078: 564A3314
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B207C: BF870193
	v_fma_f32 v20, -v32, v29, v34                              // 0000001B2080: D6130014 248A3B20
	v_cndmask_b32_e64 v16, 0, v16, s1                          // 0000001B2088: D5010010 00062080
	.long 0xd41b0001                                           // 0000001B2090: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v24, vcc_lo              // 0000001B2094: 020230FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B209C: BF870214
	v_fma_f32 v21, -v21, v37, v28                              // 0000001B20A0: D6130015 24724B15
	v_fmac_f32_e32 v29, v20, v35                               // 0000001B20A8: 563A4714
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B20AC: BF870293
	v_cndmask_b32_e64 v16, 0x7f800000, v16, s1                 // 0000001B20B0: D5010010 000620FF 7F800000
	.long 0xd71c0014                                           // 0000001B20BC: D71C0014
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000001B20C0: 0202371A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B20C4: BF870004
	v_div_fmas_f32 v21, v21, v25, v37                          // 0000001B20C8: D6370015 04963315
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000001B20D0: 7C3C42FF 42CE8ED0
	v_fma_f32 v24, -v32, v29, v34                              // 0000001B20D8: D6130018 248A3B20
	v_add_f32_e32 v16, 1.0, v16                                // 0000001B20E0: 062020F2
	.long 0xd41e0001                                           // 0000001B20E4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v18, vcc_lo              // 0000001B20E8: 020224FF 42CE8ED0
	v_div_fixup_f32 v8, v21, v17, v8                           // 0000001B20F0: D6270008 04222315
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001B20F8: 02282880
	s_mov_b32 vcc_lo, s0                                       // 0000001B20FC: BEEA0000
	v_div_scale_f32 v25, null, v16, v16, v10                   // 0000001B2100: D6FC7C19 042A2110
	v_div_fmas_f32 v24, v24, v35, v29                          // 0000001B2108: D6370018 04764718
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000001B2110: 7C3642FF C2B17218
	v_lshlrev_b32_e32 v33, 16, v65                             // 0000001B2118: 30428290
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B211C: BF870194
	v_rcp_f32_e32 v26, v25                                     // 0000001B2120: 7E345519
	v_div_fixup_f32 v9, v24, v19, v9                           // 0000001B2124: D6270009 04262718
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 0000001B212C: 022828FF 7F800000
	v_mul_f32_e32 v24, 0xbfb8aa3b, v18                         // 0000001B2134: 103024FF BFB8AA3B
	v_div_scale_f32 v32, vcc_lo, v10, v16, v10                 // 0000001B213C: D6FC6A20 042A210A
	v_mul_f32_e32 v35, 0xbfb8aa3b, v33                         // 0000001B2144: 104642FF BFB8AA3B
	.long 0x7e903989                                           // 0000001B214C: 7E903989
	v_add_f32_e32 v17, 1.0, v20                                // 0000001B2150: 062228F2
	v_fma_f32 v28, 0xbfb8aa3b, v18, -v24                       // 0000001B2154: D613001C 846224FF BFB8AA3B
	v_rndne_f32_e32 v29, v24                                   // 0000001B2160: 7E3A4718
	v_fma_f32 v20, -v25, v26, 1.0                              // 0000001B2164: D6130014 23CA3519
	v_and_b32_e32 v27, 1, v72                                  // 0000001B216C: 36369081
	v_div_scale_f32 v21, null, v17, v17, v11                   // 0000001B2170: D6FC7C15 042E2311
	v_fmac_f32_e32 v28, 0xb2a5705f, v18                        // 0000001B2178: 563824FF B2A5705F
	v_sub_f32_e32 v24, v24, v29                                // 0000001B2180: 08303B18
	v_fmac_f32_e32 v26, v20, v26                               // 0000001B2184: 56343514
	.long 0x7e263988                                           // 0000001B2188: 7E263988
	v_rcp_f32_e32 v20, v21                                     // 0000001B218C: 7E285515
	.long 0x7f2639c8                                           // 0000001B2190: 7F2639C8
	v_add_f32_e32 v24, v24, v28                                // 0000001B2194: 06303918
	v_mul_f32_e32 v34, v32, v26                                // 0000001B2198: 10443520
	v_fma_f32 v36, 0xbfb8aa3b, v33, -v35                       // 0000001B219C: D6130024 848E42FF BFB8AA3B
	v_rndne_f32_e32 v37, v35                                   // 0000001B21A8: 7E4A4723
	v_add3_u32 v9, v9, v27, 0x7fff                             // 0000001B21AC: D6550009 03FE3709 00007FFF
	v_and_b32_e32 v19, 1, v19                                  // 0000001B21B8: 36262681
	v_fma_f32 v28, -v25, v34, v32                              // 0000001B21BC: D613001C 24824519
	v_exp_f32_e32 v24, v24                                     // 0000001B21C4: 7E304B18
	v_fma_f32 v27, -v21, v20, 1.0                              // 0000001B21C8: D613001B 23CA2915
	v_fmac_f32_e32 v36, 0xb2a5705f, v33                        // 0000001B21D0: 564842FF B2A5705F
	v_sub_f32_e32 v35, v35, v37                                // 0000001B21D8: 08464B23
	v_add3_u32 v8, v8, v19, 0x7fff                             // 0000001B21DC: D6550008 03FE2708 00007FFF
	v_cvt_i32_f32_e32 v19, v29                                 // 0000001B21E8: 7E26111D
	v_fmac_f32_e32 v20, v27, v20                               // 0000001B21EC: 5628291B
	v_div_scale_f32 v27, s0, v11, v17, v11                     // 0000001B21F0: D6FC001B 042E230B
	v_dual_fmac_f32 v34, v28, v26 :: v_dual_add_f32 v29, v35, v36// 0000001B21F8: C808351C 221C4923
	global_store_d16_hi_b16 v[6:7], v8, off offset:192         // 0000001B2200: DC9600C0 007C0806
	.long 0xd71c0008                                           // 0000001B2208: D71C0008
	v_cndmask_b32_e32 v1, v24, v19, vcc_lo                     // 0000001B220C: 02022718
	v_mul_f32_e32 v28, v27, v20                                // 0000001B2210: 1038291B
	v_fma_f32 v19, -v25, v34, v32                              // 0000001B2214: D6130013 24824519
	v_exp_f32_e32 v25, v29                                     // 0000001B221C: 7E324B1D
	global_store_d16_hi_b16 v[46:47], v9, off offset:192       // 0000001B2220: DC9600C0 007C092E
	v_cndmask_b32_e64 v8, 0, v8, s1                            // 0000001B2228: D5010008 00061080
	v_fma_f32 v24, -v21, v28, v27                              // 0000001B2230: D6130018 246E3915
	v_div_fmas_f32 v19, v19, v26, v34                          // 0000001B2238: D6370013 048A3513
	v_cvt_i32_f32_e32 v26, v37                                 // 0000001B2240: 7E341125
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v18                  // 0000001B2244: 7C3624FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B224C: BF870214
	v_fmac_f32_e32 v28, v24, v20                               // 0000001B2250: 56382918
	v_div_fixup_f32 v10, v19, v16, v10                         // 0000001B2254: D627000A 042A2113
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B225C: BF870004
	.long 0xd71c0010                                           // 0000001B2260: D71C0010
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000001B2264: 02023519
	v_cndmask_b32_e32 v8, 0x7f800000, v8, vcc_lo               // 0000001B2268: 021010FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000001B2270: 7C3C42FF 42CE8ED0
	v_fma_f32 v18, -v21, v28, v27                              // 0000001B2278: D6130012 246E3915
	s_waitcnt vmcnt(1)                                         // 0000001B2280: BF8907F7
	v_lshlrev_b32_e32 v24, 16, v68                             // 0000001B2284: 30308890
	.long 0x7e2a398a                                           // 0000001B2288: 7E2A398A
	v_add_f32_e32 v8, 1.0, v8                                  // 0000001B228C: 061010F2
	v_cndmask_b32_e32 v16, 0, v16, vcc_lo                      // 0000001B2290: 02202080
	s_mov_b32 vcc_lo, s0                                       // 0000001B2294: BEEA0000
	v_mul_f32_e32 v29, 0xbfb8aa3b, v24                         // 0000001B2298: 103A30FF BFB8AA3B
	v_div_fmas_f32 v18, v18, v20, v28                          // 0000001B22A0: D6370012 04722912
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000001B22A8: 7C3642FF C2B17218
	v_lshlrev_b32_e32 v20, 16, v54                             // 0000001B22B0: 30286C90
	v_div_scale_f32 v19, null, v8, v8, v12                     // 0000001B22B4: D6FC7C13 04321108
	v_fma_f32 v33, 0xbfb8aa3b, v24, -v29                       // 0000001B22BC: D6130021 847630FF BFB8AA3B
	v_div_fixup_f32 v11, v18, v17, v11                         // 0000001B22C8: D627000B 042E2312
	v_cndmask_b32_e32 v16, 0x7f800000, v16, vcc_lo             // 0000001B22D0: 022020FF 7F800000
	v_mul_f32_e32 v18, 0xbfb8aa3b, v20                         // 0000001B22D8: 102428FF BFB8AA3B
	v_rcp_f32_e32 v17, v19                                     // 0000001B22E0: 7E225513
	v_rndne_f32_e32 v34, v29                                   // 0000001B22E4: 7E44471D
	v_fmac_f32_e32 v33, 0xb2a5705f, v24                        // 0000001B22E8: 564230FF B2A5705F
	v_add_f32_e32 v16, 1.0, v16                                // 0000001B22F0: 062020F2
	v_fma_f32 v26, 0xbfb8aa3b, v20, -v18                       // 0000001B22F4: D613001A 844A28FF BFB8AA3B
	v_rndne_f32_e32 v27, v18                                   // 0000001B2300: 7E364712
	.long 0xd41e0001                                           // 0000001B2304: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v20, vcc_lo              // 0000001B2308: 020228FF 42CE8ED0
	.long 0x7e90398b                                           // 0000001B2310: 7E90398B
	v_div_scale_f32 v25, null, v16, v16, v13                   // 0000001B2314: D6FC7C19 04362110
	v_fmac_f32_e32 v26, 0xb2a5705f, v20                        // 0000001B231C: 563428FF B2A5705F
	v_sub_f32_e32 v18, v18, v27                                // 0000001B2324: 08243712
	v_fma_f32 v28, -v19, v17, 1.0                              // 0000001B2328: D613001C 23CA2313
	v_cvt_i32_f32_e32 v27, v27                                 // 0000001B2330: 7E36111B
	v_rcp_f32_e32 v32, v25                                     // 0000001B2334: 7E405519
	.long 0x7f2a39c8                                           // 0000001B2338: 7F2A39C8
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B233C: BF8701B3
	v_dual_add_f32 v18, v18, v26 :: v_dual_fmac_f32 v17, v28, v17// 0000001B2340: C9003512 1210231C
	v_div_scale_f32 v26, vcc_lo, v12, v8, v12                  // 0000001B2348: D6FC6A1A 0432110C
	v_dual_sub_f32 v28, v29, v34 :: v_dual_and_b32 v35, 1, v72 // 0000001B2350: C964451D 1C229081
	v_exp_f32_e32 v18, v18                                     // 0000001B2358: 7E244B12
	v_and_b32_e32 v21, 1, v21                                  // 0000001B235C: 362A2A81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001B2360: BF870313
	v_mul_f32_e32 v36, v26, v17                                // 0000001B2364: 1048231A
	v_fma_f32 v29, -v25, v32, 1.0                              // 0000001B2368: D613001D 23CA4119
	v_add_f32_e32 v28, v28, v33                                // 0000001B2370: 0638431C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B2374: BF870214
	v_add3_u32 v9, v10, v21, 0x7fff                            // 0000001B2378: D6550009 03FE2B0A 00007FFF
	v_fma_f32 v33, -v19, v36, v26                              // 0000001B2384: D6130021 246A4913
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B238C: BF870004
	v_fmac_f32_e32 v32, v29, v32                               // 0000001B2390: 5640411D
	v_div_scale_f32 v29, s0, v13, v16, v13                     // 0000001B2394: D6FC001D 0436210D
	v_exp_f32_e32 v28, v28                                     // 0000001B239C: 7E384B1C
	.long 0xd71c0012                                           // 0000001B23A0: D71C0012
	v_cndmask_b32_e32 v1, v18, v27, vcc_lo                     // 0000001B23A4: 02023712
	v_fmac_f32_e32 v36, v33, v17                               // 0000001B23A8: 56482321
	v_cvt_i32_f32_e32 v33, v34                                 // 0000001B23AC: 7E421122
	v_mul_f32_e32 v27, v29, v32                                // 0000001B23B0: 1036411D
	v_add3_u32 v10, v11, v35, 0x7fff                           // 0000001B23B4: D655000A 03FE470B 00007FFF
	v_cndmask_b32_e64 v18, 0, v18, s1                          // 0000001B23C0: D5010012 00062480
	.long 0xd41b0001                                           // 0000001B23C8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v20, vcc_lo              // 0000001B23CC: 020228FF C2B17218
	v_fma_f32 v19, -v19, v36, v26                              // 0000001B23D4: D6130013 246A4913
	v_fma_f32 v34, -v25, v27, v29                              // 0000001B23DC: D6130022 24763719
	.long 0xd71c001a                                           // 0000001B23E4: D71C001A
	v_cndmask_b32_e32 v1, v28, v33, vcc_lo                     // 0000001B23E8: 0202431C
	global_store_d16_hi_b16 v[14:15], v9, off offset:192       // 0000001B23EC: DC9600C0 007C090E
	v_cndmask_b32_e64 v18, 0x7f800000, v18, s1                 // 0000001B23F4: D5010012 000624FF 7F800000
	.long 0xd41e0001                                           // 0000001B2400: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v24, vcc_lo              // 0000001B2404: 020230FF 42CE8ED0
	v_fmac_f32_e32 v27, v34, v32                               // 0000001B240C: 56364122
	v_div_fmas_f32 v17, v19, v17, v36                          // 0000001B2410: D6370011 04922313
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000001B2418: 7C3630FF C2B17218
	v_add_f32_e32 v18, 1.0, v18                                // 0000001B2420: 062424F2
	v_cndmask_b32_e64 v20, 0, v26, s1                          // 0000001B2424: D5010014 00063480
	v_fma_f32 v19, -v25, v27, v29                              // 0000001B242C: D6130013 24763719
	v_div_fixup_f32 v8, v17, v8, v12                           // 0000001B2434: D6270008 04321111
	global_store_d16_hi_b16 v[22:23], v10, off offset:192      // 0000001B243C: DC9600C0 007C0A16
	v_div_scale_f32 v25, null, v18, v18, v0                    // 0000001B2444: D6FC7C19 04022512
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 0000001B244C: 022828FF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001B2454: BEEA0000
	v_lshlrev_b32_e32 v17, 16, v62                             // 0000001B2458: 30227C90
	v_div_fmas_f32 v19, v19, v32, v27                          // 0000001B245C: D6370013 046E4113
	v_rcp_f32_e32 v24, v25                                     // 0000001B2464: 7E305519
	v_add_f32_e32 v20, 1.0, v20                                // 0000001B2468: 062828F2
	v_lshlrev_b32_e32 v28, 16, v55                             // 0000001B246C: 30386E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B2470: BF870223
	v_div_fixup_f32 v11, v19, v16, v13                         // 0000001B2474: D627000B 04362113
	.long 0x7e203988                                           // 0000001B247C: 7E203988
	v_div_scale_f32 v13, null, v20, v20, v1                    // 0000001B2480: D6FC7C0D 04062914
	.long 0x7f2039c8                                           // 0000001B2488: 7F2039C8
	v_mul_f32_e32 v29, 0xbfb8aa3b, v28                         // 0000001B248C: 103A38FF BFB8AA3B
	.long 0x7e90398b                                           // 0000001B2494: 7E90398B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B2498: BF8701B5
	v_fma_f32 v9, -v25, v24, 1.0                               // 0000001B249C: D6130009 23CA3119
	v_rcp_f32_e32 v12, v13                                     // 0000001B24A4: 7E18550D
	v_and_b32_e32 v16, 1, v16                                  // 0000001B24A8: 36202081
	v_and_b32_e32 v10, 1, v72                                  // 0000001B24AC: 36149081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B24B0: BF870223
	v_fmac_f32_e32 v24, v9, v24                                // 0000001B24B4: 56303109
	v_div_scale_f32 v9, vcc_lo, v0, v18, v0                    // 0000001B24B8: D6FC6A09 04022500
	v_add3_u32 v8, v8, v16, 0x7fff                             // 0000001B24C0: D6550008 03FE2108 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B24CC: BF870224
	v_add3_u32 v10, v11, v10, 0x7fff                           // 0000001B24D0: D655000A 03FE150B 00007FFF
	v_mul_f32_e32 v11, 0xbfb8aa3b, v17                         // 0000001B24DC: 101622FF BFB8AA3B
	v_mul_f32_e32 v19, v9, v24                                 // 0000001B24E4: 10263109
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001B24E8: BF870005
	v_fma_f32 v21, -v13, v12, 1.0                              // 0000001B24EC: D6130015 23CA190D
	s_clause 0x1                                               // 0000001B24F4: BF850001
	global_store_d16_hi_b16 v[30:31], v8, off offset:192       // 0000001B24F8: DC9600C0 007C081E
	global_store_d16_hi_b16 v[38:39], v10, off offset:192      // 0000001B2500: DC9600C0 007C0A26
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v11                       // 0000001B2508: D613001A 842E22FF BFB8AA3B
	v_fma_f32 v16, -v25, v19, v9                               // 0000001B2514: D6130010 24262719
	v_fmac_f32_e32 v12, v21, v12                               // 0000001B251C: 56181915
	v_div_scale_f32 v21, s0, v1, v20, v1                       // 0000001B2520: D6FC0015 04062901
	v_rndne_f32_e32 v27, v11                                   // 0000001B2528: 7E36470B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B252C: BF870114
	v_dual_fmac_f32 v26, 0xb2a5705f, v17 :: v_dual_fmac_f32 v19, v16, v24// 0000001B2530: C80022FF 1A123110 B2A5705F
	v_dual_mul_f32 v16, v21, v12 :: v_dual_sub_f32 v11, v11, v27// 0000001B253C: C8CA1915 100A370B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B2544: BF8701A2
	v_fma_f32 v8, -v25, v19, v9                                // 0000001B2548: D6130008 24262719
	v_fma_f32 v25, 0xbfb8aa3b, v28, -v29                       // 0000001B2550: D6130019 847638FF BFB8AA3B
	v_fma_f32 v9, -v13, v16, v21                               // 0000001B255C: D6130009 2456210D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B2564: BF870004
	v_add_f32_e32 v11, v11, v26                                // 0000001B2568: 0616350B
	v_rndne_f32_e32 v26, v29                                   // 0000001B256C: 7E34471D
	v_div_fmas_f32 v8, v8, v24, v19                            // 0000001B2570: D6370008 044E3108
	v_fmac_f32_e32 v25, 0xb2a5705f, v28                        // 0000001B2578: 563238FF B2A5705F
	v_fmac_f32_e32 v16, v9, v12                                // 0000001B2580: 56201909
	v_exp_f32_e32 v9, v11                                      // 0000001B2584: 7E124B0B
	v_sub_f32_e32 v11, v29, v26                                // 0000001B2588: 0816351D
	v_lshlrev_b32_e32 v19, 16, v63                             // 0000001B258C: 30267E90
	v_cvt_i32_f32_e32 v24, v27                                 // 0000001B2590: 7E30111B
	v_fma_f32 v13, -v13, v16, v21                              // 0000001B2594: D613000D 2456210D
	s_waitcnt vmcnt(0)                                         // 0000001B259C: BF8903F7
	v_lshlrev_b32_e32 v21, 16, v64                             // 0000001B25A0: 302A8090
	v_add_f32_e32 v11, v11, v25                                // 0000001B25A4: 0616330B
	v_mul_f32_e32 v25, 0xbfb8aa3b, v19                         // 0000001B25A8: 103226FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000001B25B0: 7C3C22FF 42CE8ED0
	v_cvt_i32_f32_e32 v26, v26                                 // 0000001B25B8: 7E34111A
	v_mul_f32_e32 v27, 0xbfb8aa3b, v21                         // 0000001B25BC: 10362AFF BFB8AA3B
	.long 0xd71c0009                                           // 0000001B25C4: D71C0009
	v_cndmask_b32_e32 v1, v9, v24, vcc_lo                      // 0000001B25C8: 02023109
	v_fma_f32 v24, 0xbfb8aa3b, v19, -v25                       // 0000001B25CC: D6130018 846626FF BFB8AA3B
	v_rndne_f32_e32 v29, v25                                   // 0000001B25D8: 7E3A4719
	v_exp_f32_e32 v11, v11                                     // 0000001B25DC: 7E164B0B
	v_fma_f32 v32, 0xbfb8aa3b, v21, -v27                       // 0000001B25E0: D6130020 846E2AFF BFB8AA3B
	v_rndne_f32_e32 v33, v27                                   // 0000001B25EC: 7E42471B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B25F0: BF870223
	v_dual_fmac_f32 v24, 0xb2a5705f, v19 :: v_dual_sub_f32 v25, v25, v29// 0000001B25F4: C80A26FF 18183B19 B2A5705F
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 0000001B2600: 02121280
	v_fmac_f32_e32 v32, 0xb2a5705f, v21                        // 0000001B2604: 56402AFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 0000001B260C: BF8702B4
	v_sub_f32_e32 v27, v27, v33                                // 0000001B2610: 0836431B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000001B2614: 7C3622FF C2B17218
	v_add_f32_e32 v24, v25, v24                                // 0000001B261C: 06303119
	.long 0xd71c000b                                           // 0000001B2620: D71C000B
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 0000001B2624: 0202350B
	v_cvt_i32_f32_e32 v26, v33                                 // 0000001B2628: 7E341121
	v_add_f32_e32 v25, v27, v32                                // 0000001B262C: 0632411B
	v_cndmask_b32_e32 v9, 0x7f800000, v9, vcc_lo               // 0000001B2630: 021212FF 7F800000
	v_exp_f32_e32 v17, v24                                     // 0000001B2638: 7E224B18
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v28                  // 0000001B263C: 7C3C38FF 42CE8ED0
	.long 0x7f4239c8                                           // 0000001B2644: 7F4239C8
	v_exp_f32_e32 v24, v25                                     // 0000001B2648: 7E304B19
	v_cvt_i32_f32_e32 v25, v29                                 // 0000001B264C: 7E32111D
	v_add_f32_e32 v9, 1.0, v9                                  // 0000001B2650: 061212F2
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 0000001B2654: 02161680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v28                  // 0000001B2658: 7C3638FF C2B17218
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_4)   // 0000001B2660: BF870206
	.long 0xd71c0011                                           // 0000001B2664: D71C0011
	v_cndmask_b32_e32 v1, v17, v25, vcc_lo                     // 0000001B2668: 02023311
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B266C: BF870214
	v_div_scale_f32 v25, null, v9, v9, v2                      // 0000001B2670: D6FC7C19 040A1309
	v_cndmask_b32_e32 v11, 0x7f800000, v11, vcc_lo             // 0000001B2678: 021616FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v19                  // 0000001B2680: 7C3C26FF 42CE8ED0
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B2688: BF870215
	.long 0xd71c0018                                           // 0000001B268C: D71C0018
	v_cndmask_b32_e32 v1, v24, v26, vcc_lo                     // 0000001B2690: 02023518
	v_rcp_f32_e32 v26, v25                                     // 0000001B2694: 7E345519
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B2698: BF870003
	v_add_f32_e32 v11, 1.0, v11                                // 0000001B269C: 061616F2
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000001B26A0: 02222280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v21                  // 0000001B26A4: 7C3C2AFF 42CE8ED0
	v_cndmask_b32_e32 v24, 0, v24, vcc_lo                      // 0000001B26AC: 02303080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v19                  // 0000001B26B0: 7C3626FF C2B17218
	v_div_scale_f32 v19, null, v11, v11, v3                    // 0000001B26B8: D6FC7C13 040E170B
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 0000001B26C0: 022222FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v21                  // 0000001B26C8: 7C362AFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B26D0: BF870113
	v_rcp_f32_e32 v27, v19                                     // 0000001B26D4: 7E365513
	v_add_f32_e32 v17, 1.0, v17                                // 0000001B26D8: 062222F2
	v_cndmask_b32_e32 v21, 0x7f800000, v24, vcc_lo             // 0000001B26DC: 022A30FF 7F800000
	v_fma_f32 v24, -v25, v26, 1.0                              // 0000001B26E4: D6130018 23CA3519
	s_mov_b32 vcc_lo, s0                                       // 0000001B26EC: BEEA0000
	v_div_fixup_f32 v0, v8, v18, v0                            // 0000001B26F0: D6270000 04022508
	v_div_scale_f32 v28, null, v17, v17, v4                    // 0000001B26F8: D6FC7C1C 04122311
	v_add_f32_e32 v21, 1.0, v21                                // 0000001B2700: 062A2AF2
	v_div_fmas_f32 v12, v13, v12, v16                          // 0000001B2704: D637000C 0442190D
	v_fmac_f32_e32 v26, v24, v26                               // 0000001B270C: 56343518
	v_div_scale_f32 v16, vcc_lo, v2, v9, v2                    // 0000001B2710: D6FC6A10 040A1302
	v_rcp_f32_e32 v13, v28                                     // 0000001B2718: 7E1A551C
	v_div_scale_f32 v24, null, v21, v21, v5                    // 0000001B271C: D6FC7C18 04162B15
	v_fma_f32 v29, -v19, v27, 1.0                              // 0000001B2724: D613001D 23CA3713
	v_div_fixup_f32 v1, v12, v20, v1                           // 0000001B272C: D6270001 0406290C
	v_mul_f32_e32 v10, v16, v26                                // 0000001B2734: 10143510
	v_div_scale_f32 v20, s0, v3, v11, v3                       // 0000001B2738: D6FC0014 040E1703
	v_rcp_f32_e32 v12, v24                                     // 0000001B2740: 7E185518
	v_fmac_f32_e32 v27, v29, v27                               // 0000001B2744: 5636371D
	.long 0x7e903981                                           // 0000001B2748: 7E903981
	v_fma_f32 v8, -v25, v10, v16                               // 0000001B274C: D6130008 24421519
	v_fma_f32 v29, -v28, v13, 1.0                              // 0000001B2754: D613001D 23CA1B1C
	.long 0x7e423980                                           // 0000001B275C: 7E423980
	v_mul_f32_e32 v18, v20, v27                                // 0000001B2760: 10243714
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B2764: BF870293
	v_dual_fmac_f32 v10, v8, v26 :: v_dual_fmac_f32 v13, v29, v13// 0000001B2768: C8003508 0A0C1B1D
	v_fma_f32 v32, -v24, v12, 1.0                              // 0000001B2770: D6130020 23CA1918
	v_div_scale_f32 v29, s1, v4, v17, v4                       // 0000001B2778: D6FC011D 04122304
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B2780: BF870214
	v_fma_f32 v8, -v19, v18, v20                               // 0000001B2784: D6130008 24522513
	v_fma_f32 v16, -v25, v10, v16                              // 0000001B278C: D6130010 24421519
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B2794: BF870004
	v_fmac_f32_e32 v12, v32, v12                               // 0000001B2798: 56181920
	v_div_scale_f32 v32, s2, v5, v21, v5                       // 0000001B279C: D6FC0220 04162B05
	v_mul_f32_e32 v34, v29, v13                                // 0000001B27A4: 10441B1D
	v_fmac_f32_e32 v18, v8, v27                                // 0000001B27A8: 56243708
	v_div_fmas_f32 v10, v16, v26, v10                          // 0000001B27AC: D637000A 042A3510
	s_mov_b32 vcc_lo, s0                                       // 0000001B27B4: BEEA0000
	v_mul_f32_e32 v25, v32, v12                                // 0000001B27B8: 10321920
	v_fma_f32 v8, -v28, v34, v29                               // 0000001B27BC: D6130008 2476451C
	v_fma_f32 v16, -v19, v18, v20                              // 0000001B27C4: D6130010 24522513
	v_div_fixup_f32 v2, v10, v9, v2                            // 0000001B27CC: D6270002 040A130A
	v_and_b32_e32 v10, 1, v33                                  // 0000001B27D4: 36144281
	v_fma_f32 v19, -v24, v25, v32                              // 0000001B27D8: D6130013 24823318
	v_fmac_f32_e32 v34, v8, v13                                // 0000001B27E0: 56441B08
	v_div_fmas_f32 v8, v16, v27, v18                           // 0000001B27E4: D6370008 044A3710
	s_mov_b32 vcc_lo, s1                                       // 0000001B27EC: BEEA0001
	v_and_b32_e32 v16, 1, v72                                  // 0000001B27F0: 36209081
	v_fmac_f32_e32 v25, v19, v12                               // 0000001B27F4: 56321913
	v_fma_f32 v9, -v28, v34, v29                               // 0000001B27F8: D6130009 2476451C
	v_div_fixup_f32 v3, v8, v11, v3                            // 0000001B2800: D6270003 040E1708
	.long 0x7f1639c8                                           // 0000001B2808: 7F1639C8
	v_add3_u32 v0, v0, v10, 0x7fff                             // 0000001B280C: D6550000 03FE1500 00007FFF
	v_fma_f32 v8, -v24, v25, v32                               // 0000001B2818: D6130008 24823318
	v_div_fmas_f32 v9, v9, v13, v34                            // 0000001B2820: D6370009 048A1B09
	s_mov_b32 vcc_lo, s2                                       // 0000001B2828: BEEA0002
	.long 0x7e903983                                           // 0000001B282C: 7E903983
	v_add3_u32 v1, v1, v16, 0x7fff                             // 0000001B2830: D6550001 03FE2101 00007FFF
	v_div_fmas_f32 v8, v8, v12, v25                            // 0000001B283C: D6370008 04661908
	v_div_fixup_f32 v4, v9, v17, v4                            // 0000001B2844: D6270004 04122309
	.long 0x7e123982                                           // 0000001B284C: 7E123982
	.long 0x7f1239c8                                           // 0000001B2850: 7F1239C8
	global_store_d16_hi_b16 v[6:7], v0, off offset:224         // 0000001B2854: DC9600E0 007C0006
	v_div_fixup_f32 v5, v8, v21, v5                            // 0000001B285C: D6270005 04162B08
	.long 0x7e163984                                           // 0000001B2864: 7E163984
	v_and_b32_e32 v8, 1, v72                                   // 0000001B2868: 36109081
	v_and_b32_e32 v9, 1, v9                                    // 0000001B286C: 36121281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B2870: BF870214
	.long 0x7e903985                                           // 0000001B2874: 7E903985
	v_and_b32_e32 v10, 1, v11                                  // 0000001B2878: 36141681
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B287C: BF870223
	v_add3_u32 v0, v2, v9, 0x7fff                              // 0000001B2880: D6550000 03FE1302 00007FFF
	v_add3_u32 v2, v3, v8, 0x7fff                              // 0000001B288C: D6550002 03FE1103 00007FFF
	v_and_b32_e32 v11, 1, v72                                  // 0000001B2898: 36169081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B289C: BF870114
	v_add3_u32 v3, v4, v10, 0x7fff                             // 0000001B28A0: D6550003 03FE1504 00007FFF
	v_add3_u32 v4, v5, v11, 0x7fff                             // 0000001B28AC: D6550004 03FE1705 00007FFF
	s_clause 0x4                                               // 0000001B28B8: BF850004
	global_store_d16_hi_b16 v[46:47], v1, off offset:224       // 0000001B28BC: DC9600E0 007C012E
	global_store_d16_hi_b16 v[14:15], v0, off offset:224       // 0000001B28C4: DC9600E0 007C000E
	global_store_d16_hi_b16 v[22:23], v2, off offset:224       // 0000001B28CC: DC9600E0 007C0216
	global_store_d16_hi_b16 v[30:31], v3, off offset:224       // 0000001B28D4: DC9600E0 007C031E
	global_store_d16_hi_b16 v[38:39], v4, off offset:224       // 0000001B28DC: DC9600E0 007C0426
	s_nop 0                                                    // 0000001B28E4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001B28E8: BFB60003
	s_endpgm                                                   // 0000001B28EC: BFB00000
		...

