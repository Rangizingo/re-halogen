00000000000fa000 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000FA000: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000FA004: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000FA00C: F4080500 F8000048
	s_lshl_b32 s26, s3, 5                                      // 0000000FA014: 841A8503
	s_ashr_i32 s3, s2, 31                                      // 0000000FA018: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000FA01C: 861B9F1A
	v_and_b32_e32 v8, 31, v0                                   // 0000000FA020: 3610009F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000FA024: BF8704C1
	v_dual_mov_b32 v4, v0 :: v_dual_lshlrev_b32 v1, 2, v8      // 0000000FA028: CA220100 04001082
	s_waitcnt lgkmcnt(0)                                       // 0000000FA030: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000FA034: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000FA03C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000FA040: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000FA044: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000FA048: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FA04C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000FA050: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000FA054: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000FA058: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000FA05C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000FA064: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000FA06C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000FA070: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000FA074: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000FA078: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000FA07C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000FA080: 821E191E
	.long 0xd7001f02                                           // 0000000FA084: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000FA088: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000FA08C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000FA094: BE9E0080
	s_nop 0                                                    // 0000000FA098: BF800000
	s_nop 0                                                    // 0000000FA09C: BF800000
	s_nop 0                                                    // 0000000FA0A0: BF800000
	s_nop 0                                                    // 0000000FA0A4: BF800000
	s_nop 0                                                    // 0000000FA0A8: BF800000
	s_nop 0                                                    // 0000000FA0AC: BF800000
	s_nop 0                                                    // 0000000FA0B0: BF800000
	s_nop 0                                                    // 0000000FA0B4: BF800000
	s_nop 0                                                    // 0000000FA0B8: BF800000
	s_nop 0                                                    // 0000000FA0BC: BF800000
	v_lshrrev_b32_e32 v7, 5, v4                                // 0000000FA0C0: 320E0885
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000FA0C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA0CC: BF870092
	v_lshlrev_b32_e32 v5, 9, v7                                // 0000000FA0D0: 300A0E89
	.long 0xd7006a05                                           // 0000000FA0D4: D7006A05
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 0000000FA0D8: 02020B02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FA0DC: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v3, vcc_lo                // 0000000FA0E0: D5207C06 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0xf7f, v4                         // 0000000FA0E8: 7C9208FF 00000F7F
	v_mov_b32_e32 v4, v10                                      // 0000000FA0F0: 7E08030A
	global_load_b32 v9, v[5:6], off                            // 0000000FA0F4: DC520000 097C0005
	v_mad_u64_u32 v[5:6], null, 0x84, v7, v[1:2]               // 0000000FA0FC: D6FE7C05 04060EFF 00000084
	s_or_b32 s30, vcc_lo, s30                                  // 0000000FA108: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000FA10C: BF8903F7
	ds_store_b32 v5, v9                                        // 0000000FA110: D8340000 00000905
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000FA118: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000FA11C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000FA120: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000FA124: F4000780 F8000058
	v_or_b32_e32 v43, 0xffffff80, v0                           // 0000000FA12C: 385600FF FFFFFF80
	v_lshrrev_b32_e32 v2, 5, v0                                // 0000000FA134: 32040085
	s_mov_b32 s0, 0                                            // 0000000FA138: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000FA13C: BF89FC07
	s_barrier                                                  // 0000000FA140: BFBD0000
	buffer_gl0_inv                                             // 0000000FA144: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000FA14C: BF02801E
	s_cbranch_scc1 11                                          // 0000000FA150: BFA2000B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x180>
	v_lshrrev_b32_e32 v3, 5, v0                                // 0000000FA154: 32060085
	v_mov_b32_e32 v4, 0                                        // 0000000FA158: 7E080280
	v_or_b32_e32 v7, 0xffffff80, v0                            // 0000000FA15C: 380E00FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FA164: BF870002
	v_dual_mov_b32 v6, v4 :: v_dual_mov_b32 v5, v3             // 0000000FA168: CA100104 06040103
	v_lshlrev_b32_e32 v4, 2, v8                                // 0000000FA170: 30081082
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000FA174: 916A007E
	s_cbranch_vccz 2                                           // 0000000FA178: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	s_branch 2590                                              // 0000000FA17C: BFA00A1E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x29f8>
	v_lshlrev_b32_e32 v4, 2, v8                                // 0000000FA180: 30081082
	s_add_i32 s0, s30, 63                                      // 0000000FA184: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000FA188: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000FA190: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000FA194: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000FA198: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000FA19C: 84008702
	v_lshlrev_b32_e32 v5, 1, v8                                // 0000000FA1A0: 300A1081
	s_ashr_i32 s1, s0, 31                                      // 0000000FA1A4: 86019F00
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v44, 2, v0      // 0000000FA1A8: CA220080 032C0082
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000FA1B0: 84808100
	v_lshlrev_b32_e32 v11, 8, v2                               // 0000000FA1B4: 30160488
	s_add_u32 s22, s22, s0                                     // 0000000FA1B8: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000FA1BC: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000FA1C0: 848A811A
	v_add_nc_u32_e32 v45, 0x8340, v44                          // 0000000FA1C4: 4A5A58FF 00008340
	s_add_u32 s10, s22, s10                                    // 0000000FA1CC: 800A0A16
	s_addc_u32 s1, s1, s11                                     // 0000000FA1D0: 82010B01
	.long 0xd7000a09                                           // 0000000FA1D4: D7000A09
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000000FA1D8: 02020A0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FA1DC: BF870001
	v_add_co_ci_u32_e64 v10, null, s1, 0, s10                  // 0000000FA1E0: D5207C0A 00290001
	.long 0xd7000137                                           // 0000000FA1E8: D7000137
	v_cndmask_b32_e32 v1, s4, v44, vcc_lo                      // 0000000FA1EC: 02025804
	.long 0xd7000439                                           // 0000000FA1F0: D7000439
	v_cndmask_b32_e32 v1, s6, v44, vcc_lo                      // 0000000FA1F4: 02025806
	v_add_co_ci_u32_e64 v56, null, s5, 0, s1                   // 0000000FA1F8: D5207C38 00050005
	s_movk_i32 s1, 0x204                                       // 0000000FA200: B0010204
	v_add_co_ci_u32_e64 v58, null, s7, 0, s4                   // 0000000FA204: D5207C3A 00110007
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000FA20C: 84848E02
	v_mad_u32_u24 v59, v2, s1, 0x6300                          // 0000000FA210: D60B003B 03FC0302 00006300
	s_add_u32 s1, s14, s4                                      // 0000000FA21C: 8001040E
	s_addc_u32 s4, s15, s5                                     // 0000000FA220: 8204050F
	.long 0xd700010b                                           // 0000000FA224: D700010B
	v_cndmask_b32_e32 v1, s1, v11, vcc_lo                      // 0000000FA228: 02021601
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FA22C: BF870001
	v_add_co_ci_u32_e64 v12, null, s4, 0, s1                   // 0000000FA230: D5207C0C 00050004
	s_lshl_b64 s[4:5], s[2:3], 9                               // 0000000FA238: 84848902
	v_mov_b32_e32 v6, v3                                       // 0000000FA23C: 7E0C0303
	v_dual_mov_b32 v5, v2 :: v_dual_add_nc_u32 v46, 0x8440, v44// 0000000FA240: CA200102 052E58FF 00008440
	v_or_b32_e32 v3, s4, v44                                   // 0000000FA24C: 38065804
	.long 0xd700010d                                           // 0000000FA250: D700010D
	v_cndmask_b32_e32 v1, 0x1000, v11, vcc_lo                  // 0000000FA254: 020216FF 00001000
	v_dual_mov_b32 v18, s5 :: v_dual_add_nc_u32 v47, 1, v2     // 0000000FA25C: CA200005 122E0481
	v_add_co_ci_u32_e64 v14, null, 0, v12, s1                  // 0000000FA264: D5207C0E 00061880
	.long 0xd700010f                                           // 0000000FA26C: D700010F
	v_cndmask_b32_e32 v1, 0x2000, v11, vcc_lo                  // 0000000FA270: 020216FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FA278: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000FA27C: D5207C10 00061880
	.long 0xd7000111                                           // 0000000FA284: D7000111
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 0000000FA288: 02020606
	v_add_co_ci_u32_e64 v18, null, s7, v18, s1                 // 0000000FA28C: D5207C12 00062407
	.long 0xd7000113                                           // 0000000FA294: D7000113
	v_cndmask_b32_e32 v1, 0x3000, v11, vcc_lo                  // 0000000FA298: 020216FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000FA2A0: BF870211
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000FA2A4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000FA2AC: D7000115
	v_cndmask_b32_e32 v1, 0x60000, v17, vcc_lo                 // 0000000FA2B0: 020222FF 00060000
	.long 0xd7000b30                                           // 0000000FA2B8: D7000B30
	v_cndmask_b32_e32 v1, s12, v44, vcc_lo                     // 0000000FA2BC: 0202580C
	v_add_co_ci_u32_e64 v22, null, 0, v18, s1                  // 0000000FA2C0: D5207C16 00062480
	.long 0xd7000117                                           // 0000000FA2C8: D7000117
	v_cndmask_b32_e32 v1, 0xc0000, v17, vcc_lo                 // 0000000FA2CC: 020222FF 000C0000
	v_add_co_ci_u32_e64 v49, null, s13, 0, s11                 // 0000000FA2D4: D5207C31 002D000D
	.long 0xd7000b32                                           // 0000000FA2DC: D7000B32
	v_cndmask_b32_e32 v1, s34, v4, vcc_lo                      // 0000000FA2E0: 02020822
	v_add_co_ci_u32_e64 v24, null, 0, v18, s1                  // 0000000FA2E4: D5207C18 00062480
	.long 0xd7000119                                           // 0000000FA2EC: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v17, vcc_lo                // 0000000FA2F0: 020222FF 00120000
	.long 0xd44c0000                                           // 0000000FA2F8: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000000FA2FC: 020200FF 00000200
	v_add_nc_u32_e32 v7, 0x6300, v44                           // 0000000FA304: 4A0E58FF 00006300
	v_add_co_ci_u32_e64 v51, null, s35, 0, s11                 // 0000000FA30C: D5207C33 002D0023
	v_or_b32_e32 v8, 0x4200, v1                                // 0000000FA314: 381002FF 00004200
	v_add_nc_u32_e32 v52, 17, v2                               // 0000000FA31C: 4A680491
	v_add_nc_u32_e32 v53, 33, v2                               // 0000000FA320: 4A6A04A1
	v_add_nc_u32_e32 v54, 49, v2                               // 0000000FA324: 4A6C04B1
	v_add_co_ci_u32_e64 v26, null, 0, v18, s1                  // 0000000FA328: D5207C1A 00062480
	s_mov_b32 s5, 0                                            // 0000000FA330: BE850080
	s_mov_b32 s6, 0                                            // 0000000FA334: BE860080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000FA338: 7C9800C0
	s_mul_i32 s1, s6, 0xc00                                    // 0000000FA33C: 9601FF06 00000C00
	s_lshl_b32 s7, s6, 6                                       // 0000000FA344: 84078606
	s_add_i32 s10, s31, s1                                     // 0000000FA348: 810A011F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000FA34C: BF870499
	s_ashr_i32 s11, s10, 31                                    // 0000000FA350: 860B9F0A
	s_lshl_b64 s[10:11], s[10:11], 2                           // 0000000FA354: 848A820A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FA358: BF870009
	s_add_u32 s10, s8, s10                                     // 0000000FA35C: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 0000000FA360: 820B0B09
	s_load_b32 s10, s[10:11], null                             // 0000000FA364: F4000285 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000FA36C: BE84206A
	s_cbranch_execz 79                                         // 0000000FA370: BFA5004F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4b0>
	v_or_b32_e32 v3, s7, v0                                    // 0000000FA374: 38060007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA378: BF870091
	v_mad_u64_u32 v[27:28], null, v3, 48, s[2:3]               // 0000000FA37C: D6FE7C1B 00096103
	v_ashrrev_i32_e32 v28, 31, v27                             // 0000000FA384: 3438369F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA388: BF870091
	.long 0xd73c001b                                           // 0000000FA38C: D73C001B
	v_cndmask_b32_e32 v1, 2, v27, vcc_lo                       // 0000000FA390: 02023682
	.long 0xd700011b                                           // 0000000FA394: D700011B
	v_cndmask_b32_e32 v1, s8, v27, vcc_lo                      // 0000000FA398: 02023608
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FA39C: BF8700D1
	v_add_co_ci_u32_e64 v28, null, s9, v28, s1                 // 0000000FA3A0: D5207C1C 00063809
	global_load_b32 v3, v[27:28], off                          // 0000000FA3A8: DC520000 037C001B
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FA3B0: BF890007
	v_sub_f32_e32 v27, s10, v3                                 // 0000000FA3B4: 0836060A
	v_mul_f32_e32 v29, 0x3fb8aa3b, v3                          // 0000000FA3B8: 103A06FF 3FB8AA3B
	v_rndne_f32_e32 v33, v29                                   // 0000000FA3C0: 7E42471D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000FA3C4: BF8701A3
	v_mul_f32_e32 v28, 0x3fb8aa3b, v27                         // 0000000FA3C8: 103836FF 3FB8AA3B
	v_fma_f32 v32, 0x3fb8aa3b, v3, -v29                        // 0000000FA3D0: D6130020 847606FF 3FB8AA3B
	v_sub_f32_e32 v29, v29, v33                                // 0000000FA3DC: 083A431D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000FA3E0: BF870223
	v_fma_f32 v30, 0x3fb8aa3b, v27, -v28                       // 0000000FA3E4: D613001E 847236FF 3FB8AA3B
	v_rndne_f32_e32 v31, v28                                   // 0000000FA3F0: 7E3E471C
	v_fmac_f32_e32 v32, 0x32a5705f, v3                         // 0000000FA3F4: 564006FF 32A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000FA3FC: BF870113
	v_fmac_f32_e32 v30, 0x32a5705f, v27                        // 0000000FA400: 563C36FF 32A5705F
	v_dual_sub_f32 v28, v28, v31 :: v_dual_add_f32 v29, v29, v32// 0000000FA408: C9483F1C 1C1C411D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000FA410: BF870111
	v_add_f32_e32 v28, v28, v30                                // 0000000FA414: 06383D1C
	v_exp_f32_e32 v29, v29                                     // 0000000FA418: 7E3A4B1D
	v_cvt_i32_f32_e32 v30, v31                                 // 0000000FA41C: 7E3C111F
	v_cvt_i32_f32_e32 v31, v33                                 // 0000000FA420: 7E3E1121
	.long 0xd41b0001                                           // 0000000FA424: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v27, vcc_lo              // 0000000FA428: 020236FF C2CE8ED0
	v_exp_f32_e32 v28, v28                                     // 0000000FA430: 7E384B1C
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 0000000FA434: BF870106
	.long 0xd71c001d                                           // 0000000FA438: D71C001D
	v_cndmask_b32_e32 v1, v29, v31, vcc_lo                     // 0000000FA43C: 02023F1D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA440: BF870095
	.long 0xd71c001c                                           // 0000000FA444: D71C001C
	v_cndmask_b32_e32 v1, v28, v30, vcc_lo                     // 0000000FA448: 02023D1C
	v_cndmask_b32_e64 v28, 0, v28, s1                          // 0000000FA44C: D501001C 00063880
	.long 0xd41b0001                                           // 0000000FA454: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v3, vcc_lo               // 0000000FA458: 020206FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FA460: BF8700A1
	v_cndmask_b32_e64 v29, 0, v29, s1                          // 0000000FA464: D501001D 00063A80
	.long 0xd41e0001                                           // 0000000FA46C: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v27, vcc_lo              // 0000000FA470: 020236FF 42B17218
	v_cndmask_b32_e64 v27, 0x7f800000, v28, s1                 // 0000000FA478: D501001B 000638FF 7F800000
	.long 0xd41e0001                                           // 0000000FA484: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v3, vcc_lo               // 0000000FA488: 020206FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FA490: BF870001
	v_cndmask_b32_e64 v3, 0x7f800000, v29, s1                  // 0000000FA494: D5010003 00063AFF 7F800000
	ds_store_b32 v45, v27                                      // 0000000FA4A0: D8340000 00001B2D
	ds_store_b32 v46, v3                                       // 0000000FA4A8: D8340000 0000032E
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FA4B0: 8C7E047E
	v_mov_b32_e32 v3, v0                                       // 0000000FA4B4: 7E060300
	s_mov_b32 s4, 0                                            // 0000000FA4B8: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000000FA4BC: BF89FC07
	s_barrier                                                  // 0000000FA4C0: BFBD0000
	buffer_gl0_inv                                             // 0000000FA4C4: E0AC0000 00000000
	s_nop 0                                                    // 0000000FA4CC: BF800000
	s_nop 0                                                    // 0000000FA4D0: BF800000
	s_nop 0                                                    // 0000000FA4D4: BF800000
	s_nop 0                                                    // 0000000FA4D8: BF800000
	s_nop 0                                                    // 0000000FA4DC: BF800000
	s_nop 0                                                    // 0000000FA4E0: BF800000
	s_nop 0                                                    // 0000000FA4E4: BF800000
	s_nop 0                                                    // 0000000FA4E8: BF800000
	s_nop 0                                                    // 0000000FA4EC: BF800000
	s_nop 0                                                    // 0000000FA4F0: BF800000
	s_nop 0                                                    // 0000000FA4F4: BF800000
	s_nop 0                                                    // 0000000FA4F8: BF800000
	s_nop 0                                                    // 0000000FA4FC: BF800000
	v_lshrrev_b32_e32 v29, 7, v3                               // 0000000FA500: 323A0687
	v_add_nc_u32_e32 v31, 0x80, v3                             // 0000000FA504: 4A3E06FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA50C: BF870092
	v_or_b32_e32 v27, s7, v29                                  // 0000000FA510: 38363A07
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000FA514: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA51C: BF870091
	.long 0xd73c001b                                           // 0000000FA520: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000FA524: 02023689
	.long 0xd700011b                                           // 0000000FA528: D700011B
	v_cndmask_b32_e32 v1, v48, v27, vcc_lo                     // 0000000FA52C: 02023730
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FA530: BF870001
	v_add_co_ci_u32_e64 v28, null, v49, v28, s1                // 0000000FA534: D5207C1C 00063931
	.long 0xd4490001                                           // 0000000FA53C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000FA540: 020206FF 0000077F
	v_mov_b32_e32 v3, v31                                      // 0000000FA548: 7E06031F
	global_load_b32 v30, v[27:28], off                         // 0000000FA54C: DC520000 1E7C001B
	v_mad_u64_u32 v[27:28], null, 0x204, v29, v[7:8]           // 0000000FA554: D6FE7C1B 041E3AFF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000FA560: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000FA564: BF8903F7
	ds_store_b32 v27, v30                                      // 0000000FA568: D8340000 00001E1B
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FA570: 917E047E
	s_cbranch_execnz 65506                                     // 0000000FA574: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x500>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FA578: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000FA57C: BF89FC07
	s_barrier                                                  // 0000000FA580: BFBD0000
	buffer_gl0_inv                                             // 0000000FA584: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000FA58C: BE842000
	s_cbranch_execz 123                                        // 0000000FA590: BFA5007B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x780>
	v_mov_b32_e32 v3, v59                                      // 0000000FA594: 7E06033B
	v_mov_b32_e32 v27, v0                                      // 0000000FA598: 7E360300
	s_mov_b32 s11, 0                                           // 0000000FA59C: BE8B0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA5A0: BF870091
	v_lshrrev_b32_e32 v28, 5, v27                              // 0000000FA5A4: 32383685
	v_or_b32_e32 v29, s7, v28                                  // 0000000FA5A8: 383A3807
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA5AC: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000FA5B0: D6FE7C1D 0009611D
	.long 0xd73c001d                                           // 0000000FA5B8: D73C001D
	v_cndmask_b32_e32 v1, 9, v29, vcc_lo                       // 0000000FA5BC: 02023A89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA5C0: BF870091
	.long 0xd700011d                                           // 0000000FA5C4: D700011D
	v_cndmask_b32_e32 v1, v50, v29, vcc_lo                     // 0000000FA5C8: 02023B32
	v_add_co_ci_u32_e64 v30, null, v51, v30, s1                // 0000000FA5CC: D5207C1E 00063D33
	s_movk_i32 s1, 0xfe00                                      // 0000000FA5D4: B001FE00
	global_load_b32 v30, v[29:30], off                         // 0000000FA5D8: DC520000 1E7C001D
	v_mov_b32_e32 v29, v1                                      // 0000000FA5E0: 7E3A0301
	v_add_nc_u32_e32 v62, s1, v3                               // 0000000FA5E4: 4A7C0601
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FA5E8: BF870002
	v_add_nc_u32_e32 v63, 0x400, v29                           // 0000000FA5EC: 4A7E3AFF 00000400
	s_add_i32 s1, s1, 64                                       // 0000000FA5F4: 8101C001
	ds_load_2addr_b32 v[31:32], v29 offset1:33                 // 0000000FA5F8: D8DC2100 1F00001D
	ds_load_2addr_b32 v[33:34], v62 offset0:128 offset1:129    // 0000000FA600: D8DC8180 2100003E
	ds_load_2addr_b32 v[35:36], v29 offset0:66 offset1:99      // 0000000FA608: D8DC6342 2300001D
	ds_load_2addr_b32 v[37:38], v62 offset0:130 offset1:131    // 0000000FA610: D8DC8382 2500003E
	ds_load_2addr_b32 v[39:40], v29 offset0:132 offset1:165    // 0000000FA618: D8DCA584 2700001D
	ds_load_2addr_b32 v[41:42], v62 offset0:132 offset1:133    // 0000000FA620: D8DC8584 2900003E
	ds_load_2addr_b32 v[60:61], v62 offset0:134 offset1:135    // 0000000FA628: D8DC8786 3C00003E
	s_cmp_eq_u32 s1, 0                                         // 0000000FA630: BF068001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000FA634: BF890057
	v_fma_f32 v30, -v33, v31, v30                              // 0000000FA638: D613001E 247A3F21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FA640: BF8700D1
	v_fma_f32 v32, -v34, v32, v30                              // 0000000FA644: D6130020 247A4122
	ds_load_2addr_b32 v[30:31], v29 offset0:198 offset1:231    // 0000000FA64C: D8DCE7C6 1E00001D
	v_add_nc_u32_e32 v29, 0x840, v29                           // 0000000FA654: 4A3A3AFF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FA65C: BF89FC47
	v_fma_f32 v32, -v37, v35, v32                              // 0000000FA660: D6130020 24824725
	v_fma_f32 v36, -v38, v36, v32                              // 0000000FA668: D6130024 24824926
	ds_load_2addr_b32 v[32:33], v62 offset0:136 offset1:137    // 0000000FA670: D8DC8988 2000003E
	ds_load_2addr_b32 v[34:35], v63 offset0:8 offset1:41       // 0000000FA678: D8DC2908 2200003F
	s_waitcnt lgkmcnt(4)                                       // 0000000FA680: BF89FC47
	v_fma_f32 v36, -v41, v39, v36                              // 0000000FA684: D6130024 24924F29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FA68C: BF8700D1
	v_fma_f32 v40, -v42, v40, v36                              // 0000000FA690: D6130028 2492512A
	ds_load_2addr_b32 v[36:37], v62 offset0:138 offset1:139    // 0000000FA698: D8DC8B8A 2400003E
	ds_load_2addr_b32 v[38:39], v63 offset0:74 offset1:107     // 0000000FA6A0: D8DC6B4A 2600003F
	s_waitcnt lgkmcnt(4)                                       // 0000000FA6A8: BF89FC47
	v_fma_f32 v30, -v60, v30, v40                              // 0000000FA6AC: D613001E 24A23D3C
	v_fma_f32 v42, -v61, v31, v30                              // 0000000FA6B4: D613002A 247A3F3D
	ds_load_2addr_b32 v[30:31], v63 offset0:140 offset1:173    // 0000000FA6BC: D8DCAD8C 1E00003F
	ds_load_2addr_b32 v[40:41], v62 offset0:140 offset1:141    // 0000000FA6C4: D8DC8D8C 2800003E
	ds_load_2addr_b32 v[60:61], v62 offset0:142 offset1:143    // 0000000FA6CC: D8DC8F8E 3C00003E
	s_waitcnt lgkmcnt(5)                                       // 0000000FA6D4: BF89FC57
	v_fma_f32 v32, -v32, v34, v42                              // 0000000FA6D8: D6130020 24AA4520
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FA6E0: BF8700C1
	v_fma_f32 v34, -v33, v35, v32                              // 0000000FA6E4: D6130022 24824721
	ds_load_2addr_b32 v[32:33], v63 offset0:206 offset1:239    // 0000000FA6EC: D8DCEFCE 2000003F
	s_waitcnt lgkmcnt(4)                                       // 0000000FA6F4: BF89FC47
	v_fma_f32 v34, -v36, v38, v34                              // 0000000FA6F8: D6130022 248A4D24
	v_fma_f32 v34, -v37, v39, v34                              // 0000000FA700: D6130022 248A4F25
	s_waitcnt lgkmcnt(2)                                       // 0000000FA708: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA70C: BF870091
	v_fma_f32 v30, -v40, v30, v34                              // 0000000FA710: D613001E 248A3D28
	v_fma_f32 v30, -v41, v31, v30                              // 0000000FA718: D613001E 247A3F29
	s_waitcnt lgkmcnt(0)                                       // 0000000FA720: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA724: BF870091
	v_fma_f32 v30, -v60, v32, v30                              // 0000000FA728: D613001E 247A413C
	v_fma_f32 v30, -v61, v33, v30                              // 0000000FA730: D613001E 247A433D
	s_cbranch_scc0 65450                                       // 0000000FA738: BFA1FFAA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5e4>
	v_add_nc_u32_e32 v31, 0x80, v27                            // 0000000FA73C: 4A3E36FF 00000080
	v_mad_u64_u32 v[28:29], null, 0x84, v28, v[8:9]            // 0000000FA744: D6FE7C1C 042238FF 00000084
	.long 0xd4490001                                           // 0000000FA750: D4490001
	v_cndmask_b32_e32 v1, 0x17f, v27, vcc_lo                   // 0000000FA754: 020236FF 0000017F
	v_add_nc_u32_e32 v3, 0x810, v3                             // 0000000FA75C: 4A0606FF 00000810
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000FA764: BF870004
	v_mov_b32_e32 v27, v31                                     // 0000000FA768: 7E36031F
	s_or_b32 s11, s1, s11                                      // 0000000FA76C: 8C0B0B01
	ds_store_b32 v28, v30                                      // 0000000FA770: D8340000 00001E1C
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000FA778: 917E0B7E
	s_cbranch_execnz 65416                                     // 0000000FA77C: BFA6FF88 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5a0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FA780: 8C7E047E
	v_mov_b32_e32 v3, v0                                       // 0000000FA784: 7E060300
	s_or_b32 s13, s7, 16                                       // 0000000FA788: 8C0D9007
	s_mov_b32 s4, 0                                            // 0000000FA78C: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000000FA790: BF89FC07
	s_barrier                                                  // 0000000FA794: BFBD0000
	buffer_gl0_inv                                             // 0000000FA798: E0AC0000 00000000
	s_nop 0                                                    // 0000000FA7A0: BF800000
	s_nop 0                                                    // 0000000FA7A4: BF800000
	s_nop 0                                                    // 0000000FA7A8: BF800000
	s_nop 0                                                    // 0000000FA7AC: BF800000
	s_nop 0                                                    // 0000000FA7B0: BF800000
	s_nop 0                                                    // 0000000FA7B4: BF800000
	s_nop 0                                                    // 0000000FA7B8: BF800000
	s_nop 0                                                    // 0000000FA7BC: BF800000
	v_lshrrev_b32_e32 v29, 7, v3                               // 0000000FA7C0: 323A0687
	v_add_nc_u32_e32 v31, 0x80, v3                             // 0000000FA7C4: 4A3E06FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA7CC: BF870092
	v_or_b32_e32 v27, s13, v29                                 // 0000000FA7D0: 38363A0D
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000FA7D4: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA7DC: BF870091
	.long 0xd73c001b                                           // 0000000FA7E0: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000FA7E4: 02023689
	.long 0xd700011b                                           // 0000000FA7E8: D700011B
	v_cndmask_b32_e32 v1, v48, v27, vcc_lo                     // 0000000FA7EC: 02023730
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FA7F0: BF870001
	v_add_co_ci_u32_e64 v28, null, v49, v28, s1                // 0000000FA7F4: D5207C1C 00063931
	.long 0xd4490001                                           // 0000000FA7FC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000FA800: 020206FF 0000077F
	v_mov_b32_e32 v3, v31                                      // 0000000FA808: 7E06031F
	global_load_b32 v30, v[27:28], off                         // 0000000FA80C: DC520000 1E7C001B
	v_mad_u64_u32 v[27:28], null, 0x204, v29, v[7:8]           // 0000000FA814: D6FE7C1B 041E3AFF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000FA820: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000FA824: BF8903F7
	ds_store_b32 v27, v30                                      // 0000000FA828: D8340000 00001E1B
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FA830: 917E047E
	s_cbranch_execnz 65506                                     // 0000000FA834: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x7c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FA838: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000FA83C: BF89FC07
	s_barrier                                                  // 0000000FA840: BFBD0000
	buffer_gl0_inv                                             // 0000000FA844: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000FA84C: BE842000
	s_cbranch_execz 123                                        // 0000000FA850: BFA5007B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa40>
	v_mov_b32_e32 v3, v59                                      // 0000000FA854: 7E06033B
	v_mov_b32_e32 v27, v0                                      // 0000000FA858: 7E360300
	s_mov_b32 s11, 0                                           // 0000000FA85C: BE8B0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA860: BF870091
	v_lshrrev_b32_e32 v28, 5, v27                              // 0000000FA864: 32383685
	v_or_b32_e32 v29, s13, v28                                 // 0000000FA868: 383A380D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA86C: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000FA870: D6FE7C1D 0009611D
	.long 0xd73c001d                                           // 0000000FA878: D73C001D
	v_cndmask_b32_e32 v1, 9, v29, vcc_lo                       // 0000000FA87C: 02023A89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA880: BF870091
	.long 0xd700011d                                           // 0000000FA884: D700011D
	v_cndmask_b32_e32 v1, v50, v29, vcc_lo                     // 0000000FA888: 02023B32
	v_add_co_ci_u32_e64 v30, null, v51, v30, s1                // 0000000FA88C: D5207C1E 00063D33
	s_movk_i32 s1, 0xfe00                                      // 0000000FA894: B001FE00
	global_load_b32 v30, v[29:30], off                         // 0000000FA898: DC520000 1E7C001D
	v_mov_b32_e32 v29, v1                                      // 0000000FA8A0: 7E3A0301
	v_add_nc_u32_e32 v62, s1, v3                               // 0000000FA8A4: 4A7C0601
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FA8A8: BF870002
	v_add_nc_u32_e32 v63, 0x400, v29                           // 0000000FA8AC: 4A7E3AFF 00000400
	s_add_i32 s1, s1, 64                                       // 0000000FA8B4: 8101C001
	ds_load_2addr_b32 v[31:32], v29 offset1:33                 // 0000000FA8B8: D8DC2100 1F00001D
	ds_load_2addr_b32 v[33:34], v62 offset0:128 offset1:129    // 0000000FA8C0: D8DC8180 2100003E
	ds_load_2addr_b32 v[35:36], v29 offset0:66 offset1:99      // 0000000FA8C8: D8DC6342 2300001D
	ds_load_2addr_b32 v[37:38], v62 offset0:130 offset1:131    // 0000000FA8D0: D8DC8382 2500003E
	ds_load_2addr_b32 v[39:40], v29 offset0:132 offset1:165    // 0000000FA8D8: D8DCA584 2700001D
	ds_load_2addr_b32 v[41:42], v62 offset0:132 offset1:133    // 0000000FA8E0: D8DC8584 2900003E
	ds_load_2addr_b32 v[60:61], v62 offset0:134 offset1:135    // 0000000FA8E8: D8DC8786 3C00003E
	s_cmp_lg_u32 s1, 0                                         // 0000000FA8F0: BF078001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000FA8F4: BF890057
	v_fma_f32 v30, -v33, v31, v30                              // 0000000FA8F8: D613001E 247A3F21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FA900: BF8700D1
	v_fma_f32 v32, -v34, v32, v30                              // 0000000FA904: D6130020 247A4122
	ds_load_2addr_b32 v[30:31], v29 offset0:198 offset1:231    // 0000000FA90C: D8DCE7C6 1E00001D
	v_add_nc_u32_e32 v29, 0x840, v29                           // 0000000FA914: 4A3A3AFF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FA91C: BF89FC47
	v_fma_f32 v32, -v37, v35, v32                              // 0000000FA920: D6130020 24824725
	v_fma_f32 v36, -v38, v36, v32                              // 0000000FA928: D6130024 24824926
	ds_load_2addr_b32 v[32:33], v62 offset0:136 offset1:137    // 0000000FA930: D8DC8988 2000003E
	ds_load_2addr_b32 v[34:35], v63 offset0:8 offset1:41       // 0000000FA938: D8DC2908 2200003F
	s_waitcnt lgkmcnt(4)                                       // 0000000FA940: BF89FC47
	v_fma_f32 v36, -v41, v39, v36                              // 0000000FA944: D6130024 24924F29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FA94C: BF8700D1
	v_fma_f32 v40, -v42, v40, v36                              // 0000000FA950: D6130028 2492512A
	ds_load_2addr_b32 v[36:37], v62 offset0:138 offset1:139    // 0000000FA958: D8DC8B8A 2400003E
	ds_load_2addr_b32 v[38:39], v63 offset0:74 offset1:107     // 0000000FA960: D8DC6B4A 2600003F
	s_waitcnt lgkmcnt(4)                                       // 0000000FA968: BF89FC47
	v_fma_f32 v30, -v60, v30, v40                              // 0000000FA96C: D613001E 24A23D3C
	v_fma_f32 v42, -v61, v31, v30                              // 0000000FA974: D613002A 247A3F3D
	ds_load_2addr_b32 v[30:31], v63 offset0:140 offset1:173    // 0000000FA97C: D8DCAD8C 1E00003F
	ds_load_2addr_b32 v[40:41], v62 offset0:140 offset1:141    // 0000000FA984: D8DC8D8C 2800003E
	ds_load_2addr_b32 v[60:61], v62 offset0:142 offset1:143    // 0000000FA98C: D8DC8F8E 3C00003E
	s_waitcnt lgkmcnt(5)                                       // 0000000FA994: BF89FC57
	v_fma_f32 v32, -v32, v34, v42                              // 0000000FA998: D6130020 24AA4520
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FA9A0: BF8700C1
	v_fma_f32 v34, -v33, v35, v32                              // 0000000FA9A4: D6130022 24824721
	ds_load_2addr_b32 v[32:33], v63 offset0:206 offset1:239    // 0000000FA9AC: D8DCEFCE 2000003F
	s_waitcnt lgkmcnt(4)                                       // 0000000FA9B4: BF89FC47
	v_fma_f32 v34, -v36, v38, v34                              // 0000000FA9B8: D6130022 248A4D24
	v_fma_f32 v34, -v37, v39, v34                              // 0000000FA9C0: D6130022 248A4F25
	s_waitcnt lgkmcnt(2)                                       // 0000000FA9C8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA9CC: BF870091
	v_fma_f32 v30, -v40, v30, v34                              // 0000000FA9D0: D613001E 248A3D28
	v_fma_f32 v30, -v41, v31, v30                              // 0000000FA9D8: D613001E 247A3F29
	s_waitcnt lgkmcnt(0)                                       // 0000000FA9E0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FA9E4: BF870091
	v_fma_f32 v30, -v60, v32, v30                              // 0000000FA9E8: D613001E 247A413C
	v_fma_f32 v30, -v61, v33, v30                              // 0000000FA9F0: D613001E 247A433D
	s_cbranch_scc1 65450                                       // 0000000FA9F8: BFA2FFAA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8a4>
	v_add_nc_u32_e32 v31, 0x80, v27                            // 0000000FA9FC: 4A3E36FF 00000080
	v_mad_u64_u32 v[28:29], null, 0x84, v28, v[8:9]            // 0000000FAA04: D6FE7C1C 042238FF 00000084
	.long 0xd4490001                                           // 0000000FAA10: D4490001
	v_cndmask_b32_e32 v1, 0x17f, v27, vcc_lo                   // 0000000FAA14: 020236FF 0000017F
	v_add_nc_u32_e32 v3, 0x810, v3                             // 0000000FAA1C: 4A0606FF 00000810
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000FAA24: BF870004
	v_mov_b32_e32 v27, v31                                     // 0000000FAA28: 7E36031F
	s_or_b32 s11, s1, s11                                      // 0000000FAA2C: 8C0B0B01
	ds_store_b32 v28, v30 offset:2112                          // 0000000FAA30: D8340840 00001E1C
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000FAA38: 917E0B7E
	s_cbranch_execnz 65416                                     // 0000000FAA3C: BFA6FF88 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x860>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FAA40: 8C7E047E
	v_mov_b32_e32 v3, v0                                       // 0000000FAA44: 7E060300
	s_or_b32 s12, s7, 32                                       // 0000000FAA48: 8C0CA007
	s_mov_b32 s4, 0                                            // 0000000FAA4C: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000000FAA50: BF89FC07
	s_barrier                                                  // 0000000FAA54: BFBD0000
	buffer_gl0_inv                                             // 0000000FAA58: E0AC0000 00000000
	s_nop 0                                                    // 0000000FAA60: BF800000
	s_nop 0                                                    // 0000000FAA64: BF800000
	s_nop 0                                                    // 0000000FAA68: BF800000
	s_nop 0                                                    // 0000000FAA6C: BF800000
	s_nop 0                                                    // 0000000FAA70: BF800000
	s_nop 0                                                    // 0000000FAA74: BF800000
	s_nop 0                                                    // 0000000FAA78: BF800000
	s_nop 0                                                    // 0000000FAA7C: BF800000
	v_lshrrev_b32_e32 v29, 7, v3                               // 0000000FAA80: 323A0687
	v_add_nc_u32_e32 v31, 0x80, v3                             // 0000000FAA84: 4A3E06FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAA8C: BF870092
	v_or_b32_e32 v27, s12, v29                                 // 0000000FAA90: 38363A0C
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000FAA94: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAA9C: BF870091
	.long 0xd73c001b                                           // 0000000FAAA0: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000FAAA4: 02023689
	.long 0xd700011b                                           // 0000000FAAA8: D700011B
	v_cndmask_b32_e32 v1, v48, v27, vcc_lo                     // 0000000FAAAC: 02023730
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FAAB0: BF870001
	v_add_co_ci_u32_e64 v28, null, v49, v28, s1                // 0000000FAAB4: D5207C1C 00063931
	.long 0xd4490001                                           // 0000000FAABC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000FAAC0: 020206FF 0000077F
	v_mov_b32_e32 v3, v31                                      // 0000000FAAC8: 7E06031F
	global_load_b32 v30, v[27:28], off                         // 0000000FAACC: DC520000 1E7C001B
	v_mad_u64_u32 v[27:28], null, 0x204, v29, v[7:8]           // 0000000FAAD4: D6FE7C1B 041E3AFF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000FAAE0: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000FAAE4: BF8903F7
	ds_store_b32 v27, v30                                      // 0000000FAAE8: D8340000 00001E1B
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FAAF0: 917E047E
	s_cbranch_execnz 65506                                     // 0000000FAAF4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa80>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FAAF8: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000FAAFC: BF89FC07
	s_barrier                                                  // 0000000FAB00: BFBD0000
	buffer_gl0_inv                                             // 0000000FAB04: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000FAB0C: BE842000
	s_cbranch_execz 123                                        // 0000000FAB10: BFA5007B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd00>
	v_mov_b32_e32 v3, v59                                      // 0000000FAB14: 7E06033B
	v_mov_b32_e32 v27, v0                                      // 0000000FAB18: 7E360300
	s_mov_b32 s11, 0                                           // 0000000FAB1C: BE8B0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAB20: BF870091
	v_lshrrev_b32_e32 v28, 5, v27                              // 0000000FAB24: 32383685
	v_or_b32_e32 v29, s12, v28                                 // 0000000FAB28: 383A380C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAB2C: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000FAB30: D6FE7C1D 0009611D
	.long 0xd73c001d                                           // 0000000FAB38: D73C001D
	v_cndmask_b32_e32 v1, 9, v29, vcc_lo                       // 0000000FAB3C: 02023A89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAB40: BF870091
	.long 0xd700011d                                           // 0000000FAB44: D700011D
	v_cndmask_b32_e32 v1, v50, v29, vcc_lo                     // 0000000FAB48: 02023B32
	v_add_co_ci_u32_e64 v30, null, v51, v30, s1                // 0000000FAB4C: D5207C1E 00063D33
	s_movk_i32 s1, 0xfe00                                      // 0000000FAB54: B001FE00
	global_load_b32 v30, v[29:30], off                         // 0000000FAB58: DC520000 1E7C001D
	v_mov_b32_e32 v29, v1                                      // 0000000FAB60: 7E3A0301
	v_add_nc_u32_e32 v62, s1, v3                               // 0000000FAB64: 4A7C0601
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FAB68: BF870002
	v_add_nc_u32_e32 v63, 0x400, v29                           // 0000000FAB6C: 4A7E3AFF 00000400
	s_add_i32 s1, s1, 64                                       // 0000000FAB74: 8101C001
	ds_load_2addr_b32 v[31:32], v29 offset1:33                 // 0000000FAB78: D8DC2100 1F00001D
	ds_load_2addr_b32 v[33:34], v62 offset0:128 offset1:129    // 0000000FAB80: D8DC8180 2100003E
	ds_load_2addr_b32 v[35:36], v29 offset0:66 offset1:99      // 0000000FAB88: D8DC6342 2300001D
	ds_load_2addr_b32 v[37:38], v62 offset0:130 offset1:131    // 0000000FAB90: D8DC8382 2500003E
	ds_load_2addr_b32 v[39:40], v29 offset0:132 offset1:165    // 0000000FAB98: D8DCA584 2700001D
	ds_load_2addr_b32 v[41:42], v62 offset0:132 offset1:133    // 0000000FABA0: D8DC8584 2900003E
	ds_load_2addr_b32 v[60:61], v62 offset0:134 offset1:135    // 0000000FABA8: D8DC8786 3C00003E
	s_cmp_lg_u32 s1, 0                                         // 0000000FABB0: BF078001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000FABB4: BF890057
	v_fma_f32 v30, -v33, v31, v30                              // 0000000FABB8: D613001E 247A3F21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FABC0: BF8700D1
	v_fma_f32 v32, -v34, v32, v30                              // 0000000FABC4: D6130020 247A4122
	ds_load_2addr_b32 v[30:31], v29 offset0:198 offset1:231    // 0000000FABCC: D8DCE7C6 1E00001D
	v_add_nc_u32_e32 v29, 0x840, v29                           // 0000000FABD4: 4A3A3AFF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FABDC: BF89FC47
	v_fma_f32 v32, -v37, v35, v32                              // 0000000FABE0: D6130020 24824725
	v_fma_f32 v36, -v38, v36, v32                              // 0000000FABE8: D6130024 24824926
	ds_load_2addr_b32 v[32:33], v62 offset0:136 offset1:137    // 0000000FABF0: D8DC8988 2000003E
	ds_load_2addr_b32 v[34:35], v63 offset0:8 offset1:41       // 0000000FABF8: D8DC2908 2200003F
	s_waitcnt lgkmcnt(4)                                       // 0000000FAC00: BF89FC47
	v_fma_f32 v36, -v41, v39, v36                              // 0000000FAC04: D6130024 24924F29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FAC0C: BF8700D1
	v_fma_f32 v40, -v42, v40, v36                              // 0000000FAC10: D6130028 2492512A
	ds_load_2addr_b32 v[36:37], v62 offset0:138 offset1:139    // 0000000FAC18: D8DC8B8A 2400003E
	ds_load_2addr_b32 v[38:39], v63 offset0:74 offset1:107     // 0000000FAC20: D8DC6B4A 2600003F
	s_waitcnt lgkmcnt(4)                                       // 0000000FAC28: BF89FC47
	v_fma_f32 v30, -v60, v30, v40                              // 0000000FAC2C: D613001E 24A23D3C
	v_fma_f32 v42, -v61, v31, v30                              // 0000000FAC34: D613002A 247A3F3D
	ds_load_2addr_b32 v[30:31], v63 offset0:140 offset1:173    // 0000000FAC3C: D8DCAD8C 1E00003F
	ds_load_2addr_b32 v[40:41], v62 offset0:140 offset1:141    // 0000000FAC44: D8DC8D8C 2800003E
	ds_load_2addr_b32 v[60:61], v62 offset0:142 offset1:143    // 0000000FAC4C: D8DC8F8E 3C00003E
	s_waitcnt lgkmcnt(5)                                       // 0000000FAC54: BF89FC57
	v_fma_f32 v32, -v32, v34, v42                              // 0000000FAC58: D6130020 24AA4520
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FAC60: BF8700C1
	v_fma_f32 v34, -v33, v35, v32                              // 0000000FAC64: D6130022 24824721
	ds_load_2addr_b32 v[32:33], v63 offset0:206 offset1:239    // 0000000FAC6C: D8DCEFCE 2000003F
	s_waitcnt lgkmcnt(4)                                       // 0000000FAC74: BF89FC47
	v_fma_f32 v34, -v36, v38, v34                              // 0000000FAC78: D6130022 248A4D24
	v_fma_f32 v34, -v37, v39, v34                              // 0000000FAC80: D6130022 248A4F25
	s_waitcnt lgkmcnt(2)                                       // 0000000FAC88: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAC8C: BF870091
	v_fma_f32 v30, -v40, v30, v34                              // 0000000FAC90: D613001E 248A3D28
	v_fma_f32 v30, -v41, v31, v30                              // 0000000FAC98: D613001E 247A3F29
	s_waitcnt lgkmcnt(0)                                       // 0000000FACA0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FACA4: BF870091
	v_fma_f32 v30, -v60, v32, v30                              // 0000000FACA8: D613001E 247A413C
	v_fma_f32 v30, -v61, v33, v30                              // 0000000FACB0: D613001E 247A433D
	s_cbranch_scc1 65450                                       // 0000000FACB8: BFA2FFAA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb64>
	v_add_nc_u32_e32 v31, 0x80, v27                            // 0000000FACBC: 4A3E36FF 00000080
	v_mad_u64_u32 v[28:29], null, 0x84, v28, v[8:9]            // 0000000FACC4: D6FE7C1C 042238FF 00000084
	.long 0xd4490001                                           // 0000000FACD0: D4490001
	v_cndmask_b32_e32 v1, 0x17f, v27, vcc_lo                   // 0000000FACD4: 020236FF 0000017F
	v_add_nc_u32_e32 v3, 0x810, v3                             // 0000000FACDC: 4A0606FF 00000810
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000FACE4: BF870004
	v_mov_b32_e32 v27, v31                                     // 0000000FACE8: 7E36031F
	s_or_b32 s11, s1, s11                                      // 0000000FACEC: 8C0B0B01
	ds_store_b32 v28, v30 offset:4224                          // 0000000FACF0: D8341080 00001E1C
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000FACF8: 917E0B7E
	s_cbranch_execnz 65416                                     // 0000000FACFC: BFA6FF88 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb20>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FAD00: 8C7E047E
	v_mov_b32_e32 v3, v0                                       // 0000000FAD04: 7E060300
	s_or_b32 s11, s7, 48                                       // 0000000FAD08: 8C0BB007
	s_mov_b32 s4, 0                                            // 0000000FAD0C: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000000FAD10: BF89FC07
	s_barrier                                                  // 0000000FAD14: BFBD0000
	buffer_gl0_inv                                             // 0000000FAD18: E0AC0000 00000000
	s_nop 0                                                    // 0000000FAD20: BF800000
	s_nop 0                                                    // 0000000FAD24: BF800000
	s_nop 0                                                    // 0000000FAD28: BF800000
	s_nop 0                                                    // 0000000FAD2C: BF800000
	s_nop 0                                                    // 0000000FAD30: BF800000
	s_nop 0                                                    // 0000000FAD34: BF800000
	s_nop 0                                                    // 0000000FAD38: BF800000
	s_nop 0                                                    // 0000000FAD3C: BF800000
	v_lshrrev_b32_e32 v29, 7, v3                               // 0000000FAD40: 323A0687
	v_add_nc_u32_e32 v31, 0x80, v3                             // 0000000FAD44: 4A3E06FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAD4C: BF870092
	v_or_b32_e32 v27, s11, v29                                 // 0000000FAD50: 38363A0B
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000FAD54: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAD5C: BF870091
	.long 0xd73c001b                                           // 0000000FAD60: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000FAD64: 02023689
	.long 0xd700011b                                           // 0000000FAD68: D700011B
	v_cndmask_b32_e32 v1, v48, v27, vcc_lo                     // 0000000FAD6C: 02023730
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FAD70: BF870001
	v_add_co_ci_u32_e64 v28, null, v49, v28, s1                // 0000000FAD74: D5207C1C 00063931
	.long 0xd4490001                                           // 0000000FAD7C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000FAD80: 020206FF 0000077F
	v_mov_b32_e32 v3, v31                                      // 0000000FAD88: 7E06031F
	global_load_b32 v30, v[27:28], off                         // 0000000FAD8C: DC520000 1E7C001B
	v_mad_u64_u32 v[27:28], null, 0x204, v29, v[7:8]           // 0000000FAD94: D6FE7C1B 041E3AFF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000FADA0: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000FADA4: BF8903F7
	ds_store_b32 v27, v30                                      // 0000000FADA8: D8340000 00001E1B
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FADB0: 917E047E
	s_cbranch_execnz 65506                                     // 0000000FADB4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd40>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FADB8: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000FADBC: BF89FC07
	s_barrier                                                  // 0000000FADC0: BFBD0000
	buffer_gl0_inv                                             // 0000000FADC4: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000FADCC: BE842000
	s_cbranch_execz 123                                        // 0000000FADD0: BFA5007B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfc0>
	v_mov_b32_e32 v3, v59                                      // 0000000FADD4: 7E06033B
	v_mov_b32_e32 v27, v0                                      // 0000000FADD8: 7E360300
	s_mov_b32 s14, 0                                           // 0000000FADDC: BE8E0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FADE0: BF870091
	v_lshrrev_b32_e32 v28, 5, v27                              // 0000000FADE4: 32383685
	v_or_b32_e32 v29, s11, v28                                 // 0000000FADE8: 383A380B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FADEC: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000FADF0: D6FE7C1D 0009611D
	.long 0xd73c001d                                           // 0000000FADF8: D73C001D
	v_cndmask_b32_e32 v1, 9, v29, vcc_lo                       // 0000000FADFC: 02023A89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAE00: BF870091
	.long 0xd700011d                                           // 0000000FAE04: D700011D
	v_cndmask_b32_e32 v1, v50, v29, vcc_lo                     // 0000000FAE08: 02023B32
	v_add_co_ci_u32_e64 v30, null, v51, v30, s1                // 0000000FAE0C: D5207C1E 00063D33
	s_movk_i32 s1, 0xfe00                                      // 0000000FAE14: B001FE00
	global_load_b32 v30, v[29:30], off                         // 0000000FAE18: DC520000 1E7C001D
	v_mov_b32_e32 v29, v1                                      // 0000000FAE20: 7E3A0301
	v_add_nc_u32_e32 v62, s1, v3                               // 0000000FAE24: 4A7C0601
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000FAE28: BF870002
	v_add_nc_u32_e32 v63, 0x400, v29                           // 0000000FAE2C: 4A7E3AFF 00000400
	s_add_i32 s1, s1, 64                                       // 0000000FAE34: 8101C001
	ds_load_2addr_b32 v[31:32], v29 offset1:33                 // 0000000FAE38: D8DC2100 1F00001D
	ds_load_2addr_b32 v[33:34], v62 offset0:128 offset1:129    // 0000000FAE40: D8DC8180 2100003E
	ds_load_2addr_b32 v[35:36], v29 offset0:66 offset1:99      // 0000000FAE48: D8DC6342 2300001D
	ds_load_2addr_b32 v[37:38], v62 offset0:130 offset1:131    // 0000000FAE50: D8DC8382 2500003E
	ds_load_2addr_b32 v[39:40], v29 offset0:132 offset1:165    // 0000000FAE58: D8DCA584 2700001D
	ds_load_2addr_b32 v[41:42], v62 offset0:132 offset1:133    // 0000000FAE60: D8DC8584 2900003E
	ds_load_2addr_b32 v[60:61], v62 offset0:134 offset1:135    // 0000000FAE68: D8DC8786 3C00003E
	s_cmp_lg_u32 s1, 0                                         // 0000000FAE70: BF078001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000000FAE74: BF890057
	v_fma_f32 v30, -v33, v31, v30                              // 0000000FAE78: D613001E 247A3F21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FAE80: BF8700D1
	v_fma_f32 v32, -v34, v32, v30                              // 0000000FAE84: D6130020 247A4122
	ds_load_2addr_b32 v[30:31], v29 offset0:198 offset1:231    // 0000000FAE8C: D8DCE7C6 1E00001D
	v_add_nc_u32_e32 v29, 0x840, v29                           // 0000000FAE94: 4A3A3AFF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FAE9C: BF89FC47
	v_fma_f32 v32, -v37, v35, v32                              // 0000000FAEA0: D6130020 24824725
	v_fma_f32 v36, -v38, v36, v32                              // 0000000FAEA8: D6130024 24824926
	ds_load_2addr_b32 v[32:33], v62 offset0:136 offset1:137    // 0000000FAEB0: D8DC8988 2000003E
	ds_load_2addr_b32 v[34:35], v63 offset0:8 offset1:41       // 0000000FAEB8: D8DC2908 2200003F
	s_waitcnt lgkmcnt(4)                                       // 0000000FAEC0: BF89FC47
	v_fma_f32 v36, -v41, v39, v36                              // 0000000FAEC4: D6130024 24924F29
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FAECC: BF8700D1
	v_fma_f32 v40, -v42, v40, v36                              // 0000000FAED0: D6130028 2492512A
	ds_load_2addr_b32 v[36:37], v62 offset0:138 offset1:139    // 0000000FAED8: D8DC8B8A 2400003E
	ds_load_2addr_b32 v[38:39], v63 offset0:74 offset1:107     // 0000000FAEE0: D8DC6B4A 2600003F
	s_waitcnt lgkmcnt(4)                                       // 0000000FAEE8: BF89FC47
	v_fma_f32 v30, -v60, v30, v40                              // 0000000FAEEC: D613001E 24A23D3C
	v_fma_f32 v42, -v61, v31, v30                              // 0000000FAEF4: D613002A 247A3F3D
	ds_load_2addr_b32 v[30:31], v63 offset0:140 offset1:173    // 0000000FAEFC: D8DCAD8C 1E00003F
	ds_load_2addr_b32 v[40:41], v62 offset0:140 offset1:141    // 0000000FAF04: D8DC8D8C 2800003E
	ds_load_2addr_b32 v[60:61], v62 offset0:142 offset1:143    // 0000000FAF0C: D8DC8F8E 3C00003E
	s_waitcnt lgkmcnt(5)                                       // 0000000FAF14: BF89FC57
	v_fma_f32 v32, -v32, v34, v42                              // 0000000FAF18: D6130020 24AA4520
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FAF20: BF8700C1
	v_fma_f32 v34, -v33, v35, v32                              // 0000000FAF24: D6130022 24824721
	ds_load_2addr_b32 v[32:33], v63 offset0:206 offset1:239    // 0000000FAF2C: D8DCEFCE 2000003F
	s_waitcnt lgkmcnt(4)                                       // 0000000FAF34: BF89FC47
	v_fma_f32 v34, -v36, v38, v34                              // 0000000FAF38: D6130022 248A4D24
	v_fma_f32 v34, -v37, v39, v34                              // 0000000FAF40: D6130022 248A4F25
	s_waitcnt lgkmcnt(2)                                       // 0000000FAF48: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAF4C: BF870091
	v_fma_f32 v30, -v40, v30, v34                              // 0000000FAF50: D613001E 248A3D28
	v_fma_f32 v30, -v41, v31, v30                              // 0000000FAF58: D613001E 247A3F29
	s_waitcnt lgkmcnt(0)                                       // 0000000FAF60: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FAF64: BF870091
	v_fma_f32 v30, -v60, v32, v30                              // 0000000FAF68: D613001E 247A413C
	v_fma_f32 v30, -v61, v33, v30                              // 0000000FAF70: D613001E 247A433D
	s_cbranch_scc1 65450                                       // 0000000FAF78: BFA2FFAA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe24>
	v_add_nc_u32_e32 v31, 0x80, v27                            // 0000000FAF7C: 4A3E36FF 00000080
	v_mad_u64_u32 v[28:29], null, 0x84, v28, v[8:9]            // 0000000FAF84: D6FE7C1C 042238FF 00000084
	.long 0xd4490001                                           // 0000000FAF90: D4490001
	v_cndmask_b32_e32 v1, 0x17f, v27, vcc_lo                   // 0000000FAF94: 020236FF 0000017F
	v_add_nc_u32_e32 v3, 0x810, v3                             // 0000000FAF9C: 4A0606FF 00000810
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000FAFA4: BF870004
	v_mov_b32_e32 v27, v31                                     // 0000000FAFA8: 7E36031F
	s_or_b32 s14, s1, s14                                      // 0000000FAFAC: 8C0E0E01
	ds_store_b32 v28, v30 offset:6336                          // 0000000FAFB0: D83418C0 00001E1C
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000FAFB8: 917E0E7E
	s_cbranch_execnz 65416                                     // 0000000FAFBC: BFA6FF88 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xde0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FAFC0: 8C7E047E
	v_mov_b32_e32 v3, v0                                       // 0000000FAFC4: 7E060300
	s_mov_b32 s4, 0                                            // 0000000FAFC8: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000000FAFCC: BF89FC07
	s_barrier                                                  // 0000000FAFD0: BFBD0000
	buffer_gl0_inv                                             // 0000000FAFD4: E0AC0000 00000000
	s_nop 0                                                    // 0000000FAFDC: BF800000
	s_nop 0                                                    // 0000000FAFE0: BF800000
	s_nop 0                                                    // 0000000FAFE4: BF800000
	s_nop 0                                                    // 0000000FAFE8: BF800000
	s_nop 0                                                    // 0000000FAFEC: BF800000
	s_nop 0                                                    // 0000000FAFF0: BF800000
	s_nop 0                                                    // 0000000FAFF4: BF800000
	s_nop 0                                                    // 0000000FAFF8: BF800000
	s_nop 0                                                    // 0000000FAFFC: BF800000
	v_lshrrev_b32_e32 v29, 7, v3                               // 0000000FB000: 323A0687
	v_add_nc_u32_e32 v31, 0x80, v3                             // 0000000FB004: 4A3E06FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB00C: BF870092
	v_or_b32_e32 v27, s7, v29                                  // 0000000FB010: 38363A07
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000FB014: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB01C: BF870091
	.long 0xd73c001b                                           // 0000000FB020: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000FB024: 02023689
	.long 0xd700011b                                           // 0000000FB028: D700011B
	v_cndmask_b32_e32 v1, v55, v27, vcc_lo                     // 0000000FB02C: 02023737
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FB030: BF870001
	v_add_co_ci_u32_e64 v28, null, v56, v28, s1                // 0000000FB034: D5207C1C 00063938
	.long 0xd4490001                                           // 0000000FB03C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000FB040: 020206FF 0000077F
	v_mov_b32_e32 v3, v31                                      // 0000000FB048: 7E06031F
	global_load_b32 v30, v[27:28], off                         // 0000000FB04C: DC520000 1E7C001B
	v_mad_u64_u32 v[27:28], null, 0x204, v29, v[7:8]           // 0000000FB054: D6FE7C1B 041E3AFF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000FB060: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000FB064: BF8903F7
	ds_store_b32 v27, v30                                      // 0000000FB068: D8340000 00001E1B
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FB070: 917E047E
	s_cbranch_execnz 65506                                     // 0000000FB074: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1000>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FB078: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000FB07C: BF89FC07
	s_barrier                                                  // 0000000FB080: BFBD0000
	buffer_gl0_inv                                             // 0000000FB084: E0AC0000 00000000
	s_and_saveexec_b32 s14, s0                                 // 0000000FB08C: BE8E2000
	s_cbranch_execz 155                                        // 0000000FB090: BFA5009B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1300>
	v_dual_mov_b32 v28, v12 :: v_dual_mov_b32 v27, v11         // 0000000FB094: CA10010C 1C1A010B
	v_dual_mov_b32 v3, v59 :: v_dual_mov_b32 v32, v0           // 0000000FB09C: CA10013B 03200100
	v_mov_b32_e32 v31, v47                                     // 0000000FB0A4: 7E3E032F
	s_mov_b32 s15, 0                                           // 0000000FB0A8: BE8F0080
	s_branch 19                                                // 0000000FB0AC: BFA00013 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10fc>
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000FB0B0: 8C7E167E
	v_add_nc_u32_e32 v29, 0x80, v32                            // 0000000FB0B4: 4A3A40FF 00000080
	.long 0xd4490001                                           // 0000000FB0BC: D4490001
	v_cndmask_b32_e32 v1, 0x17f, v32, vcc_lo                   // 0000000FB0C0: 020240FF 0000017F
	.long 0xd700041b                                           // 0000000FB0C8: D700041B
	v_cndmask_b32_e32 v1, 0x400, v27, vcc_lo                   // 0000000FB0CC: 020236FF 00000400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000FB0D4: BF8704C3
	v_dual_mov_b32 v32, v29 :: v_dual_add_nc_u32 v31, 4, v31   // 0000000FB0D8: CA20011D 201E3E84
	v_add_nc_u32_e32 v3, 0x810, v3                             // 0000000FB0E0: 4A0606FF 00000810
	v_add_co_ci_u32_e64 v28, null, 0, v28, s4                  // 0000000FB0E8: D5207C1C 00123880
	s_or_b32 s15, s1, s15                                      // 0000000FB0F0: 8C0F0F01
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000000FB0F4: 917E0F7E
	s_cbranch_execz 129                                        // 0000000FB0F8: BFA50081 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1300>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FB0FC: BF8700A2
	v_lshrrev_b32_e32 v29, 5, v32                              // 0000000FB100: 323A4085
	s_mov_b32 s22, exec_lo                                     // 0000000FB104: BE96007E
	v_or_b32_e32 v33, s7, v29                                  // 0000000FB108: 38423A07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FB10C: BF870001
	.long 0xd4c4007e                                           // 0000000FB110: D4C4007E
	v_cndmask_b32_e32 v1, s30, v33, vcc_lo                     // 0000000FB114: 0202421E
	s_cbranch_execz 65509                                      // 0000000FB118: BFA5FFE5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10b0>
	v_mov_b32_e32 v34, 0                                       // 0000000FB11C: 7E440280
	v_mov_b32_e32 v30, v1                                      // 0000000FB120: 7E3C0301
	s_movk_i32 s1, 0xfe00                                      // 0000000FB124: B001FE00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FB128: BF870009
	v_add_nc_u32_e32 v66, s1, v3                               // 0000000FB12C: 4A840601
	s_add_i32 s1, s1, 64                                       // 0000000FB130: 8101C001
	ds_load_2addr_b32 v[35:36], v30 offset1:33                 // 0000000FB134: D8DC2100 2300001E
	ds_load_2addr_b32 v[37:38], v66 offset0:128 offset1:129    // 0000000FB13C: D8DC8180 25000042
	ds_load_2addr_b32 v[39:40], v30 offset0:66 offset1:99      // 0000000FB144: D8DC6342 2700001E
	ds_load_2addr_b32 v[41:42], v66 offset0:130 offset1:131    // 0000000FB14C: D8DC8382 29000042
	ds_load_2addr_b32 v[60:61], v30 offset0:132 offset1:165    // 0000000FB154: D8DCA584 3C00001E
	ds_load_2addr_b32 v[62:63], v66 offset0:132 offset1:133    // 0000000FB15C: D8DC8584 3E000042
	ds_load_2addr_b32 v[64:65], v66 offset0:134 offset1:135    // 0000000FB164: D8DC8786 40000042
	s_cmp_eq_u32 s1, 0                                         // 0000000FB16C: BF068001
	s_waitcnt lgkmcnt(5)                                       // 0000000FB170: BF89FC57
	v_dual_fmac_f32 v34, v37, v35 :: v_dual_add_nc_u32 v67, 0x400, v30// 0000000FB174: C8204725 22423CFF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FB180: BF8700D1
	v_fmac_f32_e32 v34, v38, v36                               // 0000000FB184: 56444926
	ds_load_2addr_b32 v[35:36], v30 offset0:198 offset1:231    // 0000000FB188: D8DCE7C6 2300001E
	v_add_nc_u32_e32 v30, 0x840, v30                           // 0000000FB190: 4A3C3CFF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FB198: BF89FC47
	v_fmac_f32_e32 v34, v41, v39                               // 0000000FB19C: 56444F29
	v_fmac_f32_e32 v34, v42, v40                               // 0000000FB1A0: 5644512A
	ds_load_2addr_b32 v[37:38], v66 offset0:136 offset1:137    // 0000000FB1A4: D8DC8988 25000042
	ds_load_2addr_b32 v[39:40], v67 offset0:8 offset1:41       // 0000000FB1AC: D8DC2908 27000043
	s_waitcnt lgkmcnt(4)                                       // 0000000FB1B4: BF89FC47
	v_fmac_f32_e32 v34, v62, v60                               // 0000000FB1B8: 5644793E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FB1BC: BF8700D1
	v_fmac_f32_e32 v34, v63, v61                               // 0000000FB1C0: 56447B3F
	ds_load_2addr_b32 v[41:42], v66 offset0:138 offset1:139    // 0000000FB1C4: D8DC8B8A 29000042
	ds_load_2addr_b32 v[60:61], v67 offset0:74 offset1:107     // 0000000FB1CC: D8DC6B4A 3C000043
	s_waitcnt lgkmcnt(4)                                       // 0000000FB1D4: BF89FC47
	v_fmac_f32_e32 v34, v64, v35                               // 0000000FB1D8: 56444740
	v_fmac_f32_e32 v34, v65, v36                               // 0000000FB1DC: 56444941
	ds_load_2addr_b32 v[35:36], v67 offset0:140 offset1:173    // 0000000FB1E0: D8DCAD8C 23000043
	ds_load_2addr_b32 v[62:63], v66 offset0:140 offset1:141    // 0000000FB1E8: D8DC8D8C 3E000042
	ds_load_2addr_b32 v[64:65], v66 offset0:142 offset1:143    // 0000000FB1F0: D8DC8F8E 40000042
	s_waitcnt lgkmcnt(5)                                       // 0000000FB1F8: BF89FC57
	v_fmac_f32_e32 v34, v37, v39                               // 0000000FB1FC: 56444F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FB200: BF8700C1
	v_fmac_f32_e32 v34, v38, v40                               // 0000000FB204: 56445126
	ds_load_2addr_b32 v[37:38], v67 offset0:206 offset1:239    // 0000000FB208: D8DCEFCE 25000043
	s_waitcnt lgkmcnt(4)                                       // 0000000FB210: BF89FC47
	v_fmac_f32_e32 v34, v41, v60                               // 0000000FB214: 56447929
	v_fmac_f32_e32 v34, v42, v61                               // 0000000FB218: 56447B2A
	s_waitcnt lgkmcnt(2)                                       // 0000000FB21C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB220: BF870091
	v_fmac_f32_e32 v34, v62, v35                               // 0000000FB224: 5644473E
	v_fmac_f32_e32 v34, v63, v36                               // 0000000FB228: 5644493F
	s_waitcnt lgkmcnt(0)                                       // 0000000FB22C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB230: BF870091
	v_fmac_f32_e32 v34, v64, v37                               // 0000000FB234: 56444B40
	v_fmac_f32_e32 v34, v65, v38                               // 0000000FB238: 56444D41
	s_cbranch_scc0 65466                                       // 0000000FB23C: BFA1FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1128>
	v_lshlrev_b32_e32 v29, 2, v29                              // 0000000FB240: 303A3A82
	s_mov_b32 s23, 0                                           // 0000000FB244: BE970080
	ds_load_b32 v36, v29 offset:33856                          // 0000000FB248: D8D88440 2400001D
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v35, v1          // 0000000FB250: CA10011C 1E220101
	s_waitcnt lgkmcnt(0)                                       // 0000000FB258: BF89FC07
	v_dual_mov_b32 v29, v27 :: v_dual_mul_f32 v34, v34, v36    // 0000000FB25C: CA06011B 1D224922
	v_mov_b32_e32 v36, v31                                     // 0000000FB264: 7E48031F
	s_nop 0                                                    // 0000000FB268: BF800000
	s_nop 0                                                    // 0000000FB26C: BF800000
	s_nop 0                                                    // 0000000FB270: BF800000
	s_nop 0                                                    // 0000000FB274: BF800000
	s_nop 0                                                    // 0000000FB278: BF800000
	s_nop 0                                                    // 0000000FB27C: BF800000
	global_load_b32 v37, v[29:30], off                         // 0000000FB280: DC520000 257C001D
	ds_load_b32 v38, v35 offset:16896                          // 0000000FB288: D8D84200 26000023
	v_add_nc_u32_e32 v36, -1, v36                              // 0000000FB290: 4A4848C1
	.long 0xd700011d                                           // 0000000FB294: D700011D
	v_cndmask_b32_e32 v0, v29, v132, vcc_lo                    // 0000000FB298: 0201091D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000FB29C: BF870191
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000FB2A0: D5207C1E 00063C80
	.long 0xd44a0004                                           // 0000000FB2A8: D44A0004
	v_cndmask_b32_e32 v1, 0, v36, vcc_lo                       // 0000000FB2AC: 02024880
	v_add_nc_u32_e32 v35, 0x84, v35                            // 0000000FB2B0: 4A4646FF 00000084
	s_or_b32 s23, s4, s23                                      // 0000000FB2B8: 8C171704
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FB2BC: BF890007
	v_fmac_f32_e32 v34, v37, v38                               // 0000000FB2C0: 56444D25
	s_and_not1_b32 exec_lo, exec_lo, s23                       // 0000000FB2C4: 917E177E
	s_cbranch_execnz 65517                                     // 0000000FB2C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1280>
	s_or_b32 exec_lo, exec_lo, s23                             // 0000000FB2CC: 8C7E177E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FB2D0: BF870121
	v_bfe_u32 v35, v34, 16, 1                                  // 0000000FB2D4: D6100023 02052122
	v_mad_u64_u32 v[29:30], null, 0x3000, v33, v[9:10]         // 0000000FB2DC: D6FE7C1D 042642FF 00003000
	v_add3_u32 v33, v34, v35, 0x7fff                           // 0000000FB2E8: D6550021 03FE4722 00007FFF
	global_store_d16_hi_b16 v[29:30], v33, off                 // 0000000FB2F4: DC960000 007C211D
	s_branch 65388                                             // 0000000FB2FC: BFA0FF6C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10b0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000FB300: 8C7E0E7E
	v_mov_b32_e32 v3, v0                                       // 0000000FB304: 7E060300
	s_mov_b32 s4, 0                                            // 0000000FB308: BE840080
	s_waitcnt_vscnt null, 0x0                                  // 0000000FB30C: BC7C0000
	s_barrier                                                  // 0000000FB310: BFBD0000
	buffer_gl0_inv                                             // 0000000FB314: E0AC0000 00000000
	s_nop 0                                                    // 0000000FB31C: BF800000
	s_nop 0                                                    // 0000000FB320: BF800000
	s_nop 0                                                    // 0000000FB324: BF800000
	s_nop 0                                                    // 0000000FB328: BF800000
	s_nop 0                                                    // 0000000FB32C: BF800000
	s_nop 0                                                    // 0000000FB330: BF800000
	s_nop 0                                                    // 0000000FB334: BF800000
	s_nop 0                                                    // 0000000FB338: BF800000
	s_nop 0                                                    // 0000000FB33C: BF800000
	v_lshrrev_b32_e32 v29, 7, v3                               // 0000000FB340: 323A0687
	v_add_nc_u32_e32 v31, 0x80, v3                             // 0000000FB344: 4A3E06FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB34C: BF870092
	v_or_b32_e32 v27, s13, v29                                 // 0000000FB350: 38363A0D
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000FB354: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB35C: BF870091
	.long 0xd73c001b                                           // 0000000FB360: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000FB364: 02023689
	.long 0xd700011b                                           // 0000000FB368: D700011B
	v_cndmask_b32_e32 v1, v55, v27, vcc_lo                     // 0000000FB36C: 02023737
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FB370: BF870001
	v_add_co_ci_u32_e64 v28, null, v56, v28, s1                // 0000000FB374: D5207C1C 00063938
	.long 0xd4490001                                           // 0000000FB37C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000FB380: 020206FF 0000077F
	v_mov_b32_e32 v3, v31                                      // 0000000FB388: 7E06031F
	global_load_b32 v30, v[27:28], off                         // 0000000FB38C: DC520000 1E7C001B
	v_mad_u64_u32 v[27:28], null, 0x204, v29, v[7:8]           // 0000000FB394: D6FE7C1B 041E3AFF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000FB3A0: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000FB3A4: BF8903F7
	ds_store_b32 v27, v30                                      // 0000000FB3A8: D8340000 00001E1B
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FB3B0: 917E047E
	s_cbranch_execnz 65506                                     // 0000000FB3B4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1340>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FB3B8: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000FB3BC: BF89FC07
	s_barrier                                                  // 0000000FB3C0: BFBD0000
	buffer_gl0_inv                                             // 0000000FB3C4: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000FB3CC: BE8D2000
	s_cbranch_execz 155                                        // 0000000FB3D0: BFA5009B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1640>
	v_dual_mov_b32 v28, v14 :: v_dual_mov_b32 v27, v13         // 0000000FB3D4: CA10010E 1C1A010D
	v_dual_mov_b32 v3, v59 :: v_dual_mov_b32 v32, v0           // 0000000FB3DC: CA10013B 03200100
	v_mov_b32_e32 v31, v52                                     // 0000000FB3E4: 7E3E0334
	s_mov_b32 s14, 0                                           // 0000000FB3E8: BE8E0080
	s_branch 19                                                // 0000000FB3EC: BFA00013 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x143c>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000000FB3F0: 8C7E0F7E
	v_add_nc_u32_e32 v29, 0x80, v32                            // 0000000FB3F4: 4A3A40FF 00000080
	.long 0xd4490001                                           // 0000000FB3FC: D4490001
	v_cndmask_b32_e32 v1, 0x17f, v32, vcc_lo                   // 0000000FB400: 020240FF 0000017F
	.long 0xd700041b                                           // 0000000FB408: D700041B
	v_cndmask_b32_e32 v1, 0x400, v27, vcc_lo                   // 0000000FB40C: 020236FF 00000400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000FB414: BF8704C3
	v_dual_mov_b32 v32, v29 :: v_dual_add_nc_u32 v31, 4, v31   // 0000000FB418: CA20011D 201E3E84
	v_add_nc_u32_e32 v3, 0x810, v3                             // 0000000FB420: 4A0606FF 00000810
	v_add_co_ci_u32_e64 v28, null, 0, v28, s4                  // 0000000FB428: D5207C1C 00123880
	s_or_b32 s14, s1, s14                                      // 0000000FB430: 8C0E0E01
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000FB434: 917E0E7E
	s_cbranch_execz 129                                        // 0000000FB438: BFA50081 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1640>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FB43C: BF8700A2
	v_lshrrev_b32_e32 v29, 5, v32                              // 0000000FB440: 323A4085
	s_mov_b32 s15, exec_lo                                     // 0000000FB444: BE8F007E
	v_or3_b32 v33, v29, s7, 16                                 // 0000000FB448: D6580021 02400F1D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FB450: BF870001
	.long 0xd4c4007e                                           // 0000000FB454: D4C4007E
	v_cndmask_b32_e32 v1, s30, v33, vcc_lo                     // 0000000FB458: 0202421E
	s_cbranch_execz 65508                                      // 0000000FB45C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13f0>
	v_mov_b32_e32 v34, 0                                       // 0000000FB460: 7E440280
	v_mov_b32_e32 v30, v1                                      // 0000000FB464: 7E3C0301
	s_movk_i32 s1, 0xfe00                                      // 0000000FB468: B001FE00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FB46C: BF870009
	v_add_nc_u32_e32 v66, s1, v3                               // 0000000FB470: 4A840601
	s_add_i32 s1, s1, 64                                       // 0000000FB474: 8101C001
	ds_load_2addr_b32 v[35:36], v30 offset1:33                 // 0000000FB478: D8DC2100 2300001E
	ds_load_2addr_b32 v[37:38], v66 offset0:128 offset1:129    // 0000000FB480: D8DC8180 25000042
	ds_load_2addr_b32 v[39:40], v30 offset0:66 offset1:99      // 0000000FB488: D8DC6342 2700001E
	ds_load_2addr_b32 v[41:42], v66 offset0:130 offset1:131    // 0000000FB490: D8DC8382 29000042
	ds_load_2addr_b32 v[60:61], v30 offset0:132 offset1:165    // 0000000FB498: D8DCA584 3C00001E
	ds_load_2addr_b32 v[62:63], v66 offset0:132 offset1:133    // 0000000FB4A0: D8DC8584 3E000042
	ds_load_2addr_b32 v[64:65], v66 offset0:134 offset1:135    // 0000000FB4A8: D8DC8786 40000042
	s_cmp_lg_u32 s1, 0                                         // 0000000FB4B0: BF078001
	s_waitcnt lgkmcnt(5)                                       // 0000000FB4B4: BF89FC57
	v_dual_fmac_f32 v34, v37, v35 :: v_dual_add_nc_u32 v67, 0x400, v30// 0000000FB4B8: C8204725 22423CFF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FB4C4: BF8700D1
	v_fmac_f32_e32 v34, v38, v36                               // 0000000FB4C8: 56444926
	ds_load_2addr_b32 v[35:36], v30 offset0:198 offset1:231    // 0000000FB4CC: D8DCE7C6 2300001E
	v_add_nc_u32_e32 v30, 0x840, v30                           // 0000000FB4D4: 4A3C3CFF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FB4DC: BF89FC47
	v_fmac_f32_e32 v34, v41, v39                               // 0000000FB4E0: 56444F29
	v_fmac_f32_e32 v34, v42, v40                               // 0000000FB4E4: 5644512A
	ds_load_2addr_b32 v[37:38], v66 offset0:136 offset1:137    // 0000000FB4E8: D8DC8988 25000042
	ds_load_2addr_b32 v[39:40], v67 offset0:8 offset1:41       // 0000000FB4F0: D8DC2908 27000043
	s_waitcnt lgkmcnt(4)                                       // 0000000FB4F8: BF89FC47
	v_fmac_f32_e32 v34, v62, v60                               // 0000000FB4FC: 5644793E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FB500: BF8700D1
	v_fmac_f32_e32 v34, v63, v61                               // 0000000FB504: 56447B3F
	ds_load_2addr_b32 v[41:42], v66 offset0:138 offset1:139    // 0000000FB508: D8DC8B8A 29000042
	ds_load_2addr_b32 v[60:61], v67 offset0:74 offset1:107     // 0000000FB510: D8DC6B4A 3C000043
	s_waitcnt lgkmcnt(4)                                       // 0000000FB518: BF89FC47
	v_fmac_f32_e32 v34, v64, v35                               // 0000000FB51C: 56444740
	v_fmac_f32_e32 v34, v65, v36                               // 0000000FB520: 56444941
	ds_load_2addr_b32 v[35:36], v67 offset0:140 offset1:173    // 0000000FB524: D8DCAD8C 23000043
	ds_load_2addr_b32 v[62:63], v66 offset0:140 offset1:141    // 0000000FB52C: D8DC8D8C 3E000042
	ds_load_2addr_b32 v[64:65], v66 offset0:142 offset1:143    // 0000000FB534: D8DC8F8E 40000042
	s_waitcnt lgkmcnt(5)                                       // 0000000FB53C: BF89FC57
	v_fmac_f32_e32 v34, v37, v39                               // 0000000FB540: 56444F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FB544: BF8700C1
	v_fmac_f32_e32 v34, v38, v40                               // 0000000FB548: 56445126
	ds_load_2addr_b32 v[37:38], v67 offset0:206 offset1:239    // 0000000FB54C: D8DCEFCE 25000043
	s_waitcnt lgkmcnt(4)                                       // 0000000FB554: BF89FC47
	v_fmac_f32_e32 v34, v41, v60                               // 0000000FB558: 56447929
	v_fmac_f32_e32 v34, v42, v61                               // 0000000FB55C: 56447B2A
	s_waitcnt lgkmcnt(2)                                       // 0000000FB560: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB564: BF870091
	v_fmac_f32_e32 v34, v62, v35                               // 0000000FB568: 5644473E
	v_fmac_f32_e32 v34, v63, v36                               // 0000000FB56C: 5644493F
	s_waitcnt lgkmcnt(0)                                       // 0000000FB570: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB574: BF870091
	v_fmac_f32_e32 v34, v64, v37                               // 0000000FB578: 56444B40
	v_fmac_f32_e32 v34, v65, v38                               // 0000000FB57C: 56444D41
	s_cbranch_scc1 65466                                       // 0000000FB580: BFA2FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x146c>
	v_lshlrev_b32_e32 v29, 2, v29                              // 0000000FB584: 303A3A82
	v_mov_b32_e32 v35, v1                                      // 0000000FB588: 7E460301
	s_mov_b32 s22, 0                                           // 0000000FB58C: BE960080
	ds_load_b32 v36, v29 offset:33920                          // 0000000FB590: D8D88480 2400001D
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000FB598: CA10011C 1E1C011B
	s_waitcnt lgkmcnt(0)                                       // 0000000FB5A0: BF89FC07
	v_mul_f32_e32 v34, v34, v36                                // 0000000FB5A4: 10444922
	v_mov_b32_e32 v36, v31                                     // 0000000FB5A8: 7E48031F
	s_nop 0                                                    // 0000000FB5AC: BF800000
	s_nop 0                                                    // 0000000FB5B0: BF800000
	s_nop 0                                                    // 0000000FB5B4: BF800000
	s_nop 0                                                    // 0000000FB5B8: BF800000
	s_nop 0                                                    // 0000000FB5BC: BF800000
	global_load_b32 v37, v[29:30], off                         // 0000000FB5C0: DC520000 257C001D
	ds_load_b32 v38, v35 offset:16896                          // 0000000FB5C8: D8D84200 26000023
	v_add_nc_u32_e32 v36, -1, v36                              // 0000000FB5D0: 4A4848C1
	.long 0xd700011d                                           // 0000000FB5D4: D700011D
	v_cndmask_b32_e32 v0, v29, v132, vcc_lo                    // 0000000FB5D8: 0201091D
	v_add_nc_u32_e32 v35, 0x84, v35                            // 0000000FB5DC: 4A4646FF 00000084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000FB5E4: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000FB5EC: BF870004
	.long 0xd44a0004                                           // 0000000FB5F0: D44A0004
	v_cndmask_b32_e32 v1, 0, v36, vcc_lo                       // 0000000FB5F4: 02024880
	s_or_b32 s22, s4, s22                                      // 0000000FB5F8: 8C161604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FB5FC: BF890007
	v_fmac_f32_e32 v34, v37, v38                               // 0000000FB600: 56444D25
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 0000000FB604: 917E167E
	s_cbranch_execnz 65517                                     // 0000000FB608: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000FB60C: 8C7E167E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FB610: BF870121
	v_bfe_u32 v35, v34, 16, 1                                  // 0000000FB614: D6100023 02052122
	v_mad_u64_u32 v[29:30], null, 0x3000, v33, v[9:10]         // 0000000FB61C: D6FE7C1D 042642FF 00003000
	v_add3_u32 v33, v34, v35, 0x7fff                           // 0000000FB628: D6550021 03FE4722 00007FFF
	global_store_d16_hi_b16 v[29:30], v33, off                 // 0000000FB634: DC960000 007C211D
	s_branch 65388                                             // 0000000FB63C: BFA0FF6C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13f0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000FB640: 8C7E0D7E
	v_mov_b32_e32 v3, v0                                       // 0000000FB644: 7E060300
	s_mov_b32 s4, 0                                            // 0000000FB648: BE840080
	s_waitcnt_vscnt null, 0x0                                  // 0000000FB64C: BC7C0000
	s_barrier                                                  // 0000000FB650: BFBD0000
	buffer_gl0_inv                                             // 0000000FB654: E0AC0000 00000000
	s_nop 0                                                    // 0000000FB65C: BF800000
	s_nop 0                                                    // 0000000FB660: BF800000
	s_nop 0                                                    // 0000000FB664: BF800000
	s_nop 0                                                    // 0000000FB668: BF800000
	s_nop 0                                                    // 0000000FB66C: BF800000
	s_nop 0                                                    // 0000000FB670: BF800000
	s_nop 0                                                    // 0000000FB674: BF800000
	s_nop 0                                                    // 0000000FB678: BF800000
	s_nop 0                                                    // 0000000FB67C: BF800000
	v_lshrrev_b32_e32 v29, 7, v3                               // 0000000FB680: 323A0687
	v_add_nc_u32_e32 v31, 0x80, v3                             // 0000000FB684: 4A3E06FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB68C: BF870092
	v_or_b32_e32 v27, s12, v29                                 // 0000000FB690: 38363A0C
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000FB694: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB69C: BF870091
	.long 0xd73c001b                                           // 0000000FB6A0: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000FB6A4: 02023689
	.long 0xd700011b                                           // 0000000FB6A8: D700011B
	v_cndmask_b32_e32 v1, v55, v27, vcc_lo                     // 0000000FB6AC: 02023737
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FB6B0: BF870001
	v_add_co_ci_u32_e64 v28, null, v56, v28, s1                // 0000000FB6B4: D5207C1C 00063938
	.long 0xd4490001                                           // 0000000FB6BC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000FB6C0: 020206FF 0000077F
	v_mov_b32_e32 v3, v31                                      // 0000000FB6C8: 7E06031F
	global_load_b32 v30, v[27:28], off                         // 0000000FB6CC: DC520000 1E7C001B
	v_mad_u64_u32 v[27:28], null, 0x204, v29, v[7:8]           // 0000000FB6D4: D6FE7C1B 041E3AFF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000FB6E0: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000FB6E4: BF8903F7
	ds_store_b32 v27, v30                                      // 0000000FB6E8: D8340000 00001E1B
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FB6F0: 917E047E
	s_cbranch_execnz 65506                                     // 0000000FB6F4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1680>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FB6F8: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000FB6FC: BF89FC07
	s_barrier                                                  // 0000000FB700: BFBD0000
	buffer_gl0_inv                                             // 0000000FB704: E0AC0000 00000000
	s_and_saveexec_b32 s12, s0                                 // 0000000FB70C: BE8C2000
	s_cbranch_execz 155                                        // 0000000FB710: BFA5009B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1980>
	v_dual_mov_b32 v28, v16 :: v_dual_mov_b32 v27, v15         // 0000000FB714: CA100110 1C1A010F
	v_dual_mov_b32 v3, v59 :: v_dual_mov_b32 v32, v0           // 0000000FB71C: CA10013B 03200100
	v_mov_b32_e32 v31, v53                                     // 0000000FB724: 7E3E0335
	s_mov_b32 s13, 0                                           // 0000000FB728: BE8D0080
	s_branch 19                                                // 0000000FB72C: BFA00013 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x177c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000FB730: 8C7E0E7E
	v_add_nc_u32_e32 v29, 0x80, v32                            // 0000000FB734: 4A3A40FF 00000080
	.long 0xd4490001                                           // 0000000FB73C: D4490001
	v_cndmask_b32_e32 v1, 0x17f, v32, vcc_lo                   // 0000000FB740: 020240FF 0000017F
	.long 0xd700041b                                           // 0000000FB748: D700041B
	v_cndmask_b32_e32 v1, 0x400, v27, vcc_lo                   // 0000000FB74C: 020236FF 00000400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000FB754: BF8704C3
	v_dual_mov_b32 v32, v29 :: v_dual_add_nc_u32 v31, 4, v31   // 0000000FB758: CA20011D 201E3E84
	v_add_nc_u32_e32 v3, 0x810, v3                             // 0000000FB760: 4A0606FF 00000810
	v_add_co_ci_u32_e64 v28, null, 0, v28, s4                  // 0000000FB768: D5207C1C 00123880
	s_or_b32 s13, s1, s13                                      // 0000000FB770: 8C0D0D01
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000FB774: 917E0D7E
	s_cbranch_execz 129                                        // 0000000FB778: BFA50081 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1980>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FB77C: BF8700A2
	v_lshrrev_b32_e32 v29, 5, v32                              // 0000000FB780: 323A4085
	s_mov_b32 s14, exec_lo                                     // 0000000FB784: BE8E007E
	v_or3_b32 v33, v29, s7, 32                                 // 0000000FB788: D6580021 02800F1D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FB790: BF870001
	.long 0xd4c4007e                                           // 0000000FB794: D4C4007E
	v_cndmask_b32_e32 v1, s30, v33, vcc_lo                     // 0000000FB798: 0202421E
	s_cbranch_execz 65508                                      // 0000000FB79C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1730>
	v_mov_b32_e32 v34, 0                                       // 0000000FB7A0: 7E440280
	v_mov_b32_e32 v30, v1                                      // 0000000FB7A4: 7E3C0301
	s_movk_i32 s1, 0xfe00                                      // 0000000FB7A8: B001FE00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FB7AC: BF870009
	v_add_nc_u32_e32 v66, s1, v3                               // 0000000FB7B0: 4A840601
	s_add_i32 s1, s1, 64                                       // 0000000FB7B4: 8101C001
	ds_load_2addr_b32 v[35:36], v30 offset1:33                 // 0000000FB7B8: D8DC2100 2300001E
	ds_load_2addr_b32 v[37:38], v66 offset0:128 offset1:129    // 0000000FB7C0: D8DC8180 25000042
	ds_load_2addr_b32 v[39:40], v30 offset0:66 offset1:99      // 0000000FB7C8: D8DC6342 2700001E
	ds_load_2addr_b32 v[41:42], v66 offset0:130 offset1:131    // 0000000FB7D0: D8DC8382 29000042
	ds_load_2addr_b32 v[60:61], v30 offset0:132 offset1:165    // 0000000FB7D8: D8DCA584 3C00001E
	ds_load_2addr_b32 v[62:63], v66 offset0:132 offset1:133    // 0000000FB7E0: D8DC8584 3E000042
	ds_load_2addr_b32 v[64:65], v66 offset0:134 offset1:135    // 0000000FB7E8: D8DC8786 40000042
	s_cmp_lg_u32 s1, 0                                         // 0000000FB7F0: BF078001
	s_waitcnt lgkmcnt(5)                                       // 0000000FB7F4: BF89FC57
	v_dual_fmac_f32 v34, v37, v35 :: v_dual_add_nc_u32 v67, 0x400, v30// 0000000FB7F8: C8204725 22423CFF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FB804: BF8700D1
	v_fmac_f32_e32 v34, v38, v36                               // 0000000FB808: 56444926
	ds_load_2addr_b32 v[35:36], v30 offset0:198 offset1:231    // 0000000FB80C: D8DCE7C6 2300001E
	v_add_nc_u32_e32 v30, 0x840, v30                           // 0000000FB814: 4A3C3CFF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FB81C: BF89FC47
	v_fmac_f32_e32 v34, v41, v39                               // 0000000FB820: 56444F29
	v_fmac_f32_e32 v34, v42, v40                               // 0000000FB824: 5644512A
	ds_load_2addr_b32 v[37:38], v66 offset0:136 offset1:137    // 0000000FB828: D8DC8988 25000042
	ds_load_2addr_b32 v[39:40], v67 offset0:8 offset1:41       // 0000000FB830: D8DC2908 27000043
	s_waitcnt lgkmcnt(4)                                       // 0000000FB838: BF89FC47
	v_fmac_f32_e32 v34, v62, v60                               // 0000000FB83C: 5644793E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FB840: BF8700D1
	v_fmac_f32_e32 v34, v63, v61                               // 0000000FB844: 56447B3F
	ds_load_2addr_b32 v[41:42], v66 offset0:138 offset1:139    // 0000000FB848: D8DC8B8A 29000042
	ds_load_2addr_b32 v[60:61], v67 offset0:74 offset1:107     // 0000000FB850: D8DC6B4A 3C000043
	s_waitcnt lgkmcnt(4)                                       // 0000000FB858: BF89FC47
	v_fmac_f32_e32 v34, v64, v35                               // 0000000FB85C: 56444740
	v_fmac_f32_e32 v34, v65, v36                               // 0000000FB860: 56444941
	ds_load_2addr_b32 v[35:36], v67 offset0:140 offset1:173    // 0000000FB864: D8DCAD8C 23000043
	ds_load_2addr_b32 v[62:63], v66 offset0:140 offset1:141    // 0000000FB86C: D8DC8D8C 3E000042
	ds_load_2addr_b32 v[64:65], v66 offset0:142 offset1:143    // 0000000FB874: D8DC8F8E 40000042
	s_waitcnt lgkmcnt(5)                                       // 0000000FB87C: BF89FC57
	v_fmac_f32_e32 v34, v37, v39                               // 0000000FB880: 56444F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FB884: BF8700C1
	v_fmac_f32_e32 v34, v38, v40                               // 0000000FB888: 56445126
	ds_load_2addr_b32 v[37:38], v67 offset0:206 offset1:239    // 0000000FB88C: D8DCEFCE 25000043
	s_waitcnt lgkmcnt(4)                                       // 0000000FB894: BF89FC47
	v_fmac_f32_e32 v34, v41, v60                               // 0000000FB898: 56447929
	v_fmac_f32_e32 v34, v42, v61                               // 0000000FB89C: 56447B2A
	s_waitcnt lgkmcnt(2)                                       // 0000000FB8A0: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB8A4: BF870091
	v_fmac_f32_e32 v34, v62, v35                               // 0000000FB8A8: 5644473E
	v_fmac_f32_e32 v34, v63, v36                               // 0000000FB8AC: 5644493F
	s_waitcnt lgkmcnt(0)                                       // 0000000FB8B0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB8B4: BF870091
	v_fmac_f32_e32 v34, v64, v37                               // 0000000FB8B8: 56444B40
	v_fmac_f32_e32 v34, v65, v38                               // 0000000FB8BC: 56444D41
	s_cbranch_scc1 65466                                       // 0000000FB8C0: BFA2FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x17ac>
	v_lshlrev_b32_e32 v29, 2, v29                              // 0000000FB8C4: 303A3A82
	v_mov_b32_e32 v35, v1                                      // 0000000FB8C8: 7E460301
	s_mov_b32 s15, 0                                           // 0000000FB8CC: BE8F0080
	ds_load_b32 v36, v29 offset:33984                          // 0000000FB8D0: D8D884C0 2400001D
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000FB8D8: CA10011C 1E1C011B
	s_waitcnt lgkmcnt(0)                                       // 0000000FB8E0: BF89FC07
	v_mul_f32_e32 v34, v34, v36                                // 0000000FB8E4: 10444922
	v_mov_b32_e32 v36, v31                                     // 0000000FB8E8: 7E48031F
	s_nop 0                                                    // 0000000FB8EC: BF800000
	s_nop 0                                                    // 0000000FB8F0: BF800000
	s_nop 0                                                    // 0000000FB8F4: BF800000
	s_nop 0                                                    // 0000000FB8F8: BF800000
	s_nop 0                                                    // 0000000FB8FC: BF800000
	global_load_b32 v37, v[29:30], off                         // 0000000FB900: DC520000 257C001D
	ds_load_b32 v38, v35 offset:16896                          // 0000000FB908: D8D84200 26000023
	v_add_nc_u32_e32 v36, -1, v36                              // 0000000FB910: 4A4848C1
	.long 0xd700011d                                           // 0000000FB914: D700011D
	v_cndmask_b32_e32 v0, v29, v132, vcc_lo                    // 0000000FB918: 0201091D
	v_add_nc_u32_e32 v35, 0x84, v35                            // 0000000FB91C: 4A4646FF 00000084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000FB924: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000FB92C: BF870004
	.long 0xd44a0004                                           // 0000000FB930: D44A0004
	v_cndmask_b32_e32 v1, 0, v36, vcc_lo                       // 0000000FB934: 02024880
	s_or_b32 s15, s4, s15                                      // 0000000FB938: 8C0F0F04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FB93C: BF890007
	v_fmac_f32_e32 v34, v37, v38                               // 0000000FB940: 56444D25
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000000FB944: 917E0F7E
	s_cbranch_execnz 65517                                     // 0000000FB948: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1900>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000000FB94C: 8C7E0F7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FB950: BF870121
	v_bfe_u32 v35, v34, 16, 1                                  // 0000000FB954: D6100023 02052122
	v_mad_u64_u32 v[29:30], null, 0x3000, v33, v[9:10]         // 0000000FB95C: D6FE7C1D 042642FF 00003000
	v_add3_u32 v33, v34, v35, 0x7fff                           // 0000000FB968: D6550021 03FE4722 00007FFF
	global_store_d16_hi_b16 v[29:30], v33, off                 // 0000000FB974: DC960000 007C211D
	s_branch 65388                                             // 0000000FB97C: BFA0FF6C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1730>
	s_or_b32 exec_lo, exec_lo, s12                             // 0000000FB980: 8C7E0C7E
	v_mov_b32_e32 v3, v0                                       // 0000000FB984: 7E060300
	s_mov_b32 s4, 0                                            // 0000000FB988: BE840080
	s_waitcnt_vscnt null, 0x0                                  // 0000000FB98C: BC7C0000
	s_barrier                                                  // 0000000FB990: BFBD0000
	buffer_gl0_inv                                             // 0000000FB994: E0AC0000 00000000
	s_nop 0                                                    // 0000000FB99C: BF800000
	s_nop 0                                                    // 0000000FB9A0: BF800000
	s_nop 0                                                    // 0000000FB9A4: BF800000
	s_nop 0                                                    // 0000000FB9A8: BF800000
	s_nop 0                                                    // 0000000FB9AC: BF800000
	s_nop 0                                                    // 0000000FB9B0: BF800000
	s_nop 0                                                    // 0000000FB9B4: BF800000
	s_nop 0                                                    // 0000000FB9B8: BF800000
	s_nop 0                                                    // 0000000FB9BC: BF800000
	v_lshrrev_b32_e32 v29, 7, v3                               // 0000000FB9C0: 323A0687
	v_add_nc_u32_e32 v31, 0x80, v3                             // 0000000FB9C4: 4A3E06FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB9CC: BF870092
	v_or_b32_e32 v27, s11, v29                                 // 0000000FB9D0: 38363A0B
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000FB9D4: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FB9DC: BF870091
	.long 0xd73c001b                                           // 0000000FB9E0: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000FB9E4: 02023689
	.long 0xd700011b                                           // 0000000FB9E8: D700011B
	v_cndmask_b32_e32 v1, v55, v27, vcc_lo                     // 0000000FB9EC: 02023737
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FB9F0: BF870001
	v_add_co_ci_u32_e64 v28, null, v56, v28, s1                // 0000000FB9F4: D5207C1C 00063938
	.long 0xd4490001                                           // 0000000FB9FC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v3, vcc_lo                    // 0000000FBA00: 020206FF 0000077F
	v_mov_b32_e32 v3, v31                                      // 0000000FBA08: 7E06031F
	global_load_b32 v30, v[27:28], off                         // 0000000FBA0C: DC520000 1E7C001B
	v_mad_u64_u32 v[27:28], null, 0x204, v29, v[7:8]           // 0000000FBA14: D6FE7C1B 041E3AFF 00000204
	s_or_b32 s4, s1, s4                                        // 0000000FBA20: 8C040401
	s_waitcnt vmcnt(0)                                         // 0000000FBA24: BF8903F7
	ds_store_b32 v27, v30                                      // 0000000FBA28: D8340000 00001E1B
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FBA30: 917E047E
	s_cbranch_execnz 65506                                     // 0000000FBA34: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FBA38: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000FBA3C: BF89FC07
	s_barrier                                                  // 0000000FBA40: BFBD0000
	buffer_gl0_inv                                             // 0000000FBA44: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 0000000FBA4C: BE8B2000
	s_cbranch_execz 155                                        // 0000000FBA50: BFA5009B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	v_dual_mov_b32 v28, v20 :: v_dual_mov_b32 v27, v19         // 0000000FBA54: CA100114 1C1A0113
	v_dual_mov_b32 v3, v59 :: v_dual_mov_b32 v32, v0           // 0000000FBA5C: CA10013B 03200100
	v_mov_b32_e32 v31, v54                                     // 0000000FBA64: 7E3E0336
	s_mov_b32 s12, 0                                           // 0000000FBA68: BE8C0080
	s_branch 19                                                // 0000000FBA6C: BFA00013 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1abc>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000FBA70: 8C7E0D7E
	v_add_nc_u32_e32 v29, 0x80, v32                            // 0000000FBA74: 4A3A40FF 00000080
	.long 0xd4490001                                           // 0000000FBA7C: D4490001
	v_cndmask_b32_e32 v1, 0x17f, v32, vcc_lo                   // 0000000FBA80: 020240FF 0000017F
	.long 0xd700041b                                           // 0000000FBA88: D700041B
	v_cndmask_b32_e32 v1, 0x400, v27, vcc_lo                   // 0000000FBA8C: 020236FF 00000400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000FBA94: BF8704C3
	v_dual_mov_b32 v32, v29 :: v_dual_add_nc_u32 v31, 4, v31   // 0000000FBA98: CA20011D 201E3E84
	v_add_nc_u32_e32 v3, 0x810, v3                             // 0000000FBAA0: 4A0606FF 00000810
	v_add_co_ci_u32_e64 v28, null, 0, v28, s4                  // 0000000FBAA8: D5207C1C 00123880
	s_or_b32 s12, s1, s12                                      // 0000000FBAB0: 8C0C0C01
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 0000000FBAB4: 917E0C7E
	s_cbranch_execz 129                                        // 0000000FBAB8: BFA50081 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FBABC: BF8700A2
	v_lshrrev_b32_e32 v29, 5, v32                              // 0000000FBAC0: 323A4085
	s_mov_b32 s13, exec_lo                                     // 0000000FBAC4: BE8D007E
	v_or3_b32 v33, v29, s7, 48                                 // 0000000FBAC8: D6580021 02C00F1D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FBAD0: BF870001
	.long 0xd4c4007e                                           // 0000000FBAD4: D4C4007E
	v_cndmask_b32_e32 v1, s30, v33, vcc_lo                     // 0000000FBAD8: 0202421E
	s_cbranch_execz 65508                                      // 0000000FBADC: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a70>
	v_mov_b32_e32 v34, 0                                       // 0000000FBAE0: 7E440280
	v_mov_b32_e32 v30, v1                                      // 0000000FBAE4: 7E3C0301
	s_movk_i32 s1, 0xfe00                                      // 0000000FBAE8: B001FE00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FBAEC: BF870009
	v_add_nc_u32_e32 v66, s1, v3                               // 0000000FBAF0: 4A840601
	s_add_i32 s1, s1, 64                                       // 0000000FBAF4: 8101C001
	ds_load_2addr_b32 v[35:36], v30 offset1:33                 // 0000000FBAF8: D8DC2100 2300001E
	ds_load_2addr_b32 v[37:38], v66 offset0:128 offset1:129    // 0000000FBB00: D8DC8180 25000042
	ds_load_2addr_b32 v[39:40], v30 offset0:66 offset1:99      // 0000000FBB08: D8DC6342 2700001E
	ds_load_2addr_b32 v[41:42], v66 offset0:130 offset1:131    // 0000000FBB10: D8DC8382 29000042
	ds_load_2addr_b32 v[60:61], v30 offset0:132 offset1:165    // 0000000FBB18: D8DCA584 3C00001E
	ds_load_2addr_b32 v[62:63], v66 offset0:132 offset1:133    // 0000000FBB20: D8DC8584 3E000042
	ds_load_2addr_b32 v[64:65], v66 offset0:134 offset1:135    // 0000000FBB28: D8DC8786 40000042
	s_cmp_lg_u32 s1, 0                                         // 0000000FBB30: BF078001
	s_waitcnt lgkmcnt(5)                                       // 0000000FBB34: BF89FC57
	v_dual_fmac_f32 v34, v37, v35 :: v_dual_add_nc_u32 v67, 0x400, v30// 0000000FBB38: C8204725 22423CFF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FBB44: BF8700D1
	v_fmac_f32_e32 v34, v38, v36                               // 0000000FBB48: 56444926
	ds_load_2addr_b32 v[35:36], v30 offset0:198 offset1:231    // 0000000FBB4C: D8DCE7C6 2300001E
	v_add_nc_u32_e32 v30, 0x840, v30                           // 0000000FBB54: 4A3C3CFF 00000840
	s_waitcnt lgkmcnt(4)                                       // 0000000FBB5C: BF89FC47
	v_fmac_f32_e32 v34, v41, v39                               // 0000000FBB60: 56444F29
	v_fmac_f32_e32 v34, v42, v40                               // 0000000FBB64: 5644512A
	ds_load_2addr_b32 v[37:38], v66 offset0:136 offset1:137    // 0000000FBB68: D8DC8988 25000042
	ds_load_2addr_b32 v[39:40], v67 offset0:8 offset1:41       // 0000000FBB70: D8DC2908 27000043
	s_waitcnt lgkmcnt(4)                                       // 0000000FBB78: BF89FC47
	v_fmac_f32_e32 v34, v62, v60                               // 0000000FBB7C: 5644793E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FBB80: BF8700D1
	v_fmac_f32_e32 v34, v63, v61                               // 0000000FBB84: 56447B3F
	ds_load_2addr_b32 v[41:42], v66 offset0:138 offset1:139    // 0000000FBB88: D8DC8B8A 29000042
	ds_load_2addr_b32 v[60:61], v67 offset0:74 offset1:107     // 0000000FBB90: D8DC6B4A 3C000043
	s_waitcnt lgkmcnt(4)                                       // 0000000FBB98: BF89FC47
	v_fmac_f32_e32 v34, v64, v35                               // 0000000FBB9C: 56444740
	v_fmac_f32_e32 v34, v65, v36                               // 0000000FBBA0: 56444941
	ds_load_2addr_b32 v[35:36], v67 offset0:140 offset1:173    // 0000000FBBA4: D8DCAD8C 23000043
	ds_load_2addr_b32 v[62:63], v66 offset0:140 offset1:141    // 0000000FBBAC: D8DC8D8C 3E000042
	ds_load_2addr_b32 v[64:65], v66 offset0:142 offset1:143    // 0000000FBBB4: D8DC8F8E 40000042
	s_waitcnt lgkmcnt(5)                                       // 0000000FBBBC: BF89FC57
	v_fmac_f32_e32 v34, v37, v39                               // 0000000FBBC0: 56444F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000FBBC4: BF8700C1
	v_fmac_f32_e32 v34, v38, v40                               // 0000000FBBC8: 56445126
	ds_load_2addr_b32 v[37:38], v67 offset0:206 offset1:239    // 0000000FBBCC: D8DCEFCE 25000043
	s_waitcnt lgkmcnt(4)                                       // 0000000FBBD4: BF89FC47
	v_fmac_f32_e32 v34, v41, v60                               // 0000000FBBD8: 56447929
	v_fmac_f32_e32 v34, v42, v61                               // 0000000FBBDC: 56447B2A
	s_waitcnt lgkmcnt(2)                                       // 0000000FBBE0: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBBE4: BF870091
	v_fmac_f32_e32 v34, v62, v35                               // 0000000FBBE8: 5644473E
	v_fmac_f32_e32 v34, v63, v36                               // 0000000FBBEC: 5644493F
	s_waitcnt lgkmcnt(0)                                       // 0000000FBBF0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FBBF4: BF870091
	v_fmac_f32_e32 v34, v64, v37                               // 0000000FBBF8: 56444B40
	v_fmac_f32_e32 v34, v65, v38                               // 0000000FBBFC: 56444D41
	s_cbranch_scc1 65466                                       // 0000000FBC00: BFA2FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1aec>
	v_lshlrev_b32_e32 v29, 2, v29                              // 0000000FBC04: 303A3A82
	v_mov_b32_e32 v35, v1                                      // 0000000FBC08: 7E460301
	s_mov_b32 s14, 0                                           // 0000000FBC0C: BE8E0080
	ds_load_b32 v36, v29 offset:34048                          // 0000000FBC10: D8D88500 2400001D
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000FBC18: CA10011C 1E1C011B
	s_waitcnt lgkmcnt(0)                                       // 0000000FBC20: BF89FC07
	v_mul_f32_e32 v34, v34, v36                                // 0000000FBC24: 10444922
	v_mov_b32_e32 v36, v31                                     // 0000000FBC28: 7E48031F
	s_nop 0                                                    // 0000000FBC2C: BF800000
	s_nop 0                                                    // 0000000FBC30: BF800000
	s_nop 0                                                    // 0000000FBC34: BF800000
	s_nop 0                                                    // 0000000FBC38: BF800000
	s_nop 0                                                    // 0000000FBC3C: BF800000
	global_load_b32 v37, v[29:30], off                         // 0000000FBC40: DC520000 257C001D
	ds_load_b32 v38, v35 offset:16896                          // 0000000FBC48: D8D84200 26000023
	v_add_nc_u32_e32 v36, -1, v36                              // 0000000FBC50: 4A4848C1
	.long 0xd700011d                                           // 0000000FBC54: D700011D
	v_cndmask_b32_e32 v0, v29, v132, vcc_lo                    // 0000000FBC58: 0201091D
	v_add_nc_u32_e32 v35, 0x84, v35                            // 0000000FBC5C: 4A4646FF 00000084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000FBC64: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000FBC6C: BF870004
	.long 0xd44a0004                                           // 0000000FBC70: D44A0004
	v_cndmask_b32_e32 v1, 0, v36, vcc_lo                       // 0000000FBC74: 02024880
	s_or_b32 s14, s4, s14                                      // 0000000FBC78: 8C0E0E04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FBC7C: BF890007
	v_fmac_f32_e32 v34, v37, v38                               // 0000000FBC80: 56444D25
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000FBC84: 917E0E7E
	s_cbranch_execnz 65517                                     // 0000000FBC88: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c40>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000FBC8C: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FBC90: BF870121
	v_bfe_u32 v35, v34, 16, 1                                  // 0000000FBC94: D6100023 02052122
	v_mad_u64_u32 v[29:30], null, 0x3000, v33, v[9:10]         // 0000000FBC9C: D6FE7C1D 042642FF 00003000
	v_add3_u32 v33, v34, v35, 0x7fff                           // 0000000FBCA8: D6550021 03FE4722 00007FFF
	global_store_d16_hi_b16 v[29:30], v33, off                 // 0000000FBCB4: DC960000 007C211D
	s_branch 65388                                             // 0000000FBCBC: BFA0FF6C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a70>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000000FBCC0: 8C7E0B7E
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000FBCC4: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v27, v0                                      // 0000000FBCCC: 7E360300
	s_waitcnt_vscnt null, 0x0                                  // 0000000FBCD0: BC7C0000
	s_barrier                                                  // 0000000FBCD4: BFBD0000
	s_xor_b32 s4, s1, 0x80000000                               // 0000000FBCD8: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000FBCE0: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000FBCE4: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000FBCEC: BF4EFF0A C2CE8ED0
	buffer_gl0_inv                                             // 0000000FBCF4: E0AC0000 00000000
	s_sub_f32 s1, s1, s11                                      // 0000000FBCFC: A0810B01
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000FBD00: A304040A 32A5705F
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_2)// 0000000FBD08: BF87052B
	s_add_f32 s1, s1, s4                                       // 0000000FBD0C: A0010401
	s_mov_b32 s4, 0                                            // 0000000FBD10: BE840080
	v_exp_f32_e32 v3, s1                                       // 0000000FBD14: 7E064A01
	s_cvt_i32_f32 s1, s11                                      // 0000000FBD18: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000FBD1C: BF870585
	.long 0xd71c0003                                           // 0000000FBD20: D71C0003
	v_cndmask_b32_e32 v0, v3, v1, vcc_lo                       // 0000000FBD24: 02000303
	s_cselect_b32 s1, -1, 0                                    // 0000000FBD28: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000FBD2C: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FBD34: BF870001
	v_cndmask_b32_e64 v3, 0, v3, s1                            // 0000000FBD38: D5010003 00060680
	s_cselect_b32 s1, -1, 0                                    // 0000000FBD40: 980180C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000FBD44: BF870481
	v_cndmask_b32_e64 v3, 0x7f800000, v3, s1                   // 0000000FBD48: D5010003 000606FF 7F800000
	s_nop 0                                                    // 0000000FBD54: BF800000
	s_nop 0                                                    // 0000000FBD58: BF800000
	s_nop 0                                                    // 0000000FBD5C: BF800000
	s_nop 0                                                    // 0000000FBD60: BF800000
	s_nop 0                                                    // 0000000FBD64: BF800000
	s_nop 0                                                    // 0000000FBD68: BF800000
	s_nop 0                                                    // 0000000FBD6C: BF800000
	s_nop 0                                                    // 0000000FBD70: BF800000
	s_nop 0                                                    // 0000000FBD74: BF800000
	s_nop 0                                                    // 0000000FBD78: BF800000
	s_nop 0                                                    // 0000000FBD7C: BF800000
	v_lshrrev_b32_e32 v28, 5, v27                              // 0000000FBD80: 32383685
	.long 0xd4490001                                           // 0000000FBD84: D4490001
	v_cndmask_b32_e32 v1, 0xf7f, v27, vcc_lo                   // 0000000FBD88: 020236FF 00000F7F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FBD90: BF8700D2
	v_mad_u64_u32 v[28:29], null, 0x84, v28, v[1:2]            // 0000000FBD94: D6FE7C1C 040638FF 00000084
	s_or_b32 s4, s1, s4                                        // 0000000FBDA0: 8C040401
	ds_load_b32 v29, v28                                       // 0000000FBDA4: D8D80000 1D00001C
	s_waitcnt lgkmcnt(0)                                       // 0000000FBDAC: BF89FC07
	v_dual_mul_f32 v29, v3, v29 :: v_dual_add_nc_u32 v30, 0x80, v27// 0000000FBDB0: C8E03B03 1D1E36FF 00000080
	v_mov_b32_e32 v27, v30                                     // 0000000FBDBC: 7E36031E
	ds_store_b32 v28, v29                                      // 0000000FBDC0: D8340000 00001D1C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FBDC8: 917E047E
	s_cbranch_execnz 65516                                     // 0000000FBDCC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d80>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FBDD0: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000FBDD4: BF89FC07
	s_barrier                                                  // 0000000FBDD8: BFBD0000
	buffer_gl0_inv                                             // 0000000FBDDC: E0AC0000 00000000
	s_and_saveexec_b32 s10, s5                                 // 0000000FBDE4: BE8A2005
	s_cbranch_execz 45                                         // 0000000FBDE8: BFA5002D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ea0>
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v28, v18            // 0000000FBDEC: CA100080 031C0112
	v_dual_mov_b32 v27, v17 :: v_dual_mov_b32 v30, v44         // 0000000FBDF4: CA100111 1B1E012C
	v_mov_b32_e32 v29, 0                                       // 0000000FBDFC: 7E3A0280
	s_mov_b32 s11, 0                                           // 0000000FBE00: BE8B0080
	s_nop 0                                                    // 0000000FBE04: BF800000
	s_nop 0                                                    // 0000000FBE08: BF800000
	s_nop 0                                                    // 0000000FBE0C: BF800000
	s_nop 0                                                    // 0000000FBE10: BF800000
	s_nop 0                                                    // 0000000FBE14: BF800000
	s_nop 0                                                    // 0000000FBE18: BF800000
	s_nop 0                                                    // 0000000FBE1C: BF800000
	s_nop 0                                                    // 0000000FBE20: BF800000
	s_nop 0                                                    // 0000000FBE24: BF800000
	s_nop 0                                                    // 0000000FBE28: BF800000
	s_nop 0                                                    // 0000000FBE2C: BF800000
	s_nop 0                                                    // 0000000FBE30: BF800000
	s_nop 0                                                    // 0000000FBE34: BF800000
	s_nop 0                                                    // 0000000FBE38: BF800000
	s_nop 0                                                    // 0000000FBE3C: BF800000
	global_load_b32 v31, v[27:28], off                         // 0000000FBE40: DC520000 1F7C001B
	ds_load_b32 v32, v29 offset:33600                          // 0000000FBE48: D8D88340 2000001D
	v_add_nc_u32_e32 v3, -1, v3                                // 0000000FBE50: 4A0606C1
	.long 0xd700011b                                           // 0000000FBE54: D700011B
	v_cndmask_b32_e32 v1, 0x6000, v27, vcc_lo                  // 0000000FBE58: 020236FF 00006000
	v_add_nc_u32_e32 v29, 4, v29                               // 0000000FBE60: 4A3A3A84
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000FBE64: D5207C1C 00063880
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000FBE6C: BF870004
	.long 0xd44a0004                                           // 0000000FBE70: D44A0004
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 0000000FBE74: 02020680
	s_or_b32 s11, s4, s11                                      // 0000000FBE78: 8C0B0B04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FBE7C: BF890007
	v_mul_f32_e32 v31, v31, v32                                // 0000000FBE80: 103E411F
	ds_store_b32 v30, v31 offset:25344                         // 0000000FBE84: D8346300 00001F1E
	v_add_nc_u32_e32 v30, 0x204, v30                           // 0000000FBE8C: 4A3C3CFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 0000000FBE94: 917E0B7E
	s_cbranch_execnz 65513                                     // 0000000FBE98: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e40>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000000FBE9C: 8C7E0B7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FBEA0: BF870009
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000FBEA4: 8C7E0A7E
	v_mov_b32_e32 v3, v0                                       // 0000000FBEA8: 7E060300
	s_mov_b32 s4, 0                                            // 0000000FBEAC: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000FBEB0: BF870241
	v_add_nc_u32_e32 v27, 0x80, v3                             // 0000000FBEB4: 4A3606FF 00000080
	v_add_nc_u32_e32 v28, 0x100, v3                            // 0000000FBEBC: 4A3806FF 00000100
	v_lshrrev_b32_e32 v35, 7, v3                               // 0000000FBEC4: 32460687
	v_add_nc_u32_e32 v29, 0x180, v3                            // 0000000FBEC8: 4A3A06FF 00000180
	v_lshrrev_b32_e32 v36, 7, v27                              // 0000000FBED0: 32483687
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000FBED4: BF870214
	v_lshrrev_b32_e32 v37, 7, v28                              // 0000000FBED8: 324A3887
	v_or_b32_e32 v27, s7, v35                                  // 0000000FBEDC: 38364607
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000FBEE0: BF870214
	v_lshrrev_b32_e32 v38, 7, v29                              // 0000000FBEE4: 324C3A87
	v_or_b32_e32 v29, s7, v36                                  // 0000000FBEE8: 383A4807
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000FBEEC: BF870214
	v_or_b32_e32 v31, s7, v37                                  // 0000000FBEF0: 383E4A07
	v_mad_u64_u32 v[27:28], null, v27, 48, s[2:3]              // 0000000FBEF4: D6FE7C1B 0009611B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000FBEFC: BF870214
	v_or_b32_e32 v33, s7, v38                                  // 0000000FBF00: 38424C07
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000FBF04: D6FE7C1D 0009611D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000FBF0C: BF870194
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 0000000FBF10: D6FE7C1F 0009611F
	v_mad_u64_u32 v[33:34], null, v33, 48, s[2:3]              // 0000000FBF18: D6FE7C21 00096121
	.long 0xd73c001b                                           // 0000000FBF20: D73C001B
	v_cndmask_b32_e32 v1, 9, v27, vcc_lo                       // 0000000FBF24: 02023689
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000FBF28: BF870214
	.long 0xd73c001d                                           // 0000000FBF2C: D73C001D
	v_cndmask_b32_e32 v1, 9, v29, vcc_lo                       // 0000000FBF30: 02023A89
	.long 0xd73c001f                                           // 0000000FBF34: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 0000000FBF38: 02023E89
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000FBF3C: BF870214
	.long 0xd73c0021                                           // 0000000FBF40: D73C0021
	v_cndmask_b32_e32 v1, 9, v33, vcc_lo                       // 0000000FBF44: 02024289
	.long 0xd700011b                                           // 0000000FBF48: D700011B
	v_cndmask_b32_e32 v1, v57, v27, vcc_lo                     // 0000000FBF4C: 02023739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FBF50: BF8700A1
	v_add_co_ci_u32_e64 v28, null, v58, v28, s1                // 0000000FBF54: D5207C1C 0006393A
	.long 0xd700011d                                           // 0000000FBF5C: D700011D
	v_cndmask_b32_e32 v1, v57, v29, vcc_lo                     // 0000000FBF60: 02023B39
	v_add_co_ci_u32_e64 v30, null, v58, v30, s1                // 0000000FBF64: D5207C1E 00063D3A
	.long 0xd700011f                                           // 0000000FBF6C: D700011F
	v_cndmask_b32_e32 v1, v57, v31, vcc_lo                     // 0000000FBF70: 02023F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FBF74: BF8700A1
	v_add_co_ci_u32_e64 v32, null, v58, v32, s1                // 0000000FBF78: D5207C20 0006413A
	.long 0xd7000121                                           // 0000000FBF80: D7000121
	v_cndmask_b32_e32 v1, v57, v33, vcc_lo                     // 0000000FBF84: 02024339
	v_add_co_ci_u32_e64 v34, null, v58, v34, s1                // 0000000FBF88: D5207C22 0006453A
	s_clause 0x3                                               // 0000000FBF90: BF850003
	global_load_b32 v39, v[27:28], off                         // 0000000FBF94: DC520000 277C001B
	global_load_b32 v40, v[29:30], off                         // 0000000FBF9C: DC520000 287C001D
	global_load_b32 v32, v[31:32], off                         // 0000000FBFA4: DC520000 207C001F
	global_load_b32 v33, v[33:34], off                         // 0000000FBFAC: DC520000 217C0021
	v_lshlrev_b32_e32 v27, 2, v35                              // 0000000FBFB4: 30364682
	v_lshlrev_b32_e32 v28, 2, v36                              // 0000000FBFB8: 30384882
	v_lshlrev_b32_e32 v29, 2, v37                              // 0000000FBFBC: 303A4A82
	v_lshlrev_b32_e32 v30, 2, v38                              // 0000000FBFC0: 303C4C82
	ds_load_b32 v34, v27 offset:33600                          // 0000000FBFC4: D8D88340 2200001B
	ds_load_b32 v41, v28 offset:33600                          // 0000000FBFCC: D8D88340 2900001C
	ds_load_b32 v42, v29 offset:33600                          // 0000000FBFD4: D8D88340 2A00001D
	ds_load_b32 v60, v30 offset:33600                          // 0000000FBFDC: D8D88340 3C00001E
	v_mad_u64_u32 v[27:28], null, 0x204, v35, v[7:8]           // 0000000FBFE4: D6FE7C1B 041E46FF 00000204
	v_mad_u64_u32 v[28:29], null, 0x204, v36, v[7:8]           // 0000000FBFF0: D6FE7C1C 041E48FF 00000204
	.long 0xd4490001                                           // 0000000FBFFC: D4490001
	v_cndmask_b32_e32 v1, 0x5ff, v3, vcc_lo                    // 0000000FC000: 020206FF 000005FF
	v_mad_u64_u32 v[29:30], null, 0x204, v37, v[7:8]           // 0000000FC008: D6FE7C1D 041E4AFF 00000204
	v_mad_u64_u32 v[30:31], null, 0x204, v38, v[7:8]           // 0000000FC014: D6FE7C1E 041E4CFF 00000204
	v_add_nc_u32_e32 v3, 0x200, v3                             // 0000000FC020: 4A0606FF 00000200
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000FC028: BF870004
	s_or_b32 s4, s1, s4                                        // 0000000FC02C: 8C040401
	s_waitcnt vmcnt(2) lgkmcnt(2)                              // 0000000FC030: BF890827
	v_dual_mul_f32 v31, v39, v34 :: v_dual_mul_f32 v34, v40, v41// 0000000FC034: C8C64527 1F225328
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FC03C: BF890007
	v_dual_mul_f32 v32, v32, v42 :: v_dual_mul_f32 v33, v33, v60// 0000000FC040: C8C65520 20207921
	ds_store_b32 v27, v31                                      // 0000000FC048: D8340000 00001F1B
	ds_store_b32 v28, v34                                      // 0000000FC050: D8340000 0000221C
	ds_store_b32 v29, v32                                      // 0000000FC058: D8340000 0000201D
	ds_store_b32 v30, v33                                      // 0000000FC060: D8340000 0000211E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FC068: 917E047E
	s_cbranch_execnz 65424                                     // 0000000FC06C: BFA6FF90 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1eb0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FC070: 8C7E047E
	v_add_nc_u32_e32 v3, 0x400, v8                             // 0000000FC074: 4A0610FF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000FC07C: BF89FC07
	s_barrier                                                  // 0000000FC080: BFBD0000
	buffer_gl0_inv                                             // 0000000FC084: E0AC0000 00000000
	ds_load_2addr_b32 v[27:28], v8 offset1:33                  // 0000000FC08C: D8DC2100 1B000008
	ds_load_2addr_b32 v[29:30], v8 offset0:66 offset1:99       // 0000000FC094: D8DC6342 1D000008
	ds_load_2addr_b32 v[31:32], v8 offset0:132 offset1:165     // 0000000FC09C: D8DCA584 1F000008
	ds_load_2addr_b32 v[33:34], v8 offset0:198 offset1:231     // 0000000FC0A4: D8DCE7C6 21000008
	ds_load_2addr_b32 v[35:36], v3 offset0:8 offset1:41        // 0000000FC0AC: D8DC2908 23000003
	ds_load_2addr_b32 v[37:38], v3 offset0:74 offset1:107      // 0000000FC0B4: D8DC6B4A 25000003
	ds_load_2addr_b32 v[39:40], v3 offset0:140 offset1:173     // 0000000FC0BC: D8DCAD8C 27000003
	ds_load_2addr_b32 v[41:42], v3 offset0:206 offset1:239     // 0000000FC0C4: D8DCEFCE 29000003
	v_mov_b32_e32 v3, v0                                       // 0000000FC0CC: 7E060300
	s_mov_b32 s4, 0                                            // 0000000FC0D0: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FC0D4: BF870121
	v_lshrrev_b32_e32 v60, 5, v3                               // 0000000FC0D8: 32780685
	.long 0xd4490001                                           // 0000000FC0DC: D4490001
	v_cndmask_b32_e32 v1, 0xf7f, v3, vcc_lo                    // 0000000FC0E0: 020206FF 00000F7F
	v_lshlrev_b32_e32 v67, 2, v60                              // 0000000FC0E8: 30867882
	v_mad_u64_u32 v[60:61], null, 0x84, v60, v[1:2]            // 0000000FC0EC: D6FE7C3C 040678FF 00000084
	s_or_b32 s4, s1, s4                                        // 0000000FC0F8: 8C040401
	v_add_nc_u32_e32 v61, 0x6200, v67                          // 0000000FC0FC: 4A7A86FF 00006200
	ds_load_b32 v68, v60                                       // 0000000FC104: D8D80000 4400003C
	ds_load_2addr_b32 v[61:62], v61 offset0:64 offset1:193     // 0000000FC10C: D8DCC140 3D00003D
	s_waitcnt lgkmcnt(0)                                       // 0000000FC114: BF89FC07
	v_fmac_f32_e32 v68, v61, v27                               // 0000000FC118: 5688373D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FC11C: BF870001
	v_dual_fmac_f32 v68, v62, v28 :: v_dual_add_nc_u32 v63, 0x6600, v67// 0000000FC120: C820393E 443E86FF 00006600
	ds_load_2addr_b32 v[63:64], v63 offset0:66 offset1:195     // 0000000FC12C: D8DCC342 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000000FC134: BF89FC07
	v_dual_fmac_f32 v68, v63, v29 :: v_dual_add_nc_u32 v65, 0x6a00, v67// 0000000FC138: C8203B3F 444086FF 00006A00
	ds_load_2addr_b32 v[65:66], v65 offset0:68 offset1:197     // 0000000FC144: D8DCC544 41000041
	v_fmac_f32_e32 v68, v64, v30                               // 0000000FC14C: 56883D40
	s_waitcnt lgkmcnt(0)                                       // 0000000FC150: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC154: BF870091
	v_fmac_f32_e32 v68, v65, v31                               // 0000000FC158: 56883F41
	v_dual_fmac_f32 v68, v66, v32 :: v_dual_add_nc_u32 v61, 0x6e00, v67// 0000000FC15C: C8204142 443C86FF 00006E00
	ds_load_2addr_b32 v[61:62], v61 offset0:70 offset1:199     // 0000000FC168: D8DCC746 3D00003D
	s_waitcnt lgkmcnt(0)                                       // 0000000FC170: BF89FC07
	v_dual_fmac_f32 v68, v61, v33 :: v_dual_add_nc_u32 v63, 0x7200, v67// 0000000FC174: C820433D 443E86FF 00007200
	ds_load_2addr_b32 v[63:64], v63 offset0:72 offset1:201     // 0000000FC180: D8DCC948 3F00003F
	v_dual_fmac_f32 v68, v62, v34 :: v_dual_add_nc_u32 v65, 0x7600, v67// 0000000FC188: C820453E 444086FF 00007600
	ds_load_2addr_b32 v[65:66], v65 offset0:74 offset1:203     // 0000000FC194: D8DCCB4A 41000041
	s_waitcnt lgkmcnt(1)                                       // 0000000FC19C: BF89FC17
	v_fmac_f32_e32 v68, v63, v35                               // 0000000FC1A0: 5688473F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FC1A4: BF870001
	v_dual_fmac_f32 v68, v64, v36 :: v_dual_add_nc_u32 v61, 0x7a00, v67// 0000000FC1A8: C8204940 443C86FF 00007A00
	ds_load_2addr_b32 v[61:62], v61 offset0:76 offset1:205     // 0000000FC1B4: D8DCCD4C 3D00003D
	s_waitcnt lgkmcnt(1)                                       // 0000000FC1BC: BF89FC17
	v_dual_fmac_f32 v68, v65, v37 :: v_dual_add_nc_u32 v63, 0x7e00, v67// 0000000FC1C0: C8204B41 443E86FF 00007E00
	ds_load_2addr_b32 v[63:64], v63 offset0:78 offset1:207     // 0000000FC1CC: D8DCCF4E 3F00003F
	v_fmac_f32_e32 v68, v66, v38                               // 0000000FC1D4: 56884D42
	s_waitcnt lgkmcnt(1)                                       // 0000000FC1D8: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC1DC: BF870091
	v_fmac_f32_e32 v68, v61, v39                               // 0000000FC1E0: 56884F3D
	v_dual_fmac_f32 v68, v62, v40 :: v_dual_add_nc_u32 v61, 0x80, v3// 0000000FC1E4: C820513E 443C06FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 0000000FC1F0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC1F4: BF870091
	v_dual_mov_b32 v3, v61 :: v_dual_fmac_f32 v68, v63, v41    // 0000000FC1F8: CA00013D 0344533F
	v_fmac_f32_e32 v68, v64, v42                               // 0000000FC200: 56885540
	ds_store_b32 v60, v68                                      // 0000000FC204: D8340000 0000443C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FC20C: 917E047E
	s_cbranch_execnz 65456                                     // 0000000FC210: BFA6FFB0 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x20d4>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FC214: 8C7E047E
	v_dual_mov_b32 v28, v22 :: v_dual_mov_b32 v27, v21         // 0000000FC218: CA100116 1C1A0115
	v_dual_mov_b32 v3, v44 :: v_dual_mov_b32 v30, v43          // 0000000FC220: CA10012C 031E012B
	v_mov_b32_e32 v29, 0                                       // 0000000FC228: 7E3A0280
	s_mov_b32 s7, 0                                            // 0000000FC22C: BE870080
	s_waitcnt lgkmcnt(0)                                       // 0000000FC230: BF89FC07
	s_barrier                                                  // 0000000FC234: BFBD0000
	buffer_gl0_inv                                             // 0000000FC238: E0AC0000 00000000
	global_load_b32 v31, v[27:28], off                         // 0000000FC240: DC520000 1F7C001B
	ds_load_b32 v32, v29 offset:33664                          // 0000000FC248: D8D88380 2000001D
	v_add_nc_u32_e32 v30, 0x80, v30                            // 0000000FC250: 4A3C3CFF 00000080
	.long 0xd700011b                                           // 0000000FC258: D700011B
	v_cndmask_b32_e32 v1, 0x6000, v27, vcc_lo                  // 0000000FC25C: 020236FF 00006000
	v_add_nc_u32_e32 v29, 4, v29                               // 0000000FC264: 4A3A3A84
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000FC268: D5207C1C 00063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FC270: BF890007
	v_mul_f32_e32 v31, v31, v32                                // 0000000FC274: 103E411F
	.long 0xd4490004                                           // 0000000FC278: D4490004
	v_cndmask_b32_e32 v1, 0x77f, v30, vcc_lo                   // 0000000FC27C: 02023CFF 0000077F
	ds_store_b32 v3, v31 offset:25344                          // 0000000FC284: D8346300 00001F03
	v_add_nc_u32_e32 v3, 0x204, v3                             // 0000000FC28C: 4A0606FF 00000204
	s_or_b32 s7, s4, s7                                        // 0000000FC294: 8C070704
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FC298: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000000FC29C: 917E077E
	s_cbranch_execnz 65511                                     // 0000000FC2A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2240>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000FC2A4: 8C7E077E
	v_add_nc_u32_e32 v3, 0x800, v8                             // 0000000FC2A8: 4A0610FF 00000800
	v_add_nc_u32_e32 v41, 0xc00, v8                            // 0000000FC2B0: 4A5210FF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000FC2B8: BF89FC07
	s_barrier                                                  // 0000000FC2BC: BFBD0000
	buffer_gl0_inv                                             // 0000000FC2C0: E0AC0000 00000000
	ds_load_2addr_b32 v[27:28], v3 offset0:16 offset1:49       // 0000000FC2C8: D8DC3110 1B000003
	ds_load_2addr_b32 v[29:30], v3 offset0:82 offset1:115      // 0000000FC2D0: D8DC7352 1D000003
	ds_load_2addr_b32 v[31:32], v3 offset0:148 offset1:181     // 0000000FC2D8: D8DCB594 1F000003
	ds_load_2addr_b32 v[33:34], v3 offset0:214 offset1:247     // 0000000FC2E0: D8DCF7D6 21000003
	ds_load_2addr_b32 v[35:36], v41 offset0:24 offset1:57      // 0000000FC2E8: D8DC3918 23000029
	ds_load_2addr_b32 v[37:38], v41 offset0:90 offset1:123     // 0000000FC2F0: D8DC7B5A 25000029
	ds_load_2addr_b32 v[39:40], v41 offset0:156 offset1:189    // 0000000FC2F8: D8DCBD9C 27000029
	ds_load_2addr_b32 v[41:42], v41 offset0:222 offset1:255    // 0000000FC300: D8DCFFDE 29000029
	v_mov_b32_e32 v3, v0                                       // 0000000FC308: 7E060300
	s_mov_b32 s4, 0                                            // 0000000FC30C: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FC310: BF870121
	v_lshrrev_b32_e32 v60, 5, v3                               // 0000000FC314: 32780685
	.long 0xd4490001                                           // 0000000FC318: D4490001
	v_cndmask_b32_e32 v1, 0xf7f, v3, vcc_lo                    // 0000000FC31C: 020206FF 00000F7F
	v_lshlrev_b32_e32 v67, 2, v60                              // 0000000FC324: 30867882
	v_mad_u64_u32 v[60:61], null, 0x84, v60, v[1:2]            // 0000000FC328: D6FE7C3C 040678FF 00000084
	s_or_b32 s4, s1, s4                                        // 0000000FC334: 8C040401
	v_add_nc_u32_e32 v61, 0x6200, v67                          // 0000000FC338: 4A7A86FF 00006200
	ds_load_b32 v68, v60                                       // 0000000FC340: D8D80000 4400003C
	ds_load_2addr_b32 v[61:62], v61 offset0:64 offset1:193     // 0000000FC348: D8DCC140 3D00003D
	s_waitcnt lgkmcnt(0)                                       // 0000000FC350: BF89FC07
	v_fmac_f32_e32 v68, v61, v27                               // 0000000FC354: 5688373D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FC358: BF870001
	v_dual_fmac_f32 v68, v62, v28 :: v_dual_add_nc_u32 v63, 0x6600, v67// 0000000FC35C: C820393E 443E86FF 00006600
	ds_load_2addr_b32 v[63:64], v63 offset0:66 offset1:195     // 0000000FC368: D8DCC342 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000000FC370: BF89FC07
	v_dual_fmac_f32 v68, v63, v29 :: v_dual_add_nc_u32 v65, 0x6a00, v67// 0000000FC374: C8203B3F 444086FF 00006A00
	ds_load_2addr_b32 v[65:66], v65 offset0:68 offset1:197     // 0000000FC380: D8DCC544 41000041
	v_fmac_f32_e32 v68, v64, v30                               // 0000000FC388: 56883D40
	s_waitcnt lgkmcnt(0)                                       // 0000000FC38C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC390: BF870091
	v_fmac_f32_e32 v68, v65, v31                               // 0000000FC394: 56883F41
	v_dual_fmac_f32 v68, v66, v32 :: v_dual_add_nc_u32 v61, 0x6e00, v67// 0000000FC398: C8204142 443C86FF 00006E00
	ds_load_2addr_b32 v[61:62], v61 offset0:70 offset1:199     // 0000000FC3A4: D8DCC746 3D00003D
	s_waitcnt lgkmcnt(0)                                       // 0000000FC3AC: BF89FC07
	v_dual_fmac_f32 v68, v61, v33 :: v_dual_add_nc_u32 v63, 0x7200, v67// 0000000FC3B0: C820433D 443E86FF 00007200
	ds_load_2addr_b32 v[63:64], v63 offset0:72 offset1:201     // 0000000FC3BC: D8DCC948 3F00003F
	v_dual_fmac_f32 v68, v62, v34 :: v_dual_add_nc_u32 v65, 0x7600, v67// 0000000FC3C4: C820453E 444086FF 00007600
	ds_load_2addr_b32 v[65:66], v65 offset0:74 offset1:203     // 0000000FC3D0: D8DCCB4A 41000041
	s_waitcnt lgkmcnt(1)                                       // 0000000FC3D8: BF89FC17
	v_fmac_f32_e32 v68, v63, v35                               // 0000000FC3DC: 5688473F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FC3E0: BF870001
	v_dual_fmac_f32 v68, v64, v36 :: v_dual_add_nc_u32 v61, 0x7a00, v67// 0000000FC3E4: C8204940 443C86FF 00007A00
	ds_load_2addr_b32 v[61:62], v61 offset0:76 offset1:205     // 0000000FC3F0: D8DCCD4C 3D00003D
	s_waitcnt lgkmcnt(1)                                       // 0000000FC3F8: BF89FC17
	v_dual_fmac_f32 v68, v65, v37 :: v_dual_add_nc_u32 v63, 0x7e00, v67// 0000000FC3FC: C8204B41 443E86FF 00007E00
	ds_load_2addr_b32 v[63:64], v63 offset0:78 offset1:207     // 0000000FC408: D8DCCF4E 3F00003F
	v_fmac_f32_e32 v68, v66, v38                               // 0000000FC410: 56884D42
	s_waitcnt lgkmcnt(1)                                       // 0000000FC414: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC418: BF870091
	v_fmac_f32_e32 v68, v61, v39                               // 0000000FC41C: 56884F3D
	v_dual_fmac_f32 v68, v62, v40 :: v_dual_add_nc_u32 v61, 0x80, v3// 0000000FC420: C820513E 443C06FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 0000000FC42C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC430: BF870091
	v_dual_mov_b32 v3, v61 :: v_dual_fmac_f32 v68, v63, v41    // 0000000FC434: CA00013D 0344533F
	v_fmac_f32_e32 v68, v64, v42                               // 0000000FC43C: 56885540
	ds_store_b32 v60, v68                                      // 0000000FC440: D8340000 0000443C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FC448: 917E047E
	s_cbranch_execnz 65456                                     // 0000000FC44C: BFA6FFB0 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2310>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FC450: 8C7E047E
	v_dual_mov_b32 v28, v24 :: v_dual_mov_b32 v27, v23         // 0000000FC454: CA100118 1C1A0117
	v_dual_mov_b32 v3, v44 :: v_dual_mov_b32 v30, v43          // 0000000FC45C: CA10012C 031E012B
	v_mov_b32_e32 v29, 0                                       // 0000000FC464: 7E3A0280
	s_mov_b32 s7, 0                                            // 0000000FC468: BE870080
	s_waitcnt lgkmcnt(0)                                       // 0000000FC46C: BF89FC07
	s_barrier                                                  // 0000000FC470: BFBD0000
	buffer_gl0_inv                                             // 0000000FC474: E0AC0000 00000000
	s_nop 0                                                    // 0000000FC47C: BF800000
	global_load_b32 v31, v[27:28], off                         // 0000000FC480: DC520000 1F7C001B
	ds_load_b32 v32, v29 offset:33728                          // 0000000FC488: D8D883C0 2000001D
	v_add_nc_u32_e32 v30, 0x80, v30                            // 0000000FC490: 4A3C3CFF 00000080
	.long 0xd700011b                                           // 0000000FC498: D700011B
	v_cndmask_b32_e32 v1, 0x6000, v27, vcc_lo                  // 0000000FC49C: 020236FF 00006000
	v_add_nc_u32_e32 v29, 4, v29                               // 0000000FC4A4: 4A3A3A84
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000FC4A8: D5207C1C 00063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FC4B0: BF890007
	v_mul_f32_e32 v31, v31, v32                                // 0000000FC4B4: 103E411F
	.long 0xd4490004                                           // 0000000FC4B8: D4490004
	v_cndmask_b32_e32 v1, 0x77f, v30, vcc_lo                   // 0000000FC4BC: 02023CFF 0000077F
	ds_store_b32 v3, v31 offset:25344                          // 0000000FC4C4: D8346300 00001F03
	v_add_nc_u32_e32 v3, 0x204, v3                             // 0000000FC4CC: 4A0606FF 00000204
	s_or_b32 s7, s4, s7                                        // 0000000FC4D4: 8C070704
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FC4D8: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000000FC4DC: 917E077E
	s_cbranch_execnz 65511                                     // 0000000FC4E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2480>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000FC4E4: 8C7E077E
	v_add_nc_u32_e32 v3, 0x1000, v8                            // 0000000FC4E8: 4A0610FF 00001000
	v_add_nc_u32_e32 v33, 0x1200, v8                           // 0000000FC4F0: 4A4210FF 00001200
	v_add_nc_u32_e32 v39, 0x1400, v8                           // 0000000FC4F8: 4A4E10FF 00001400
	s_waitcnt lgkmcnt(0)                                       // 0000000FC500: BF89FC07
	s_barrier                                                  // 0000000FC504: BFBD0000
	buffer_gl0_inv                                             // 0000000FC508: E0AC0000 00000000
	ds_load_2addr_b32 v[27:28], v3 offset0:32 offset1:65       // 0000000FC510: D8DC4120 1B000003
	ds_load_2addr_b32 v[29:30], v3 offset0:98 offset1:131      // 0000000FC518: D8DC8362 1D000003
	ds_load_2addr_b32 v[31:32], v3 offset0:164 offset1:197     // 0000000FC520: D8DCC5A4 1F000003
	v_add_nc_u32_e32 v3, 0x1600, v8                            // 0000000FC528: 4A0610FF 00001600
	ds_load_2addr_b32 v[33:34], v33 offset0:102 offset1:135    // 0000000FC530: D8DC8766 21000021
	ds_load_2addr_b32 v[35:36], v39 offset0:40 offset1:73      // 0000000FC538: D8DC4928 23000027
	ds_load_2addr_b32 v[37:38], v39 offset0:106 offset1:139    // 0000000FC540: D8DC8B6A 25000027
	ds_load_2addr_b32 v[39:40], v39 offset0:172 offset1:205    // 0000000FC548: D8DCCDAC 27000027
	ds_load_2addr_b32 v[41:42], v3 offset0:110 offset1:143     // 0000000FC550: D8DC8F6E 29000003
	v_mov_b32_e32 v3, v0                                       // 0000000FC558: 7E060300
	s_mov_b32 s4, 0                                            // 0000000FC55C: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FC560: BF870121
	v_lshrrev_b32_e32 v60, 5, v3                               // 0000000FC564: 32780685
	.long 0xd4490001                                           // 0000000FC568: D4490001
	v_cndmask_b32_e32 v1, 0xf7f, v3, vcc_lo                    // 0000000FC56C: 020206FF 00000F7F
	v_lshlrev_b32_e32 v67, 2, v60                              // 0000000FC574: 30867882
	v_mad_u64_u32 v[60:61], null, 0x84, v60, v[1:2]            // 0000000FC578: D6FE7C3C 040678FF 00000084
	s_or_b32 s4, s1, s4                                        // 0000000FC584: 8C040401
	v_add_nc_u32_e32 v61, 0x6200, v67                          // 0000000FC588: 4A7A86FF 00006200
	ds_load_b32 v68, v60                                       // 0000000FC590: D8D80000 4400003C
	ds_load_2addr_b32 v[61:62], v61 offset0:64 offset1:193     // 0000000FC598: D8DCC140 3D00003D
	s_waitcnt lgkmcnt(0)                                       // 0000000FC5A0: BF89FC07
	v_fmac_f32_e32 v68, v61, v27                               // 0000000FC5A4: 5688373D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FC5A8: BF870001
	v_dual_fmac_f32 v68, v62, v28 :: v_dual_add_nc_u32 v63, 0x6600, v67// 0000000FC5AC: C820393E 443E86FF 00006600
	ds_load_2addr_b32 v[63:64], v63 offset0:66 offset1:195     // 0000000FC5B8: D8DCC342 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000000FC5C0: BF89FC07
	v_dual_fmac_f32 v68, v63, v29 :: v_dual_add_nc_u32 v65, 0x6a00, v67// 0000000FC5C4: C8203B3F 444086FF 00006A00
	ds_load_2addr_b32 v[65:66], v65 offset0:68 offset1:197     // 0000000FC5D0: D8DCC544 41000041
	v_fmac_f32_e32 v68, v64, v30                               // 0000000FC5D8: 56883D40
	s_waitcnt lgkmcnt(0)                                       // 0000000FC5DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC5E0: BF870091
	v_fmac_f32_e32 v68, v65, v31                               // 0000000FC5E4: 56883F41
	v_dual_fmac_f32 v68, v66, v32 :: v_dual_add_nc_u32 v61, 0x6e00, v67// 0000000FC5E8: C8204142 443C86FF 00006E00
	ds_load_2addr_b32 v[61:62], v61 offset0:70 offset1:199     // 0000000FC5F4: D8DCC746 3D00003D
	s_waitcnt lgkmcnt(0)                                       // 0000000FC5FC: BF89FC07
	v_dual_fmac_f32 v68, v61, v33 :: v_dual_add_nc_u32 v63, 0x7200, v67// 0000000FC600: C820433D 443E86FF 00007200
	ds_load_2addr_b32 v[63:64], v63 offset0:72 offset1:201     // 0000000FC60C: D8DCC948 3F00003F
	v_dual_fmac_f32 v68, v62, v34 :: v_dual_add_nc_u32 v65, 0x7600, v67// 0000000FC614: C820453E 444086FF 00007600
	ds_load_2addr_b32 v[65:66], v65 offset0:74 offset1:203     // 0000000FC620: D8DCCB4A 41000041
	s_waitcnt lgkmcnt(1)                                       // 0000000FC628: BF89FC17
	v_fmac_f32_e32 v68, v63, v35                               // 0000000FC62C: 5688473F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FC630: BF870001
	v_dual_fmac_f32 v68, v64, v36 :: v_dual_add_nc_u32 v61, 0x7a00, v67// 0000000FC634: C8204940 443C86FF 00007A00
	ds_load_2addr_b32 v[61:62], v61 offset0:76 offset1:205     // 0000000FC640: D8DCCD4C 3D00003D
	s_waitcnt lgkmcnt(1)                                       // 0000000FC648: BF89FC17
	v_dual_fmac_f32 v68, v65, v37 :: v_dual_add_nc_u32 v63, 0x7e00, v67// 0000000FC64C: C8204B41 443E86FF 00007E00
	ds_load_2addr_b32 v[63:64], v63 offset0:78 offset1:207     // 0000000FC658: D8DCCF4E 3F00003F
	v_fmac_f32_e32 v68, v66, v38                               // 0000000FC660: 56884D42
	s_waitcnt lgkmcnt(1)                                       // 0000000FC664: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC668: BF870091
	v_fmac_f32_e32 v68, v61, v39                               // 0000000FC66C: 56884F3D
	v_dual_fmac_f32 v68, v62, v40 :: v_dual_add_nc_u32 v61, 0x80, v3// 0000000FC670: C820513E 443C06FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 0000000FC67C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC680: BF870091
	v_dual_mov_b32 v3, v61 :: v_dual_fmac_f32 v68, v63, v41    // 0000000FC684: CA00013D 0344533F
	v_fmac_f32_e32 v68, v64, v42                               // 0000000FC68C: 56885540
	ds_store_b32 v60, v68                                      // 0000000FC690: D8340000 0000443C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FC698: 917E047E
	s_cbranch_execnz 65456                                     // 0000000FC69C: BFA6FFB0 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2560>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FC6A0: 8C7E047E
	v_dual_mov_b32 v28, v26 :: v_dual_mov_b32 v27, v25         // 0000000FC6A4: CA10011A 1C1A0119
	v_dual_mov_b32 v3, v44 :: v_dual_mov_b32 v30, v43          // 0000000FC6AC: CA10012C 031E012B
	v_mov_b32_e32 v29, 0                                       // 0000000FC6B4: 7E3A0280
	s_mov_b32 s7, 0                                            // 0000000FC6B8: BE870080
	s_waitcnt lgkmcnt(0)                                       // 0000000FC6BC: BF89FC07
	s_barrier                                                  // 0000000FC6C0: BFBD0000
	buffer_gl0_inv                                             // 0000000FC6C4: E0AC0000 00000000
	s_nop 0                                                    // 0000000FC6CC: BF800000
	s_nop 0                                                    // 0000000FC6D0: BF800000
	s_nop 0                                                    // 0000000FC6D4: BF800000
	s_nop 0                                                    // 0000000FC6D8: BF800000
	s_nop 0                                                    // 0000000FC6DC: BF800000
	s_nop 0                                                    // 0000000FC6E0: BF800000
	s_nop 0                                                    // 0000000FC6E4: BF800000
	s_nop 0                                                    // 0000000FC6E8: BF800000
	s_nop 0                                                    // 0000000FC6EC: BF800000
	s_nop 0                                                    // 0000000FC6F0: BF800000
	s_nop 0                                                    // 0000000FC6F4: BF800000
	s_nop 0                                                    // 0000000FC6F8: BF800000
	s_nop 0                                                    // 0000000FC6FC: BF800000
	global_load_b32 v31, v[27:28], off                         // 0000000FC700: DC520000 1F7C001B
	ds_load_b32 v32, v29 offset:33792                          // 0000000FC708: D8D88400 2000001D
	v_add_nc_u32_e32 v30, 0x80, v30                            // 0000000FC710: 4A3C3CFF 00000080
	.long 0xd700011b                                           // 0000000FC718: D700011B
	v_cndmask_b32_e32 v1, 0x6000, v27, vcc_lo                  // 0000000FC71C: 020236FF 00006000
	v_add_nc_u32_e32 v29, 4, v29                               // 0000000FC724: 4A3A3A84
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000FC728: D5207C1C 00063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000FC730: BF890007
	v_mul_f32_e32 v31, v31, v32                                // 0000000FC734: 103E411F
	.long 0xd4490004                                           // 0000000FC738: D4490004
	v_cndmask_b32_e32 v1, 0x77f, v30, vcc_lo                   // 0000000FC73C: 02023CFF 0000077F
	ds_store_b32 v3, v31 offset:25344                          // 0000000FC744: D8346300 00001F03
	v_add_nc_u32_e32 v3, 0x204, v3                             // 0000000FC74C: 4A0606FF 00000204
	s_or_b32 s7, s4, s7                                        // 0000000FC754: 8C070704
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000FC758: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000000FC75C: 917E077E
	s_cbranch_execnz 65511                                     // 0000000FC760: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2700>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000FC764: 8C7E077E
	v_add_nc_u32_e32 v3, 0x1800, v8                            // 0000000FC768: 4A0610FF 00001800
	v_add_nc_u32_e32 v33, 0x1a00, v8                           // 0000000FC770: 4A4210FF 00001A00
	v_add_nc_u32_e32 v39, 0x1c00, v8                           // 0000000FC778: 4A4E10FF 00001C00
	s_waitcnt lgkmcnt(0)                                       // 0000000FC780: BF89FC07
	s_barrier                                                  // 0000000FC784: BFBD0000
	buffer_gl0_inv                                             // 0000000FC788: E0AC0000 00000000
	ds_load_2addr_b32 v[27:28], v3 offset0:48 offset1:81       // 0000000FC790: D8DC5130 1B000003
	ds_load_2addr_b32 v[29:30], v3 offset0:114 offset1:147     // 0000000FC798: D8DC9372 1D000003
	ds_load_2addr_b32 v[31:32], v3 offset0:180 offset1:213     // 0000000FC7A0: D8DCD5B4 1F000003
	v_add_nc_u32_e32 v3, 0x1e00, v8                            // 0000000FC7A8: 4A0610FF 00001E00
	ds_load_2addr_b32 v[33:34], v33 offset0:118 offset1:151    // 0000000FC7B0: D8DC9776 21000021
	ds_load_2addr_b32 v[35:36], v39 offset0:56 offset1:89      // 0000000FC7B8: D8DC5938 23000027
	ds_load_2addr_b32 v[37:38], v39 offset0:122 offset1:155    // 0000000FC7C0: D8DC9B7A 25000027
	ds_load_2addr_b32 v[39:40], v39 offset0:188 offset1:221    // 0000000FC7C8: D8DCDDBC 27000027
	ds_load_2addr_b32 v[41:42], v3 offset0:126 offset1:159     // 0000000FC7D0: D8DC9F7E 29000003
	v_mov_b32_e32 v3, v0                                       // 0000000FC7D8: 7E060300
	s_mov_b32 s4, 0                                            // 0000000FC7DC: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000FC7E0: BF870121
	v_lshrrev_b32_e32 v60, 5, v3                               // 0000000FC7E4: 32780685
	.long 0xd4490001                                           // 0000000FC7E8: D4490001
	v_cndmask_b32_e32 v1, 0xf7f, v3, vcc_lo                    // 0000000FC7EC: 020206FF 00000F7F
	v_lshlrev_b32_e32 v67, 2, v60                              // 0000000FC7F4: 30867882
	v_mad_u64_u32 v[60:61], null, 0x84, v60, v[1:2]            // 0000000FC7F8: D6FE7C3C 040678FF 00000084
	s_or_b32 s4, s1, s4                                        // 0000000FC804: 8C040401
	v_add_nc_u32_e32 v61, 0x6200, v67                          // 0000000FC808: 4A7A86FF 00006200
	ds_load_b32 v68, v60                                       // 0000000FC810: D8D80000 4400003C
	ds_load_2addr_b32 v[61:62], v61 offset0:64 offset1:193     // 0000000FC818: D8DCC140 3D00003D
	s_waitcnt lgkmcnt(0)                                       // 0000000FC820: BF89FC07
	v_fmac_f32_e32 v68, v61, v27                               // 0000000FC824: 5688373D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FC828: BF870001
	v_dual_fmac_f32 v68, v62, v28 :: v_dual_add_nc_u32 v63, 0x6600, v67// 0000000FC82C: C820393E 443E86FF 00006600
	ds_load_2addr_b32 v[63:64], v63 offset0:66 offset1:195     // 0000000FC838: D8DCC342 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000000FC840: BF89FC07
	v_dual_fmac_f32 v68, v63, v29 :: v_dual_add_nc_u32 v65, 0x6a00, v67// 0000000FC844: C8203B3F 444086FF 00006A00
	ds_load_2addr_b32 v[65:66], v65 offset0:68 offset1:197     // 0000000FC850: D8DCC544 41000041
	v_fmac_f32_e32 v68, v64, v30                               // 0000000FC858: 56883D40
	s_waitcnt lgkmcnt(0)                                       // 0000000FC85C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC860: BF870091
	v_fmac_f32_e32 v68, v65, v31                               // 0000000FC864: 56883F41
	v_dual_fmac_f32 v68, v66, v32 :: v_dual_add_nc_u32 v61, 0x6e00, v67// 0000000FC868: C8204142 443C86FF 00006E00
	ds_load_2addr_b32 v[61:62], v61 offset0:70 offset1:199     // 0000000FC874: D8DCC746 3D00003D
	s_waitcnt lgkmcnt(0)                                       // 0000000FC87C: BF89FC07
	v_dual_fmac_f32 v68, v61, v33 :: v_dual_add_nc_u32 v63, 0x7200, v67// 0000000FC880: C820433D 443E86FF 00007200
	ds_load_2addr_b32 v[63:64], v63 offset0:72 offset1:201     // 0000000FC88C: D8DCC948 3F00003F
	v_dual_fmac_f32 v68, v62, v34 :: v_dual_add_nc_u32 v65, 0x7600, v67// 0000000FC894: C820453E 444086FF 00007600
	ds_load_2addr_b32 v[65:66], v65 offset0:74 offset1:203     // 0000000FC8A0: D8DCCB4A 41000041
	s_waitcnt lgkmcnt(1)                                       // 0000000FC8A8: BF89FC17
	v_fmac_f32_e32 v68, v63, v35                               // 0000000FC8AC: 5688473F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FC8B0: BF870001
	v_dual_fmac_f32 v68, v64, v36 :: v_dual_add_nc_u32 v61, 0x7a00, v67// 0000000FC8B4: C8204940 443C86FF 00007A00
	ds_load_2addr_b32 v[61:62], v61 offset0:76 offset1:205     // 0000000FC8C0: D8DCCD4C 3D00003D
	s_waitcnt lgkmcnt(1)                                       // 0000000FC8C8: BF89FC17
	v_dual_fmac_f32 v68, v65, v37 :: v_dual_add_nc_u32 v63, 0x7e00, v67// 0000000FC8CC: C8204B41 443E86FF 00007E00
	ds_load_2addr_b32 v[63:64], v63 offset0:78 offset1:207     // 0000000FC8D8: D8DCCF4E 3F00003F
	v_fmac_f32_e32 v68, v66, v38                               // 0000000FC8E0: 56884D42
	s_waitcnt lgkmcnt(1)                                       // 0000000FC8E4: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC8E8: BF870091
	v_fmac_f32_e32 v68, v61, v39                               // 0000000FC8EC: 56884F3D
	v_dual_fmac_f32 v68, v62, v40 :: v_dual_add_nc_u32 v61, 0x80, v3// 0000000FC8F0: C820513E 443C06FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 0000000FC8FC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000FC900: BF870091
	v_dual_mov_b32 v3, v61 :: v_dual_fmac_f32 v68, v63, v41    // 0000000FC904: CA00013D 0344533F
	v_fmac_f32_e32 v68, v64, v42                               // 0000000FC90C: 56885540
	ds_store_b32 v60, v68                                      // 0000000FC910: D8340000 0000443C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000FC918: 917E047E
	s_cbranch_execnz 65456                                     // 0000000FC91C: BFA6FFB0 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27e0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000FC920: 8C7E047E
	.long 0xd700010b                                           // 0000000FC924: D700010B
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000FC928: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FC930: BF8700A1
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000FC934: D5207C0C 00061880
	.long 0xd700010d                                           // 0000000FC93C: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000FC940: 02021AFF 000C0000
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000FC948: D5207C0E 00061C80
	.long 0xd700010f                                           // 0000000FC950: D700010F
	v_cndmask_b32_e32 v1, 0xc0000, v15, vcc_lo                 // 0000000FC954: 02021EFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FC95C: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000FC960: D5207C10 00062080
	.long 0xd7000113                                           // 0000000FC968: D7000113
	v_cndmask_b32_e32 v1, 0xc0000, v19, vcc_lo                 // 0000000FC96C: 020226FF 000C0000
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000FC974: D5207C14 00062880
	.long 0xd7000111                                           // 0000000FC97C: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000FC980: 020222FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FC988: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000FC98C: D5207C12 00062480
	.long 0xd7000115                                           // 0000000FC994: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000FC998: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000FC9A0: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000FC9A8: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000FC9AC: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000FC9B4: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000FC9B8: D5207C18 00063080
	.long 0xd7000119                                           // 0000000FC9C0: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000FC9C4: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000FC9CC: D5207C1A 00063480
	s_add_i32 s6, s6, 1                                        // 0000000FC9D4: 81068106
	s_waitcnt lgkmcnt(0)                                       // 0000000FC9D8: BF89FC07
	s_cmp_eq_u32 s6, s33                                       // 0000000FC9DC: BF062106
	s_barrier                                                  // 0000000FC9E0: BFBD0000
	buffer_gl0_inv                                             // 0000000FC9E4: E0AC0000 00000000
	s_cbranch_scc0 63059                                       // 0000000FC9EC: BFA1F653 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33c>
	v_mov_b32_e32 v7, v43                                      // 0000000FC9F0: 7E0E032B
	v_mov_b32_e32 v3, v2                                       // 0000000FC9F4: 7E060302
	s_add_u32 s0, s28, s20                                     // 0000000FC9F8: 8000141C
	.long 0xd73c0000                                           // 0000000FC9FC: D73C0000
	v_cndmask_b32_e32 v1, 9, v5, vcc_lo                        // 0000000FCA00: 02020A89
	s_addc_u32 s1, s29, s21                                    // 0000000FCA04: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000FCA08: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000FCA0C: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000FCA10: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000FCA14: 82010103
	.long 0xd7006a00                                           // 0000000FCA18: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000FCA1C: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000FCA20: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000FCA24: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000FCA2C: BE810080
	.long 0xd7006a02                                           // 0000000FCA30: D7006A02
	v_cndmask_b32_e32 v1, v0, v4, vcc_lo                       // 0000000FCA34: 02020900
	v_add_co_ci_u32_e64 v5, null, 0, v1, vcc_lo                // 0000000FCA38: D5207C05 01AA0280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000FCA40: BF870191
	v_mad_u64_u32 v[0:1], null, 0x84, v3, v[4:5]               // 0000000FCA44: D6FE7C00 041206FF 00000084
	.long 0xd7006a01                                           // 0000000FCA50: D7006A01
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 0000000FCA54: 02020410
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000FCA58: BF870001
	v_add_co_ci_u32_e64 v2, null, s17, v5, vcc_lo              // 0000000FCA5C: D5207C02 01AA0A11
	s_nop 0                                                    // 0000000FCA64: BF800000
	s_nop 0                                                    // 0000000FCA68: BF800000
	s_nop 0                                                    // 0000000FCA6C: BF800000
	s_nop 0                                                    // 0000000FCA70: BF800000
	s_nop 0                                                    // 0000000FCA74: BF800000
	s_nop 0                                                    // 0000000FCA78: BF800000
	s_nop 0                                                    // 0000000FCA7C: BF800000
	ds_load_b32 v3, v0                                         // 0000000FCA80: D8D80000 03000000
	v_add_nc_u32_e32 v7, 0x80, v7                              // 0000000FCA88: 4A0E0EFF 00000080
	v_add_nc_u32_e32 v0, 0x210, v0                             // 0000000FCA90: 4A0000FF 00000210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000FCA98: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0xf7f, v7                         // 0000000FCA9C: 7C920EFF 00000F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000FCAA4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000FCAA8: BF89FC07
	global_store_b32 v[1:2], v3, off                           // 0000000FCAAC: DC6A0000 007C0301
	.long 0xd7000001                                           // 0000000FCAB4: D7000001
	v_cndmask_b32_e32 v1, 0x800, v1, vcc_lo                    // 0000000FCAB8: 020202FF 00000800
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000000FCAC0: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000FCAC8: 917E017E
	s_cbranch_execnz 65516                                     // 0000000FCACC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi4ELi16ELi0ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a80>
	s_endpgm                                                   // 0000000FCAD0: BFB00000
		...

