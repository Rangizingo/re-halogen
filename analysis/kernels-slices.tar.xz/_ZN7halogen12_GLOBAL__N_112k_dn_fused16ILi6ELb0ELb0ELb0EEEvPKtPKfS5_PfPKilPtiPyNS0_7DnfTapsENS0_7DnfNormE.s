0000000000040c00 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE>:
; _ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE():
	s_clause 0x1                                               // 000000040C00: BF850001
	s_load_b256 s[20:27], s[0:1], 0x20                         // 000000040C04: F40C0500 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 000000040C0C: F40C0200 F8000000
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 5, v0       // 000000040C14: CA220080 02020085
	s_ashr_i32 s3, s2, 31                                      // 000000040C1C: 86039F02
	s_mov_b32 s28, 0                                           // 000000040C20: BE9C0080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000040C24: BF870001
	v_and_b32_e32 v3, 0x200, v3                                // 000000040C28: 360606FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 000000040C30: BF89FC07
	s_load_b32 s16, s[20:21], null                             // 000000040C34: F400040A F8000000
	v_readfirstlane_b32 s20, v0                                // 000000040C3C: 7E280500
	s_lshl_b64 s[4:5], s[22:23], 2                             // 000000040C40: 84848216
	s_lshr_b32 s21, s20, 5                                     // 000000040C44: 85158514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000040C48: BF8704D9
	s_lshl_b32 s33, s21, 4                                     // 000000040C4C: 84218415
	s_add_u32 s4, s14, s4                                      // 000000040C50: 8004040E
	v_and_or_b32 v1, v0, 15, s33                               // 000000040C54: D6570001 00851F00
	s_addc_u32 s5, s15, s5                                     // 000000040C5C: 8205050F
	s_lshl_b64 s[6:7], s[2:3], 16                              // 000000040C60: 84869002
	s_add_u32 s4, s4, s6                                       // 000000040C64: 80040604
	s_delay_alu instid0(VALU_DEP_1)                            // 000000040C68: BF870001
	.long 0xd73c0001                                           // 000000040C6C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000040C70: 02020282
	s_addc_u32 s5, s5, s7                                      // 000000040C74: 82050705
	s_waitcnt lgkmcnt(0)                                       // 000000040C78: BF89FC07
	s_mul_i32 s14, s16, 0x9000000                              // 000000040C7C: 960EFF10 09000000
	s_mul_hi_i32 s15, s16, 0x9000000                           // 000000040C84: 970FFF10 09000000
	s_add_u32 s4, s4, s14                                      // 000000040C8C: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000040C90: 82050F05
	.long 0xd7006a01                                           // 000000040C94: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000040C98: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000040C9C: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000040CA0: D5207C02 01AA0405
	s_or_b32 s5, s21, s2                                       // 000000040CA8: 8C050215
	.long 0xd7006abb                                           // 000000040CAC: D7006ABB
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000040CB0: 02020701
	v_add_co_ci_u32_e64 v188, null, 0, v2, vcc_lo              // 000000040CB4: D5207CBC 01AA0480
	s_cselect_b32 s38, 0, -1                                   // 000000040CBC: 9826C180
	.long 0xd7006a09                                           // 000000040CC0: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v187, vcc_lo                 // 000000040CC4: 020376FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000040CCC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v188, vcc_lo             // 000000040CD0: D5207C0A 01AB7880
	.long 0xd7006a34                                           // 000000040CD8: D7006A34
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000040CDC: 0201FFBB
	.long 0x00002000                                           // 000000040CE0: 00002000
	v_add_co_ci_u32_e64 v53, null, 0, v188, vcc_lo             // 000000040CE4: D5207C35 01AB7880
	.long 0xd7006a0d                                           // 000000040CEC: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v187, vcc_lo                 // 000000040CF0: 020376FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000040CF8: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v188, vcc_lo             // 000000040CFC: D5207C0E 01AB7880
	.long 0xd7006a0f                                           // 000000040D04: D7006A0F
	v_cndmask_b32_e32 v1, 0x3000, v187, vcc_lo                 // 000000040D08: 020376FF 00003000
	v_add_co_ci_u32_e64 v16, null, 0, v188, vcc_lo             // 000000040D10: D5207C10 01AB7880
	.long 0xd7006a3c                                           // 000000040D18: D7006A3C
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000040D1C: 0201FFBB
	.long 0x00004000                                           // 000000040D20: 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000040D24: BF870001
	v_add_co_ci_u32_e64 v61, null, 0, v188, vcc_lo             // 000000040D28: D5207C3D 01AB7880
	.long 0xd7006a11                                           // 000000040D30: D7006A11
	v_cndmask_b32_e32 v1, 0x4000, v187, vcc_lo                 // 000000040D34: 020376FF 00004000
	s_clause 0x7                                               // 000000040D3C: BF850007
	global_load_b32 v5, v[187:188], off                        // 000000040D40: DC520000 057C00BB
	global_load_b32 v6, v[187:188], off offset:1024            // 000000040D48: DC520400 067C00BB
	global_load_b32 v7, v[187:188], off offset:2048            // 000000040D50: DC520800 077C00BB
	global_load_b32 v8, v[187:188], off offset:3072            // 000000040D58: DC520C00 087C00BB
	global_load_b32 v2, v[9:10], off offset:1024               // 000000040D60: DC520400 027C0009
	global_load_b32 v3, v[9:10], off offset:2048               // 000000040D68: DC520800 037C0009
	global_load_b32 v4, v[9:10], off offset:3072               // 000000040D70: DC520C00 047C0009
	global_load_b32 v1, v[13:14], off offset:1024              // 000000040D78: DC520400 017C000D
	v_add_co_ci_u32_e64 v18, null, 0, v188, vcc_lo             // 000000040D80: D5207C12 01AB7880
	s_clause 0x7                                               // 000000040D88: BF850007
	global_load_b32 v12, v[13:14], off offset:2048             // 000000040D8C: DC520800 0C7C000D
	global_load_b32 v13, v[13:14], off offset:3072             // 000000040D94: DC520C00 0D7C000D
	global_load_b32 v9, v[15:16], off offset:1024              // 000000040D9C: DC520400 097C000F
	global_load_b32 v10, v[15:16], off offset:2048             // 000000040DA4: DC520800 0A7C000F
	global_load_b32 v11, v[15:16], off offset:3072             // 000000040DAC: DC520C00 0B7C000F
	global_load_b32 v14, v[17:18], off offset:1024             // 000000040DB4: DC520400 0E7C0011
	global_load_b32 v15, v[17:18], off offset:2048             // 000000040DBC: DC520800 0F7C0011
	global_load_b32 v16, v[17:18], off offset:3072             // 000000040DC4: DC520C00 107C0011
	.long 0xd7006a11                                           // 000000040DCC: D7006A11
	v_cndmask_b32_e32 v1, 0x5000, v187, vcc_lo                 // 000000040DD0: 020376FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000040DD8: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v188, vcc_lo             // 000000040DDC: D5207C12 01AB7880
	.long 0xd7006a41                                           // 000000040DE4: D7006A41
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000040DE8: 0201FFBB
	.long 0x00006000                                           // 000000040DEC: 00006000
	v_add_co_ci_u32_e64 v66, null, 0, v188, vcc_lo             // 000000040DF0: D5207C42 01AB7880
	.long 0xd7006a17                                           // 000000040DF8: D7006A17
	v_cndmask_b32_e32 v1, 0x6000, v187, vcc_lo                 // 000000040DFC: 020376FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000040E04: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v188, vcc_lo             // 000000040E08: D5207C18 01AB7880
	.long 0xd7006a19                                           // 000000040E10: D7006A19
	v_cndmask_b32_e32 v1, 0x7000, v187, vcc_lo                 // 000000040E14: 020376FF 00007000
	v_add_co_ci_u32_e64 v26, null, 0, v188, vcc_lo             // 000000040E1C: D5207C1A 01AB7880
	.long 0xd7006a29                                           // 000000040E24: D7006A29
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000040E28: 0201FFBB
	.long 0x00008000                                           // 000000040E2C: 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000040E30: BF8700A1
	v_add_co_ci_u32_e64 v42, null, 0, v188, vcc_lo             // 000000040E34: D5207C2A 01AB7880
	.long 0xd7006a20                                           // 000000040E3C: D7006A20
	v_cndmask_b32_e32 v1, 0x8000, v187, vcc_lo                 // 000000040E40: 020376FF 00008000
	v_add_co_ci_u32_e64 v33, null, 0, v188, vcc_lo             // 000000040E48: D5207C21 01AB7880
	.long 0xd7006a22                                           // 000000040E50: D7006A22
	v_cndmask_b32_e32 v1, 0x9000, v187, vcc_lo                 // 000000040E54: 020376FF 00009000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000040E5C: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v188, vcc_lo             // 000000040E60: D5207C23 01AB7880
	.long 0xd7006a2b                                           // 000000040E68: D7006A2B
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000040E6C: 0201FFBB
	.long 0x0000a000                                           // 000000040E70: 0000A000
	v_add_co_ci_u32_e64 v44, null, 0, v188, vcc_lo             // 000000040E74: D5207C2C 01AB7880
	.long 0xd7006a25                                           // 000000040E7C: D7006A25
	v_cndmask_b32_e32 v1, 0xa000, v187, vcc_lo                 // 000000040E80: 020376FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000040E88: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v188, vcc_lo             // 000000040E8C: D5207C26 01AB7880
	.long 0xd7006a27                                           // 000000040E94: D7006A27
	v_cndmask_b32_e32 v1, 0xb000, v187, vcc_lo                 // 000000040E98: 020376FF 0000B000
	v_add_co_ci_u32_e64 v40, null, 0, v188, vcc_lo             // 000000040EA0: D5207C28 01AB7880
	.long 0xd7006a2d                                           // 000000040EA8: D7006A2D
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000040EAC: 0201FFBB
	.long 0x0000c000                                           // 000000040EB0: 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000040EB4: BF8700A1
	v_add_co_ci_u32_e64 v46, null, 0, v188, vcc_lo             // 000000040EB8: D5207C2E 01AB7880
	.long 0xd7006a2f                                           // 000000040EC0: D7006A2F
	v_cndmask_b32_e32 v1, 0xc000, v187, vcc_lo                 // 000000040EC4: 020376FF 0000C000
	v_add_co_ci_u32_e64 v48, null, 0, v188, vcc_lo             // 000000040ECC: D5207C30 01AB7880
	.long 0xd7006a36                                           // 000000040ED4: D7006A36
	v_cndmask_b32_e32 v1, 0xd000, v187, vcc_lo                 // 000000040ED8: 020376FF 0000D000
	s_clause 0x17                                              // 000000040EE0: BF850017
	global_load_b32 v20, v[17:18], off offset:1024             // 000000040EE4: DC520400 147C0011
	global_load_b32 v21, v[17:18], off offset:2048             // 000000040EEC: DC520800 157C0011
	global_load_b32 v22, v[17:18], off offset:3072             // 000000040EF4: DC520C00 167C0011
	global_load_b32 v17, v[23:24], off offset:1024             // 000000040EFC: DC520400 117C0017
	global_load_b32 v18, v[23:24], off offset:2048             // 000000040F04: DC520800 127C0017
	global_load_b32 v19, v[23:24], off offset:3072             // 000000040F0C: DC520C00 137C0017
	global_load_b32 v23, v[25:26], off offset:1024             // 000000040F14: DC520400 177C0019
	global_load_b32 v24, v[25:26], off offset:2048             // 000000040F1C: DC520800 187C0019
	global_load_b32 v31, v[25:26], off offset:3072             // 000000040F24: DC520C00 1F7C0019
	global_load_b32 v28, v[32:33], off offset:1024             // 000000040F2C: DC520400 1C7C0020
	global_load_b32 v29, v[32:33], off offset:2048             // 000000040F34: DC520800 1D7C0020
	global_load_b32 v30, v[32:33], off offset:3072             // 000000040F3C: DC520C00 1E7C0020
	global_load_b32 v25, v[34:35], off offset:1024             // 000000040F44: DC520400 197C0022
	global_load_b32 v26, v[34:35], off offset:2048             // 000000040F4C: DC520800 1A7C0022
	global_load_b32 v27, v[34:35], off offset:3072             // 000000040F54: DC520C00 1B7C0022
	global_load_b32 v32, v[37:38], off offset:1024             // 000000040F5C: DC520400 207C0025
	global_load_b32 v36, v[37:38], off offset:2048             // 000000040F64: DC520800 247C0025
	global_load_b32 v37, v[37:38], off offset:3072             // 000000040F6C: DC520C00 257C0025
	global_load_b32 v33, v[39:40], off offset:1024             // 000000040F74: DC520400 217C0027
	global_load_b32 v34, v[39:40], off offset:2048             // 000000040F7C: DC520800 227C0027
	global_load_b32 v35, v[39:40], off offset:3072             // 000000040F84: DC520C00 237C0027
	global_load_b32 v38, v[47:48], off offset:1024             // 000000040F8C: DC520400 267C002F
	global_load_b32 v39, v[47:48], off offset:2048             // 000000040F94: DC520800 277C002F
	global_load_b32 v40, v[47:48], off offset:3072             // 000000040F9C: DC520C00 287C002F
	v_add_co_ci_u32_e64 v55, null, 0, v188, vcc_lo             // 000000040FA4: D5207C37 01AB7880
	.long 0xd7006a2f                                           // 000000040FAC: D7006A2F
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000040FB0: 0201FFBB
	.long 0x0000e000                                           // 000000040FB4: 0000E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000040FB8: BF8700A1
	v_add_co_ci_u32_e64 v48, null, 0, v188, vcc_lo             // 000000040FBC: D5207C30 01AB7880
	.long 0xd7006a3e                                           // 000000040FC4: D7006A3E
	v_cndmask_b32_e32 v1, 0xe000, v187, vcc_lo                 // 000000040FC8: 020376FF 0000E000
	v_add_co_ci_u32_e64 v63, null, 0, v188, vcc_lo             // 000000040FD0: D5207C3F 01AB7880
	.long 0xd7006a43                                           // 000000040FD8: D7006A43
	v_cndmask_b32_e32 v1, 0xf000, v187, vcc_lo                 // 000000040FDC: 020376FF 0000F000
	s_clause 0x7                                               // 000000040FE4: BF850007
	global_load_b32 v51, v[41:42], off offset:-4096            // 000000040FE8: DC521000 337C0029
	global_load_b32 v58, v[41:42], off                         // 000000040FF0: DC520000 3A7C0029
	global_load_b32 v50, v[43:44], off offset:-4096            // 000000040FF8: DC521000 327C002B
	global_load_b32 v56, v[43:44], off                         // 000000041000: DC520000 387C002B
	global_load_b32 v44, v[45:46], off offset:-4096            // 000000041008: DC521000 2C7C002D
	global_load_b32 v43, v[45:46], off                         // 000000041010: DC520000 2B7C002D
	global_load_b32 v42, v[47:48], off offset:-4096            // 000000041018: DC521000 2A7C002F
	global_load_b32 v41, v[47:48], off                         // 000000041020: DC520000 297C002F
	v_add_co_ci_u32_e64 v68, null, 0, v188, vcc_lo             // 000000041028: D5207C44 01AB7880
	s_clause 0xf                                               // 000000041030: BF85000F
	global_load_b32 v48, v[54:55], off offset:1024             // 000000041034: DC520400 307C0036
	global_load_b32 v49, v[54:55], off offset:2048             // 00000004103C: DC520800 317C0036
	global_load_b32 v55, v[54:55], off offset:3072             // 000000041044: DC520C00 377C0036
	global_load_b32 v45, v[62:63], off offset:1024             // 00000004104C: DC520400 2D7C003E
	global_load_b32 v46, v[62:63], off offset:2048             // 000000041054: DC520800 2E7C003E
	global_load_b32 v47, v[62:63], off offset:3072             // 00000004105C: DC520C00 2F7C003E
	global_load_b32 v57, v[67:68], off                         // 000000041064: DC520000 397C0043
	global_load_b32 v59, v[67:68], off offset:1024             // 00000004106C: DC520400 3B7C0043
	global_load_b32 v54, v[52:53], off offset:-4096            // 000000041074: DC521000 367C0034
	global_load_b32 v64, v[52:53], off                         // 00000004107C: DC520000 407C0034
	global_load_b32 v53, v[60:61], off offset:-4096            // 000000041084: DC521000 357C003C
	global_load_b32 v63, v[60:61], off                         // 00000004108C: DC520000 3F7C003C
	global_load_b32 v52, v[65:66], off offset:-4096            // 000000041094: DC521000 347C0041
	global_load_b32 v62, v[65:66], off                         // 00000004109C: DC520000 3E7C0041
	global_load_b32 v60, v[67:68], off offset:2048             // 0000000410A4: DC520800 3C7C0043
	global_load_b32 v61, v[67:68], off offset:3072             // 0000000410AC: DC520C00 3D7C0043
	v_lshlrev_b32_e32 v65, 3, v0                               // 0000000410B4: 30820083
	s_cbranch_scc1 1                                           // 0000000410B8: BFA20001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4c0>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 0000000410BC: BE9C4D83
	s_load_b32 s39, s[0:1], 0x38                               // 0000000410C0: F40009C0 F8000038
	v_lshrrev_b32_e32 v69, 4, v0                               // 0000000410C8: 328A0084
	s_mul_hi_i32 s4, s2, 0x55555556                            // 0000000410CC: 9704FF02 55555556
	v_and_b32_e32 v67, 0x78, v65                               // 0000000410D4: 368682FF 00000078
	s_lshr_b32 s14, s4, 31                                     // 0000000410DC: 850E9F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000410E0: BF870499
	s_add_i32 s4, s4, s14                                      // 0000000410E4: 81040E04
	s_lshl_b32 s14, s4, 7                                      // 0000000410E8: 840E8704
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000410EC: BF870001
	v_lshlrev_b32_e32 v67, 1, v67                              // 0000000410F0: 30868681
	s_ashr_i32 s15, s14, 31                                    // 0000000410F4: 860F9F0E
	s_mov_b32 s4, exec_lo                                      // 0000000410F8: BE84007E
	s_lshl_b64 s[14:15], s[14:15], 1                           // 0000000410FC: 848E810E
	s_waitcnt lgkmcnt(0)                                       // 000000041100: BF89FC07
	s_add_i32 s40, s39, -1                                     // 000000041104: 8128C127
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041108: BF870099
	v_min_i32_e32 v66, s40, v69                                // 00000004110C: 22848A28
	v_mad_i64_i32 v[65:66], null, 0x5000, v66, s[8:9]          // 000000041110: D6FF7C41 002284FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004111C: BF870091
	.long 0xd7006a41                                           // 000000041120: D7006A41
	v_cndmask_b32_e32 v0, v65, v14, vcc_lo                     // 000000041124: 02001D41
	v_add_co_ci_u32_e64 v66, null, s15, v66, vcc_lo            // 000000041128: D5207C42 01AA840F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041130: BF870092
	.long 0xd7006a41                                           // 000000041134: D7006A41
	v_cndmask_b32_e32 v1, v65, v67, vcc_lo                     // 000000041138: 02028741
	v_add_co_ci_u32_e64 v66, null, 0, v66, vcc_lo              // 00000004113C: D5207C42 01AA8480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041144: BF870092
	.long 0xd7006a43                                           // 000000041148: D7006A43
	v_cndmask_b32_e32 v1, 0x1000, v65, vcc_lo                  // 00000004114C: 020282FF 00001000
	v_add_co_ci_u32_e64 v68, null, 0, v66, vcc_lo              // 000000041154: D5207C44 01AA8480
	s_clause 0x1                                               // 00000004115C: BF850001
	global_load_b128 v[74:77], v[65:66], off                   // 000000041160: DC5E0000 4A7C0041
	global_load_b128 v[78:81], v[67:68], off                   // 000000041168: DC5E0000 4E7C0043
	.long 0xd4c3007e                                           // 000000041170: D4C3007E
	v_cndmask_b32_e32 v1, s39, v69, vcc_lo                     // 000000041174: 02028A27
	s_cbranch_execz 11                                         // 000000041178: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5a8>
	s_waitcnt vmcnt(1)                                         // 00000004117C: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 000000041180: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000041184: BF870001
	v_mov_b32_e32 v75, v76                                     // 000000041188: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 00000004118C: 7E94034C
	s_waitcnt vmcnt(0)                                         // 000000041190: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 000000041194: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 000000041198: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 00000004119C: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 0000000411A0: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 0000000411A4: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000411A8: 8C7E047E
	v_cmp_gt_u32_e32 vcc_lo, 16, v0                            // 0000000411AC: 7C980090
	.long 0xd4440004                                           // 0000000411B0: D4440004
	v_cndmask_b32_e32 v1, s39, v0, vcc_lo                      // 0000000411B4: 02020027
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v140, 0            // 0000000411B8: CA100080 418C0080
	s_and_b32 s16, vcc_lo, s4                                  // 0000000411C0: 8B10046A
	scratch_store_b32 off, v65, off                            // 0000000411C4: DC690000 007C4100
	s_and_saveexec_b32 s4, s16                                 // 0000000411CC: BE842010
	s_cbranch_execz 30                                         // 0000000411D0: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x64c>
	v_mul_u32_u24_e32 v65, 0xc0, v0                            // 0000000411D4: 168200FF 000000C0
	s_lshl_b64 s[16:17], s[2:3], 2                             // 0000000411DC: 84908202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000411E0: BF870091
	.long 0xd7001242                                           // 0000000411E4: D7001242
	v_cndmask_b32_e32 v1, s10, v65, vcc_lo                     // 0000000411E8: 0202820A
	v_add_co_ci_u32_e64 v67, null, s11, 0, s18                 // 0000000411EC: D5207C43 0049000B
	.long 0xd7001244                                           // 0000000411F4: D7001244
	v_cndmask_b32_e32 v1, s12, v65, vcc_lo                     // 0000000411F8: 0202820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000411FC: BF870211
	v_add_co_ci_u32_e64 v69, null, s13, 0, s18                 // 000000041200: D5207C45 0049000D
	.long 0xd7006a41                                           // 000000041208: D7006A41
	v_cndmask_b32_e32 v0, v66, v16, vcc_lo                     // 00000004120C: 02002142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000041210: BF870211
	v_add_co_ci_u32_e64 v66, null, s17, v67, vcc_lo            // 000000041214: D5207C42 01AA8611
	.long 0xd7006a43                                           // 00000004121C: D7006A43
	v_cndmask_b32_e32 v0, v68, v16, vcc_lo                     // 000000041220: 02002144
	s_delay_alu instid0(VALU_DEP_1)                            // 000000041224: BF870001
	v_add_co_ci_u32_e64 v68, null, s17, v69, vcc_lo            // 000000041228: D5207C44 01AA8A11
	global_load_b32 v140, v[65:66], off                        // 000000041230: DC520000 8C7C0041
	global_load_b32 v65, v[67:68], off                         // 000000041238: DC520000 417C0043
	s_waitcnt vmcnt(0)                                         // 000000041240: BF8903F7
	scratch_store_b32 off, v65, off                            // 000000041244: DC690000 007C4100
	s_or_b32 exec_lo, exec_lo, s4                              // 00000004124C: 8C7E047E
	s_waitcnt vmcnt(62)                                        // 000000041250: BF89FBF7
	v_dual_mul_f32 v139, 0x43800000, v5 :: v_dual_mul_f32 v138, 0x43800000, v6// 000000041254: C8C60AFF 8B8A0CFF 43800000
	v_dual_mul_f32 v137, 0x43800000, v7 :: v_dual_mul_f32 v136, 0x43800000, v8// 000000041260: C8C60EFF 898810FF 43800000
	s_waitcnt vmcnt(9)                                         // 00000004126C: BF8927F7
	v_dual_mul_f32 v135, 0x43800000, v54 :: v_dual_mul_f32 v54, 0x43800000, v4// 000000041270: C8C66CFF 873608FF 43800000
	v_dual_mul_f32 v134, 0x43800000, v2 :: v_dual_mul_f32 v133, 0x43800000, v3// 00000004127C: C8C604FF 868406FF 43800000
	s_waitcnt vmcnt(8)                                         // 000000041288: BF8923F7
	v_dual_mul_f32 v132, 0x43800000, v64 :: v_dual_mul_f32 v131, 0x43800000, v1// 00000004128C: C8C680FF 848202FF 43800000
	v_dual_mul_f32 v130, 0x43800000, v12 :: v_dual_mul_f32 v129, 0x43800000, v13// 000000041298: C8C618FF 82801AFF 43800000
	s_waitcnt vmcnt(7)                                         // 0000000412A4: BF891FF7
	v_dual_mul_f32 v128, 0x43800000, v53 :: v_dual_mul_f32 v53, 0x43800000, v11// 0000000412A8: C8C66AFF 803416FF 43800000
	v_dual_mul_f32 v127, 0x43800000, v9 :: v_dual_mul_f32 v126, 0x43800000, v10// 0000000412B4: C8C612FF 7F7E14FF 43800000
	s_waitcnt vmcnt(6)                                         // 0000000412C0: BF891BF7
	v_dual_mul_f32 v125, 0x43800000, v63 :: v_dual_mul_f32 v124, 0x43800000, v14// 0000000412C4: C8C67EFF 7D7C1CFF 43800000
	v_dual_mul_f32 v123, 0x43800000, v15 :: v_dual_mul_f32 v122, 0x43800000, v16// 0000000412D0: C8C61EFF 7B7A20FF 43800000
	s_waitcnt vmcnt(5)                                         // 0000000412DC: BF8917F7
	v_dual_mul_f32 v121, 0x43800000, v52 :: v_dual_mul_f32 v52, 0x43800000, v22// 0000000412E0: C8C668FF 79342CFF 43800000
	v_dual_mul_f32 v120, 0x43800000, v20 :: v_dual_mul_f32 v119, 0x43800000, v21// 0000000412EC: C8C628FF 78762AFF 43800000
	s_waitcnt vmcnt(4)                                         // 0000000412F8: BF8913F7
	v_dual_mul_f32 v118, 0x43800000, v62 :: v_dual_mul_f32 v117, 0x43800000, v17// 0000000412FC: C8C67CFF 767422FF 43800000
	v_dual_mul_f32 v116, 0x43800000, v18 :: v_dual_mul_f32 v115, 0x43800000, v19// 000000041308: C8C624FF 747226FF 43800000
	v_dual_mul_f32 v114, 0x43800000, v51 :: v_dual_mul_f32 v111, 0x43800000, v58// 000000041314: C8C666FF 726E74FF 43800000
	v_dual_mul_f32 v113, 0x43800000, v23 :: v_dual_mul_f32 v112, 0x43800000, v24// 000000041320: C8C62EFF 717030FF 43800000
	v_dual_mul_f32 v51, 0x43800000, v31 :: v_dual_mul_f32 v110, 0x43800000, v28// 00000004132C: C8C63EFF 336E38FF 43800000
	v_dual_mul_f32 v109, 0x43800000, v29 :: v_dual_mul_f32 v108, 0x43800000, v30// 000000041338: C8C63AFF 6D6C3CFF 43800000
	v_dual_mul_f32 v107, 0x43800000, v50 :: v_dual_mul_f32 v106, 0x43800000, v25// 000000041344: C8C664FF 6B6A32FF 43800000
	v_dual_mul_f32 v105, 0x43800000, v26 :: v_dual_mul_f32 v50, 0x43800000, v27// 000000041350: C8C634FF 693236FF 43800000
	v_dual_mul_f32 v104, 0x43800000, v56 :: v_dual_mul_f32 v101, 0x43800000, v37// 00000004135C: C8C670FF 68644AFF 43800000
	v_dual_mul_f32 v103, 0x43800000, v32 :: v_dual_mul_f32 v98, 0x43800000, v34// 000000041368: C8C640FF 676244FF 43800000
	v_dual_mul_f32 v102, 0x43800000, v36 :: v_dual_mul_f32 v99, 0x43800000, v33// 000000041374: C8C648FF 666242FF 43800000
	v_dual_mul_f32 v100, 0x43800000, v44 :: v_dual_mul_f32 v97, 0x43800000, v43// 000000041380: C8C658FF 646056FF 43800000
	v_dual_mul_f32 v58, 0x43800000, v35 :: v_dual_mul_f32 v93, 0x43800000, v42// 00000004138C: C8C646FF 3A5C54FF 43800000
	v_dual_mul_f32 v96, 0x43800000, v38 :: v_dual_mul_f32 v95, 0x43800000, v39// 000000041398: C8C64CFF 605E4EFF 43800000
	v_dual_mul_f32 v94, 0x43800000, v40 :: v_dual_mul_f32 v91, 0x43800000, v49// 0000000413A4: C8C650FF 5E5A62FF 43800000
	v_dual_mul_f32 v92, 0x43800000, v48 :: v_dual_mul_f32 v141, 0x43800000, v45// 0000000413B0: C8C660FF 5C8C5AFF 43800000
	v_dual_mul_f32 v152, 0x43800000, v55 :: v_dual_mul_f32 v191, 0x43800000, v57// 0000000413BC: C8C66EFF 98BE72FF 43800000
	v_dual_mul_f32 v90, 0x43800000, v41 :: v_dual_mul_f32 v189, 0x43800000, v59// 0000000413C8: C8C652FF 5ABC76FF 43800000
	s_waitcnt vmcnt(2)                                         // 0000000413D4: BF890BF7
	v_dual_mul_f32 v150, 0x43800000, v46 :: v_dual_mul_f32 v151, 0x43800000, v61// 0000000413D8: C8C65CFF 96967AFF 43800000
	v_mul_f32_e32 v142, 0x43800000, v47                        // 0000000413E4: 111C5EFF 43800000
	v_mul_f32_e32 v190, 0x43800000, v60                        // 0000000413EC: 117C78FF 43800000
	s_cmp_lt_i32 s39, 1                                        // 0000000413F4: BF048127
	s_cbranch_scc1 4721                                        // 0000000413F8: BFA21271 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x51c0>
	s_add_u32 s30, s8, s14                                     // 0000000413FC: 801E0E08
	s_addc_u32 s31, s9, s15                                    // 000000041400: 821F0F09
	s_lshl_b64 s[14:15], s[2:3], 2                             // 000000041404: 848E8202
	s_load_b64 s[26:27], s[0:1], 0x68                          // 000000041408: F4040680 F8000068
	s_add_u32 s10, s10, s14                                    // 000000041410: 800A0E0A
	s_addc_u32 s11, s11, s15                                   // 000000041414: 820B0F0B
	s_add_u32 s34, s12, s14                                    // 000000041418: 80220E0C
	s_addc_u32 s35, s13, s15                                   // 00000004141C: 82230F0D
	s_add_i32 s3, s39, 15                                      // 000000041420: 81038F27
	s_load_b256 s[12:19], s[0:1], 0x48                         // 000000041424: F40C0300 F8000048
	s_ashr_i32 s4, s3, 31                                      // 00000004142C: 86049F03
	.long 0xd71f008f                                           // 000000041430: D71F008F
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000041434: 020100C1
	s_lshr_b32 s4, s4, 28                                      // 000000041438: 85049C04
	v_mov_b32_e32 v1, 0                                        // 00000004143C: 7E020280
	s_add_i32 s3, s3, s4                                       // 000000041440: 81030403
	v_mov_b32_e32 v149, 0x1000504                              // 000000041444: 7F2A02FF 01000504
	s_waitcnt lgkmcnt(0)                                       // 00000004144C: BF89FC07
	s_ashr_i32 s15, s3, 4                                      // 000000041450: 860F8403
	s_cmp_lg_u32 s21, 0                                        // 000000041454: BF078015
	s_movk_i32 s3, 0x5f40                                      // 000000041458: B0035F40
	s_cselect_b32 s41, -1, 0                                   // 00000004145C: 982980C1
	s_lshl_b32 s22, s2, 7                                      // 000000041460: 84168702
	v_and_b32_e32 v2, 16, v143                                 // 000000041464: 36051E90
	s_ashr_i32 s23, s22, 31                                    // 000000041468: 86179F16
	s_cmp_gt_u32 s20, 63                                       // 00000004146C: BF08BF14
	v_xor_b32_e32 v146, 2, v143                                // 000000041470: 3B251E82
	s_cselect_b32 s42, -1, 0                                   // 000000041474: 982A80C1
	s_cmp_eq_u32 s21, 0                                        // 000000041478: BF068015
	v_add_nc_u32_e32 v144, 16, v2                              // 00000004147C: 4B200490
	s_cselect_b32 s2, -1, 0                                    // 000000041480: 980280C1
	v_xor_b32_e32 v147, 4, v143                                // 000000041484: 3B271E84
	s_and_b32 s4, s2, exec_lo                                  // 000000041488: 8B047E02
	s_cselect_b32 s43, s3, 0x5f80                              // 00000004148C: 982BFF03 00005F80
	s_lshl_b64 s[36:37], s[22:23], 1                           // 000000041494: 84A48116
	v_xor_b32_e32 v148, 8, v143                                // 000000041498: 3B291E88
	s_add_u32 s44, s24, s36                                    // 00000004149C: 802C2418
	s_addc_u32 s45, s25, s37                                   // 0000000414A0: 822D2519
	s_max_i32 s46, s15, 1                                      // 0000000414A4: 8A2E810F
	s_add_u32 s16, s16, s6                                     // 0000000414A8: 80100610
	s_addc_u32 s17, s17, s7                                    // 0000000414AC: 82110711
	s_add_u32 s18, s18, s6                                     // 0000000414B0: 80120612
	s_mov_b32 s20, 0                                           // 0000000414B4: BE940080
	s_addc_u32 s19, s19, s7                                    // 0000000414B8: 82130713
	s_add_u32 s47, s26, s6                                     // 0000000414BC: 802F061A
	s_addc_u32 s7, s27, s7                                     // 0000000414C0: 8207071B
	s_mov_b32 s48, 0x41800000                                  // 0000000414C4: BEB000FF 41800000
	s_movk_i32 s49, 0x1800                                     // 0000000414CC: B0311800
	s_movk_i32 s50, 0x2900                                     // 0000000414D0: B0322900
	s_mov_b32 s21, s20                                         // 0000000414D4: BE950014
	s_mov_b32 s22, s20                                         // 0000000414D8: BE960014
	s_mov_b32 s23, s20                                         // 0000000414DC: BE970014
	s_mov_b32 s24, s20                                         // 0000000414E0: BE980014
	s_mov_b32 s25, s20                                         // 0000000414E4: BE990014
	s_mov_b32 s26, s20                                         // 0000000414E8: BE9A0014
	s_mov_b32 s27, s20                                         // 0000000414EC: BE9B0014
	s_mov_b32 s51, 0x3d800000                                  // 0000000414F0: BEB300FF 3D800000
	s_mov_b32 s52, 0x76543210                                  // 0000000414F8: BEB400FF 76543210
	s_mov_b32 s53, s20                                         // 000000041500: BEB50014
	s_mov_b32 s6, s20                                          // 000000041504: BE860014
	s_branch 10                                                // 000000041508: BFA0000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x934>
	v_mov_b32_e32 v151, v65                                    // 00000004150C: 7F2E0341
	v_mov_b32_e32 v152, v57                                    // 000000041510: 7F300339
	v_mov_b32_e32 v58, v49                                     // 000000041514: 7E740331
	v_mov_b32_e32 v50, v9                                      // 000000041518: 7E640309
	v_mov_b32_e32 v51, v17                                     // 00000004151C: 7E660311
	v_mov_b32_e32 v52, v25                                     // 000000041520: 7E680319
	v_mov_b32_e32 v53, v33                                     // 000000041524: 7E6A0321
	v_mov_b32_e32 v54, v41                                     // 000000041528: 7E6C0329
	s_cmp_eq_u32 s53, s46                                      // 00000004152C: BF062E35
	s_cbranch_scc1 4633                                        // 000000041530: BFA21219 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5198>
	v_mov_b32_e32 v44, v0                                      // 000000041534: 7E580300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000041538: BF8701B1
	v_ashrrev_i32_e32 v2, 4, v44                               // 00000004153C: 34045884
	v_and_b32_e32 v55, 15, v44                                 // 000000041540: 366E588F
	.long 0xd4440003                                           // 000000041544: D4440003
	v_cndmask_b32_e32 v1, 16, v44, vcc_lo                      // 000000041548: 02025890
	.long 0xd72c0003                                           // 00000004154C: D72C0003
	v_cndmask_b32_e32 v1, 0x110, v2, vcc_lo                    // 000000041550: 020204FF 00000110
	s_delay_alu instid0(VALU_DEP_1)                            // 000000041558: BF870001
	v_lshl_add_u32 v3, v55, 4, v3                              // 00000004155C: D6460003 040D0937
	s_waitcnt vmcnt(1)                                         // 000000041564: BF8907F7
	ds_store_b128 v3, v[74:77] offset:10496                    // 000000041568: DB7C2900 00004A03
	s_waitcnt vmcnt(0)                                         // 000000041570: BF8903F7
	ds_store_b128 v3, v[78:81] offset:6144                     // 000000041574: DB7C1800 00004E03
	s_and_saveexec_b32 s4, s3                                  // 00000004157C: BE842003
	s_cbranch_execz 6                                          // 000000041580: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x99c>
	scratch_load_b32 v4, off, off                              // 000000041584: DC510000 047C0000
	v_lshlrev_b32_e32 v3, 2, v44                               // 00000004158C: 30065882
	s_waitcnt vmcnt(0)                                         // 000000041590: BF8903F7
	ds_store_b32 v3, v4 offset:24064                           // 000000041594: D8345E00 00000403
	s_or_b32 exec_lo, exec_lo, s4                              // 00000004159C: 8C7E047E
	v_and_b32_e32 v34, 1, v44                                  // 0000000415A0: 36445881
	s_lshl_b32 s54, s53, 4                                     // 0000000415A4: 84368435
	v_or_b32_e32 v153, s33, v55                                // 0000000415A8: 39326E21
	s_mov_b32 s29, exec_lo                                     // 0000000415AC: BE9D007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000415B0: BF870112
	v_or_b32_e32 v15, s54, v34                                 // 0000000415B4: 381E4436
	v_and_b32_e32 v6, 0x7ffffffe, v153                         // 0000000415B8: 360D32FF 7FFFFFFE
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000000415C0: BF870232
	v_min_i32_e32 v3, s40, v15                                 // 0000000415C4: 22061E28
	v_or_b32_e32 v5, 2, v15                                    // 0000000415C8: 380A1E82
	v_or_b32_e32 v7, 4, v15                                    // 0000000415CC: 380E1E84
	v_lshlrev_b32_e32 v19, 1, v6                               // 0000000415D0: 30260C81
	v_or_b32_e32 v8, 6, v15                                    // 0000000415D4: 38101E86
	v_mad_i64_i32 v[3:4], null, 0x5000, v3, s[8:9]             // 0000000415D8: D6FF7C03 002206FF 00005000
	v_min_i32_e32 v5, s40, v5                                  // 0000000415E4: 220A0A28
	v_min_i32_e32 v7, s40, v7                                  // 0000000415E8: 220E0E28
	v_or_b32_e32 v17, 12, v15                                  // 0000000415EC: 38221E8C
	v_min_i32_e32 v8, s40, v8                                  // 0000000415F0: 22101028
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000415F4: BF8700A4
	v_mad_i64_i32 v[5:6], null, 0x5000, v5, s[8:9]             // 0000000415F8: D6FF7C05 00220AFF 00005000
	.long 0xd7006a09                                           // 000000041604: D7006A09
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000041608: 02004903
	v_add_co_ci_u32_e64 v10, null, s37, v4, vcc_lo             // 00000004160C: D5207C0A 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v7, s[8:9]             // 000000041614: D6FF7C03 00220EFF 00005000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041620: BF870093
	.long 0xd7006a07                                           // 000000041624: D7006A07
	v_cndmask_b32_e32 v1, v9, v19, vcc_lo                      // 000000041628: 02022709
	v_add_co_ci_u32_e64 v9, null, 0, v10, vcc_lo               // 00000004162C: D5207C09 01AA1480
	.long 0xd7006a0a                                           // 000000041634: D7006A0A
	v_cndmask_b32_e32 v0, v5, v36, vcc_lo                      // 000000041638: 02004905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004163C: BF870211
	v_add_co_ci_u32_e64 v11, null, s37, v6, vcc_lo             // 000000041640: D5207C0B 01AA0C25
	.long 0xd7006a05                                           // 000000041648: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 00000004164C: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000041654: BF870211
	v_add_co_ci_u32_e64 v6, null, 0, v9, vcc_lo                // 000000041658: D5207C06 01AA1280
	.long 0xd7006a07                                           // 000000041660: D7006A07
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 000000041664: 0202270A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000041668: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v11, vcc_lo               // 00000004166C: D5207C09 01AA1680
	.long 0xd7006a0a                                           // 000000041674: D7006A0A
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000041678: 02004903
	v_add_co_ci_u32_e64 v11, null, s37, v4, vcc_lo             // 00000004167C: D5207C0B 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v8, s[8:9]             // 000000041684: D6FF7C03 002210FF 00005000
	.long 0xd7006a07                                           // 000000041690: D7006A07
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 000000041694: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004169C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v9, vcc_lo                // 0000000416A0: D5207C08 01AA1280
	.long 0xd7006a09                                           // 0000000416A8: D7006A09
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 0000000416AC: 0202270A
	v_add_co_ci_u32_e64 v10, null, 0, v11, vcc_lo              // 0000000416B0: D5207C0A 01AA1680
	v_or_b32_e32 v11, 8, v15                                   // 0000000416B8: 38161E88
	.long 0xd7006a03                                           // 0000000416BC: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 0000000416C0: 02004903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000416C4: BF870191
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 0000000416C8: D5207C04 01AA0825
	v_min_i32_e32 v11, s40, v11                                // 0000000416D0: 22161628
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000416D4: BF870093
	.long 0xd7006a0c                                           // 0000000416D8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 0000000416DC: 02022703
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 0000000416E0: D5207C0D 01AA0880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000416E8: BF8700A3
	v_mad_i64_i32 v[3:4], null, 0x5000, v11, s[8:9]            // 0000000416EC: D6FF7C03 002216FF 00005000
	.long 0xd7006a09                                           // 0000000416F8: D7006A09
	v_cndmask_b32_e32 v1, 0x2000, v9, vcc_lo                   // 0000000416FC: 020212FF 00002000
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo              // 000000041704: D5207C0A 01AA1480
	.long 0xd7006a0b                                           // 00000004170C: D7006A0B
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 000000041710: 020218FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000041718: BF8700B1
	v_add_co_ci_u32_e64 v12, null, 0, v13, vcc_lo              // 00000004171C: D5207C0C 01AA1A80
	v_or_b32_e32 v13, 10, v15                                  // 000000041724: 381A1E8A
	.long 0xd7006a03                                           // 000000041728: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000004172C: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 000000041730: D5207C04 01AA0825
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000041738: BF870193
	v_min_i32_e32 v13, s40, v13                                // 00000004173C: 221A1A28
	.long 0xd7006a0e                                           // 000000041740: D7006A0E
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000041744: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000041748: BF870191
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000004174C: D5207C10 01AA0880
	v_mad_i64_i32 v[3:4], null, 0x5000, v13, s[8:9]            // 000000041754: D6FF7C03 00221AFF 00005000
	v_or_b32_e32 v15, 14, v15                                  // 000000041760: 381E1E8E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041764: BF870094
	.long 0xd7006a0d                                           // 000000041768: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v14, vcc_lo                  // 00000004176C: 02021CFF 00002000
	v_add_co_ci_u32_e64 v14, null, 0, v16, vcc_lo              // 000000041774: D5207C0E 01AA2080
	v_min_i32_e32 v16, s40, v17                                // 00000004177C: 22202228
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000041780: BF8700A4
	v_min_i32_e32 v15, s40, v15                                // 000000041784: 221E1E28
	.long 0xd7006a11                                           // 000000041788: D7006A11
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000004178C: 02004903
	v_add_co_ci_u32_e64 v18, null, s37, v4, vcc_lo             // 000000041790: D5207C12 01AA0825
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000041798: BF870194
	v_mad_i64_i32 v[3:4], null, 0x5000, v16, s[8:9]            // 00000004179C: D6FF7C03 002220FF 00005000
	.long 0xd7006a11                                           // 0000000417A8: D7006A11
	v_cndmask_b32_e32 v1, v17, v19, vcc_lo                     // 0000000417AC: 02022711
	v_mad_i64_i32 v[15:16], null, 0x5000, v15, s[8:9]          // 0000000417B0: D6FF7C0F 00221EFF 00005000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000417BC: BF870194
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 0000000417C0: D5207C12 01AA2480
	.long 0xd7006a11                                           // 0000000417C8: D7006A11
	v_cndmask_b32_e32 v1, 0x2000, v17, vcc_lo                  // 0000000417CC: 020222FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000417D4: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 0000000417D8: D5207C12 01AA2480
	.long 0xd7006a03                                           // 0000000417E0: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 0000000417E4: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 0000000417E8: D5207C04 01AA0825
	.long 0xd7006a0f                                           // 0000000417F0: D7006A0F
	v_cndmask_b32_e32 v0, v15, v36, vcc_lo                     // 0000000417F4: 0200490F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000417F8: BF870211
	v_add_co_ci_u32_e64 v16, null, s37, v16, vcc_lo            // 0000000417FC: D5207C10 01AA2025
	.long 0xd7006a03                                           // 000000041804: D7006A03
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000041808: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004180C: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000041810: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 000000041818: D7006A0F
	v_cndmask_b32_e32 v1, v15, v19, vcc_lo                     // 00000004181C: 0202270F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000041820: BF870211
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 000000041824: D5207C10 01AA2080
	.long 0xd7006a03                                           // 00000004182C: D7006A03
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 000000041830: 020206FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000041838: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000004183C: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 000000041844: D7006A0F
	v_cndmask_b32_e32 v1, 0x2000, v15, vcc_lo                  // 000000041848: 02021EFF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000041850: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 000000041854: D5207C10 01AA2080
	s_clause 0x7                                               // 00000004185C: BF850007
	global_load_b32 v42, v[5:6], off                           // 000000041860: DC520000 2A7C0005
	global_load_b32 v41, v[7:8], off                           // 000000041868: DC520000 297C0007
	global_load_b32 v40, v[9:10], off                          // 000000041870: DC520000 287C0009
	global_load_b32 v39, v[11:12], off                         // 000000041878: DC520000 277C000B
	global_load_b32 v38, v[13:14], off                         // 000000041880: DC520000 267C000D
	global_load_b32 v37, v[17:18], off                         // 000000041888: DC520000 257C0011
	global_load_b32 v35, v[3:4], off                           // 000000041890: DC520000 237C0003
	global_load_b32 v36, v[15:16], off                         // 000000041898: DC520000 247C000F
	v_lshlrev_b32_e32 v5, 16, v78                              // 0000000418A0: 300A9C90
	v_and_b32_e32 v4, 0xffff0000, v74                          // 0000000418A4: 360894FF FFFF0000
	v_and_b32_e32 v8, 0xffff0000, v75                          // 0000000418AC: 361096FF FFFF0000
	v_lshlrev_b32_e32 v3, 16, v74                              // 0000000418B4: 30069490
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000418B8: BF8701A4
	v_dual_mul_f32 v5, v5, v5 :: v_dual_lshlrev_b32 v12, 16, v80// 0000000418BC: C8E20B05 050CA090
	v_lshlrev_b32_e32 v7, 16, v75                              // 0000000418C4: 300E9690
	v_dual_mul_f32 v3, v3, v3 :: v_dual_and_b32 v6, 0xffff0000, v78// 0000000418C8: C8E40703 03069CFF FFFF0000
	v_mul_f32_e32 v4, v4, v4                                   // 0000000418D4: 10080904
	v_and_b32_e32 v13, 0xffff0000, v80                         // 0000000418D8: 361AA0FF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v76                         // 0000000418E0: 361498FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000418E8: BF8701B4
	v_dual_mul_f32 v6, v6, v6 :: v_dual_and_b32 v11, 0xffff0000, v77// 0000000418EC: C8E40D06 060A9AFF FFFF0000
	v_mul_f32_e32 v12, v12, v12                                // 0000000418F8: 1018190C
	v_add_f32_e32 v3, v3, v4                                   // 0000000418FC: 06060903
	v_dual_add_f32 v4, v5, v6 :: v_dual_lshlrev_b32 v9, 16, v76// 000000041900: C9220D05 04089890
	v_dual_mul_f32 v5, v7, v7 :: v_dual_mul_f32 v6, v8, v8     // 000000041908: C8C60F07 05061108
	v_lshlrev_b32_e32 v7, 16, v79                              // 000000041910: 300E9E90
	v_dual_mul_f32 v13, v13, v13 :: v_dual_and_b32 v8, 0xffff0000, v79// 000000041914: C8E41B0D 0D089EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000041920: BF870113
	v_dual_add_f32 v5, v5, v6 :: v_dual_and_b32 v14, 0xffff0000, v81// 000000041924: C9240D05 050EA2FF FFFF0000
	v_dual_mul_f32 v6, v7, v7 :: v_dual_mul_f32 v7, v8, v8     // 000000041930: C8C60F07 06061108
	v_dual_mul_f32 v8, v9, v9 :: v_dual_mul_f32 v9, v10, v10   // 000000041938: C8C61309 0808150A
	v_lshlrev_b32_e32 v10, 16, v77                             // 000000041940: 30149A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000041944: BF870113
	v_dual_add_f32 v6, v6, v7 :: v_dual_add_f32 v7, v12, v13   // 000000041948: C9080F06 06061B0C
	v_dual_add_f32 v8, v8, v9 :: v_dual_mul_f32 v9, v10, v10   // 000000041950: C9061308 0808150A
	v_dual_mul_f32 v10, v11, v11 :: v_dual_lshlrev_b32 v11, 16, v81// 000000041958: C8E2170B 0A0AA290
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000041960: BF870113
	v_add_f32_e32 v4, v4, v6                                   // 000000041964: 06080D04
	v_dual_add_f32 v9, v9, v10 :: v_dual_mul_f32 v10, v11, v11 // 000000041968: C9061509 090A170B
	v_mul_f32_e32 v11, v14, v14                                // 000000041970: 10161D0E
	v_add_f32_e32 v3, v3, v5                                   // 000000041974: 06060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000041978: BF870123
	v_add_f32_e32 v5, v8, v9                                   // 00000004197C: 060A1308
	v_xor_b32_e32 v9, 1, v143                                  // 000000041980: 3A131E81
	v_dual_add_f32 v8, v10, v11 :: v_dual_add_f32 v3, v3, v5   // 000000041984: C908170A 08020B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000004198C: BF8701A2
	v_cmp_lt_u32_e32 vcc_lo, v9, v144                          // 000000041990: 7C932109
	v_cndmask_b32_e32 v9, v143, v9, vcc_lo                     // 000000041994: 0212138F
	v_add_f32_e32 v5, v7, v8                                   // 000000041998: 060A1107
	v_cmp_lt_u32_e32 vcc_lo, v146, v144                        // 00000004199C: 7C932192
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000419A0: BF870193
	v_lshlrev_b32_e32 v6, 2, v9                                // 0000000419A4: 300C1282
	v_dual_add_f32 v4, v4, v5 :: v_dual_cndmask_b32 v7, v143, v146// 0000000419A8: C9120B04 0407258F
	v_cmp_lt_u32_e32 vcc_lo, v147, v144                        // 0000000419B0: 7C932193
	ds_bpermute_b32 v5, v6, v3                                 // 0000000419B4: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 0000000419BC: DACC0000 06000406
	s_waitcnt lgkmcnt(0)                                       // 0000000419C4: BF89FC07
	v_dual_add_f32 v4, v4, v6 :: v_dual_add_f32 v3, v3, v5     // 0000000419C8: C9080D04 04020B03
	v_lshlrev_b32_e32 v5, 2, v7                                // 0000000419D0: 300A0E82
	ds_bpermute_b32 v6, v5, v3                                 // 0000000419D4: DACC0000 06000305
	ds_bpermute_b32 v5, v5, v4                                 // 0000000419DC: DACC0000 05000405
	v_cndmask_b32_e32 v7, v143, v147, vcc_lo                   // 0000000419E4: 020F278F
	v_cmp_lt_u32_e32 vcc_lo, v148, v144                        // 0000000419E8: 7C932194
	s_waitcnt lgkmcnt(0)                                       // 0000000419EC: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v5     // 0000000419F0: C9080D03 03040B04
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000419F8: BF870003
	v_dual_cndmask_b32 v7, v143, v148 :: v_dual_lshlrev_b32 v6, 2, v7// 0000000419FC: CA63298F 07060E82
	ds_bpermute_b32 v5, v6, v3                                 // 000000041A04: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 000000041A0C: DACC0000 06000406
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000041A14: 300E0E82
	s_waitcnt lgkmcnt(0)                                       // 000000041A18: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 000000041A1C: C9080B03 03040D04
	ds_bpermute_b32 v5, v7, v3                                 // 000000041A24: DACC0000 05000307
	ds_bpermute_b32 v6, v7, v4                                 // 000000041A2C: DACC0000 06000407
	v_cmpx_eq_u32_e32 0, v55                                   // 000000041A34: 7D946E80
	s_cbranch_execnz 18                                        // 000000041A38: BFA60012 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xe84>
	s_or_b32 exec_lo, exec_lo, s29                             // 000000041A3C: 8C7E1D7E
	v_and_b32_e32 v43, 31, v44                                 // 000000041A40: 3656589F
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 000000041A44: 916A027E
	s_cbranch_vccz 59                                          // 000000041A48: BFA3003B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xf38>
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 000000041A4C: 916A267E
	s_cbranch_vccz 179                                         // 000000041A50: BFA300B3 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1120>
	s_waitcnt lgkmcnt(0)                                       // 000000041A54: BF89FC07
	s_barrier                                                  // 000000041A58: BFBD0000
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 000000041A5C: 916A267E
	s_cbranch_vccz 177                                         // 000000041A60: BFA300B1 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1128>
	s_add_i32 s53, s53, 1                                      // 000000041A64: 81358135
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000041A68: BF870009
	s_cmp_ge_i32 s53, s15                                      // 000000041A6C: BF030F35
	s_cbranch_scc0 181                                         // 000000041A70: BFA100B5 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1148>
	s_and_b32 vcc_lo, exec_lo, s42                             // 000000041A74: 8B6A2A7E
	s_mov_b32 s3, -1                                           // 000000041A78: BE8300C1
	s_cbranch_vccnz 252                                        // 000000041A7C: BFA400FC <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1270>
	s_branch 331                                               // 000000041A80: BFA0014B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x13b0>
	s_waitcnt lgkmcnt(0)                                       // 000000041A84: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 000000041A88: C9080B03 03040D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041A90: BF870091
	v_dual_add_f32 v3, 0x358637bd, v3 :: v_dual_add_f32 v4, 0x358637bd, v4// 000000041A94: C90806FF 030408FF 358637BD
	v_dual_mul_f32 v5, 0x4b800000, v3 :: v_dual_mul_f32 v6, 0x4b800000, v4// 000000041AA0: C8C606FF 050608FF 4B800000
	.long 0xd4140004                                           // 000000041AAC: D4140004
	v_cndmask_b32_e32 v1, 0x800000, v4, vcc_lo                 // 000000041AB0: 020208FF 00800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v3                      // 000000041AB8: 7C2806FF 00800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041AC0: BF870092
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 000000041AC4: D5010004 00120D04
	v_rsq_f32_e32 v4, v4                                       // 000000041ACC: 7E085D04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041AD0: BF870095
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_mul_f32 v6, 0x45800000, v4// 000000041AD4: CA460B03 030608FF 45800000
	v_rsq_f32_e32 v3, v3                                       // 000000041AE0: 7E065D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 000000041AE4: BF870321
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 000000041AE8: D5010004 00120D04
	v_rsq_f32_e32 v6, 0x43000000                               // 000000041AF0: 7E0C5CFF 43000000
	v_mul_f32_e32 v5, 0x45800000, v3                           // 000000041AF8: 100A06FF 45800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000041B00: BF870001
	v_cndmask_b32_e32 v3, v3, v5, vcc_lo                       // 000000041B04: 02060B03
	v_lshlrev_b32_e32 v5, 2, v2                                // 000000041B08: 300A0482
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)   // 000000041B0C: BF870105
	v_mul_f32_e32 v3, v6, v3                                   // 000000041B10: 10060706
	s_delay_alu instid0(VALU_DEP_2)                            // 000000041B14: BF870002
	v_add_nc_u32_e32 v5, 0x5c00, v5                            // 000000041B18: 4A0A0AFF 00005C00
	ds_store_2addr_b32 v5, v4, v3 offset0:208 offset1:224      // 000000041B20: D838E0D0 00030405
	s_or_b32 exec_lo, exec_lo, s29                             // 000000041B28: 8C7E1D7E
	v_and_b32_e32 v43, 31, v44                                 // 000000041B2C: 3656589F
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 000000041B30: 916A027E
	s_cbranch_vccnz 65477                                      // 000000041B34: BFA4FFC5 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xe4c>
	.long 0xd7600045                                           // 000000041B38: D7600045
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                   // 000000041B3C: 0201018C
	.long 0xd7600044                                           // 000000041B40: D7600044
	v_cndmask_b32_e32 v0, v140, v129, vcc_lo                   // 000000041B44: 0201038C
	.long 0xd7600043                                           // 000000041B48: D7600043
	v_cndmask_b32_e32 v0, v140, v130, vcc_lo                   // 000000041B4C: 0201058C
	.long 0xd7600042                                           // 000000041B50: D7600042
	v_cndmask_b32_e32 v0, v140, v131, vcc_lo                   // 000000041B54: 0201078C
	.long 0xd7600041                                           // 000000041B58: D7600041
	v_cndmask_b32_e32 v0, v140, v132, vcc_lo                   // 000000041B5C: 0201098C
	.long 0xd7600040                                           // 000000041B60: D7600040
	v_cndmask_b32_e32 v0, v140, v133, vcc_lo                   // 000000041B64: 02010B8C
	.long 0xd760003f                                           // 000000041B68: D760003F
	v_cndmask_b32_e32 v0, v140, v134, vcc_lo                   // 000000041B6C: 02010D8C
	.long 0xd760003e                                           // 000000041B70: D760003E
	v_cndmask_b32_e32 v0, v140, v135, vcc_lo                   // 000000041B74: 02010F8C
	.long 0xd760003d                                           // 000000041B78: D760003D
	v_cndmask_b32_e32 v0, v140, v136, vcc_lo                   // 000000041B7C: 0201118C
	.long 0xd760003c                                           // 000000041B80: D760003C
	v_cndmask_b32_e32 v0, v140, v137, vcc_lo                   // 000000041B84: 0201138C
	.long 0xd760003b                                           // 000000041B88: D760003B
	v_cndmask_b32_e32 v0, v140, v138, vcc_lo                   // 000000041B8C: 0201158C
	.long 0xd760003a                                           // 000000041B90: D760003A
	v_cndmask_b32_e32 v0, v140, v139, vcc_lo                   // 000000041B94: 0201178C
	.long 0xd7600039                                           // 000000041B98: D7600039
	v_cndmask_b32_e32 v0, v140, v140, vcc_lo                   // 000000041B9C: 0201198C
	.long 0xd7600038                                           // 000000041BA0: D7600038
	v_cndmask_b32_e32 v0, v140, v141, vcc_lo                   // 000000041BA4: 02011B8C
	.long 0xd7600037                                           // 000000041BA8: D7600037
	v_cndmask_b32_e32 v0, v140, v142, vcc_lo                   // 000000041BAC: 02011D8C
	.long 0xd760001d                                           // 000000041BB0: D760001D
	v_cndmask_b32_e32 v0, v140, v143, vcc_lo                   // 000000041BB4: 02011F8C
	s_mov_b32 s4, exec_lo                                      // 000000041BB8: BE84007E
	v_cmpx_gt_u32_e32 16, v43                                  // 000000041BBC: 7D985690
	s_cbranch_execz 83                                         // 000000041BC0: BFA50053 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1110>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 000000041BC4: 7C945680
	s_add_f32 s69, s69, 0                                      // 000000041BC8: A0458045
	v_lshlrev_b32_e32 v4, 2, v43                               // 000000041BCC: 30085682
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000041BD0: BF8704BA
	s_add_f32 s68, s69, s68                                    // 000000041BD4: A0444445
	v_cndmask_b32_e64 v3, 0, s69, vcc_lo                       // 000000041BD8: D5010003 01A88A80
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 000000041BE0: 7C945681
	s_add_f32 s67, s68, s67                                    // 000000041BE4: A0434344
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000041BE8: BF8704A2
	v_cndmask_b32_e64 v3, v3, s68, vcc_lo                      // 000000041BEC: D5010003 01A88903
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 000000041BF4: 7C945682
	s_add_f32 s66, s67, s66                                    // 000000041BF8: A0424243
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000041BFC: BF8704A2
	v_cndmask_b32_e64 v3, v3, s67, vcc_lo                      // 000000041C00: D5010003 01A88703
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 000000041C08: 7C945683
	s_add_f32 s65, s66, s65                                    // 000000041C0C: A0414142
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000041C10: BF8704A2
	v_cndmask_b32_e64 v3, v3, s66, vcc_lo                      // 000000041C14: D5010003 01A88503
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 000000041C1C: 7C945684
	s_add_f32 s64, s65, s64                                    // 000000041C20: A0404041
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000041C24: BF8704A2
	v_cndmask_b32_e64 v3, v3, s65, vcc_lo                      // 000000041C28: D5010003 01A88303
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 000000041C30: 7C945685
	s_add_f32 s63, s64, s63                                    // 000000041C34: A03F3F40
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000041C38: BF8704A2
	v_cndmask_b32_e64 v3, v3, s64, vcc_lo                      // 000000041C3C: D5010003 01A88103
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 000000041C44: 7C945686
	s_add_f32 s62, s63, s62                                    // 000000041C48: A03E3E3F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000041C4C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s63, vcc_lo                      // 000000041C50: D5010003 01A87F03
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 000000041C58: 7C945687
	s_add_f32 s61, s62, s61                                    // 000000041C5C: A03D3D3E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000041C60: BF8704A2
	v_cndmask_b32_e64 v3, v3, s62, vcc_lo                      // 000000041C64: D5010003 01A87D03
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 000000041C6C: 7C945688
	s_add_f32 s60, s61, s60                                    // 000000041C70: A03C3C3D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000041C74: BF8704A2
	v_cndmask_b32_e64 v3, v3, s61, vcc_lo                      // 000000041C78: D5010003 01A87B03
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 000000041C80: 7C945689
	s_add_f32 s59, s60, s59                                    // 000000041C84: A03B3B3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000041C88: BF8704A2
	v_cndmask_b32_e64 v3, v3, s60, vcc_lo                      // 000000041C8C: D5010003 01A87903
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 000000041C94: 7C94568A
	s_add_f32 s58, s59, s58                                    // 000000041C98: A03A3A3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000041C9C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s59, vcc_lo                      // 000000041CA0: D5010003 01A87703
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 000000041CA8: 7C94568B
	s_add_f32 s57, s58, s57                                    // 000000041CAC: A039393A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000041CB0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s58, vcc_lo                      // 000000041CB4: D5010003 01A87503
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 000000041CBC: 7C94568C
	s_add_f32 s56, s57, s56                                    // 000000041CC0: A0383839
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000041CC4: BF8704A2
	v_cndmask_b32_e64 v3, v3, s57, vcc_lo                      // 000000041CC8: D5010003 01A87303
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 000000041CD0: 7C94568D
	s_add_f32 s55, s56, s55                                    // 000000041CD4: A0373738
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000041CD8: BF8704A2
	v_cndmask_b32_e64 v3, v3, s56, vcc_lo                      // 000000041CDC: D5010003 01A87103
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 000000041CE4: 7C94568E
	s_add_f32 s29, s55, s29                                    // 000000041CE8: A01D1D37
	s_delay_alu instid0(VALU_DEP_2)                            // 000000041CEC: BF870002
	v_cndmask_b32_e64 v3, v3, s55, vcc_lo                      // 000000041CF0: D5010003 01A86F03
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 000000041CF8: 7C94568F
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 000000041CFC: BF870482
	v_cndmask_b32_e64 v3, v3, s29, vcc_lo                      // 000000041D00: D5010003 01A83B03
	ds_store_b32 v4, v3 offset:24128                           // 000000041D08: D8345E40 00000304
	s_or_b32 exec_lo, exec_lo, s4                              // 000000041D10: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000041D14: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 000000041D18: 916A267E
	s_cbranch_vccnz 65357                                      // 000000041D1C: BFA4FF4D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xe54>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 000000041D20: BE9C4D83
	s_branch 65355                                             // 000000041D24: BFA0FF4B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xe54>
	s_sendmsg_rtn_b64 s[56:57], sendmsg(MSG_RTN_GET_REALTIME)  // 000000041D28: BEB84D83
	s_waitcnt lgkmcnt(0)                                       // 000000041D2C: BF89FC07
	s_sub_i32 s4, s6, s28                                      // 000000041D30: 81841C06
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000041D34: BF8704A9
	s_add_i32 s6, s4, s56                                      // 000000041D38: 81063804
	s_add_i32 s53, s53, 1                                      // 000000041D3C: 81358135
	s_cmp_ge_i32 s53, s15                                      // 000000041D40: BF030F35
	s_cbranch_scc1 65355                                       // 000000041D44: BFA2FF4B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xe74>
	s_lshl_b32 s4, s53, 4                                      // 000000041D48: 84048435
	v_lshlrev_b32_e32 v4, 4, v44                               // 000000041D4C: 30085884
	s_waitcnt lgkmcnt(0)                                       // 000000041D50: BF89FC07
	v_add_nc_u32_e32 v6, s4, v2                                // 000000041D54: 4A0C0404
	s_mov_b32 s29, exec_lo                                     // 000000041D58: BE9D007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000041D5C: BF870112
	v_and_b32_e32 v4, 0xf0, v4                                 // 000000041D60: 360808FF 000000F0
	v_min_i32_e32 v2, s40, v6                                  // 000000041D68: 22040C28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041D6C: BF870091
	v_mad_i64_i32 v[2:3], null, 0x5000, v2, s[30:31]           // 000000041D70: D6FF7C02 007A04FF 00005000
	.long 0xd7006a02                                           // 000000041D7C: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000041D80: 02020902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000041D84: BF870111
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000041D88: D5207C03 01AA0680
	.long 0xd7006a04                                           // 000000041D90: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 000000041D94: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000041D9C: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 000000041DA0: D5207C05 01AA0680
	s_clause 0x1                                               // 000000041DA8: BF850001
	global_load_b128 v[74:77], v[2:3], off                     // 000000041DAC: DC5E0000 4A7C0002
	global_load_b128 v[78:81], v[4:5], off                     // 000000041DB4: DC5E0000 4E7C0004
	.long 0xd4c3007e                                           // 000000041DBC: D4C3007E
	v_cndmask_b32_e32 v1, s39, v6, vcc_lo                      // 000000041DC0: 02020C27
	s_cbranch_execz 11                                         // 000000041DC4: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11f4>
	s_waitcnt vmcnt(1)                                         // 000000041DC8: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 000000041DCC: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000041DD0: BF870001
	v_mov_b32_e32 v75, v76                                     // 000000041DD4: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 000000041DD8: 7E94034C
	s_waitcnt vmcnt(0)                                         // 000000041DDC: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 000000041DE0: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 000000041DE4: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 000000041DE8: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 000000041DEC: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 000000041DF0: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s29                             // 000000041DF4: 8C7E1D7E
	s_and_saveexec_b32 s29, s3                                 // 000000041DF8: BE9D2003
	s_cbranch_execz 23                                         // 000000041DFC: BFA50017 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x125c>
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v2, s4, v44      // 000000041E00: CA200080 03025804
	v_mov_b32_e32 v140, 0                                      // 000000041E08: 7F180280
	s_mov_b32 s3, exec_lo                                      // 000000041E0C: BE83007E
	scratch_store_b32 off, v3, off                             // 000000041E10: DC690000 007C0300
	.long 0xd4c4007e                                           // 000000041E18: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 000000041E1C: 02020427
	s_cbranch_execz 13                                         // 000000041E20: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1258>
	v_mad_i64_i32 v[3:4], null, 0xc0, v2, s[10:11]             // 000000041E24: D6FF7C03 002A04FF 000000C0
	v_mad_i64_i32 v[5:6], null, 0xc0, v2, s[34:35]             // 000000041E30: D6FF7C05 008A04FF 000000C0
	global_load_b32 v140, v[3:4], off                          // 000000041E3C: DC520000 8C7C0003
	global_load_b32 v2, v[5:6], off                            // 000000041E44: DC520000 027C0005
	s_waitcnt vmcnt(0)                                         // 000000041E4C: BF8903F7
	scratch_store_b32 off, v2, off                             // 000000041E50: DC690000 007C0200
	s_or_b32 exec_lo, exec_lo, s3                              // 000000041E58: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000041E5C: BF870499
	s_or_b32 exec_lo, exec_lo, s29                             // 000000041E60: 8C7E1D7E
	s_and_b32 vcc_lo, exec_lo, s42                             // 000000041E64: 8B6A2A7E
	s_mov_b32 s3, -1                                           // 000000041E68: BE8300C1
	s_cbranch_vccz 80                                          // 000000041E6C: BFA30050 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x13b0>
	v_and_b32_e32 v2, -16, v44                                 // 000000041E70: 360458D0
	s_mov_b32 s3, exec_lo                                      // 000000041E74: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000041E78: BF870001
	v_cmpx_eq_u32_e32 64, v2                                   // 000000041E7C: 7D9404C0
	s_cbranch_execz 73                                         // 000000041E80: BFA50049 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x13a8>
	v_lshlrev_b32_e32 v4, 2, v44                               // 000000041E84: 30085882
	s_waitcnt lgkmcnt(0)                                       // 000000041E88: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000041E8C: BF870001
	v_add_nc_u32_e32 v5, 0x5c00, v4                            // 000000041E90: 4A0A08FF 00005C00
	ds_load_2addr_b32 v[2:3], v5 offset0:64 offset1:80         // 000000041E98: D8DC5040 02000005
	ds_load_b32 v6, v1 offset:24188                            // 000000041EA0: D8D85E7C 06000001
	s_waitcnt lgkmcnt(1)                                       // 000000041EA8: BF89FC17
	v_mul_f32_e32 v7, 0x3fb8aa3b, v3                           // 000000041EAC: 100E06FF 3FB8AA3B
	ds_load_b32 v8, v4 offset:24128                            // 000000041EB4: D8D85E40 08000004
	s_waitcnt lgkmcnt(1)                                       // 000000041EBC: BF89FC17
	v_sub_f32_e32 v6, v6, v3                                   // 000000041EC0: 080C0706
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000041EC4: 7C3606FF C2CE8ED0
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v7                          // 000000041ECC: D6130009 841E06FF 3FB8AA3B
	v_rndne_f32_e32 v10, v7                                    // 000000041ED8: 7E144707
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000041EDC: BF870114
	v_mul_f32_e32 v11, 0x3fb8aa3b, v6                          // 000000041EE0: 10160CFF 3FB8AA3B
	v_sub_f32_e32 v7, v7, v10                                  // 000000041EE8: 080E1507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000041EEC: BF8701C2
	v_fma_f32 v12, 0x3fb8aa3b, v6, -v11                        // 000000041EF0: D613000C 842E0CFF 3FB8AA3B
	v_fmac_f32_e32 v9, 0x32a5705f, v3                          // 000000041EFC: 561206FF 32A5705F
	v_cvt_i32_f32_e32 v10, v10                                 // 000000041F04: 7E14110A
	v_rndne_f32_e32 v13, v11                                   // 000000041F08: 7E1A470B
	v_dual_fmac_f32 v12, 0x32a5705f, v6 :: v_dual_add_f32 v7, v7, v9// 000000041F0C: C8080CFF 0C061307 32A5705F
	s_waitcnt lgkmcnt(0)                                       // 000000041F18: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000041F1C: BF870112
	v_dual_sub_f32 v9, v11, v13 :: v_dual_mul_f32 v2, v8, v2   // 000000041F20: C9461B0B 09020508
	v_exp_f32_e32 v7, v7                                       // 000000041F28: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000041F2C: BF870125
	.long 0xd71c0007                                           // 000000041F30: D71C0007
	v_cndmask_b32_e32 v1, v7, v10, vcc_lo                      // 000000041F34: 02021507
	v_cvt_i32_f32_e32 v10, v13                                 // 000000041F38: 7E14110D
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo                        // 000000041F3C: 020E0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000041F40: 7C3C06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000041F48: BF8701B2
	v_cndmask_b32_e32 v3, 0x7f800000, v7, vcc_lo               // 000000041F4C: 02060EFF 7F800000
	v_add_f32_e32 v9, v9, v12                                  // 000000041F54: 06121909
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v6                   // 000000041F58: 7C360CFF C2CE8ED0
	v_mul_f32_e32 v2, v3, v2                                   // 000000041F60: 10040503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041F64: BF870093
	v_exp_f32_e32 v9, v9                                       // 000000041F68: 7E124B09
	v_mul_f32_e32 v2, 0x41800000, v2                           // 000000041F6C: 100404FF 41800000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000041F74: BF870095
	.long 0xd71c0009                                           // 000000041F78: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000041F7C: 02021509
	v_cndmask_b32_e32 v7, 0, v9, vcc_lo                        // 000000041F80: 020E1280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v6                   // 000000041F84: 7C3C0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000041F8C: BF870002
	v_cndmask_b32_e32 v6, 0x7f800000, v7, vcc_lo               // 000000041F90: 020C0EFF 7F800000
	ds_store_b32 v4, v3 offset:24064                           // 000000041F98: D8345E00 00000304
	ds_store_2addr_b32 v5, v6, v2 offset0:96 offset1:112       // 000000041FA0: D8387060 00020605
	s_or_b32 exec_lo, exec_lo, s3                              // 000000041FA8: 8C7E037E
	s_mov_b32 s3, 0                                            // 000000041FAC: BE830080
	v_lshrrev_b32_e32 v154, 4, v43                             // 000000041FB0: 33345684
	v_mul_u32_u24_e32 v57, 0x110, v55                          // 000000041FB4: 16726EFF 00000110
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 000000041FBC: 916A037E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000041FC0: BF870002
	v_lshlrev_b32_e32 v56, 2, v154                             // 000000041FC4: 30713482
	s_cbranch_vccnz 871                                        // 000000041FC8: BFA40367 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2168>
	v_mad_u32_u24 v2, 0x110, v55, s49                          // 000000041FCC: D60B0002 00C66EFF 00000110
	s_and_b32 s3, s2, exec_lo                                  // 000000041FD8: 8B037E02
	s_cselect_b32 s3, 0, 0x1100                                // 000000041FDC: 9803FF80 00001100
	v_mad_u32_u24 v3, 0x110, v55, s50                          // 000000041FE4: D60B0003 00CA6EFF 00000110
	ds_load_b128 v[10:13], v57 offset:6144                     // 000000041FF0: DBFC1800 0A000039
	ds_load_b128 v[14:17], v57 offset:6160                     // 000000041FF8: DBFC1810 0E000039
	v_add_nc_u32_e32 v4, s3, v2                                // 000000042000: 4A080403
	v_mov_b32_e32 v8, v1                                       // 000000042004: 7E100301
	s_waitcnt lgkmcnt(0)                                       // 000000042008: BF89FC07
	v_mov_b32_e32 v5, v1                                       // 00000004200C: 7E0A0301
	v_cndmask_b32_e64 v45, v3, v2, s2                          // 000000042010: D501002D 000A0503
	v_mov_b32_e32 v3, v1                                       // 000000042018: 7E060301
	ds_load_b128 v[18:21], v4                                  // 00000004201C: DBFC0000 12000004
	ds_load_b128 v[22:25], v4 offset:16                        // 000000042024: DBFC0010 16000004
	ds_load_b128 v[26:29], v57 offset:6176                     // 00000004202C: DBFC1820 1A000039
	ds_load_b128 v[30:33], v57 offset:6192                     // 000000042034: DBFC1830 1E000039
	ds_load_b128 v[59:62], v45 offset:32                       // 00000004203C: DBFC0020 3B00002D
	ds_load_b128 v[63:66], v45 offset:48                       // 000000042044: DBFC0030 3F00002D
	ds_load_b128 v[155:158], v45 offset:64                     // 00000004204C: DBFC0040 9B00002D
	ds_load_b128 v[159:162], v45 offset:80                     // 000000042054: DBFC0050 9F00002D
	ds_load_b128 v[167:170], v57 offset:6224                   // 00000004205C: DBFC1850 A7000039
	ds_load_b128 v[163:166], v57 offset:6208                   // 000000042064: DBFC1840 A3000039
	v_mov_b32_e32 v2, v1                                       // 00000004206C: 7E040301
	v_mov_b32_e32 v4, v1                                       // 000000042070: 7E080301
	v_mov_b32_e32 v6, v1                                       // 000000042074: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000042078: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 00000004207C: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000042080: BF870212
	v_mov_b32_e32 v8, v7                                       // 000000042084: 7E100307
	v_mov_b32_e32 v7, v6                                       // 000000042088: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 00000004208C: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000042090: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000042094: 7E080303
	v_mov_b32_e32 v3, v2                                       // 000000042098: 7E060302
	v_mov_b32_e32 v2, v1                                       // 00000004209C: 7E040301
	ds_load_b128 v[175:178], v57 offset:6256                   // 0000000420A0: DBFC1870 AF000039
	ds_load_b128 v[171:174], v57 offset:6240                   // 0000000420A8: DBFC1860 AB000039
	ds_load_b128 v[183:186], v45 offset:112                    // 0000000420B0: DBFC0070 B700002D
	ds_load_b128 v[179:182], v45 offset:96                     // 0000000420B8: DBFC0060 B300002D
	v_or_b32_e32 v49, 6, v154                                  // 0000000420C0: 38633486
	v_or_b32_e32 v48, 8, v154                                  // 0000000420C4: 38613488
	v_or_b32_e32 v47, 10, v154                                 // 0000000420C8: 385F348A
	s_waitcnt lgkmcnt(12)                                      // 0000000420CC: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 0000000420D0: CC414002 1C0A1512
	ds_load_b128 v[14:17], v57 offset:6288                     // 0000000420D8: DBFC1890 0E000039
	ds_load_b128 v[10:13], v57 offset:6272                     // 0000000420E0: DBFC1880 0A000039
	ds_load_b128 v[22:25], v45 offset:144                      // 0000000420E8: DBFC0090 1600002D
	ds_load_b128 v[18:21], v45 offset:128                      // 0000000420F0: DBFC0080 1200002D
	s_and_not1_b32 vcc_lo, exec_lo, s41                        // 0000000420F8: 916A297E
	s_mov_b32 s3, -1                                           // 0000000420FC: BE8300C1
	s_waitcnt lgkmcnt(12)                                      // 000000042100: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[59:66], v[26:33], v[2:9]// 000000042104: CC414002 1C0A353B
	ds_load_b128 v[30:33], v57 offset:6320                     // 00000004210C: DBFC18B0 1E000039
	ds_load_b128 v[26:29], v57 offset:6304                     // 000000042114: DBFC18A0 1A000039
	ds_load_b128 v[65:68], v45 offset:176                      // 00000004211C: DBFC00B0 4100002D
	ds_load_b128 v[61:64], v45 offset:160                      // 000000042124: DBFC00A0 3D00002D
	v_lshlrev_b32_e32 v60, 2, v55                              // 00000004212C: 30786E82
	v_or_b32_e32 v59, 4, v154                                  // 000000042130: 38773484
	s_waitcnt lgkmcnt(12)                                      // 000000042134: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[155:162], v[163:170], v[2:9]// 000000042138: CC414002 1C0B479B
	ds_load_b128 v[159:162], v57 offset:6352                   // 000000042140: DBFC18D0 9F000039
	ds_load_b128 v[155:158], v57 offset:6336                   // 000000042148: DBFC18C0 9B000039
	v_add_nc_u32_e32 v46, 64, v60                              // 000000042150: 4A5C78C0
	ds_load_b128 v[167:170], v57 offset:6384                   // 000000042154: DBFC18F0 A7000039
	ds_load_b128 v[163:166], v57 offset:6368                   // 00000004215C: DBFC18E0 A3000039
	s_waitcnt lgkmcnt(12)                                      // 000000042164: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[179:186], v[171:178], v[2:9]// 000000042168: CC414002 1C0B57B3
	ds_load_b128 v[175:178], v45 offset:208                    // 000000042170: DBFC00D0 AF00002D
	ds_load_b128 v[171:174], v45 offset:192                    // 000000042178: DBFC00C0 AB00002D
	s_waitcnt lgkmcnt(10)                                      // 000000042180: BF89FCA7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 000000042184: CC414002 1C0A1512
	v_add_nc_u32_e32 v10, 0x5c00, v56                          // 00000004218C: 4A1470FF 00005C00
	v_add_nc_u32_e32 v11, s43, v56                             // 000000042194: 4A16702B
	ds_load_b128 v[183:186], v45 offset:240                    // 000000042198: DBFC00F0 B700002D
	ds_load_b128 v[179:182], v45 offset:224                    // 0000000421A0: DBFC00E0 B300002D
	ds_load_2addr_stride64_b32 v[12:13], v46 offset0:94 offset1:95// 0000000421A8: D8E05F5E 0C00002E
	v_or_b32_e32 v46, 12, v154                                 // 0000000421B0: 385D348C
	s_waitcnt lgkmcnt(9)                                       // 0000000421B4: BF89FC97
	v_wmma_f32_16x16x16_bf16 v[2:9], v[61:68], v[26:33], v[2:9]// 0000000421B8: CC414002 1C0A353D
	ds_load_2addr_b32 v[28:29], v10 offset0:144 offset1:146    // 0000000421C0: D8DC9290 1C00000A
	ds_load_2addr_b32 v[24:25], v10 offset0:148 offset1:150    // 0000000421C8: D8DC9694 1800000A
	ds_load_2addr_b32 v[20:21], v10 offset0:152 offset1:154    // 0000000421D0: D8DC9A98 1400000A
	ds_load_2addr_b32 v[16:17], v10 offset0:156 offset1:158    // 0000000421D8: D8DC9E9C 1000000A
	ds_load_2addr_b32 v[26:27], v11 offset1:2                  // 0000000421E0: D8DC0200 1A00000B
	ds_load_2addr_b32 v[22:23], v11 offset0:4 offset1:6        // 0000000421E8: D8DC0604 1600000B
	ds_load_2addr_b32 v[18:19], v11 offset0:8 offset1:10       // 0000000421F0: D8DC0A08 1200000B
	ds_load_2addr_b32 v[14:15], v11 offset0:12 offset1:14      // 0000000421F8: D8DC0E0C 0E00000B
	v_or_b32_e32 v61, 2, v154                                  // 000000042200: 387B3482
	v_or_b32_e32 v45, 14, v154                                 // 000000042204: 385B348E
	s_waitcnt lgkmcnt(11)                                      // 000000042208: BF89FCB7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[171:178], v[155:162], v[2:9]// 00000004220C: CC414002 1C0B37AB
	s_waitcnt lgkmcnt(9)                                       // 000000042214: BF89FC97
	s_delay_alu instid0(VALU_DEP_1)                            // 000000042218: BF870001
	v_wmma_f32_16x16x16_bf16 v[2:9], v[179:186], v[163:170], v[2:9]// 00000004221C: CC414002 1C0B47B3
	s_cbranch_vccnz 353                                        // 000000042224: BFA40161 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1bac>
	.long 0x7e143880                                           // 000000042228: 7E143880
	s_mov_b32 s3, exec_lo                                      // 00000004222C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000042230: BF870001
	.long 0x7f14390a                                           // 000000042234: 7F14390A
	.long 0xd4cb007e                                           // 000000042238: D4CB007E
	v_cndmask_b32_e32 v1, v55, v154, vcc_lo                    // 00000004223C: 02033537
	s_cbranch_execz 34                                         // 000000042240: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x16cc>
	s_waitcnt lgkmcnt(7)                                       // 000000042244: BF89FC77
	v_sub_f32_e32 v11, v28, v12                                // 000000042248: 0816191C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004224C: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v11                         // 000000042250: 103C16FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v11, -v30                       // 000000042258: D613001F 847A16FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 000000042264: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042268: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v11 :: v_dual_sub_f32 v30, v30, v32// 00000004226C: C80A16FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 000000042278: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 00000004227C: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000042280: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000042288: BF870293
	v_exp_f32_e32 v30, v30                                     // 00000004228C: 7E3C4B1E
	.long 0xd71c001e                                           // 000000042290: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 000000042294: 02023F1E
	s_waitcnt lgkmcnt(3)                                       // 000000042298: BF89FC37
	v_mul_f32_e32 v31, v2, v26                                 // 00000004229C: 103E3502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000422A0: BF870122
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 0000000422A4: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 0000000422A8: 7C3C16FF 42B17218
	v_dual_cndmask_b32 v11, 0x7f800000, v30 :: v_dual_mul_f32 v30, v13, v31// 0000000422B0: CA463CFF 0B1E3F0D 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000422BC: BF870091
	v_mul_f32_e32 v11, v11, v30                                // 0000000422C0: 10163D0B
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 0000000422C4: CC22000A 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000422CC: 8C7E037E
	v_mul_u32_u24_e32 v11, 48, v154                            // 0000000422D0: 161734B0
	s_mov_b32 s3, exec_lo                                      // 0000000422D4: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000422D8: BF870001
	v_lshl_add_u32 v11, v55, 1, v11                            // 0000000422DC: D646000B 042D0337
	ds_store_b16_d16_hi v11, v10 offset:23296                  // 0000000422E4: DA845B00 00000A0B
	.long 0xd4cb007e                                           // 0000000422EC: D4CB007E
	v_cndmask_b32_e32 v1, v55, v61, vcc_lo                     // 0000000422F0: 02027B37
	s_cbranch_execz 34                                         // 0000000422F4: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1780>
	s_waitcnt lgkmcnt(8)                                       // 0000000422F8: BF89FC87
	v_sub_f32_e32 v10, v29, v12                                // 0000000422FC: 0814191D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042300: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v10                         // 000000042304: 103C14FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v30                       // 00000004230C: D613001F 847A14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 000000042318: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004231C: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v10 :: v_dual_sub_f32 v30, v30, v32// 000000042320: C80A14FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 00000004232C: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 000000042330: 7E3E1120
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000042334: BF870292
	v_exp_f32_e32 v30, v30                                     // 000000042338: 7E3C4B1E
	.long 0xd71c001e                                           // 00000004233C: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 000000042340: 02023F1E
	s_waitcnt lgkmcnt(4)                                       // 000000042344: BF89FC47
	v_mul_f32_e32 v31, v3, v27                                 // 000000042348: 103E3703
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000004234C: 7C3614FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042354: BF870123
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 000000042358: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000004235C: 7C3C14FF 42B17218
	v_cndmask_b32_e32 v10, 0x7f800000, v30, vcc_lo             // 000000042364: 02143CFF 7F800000
	v_mul_f32_e32 v30, v13, v31                                // 00000004236C: 103C3F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042370: BF870091
	v_mul_f32_e32 v10, v10, v30                                // 000000042374: 10143D0A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 000000042378: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 000000042380: 8C7E037E
	.long 0x7f143880                                           // 000000042384: 7F143880
	v_or_b32_e32 v30, 0x5b00, v11                              // 000000042388: 383C16FF 00005B00
	s_mov_b32 s3, exec_lo                                      // 000000042390: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000042394: BF870002
	.long 0x7e16398a                                           // 000000042398: 7E16398A
	ds_store_b16 v30, v10 offset:96                            // 00000004239C: D87C0060 00000A1E
	.long 0xd4cb007e                                           // 0000000423A4: D4CB007E
	v_cndmask_b32_e32 v1, v55, v59, vcc_lo                     // 0000000423A8: 02027737
	s_cbranch_execz 35                                         // 0000000423AC: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x183c>
	s_waitcnt lgkmcnt(8)                                       // 0000000423B0: BF89FC87
	v_sub_f32_e32 v11, v24, v12                                // 0000000423B4: 08161918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000423B8: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 0000000423BC: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 0000000423C4: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 0000000423CC: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 0000000423D8: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000423DC: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 0000000423E0: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 0000000423EC: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 0000000423F0: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000423F4: BF870292
	v_exp_f32_e32 v31, v31                                     // 0000000423F8: 7E3E4B1F
	.long 0xd71c001f                                           // 0000000423FC: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000042400: 0202411F
	s_waitcnt lgkmcnt(4)                                       // 000000042404: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042408: BF870121
	v_dual_mul_f32 v32, v4, v22 :: v_dual_cndmask_b32 v31, 0, v31// 00000004240C: C8D22D04 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000042414: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000004241C: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042424: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 000000042428: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 00000004242C: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000042430: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 000000042434: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004243C: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000042440: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000042444: BE83007E
	ds_store_b16 v30, v11 offset:192                           // 000000042448: D87C00C0 00000B1E
	.long 0xd4cb007e                                           // 000000042450: D4CB007E
	v_cndmask_b32_e32 v1, v55, v49, vcc_lo                     // 000000042454: 02026337
	s_cbranch_execz 35                                         // 000000042458: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x18e8>
	s_waitcnt lgkmcnt(9)                                       // 00000004245C: BF89FC97
	v_sub_f32_e32 v10, v25, v12                                // 000000042460: 08141919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042464: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 000000042468: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000042470: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 00000004247C: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000042480: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000042484: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 00000004248C: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000042490: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000042494: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 000000042498: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000004249C: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 0000000424A4: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000424A8: BF870135
	.long 0xd71c000b                                           // 0000000424AC: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 0000000424B0: 02023F0B
	s_waitcnt lgkmcnt(5)                                       // 0000000424B4: BF89FC57
	v_mul_f32_e32 v31, v5, v23                                 // 0000000424B8: 103E2F05
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 0000000424BC: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 0000000424C0: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000424C8: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 0000000424CC: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 0000000424D4: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000424D8: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 0000000424DC: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 0000000424E0: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000424E8: 8C7E037E
	.long 0x7e143880                                           // 0000000424EC: 7E143880
	s_mov_b32 s3, exec_lo                                      // 0000000424F0: BE83007E
	ds_store_b16_d16_hi v30, v10 offset:288                    // 0000000424F4: DA840120 00000A1E
	.long 0x7e16390a                                           // 0000000424FC: 7E16390A
	.long 0xd4cb007e                                           // 000000042500: D4CB007E
	v_cndmask_b32_e32 v1, v55, v48, vcc_lo                     // 000000042504: 02026137
	s_cbranch_execz 34                                         // 000000042508: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1994>
	s_waitcnt lgkmcnt(9)                                       // 00000004250C: BF89FC97
	v_sub_f32_e32 v11, v20, v12                                // 000000042510: 08161914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042514: BF870091
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000042518: 103E16FF 3FB8AA3B
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000042520: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000004252C: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042530: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000042534: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000042540: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000042544: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000042548: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000004254C: 7E3E4B1F
	.long 0xd71c001f                                           // 000000042550: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000042554: 0202411F
	s_waitcnt lgkmcnt(5)                                       // 000000042558: BF89FC57
	v_mul_f32_e32 v32, v6, v18                                 // 00000004255C: 10402506
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000042560: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042568: BF870123
	v_cndmask_b32_e32 v31, 0, v31, vcc_lo                      // 00000004256C: 023E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000042570: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000042578: 02163EFF 7F800000
	v_mul_f32_e32 v31, v13, v32                                // 000000042580: 103E410D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042584: BF870091
	v_mul_f32_e32 v11, v11, v31                                // 000000042588: 10163F0B
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 00000004258C: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000042594: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000042598: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000004259C: BE83007E
	ds_store_b16 v30, v11 offset:384                           // 0000000425A0: D87C0180 00000B1E
	.long 0xd4cb007e                                           // 0000000425A8: D4CB007E
	v_cndmask_b32_e32 v1, v55, v47, vcc_lo                     // 0000000425AC: 02025F37
	s_cbranch_execz 35                                         // 0000000425B0: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1a40>
	s_waitcnt lgkmcnt(10)                                      // 0000000425B4: BF89FCA7
	v_sub_f32_e32 v10, v21, v12                                // 0000000425B8: 08141915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000425BC: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 0000000425C0: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 0000000425C8: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 0000000425D4: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000425D8: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 0000000425DC: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 0000000425E4: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000425E8: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 0000000425EC: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 0000000425F0: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 0000000425F4: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 0000000425FC: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000042600: BF870135
	.long 0xd71c000b                                           // 000000042604: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000042608: 02023F0B
	s_waitcnt lgkmcnt(6)                                       // 00000004260C: BF89FC67
	v_mul_f32_e32 v31, v7, v19                                 // 000000042610: 103E2707
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000042614: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000042618: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000042620: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000042624: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000004262C: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042630: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000042634: 1014170A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 000000042638: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 000000042640: 8C7E037E
	.long 0x7f143880                                           // 000000042644: 7F143880
	s_mov_b32 s3, exec_lo                                      // 000000042648: BE83007E
	ds_store_b16 v30, v10 offset:480                           // 00000004264C: D87C01E0 00000A1E
	.long 0x7e16398a                                           // 000000042654: 7E16398A
	.long 0xd4cb007e                                           // 000000042658: D4CB007E
	v_cndmask_b32_e32 v1, v55, v46, vcc_lo                     // 00000004265C: 02025D37
	s_cbranch_execz 35                                         // 000000042660: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1af0>
	s_waitcnt lgkmcnt(10)                                      // 000000042664: BF89FCA7
	v_sub_f32_e32 v11, v16, v12                                // 000000042668: 08161910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004266C: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000042670: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000042678: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000042680: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000004268C: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042690: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000042694: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 0000000426A0: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 0000000426A4: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000426A8: BF870292
	v_exp_f32_e32 v31, v31                                     // 0000000426AC: 7E3E4B1F
	.long 0xd71c001f                                           // 0000000426B0: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000000426B4: 0202411F
	s_waitcnt lgkmcnt(6)                                       // 0000000426B8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000426BC: BF870121
	v_dual_mul_f32 v32, v8, v14 :: v_dual_cndmask_b32 v31, 0, v31// 0000000426C0: C8D21D08 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 0000000426C8: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 0000000426D0: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000426D8: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 0000000426DC: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 0000000426E0: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000426E4: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 0000000426E8: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000426F0: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000426F4: BF870009
	s_mov_b32 s3, exec_lo                                      // 0000000426F8: BE83007E
	ds_store_b16 v30, v11 offset:576                           // 0000000426FC: D87C0240 00000B1E
	.long 0xd4cb007e                                           // 000000042704: D4CB007E
	v_cndmask_b32_e32 v1, v55, v45, vcc_lo                     // 000000042708: 02025B37
	s_cbranch_execz 35                                         // 00000004270C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b9c>
	s_waitcnt lgkmcnt(11)                                      // 000000042710: BF89FCB7
	v_sub_f32_e32 v10, v17, v12                                // 000000042714: 08141911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042718: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000004271C: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000042724: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000042730: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000042734: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000042738: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000042740: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000042744: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000042748: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000004274C: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000042750: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 000000042758: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000004275C: BF870135
	.long 0xd71c000b                                           // 000000042760: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000042764: 02023F0B
	s_waitcnt lgkmcnt(7)                                       // 000000042768: BF89FC77
	v_mul_f32_e32 v31, v9, v15                                 // 00000004276C: 103E1F09
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000042770: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000042774: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000004277C: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000042780: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 000000042788: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004278C: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000042790: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 000000042794: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000004279C: 8C7E037E
	s_mov_b32 s3, 0                                            // 0000000427A0: BE830080
	ds_store_b16_d16_hi v30, v10 offset:672                    // 0000000427A4: DA8402A0 00000A1E
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000000427AC: 8B6A037E
	s_cbranch_vccz 365                                         // 0000000427B0: BFA3016D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2168>
	v_or_b32_e32 v10, 0x5e40, v56                              // 0000000427B4: 381470FF 00005E40
	v_mov_b32_e32 v63, 0                                       // 0000000427BC: 7E7E0280
	v_mov_b32_e32 v65, 0                                       // 0000000427C0: 7E820280
	s_mov_b32 s3, exec_lo                                      // 0000000427C4: BE83007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000427C8: BF870003
	v_subrev_nc_u32_e32 v64, 64, v10                           // 0000000427CC: 4E8014C0
	ds_load_2addr_b32 v[32:33], v64 offset0:2 offset1:4        // 0000000427D0: D8DC0402 20000040
	ds_load_2addr_b32 v[30:31], v64 offset0:6 offset1:8        // 0000000427D8: D8DC0806 1E000040
	ds_load_2addr_b32 v[10:11], v64 offset0:10 offset1:12      // 0000000427E0: D8DC0C0A 0A000040
	ds_load_b32 v62, v64 offset:56                             // 0000000427E8: D8D80038 3E000040
	.long 0xd4c9007e                                           // 0000000427F0: D4C9007E
	v_cndmask_b32_e32 v1, v55, v154, vcc_lo                    // 0000000427F4: 02033537
	s_cbranch_execz 37                                         // 0000000427F8: BFA50025 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1c90>
	s_waitcnt lgkmcnt(11)                                      // 0000000427FC: BF89FCB7
	v_sub_f32_e32 v28, v28, v12                                // 000000042800: 0838191C
	ds_load_b32 v64, v64                                       // 000000042804: D8D80000 40000040
	s_waitcnt lgkmcnt(8)                                       // 00000004280C: BF89FC87
	v_dual_mul_f32 v2, v2, v26 :: v_dual_mul_f32 v65, 0x3fb8aa3b, v28// 000000042810: C8C63502 024038FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000004281C: BF870111
	v_mul_f32_e32 v2, v13, v2                                  // 000000042820: 1004050D
	v_fma_f32 v66, 0x3fb8aa3b, v28, -v65                       // 000000042824: D6130042 850638FF 3FB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 000000042830: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000042834: BF8701C1
	v_dual_sub_f32 v65, v65, v67 :: v_dual_fmac_f32 v66, 0x32a5705f, v28// 000000042838: C9408741 414238FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v28                  // 000000042844: 7C3638FF C2CE8ED0
	s_waitcnt lgkmcnt(0)                                       // 00000004284C: BF89FC07
	v_mul_f32_e32 v2, v64, v2                                  // 000000042850: 10040540
	v_add_f32_e32 v65, v65, v66                                // 000000042854: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000042858: 7E841143
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004285C: BF870292
	v_exp_f32_e32 v65, v65                                     // 000000042860: 7E824B41
	.long 0xd71c0041                                           // 000000042864: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000042868: 02028541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004286C: BF870121
	v_cndmask_b32_e32 v26, 0, v65, vcc_lo                      // 000000042870: 02348280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v28                  // 000000042874: 7C3C38FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 00000004287C: 023434FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000042884: BF870001
	.long 0xd5080041                                           // 000000042888: D5080041
	v_sub_co_ci_u32_e32 v1, vcc_lo, v2, v26, vcc_lo            // 00000004288C: 42023502
	s_or_b32 exec_lo, exec_lo, s3                              // 000000042890: 8C7E037E
	v_or_b32_e32 v2, 0x5e40, v60                               // 000000042894: 380478FF 00005E40
	s_waitcnt lgkmcnt(7)                                       // 00000004289C: BF89FC77
	v_lshlrev_b32_e32 v26, 6, v154                             // 0000000428A0: 30353486
	s_mov_b32 s3, exec_lo                                      // 0000000428A4: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000428A8: BF870001
	v_add3_u32 v2, v2, v26, 0xfffff8c0                         // 0000000428AC: D6550002 03FE3502 FFFFF8C0
	ds_store_b32 v2, v65                                       // 0000000428B8: D8340000 00004102
	.long 0xd4c9007e                                           // 0000000428C0: D4C9007E
	v_cndmask_b32_e32 v1, v55, v61, vcc_lo                     // 0000000428C4: 02027B37
	s_cbranch_execz 33                                         // 0000000428C8: BFA50021 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1d50>
	v_dual_sub_f32 v26, v29, v12 :: v_dual_mul_f32 v3, v3, v27 // 0000000428CC: C946191D 1A023703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000428D4: BF870121
	v_dual_mul_f32 v28, 0x3fb8aa3b, v26 :: v_dual_mul_f32 v3, v13, v3// 0000000428D8: C8C634FF 1C02070D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v26                  // 0000000428E4: 7C3634FF C2CE8ED0
	v_fma_f32 v29, 0x3fb8aa3b, v26, -v28                       // 0000000428EC: D613001D 847234FF 3FB8AA3B
	v_rndne_f32_e32 v60, v28                                   // 0000000428F8: 7E78471C
	s_waitcnt lgkmcnt(4)                                       // 0000000428FC: BF89FC47
	v_mul_f32_e32 v3, v32, v3                                  // 000000042900: 10060720
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042904: BF870092
	v_dual_fmac_f32 v29, 0x32a5705f, v26 :: v_dual_sub_f32 v28, v28, v60// 000000042908: C80A34FF 1D1C791C 32A5705F
	v_add_f32_e32 v28, v28, v29                                // 000000042914: 06383B1C
	v_cvt_i32_f32_e32 v29, v60                                 // 000000042918: 7E3A113C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000004291C: BF870292
	v_exp_f32_e32 v28, v28                                     // 000000042920: 7E384B1C
	.long 0xd71c001c                                           // 000000042924: D71C001C
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                     // 000000042928: 02023B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000004292C: BF870121
	v_cndmask_b32_e32 v27, 0, v28, vcc_lo                      // 000000042930: 02363880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v26                  // 000000042934: 7C3C34FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v27, vcc_lo             // 00000004293C: 023436FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000042944: BF870001
	.long 0xd508003f                                           // 000000042948: D508003F
	v_sub_co_ci_u32_e32 v1, vcc_lo, v3, v26, vcc_lo            // 00000004294C: 42023503
	s_or_b32 exec_lo, exec_lo, s3                              // 000000042950: 8C7E037E
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v26, 0              // 000000042954: CA100080 031A0080
	s_mov_b32 s3, exec_lo                                      // 00000004295C: BE83007E
	ds_store_b32 v2, v63 offset:128                            // 000000042960: D8340080 00003F02
	.long 0xd4c9007e                                           // 000000042968: D4C9007E
	v_cndmask_b32_e32 v1, v55, v59, vcc_lo                     // 00000004296C: 02027737
	s_cbranch_execz 35                                         // 000000042970: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1e00>
	v_sub_f32_e32 v24, v24, v12                                // 000000042974: 08301918
	s_waitcnt lgkmcnt(8)                                       // 000000042978: BF89FC87
	v_mul_f32_e32 v4, v4, v22                                  // 00000004297C: 10082D04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000042980: BF8701A2
	v_mul_f32_e32 v26, 0x3fb8aa3b, v24                         // 000000042984: 103430FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v24                  // 00000004298C: 7C3630FF C2CE8ED0
	v_mul_f32_e32 v4, v13, v4                                  // 000000042994: 1008090D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000042998: BF8701B3
	v_fma_f32 v27, 0x3fb8aa3b, v24, -v26                       // 00000004299C: D613001B 846A30FF 3FB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000429A8: 7E38471A
	s_waitcnt lgkmcnt(5)                                       // 0000000429AC: BF89FC57
	v_mul_f32_e32 v4, v33, v4                                  // 0000000429B0: 10080921
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000429B4: BF870193
	v_fmac_f32_e32 v27, 0x32a5705f, v24                        // 0000000429B8: 563630FF 32A5705F
	v_sub_f32_e32 v26, v26, v28                                // 0000000429C0: 0834391A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000429C4: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000429C8: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000429CC: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000429D0: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000429D4: BF870095
	.long 0xd71c001a                                           // 0000000429D8: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000429DC: 0202371A
	v_cndmask_b32_e32 v22, 0, v26, vcc_lo                      // 0000000429E0: 022C3480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v24                  // 0000000429E4: 7C3C30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000429EC: BF870092
	v_cndmask_b32_e32 v22, 0x7f800000, v22, vcc_lo             // 0000000429F0: 022C2CFF 7F800000
	.long 0xd508001a                                           // 0000000429F8: D508001A
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v22, vcc_lo            // 0000000429FC: 42022D04
	s_or_b32 exec_lo, exec_lo, s3                              // 000000042A00: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000042A04: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000042A08: BE83007E
	ds_store_b32 v2, v26 offset:256                            // 000000042A0C: D8340100 00001A02
	.long 0xd4c9007e                                           // 000000042A14: D4C9007E
	v_cndmask_b32_e32 v1, v55, v49, vcc_lo                     // 000000042A18: 02026337
	s_cbranch_execz 34                                         // 000000042A1C: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1ea8>
	v_sub_f32_e32 v3, v25, v12                                 // 000000042A20: 08061919
	s_waitcnt lgkmcnt(9)                                       // 000000042A24: BF89FC97
	v_mul_f32_e32 v5, v5, v23                                  // 000000042A28: 100A2F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042A2C: BF870091
	v_dual_mul_f32 v4, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, v13, v5// 000000042A30: C8C606FF 04040B0D 3FB8AA3B
	v_fma_f32 v22, 0x3fb8aa3b, v3, -v4                         // 000000042A3C: D6130016 841206FF 3FB8AA3B
	v_rndne_f32_e32 v24, v4                                    // 000000042A48: 7E304704
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000042A4C: BF870112
	v_fmac_f32_e32 v22, 0x32a5705f, v3                         // 000000042A50: 562C06FF 32A5705F
	v_sub_f32_e32 v4, v4, v24                                  // 000000042A58: 08083104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000042A5C: BF8701B1
	v_add_f32_e32 v4, v4, v22                                  // 000000042A60: 06082D04
	v_cvt_i32_f32_e32 v22, v24                                 // 000000042A64: 7E2C1118
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000042A68: 7C3606FF C2CE8ED0
	v_exp_f32_e32 v4, v4                                       // 000000042A70: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042A74: BF870095
	.long 0xd71c0004                                           // 000000042A78: D71C0004
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 000000042A7C: 02022D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 000000042A80: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000042A84: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(5)                                       // 000000042A8C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042A90: BF870092
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v30, v5// 000000042A94: CA4608FF 03040B1E 7F800000
	.long 0xd5080003                                           // 000000042AA0: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 000000042AA4: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 000000042AA8: 8C7E037E
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 000000042AAC: CA100080 04040080
	s_mov_b32 s3, exec_lo                                      // 000000042AB4: BE83007E
	ds_store_b32 v2, v3 offset:384                             // 000000042AB8: D8340180 00000302
	.long 0xd4c9007e                                           // 000000042AC0: D4C9007E
	v_cndmask_b32_e32 v1, v55, v48, vcc_lo                     // 000000042AC4: 02026137
	s_cbranch_execz 34                                         // 000000042AC8: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1f54>
	s_waitcnt lgkmcnt(9)                                       // 000000042ACC: BF89FC97
	v_dual_sub_f32 v3, v20, v12 :: v_dual_mul_f32 v6, v6, v18  // 000000042AD0: C9461914 03062506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042AD8: BF870121
	v_dual_mul_f32 v5, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v6, v13, v6// 000000042ADC: C8C606FF 05060D0D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000042AE8: 7C3606FF C2CE8ED0
	v_fma_f32 v20, 0x3fb8aa3b, v3, -v5                         // 000000042AF0: D6130014 841606FF 3FB8AA3B
	v_rndne_f32_e32 v22, v5                                    // 000000042AFC: 7E2C4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042B00: BF870091
	v_dual_fmac_f32 v20, 0x32a5705f, v3 :: v_dual_sub_f32 v5, v5, v22// 000000042B04: C80A06FF 14042D05 32A5705F
	v_add_f32_e32 v5, v5, v20                                  // 000000042B10: 060A2905
	v_cvt_i32_f32_e32 v20, v22                                 // 000000042B14: 7E281116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000042B18: BF870292
	v_exp_f32_e32 v5, v5                                       // 000000042B1C: 7E0A4B05
	.long 0xd71c0005                                           // 000000042B20: D71C0005
	v_cndmask_b32_e32 v1, v5, v20, vcc_lo                      // 000000042B24: 02022905
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042B28: BF870121
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo                        // 000000042B2C: 020A0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000042B30: 7C3C06FF 42B17218
	v_cndmask_b32_e32 v3, 0x7f800000, v5, vcc_lo               // 000000042B38: 02060AFF 7F800000
	s_waitcnt lgkmcnt(6)                                       // 000000042B40: BF89FC67
	v_mul_f32_e32 v5, v31, v6                                  // 000000042B44: 100A0D1F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000042B48: BF870001
	.long 0xd5080005                                           // 000000042B4C: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v3, vcc_lo             // 000000042B50: 42020705
	s_or_b32 exec_lo, exec_lo, s3                              // 000000042B54: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000042B58: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000042B5C: BE83007E
	ds_store_b32 v2, v5 offset:512                             // 000000042B60: D8340200 00000502
	.long 0xd4c9007e                                           // 000000042B68: D4C9007E
	v_cndmask_b32_e32 v1, v55, v47, vcc_lo                     // 000000042B6C: 02025F37
	s_cbranch_execz 35                                         // 000000042B70: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2000>
	v_sub_f32_e32 v3, v21, v12                                 // 000000042B74: 08061915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042B78: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 000000042B7C: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 000000042B84: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 000000042B90: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000042B94: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 000000042B98: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000042B9C: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 000000042BA4: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042BAC: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 000000042BB0: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 000000042BB4: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 000000042BB8: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000042BBC: BF8700A5
	.long 0xd71c0004                                           // 000000042BC0: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 000000042BC4: 02020B04
	s_waitcnt lgkmcnt(10)                                      // 000000042BC8: BF89FCA7
	v_dual_mul_f32 v5, v7, v19 :: v_dual_cndmask_b32 v4, 0, v4 // 000000042BCC: C8D22707 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000042BD4: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 000000042BD8: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000042BDC: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(6)                                       // 000000042BE4: BF89FC67
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v10, v5// 000000042BE8: CA4608FF 03040B0A 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000042BF4: BF870001
	.long 0xd5080004                                           // 000000042BF8: D5080004
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 000000042BFC: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 000000042C00: 8C7E037E
	v_mov_b32_e32 v3, 0                                        // 000000042C04: 7E060280
	v_mov_b32_e32 v5, 0                                        // 000000042C08: 7E0A0280
	s_mov_b32 s3, exec_lo                                      // 000000042C0C: BE83007E
	ds_store_b32 v2, v4 offset:640                             // 000000042C10: D8340280 00000402
	.long 0xd4c9007e                                           // 000000042C18: D4C9007E
	v_cndmask_b32_e32 v1, v55, v46, vcc_lo                     // 000000042C1C: 02025D37
	s_cbranch_execz 35                                         // 000000042C20: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x20b0>
	v_sub_f32_e32 v4, v16, v12                                 // 000000042C24: 08081910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042C28: BF870091
	v_mul_f32_e32 v5, 0x3fb8aa3b, v4                           // 000000042C2C: 100A08FF 3FB8AA3B
	v_fma_f32 v6, 0x3fb8aa3b, v4, -v5                          // 000000042C34: D6130006 841608FF 3FB8AA3B
	v_rndne_f32_e32 v7, v5                                     // 000000042C40: 7E0E4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000042C44: BF870221
	v_sub_f32_e32 v5, v5, v7                                   // 000000042C48: 080A0F05
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 000000042C4C: 7C3608FF C2CE8ED0
	v_fmac_f32_e32 v6, 0x32a5705f, v4                          // 000000042C54: 560C08FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042C5C: BF870121
	v_add_f32_e32 v5, v5, v6                                   // 000000042C60: 060A0D05
	v_cvt_i32_f32_e32 v6, v7                                   // 000000042C64: 7E0C1107
	v_exp_f32_e32 v5, v5                                       // 000000042C68: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000042C6C: BF8700A5
	.long 0xd71c0005                                           // 000000042C70: D71C0005
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 000000042C74: 02020D05
	s_waitcnt lgkmcnt(10)                                      // 000000042C78: BF89FCA7
	v_dual_mul_f32 v6, v8, v14 :: v_dual_cndmask_b32 v5, 0, v5 // 000000042C7C: C8D21D08 06040A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000042C84: BF870131
	v_mul_f32_e32 v6, v13, v6                                  // 000000042C88: 100C0D0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 000000042C8C: 7C3C08FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 000000042C94: BF89FC77
	v_dual_cndmask_b32 v4, 0x7f800000, v5 :: v_dual_mul_f32 v5, v11, v6// 000000042C98: CA460AFF 04040D0B 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000042CA4: BF870001
	.long 0xd5080005                                           // 000000042CA8: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v4, vcc_lo             // 000000042CAC: 42020905
	s_or_b32 exec_lo, exec_lo, s3                              // 000000042CB0: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000042CB4: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000042CB8: BE83007E
	ds_store_b32 v2, v5 offset:768                             // 000000042CBC: D8340300 00000502
	.long 0xd4c9007e                                           // 000000042CC4: D4C9007E
	v_cndmask_b32_e32 v1, v55, v45, vcc_lo                     // 000000042CC8: 02025B37
	s_cbranch_execz 35                                         // 000000042CCC: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x215c>
	v_sub_f32_e32 v3, v17, v12                                 // 000000042CD0: 08061911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042CD4: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 000000042CD8: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 000000042CE0: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 000000042CEC: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000042CF0: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 000000042CF4: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000042CF8: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 000000042D00: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042D08: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 000000042D0C: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 000000042D10: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 000000042D14: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000042D18: BF8700A5
	.long 0xd71c0004                                           // 000000042D1C: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 000000042D20: 02020B04
	s_waitcnt lgkmcnt(11)                                      // 000000042D24: BF89FCB7
	v_dual_mul_f32 v5, v9, v15 :: v_dual_cndmask_b32 v4, 0, v4 // 000000042D28: C8D21F09 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000042D30: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 000000042D34: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000042D38: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 000000042D40: BF89FC77
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v62, v5// 000000042D44: CA4608FF 03040B3E 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000042D50: BF870001
	.long 0xd5080003                                           // 000000042D54: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 000000042D58: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 000000042D5C: 8C7E037E
	ds_store_b32 v2, v3 offset:896                             // 000000042D60: D8340380 00000302
	s_waitcnt lgkmcnt(0)                                       // 000000042D68: BF89FC07
	s_barrier                                                  // 000000042D6C: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s41                             // 000000042D70: 8B6A297E
	s_mov_b32 s3, -1                                           // 000000042D74: BE8300C1
	s_cbranch_vccz 175                                         // 000000042D78: BFA300AF <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2438>
	s_mov_b32 s3, exec_lo                                      // 000000042D7C: BE83007E
	v_cmpx_gt_i32_e32 0x120, v44                               // 000000042D80: 7D8858FF 00000120
	s_cbranch_execz 169                                        // 000000042D88: BFA500A9 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2430>
	v_add_nc_u32_e32 v2, 0xffffff00, v44                       // 000000042D8C: 4A0458FF FFFFFF00
	s_mov_b32 s4, 0                                            // 000000042D94: BE840080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000042D98: BF870001
	v_mov_b32_e32 v3, v2                                       // 000000042D9C: 7E060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000042DA0: BF8700A1
	v_add_nc_u32_e32 v3, 0xe0, v3                              // 000000042DA4: 4A0606FF 000000E0
	s_waitcnt lgkmcnt(0)                                       // 000000042DAC: BF89FC07
	v_ashrrev_i32_e32 v16, 7, v3                               // 000000042DB0: 34200687
	v_and_b32_e32 v12, 0x7f, v3                                // 000000042DB4: 361806FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042DBC: BF870092
	.long 0xd72c0004                                           // 000000042DC0: D72C0004
	v_cndmask_b32_e32 v1, 0x880, v16, vcc_lo                   // 000000042DC4: 020220FF 00000880
	v_lshl_add_u32 v4, v12, 1, v4                              // 000000042DCC: D6460004 0411030C
	ds_load_u16 v20, v4 offset:7776                            // 000000042DD4: D8F01E60 14000004
	ds_load_u16 v21, v4 offset:7232                            // 000000042DDC: D8F01C40 15000004
	ds_load_u16 v22, v4 offset:6688                            // 000000042DE4: D8F01A20 16000004
	ds_load_u16 v23, v4 offset:6144                            // 000000042DEC: D8F01800 17000004
	ds_load_u16 v24, v4 offset:6416                            // 000000042DF4: D8F01910 18000004
	s_waitcnt lgkmcnt(3)                                       // 000000042DFC: BF89FC37
	v_lshlrev_b32_e32 v21, 16, v21                             // 000000042E00: 302A2A90
	s_waitcnt lgkmcnt(1)                                       // 000000042E04: BF89FC17
	v_lshlrev_b32_e32 v23, 16, v23                             // 000000042E08: 302E2E90
	v_lshlrev_b32_e32 v17, 5, v16                              // 000000042E0C: 30222085
	ds_load_u16 v25, v4 offset:6960                            // 000000042E10: D8F01B30 19000004
	ds_load_u16 v26, v4 offset:7504                            // 000000042E18: D8F01D50 1A000004
	ds_load_u16 v27, v4 offset:8048                            // 000000042E20: D8F01F70 1B000004
	ds_load_b128 v[4:7], v17 offset:24384                      // 000000042E28: DBFC5F40 04000011
	ds_load_b128 v[8:11], v17 offset:24400                     // 000000042E30: DBFC5F50 08000011
	v_lshlrev_b32_e32 v20, 16, v20                             // 000000042E38: 30282890
	s_waitcnt lgkmcnt(0)                                       // 000000042E3C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000042E40: BF870091
	v_dual_mul_f32 v10, v10, v20 :: v_dual_lshlrev_b32 v25, 16, v25// 000000042E44: C8E2290A 0A183290
	v_dual_mul_f32 v7, v7, v25 :: v_dual_lshlrev_b32 v24, 16, v24// 000000042E4C: C8E23307 07183090
	v_mul_f32_e32 v8, v8, v21                                  // 000000042E54: 10102B08
	s_delay_alu instid0(VALU_DEP_2)                            // 000000042E58: BF870002
	v_dual_mul_f32 v4, v4, v23 :: v_dual_mul_f32 v5, v5, v24   // 000000042E5C: C8C62F04 04043105
	v_mul_u32_u24_e32 v18, 48, v12                             // 000000042E64: 162418B0
	ds_load_b128 v[12:15], v17 offset:24192                    // 000000042E68: DBFC5E80 0C000011
	v_lshlrev_b32_e32 v26, 16, v26                             // 000000042E70: 30343490
	v_lshlrev_b32_e32 v27, 16, v27                             // 000000042E74: 30363690
	v_lshl_add_u32 v28, v16, 4, v18                            // 000000042E78: D646001C 04490910
	ds_load_b128 v[16:19], v17 offset:24208                    // 000000042E80: DBFC5E90 10000011
	s_waitcnt lgkmcnt(1)                                       // 000000042E88: BF89FC17
	v_mul_f32_e32 v12, v12, v4                                 // 000000042E8C: 1018090C
	v_mul_f32_e32 v4, v13, v5                                  // 000000042E90: 10080B0D
	v_dual_mul_f32 v11, v11, v27 :: v_dual_lshlrev_b32 v22, 16, v22// 000000042E94: C8E2370B 0B162C90
	v_mul_f32_e32 v5, v15, v7                                  // 000000042E9C: 100A0F0F
	v_mul_f32_e32 v9, v9, v26                                  // 000000042EA0: 10123509
	s_waitcnt lgkmcnt(0)                                       // 000000042EA4: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000042EA8: BF870243
	v_dual_mul_f32 v7, v16, v8 :: v_dual_mul_f32 v6, v6, v22   // 000000042EAC: C8C61110 07062D06
	v_cmp_lt_i32_e32 vcc_lo, 31, v3                            // 000000042EB4: 7C82069F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 000000042EB8: CC220004 02006104
	v_dual_mul_f32 v8, v17, v9 :: v_dual_mul_f32 v9, v18, v10  // 000000042EC0: C8C61311 08081512
	v_mul_f32_e32 v6, v14, v6                                  // 000000042EC8: 100C0D0E
	v_mul_f32_e32 v10, v19, v11                                // 000000042ECC: 10141713
	v_fma_mixlo_f16 v4, v12, s48, 0                            // 000000042ED0: CC210004 0200610C
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 000000042ED8: CC220005 02006105
	s_or_b32 s4, vcc_lo, s4                                    // 000000042EE0: 8C04046A
	v_fma_mixlo_f16 v5, v6, s48, 0                             // 000000042EE4: CC210005 02006106
	v_fma_mixhi_f16 v6, v8, s48, 0                             // 000000042EEC: CC220006 02006108
	v_fma_mixlo_f16 v6, v7, s48, 0                             // 000000042EF4: CC210006 02006107
	v_fma_mixhi_f16 v7, v10, s48, 0                            // 000000042EFC: CC220007 0200610A
	v_fma_mixlo_f16 v7, v9, s48, 0                             // 000000042F04: CC210007 02006109
	ds_store_b128 v28, v[4:7]                                  // 000000042F0C: DB7C0000 0000041C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000042F14: 917E047E
	s_cbranch_execnz 65441                                     // 000000042F18: BFA6FFA1 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x21a0>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000042F1C: 8C7E047E
	v_lshl_add_u32 v3, v44, 3, 0xffffff00                      // 000000042F20: D6460003 03FD072C FFFFFF00
	s_mov_b32 s4, 0                                            // 000000042F2C: BE840080
	v_add_nc_u32_e32 v2, 0xe0, v2                              // 000000042F30: 4A0404FF 000000E0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000042F38: BF8701A2
	v_and_b32_e32 v4, 0x78, v3                                 // 000000042F3C: 360806FF 00000078
	v_add_nc_u32_e32 v3, 0x700, v3                             // 000000042F44: 4A0606FF 00000700
	v_ashrrev_i32_e32 v5, 4, v2                                // 000000042F4C: 340A0484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000042F50: BF870121
	.long 0xd72c0006                                           // 000000042F54: D72C0006
	v_cndmask_b32_e32 v1, 0x110, v5, vcc_lo                    // 000000042F58: 02020AFF 00000110
	v_lshlrev_b32_e32 v8, 2, v5                                // 000000042F60: 30100A82
	v_lshl_add_u32 v9, v4, 1, v6                               // 000000042F64: D6460009 04190304
	ds_load_b128 v[4:7], v9 offset:10496                       // 000000042F6C: DBFC2900 04000009
	ds_load_b32 v8, v8 offset:24448                            // 000000042F74: D8D85F80 08000008
	s_waitcnt lgkmcnt(1)                                       // 000000042F7C: BF89FC17
	v_and_b32_e32 v12, 0xffff0000, v6                          // 000000042F80: 36180CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000042F88: 300C0C90
	v_and_b32_e32 v13, 0xffff0000, v7                          // 000000042F8C: 361A0EFF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v4                          // 000000042F94: 361408FF FFFF0000
	v_lshlrev_b32_e32 v4, 16, v4                               // 000000042F9C: 30080890
	v_and_b32_e32 v11, 0xffff0000, v5                          // 000000042FA0: 36160AFF FFFF0000
	v_lshlrev_b32_e32 v5, 16, v5                               // 000000042FA8: 300A0A90
	s_waitcnt lgkmcnt(0)                                       // 000000042FAC: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000042FB0: BF8701A3
	v_dual_mul_f32 v14, v8, v4 :: v_dual_lshlrev_b32 v7, 16, v7// 000000042FB4: C8E20908 0E060E90
	v_mul_f32_e32 v4, v8, v10                                  // 000000042FBC: 10081508
	v_mul_f32_e32 v10, v8, v5                                  // 000000042FC0: 10140B08
	v_mul_f32_e32 v5, v8, v11                                  // 000000042FC4: 100A1708
	v_mul_f32_e32 v11, v8, v6                                  // 000000042FC8: 10160D08
	v_mul_f32_e32 v6, v8, v12                                  // 000000042FCC: 100C1908
	v_mul_f32_e32 v12, v8, v7                                  // 000000042FD0: 10180F08
	v_mul_f32_e32 v7, v8, v13                                  // 000000042FD4: 100E1B08
	v_cmp_lt_i32_e32 vcc_lo, 31, v2                            // 000000042FD8: 7C82049F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 000000042FDC: CC220004 02006104
	v_fma_mixlo_f16 v4, v14, s48, 0                            // 000000042FE4: CC210004 0200610E
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 000000042FEC: CC220005 02006105
	v_fma_mixlo_f16 v5, v10, s48, 0                            // 000000042FF4: CC210005 0200610A
	v_fma_mixhi_f16 v6, v6, s48, 0                             // 000000042FFC: CC220006 02006106
	v_fma_mixlo_f16 v6, v11, s48, 0                            // 000000043004: CC210006 0200610B
	v_fma_mixhi_f16 v7, v7, s48, 0                             // 00000004300C: CC220007 02006107
	v_fma_mixlo_f16 v7, v12, s48, 0                            // 000000043014: CC210007 0200610C
	s_or_b32 s4, vcc_lo, s4                                    // 00000004301C: 8C04046A
	ds_store_b128 v9, v[4:7] offset:10496                      // 000000043020: DB7C2900 00000409
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000043028: 917E047E
	s_cbranch_execnz 65472                                     // 00000004302C: BFA6FFC0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2330>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000043030: 8C7E037E
	s_mov_b32 s3, 0                                            // 000000043034: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000043038: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 00000004303C: 916A037E
	s_cbranch_vccnz 533                                        // 000000043040: BFA40215 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c98>
	s_mov_b32 s3, exec_lo                                      // 000000043044: BE83007E
	v_cmpx_gt_u32_e32 16, v43                                  // 000000043048: 7D985690
	s_cbranch_execz 529                                        // 00000004304C: BFA50211 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c94>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 000000043050: 7C945680
	s_waitcnt lgkmcnt(0)                                       // 000000043054: BF89FC07
	ds_load_b96 v[14:16], v1 offset:23280                      // 000000043058: DBF85AF0 0E000001
	ds_load_b128 v[59:62], v1 offset:23248                     // 000000043060: DBFC5AD0 3B000001
	ds_load_b128 v[63:66], v1 offset:23264                     // 000000043068: DBFC5AE0 3F000001
	ds_load_b128 v[10:13], v1 offset:23168                     // 000000043070: DBFC5A80 0A000001
	ds_load_b128 v[6:9], v1 offset:23184                       // 000000043078: DBFC5A90 06000001
	ds_load_b128 v[2:5], v1 offset:23200                       // 000000043080: DBFC5AA0 02000001
	ds_load_b64 v[17:18], v1 offset:23216                      // 000000043088: D9D85AB0 11000001
	v_cndmask_b32_e64 v44, 0, 1.0, vcc_lo                      // 000000043090: D501002C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 000000043098: 7C945681
	ds_load_b128 v[45:48], v1 offset:23232                     // 00000004309C: DBFC5AC0 2D000001
	v_cndmask_b32_e64 v33, 0, 1.0, vcc_lo                      // 0000000430A4: D5010021 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 0000000430AC: 7C945682
	v_cndmask_b32_e64 v32, 0, 1.0, vcc_lo                      // 0000000430B0: D5010020 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 0000000430B8: 7C945683
	v_cndmask_b32_e64 v31, 0, 1.0, vcc_lo                      // 0000000430BC: D501001F 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 0000000430C4: 7C945684
	v_cndmask_b32_e64 v29, 0, 1.0, vcc_lo                      // 0000000430C8: D501001D 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 0000000430D0: 7C945685
	v_cndmask_b32_e64 v30, 0, 1.0, vcc_lo                      // 0000000430D4: D501001E 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 0000000430DC: 7C945686
	v_cndmask_b32_e64 v28, 0, 1.0, vcc_lo                      // 0000000430E0: D501001C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 0000000430E8: 7C945687
	v_cndmask_b32_e64 v27, 0, 1.0, vcc_lo                      // 0000000430EC: D501001B 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 0000000430F4: 7C945688
	v_cndmask_b32_e64 v25, 0, 1.0, vcc_lo                      // 0000000430F8: D5010019 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 000000043100: 7C945689
	v_cndmask_b32_e64 v23, 0, 1.0, vcc_lo                      // 000000043104: D5010017 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 00000004310C: 7C94568A
	v_cndmask_b32_e64 v26, 0, 1.0, vcc_lo                      // 000000043110: D501001A 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 000000043118: 7C94568B
	v_cndmask_b32_e64 v24, 0, 1.0, vcc_lo                      // 00000004311C: D5010018 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 000000043124: 7C94568C
	v_cndmask_b32_e64 v20, 0, 1.0, vcc_lo                      // 000000043128: D5010014 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 000000043130: 7C94568D
	v_cndmask_b32_e64 v22, 0, 1.0, vcc_lo                      // 000000043134: D5010016 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 00000004313C: 7C94568E
	v_cndmask_b32_e64 v21, 0, 1.0, vcc_lo                      // 000000043140: D5010015 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 000000043148: 7C94568F
	v_cndmask_b32_e64 v19, 0, 1.0, vcc_lo                      // 00000004314C: D5010013 01A9E480
	s_waitcnt lgkmcnt(7)                                       // 000000043154: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000043158: BF8700B1
	v_fmac_f32_e32 v22, v19, v15                               // 00000004315C: 562C1F13
	v_fmac_f32_e32 v21, v19, v16                               // 000000043160: 562A2113
	s_waitcnt lgkmcnt(1)                                       // 000000043164: BF89FC17
	v_dual_fmac_f32 v23, v19, v64 :: v_dual_fmac_f32 v22, v21, v18// 000000043168: C8008113 17162515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000043170: BF8700D1
	v_dual_fmac_f32 v26, v19, v65 :: v_dual_fmac_f32 v23, v21, v3// 000000043174: C8008313 1A160715
	v_fmac_f32_e32 v25, v19, v63                               // 00000004317C: 56327F13
	ds_load_b32 v18, v1 offset:22880                           // 000000043180: D8D85960 12000001
	v_fmac_f32_e32 v26, v21, v4                                // 000000043188: 56340915
	v_dual_fmac_f32 v28, v19, v61 :: v_dual_fmac_f32 v25, v21, v2// 00000004318C: C8007B13 1C180515
	v_dual_fmac_f32 v29, v19, v59 :: v_dual_fmac_f32 v28, v21, v8// 000000043194: C8007713 1D1C1115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004319C: BF870091
	v_dual_fmac_f32 v30, v19, v60 :: v_dual_fmac_f32 v29, v21, v6// 0000000431A0: C8007913 1E1C0D15
	v_dual_fmac_f32 v27, v19, v62 :: v_dual_fmac_f32 v30, v21, v7// 0000000431A8: C8007D13 1B1E0F15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000431B0: BF870091
	v_dual_fmac_f32 v24, v19, v66 :: v_dual_fmac_f32 v27, v21, v9// 0000000431B4: C8008513 181A1315
	v_fmac_f32_e32 v24, v21, v5                                // 0000000431BC: 56300B15
	ds_load_b128 v[2:5], v1 offset:23072                       // 0000000431C0: DBFC5A20 02000001
	s_waitcnt lgkmcnt(2)                                       // 0000000431C8: BF89FC27
	v_fmac_f32_e32 v31, v19, v48                               // 0000000431CC: 563E6113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000431D0: BF870091
	v_dual_fmac_f32 v32, v19, v47 :: v_dual_fmac_f32 v31, v21, v13// 0000000431D4: C8005F13 201E1B15
	v_dual_fmac_f32 v33, v19, v46 :: v_dual_fmac_f32 v32, v21, v12// 0000000431DC: C8005D13 21201915
	v_fmac_f32_e32 v44, v19, v45                               // 0000000431E4: 56585B13
	ds_load_b128 v[45:48], v1 offset:24064                     // 0000000431E8: DBFC5E00 2D000001
	v_dual_fmac_f32 v33, v21, v11 :: v_dual_fmac_f32 v20, v19, v14// 0000000431F0: C8001715 21141D13
	ds_load_b128 v[59:62], v1 offset:23104                     // 0000000431F8: DBFC5A40 3B000001
	ds_load_b128 v[63:66], v1 offset:23136                     // 000000043200: DBFC5A60 3F000001
	ds_load_b128 v[67:70], v1 offset:23120                     // 000000043208: DBFC5A50 43000001
	ds_load_b32 v14, v1 offset:23152                           // 000000043210: D8D85A70 0E000001
	v_fmac_f32_e32 v44, v21, v10                               // 000000043218: 56581515
	ds_load_b128 v[6:9], v1 offset:23056                       // 00000004321C: DBFC5A10 06000001
	ds_load_b128 v[10:13], v1 offset:23040                     // 000000043224: DBFC5A00 0A000001
	s_waitcnt lgkmcnt(5)                                       // 00000004322C: BF89FC57
	v_fmac_f32_e32 v44, v22, v59                               // 000000043230: 56587716
	v_dual_fmac_f32 v33, v22, v60 :: v_dual_fmac_f32 v20, v21, v17// 000000043234: C8007916 21142315
	s_waitcnt lgkmcnt(3)                                       // 00000004323C: BF89FC37
	v_fmac_f32_e32 v29, v22, v67                               // 000000043240: 563A8716
	v_fmac_f32_e32 v31, v22, v62                               // 000000043244: 563E7D16
	s_waitcnt lgkmcnt(2)                                       // 000000043248: BF89FC27
	v_fmac_f32_e32 v20, v22, v14                               // 00000004324C: 56281D16
	ds_load_b128 v[14:17], v1 offset:22976                     // 000000043250: DBFC59C0 0E000001
	v_fmac_f32_e32 v24, v22, v66                               // 000000043258: 56308516
	v_fmac_f32_e32 v32, v22, v61                               // 00000004325C: 56407B16
	ds_load_b64 v[66:67], v1 offset:22944                      // 000000043260: D9D859A0 42000001
	s_waitcnt lgkmcnt(2)                                       // 000000043268: BF89FC27
	v_fmac_f32_e32 v33, v20, v11                               // 00000004326C: 56421714
	v_fmac_f32_e32 v24, v20, v5                                // 000000043270: 56300B14
	s_waitcnt lgkmcnt(1)                                       // 000000043274: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000043278: BF8701B1
	v_dual_fmac_f32 v33, v24, v15 :: v_dual_fmac_f32 v30, v22, v68// 00000004327C: C8001F18 211E8916
	v_fmac_f32_e32 v29, v20, v6                                // 000000043284: 563A0D14
	v_dual_fmac_f32 v25, v22, v63 :: v_dual_fmac_f32 v44, v20, v10// 000000043288: C8007F16 192C1514
	v_dual_fmac_f32 v23, v22, v64 :: v_dual_fmac_f32 v30, v20, v7// 000000043290: C8008116 171E0F14
	v_fmac_f32_e32 v26, v22, v65                               // 000000043298: 56348316
	ds_load_b128 v[59:62], v1 offset:22992                     // 00000004329C: DBFC59D0 3B000001
	ds_load_b96 v[63:65], v1 offset:23008                      // 0000000432A4: DBF859E0 3F000001
	v_dual_fmac_f32 v28, v22, v69 :: v_dual_fmac_f32 v25, v20, v2// 0000000432AC: C8008B16 1C180514
	v_dual_fmac_f32 v27, v22, v70 :: v_dual_fmac_f32 v32, v20, v12// 0000000432B4: C8008D16 1B201914
	v_fmac_f32_e32 v23, v20, v3                                // 0000000432BC: 562E0714
	v_fmac_f32_e32 v26, v20, v4                                // 0000000432C0: 56340914
	v_fmac_f32_e32 v31, v20, v13                               // 0000000432C4: 563E1B14
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000432C8: BF870004
	v_fmac_f32_e32 v27, v20, v9                                // 0000000432CC: 56361314
	ds_load_b128 v[2:5], v1 offset:22848                       // 0000000432D0: DBFC5940 02000001
	s_waitcnt lgkmcnt(1)                                       // 0000000432D8: BF89FC17
	v_fmac_f32_e32 v26, v24, v65                               // 0000000432DC: 56348318
	v_fmac_f32_e32 v28, v20, v8                                // 0000000432E0: 56381114
	ds_load_b128 v[6:9], v1 offset:22928                       // 0000000432E4: DBFC5990 06000001
	ds_load_b128 v[10:13], v1 offset:22912                     // 0000000432EC: DBFC5980 0A000001
	v_fmac_f32_e32 v29, v24, v59                               // 0000000432F4: 563A7718
	s_waitcnt lgkmcnt(1)                                       // 0000000432F8: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000432FC: BF870001
	v_fmac_f32_e32 v29, v26, v6                                // 000000043300: 563A0D1A
	v_fmac_f32_e32 v31, v24, v17                               // 000000043304: 563E2318
	v_fmac_f32_e32 v44, v24, v14                               // 000000043308: 56581D18
	v_fmac_f32_e32 v23, v24, v64                               // 00000004330C: 562E8118
	v_fmac_f32_e32 v32, v24, v16                               // 000000043310: 56402118
	ds_load_b128 v[14:17], v1 offset:22864                     // 000000043314: DBFC5950 0E000001
	v_fmac_f32_e32 v23, v26, v67                               // 00000004331C: 562E871A
	s_waitcnt lgkmcnt(0)                                       // 000000043320: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000043324: BF870001
	v_fmac_f32_e32 v29, v23, v14                               // 000000043328: 563A1D17
	v_fmac_f32_e32 v27, v24, v62                               // 00000004332C: 56367D18
	v_fmac_f32_e32 v30, v24, v60                               // 000000043330: 563C7918
	v_fmac_f32_e32 v25, v24, v63                               // 000000043334: 56327F18
	v_dual_fmac_f32 v33, v26, v11 :: v_dual_fmac_f32 v28, v24, v61// 000000043338: C800171A 211C7B18
	ds_load_b128 v[59:62], v1 offset:22800                     // 000000043340: DBFC5910 3B000001
	v_fmac_f32_e32 v32, v26, v12                               // 000000043348: 5640191A
	v_fmac_f32_e32 v31, v26, v13                               // 00000004334C: 563E1B1A
	v_fmac_f32_e32 v44, v26, v10                               // 000000043350: 5658151A
	ds_load_b128 v[10:13], v1 offset:22784                     // 000000043354: DBFC5900 0A000001
	ds_load_b96 v[63:65], v1 offset:22736                      // 00000004335C: DBF858D0 3F000001
	v_fmac_f32_e32 v27, v26, v9                                // 000000043364: 5636131A
	v_fmac_f32_e32 v30, v26, v7                                // 000000043368: 563C0F1A
	v_fmac_f32_e32 v25, v26, v66                               // 00000004336C: 5632851A
	v_fmac_f32_e32 v28, v26, v8                                // 000000043370: 5638111A
	ds_load_b128 v[6:9], v1 offset:22720                       // 000000043374: DBFC58C0 06000001
	ds_load_b64 v[66:67], v1 offset:22672                      // 00000004337C: D9D85890 42000001
	v_fmac_f32_e32 v33, v23, v3                                // 000000043384: 56420717
	v_fmac_f32_e32 v25, v23, v18                               // 000000043388: 56322517
	v_fmac_f32_e32 v28, v23, v16                               // 00000004338C: 56382117
	v_fmac_f32_e32 v27, v23, v17                               // 000000043390: 56362317
	v_fmac_f32_e32 v30, v23, v15                               // 000000043394: 563C1F17
	ds_load_b128 v[14:17], v1 offset:22528                     // 000000043398: DBFC5800 0E000001
	s_waitcnt lgkmcnt(5)                                       // 0000000433A0: BF89FC57
	v_fmac_f32_e32 v27, v25, v62                               // 0000000433A4: 56367D19
	v_fmac_f32_e32 v28, v25, v61                               // 0000000433A8: 56387B19
	v_fmac_f32_e32 v30, v25, v60                               // 0000000433AC: 563C7919
	s_waitcnt lgkmcnt(3)                                       // 0000000433B0: BF89FC37
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000433B4: BF870112
	v_fmac_f32_e32 v28, v27, v65                               // 0000000433B8: 5638831B
	v_fmac_f32_e32 v30, v27, v64                               // 0000000433BC: 563C811B
	s_waitcnt lgkmcnt(1)                                       // 0000000433C0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000433C4: BF870001
	v_fmac_f32_e32 v30, v28, v67                               // 0000000433C8: 563C871C
	v_dual_fmac_f32 v44, v23, v2 :: v_dual_fmac_f32 v33, v25, v11// 0000000433CC: C8000517 2C201719
	v_fmac_f32_e32 v31, v23, v5                                // 0000000433D4: 563E0B17
	v_fmac_f32_e32 v32, v23, v4                                // 0000000433D8: 56400917
	ds_load_b128 v[2:5], v1 offset:22656                       // 0000000433DC: DBFC5880 02000001
	v_fmac_f32_e32 v44, v25, v10                               // 0000000433E4: 56581519
	v_fmac_f32_e32 v29, v25, v59                               // 0000000433E8: 563A7719
	v_fmac_f32_e32 v31, v25, v13                               // 0000000433EC: 563E1B19
	v_fmac_f32_e32 v32, v25, v12                               // 0000000433F0: 56401919
	ds_load_b128 v[10:13], v1 offset:22592                     // 0000000433F4: DBFC5840 0A000001
	ds_load_b32 v18, v1 offset:22608                           // 0000000433FC: D8D85850 12000001
	v_fmac_f32_e32 v33, v27, v7                                // 000000043404: 56420F1B
	v_fmac_f32_e32 v29, v27, v63                               // 000000043408: 563A7F1B
	ds_load_b64 v[59:60], v1 offset:22400                      // 00000004340C: D9D85780 3B000001
	v_dual_fmac_f32 v32, v27, v8 :: v_dual_fmac_f32 v29, v28, v66// 000000043414: C800111B 201C851C
	ds_load_b128 v[63:66], v1 offset:24304                     // 00000004341C: DBFC5EF0 3F000001
	s_waitcnt lgkmcnt(2)                                       // 000000043424: BF89FC27
	v_fmac_f32_e32 v29, v30, v18                               // 000000043428: 563A251E
	v_dual_fmac_f32 v44, v27, v6 :: v_dual_fmac_f32 v33, v28, v3// 00000004342C: C8000D1B 2C20071C
	v_fmac_f32_e32 v31, v27, v9                                // 000000043434: 563E131B
	ds_load_b96 v[6:8], v1 offset:22464                        // 000000043438: DBF857C0 06000001
	ds_load_b32 v9, v1 offset:22336                            // 000000043440: D8D85740 09000001
	v_fmac_f32_e32 v44, v28, v2                                // 000000043448: 5658051C
	v_fmac_f32_e32 v32, v28, v4                                // 00000004344C: 5640091C
	v_fmac_f32_e32 v31, v28, v5                                // 000000043450: 563E0B1C
	v_fmac_f32_e32 v33, v30, v11                               // 000000043454: 5642171E
	ds_load_b128 v[2:5], v1 offset:24256                       // 000000043458: DBFC5EC0 02000001
	v_fmac_f32_e32 v44, v30, v10                               // 000000043460: 5658151E
	v_fmac_f32_e32 v32, v30, v12                               // 000000043464: 5640191E
	v_fmac_f32_e32 v31, v30, v13                               // 000000043468: 563E1B1E
	v_fmac_f32_e32 v33, v29, v15                               // 00000004346C: 56421F1D
	s_waitcnt lgkmcnt(3)                                       // 000000043470: BF89FC37
	v_mul_f32_e32 v72, v65, v21                                // 000000043474: 10902B41
	v_fmac_f32_e32 v44, v29, v14                               // 000000043478: 56581D1D
	v_fmac_f32_e32 v32, v29, v16                               // 00000004347C: 5640211D
	v_fmac_f32_e32 v31, v29, v17                               // 000000043480: 563E231D
	s_waitcnt lgkmcnt(2)                                       // 000000043484: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000043488: BF8700A1
	v_fmac_f32_e32 v32, v31, v8                                // 00000004348C: 5640111F
	v_fmac_f32_e32 v33, v31, v7                                // 000000043490: 56420F1F
	v_dual_fmac_f32 v44, v31, v6 :: v_dual_fmac_f32 v33, v32, v60// 000000043494: C8000D1F 2C207920
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004349C: BF870001
	v_fmac_f32_e32 v44, v32, v59                               // 0000000434A0: 56587720
	ds_load_b128 v[59:62], v1 offset:24288                     // 0000000434A4: DBFC5EE0 3B000001
	s_waitcnt lgkmcnt(1)                                       // 0000000434AC: BF89FC17
	v_fma_mixlo_f16 v49, v5, v31, 0                            // 0000000434B0: CC210031 02023F05
	v_mul_f32_e32 v15, v3, v33                                 // 0000000434B8: 101E4303
	v_fmac_f32_e32 v44, v33, v9                                // 0000000434BC: 56581321
	ds_load_b128 v[6:9], v1 offset:24272                       // 0000000434C0: DBFC5ED0 06000001
	ds_load_b128 v[10:13], v1 offset:24112                     // 0000000434C8: DBFC5E30 0A000001
	v_fma_mixlo_f16 v18, v3, v33, 0                            // 0000000434D0: CC210012 02024303
	v_mul_f32_e32 v14, v2, v44                                 // 0000000434D8: 101C5902
	v_fma_mixlo_f16 v2, v2, v44, 0                             // 0000000434DC: CC210002 02025902
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000434E4: BF870113
	v_fma_mix_f32 v15, v18, -1.0, v15 op_sel_hi:[1,1,0]        // 0000000434E8: CC20000F 1C3DE712
	v_fma_mix_f32 v3, v2, -1.0, v14 op_sel_hi:[1,1,0]          // 0000000434F0: CC200003 1C39E702
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000000434F8: BF870232
	.long 0x7f1c150f                                           // 0000000434FC: 7F1C150F
	v_mul_f32_e32 v15, v4, v32                                 // 000000043500: 101E4104
	.long 0x7f043912                                           // 000000043504: 7F043912
	v_cvt_f16_f32_e32 v14, v3                                  // 000000043508: 7E1C1503
	v_fma_mixlo_f16 v3, v4, v32, 0                             // 00000004350C: CC210003 02024104
	v_mul_f32_e32 v4, v5, v31                                  // 000000043514: 10083F05
	s_waitcnt lgkmcnt(2)                                       // 000000043518: BF89FC27
	v_fma_mixlo_f16 v69, v60, v23, 0                           // 00000004351C: CC210045 02022F3C
	s_waitcnt lgkmcnt(1)                                       // 000000043524: BF89FC17
	v_mul_f32_e32 v16, v7, v30                                 // 000000043528: 10203D07
	v_fma_mixlo_f16 v67, v7, v30, 0                            // 00000004352C: CC210043 02023D07
	v_fma_mix_f32 v7, v3, -1.0, v15 op_sel_hi:[1,1,0]          // 000000043534: CC200007 1C3DE703
	v_mul_f32_e32 v5, v6, v29                                  // 00000004353C: 100A3B06
	v_fma_mixlo_f16 v68, v9, v27, 0                            // 000000043540: CC210044 02023709
	.long 0x7f063931                                           // 000000043548: 7F063931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000004354C: BF8701D4
	v_cvt_f16_f32_e32 v15, v7                                  // 000000043550: 7E1E1507
	v_mul_f32_e32 v7, v8, v28                                  // 000000043554: 100E3908
	v_fma_mix_f32 v17, v49, -1.0, v4 op_sel_hi:[1,1,0]         // 000000043558: CC200011 1C11E731
	v_fma_mixlo_f16 v4, v6, v29, 0                             // 000000043560: CC210004 02023B06
	v_fma_mix_f32 v6, v67, -1.0, v16 op_sel_hi:[1,1,0]         // 000000043568: CC200006 1C41E743
	.long 0x7f1e1511                                           // 000000043570: 7F1E1511
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000043574: BF870193
	v_fma_mix_f32 v5, v4, -1.0, v5 op_sel_hi:[1,1,0]           // 000000043578: CC200005 1C15E704
	.long 0x7f201506                                           // 000000043580: 7F201506
	v_fma_mixlo_f16 v6, v59, v25, 0                            // 000000043584: CC210006 0202333B
	.long 0x7f083943                                           // 00000004358C: 7F083943
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000043590: BF8701C4
	v_cvt_f16_f32_e32 v16, v5                                  // 000000043594: 7E201505
	v_fma_mixlo_f16 v5, v8, v28, 0                             // 000000043598: CC210005 02023908
	v_dual_mul_f32 v8, v9, v27 :: v_dual_mul_f32 v9, v59, v25  // 0000000435A0: C8C63709 0808333B
	v_dual_mul_f32 v59, v60, v23 :: v_dual_mul_f32 v60, v61, v26// 0000000435A8: C8C62F3C 3B3C353D
	v_fma_mix_f32 v7, v5, -1.0, v7 op_sel_hi:[1,1,0]           // 0000000435B0: CC200007 1C1DE705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000435B8: BF870213
	v_fma_mix_f32 v8, v68, -1.0, v8 op_sel_hi:[1,1,0]          // 0000000435BC: CC200008 1C21E744
	v_fma_mix_f32 v9, v6, -1.0, v9 op_sel_hi:[1,1,0]           // 0000000435C4: CC200009 1C25E706
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000435CC: BF870004
	v_fma_mix_f32 v70, v69, -1.0, v59 op_sel_hi:[1,1,0]        // 0000000435D0: CC200046 1CEDE745
	.long 0x7f0c3945                                           // 0000000435D8: 7F0C3945
	v_cvt_f16_f32_e32 v17, v7                                  // 0000000435DC: 7E221507
	v_fma_mixlo_f16 v7, v61, v26, 0                            // 0000000435E0: CC210007 0202353D
	.long 0x7f221508                                           // 0000000435E8: 7F221508
	v_cvt_f16_f32_e32 v59, v9                                  // 0000000435EC: 7E761509
	.long 0x7f761546                                           // 0000000435F0: 7F761546
	v_mul_f32_e32 v9, v62, v24                                 // 0000000435F4: 1012313E
	v_fma_mix_f32 v8, v7, -1.0, v60 op_sel_hi:[1,1,0]          // 0000000435F8: CC200008 1CF1E707
	v_fma_mixlo_f16 v70, v62, v24, 0                           // 000000043600: CC210046 0202313E
	v_dual_mul_f32 v61, v63, v20 :: v_dual_mul_f32 v62, v64, v22// 000000043608: C8C6293F 3D3E2D40
	v_fma_mixlo_f16 v64, v64, v22, 0                           // 000000043610: CC210040 02022D40
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000043618: BF870214
	v_cvt_f16_f32_e32 v60, v8                                  // 00000004361C: 7E781508
	v_fma_mix_f32 v71, v70, -1.0, v9 op_sel_hi:[1,1,0]         // 000000043620: CC200047 1C25E746
	v_fma_mixlo_f16 v8, v63, v20, 0                            // 000000043628: CC210008 0202293F
	v_fma_mixlo_f16 v9, v65, v21, 0                            // 000000043630: CC210009 02022B41
	v_fma_mix_f32 v62, v64, -1.0, v62 op_sel_hi:[1,1,0]        // 000000043638: CC20003E 1CF9E740
	v_mul_f32_e32 v65, v66, v19                                // 000000043640: 10822742
	v_fma_mixlo_f16 v66, v66, v19, 0                           // 000000043644: CC210042 02022742
	v_fma_mix_f32 v61, v8, -1.0, v61 op_sel_hi:[1,1,0]         // 00000004364C: CC20003D 1CF5E708
	v_fma_mix_f32 v63, v9, -1.0, v72 op_sel_hi:[1,1,0]         // 000000043654: CC20003F 1D21E709
	.long 0x7f781547                                           // 00000004365C: 7F781547
	.long 0x7f103940                                           // 000000043660: 7F103940
	v_fma_mix_f32 v71, v66, -1.0, v65 op_sel_hi:[1,1,0]        // 000000043664: CC200047 1D05E742
	v_cvt_f16_f32_e32 v61, v61                                 // 00000004366C: 7E7A153D
	.long 0x7f7a153e                                           // 000000043670: 7F7A153E
	v_cvt_f16_f32_e32 v62, v63                                 // 000000043674: 7E7C153F
	.long 0x7f123942                                           // 000000043678: 7F123942
	ds_load_b128 v[63:66], v1 offset:24080                     // 00000004367C: DBFC5E10 3F000001
	v_mul_u32_u24_e32 v72, 48, v43                             // 000000043684: 169056B0
	.long 0x7f0e3946                                           // 000000043688: 7F0E3946
	.long 0x7f0a3944                                           // 00000004368C: 7F0A3944
	v_mul_f32_e32 v18, v45, v44                                // 000000043690: 1024592D
	v_fma_mixlo_f16 v43, v45, v44, 0                           // 000000043694: CC21002B 0202592D
	v_mul_f32_e32 v44, v46, v33                                // 00000004369C: 1058432E
	v_fma_mixlo_f16 v33, v46, v33, 0                           // 0000000436A0: CC210021 0202432E
	ds_store_b128 v72, v[6:9] offset:19216                     // 0000000436A8: DB7C4B10 00000648
	ds_store_b128 v72, v[2:5] offset:19200                     // 0000000436B0: DB7C4B00 00000248
	ds_load_b128 v[2:5], v1 offset:24096                       // 0000000436B8: DBFC5E20 02000001
	v_dual_mul_f32 v7, v47, v32 :: v_dual_mul_f32 v8, v48, v31 // 0000000436C0: C8C6412F 07083F30
	v_fma_mix_f32 v44, v33, -1.0, v44 op_sel_hi:[1,1,0]        // 0000000436C8: CC20002C 1CB1E721
	.long 0x7f7c1547                                           // 0000000436D0: 7F7C1547
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000436D4: BF870002
	.long 0x7f0c152c                                           // 0000000436D8: 7F0C152C
	v_fma_mixlo_f16 v44, v47, v32, 0                           // 0000000436DC: CC21002C 0202412F
	s_waitcnt lgkmcnt(3)                                       // 0000000436E4: BF89FC37
	v_mul_f32_e32 v9, v63, v29                                 // 0000000436E8: 10123B3F
	v_fma_mix_f32 v18, v43, -1.0, v18 op_sel_hi:[1,1,0]        // 0000000436EC: CC200012 1C49E72B
	v_fma_mixlo_f16 v45, v63, v29, 0                           // 0000000436F4: CC21002D 02023B3F
	v_fma_mix_f32 v7, v44, -1.0, v7 op_sel_hi:[1,1,0]          // 0000000436FC: CC200007 1C1DE72C
	v_fma_mixlo_f16 v46, v65, v28, 0                           // 000000043704: CC21002E 02023941
	.long 0x7f563921                                           // 00000004370C: 7F563921
	v_cvt_f16_f32_e32 v6, v18                                  // 000000043710: 7E0C1512
	v_fma_mixlo_f16 v18, v48, v31, 0                           // 000000043714: CC210012 02023F30
	v_mul_f32_e32 v31, v64, v30                                // 00000004371C: 103E3D40
	v_fma_mixlo_f16 v30, v64, v30, 0                           // 000000043720: CC21001E 02023D40
	v_fma_mix_f32 v9, v45, -1.0, v9 op_sel_hi:[1,1,0]          // 000000043728: CC200009 1C25E72D
	v_cvt_f16_f32_e32 v7, v7                                   // 000000043730: 7E0E1507
	.long 0x7f583912                                           // 000000043734: 7F583912
	s_delay_alu instid0(VALU_DEP_4)                            // 000000043738: BF870004
	v_fma_mix_f32 v29, v30, -1.0, v31 op_sel_hi:[1,1,0]        // 00000004373C: CC20001D 1C7DE71E
	v_mul_f32_e32 v31, v65, v28                                // 000000043744: 103E3941
	v_fma_mix_f32 v8, v18, -1.0, v8 op_sel_hi:[1,1,0]          // 000000043748: CC200008 1C21E712
	v_mul_f32_e32 v28, v66, v27                                // 000000043750: 10383742
	v_fma_mixlo_f16 v27, v66, v27, 0                           // 000000043754: CC21001B 02023742
	.long 0x7f5a391e                                           // 00000004375C: 7F5A391E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000043760: BF870004
	.long 0x7f0e1508                                           // 000000043764: 7F0E1508
	v_cvt_f16_f32_e32 v8, v9                                   // 000000043768: 7E101509
	.long 0x7f10151d                                           // 00000004376C: 7F10151D
	v_fma_mix_f32 v9, v46, -1.0, v31 op_sel_hi:[1,1,0]         // 000000043770: CC200009 1C7DE72E
	s_waitcnt lgkmcnt(0)                                       // 000000043778: BF89FC07
	v_mul_f32_e32 v29, v2, v25                                 // 00000004377C: 103A3302
	v_fma_mixlo_f16 v2, v2, v25, 0                             // 000000043780: CC210002 02023302
	v_mul_f32_e32 v25, v3, v23                                 // 000000043788: 10322F03
	v_fma_mixlo_f16 v31, v3, v23, 0                            // 00000004378C: CC21001F 02022F03
	v_fma_mix_f32 v3, v27, -1.0, v28 op_sel_hi:[1,1,0]         // 000000043794: CC200003 1C71E71B
	v_cvt_f16_f32_e32 v9, v9                                   // 00000004379C: 7E121509
	v_mul_f32_e32 v23, v4, v26                                 // 0000000437A0: 102E3504
	.long 0x7f5c391b                                           // 0000000437A4: 7F5C391B
	v_fma_mix_f32 v25, v31, -1.0, v25 op_sel_hi:[1,1,0]        // 0000000437A8: CC200019 1C65E71F
	.long 0x7f121503                                           // 0000000437B0: 7F121503
	v_fma_mixlo_f16 v3, v4, v26, 0                             // 0000000437B4: CC210003 02023504
	v_mul_f32_e32 v26, v11, v22                                // 0000000437BC: 10342D0B
	v_fma_mix_f32 v28, v2, -1.0, v29 op_sel_hi:[1,1,0]         // 0000000437C0: CC20001C 1C75E702
	v_fma_mixlo_f16 v11, v11, v22, 0                           // 0000000437C8: CC21000B 02022D0B
	.long 0x7f04391f                                           // 0000000437D0: 7F04391F
	v_fma_mix_f32 v4, v3, -1.0, v23 op_sel_hi:[1,1,0]          // 0000000437D4: CC200004 1C5DE703
	.long 0x7f2e1519                                           // 0000000437DC: 7F2E1519
	v_cvt_f16_f32_e32 v23, v28                                 // 0000000437E0: 7E2E151C
	v_mul_f32_e32 v25, v5, v24                                 // 0000000437E4: 10323105
	v_fma_mixlo_f16 v28, v5, v24, 0                            // 0000000437E8: CC21001C 02023105
	v_cvt_f16_f32_e32 v24, v4                                  // 0000000437F0: 7E301504
	v_mul_f32_e32 v5, v10, v20                                 // 0000000437F4: 100A290A
	v_fma_mixlo_f16 v4, v10, v20, 0                            // 0000000437F8: CC210004 0202290A
	v_fma_mix_f32 v20, v11, -1.0, v26 op_sel_hi:[1,1,0]        // 000000043800: CC200014 1C69E70B
	v_fma_mix_f32 v22, v28, -1.0, v25 op_sel_hi:[1,1,0]        // 000000043808: CC200016 1C65E71C
	v_mul_f32_e32 v25, v12, v21                                // 000000043810: 10322B0C
	.long 0x7f06391c                                           // 000000043814: 7F06391C
	v_fma_mix_f32 v10, v4, -1.0, v5 op_sel_hi:[1,1,0]          // 000000043818: CC20000A 1C15E704
	v_fma_mixlo_f16 v5, v12, v21, 0                            // 000000043820: CC210005 02022B0C
	v_mul_f32_e32 v21, v13, v19                                // 000000043828: 102A270D
	v_fma_mixlo_f16 v13, v13, v19, 0                           // 00000004382C: CC21000D 0202270D
	.long 0x7f08390b                                           // 000000043834: 7F08390B
	.long 0x7f301516                                           // 000000043838: 7F301516
	v_fma_mix_f32 v12, v5, -1.0, v25 op_sel_hi:[1,1,0]         // 00000004383C: CC20000C 1C65E705
	v_cvt_f16_f32_e32 v25, v10                                 // 000000043844: 7E32150A
	v_fma_mix_f32 v10, v13, -1.0, v21 op_sel_hi:[1,1,0]        // 000000043848: CC20000A 1C55E70D
	.long 0x7f0a390d                                           // 000000043850: 7F0A390D
	.long 0x7f321514                                           // 000000043854: 7F321514
	v_cvt_f16_f32_e32 v26, v12                                 // 000000043858: 7E34150C
	s_delay_alu instid0(VALU_DEP_4)                            // 00000004385C: BF870004
	.long 0x7f34150a                                           // 000000043860: 7F34150A
	ds_store_b128 v72, v[59:62] offset:19984                   // 000000043864: DB7C4E10 00003B48
	ds_store_b128 v72, v[14:17] offset:19968                   // 00000004386C: DB7C4E00 00000E48
	ds_store_b128 v72, v[2:5] offset:20752                     // 000000043874: DB7C5110 00000248
	ds_store_b128 v72, v[43:46] offset:20736                   // 00000004387C: DB7C5100 00002B48
	ds_store_b128 v72, v[23:26] offset:21520                   // 000000043884: DB7C5410 00001748
	ds_store_b128 v72, v[6:9] offset:21504                     // 00000004388C: DB7C5400 00000648
	s_or_b32 exec_lo, exec_lo, s3                              // 000000043894: 8C7E037E
	v_lshlrev_b32_e32 v59, 1, v153                             // 000000043898: 30773281
	s_waitcnt lgkmcnt(0)                                       // 00000004389C: BF89FC07
	s_barrier                                                  // 0000000438A0: BFBD0000
	v_cmp_eq_u32_e32 vcc_lo, 0, v34                            // 0000000438A4: 7C944480
	v_mul_u32_u24_e32 v60, 48, v55                             // 0000000438A8: 16786EB0
	s_cmp_lt_i32 s54, s39                                      // 0000000438AC: BF042736
	ds_load_u16 v2, v59 offset:6416                            // 0000000438B0: D8F01910 0200003B
	ds_load_u16 v3, v59 offset:7776                            // 0000000438B8: D8F01E60 0300003B
	ds_load_u16 v4, v59 offset:7232                            // 0000000438C0: D8F01C40 0400003B
	s_waitcnt lgkmcnt(0)                                       // 0000000438C8: BF89FC07
	ds_load_u16 v5, v59 offset:6688                            // 0000000438CC: D8F01A20 0500003B
	ds_load_u16 v6, v59 offset:6144                            // 0000000438D4: D8F01800 0600003B
	ds_load_b128 v[22:25], v60 offset:19984                    // 0000000438DC: DBFC4E10 1600003C
	ds_load_b128 v[18:21], v60 offset:19968                    // 0000000438E4: DBFC4E00 1200003C
	ds_load_b128 v[26:29], v60 offset:19200                    // 0000000438EC: DBFC4B00 1A00003C
	ds_load_b128 v[30:33], v60 offset:19216                    // 0000000438F4: DBFC4B10 1E00003C
	s_cselect_b32 s3, -1, 0                                    // 0000000438FC: 980380C1
	s_or_b32 s4, s54, 1                                        // 000000043900: 8C048136
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000043904: BF870159
	s_cmp_lt_i32 s4, s39                                       // 000000043908: BF042704
	s_cselect_b32 s4, -1, 0                                    // 00000004390C: 980480C1
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000043910: 30040490
	s_waitcnt lgkmcnt(4)                                       // 000000043914: BF89FC47
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000043918: 300C0C90
	.long 0x7f141502                                           // 00000004391C: 7F141502
	ds_load_u16 v2, v59 offset:6960                            // 000000043920: D8F01B30 0200003B
	v_cvt_f16_f32_e32 v10, v6                                  // 000000043928: 7E141506
	s_waitcnt lgkmcnt(0)                                       // 00000004392C: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000043930: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000043934: BF8700A1
	.long 0x7f161502                                           // 000000043938: 7F161502
	v_lshlrev_b32_e32 v2, 16, v5                               // 00000004393C: 30040A90
	v_cvt_f16_f32_e32 v11, v2                                  // 000000043940: 7E161502
	ds_load_u16 v2, v59 offset:7504                            // 000000043944: D8F01D50 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000004394C: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000043950: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000043954: BF8700A1
	.long 0x7f181502                                           // 000000043958: 7F181502
	v_lshlrev_b32_e32 v2, 16, v4                               // 00000004395C: 30040890
	v_cvt_f16_f32_e32 v12, v2                                  // 000000043960: 7E181502
	ds_load_u16 v2, v59 offset:8048                            // 000000043964: D8F01F70 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000004396C: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000043970: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000043974: BF8700A1
	.long 0x7f1a1502                                           // 000000043978: 7F1A1502
	v_lshlrev_b32_e32 v2, 16, v3                               // 00000004397C: 30040690
	v_cvt_f16_f32_e32 v13, v2                                  // 000000043980: 7E1A1502
	ds_load_u16 v2, v59 offset:8592                            // 000000043984: D8F02190 0200003B
	ds_load_u16 v3, v59 offset:9952                            // 00000004398C: D8F026E0 0300003B
	ds_load_u16 v4, v59 offset:9408                            // 000000043994: D8F024C0 0400003B
	ds_load_u16 v5, v59 offset:8864                            // 00000004399C: D8F022A0 0500003B
	ds_load_u16 v6, v59 offset:8320                            // 0000000439A4: D8F02080 0600003B
	s_waitcnt lgkmcnt(4)                                       // 0000000439AC: BF89FC47
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000000439B0: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000439B4: BF8700B1
	.long 0x7f1c1502                                           // 0000000439B8: 7F1C1502
	s_waitcnt lgkmcnt(0)                                       // 0000000439BC: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v6                               // 0000000439C0: 30040C90
	v_cvt_f16_f32_e32 v14, v2                                  // 0000000439C4: 7E1C1502
	ds_load_u16 v2, v59 offset:9136                            // 0000000439C8: D8F023B0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 0000000439D0: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000000439D4: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000439D8: BF8700A1
	.long 0x7f1e1502                                           // 0000000439DC: 7F1E1502
	v_lshlrev_b32_e32 v2, 16, v5                               // 0000000439E0: 30040A90
	v_cvt_f16_f32_e32 v15, v2                                  // 0000000439E4: 7E1E1502
	ds_load_u16 v2, v59 offset:9680                            // 0000000439E8: D8F025D0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 0000000439F0: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000000439F4: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000439F8: BF8700A1
	.long 0x7f201502                                           // 0000000439FC: 7F201502
	v_lshlrev_b32_e32 v2, 16, v4                               // 000000043A00: 30040890
	v_cvt_f16_f32_e32 v16, v2                                  // 000000043A04: 7E201502
	ds_load_u16 v2, v59 offset:10224                           // 000000043A08: D8F027F0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 000000043A10: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000043A14: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000043A18: BF8700A1
	.long 0x7f221502                                           // 000000043A1C: 7F221502
	v_lshlrev_b32_e32 v2, 16, v3                               // 000000043A20: 30040690
	v_cvt_f16_f32_e32 v17, v2                                  // 000000043A24: 7E221502
	v_dual_mov_b32 v2, s20 :: v_dual_mov_b32 v3, s21           // 000000043A28: CA100014 02020015
	v_dual_mov_b32 v4, s22 :: v_dual_mov_b32 v5, s23           // 000000043A30: CA100016 04040017
	v_dual_mov_b32 v6, s24 :: v_dual_mov_b32 v7, s25           // 000000043A38: CA100018 06060019
	v_dual_mov_b32 v8, s26 :: v_dual_mov_b32 v9, s27           // 000000043A40: CA10001A 0808001B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000043A48: BF870121
	v_wmma_f32_16x16x16_f16 v[61:68], v[18:25], v[10:17], v[2:9]// 000000043A4C: CC40403D 1C0A1512
	v_mov_b32_e32 v18, 0                                       // 000000043A54: 7E240280
	v_wmma_f32_16x16x16_f16 v[61:68], v[26:33], v[10:17], v[61:68]// 000000043A58: CC40403D 1CF6151A
	v_dual_mov_b32 v10, 0 :: v_dual_cndmask_b32 v11, 0x7060302, v149// 000000043A60: CA120080 0A0B2AFF 07060302
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 000000043A6C: CA100080 0C0C0080
	v_mov_b32_e32 v14, 0                                       // 000000043A74: 7E1C0280
	s_waitcnt vmcnt(7)                                         // 000000043A78: BF891FF7
	s_delay_alu instid0(VALU_DEP_3)                            // 000000043A7C: BF870003
	v_mov_b32_dpp v10, v42 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000043A80: 7E1402FA FF00B12A
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 000000043A88: CA100080 0F100080
	v_mov_b32_e32 v17, 0                                       // 000000043A90: 7E220280
	s_waitcnt vmcnt(6)                                         // 000000043A94: BF891BF7
	v_mov_b32_dpp v12, v41 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000043A98: 7E1802FA FF00B129
	v_perm_b32 v10, v42, v10, v11                              // 000000043AA0: D644000A 042E152A
	s_waitcnt vmcnt(5)                                         // 000000043AA8: BF8917F7
	v_mov_b32_dpp v13, v40 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000043AAC: 7E1A02FA FF00B128
	s_waitcnt vmcnt(4)                                         // 000000043AB4: BF8913F7
	v_mov_b32_dpp v14, v39 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000043AB8: 7E1C02FA FF00B127
	s_waitcnt vmcnt(3)                                         // 000000043AC0: BF890FF7
	v_mov_b32_dpp v15, v38 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000043AC4: 7E1E02FA FF00B126
	s_waitcnt vmcnt(2)                                         // 000000043ACC: BF890BF7
	v_mov_b32_dpp v16, v37 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000043AD0: 7E2002FA FF00B125
	s_waitcnt vmcnt(1)                                         // 000000043AD8: BF8907F7
	v_mov_b32_dpp v17, v35 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000043ADC: 7E2202FA FF00B123
	s_waitcnt vmcnt(0)                                         // 000000043AE4: BF8903F7
	v_mov_b32_dpp v18, v36 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000043AE8: 7E2402FA FF00B124
	v_perm_b32 v12, v41, v12, v11                              // 000000043AF0: D644000C 042E1929
	v_perm_b32 v13, v40, v13, v11                              // 000000043AF8: D644000D 042E1B28
	v_perm_b32 v14, v39, v14, v11                              // 000000043B00: D644000E 042E1D27
	v_perm_b32 v15, v38, v15, v11                              // 000000043B08: D644000F 042E1F26
	v_perm_b32 v16, v37, v16, v11                              // 000000043B10: D6440010 042E2125
	v_perm_b32 v17, v35, v17, v11                              // 000000043B18: D6440011 042E2323
	v_perm_b32 v11, v36, v18, v11                              // 000000043B20: D644000B 042E2524
	v_lshlrev_b32_e32 v18, 16, v10                             // 000000043B28: 30241490
	v_and_b32_e32 v19, 0xffff0000, v10                         // 000000043B2C: 362614FF FFFF0000
	ds_load_b128 v[30:33], v60 offset:21520                    // 000000043B34: DBFC5410 1E00003C
	ds_load_b128 v[26:29], v60 offset:21504                    // 000000043B3C: DBFC5400 1A00003C
	ds_load_b128 v[38:41], v60 offset:20752                    // 000000043B44: DBFC5110 2600003C
	ds_load_b128 v[34:37], v60 offset:20736                    // 000000043B4C: DBFC5100 2200003C
	v_cmp_eq_u32_e32 vcc_lo, 0, v154                           // 000000043B54: 7C953480
	v_cvt_f16_f32_e32 v10, v18                                 // 000000043B58: 7E141512
	.long 0x7f141513                                           // 000000043B5C: 7F141513
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000043B60: BF870112
	v_cndmask_b16 v18, 0, v10, s3                              // 000000043B64: D65D0012 000E1480
	v_cndmask_b16 v18, 0, v10, s4                              // 000000043B6C: D65D5012 00121480
	v_lshlrev_b32_e32 v10, 16, v12                             // 000000043B74: 30141890
	s_or_b32 s3, s54, 2                                        // 000000043B78: 8C038236
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043B7C: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000043B80: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000043B84: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000043B88: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000043B8C: BF870481
	v_cndmask_b16 v19, 0, v10, s3                              // 000000043B90: D65D0013 000E1480
	v_and_b32_e32 v10, 0xffff0000, v12                         // 000000043B98: 361418FF FFFF0000
	s_or_b32 s3, s54, 3                                        // 000000043BA0: 8C038336
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043BA4: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000043BA8: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000043BAC: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000043BB0: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000043BB4: BF870481
	v_cndmask_b16 v19, 0, v10, s3                              // 000000043BB8: D65D4013 000E1480
	v_lshlrev_b32_e32 v10, 16, v13                             // 000000043BC0: 30141A90
	s_or_b32 s3, s54, 4                                        // 000000043BC4: 8C038436
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043BC8: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000043BCC: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000043BD0: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000043BD4: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000043BD8: BF870481
	v_cndmask_b16 v20, 0, v10, s3                              // 000000043BDC: D65D0014 000E1480
	v_and_b32_e32 v10, 0xffff0000, v13                         // 000000043BE4: 36141AFF FFFF0000
	s_or_b32 s3, s54, 5                                        // 000000043BEC: 8C038536
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043BF0: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000043BF4: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000043BF8: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000043BFC: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000043C00: BF870481
	v_cndmask_b16 v20, 0, v10, s3                              // 000000043C04: D65D4014 000E1480
	v_lshlrev_b32_e32 v10, 16, v14                             // 000000043C0C: 30141C90
	s_or_b32 s3, s54, 6                                        // 000000043C10: 8C038636
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043C14: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000043C18: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000043C1C: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000043C20: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000043C24: BF870481
	v_cndmask_b16 v21, 0, v10, s3                              // 000000043C28: D65D0015 000E1480
	v_and_b32_e32 v10, 0xffff0000, v14                         // 000000043C30: 36141CFF FFFF0000
	s_or_b32 s3, s54, 7                                        // 000000043C38: 8C038736
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043C3C: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000043C40: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000043C44: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000043C48: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000043C4C: BF870481
	v_cndmask_b16 v21, 0, v10, s3                              // 000000043C50: D65D4015 000E1480
	v_lshlrev_b32_e32 v10, 16, v15                             // 000000043C58: 30141E90
	s_or_b32 s3, s54, 8                                        // 000000043C5C: 8C038836
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043C60: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000043C64: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000043C68: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000043C6C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000043C70: BF870481
	v_cndmask_b16 v22, 0, v10, s3                              // 000000043C74: D65D0016 000E1480
	v_and_b32_e32 v10, 0xffff0000, v15                         // 000000043C7C: 36141EFF FFFF0000
	s_or_b32 s3, s54, 9                                        // 000000043C84: 8C038936
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043C88: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000043C8C: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000043C90: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000043C94: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000043C98: BF870481
	v_cndmask_b16 v22, 0, v10, s3                              // 000000043C9C: D65D4016 000E1480
	v_lshlrev_b32_e32 v10, 16, v16                             // 000000043CA4: 30142090
	s_or_b32 s3, s54, 10                                       // 000000043CA8: 8C038A36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043CAC: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000043CB0: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000043CB4: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000043CB8: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000043CBC: BF870481
	v_cndmask_b16 v23, 0, v10, s3                              // 000000043CC0: D65D0017 000E1480
	v_and_b32_e32 v10, 0xffff0000, v16                         // 000000043CC8: 361420FF FFFF0000
	s_or_b32 s3, s54, 11                                       // 000000043CD0: 8C038B36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043CD4: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000043CD8: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000043CDC: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000043CE0: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000043CE4: BF870481
	v_cndmask_b16 v23, 0, v10, s3                              // 000000043CE8: D65D4017 000E1480
	v_lshlrev_b32_e32 v10, 16, v17                             // 000000043CF0: 30142290
	s_or_b32 s3, s54, 12                                       // 000000043CF4: 8C038C36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043CF8: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000043CFC: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000043D00: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000043D04: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000043D08: BF870481
	v_cndmask_b16 v24, 0, v10, s3                              // 000000043D0C: D65D0018 000E1480
	v_and_b32_e32 v10, 0xffff0000, v17                         // 000000043D14: 361422FF FFFF0000
	s_or_b32 s3, s54, 13                                       // 000000043D1C: 8C038D36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043D20: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000043D24: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000043D28: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000043D2C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000043D30: BF870481
	v_cndmask_b16 v24, 0, v10, s3                              // 000000043D34: D65D4018 000E1480
	v_lshlrev_b32_e32 v10, 16, v11                             // 000000043D3C: 30141690
	s_or_b32 s3, s54, 14                                       // 000000043D40: 8C038E36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043D44: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000043D48: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000043D4C: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000043D50: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000043D54: BF870481
	v_cndmask_b16 v25, 0, v10, s3                              // 000000043D58: D65D0019 000E1480
	v_and_b32_e32 v10, 0xffff0000, v11                         // 000000043D60: 361416FF FFFF0000
	s_or_b32 s3, s54, 15                                       // 000000043D68: 8C038F36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043D6C: BF870099
	s_cmp_lt_i32 s3, s39                                       // 000000043D70: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 000000043D74: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 000000043D78: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000043D7C: BF870481
	v_cndmask_b16 v25, 0, v10, s3                              // 000000043D80: D65D4019 000E1480
	s_waitcnt lgkmcnt(2)                                       // 000000043D88: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000043D8C: BF8700A1
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[18:25], v[2:9]// 000000043D90: CC40400A 1C0A251A
	s_waitcnt lgkmcnt(0)                                       // 000000043D98: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[34:41], v[18:25], v[10:17]// 000000043D9C: CC40400A 1C2A2522
	v_cvt_f16_f32_e32 v18, v61                                 // 000000043DA4: 7E24153D
	v_mad_u32_u24 v22, 0x110, v154, v59                        // 000000043DA8: D60B0016 04EF34FF 00000110
	.long 0x7f24153e                                           // 000000043DB4: 7F24153E
	v_cvt_f16_f32_e32 v19, v63                                 // 000000043DB8: 7E26153F
	.long 0x7f261540                                           // 000000043DBC: 7F261540
	v_cvt_f16_f32_e32 v20, v65                                 // 000000043DC0: 7E281541
	.long 0x7f281542                                           // 000000043DC4: 7F281542
	v_cvt_f16_f32_e32 v21, v67                                 // 000000043DC8: 7E2A1543
	.long 0x7f2a1544                                           // 000000043DCC: 7F2A1544
	ds_store_b16 v22, v18 offset:14848                         // 000000043DD0: D87C3A00 00001216
	ds_store_b16_d16_hi v22, v18 offset:15392                  // 000000043DD8: DA843C20 00001216
	ds_store_b16 v22, v19 offset:15936                         // 000000043DE0: D87C3E40 00001316
	ds_store_b16_d16_hi v22, v19 offset:16480                  // 000000043DE8: DA844060 00001316
	ds_store_b16 v22, v20 offset:17024                         // 000000043DF0: D87C4280 00001416
	ds_store_b16_d16_hi v22, v20 offset:17568                  // 000000043DF8: DA8444A0 00001416
	ds_store_b16 v22, v21 offset:18112                         // 000000043E00: D87C46C0 00001516
	ds_store_b16_d16_hi v22, v21 offset:18656                  // 000000043E08: DA8448E0 00001516
	v_fma_mixlo_f16 v18, v139, s51, 0                          // 000000043E10: CC210012 0200678B
	v_fma_mixhi_f16 v18, v138, s51, 0                          // 000000043E18: CC220012 0200678A
	v_mov_b32_e32 v20, 0x3020706                               // 000000043E20: 7E2802FF 03020706
	v_cndmask_b32_e32 v61, 0x5040100, v149, vcc_lo             // 000000043E28: 027B2AFF 05040100
	s_waitcnt lgkmcnt(0)                                       // 000000043E30: BF89FC07
	s_barrier                                                  // 000000043E34: BFBD0000
	ds_load_b128 v[46:49], v57 offset:14864                    // 000000043E38: DBFC3A10 2E000039
	ds_load_b128 v[42:45], v57 offset:14848                    // 000000043E40: DBFC3A00 2A000039
	ds_load_b128 v[67:70], v57 offset:14896                    // 000000043E48: DBFC3A30 43000039
	ds_load_b128 v[63:66], v57 offset:14880                    // 000000043E50: DBFC3A20 3F000039
	v_dual_mov_b32 v19, v18 :: v_dual_cndmask_b32 v62, 0x7060302, v20// 000000043E58: CA120112 133E28FF 07060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043E64: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000043E68: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v26, v18, v19, v61                              // 000000043E74: D644001A 04F62712
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000043E7C: BF8700B3
	v_perm_b32 v27, v18, v19, v62                              // 000000043E80: D644001B 04FA2712
	v_fma_mixlo_f16 v18, v137, s51, 0                          // 000000043E88: CC210012 02006789
	v_fma_mixhi_f16 v18, v136, s51, 0                          // 000000043E90: CC220012 02006788
	v_mov_b32_e32 v19, v18                                     // 000000043E98: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043E9C: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000043EA0: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v28, v18, v19, v61                              // 000000043EAC: D644001C 04F62712
	v_perm_b32 v29, v18, v19, v62                              // 000000043EB4: D644001D 04FA2712
	v_fma_mixlo_f16 v18, v135, s51, 0                          // 000000043EBC: CC210012 02006787
	v_fma_mixhi_f16 v18, v134, s51, 0                          // 000000043EC4: CC220012 02006786
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043ECC: BF870091
	v_mov_b32_e32 v19, v18                                     // 000000043ED0: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000043ED4: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000043EE0: BF8700C1
	v_perm_b32 v30, v18, v19, v61                              // 000000043EE4: D644001E 04F62712
	v_perm_b32 v31, v18, v19, v62                              // 000000043EEC: D644001F 04FA2712
	v_fma_mixlo_f16 v18, v133, s51, 0                          // 000000043EF4: CC210012 02006785
	v_fma_mixhi_f16 v18, v54, s51, 0                           // 000000043EFC: CC220012 02006736
	v_mov_b32_e32 v19, v18                                     // 000000043F04: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043F08: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000043F0C: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v32, v18, v19, v61                              // 000000043F18: D6440020 04F62712
	v_perm_b32 v33, v18, v19, v62                              // 000000043F20: D6440021 04FA2712
	v_fma_mixlo_f16 v18, v132, s51, 0                          // 000000043F28: CC210012 02006784
	v_fma_mixhi_f16 v18, v131, s51, 0                          // 000000043F30: CC220012 02006783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043F38: BF870091
	v_mov_b32_e32 v19, v18                                     // 000000043F3C: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000043F40: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000043F4C: BF8700C1
	v_perm_b32 v34, v18, v19, v61                              // 000000043F50: D6440022 04F62712
	v_perm_b32 v35, v18, v19, v62                              // 000000043F58: D6440023 04FA2712
	v_fma_mixlo_f16 v18, v130, s51, 0                          // 000000043F60: CC210012 02006782
	v_fma_mixhi_f16 v18, v129, s51, 0                          // 000000043F68: CC220012 02006781
	v_mov_b32_e32 v19, v18                                     // 000000043F70: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043F74: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000043F78: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v36, v18, v19, v61                              // 000000043F84: D6440024 04F62712
	v_perm_b32 v37, v18, v19, v62                              // 000000043F8C: D6440025 04FA2712
	v_fma_mixlo_f16 v18, v128, s51, 0                          // 000000043F94: CC210012 02006780
	v_fma_mixhi_f16 v18, v127, s51, 0                          // 000000043F9C: CC220012 0200677F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043FA4: BF870091
	v_mov_b32_e32 v19, v18                                     // 000000043FA8: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000043FAC: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000043FB8: BF8700C1
	v_perm_b32 v38, v18, v19, v61                              // 000000043FBC: D6440026 04F62712
	v_perm_b32 v39, v18, v19, v62                              // 000000043FC4: D6440027 04FA2712
	v_fma_mixlo_f16 v18, v126, s51, 0                          // 000000043FCC: CC210012 0200677E
	v_fma_mixhi_f16 v18, v53, s51, 0                           // 000000043FD4: CC220012 02006735
	v_mov_b32_e32 v19, v18                                     // 000000043FDC: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000043FE0: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000043FE4: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v40, v18, v19, v61                              // 000000043FF0: D6440028 04F62712
	v_perm_b32 v41, v18, v19, v62                              // 000000043FF8: D6440029 04FA2712
	s_waitcnt lgkmcnt(2)                                       // 000000044000: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[26:33], v[2:9]// 000000044004: CC404012 1C0A352A
	s_waitcnt lgkmcnt(0)                                       // 00000004400C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000044010: BF870001
	v_wmma_f32_16x16x16_f16 v[18:25], v[63:70], v[34:41], v[18:25]// 000000044014: CC404012 1C4A453F
	ds_load_b128 v[63:66], v57 offset:10496                    // 00000004401C: DBFC2900 3F000039
	ds_load_b128 v[67:70], v57 offset:10512                    // 000000044024: DBFC2910 43000039
	s_waitcnt lgkmcnt(0)                                       // 00000004402C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[63:70], v[26:33], v[2:9]// 000000044030: CC40402A 1C0A353F
	ds_load_b128 v[26:29], v57 offset:10528                    // 000000044038: DBFC2920 1A000039
	ds_load_b128 v[30:33], v57 offset:10544                    // 000000044040: DBFC2930 1E000039
	s_waitcnt lgkmcnt(0)                                       // 000000044048: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[26:33], v[34:41], v[42:49]// 00000004404C: CC40402A 1CAA451A
	v_fma_mixlo_f16 v27, v125, s51, 0                          // 000000044054: CC21001B 0200677D
	v_fma_mixhi_f16 v27, v124, s51, 0                          // 00000004405C: CC22001B 0200677C
	v_fma_mixlo_f16 v29, v123, s51, 0                          // 000000044064: CC21001D 0200677B
	v_fma_mixhi_f16 v29, v122, s51, 0                          // 00000004406C: CC22001D 0200677A
	v_fma_mixlo_f16 v31, v121, s51, 0                          // 000000044074: CC21001F 02006779
	v_fma_mixhi_f16 v31, v120, s51, 0                          // 00000004407C: CC22001F 02006778
	v_fma_mixlo_f16 v33, v119, s51, 0                          // 000000044084: CC210021 02006777
	v_fma_mixhi_f16 v33, v52, s51, 0                           // 00000004408C: CC220021 02006734
	v_mov_b32_e32 v28, v27                                     // 000000044094: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000044098: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000004409C: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000440A0: BF870214
	v_mov_b32_e32 v34, v33                                     // 0000000440A4: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 0000000440A8: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000440B4: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 0000000440B8: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 0000000440C4: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000440D0: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000440D4: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000440E0: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000440E8: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 0000000440F0: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 0000000440F8: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000044100: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000044108: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000044110: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000044118: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14928                    // 000000044120: DBFC3A50 26000039
	ds_load_b128 v[34:37], v57 offset:14912                    // 000000044128: DBFC3A40 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000044130: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000044134: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10576                    // 00000004413C: DBFC2950 26000039
	ds_load_b128 v[34:37], v57 offset:10560                    // 000000044144: DBFC2940 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000004414C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000044150: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v118, s51, 0                          // 000000044158: CC21001B 02006776
	v_fma_mixhi_f16 v27, v117, s51, 0                          // 000000044160: CC22001B 02006775
	v_fma_mixlo_f16 v29, v116, s51, 0                          // 000000044168: CC21001D 02006774
	v_fma_mixhi_f16 v29, v115, s51, 0                          // 000000044170: CC22001D 02006773
	v_fma_mixlo_f16 v31, v114, s51, 0                          // 000000044178: CC21001F 02006772
	v_fma_mixhi_f16 v31, v113, s51, 0                          // 000000044180: CC22001F 02006771
	v_fma_mixlo_f16 v33, v112, s51, 0                          // 000000044188: CC210021 02006770
	v_fma_mixhi_f16 v33, v51, s51, 0                           // 000000044190: CC220021 02006733
	v_mov_b32_e32 v28, v27                                     // 000000044198: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000004419C: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 0000000441A0: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000441A4: BF870214
	v_mov_b32_e32 v34, v33                                     // 0000000441A8: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 0000000441AC: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000441B8: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 0000000441BC: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 0000000441C8: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000441D4: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000441D8: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000441E4: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000441EC: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 0000000441F4: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 0000000441FC: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000044204: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000004420C: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000044214: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000004421C: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14960                    // 000000044224: DBFC3A70 26000039
	ds_load_b128 v[34:37], v57 offset:14944                    // 00000004422C: DBFC3A60 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000044234: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000044238: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10608                    // 000000044240: DBFC2970 26000039
	ds_load_b128 v[34:37], v57 offset:10592                    // 000000044248: DBFC2960 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000044250: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000044254: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v111, s51, 0                          // 00000004425C: CC21001B 0200676F
	v_fma_mixhi_f16 v27, v110, s51, 0                          // 000000044264: CC22001B 0200676E
	v_fma_mixlo_f16 v29, v109, s51, 0                          // 00000004426C: CC21001D 0200676D
	v_fma_mixhi_f16 v29, v108, s51, 0                          // 000000044274: CC22001D 0200676C
	v_fma_mixlo_f16 v31, v107, s51, 0                          // 00000004427C: CC21001F 0200676B
	v_fma_mixhi_f16 v31, v106, s51, 0                          // 000000044284: CC22001F 0200676A
	v_fma_mixlo_f16 v33, v105, s51, 0                          // 00000004428C: CC210021 02006769
	v_fma_mixhi_f16 v33, v50, s51, 0                           // 000000044294: CC220021 02006732
	v_mov_b32_e32 v28, v27                                     // 00000004429C: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 0000000442A0: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 0000000442A4: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000442A8: BF870214
	v_mov_b32_e32 v34, v33                                     // 0000000442AC: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 0000000442B0: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000442BC: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 0000000442C0: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 0000000442CC: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000442D8: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000442DC: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000442E8: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000442F0: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 0000000442F8: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 000000044300: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000044308: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000044310: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000044318: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000044320: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14992                    // 000000044328: DBFC3A90 26000039
	ds_load_b128 v[34:37], v57 offset:14976                    // 000000044330: DBFC3A80 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000044338: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000004433C: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10640                    // 000000044344: DBFC2990 26000039
	ds_load_b128 v[34:37], v57 offset:10624                    // 00000004434C: DBFC2980 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000044354: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000044358: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v104, s51, 0                          // 000000044360: CC21001B 02006768
	v_fma_mixhi_f16 v27, v103, s51, 0                          // 000000044368: CC22001B 02006767
	v_fma_mixlo_f16 v29, v102, s51, 0                          // 000000044370: CC21001D 02006766
	v_fma_mixhi_f16 v29, v101, s51, 0                          // 000000044378: CC22001D 02006765
	v_fma_mixlo_f16 v31, v100, s51, 0                          // 000000044380: CC21001F 02006764
	v_fma_mixhi_f16 v31, v99, s51, 0                           // 000000044388: CC22001F 02006763
	v_fma_mixlo_f16 v33, v98, s51, 0                           // 000000044390: CC210021 02006762
	v_fma_mixhi_f16 v33, v58, s51, 0                           // 000000044398: CC220021 0200673A
	v_mov_b32_e32 v28, v27                                     // 0000000443A0: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 0000000443A4: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 0000000443A8: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000443AC: BF870214
	v_mov_b32_e32 v34, v33                                     // 0000000443B0: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 0000000443B4: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000443C0: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 0000000443C4: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 0000000443D0: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000443DC: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000443E0: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000443EC: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000443F4: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 0000000443FC: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 000000044404: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000004440C: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000044414: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000004441C: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000044424: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15024                    // 00000004442C: DBFC3AB0 26000039
	ds_load_b128 v[34:37], v57 offset:15008                    // 000000044434: DBFC3AA0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000004443C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000044440: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10672                    // 000000044448: DBFC29B0 26000039
	ds_load_b128 v[34:37], v57 offset:10656                    // 000000044450: DBFC29A0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000044458: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000004445C: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v97, s51, 0                           // 000000044464: CC21001B 02006761
	v_fma_mixhi_f16 v27, v96, s51, 0                           // 00000004446C: CC22001B 02006760
	v_fma_mixlo_f16 v29, v95, s51, 0                           // 000000044474: CC21001D 0200675F
	v_fma_mixhi_f16 v29, v94, s51, 0                           // 00000004447C: CC22001D 0200675E
	v_fma_mixlo_f16 v31, v93, s51, 0                           // 000000044484: CC21001F 0200675D
	v_fma_mixhi_f16 v31, v92, s51, 0                           // 00000004448C: CC22001F 0200675C
	v_fma_mixlo_f16 v33, v91, s51, 0                           // 000000044494: CC210021 0200675B
	v_fma_mixhi_f16 v33, v152, s51, 0                          // 00000004449C: CC220021 02006798
	v_mov_b32_e32 v28, v27                                     // 0000000444A4: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 0000000444A8: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 0000000444AC: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000444B0: BF870214
	v_mov_b32_e32 v34, v33                                     // 0000000444B4: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 0000000444B8: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000444C4: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 0000000444C8: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 0000000444D4: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000444E0: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000444E4: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000444F0: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000444F8: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 000000044500: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 000000044508: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000044510: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000044518: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000044520: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000044528: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15056                    // 000000044530: DBFC3AD0 26000039
	ds_load_b128 v[34:37], v57 offset:15040                    // 000000044538: DBFC3AC0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000044540: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000044544: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10704                    // 00000004454C: DBFC29D0 26000039
	ds_load_b128 v[34:37], v57 offset:10688                    // 000000044554: DBFC29C0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000004455C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000044560: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v90, s51, 0                           // 000000044568: CC21001B 0200675A
	v_fma_mixhi_f16 v27, v141, s51, 0                          // 000000044570: CC22001B 0200678D
	v_fma_mixlo_f16 v29, v150, s51, 0                          // 000000044578: CC21001D 02006796
	v_fma_mixhi_f16 v29, v142, s51, 0                          // 000000044580: CC22001D 0200678E
	v_fma_mixlo_f16 v31, v191, s51, 0                          // 000000044588: CC21001F 020067BF
	v_fma_mixhi_f16 v31, v189, s51, 0                          // 000000044590: CC22001F 020067BD
	v_fma_mixlo_f16 v33, v190, s51, 0                          // 000000044598: CC210021 020067BE
	v_fma_mixhi_f16 v33, v151, s51, 0                          // 0000000445A0: CC220021 02006797
	v_mov_b32_e32 v28, v27                                     // 0000000445A8: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 0000000445AC: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 0000000445B0: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000445B4: BF870214
	v_mov_b32_e32 v34, v33                                     // 0000000445B8: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 0000000445BC: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000445C8: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 0000000445CC: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 0000000445D8: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000445E4: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000445E8: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000445F4: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000445FC: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 000000044604: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000004460C: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000044614: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000004461C: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000044624: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000004462C: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15088                    // 000000044634: DBFC3AF0 26000039
	ds_load_b128 v[34:37], v57 offset:15072                    // 00000004463C: DBFC3AE0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000044644: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000044648: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10736                    // 000000044650: DBFC29F0 26000039
	ds_load_b128 v[34:37], v57 offset:10720                    // 000000044658: DBFC29E0 22000039
	v_dual_mul_f32 v18, 0x3b800000, v18 :: v_dual_mul_f32 v19, 0x3b800000, v19// 000000044660: C8C624FF 121226FF 3B800000
	v_dual_mul_f32 v20, 0x3b800000, v20 :: v_dual_mul_f32 v21, 0x3b800000, v21// 00000004466C: C8C628FF 14142AFF 3B800000
	v_mul_f32_e32 v22, 0x3b800000, v22                         // 000000044678: 102C2CFF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000044680: BF870223
	v_sub_f32_e32 v10, v10, v18                                // 000000044684: 0814250A
	v_or_b32_e32 v18, s54, v154                                // 000000044688: 38253436
	v_dual_sub_f32 v11, v11, v19 :: v_dual_sub_f32 v12, v12, v20// 00000004468C: C94A270B 0B0C290C
	v_sub_f32_e32 v13, v13, v21                                // 000000044694: 081A2B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000044698: BF870214
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 00000004469C: CC21000A 0200610A
	v_or_b32_e32 v19, 2, v18                                   // 0000000446A4: 38262482
	.long 0xd4440003                                           // 0000000446A8: D4440003
	v_cndmask_b32_e32 v1, s39, v18, vcc_lo                     // 0000000446AC: 02022427
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 0000000446B0: CC22000A 0200610B
	v_dual_mul_f32 v23, 0x3b800000, v23 :: v_dual_sub_f32 v14, v14, v22// 0000000446B8: C8CA2EFF 170E2D0E 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000446C4: BF870214
	v_cmp_gt_i32_e32 vcc_lo, s39, v19                          // 0000000446C8: 7C882627
	v_cndmask_b16 v10, 0, v10, s3                              // 0000000446CC: D65D000A 000E1480
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000000446D4: BF8701D3
	v_dual_mul_f32 v24, 0x3b800000, v24 :: v_dual_sub_f32 v15, v15, v23// 0000000446D8: C8CA30FF 180E2F0F 3B800000
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 0000000446E4: 103232FF 3B800000
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 0000000446EC: D65D500A 01AA1480
	s_waitcnt lgkmcnt(0)                                       // 0000000446F4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 0000000446F8: CC40402A 1CAA3522
	v_dual_sub_f32 v16, v16, v24 :: v_dual_sub_f32 v17, v17, v25// 000000044700: C94A3110 10103311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000044708: BF8700C3
	v_mov_b32_e32 v11, v10                                     // 00000004470C: 7E16030A
	ds_load_b128 v[19:22], v60 offset:23296                    // 000000044710: DBFC5B00 1300003C
	ds_load_b128 v[23:26], v60 offset:23312                    // 000000044718: DBFC5B10 1700003C
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000044720: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v66, v10, v11, v61                              // 00000004472C: D6440042 04F6170A
	v_perm_b32 v67, v10, v11, v62                              // 000000044734: D6440043 04FA170A
	v_or_b32_e32 v10, 4, v18                                   // 00000004473C: 38142484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000044740: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 000000044744: 7C881427
	v_or_b32_e32 v10, 6, v18                                   // 000000044748: 38142486
	.long 0xd4440004                                           // 00000004474C: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 000000044750: 02021427
	v_fma_mixlo_f16 v10, v12, s48, 0                           // 000000044754: CC21000A 0200610C
	v_fma_mixhi_f16 v10, v13, s48, 0                           // 00000004475C: CC22000A 0200610D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000044764: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 000000044768: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s4                              // 000000044770: D65D500A 00121480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044778: BF870091
	v_mov_b32_e32 v11, v10                                     // 00000004477C: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000044780: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000004478C: BF8700B1
	v_perm_b32 v68, v10, v11, v61                              // 000000044790: D6440044 04F6170A
	v_perm_b32 v69, v10, v11, v62                              // 000000044798: D6440045 04FA170A
	v_or_b32_e32 v10, 8, v18                                   // 0000000447A0: 38142488
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 0000000447A4: 7C881427
	v_or_b32_e32 v10, 10, v18                                  // 0000000447A8: 3814248A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000447AC: BF870131
	.long 0xd4440004                                           // 0000000447B0: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 0000000447B4: 02021427
	v_fma_mixlo_f16 v10, v14, s48, 0                           // 0000000447B8: CC21000A 0200610E
	v_fma_mixhi_f16 v10, v15, s48, 0                           // 0000000447C0: CC22000A 0200610F
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 0000000447C8: D65D000A 01AA1480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000447D0: BF870092
	v_cndmask_b16 v10, 0, v10, s4                              // 0000000447D4: D65D500A 00121480
	v_mov_b32_e32 v11, v10                                     // 0000000447DC: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000447E0: BF870091
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 0000000447E4: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v70, v10, v11, v61                              // 0000000447F0: D6440046 04F6170A
	v_perm_b32 v71, v10, v11, v62                              // 0000000447F8: D6440047 04FA170A
	v_or_b32_e32 v10, 12, v18                                  // 000000044800: 3814248C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000044804: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 000000044808: 7C881427
	v_or_b32_e32 v10, 14, v18                                  // 00000004480C: 3814248E
	.long 0xd4440004                                           // 000000044810: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 000000044814: 02021427
	v_fma_mixlo_f16 v10, v16, s48, 0                           // 000000044818: CC21000A 02006110
	v_fma_mixhi_f16 v10, v17, s48, 0                           // 000000044820: CC22000A 02006111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000044828: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000004482C: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s4                              // 000000044834: D65D500A 00121480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004483C: BF870091
	v_mov_b32_e32 v11, v10                                     // 000000044840: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000044844: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000044850: BF8700B1
	v_perm_b32 v72, v10, v11, v61                              // 000000044854: D6440048 04F6170A
	v_perm_b32 v73, v10, v11, v62                              // 00000004485C: D6440049 04FA170A
	s_waitcnt lgkmcnt(0)                                       // 000000044864: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[19:26], v[66:73], v[2:9]// 000000044868: CC40400A 1C0A8513
	.long 0xd7000402                                           // 000000044870: D7000402
	v_cndmask_b32_e32 v1, s44, v59, vcc_lo                     // 000000044874: 0202762C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000044878: BF870001
	v_add_co_ci_u32_e64 v3, null, s45, 0, s4                   // 00000004487C: D5207C03 0011002D
	s_and_saveexec_b32 s4, s3                                  // 000000044884: BE842003
	s_cbranch_execz 19                                         // 000000044888: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3cd8>
	ds_load_b32 v4, v56 offset:24320                           // 00000004488C: D8D85F00 04000038
	s_waitcnt lgkmcnt(0)                                       // 000000044894: BF89FC07
	v_mul_f32_e32 v4, v42, v4                                  // 000000044898: 1008092A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004489C: BF870091
	v_add_f32_e32 v4, v10, v4                                  // 0000000448A0: 0608090A
	v_mul_f32_e32 v6, 0x3b800000, v4                           // 0000000448A4: 100C08FF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v18, v[2:3]            // 0000000448AC: D6FE7C04 040A24FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000448B8: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 0000000448BC: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000000448C4: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 0000000448D0: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000448D8: 8C7E047E
	v_or3_b32 v4, v154, s54, 2                                 // 0000000448DC: D6580004 02086D9A
	s_mov_b32 s3, exec_lo                                      // 0000000448E4: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000448E8: BF870001
	.long 0xd4c4007e                                           // 0000000448EC: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 0000000448F0: 02020827
	s_cbranch_execz 19                                         // 0000000448F4: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3d44>
	ds_load_b32 v5, v56 offset:24328                           // 0000000448F8: D8D85F08 05000038
	s_waitcnt lgkmcnt(0)                                       // 000000044900: BF89FC07
	v_mul_f32_e32 v5, v43, v5                                  // 000000044904: 100A0B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044908: BF870091
	v_add_f32_e32 v5, v11, v5                                  // 00000004490C: 060A0B0B
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000044910: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 000000044918: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044924: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000044928: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000044930: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000004493C: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 000000044944: 8C7E037E
	v_or3_b32 v4, v154, s54, 4                                 // 000000044948: D6580004 02106D9A
	s_mov_b32 s3, exec_lo                                      // 000000044950: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000044954: BF870001
	.long 0xd4c4007e                                           // 000000044958: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000004495C: 02020827
	s_cbranch_execz 19                                         // 000000044960: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3db0>
	ds_load_b32 v5, v56 offset:24336                           // 000000044964: D8D85F10 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000004496C: BF89FC07
	v_mul_f32_e32 v5, v44, v5                                  // 000000044970: 100A0B2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044974: BF870091
	v_add_f32_e32 v5, v12, v5                                  // 000000044978: 060A0B0C
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000004497C: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 000000044984: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044990: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000044994: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000004499C: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 0000000449A8: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000449B0: 8C7E037E
	v_or3_b32 v4, v154, s54, 6                                 // 0000000449B4: D6580004 02186D9A
	s_mov_b32 s3, exec_lo                                      // 0000000449BC: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000449C0: BF870001
	.long 0xd4c4007e                                           // 0000000449C4: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 0000000449C8: 02020827
	s_cbranch_execz 19                                         // 0000000449CC: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3e1c>
	ds_load_b32 v5, v56 offset:24344                           // 0000000449D0: D8D85F18 05000038
	s_waitcnt lgkmcnt(0)                                       // 0000000449D8: BF89FC07
	v_mul_f32_e32 v5, v45, v5                                  // 0000000449DC: 100A0B2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000449E0: BF870091
	v_add_f32_e32 v5, v13, v5                                  // 0000000449E4: 060A0B0D
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 0000000449E8: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 0000000449F0: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000449FC: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000044A00: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000044A08: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000044A14: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 000000044A1C: 8C7E037E
	v_or3_b32 v4, v154, s54, 8                                 // 000000044A20: D6580004 02206D9A
	s_mov_b32 s3, exec_lo                                      // 000000044A28: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000044A2C: BF870001
	.long 0xd4c4007e                                           // 000000044A30: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 000000044A34: 02020827
	s_cbranch_execz 19                                         // 000000044A38: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3e88>
	ds_load_b32 v5, v56 offset:24352                           // 000000044A3C: D8D85F20 05000038
	s_waitcnt lgkmcnt(0)                                       // 000000044A44: BF89FC07
	v_mul_f32_e32 v5, v46, v5                                  // 000000044A48: 100A0B2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044A4C: BF870091
	v_add_f32_e32 v5, v14, v5                                  // 000000044A50: 060A0B0E
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000044A54: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 000000044A5C: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044A68: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000044A6C: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000044A74: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000044A80: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 000000044A88: 8C7E037E
	v_or3_b32 v4, v154, s54, 10                                // 000000044A8C: D6580004 02286D9A
	s_mov_b32 s3, exec_lo                                      // 000000044A94: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000044A98: BF870001
	.long 0xd4c4007e                                           // 000000044A9C: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 000000044AA0: 02020827
	s_cbranch_execz 19                                         // 000000044AA4: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3ef4>
	ds_load_b32 v5, v56 offset:24360                           // 000000044AA8: D8D85F28 05000038
	s_waitcnt lgkmcnt(0)                                       // 000000044AB0: BF89FC07
	v_mul_f32_e32 v5, v47, v5                                  // 000000044AB4: 100A0B2F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044AB8: BF870091
	v_add_f32_e32 v5, v15, v5                                  // 000000044ABC: 060A0B0F
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000044AC0: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 000000044AC8: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044AD4: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000044AD8: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000044AE0: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000044AEC: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 000000044AF4: 8C7E037E
	v_or3_b32 v4, v154, s54, 12                                // 000000044AF8: D6580004 02306D9A
	s_mov_b32 s3, exec_lo                                      // 000000044B00: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000044B04: BF870001
	.long 0xd4c4007e                                           // 000000044B08: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 000000044B0C: 02020827
	s_cbranch_execz 19                                         // 000000044B10: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3f60>
	ds_load_b32 v5, v56 offset:24368                           // 000000044B14: D8D85F30 05000038
	s_waitcnt lgkmcnt(0)                                       // 000000044B1C: BF89FC07
	v_mul_f32_e32 v5, v48, v5                                  // 000000044B20: 100A0B30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044B24: BF870091
	v_add_f32_e32 v5, v16, v5                                  // 000000044B28: 060A0B10
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000044B2C: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 000000044B34: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044B40: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000044B44: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000044B4C: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000044B58: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 000000044B60: 8C7E037E
	v_or3_b32 v4, v154, s54, 14                                // 000000044B64: D6580004 02386D9A
	s_mov_b32 s3, exec_lo                                      // 000000044B6C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000044B70: BF870001
	.long 0xd4c4007e                                           // 000000044B74: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 000000044B78: 02020827
	s_cbranch_execz 19                                         // 000000044B7C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3fcc>
	ds_load_b32 v5, v56 offset:24376                           // 000000044B80: D8D85F38 05000038
	v_mad_u64_u32 v[2:3], null, 0x3000, v4, v[2:3]             // 000000044B88: D6FE7C02 040A08FF 00003000
	s_waitcnt lgkmcnt(0)                                       // 000000044B94: BF89FC07
	v_mul_f32_e32 v5, v49, v5                                  // 000000044B98: 100A0B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044B9C: BF870091
	v_add_f32_e32 v5, v17, v5                                  // 000000044BA0: 060A0B11
	v_mul_f32_e32 v5, 0x3b800000, v5                           // 000000044BA4: 100A0AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044BAC: BF870091
	v_bfe_u32 v6, v5, 16, 1                                    // 000000044BB0: D6100006 02052105
	v_add3_u32 v4, v5, v6, 0x7fff                              // 000000044BB8: D6550004 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 000000044BC4: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 000000044BCC: 8C7E037E
	ds_load_b32 v56, v1 offset:24188                           // 000000044BD0: D8D85E7C 38000001
	v_mad_u32_u24 v2, v55, 48, 0x4b00                          // 000000044BD8: D60B0002 03FD6137 00004B00
	s_add_i32 s54, s54, 16                                     // 000000044BE4: 81369036
	v_mov_b32_e32 v178, s27                                    // 000000044BE8: 7F64021B
	v_dual_mov_b32 v176, s25 :: v_dual_mov_b32 v173, s22       // 000000044BEC: CA100019 B0AC0016
	s_delay_alu instid0(VALU_DEP_3)                            // 000000044BF4: BF870003
	v_dual_mov_b32 v174, s23 :: v_dual_add_nc_u32 v55, 0xffffb500, v2// 000000044BF8: CA200017 AE3604FF FFFFB500
	v_dual_mov_b32 v171, s20 :: v_dual_mov_b32 v172, s21       // 000000044C04: CA100014 ABAC0015
	ds_load_b128 v[159:162], v55 offset:2320                   // 000000044C0C: DBFC0910 9F000037
	ds_load_b128 v[155:158], v55 offset:2304                   // 000000044C14: DBFC0900 9B000037
	ds_load_b128 v[167:170], v55 offset:3088                   // 000000044C1C: DBFC0C10 A7000037
	ds_load_b128 v[163:166], v55 offset:3072                   // 000000044C24: DBFC0C00 A3000037
	ds_load_b128 v[2:5], v55                                   // 000000044C2C: DBFC0000 02000037
	ds_load_b128 v[6:9], v55 offset:16                         // 000000044C34: DBFC0010 06000037
	ds_load_b128 v[82:85], v55 offset:4608                     // 000000044C3C: DBFC1200 52000037
	ds_load_b128 v[183:186], v55 offset:3856                   // 000000044C44: DBFC0F10 B7000037
	ds_load_b128 v[179:182], v55 offset:3840                   // 000000044C4C: DBFC0F00 B3000037
	ds_load_b128 v[86:89], v55 offset:4624                     // 000000044C54: DBFC1210 56000037
	v_mov_b32_e32 v177, s26                                    // 000000044C5C: 7F62021A
	v_mov_b32_e32 v175, s24                                    // 000000044C60: 7F5E0218
	s_waitcnt lgkmcnt(10)                                      // 000000044C64: BF89FCA7
	v_readfirstlane_b32 s3, v56                                // 000000044C68: 7E060538
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v56                  // 000000044C6C: 7C3670FF C2CE8ED0
	s_mul_f32 s3, s3, 0x3fb8aa3b                               // 000000044C74: A203FF03 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 000000044C7C: BF87000B
	s_xor_b32 s4, s3, 0x80000000                               // 000000044C80: 8D04FF03 80000000
	s_cmp_lg_u32 s12, s54                                      // 000000044C88: BF07360C
	v_fma_f32 v10, 0x3fb8aa3b, v56, s4                         // 000000044C8C: D613000A 001270FF 3FB8AA3B
	s_rndne_f32 s4, s3                                         // 000000044C98: BE846303
	s_waitcnt lgkmcnt(4)                                       // 000000044C9C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[34:41], v[2:9], v[66:73], v[171:178]// 000000044CA0: CC404022 1EAE8502
	s_delay_alu instid0(VALU_DEP_2)                            // 000000044CA8: BF870002
	v_fmac_f32_e32 v10, 0x32a5705f, v56                        // 000000044CAC: 561470FF 32A5705F
	s_sub_f32 s3, s3, s4                                       // 000000044CB4: A0830403
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_3)    // 000000044CB8: BF870581
	v_add_f32_e32 v18, s3, v10                                 // 000000044CBC: 06241403
	s_cvt_i32_f32 s3, s4                                       // 000000044CC0: BE836604
	ds_load_b128 v[14:17], v55 offset:784                      // 000000044CC4: DBFC0310 0E000037
	ds_load_b128 v[10:13], v55 offset:768                      // 000000044CCC: DBFC0300 0A000037
	ds_load_b128 v[46:49], v55 offset:1552                     // 000000044CD4: DBFC0610 2E000037
	ds_load_b128 v[42:45], v55 offset:1536                     // 000000044CDC: DBFC0600 2A000037
	v_exp_f32_e32 v18, v18                                     // 000000044CE4: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044CE8: BF870095
	.long 0xd71c0012                                           // 000000044CEC: D71C0012
	v_cndmask_b32_e32 v0, v18, v3, vcc_lo                      // 000000044CF0: 02000712
	v_cndmask_b32_e32 v2, 0, v18, vcc_lo                       // 000000044CF4: 02042480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v56                  // 000000044CF8: 7C3C70FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000044D00: BF870092
	v_cndmask_b32_e32 v145, 0x7f800000, v2, vcc_lo             // 000000044D04: 032204FF 7F800000
	v_fmac_f32_e32 v41, v54, v145                              // 000000044D0C: 56532336
	s_waitcnt lgkmcnt(2)                                       // 000000044D10: BF89FC27
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[66:73], v[171:178]// 000000044D14: CC40401A 1EAE850A
	v_wmma_f32_16x16x16_f16 v[10:17], v[155:162], v[66:73], v[171:178]// 000000044D1C: CC40400A 1EAE859B
	ds_load_b128 v[159:162], v55 offset:5392                   // 000000044D24: DBFC1510 9F000037
	ds_load_b128 v[155:158], v55 offset:5376                   // 000000044D2C: DBFC1500 9B000037
	s_waitcnt lgkmcnt(2)                                       // 000000044D34: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[66:73], v[171:178]// 000000044D38: CC404012 1EAE852A
	v_wmma_f32_16x16x16_f16 v[2:9], v[163:170], v[66:73], v[171:178]// 000000044D40: CC404002 1EAE85A3
	v_wmma_f32_16x16x16_f16 v[42:49], v[179:186], v[66:73], v[171:178]// 000000044D48: CC40402A 1EAE85B3
	v_fma_f32 v138, v138, v145, v35                            // 000000044D50: D613008A 048F238A
	v_fma_f32 v136, v136, v145, v37                            // 000000044D58: D6130088 04972388
	v_fma_f32 v135, v135, v145, v38                            // 000000044D60: D6130087 049B2387
	v_fma_f32 v131, v131, v145, v27                            // 000000044D68: D6130083 046F2383
	v_fmac_f32_e32 v33, v53, v145                              // 000000044D70: 56432335
	v_fmac_f32_e32 v25, v52, v145                              // 000000044D74: 56332334
	v_fmac_f32_e32 v17, v51, v145                              // 000000044D78: 56232333
	v_fmac_f32_e32 v9, v50, v145                               // 000000044D7C: 56132332
	v_wmma_f32_16x16x16_f16 v[50:57], v[82:89], v[66:73], v[171:178]// 000000044D80: CC404032 1EAE8552
	v_fmac_f32_e32 v49, v58, v145                              // 000000044D88: 5663233A
	v_fma_f32 v139, v139, v145, v34                            // 000000044D8C: D613008B 048B238B
	v_fma_f32 v137, v137, v145, v36                            // 000000044D94: D6130089 04932389
	s_waitcnt lgkmcnt(0)                                       // 000000044D9C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[58:65], v[155:162], v[66:73], v[171:178]// 000000044DA0: CC40403A 1EAE859B
	v_fma_f32 v134, v134, v145, v39                            // 000000044DA8: D6130086 049F2386
	v_fma_f32 v133, v133, v145, v40                            // 000000044DB0: D6130085 04A32385
	v_fma_f32 v132, v132, v145, v26                            // 000000044DB8: D6130084 046B2384
	v_fma_f32 v130, v130, v145, v28                            // 000000044DC0: D6130082 04732382
	v_fma_f32 v129, v129, v145, v29                            // 000000044DC8: D6130081 04772381
	v_fma_f32 v128, v128, v145, v30                            // 000000044DD0: D6130080 047B2380
	v_fma_f32 v127, v127, v145, v31                            // 000000044DD8: D613007F 047F237F
	v_fma_f32 v126, v126, v145, v32                            // 000000044DE0: D613007E 0483237E
	v_fma_f32 v125, v125, v145, v18                            // 000000044DE8: D613007D 044B237D
	v_fma_f32 v124, v124, v145, v19                            // 000000044DF0: D613007C 044F237C
	v_fma_f32 v123, v123, v145, v20                            // 000000044DF8: D613007B 0453237B
	v_fma_f32 v122, v122, v145, v21                            // 000000044E00: D613007A 0457237A
	v_fma_f32 v121, v121, v145, v22                            // 000000044E08: D6130079 045B2379
	v_fma_f32 v120, v120, v145, v23                            // 000000044E10: D6130078 045F2378
	v_fma_f32 v119, v119, v145, v24                            // 000000044E18: D6130077 04632377
	v_fma_f32 v118, v118, v145, v10                            // 000000044E20: D6130076 042B2376
	v_fma_f32 v117, v117, v145, v11                            // 000000044E28: D6130075 042F2375
	v_fma_f32 v116, v116, v145, v12                            // 000000044E30: D6130074 04332374
	v_fma_f32 v115, v115, v145, v13                            // 000000044E38: D6130073 04372373
	v_fma_f32 v114, v114, v145, v14                            // 000000044E40: D6130072 043B2372
	v_fma_f32 v113, v113, v145, v15                            // 000000044E48: D6130071 043F2371
	v_fma_f32 v112, v112, v145, v16                            // 000000044E50: D6130070 04432370
	v_fma_f32 v111, v111, v145, v2                             // 000000044E58: D613006F 040B236F
	v_fma_f32 v110, v110, v145, v3                             // 000000044E60: D613006E 040F236E
	v_fma_f32 v109, v109, v145, v4                             // 000000044E68: D613006D 0413236D
	v_fma_f32 v108, v108, v145, v5                             // 000000044E70: D613006C 0417236C
	v_fma_f32 v107, v107, v145, v6                             // 000000044E78: D613006B 041B236B
	v_fma_f32 v106, v106, v145, v7                             // 000000044E80: D613006A 041F236A
	v_fma_f32 v105, v105, v145, v8                             // 000000044E88: D6130069 04232369
	v_fma_f32 v104, v104, v145, v42                            // 000000044E90: D6130068 04AB2368
	v_fma_f32 v103, v103, v145, v43                            // 000000044E98: D6130067 04AF2367
	v_fma_f32 v102, v102, v145, v44                            // 000000044EA0: D6130066 04B32366
	v_fma_f32 v101, v101, v145, v45                            // 000000044EA8: D6130065 04B72365
	v_fma_f32 v100, v100, v145, v46                            // 000000044EB0: D6130064 04BB2364
	v_fma_f32 v99, v99, v145, v47                              // 000000044EB8: D6130063 04BF2363
	v_fma_f32 v98, v98, v145, v48                              // 000000044EC0: D6130062 04C32362
	v_fma_f32 v97, v97, v145, v50                              // 000000044EC8: D6130061 04CB2361
	v_fma_f32 v96, v96, v145, v51                              // 000000044ED0: D6130060 04CF2360
	v_fma_f32 v95, v95, v145, v52                              // 000000044ED8: D613005F 04D3235F
	v_fma_f32 v94, v94, v145, v53                              // 000000044EE0: D613005E 04D7235E
	v_fma_f32 v93, v93, v145, v54                              // 000000044EE8: D613005D 04DB235D
	v_fma_f32 v92, v92, v145, v55                              // 000000044EF0: D613005C 04DF235C
	v_fma_f32 v91, v91, v145, v56                              // 000000044EF8: D613005B 04E3235B
	v_fmac_f32_e32 v57, v152, v145                             // 000000044F00: 56732398
	v_fma_f32 v90, v90, v145, v58                              // 000000044F04: D613005A 04EB235A
	v_fma_f32 v141, v141, v145, v59                            // 000000044F0C: D613008D 04EF238D
	v_fma_f32 v150, v150, v145, v60                            // 000000044F14: D6130096 04F32396
	v_fma_f32 v142, v142, v145, v61                            // 000000044F1C: D613008E 04F7238E
	v_fma_f32 v191, v191, v145, v62                            // 000000044F24: D61300BF 04FB23BF
	v_fma_f32 v189, v189, v145, v63                            // 000000044F2C: D61300BD 04FF23BD
	v_fma_f32 v190, v190, v145, v64                            // 000000044F34: D61300BE 050323BE
	v_dual_fmac_f32 v65, v151, v145 :: v_dual_mul_f32 v6, 0x3b800000, v128// 000000044F3C: C8072397 410700FF 3B800000
	v_lshl_add_u32 v2, v154, 7, v153                           // 000000044F48: D6460002 06650F9A
	v_dual_mul_f32 v69, 0x3b800000, v139 :: v_dual_mul_f32 v152, 0x3b800000, v41// 000000044F50: C8C716FF 459852FF 3B800000
	v_dual_mul_f32 v70, 0x3b800000, v138 :: v_dual_mul_f32 v71, 0x3b800000, v137// 000000044F5C: C8C714FF 464712FF 3B800000
	v_mul_f32_e32 v64, 0x3b800000, v127                        // 000000044F68: 1080FEFF 3B800000
	v_mul_f32_e32 v72, 0x3b800000, v136                        // 000000044F70: 109110FF 3B800000
	v_dual_mul_f32 v4, 0x3b800000, v135 :: v_dual_mul_f32 v73, 0x3b800000, v134// 000000044F78: C8C70EFF 04490CFF 3B800000
	v_dual_mul_f32 v60, 0x3b800000, v123 :: v_dual_mul_f32 v151, 0x3b800000, v133// 000000044F84: C8C6F6FF 3C970AFF 3B800000
	v_dual_mul_f32 v66, 0x3b800000, v126 :: v_dual_mul_f32 v5, 0x3b800000, v132// 000000044F90: C8C6FCFF 420508FF 3B800000
	v_mul_f32_e32 v8, 0x3b800000, v121                         // 000000044F9C: 1010F2FF 3B800000
	v_mul_f32_e32 v68, 0x3b800000, v131                        // 000000044FA4: 108906FF 3B800000
	v_dual_mul_f32 v62, 0x3b800000, v130 :: v_dual_mul_f32 v63, 0x3b800000, v129// 000000044FAC: C8C704FF 3E3F02FF 3B800000
	v_dual_mul_f32 v52, 0x3b800000, v120 :: v_dual_mul_f32 v67, 0x3b800000, v33// 000000044FB8: C8C6F0FF 344242FF 3B800000
	v_dual_mul_f32 v10, 0x3b800000, v118 :: v_dual_mul_f32 v7, 0x3b800000, v125// 000000044FC4: C8C6ECFF 0A06FAFF 3B800000
	v_mul_f32_e32 v56, 0x3b800000, v116                        // 000000044FD0: 1070E8FF 3B800000
	v_dual_mul_f32 v59, 0x3b800000, v124 :: v_dual_mul_f32 v54, 0x3b800000, v25// 000000044FD8: C8C6F8FF 3B3632FF 3B800000
	v_dual_mul_f32 v61, 0x3b800000, v122 :: v_dual_mul_f32 v58, 0x3b800000, v115// 000000044FE4: C8C6F4FF 3D3AE6FF 3B800000
	v_dual_mul_f32 v53, 0x3b800000, v119 :: v_dual_mul_f32 v50, 0x3b800000, v113// 000000044FF0: C8C6EEFF 3532E2FF 3B800000
	v_dual_mul_f32 v55, 0x3b800000, v117 :: v_dual_mul_f32 v12, 0x3b800000, v111// 000000044FFC: C8C6EAFF 370CDEFF 3B800000
	v_dual_mul_f32 v11, 0x3b800000, v114 :: v_dual_mul_f32 v40, 0x3b800000, v17// 000000045008: C8C6E4FF 0B2822FF 3B800000
	v_dual_mul_f32 v51, 0x3b800000, v112 :: v_dual_mul_f32 v44, 0x3b800000, v109// 000000045014: C8C6E0FF 332CDAFF 3B800000
	v_dual_mul_f32 v43, 0x3b800000, v110 :: v_dual_mul_f32 v14, 0x3b800000, v107// 000000045020: C8C6DCFF 2B0ED6FF 3B800000
	v_dual_mul_f32 v45, 0x3b800000, v108 :: v_dual_mul_f32 v46, 0x3b800000, v106// 00000004502C: C8C6D8FF 2D2ED4FF 3B800000
	v_dual_mul_f32 v47, 0x3b800000, v105 :: v_dual_mul_f32 v42, 0x3b800000, v103// 000000045038: C8C6D2FF 2F2ACEFF 3B800000
	v_dual_mul_f32 v48, 0x3b800000, v9 :: v_dual_mul_f32 v15, 0x3b800000, v104// 000000045044: C8C612FF 300ED0FF 3B800000
	v_dual_mul_f32 v35, 0x3b800000, v102 :: v_dual_mul_f32 v36, 0x3b800000, v101// 000000045050: C8C6CCFF 2324CAFF 3B800000
	v_dual_mul_f32 v27, 0x3b800000, v100 :: v_dual_mul_f32 v38, 0x3b800000, v98// 00000004505C: C8C6C8FF 1B26C4FF 3B800000
	v_dual_mul_f32 v37, 0x3b800000, v99 :: v_dual_mul_f32 v28, 0x3b800000, v97// 000000045068: C8C6C6FF 251CC2FF 3B800000
	v_dual_mul_f32 v39, 0x3b800000, v49 :: v_dual_mul_f32 v32, 0x3b800000, v95// 000000045074: C8C662FF 2720BEFF 3B800000
	v_dual_mul_f32 v31, 0x3b800000, v96 :: v_dual_mul_f32 v34, 0x3b800000, v94// 000000045080: C8C6C0FF 1F22BCFF 3B800000
	v_dual_mul_f32 v29, 0x3b800000, v93 :: v_dual_mul_f32 v20, 0x3b800000, v92// 00000004508C: C8C6BAFF 1D14B8FF 3B800000
	v_dual_mul_f32 v21, 0x3b800000, v91 :: v_dual_mul_f32 v22, 0x3b800000, v57// 000000045098: C8C6B6FF 151672FF 3B800000
	v_dual_mul_f32 v30, 0x3b800000, v90 :: v_dual_mul_f32 v23, 0x3b800000, v141// 0000000450A4: C8C6B4FF 1E171AFF 3B800000
	v_dual_mul_f32 v24, 0x3b800000, v150 :: v_dual_mul_f32 v13, 0x3b800000, v65// 0000000450B0: C8C72CFF 180C82FF 3B800000
	v_mul_f32_e32 v26, 0x3b800000, v142                        // 0000000450BC: 10351CFF 3B800000
	v_dual_mul_f32 v16, 0x3b800000, v191 :: v_dual_mul_f32 v19, 0x3b800000, v190// 0000000450C4: C8C77EFF 10137CFF 3B800000
	v_mul_f32_e32 v18, 0x3b800000, v189                        // 0000000450D0: 10257AFF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 0000000450D8: BF89FC07
	s_barrier                                                  // 0000000450DC: BFBD0000
	s_cbranch_scc0 5                                           // 0000000450E0: BFA10005 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44f8>
	s_cmp_lg_u32 s13, s54                                      // 0000000450E4: BF07360D
	s_cbranch_scc0 273                                         // 0000000450E8: BFA10111 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4930>
	s_cmp_lg_u32 s14, s54                                      // 0000000450EC: BF07360E
	s_cbranch_scc1 61702                                       // 0000000450F0: BFA2F106 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	s_branch 540                                               // 0000000450F4: BFA0021C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4d68>
	v_mov_b32_e32 v82, v2                                      // 0000000450F8: 7EA40302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000450FC: BF870091
	v_ashrrev_i32_e32 v83, 31, v82                             // 000000045100: 34A6A49F
	.long 0xd73c0052                                           // 000000045104: D73C0052
	v_cndmask_b32_e32 v1, 2, v82, vcc_lo                       // 000000045108: 0202A482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004510C: BF870091
	.long 0xd7006a52                                           // 000000045110: D7006A52
	v_cndmask_b32_e32 v1, s16, v82, vcc_lo                     // 000000045114: 0202A410
	v_add_co_ci_u32_e64 v83, null, s17, v83, vcc_lo            // 000000045118: D5207C53 01AAA611
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045120: BF870092
	.long 0xd7006a54                                           // 000000045124: D7006A54
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 000000045128: 0202A4FF 00001000
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000045130: D5207C55 01AAA680
	.long 0xd7006a56                                           // 000000045138: D7006A56
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004513C: 0201FF52
	.long 0x00002000                                           // 000000045140: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000045144: BF8700A1
	v_add_co_ci_u32_e64 v87, null, 0, v83, vcc_lo              // 000000045148: D5207C57 01AAA680
	.long 0xd7006a58                                           // 000000045150: D7006A58
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 000000045154: 0202A4FF 00002000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000004515C: D5207C59 01AAA680
	s_clause 0x7                                               // 000000045164: BF850007
	global_store_b32 v[82:83], v69, off                        // 000000045168: DC6A0000 007C4552
	global_store_b32 v[82:83], v70, off offset:1024            // 000000045170: DC6A0400 007C4652
	global_store_b32 v[82:83], v71, off offset:2048            // 000000045178: DC6A0800 007C4752
	global_store_b32 v[82:83], v72, off offset:3072            // 000000045180: DC6A0C00 007C4852
	global_store_b32 v[84:85], v73, off offset:1024            // 000000045188: DC6A0400 007C4954
	global_store_b32 v[84:85], v151, off offset:2048           // 000000045190: DC6A0800 007C9754
	global_store_b32 v[84:85], v152, off offset:3072           // 000000045198: DC6A0C00 007C9854
	global_store_b32 v[88:89], v68, off offset:1024            // 0000000451A0: DC6A0400 007C4458
	.long 0xd7006a54                                           // 0000000451A8: D7006A54
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 0000000451AC: 0202A4FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000451B4: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000451B8: D5207C55 01AAA680
	.long 0xd7006a99                                           // 0000000451C0: D7006A99
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000451C4: 0201FF52
	.long 0x00004000                                           // 0000000451C8: 00004000
	v_add_co_ci_u32_e64 v154, null, 0, v83, vcc_lo             // 0000000451CC: D5207C9A 01AAA680
	.long 0xd7006a9b                                           // 0000000451D4: D7006A9B
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 0000000451D8: 0202A4FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000451E0: BF870001
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 0000000451E4: D5207C9C 01AAA680
	s_clause 0x7                                               // 0000000451EC: BF850007
	global_store_b32 v[88:89], v62, off offset:2048            // 0000000451F0: DC6A0800 007C3E58
	global_store_b32 v[88:89], v63, off offset:3072            // 0000000451F8: DC6A0C00 007C3F58
	global_store_b32 v[84:85], v64, off offset:1024            // 000000045200: DC6A0400 007C4054
	global_store_b32 v[84:85], v66, off offset:2048            // 000000045208: DC6A0800 007C4254
	global_store_b32 v[84:85], v67, off offset:3072            // 000000045210: DC6A0C00 007C4354
	global_store_b32 v[155:156], v59, off offset:1024          // 000000045218: DC6A0400 007C3B9B
	global_store_b32 v[155:156], v60, off offset:2048          // 000000045220: DC6A0800 007C3C9B
	global_store_b32 v[155:156], v61, off offset:3072          // 000000045228: DC6A0C00 007C3D9B
	.long 0xd7006a54                                           // 000000045230: D7006A54
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 000000045234: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004523C: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000045240: D5207C55 01AAA680
	.long 0xd7006a58                                           // 000000045248: D7006A58
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004524C: 0201FF52
	.long 0x00006000                                           // 000000045250: 00006000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 000000045254: D5207C59 01AAA680
	.long 0xd7006a9b                                           // 00000004525C: D7006A9B
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 000000045260: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000045268: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000004526C: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 000000045274: D7006A9D
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 000000045278: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 000000045280: D5207C9E 01AAA680
	.long 0xd7006a9f                                           // 000000045288: D7006A9F
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004528C: 0201FF52
	.long 0x00008000                                           // 000000045290: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000045294: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v83, vcc_lo             // 000000045298: D5207CA0 01AAA680
	s_clause 0x7                                               // 0000000452A0: BF850007
	global_store_b32 v[84:85], v52, off offset:1024            // 0000000452A4: DC6A0400 007C3454
	global_store_b32 v[84:85], v53, off offset:2048            // 0000000452AC: DC6A0800 007C3554
	global_store_b32 v[84:85], v54, off offset:3072            // 0000000452B4: DC6A0C00 007C3654
	global_store_b32 v[155:156], v55, off offset:1024          // 0000000452BC: DC6A0400 007C379B
	global_store_b32 v[155:156], v56, off offset:2048          // 0000000452C4: DC6A0800 007C389B
	global_store_b32 v[155:156], v58, off offset:3072          // 0000000452CC: DC6A0C00 007C3A9B
	global_store_b32 v[157:158], v50, off offset:1024          // 0000000452D4: DC6A0400 007C329D
	global_store_b32 v[157:158], v51, off offset:2048          // 0000000452DC: DC6A0800 007C339D
	.long 0xd7006a54                                           // 0000000452E4: D7006A54
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 0000000452E8: 0202A4FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000452F0: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000452F4: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 0000000452FC: D7006A9B
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 000000045300: 0202A4FF 00009000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 000000045308: D5207C9C 01AAA680
	.long 0xd7006aa1                                           // 000000045310: D7006AA1
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000045314: 0201FF52
	.long 0x0000a000                                           // 000000045318: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004531C: BF8700A1
	v_add_co_ci_u32_e64 v162, null, 0, v83, vcc_lo             // 000000045320: D5207CA2 01AAA680
	.long 0xd7006aa3                                           // 000000045328: D7006AA3
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 00000004532C: 0202A4FF 0000A000
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 000000045334: D5207CA4 01AAA680
	s_clause 0x7                                               // 00000004533C: BF850007
	global_store_b32 v[157:158], v40, off offset:3072          // 000000045340: DC6A0C00 007C289D
	global_store_b32 v[84:85], v43, off offset:1024            // 000000045348: DC6A0400 007C2B54
	global_store_b32 v[84:85], v44, off offset:2048            // 000000045350: DC6A0800 007C2C54
	global_store_b32 v[84:85], v45, off offset:3072            // 000000045358: DC6A0C00 007C2D54
	global_store_b32 v[155:156], v46, off offset:1024          // 000000045360: DC6A0400 007C2E9B
	global_store_b32 v[155:156], v47, off offset:2048          // 000000045368: DC6A0800 007C2F9B
	global_store_b32 v[155:156], v48, off offset:3072          // 000000045370: DC6A0C00 007C309B
	global_store_b32 v[163:164], v42, off offset:1024          // 000000045378: DC6A0400 007C2AA3
	.long 0xd7006a54                                           // 000000045380: D7006A54
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 000000045384: 0202A4FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004538C: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000045390: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 000000045398: D7006A9B
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004539C: 0201FF52
	.long 0x0000c000                                           // 0000000453A0: 0000C000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 0000000453A4: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 0000000453AC: D7006A9D
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 0000000453B0: 0202A4FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000453B8: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 0000000453BC: D5207C9E 01AAA680
	s_clause 0x7                                               // 0000000453C4: BF850007
	global_store_b32 v[163:164], v35, off offset:2048          // 0000000453C8: DC6A0800 007C23A3
	global_store_b32 v[163:164], v36, off offset:3072          // 0000000453D0: DC6A0C00 007C24A3
	global_store_b32 v[84:85], v37, off offset:1024            // 0000000453D8: DC6A0400 007C2554
	global_store_b32 v[84:85], v38, off offset:2048            // 0000000453E0: DC6A0800 007C2654
	global_store_b32 v[84:85], v39, off offset:3072            // 0000000453E8: DC6A0C00 007C2754
	global_store_b32 v[157:158], v31, off offset:1024          // 0000000453F0: DC6A0400 007C1F9D
	global_store_b32 v[157:158], v32, off offset:2048          // 0000000453F8: DC6A0800 007C209D
	global_store_b32 v[157:158], v34, off offset:3072          // 000000045400: DC6A0C00 007C229D
	.long 0xd7006a54                                           // 000000045408: D7006A54
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 00000004540C: 0202A4FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000045414: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000045418: D5207C55 01AAA680
	.long 0xd7006a9d                                           // 000000045420: D7006A9D
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000045424: 0201FF52
	.long 0x0000e000                                           // 000000045428: 0000E000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000004542C: D5207C9E 01AAA680
	.long 0xd7006aa3                                           // 000000045434: D7006AA3
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 000000045438: 0202A4FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000045440: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 000000045444: D5207CA4 01AAA680
	.long 0xd7006a52                                           // 00000004544C: D7006A52
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 000000045450: 0202A4FF 0000F000
	s_clause 0x7                                               // 000000045458: BF850007
	global_store_b32 v[159:160], v11, off offset:-4096         // 00000004545C: DC6A1000 007C0B9F
	global_store_b32 v[159:160], v12, off                      // 000000045464: DC6A0000 007C0C9F
	global_store_b32 v[161:162], v14, off offset:-4096         // 00000004546C: DC6A1000 007C0EA1
	global_store_b32 v[161:162], v15, off                      // 000000045474: DC6A0000 007C0FA1
	global_store_b32 v[155:156], v27, off offset:-4096         // 00000004547C: DC6A1000 007C1B9B
	global_store_b32 v[155:156], v28, off                      // 000000045484: DC6A0000 007C1C9B
	global_store_b32 v[157:158], v29, off offset:-4096         // 00000004548C: DC6A1000 007C1D9D
	global_store_b32 v[157:158], v30, off                      // 000000045494: DC6A0000 007C1E9D
	v_add_co_ci_u32_e64 v83, null, 0, v83, vcc_lo              // 00000004549C: D5207C53 01AAA680
	s_clause 0xf                                               // 0000000454A4: BF85000F
	global_store_b32 v[84:85], v20, off offset:1024            // 0000000454A8: DC6A0400 007C1454
	global_store_b32 v[84:85], v21, off offset:2048            // 0000000454B0: DC6A0800 007C1554
	global_store_b32 v[84:85], v22, off offset:3072            // 0000000454B8: DC6A0C00 007C1654
	global_store_b32 v[163:164], v23, off offset:1024          // 0000000454C0: DC6A0400 007C17A3
	global_store_b32 v[163:164], v24, off offset:2048          // 0000000454C8: DC6A0800 007C18A3
	global_store_b32 v[163:164], v26, off offset:3072          // 0000000454D0: DC6A0C00 007C1AA3
	global_store_b32 v[82:83], v16, off                        // 0000000454D8: DC6A0000 007C1052
	global_store_b32 v[82:83], v18, off offset:1024            // 0000000454E0: DC6A0400 007C1252
	global_store_b32 v[82:83], v19, off offset:2048            // 0000000454E8: DC6A0800 007C1352
	global_store_b32 v[86:87], v4, off offset:-4096            // 0000000454F0: DC6A1000 007C0456
	global_store_b32 v[86:87], v5, off                         // 0000000454F8: DC6A0000 007C0556
	global_store_b32 v[153:154], v6, off offset:-4096          // 000000045500: DC6A1000 007C0699
	global_store_b32 v[153:154], v7, off                       // 000000045508: DC6A0000 007C0799
	global_store_b32 v[88:89], v8, off offset:-4096            // 000000045510: DC6A1000 007C0858
	global_store_b32 v[88:89], v10, off                        // 000000045518: DC6A0000 007C0A58
	global_store_b32 v[82:83], v13, off offset:3072            // 000000045520: DC6A0C00 007C0D52
	s_cmp_lg_u32 s13, s54                                      // 000000045528: BF07360D
	s_cbranch_scc1 65263                                       // 00000004552C: BFA2FEEF <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44ec>
	v_mov_b32_e32 v82, v2                                      // 000000045530: 7EA40302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045534: BF870091
	v_ashrrev_i32_e32 v83, 31, v82                             // 000000045538: 34A6A49F
	.long 0xd73c0052                                           // 00000004553C: D73C0052
	v_cndmask_b32_e32 v1, 2, v82, vcc_lo                       // 000000045540: 0202A482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045544: BF870091
	.long 0xd7006a52                                           // 000000045548: D7006A52
	v_cndmask_b32_e32 v1, s18, v82, vcc_lo                     // 00000004554C: 0202A412
	v_add_co_ci_u32_e64 v83, null, s19, v83, vcc_lo            // 000000045550: D5207C53 01AAA613
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000045558: BF870092
	.long 0xd7006a54                                           // 00000004555C: D7006A54
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 000000045560: 0202A4FF 00001000
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000045568: D5207C55 01AAA680
	.long 0xd7006a56                                           // 000000045570: D7006A56
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000045574: 0201FF52
	.long 0x00002000                                           // 000000045578: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004557C: BF8700A1
	v_add_co_ci_u32_e64 v87, null, 0, v83, vcc_lo              // 000000045580: D5207C57 01AAA680
	.long 0xd7006a58                                           // 000000045588: D7006A58
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 00000004558C: 0202A4FF 00002000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 000000045594: D5207C59 01AAA680
	s_clause 0x7                                               // 00000004559C: BF850007
	global_store_b32 v[82:83], v69, off                        // 0000000455A0: DC6A0000 007C4552
	global_store_b32 v[82:83], v70, off offset:1024            // 0000000455A8: DC6A0400 007C4652
	global_store_b32 v[82:83], v71, off offset:2048            // 0000000455B0: DC6A0800 007C4752
	global_store_b32 v[82:83], v72, off offset:3072            // 0000000455B8: DC6A0C00 007C4852
	global_store_b32 v[84:85], v73, off offset:1024            // 0000000455C0: DC6A0400 007C4954
	global_store_b32 v[84:85], v151, off offset:2048           // 0000000455C8: DC6A0800 007C9754
	global_store_b32 v[84:85], v152, off offset:3072           // 0000000455D0: DC6A0C00 007C9854
	global_store_b32 v[88:89], v68, off offset:1024            // 0000000455D8: DC6A0400 007C4458
	.long 0xd7006a54                                           // 0000000455E0: D7006A54
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 0000000455E4: 0202A4FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000455EC: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000455F0: D5207C55 01AAA680
	.long 0xd7006a99                                           // 0000000455F8: D7006A99
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000455FC: 0201FF52
	.long 0x00004000                                           // 000000045600: 00004000
	v_add_co_ci_u32_e64 v154, null, 0, v83, vcc_lo             // 000000045604: D5207C9A 01AAA680
	.long 0xd7006a9b                                           // 00000004560C: D7006A9B
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 000000045610: 0202A4FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000045618: BF870001
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000004561C: D5207C9C 01AAA680
	s_clause 0x7                                               // 000000045624: BF850007
	global_store_b32 v[88:89], v62, off offset:2048            // 000000045628: DC6A0800 007C3E58
	global_store_b32 v[88:89], v63, off offset:3072            // 000000045630: DC6A0C00 007C3F58
	global_store_b32 v[84:85], v64, off offset:1024            // 000000045638: DC6A0400 007C4054
	global_store_b32 v[84:85], v66, off offset:2048            // 000000045640: DC6A0800 007C4254
	global_store_b32 v[84:85], v67, off offset:3072            // 000000045648: DC6A0C00 007C4354
	global_store_b32 v[155:156], v59, off offset:1024          // 000000045650: DC6A0400 007C3B9B
	global_store_b32 v[155:156], v60, off offset:2048          // 000000045658: DC6A0800 007C3C9B
	global_store_b32 v[155:156], v61, off offset:3072          // 000000045660: DC6A0C00 007C3D9B
	.long 0xd7006a54                                           // 000000045668: D7006A54
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 00000004566C: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000045674: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000045678: D5207C55 01AAA680
	.long 0xd7006a58                                           // 000000045680: D7006A58
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000045684: 0201FF52
	.long 0x00006000                                           // 000000045688: 00006000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000004568C: D5207C59 01AAA680
	.long 0xd7006a9b                                           // 000000045694: D7006A9B
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 000000045698: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000456A0: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 0000000456A4: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 0000000456AC: D7006A9D
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 0000000456B0: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 0000000456B8: D5207C9E 01AAA680
	.long 0xd7006a9f                                           // 0000000456C0: D7006A9F
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000456C4: 0201FF52
	.long 0x00008000                                           // 0000000456C8: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000456CC: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v83, vcc_lo             // 0000000456D0: D5207CA0 01AAA680
	s_clause 0x7                                               // 0000000456D8: BF850007
	global_store_b32 v[84:85], v52, off offset:1024            // 0000000456DC: DC6A0400 007C3454
	global_store_b32 v[84:85], v53, off offset:2048            // 0000000456E4: DC6A0800 007C3554
	global_store_b32 v[84:85], v54, off offset:3072            // 0000000456EC: DC6A0C00 007C3654
	global_store_b32 v[155:156], v55, off offset:1024          // 0000000456F4: DC6A0400 007C379B
	global_store_b32 v[155:156], v56, off offset:2048          // 0000000456FC: DC6A0800 007C389B
	global_store_b32 v[155:156], v58, off offset:3072          // 000000045704: DC6A0C00 007C3A9B
	global_store_b32 v[157:158], v50, off offset:1024          // 00000004570C: DC6A0400 007C329D
	global_store_b32 v[157:158], v51, off offset:2048          // 000000045714: DC6A0800 007C339D
	.long 0xd7006a54                                           // 00000004571C: D7006A54
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 000000045720: 0202A4FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000045728: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000004572C: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 000000045734: D7006A9B
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 000000045738: 0202A4FF 00009000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 000000045740: D5207C9C 01AAA680
	.long 0xd7006aa1                                           // 000000045748: D7006AA1
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004574C: 0201FF52
	.long 0x0000a000                                           // 000000045750: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000045754: BF8700A1
	v_add_co_ci_u32_e64 v162, null, 0, v83, vcc_lo             // 000000045758: D5207CA2 01AAA680
	.long 0xd7006aa3                                           // 000000045760: D7006AA3
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 000000045764: 0202A4FF 0000A000
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000004576C: D5207CA4 01AAA680
	s_clause 0x7                                               // 000000045774: BF850007
	global_store_b32 v[157:158], v40, off offset:3072          // 000000045778: DC6A0C00 007C289D
	global_store_b32 v[84:85], v43, off offset:1024            // 000000045780: DC6A0400 007C2B54
	global_store_b32 v[84:85], v44, off offset:2048            // 000000045788: DC6A0800 007C2C54
	global_store_b32 v[84:85], v45, off offset:3072            // 000000045790: DC6A0C00 007C2D54
	global_store_b32 v[155:156], v46, off offset:1024          // 000000045798: DC6A0400 007C2E9B
	global_store_b32 v[155:156], v47, off offset:2048          // 0000000457A0: DC6A0800 007C2F9B
	global_store_b32 v[155:156], v48, off offset:3072          // 0000000457A8: DC6A0C00 007C309B
	global_store_b32 v[163:164], v42, off offset:1024          // 0000000457B0: DC6A0400 007C2AA3
	.long 0xd7006a54                                           // 0000000457B8: D7006A54
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 0000000457BC: 0202A4FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000457C4: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000457C8: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 0000000457D0: D7006A9B
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000457D4: 0201FF52
	.long 0x0000c000                                           // 0000000457D8: 0000C000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 0000000457DC: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 0000000457E4: D7006A9D
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 0000000457E8: 0202A4FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000457F0: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 0000000457F4: D5207C9E 01AAA680
	s_clause 0x7                                               // 0000000457FC: BF850007
	global_store_b32 v[163:164], v35, off offset:2048          // 000000045800: DC6A0800 007C23A3
	global_store_b32 v[163:164], v36, off offset:3072          // 000000045808: DC6A0C00 007C24A3
	global_store_b32 v[84:85], v37, off offset:1024            // 000000045810: DC6A0400 007C2554
	global_store_b32 v[84:85], v38, off offset:2048            // 000000045818: DC6A0800 007C2654
	global_store_b32 v[84:85], v39, off offset:3072            // 000000045820: DC6A0C00 007C2754
	global_store_b32 v[157:158], v31, off offset:1024          // 000000045828: DC6A0400 007C1F9D
	global_store_b32 v[157:158], v32, off offset:2048          // 000000045830: DC6A0800 007C209D
	global_store_b32 v[157:158], v34, off offset:3072          // 000000045838: DC6A0C00 007C229D
	.long 0xd7006a54                                           // 000000045840: D7006A54
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 000000045844: 0202A4FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004584C: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000045850: D5207C55 01AAA680
	.long 0xd7006a9d                                           // 000000045858: D7006A9D
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000004585C: 0201FF52
	.long 0x0000e000                                           // 000000045860: 0000E000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 000000045864: D5207C9E 01AAA680
	.long 0xd7006aa3                                           // 00000004586C: D7006AA3
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 000000045870: 0202A4FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000045878: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000004587C: D5207CA4 01AAA680
	.long 0xd7006a52                                           // 000000045884: D7006A52
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 000000045888: 0202A4FF 0000F000
	s_clause 0x7                                               // 000000045890: BF850007
	global_store_b32 v[159:160], v11, off offset:-4096         // 000000045894: DC6A1000 007C0B9F
	global_store_b32 v[159:160], v12, off                      // 00000004589C: DC6A0000 007C0C9F
	global_store_b32 v[161:162], v14, off offset:-4096         // 0000000458A4: DC6A1000 007C0EA1
	global_store_b32 v[161:162], v15, off                      // 0000000458AC: DC6A0000 007C0FA1
	global_store_b32 v[155:156], v27, off offset:-4096         // 0000000458B4: DC6A1000 007C1B9B
	global_store_b32 v[155:156], v28, off                      // 0000000458BC: DC6A0000 007C1C9B
	global_store_b32 v[157:158], v29, off offset:-4096         // 0000000458C4: DC6A1000 007C1D9D
	global_store_b32 v[157:158], v30, off                      // 0000000458CC: DC6A0000 007C1E9D
	v_add_co_ci_u32_e64 v83, null, 0, v83, vcc_lo              // 0000000458D4: D5207C53 01AAA680
	s_clause 0xf                                               // 0000000458DC: BF85000F
	global_store_b32 v[84:85], v20, off offset:1024            // 0000000458E0: DC6A0400 007C1454
	global_store_b32 v[84:85], v21, off offset:2048            // 0000000458E8: DC6A0800 007C1554
	global_store_b32 v[84:85], v22, off offset:3072            // 0000000458F0: DC6A0C00 007C1654
	global_store_b32 v[163:164], v23, off offset:1024          // 0000000458F8: DC6A0400 007C17A3
	global_store_b32 v[163:164], v24, off offset:2048          // 000000045900: DC6A0800 007C18A3
	global_store_b32 v[163:164], v26, off offset:3072          // 000000045908: DC6A0C00 007C1AA3
	global_store_b32 v[82:83], v16, off                        // 000000045910: DC6A0000 007C1052
	global_store_b32 v[82:83], v18, off offset:1024            // 000000045918: DC6A0400 007C1252
	global_store_b32 v[82:83], v19, off offset:2048            // 000000045920: DC6A0800 007C1352
	global_store_b32 v[86:87], v4, off offset:-4096            // 000000045928: DC6A1000 007C0456
	global_store_b32 v[86:87], v5, off                         // 000000045930: DC6A0000 007C0556
	global_store_b32 v[153:154], v6, off offset:-4096          // 000000045938: DC6A1000 007C0699
	global_store_b32 v[153:154], v7, off                       // 000000045940: DC6A0000 007C0799
	global_store_b32 v[88:89], v8, off offset:-4096            // 000000045948: DC6A1000 007C0858
	global_store_b32 v[88:89], v10, off                        // 000000045950: DC6A0000 007C0A58
	global_store_b32 v[82:83], v13, off offset:3072            // 000000045958: DC6A0C00 007C0D52
	s_cmp_lg_u32 s14, s54                                      // 000000045960: BF07360E
	s_cbranch_scc1 61161                                       // 000000045964: BFA2EEE9 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	v_ashrrev_i32_e32 v3, 31, v2                               // 000000045968: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000004596C: BF870091
	.long 0xd73c0002                                           // 000000045970: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000045974: 02020482
	.long 0xd7006a02                                           // 000000045978: D7006A02
	v_cndmask_b32_e32 v1, s47, v2, vcc_lo                      // 00000004597C: 0202042F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000045980: BF870111
	v_add_co_ci_u32_e64 v3, null, s7, v3, vcc_lo               // 000000045984: D5207C03 01AA0607
	.long 0xd7006a52                                           // 00000004598C: D7006A52
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 000000045990: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000045998: BF8700A1
	v_add_co_ci_u32_e64 v83, null, 0, v3, vcc_lo               // 00000004599C: D5207C53 01AA0680
	.long 0xd7006a54                                           // 0000000459A4: D7006A54
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 0000000459A8: 0201FF02
	.long 0x00002000                                           // 0000000459AC: 00002000
	v_add_co_ci_u32_e64 v85, null, 0, v3, vcc_lo               // 0000000459B0: D5207C55 01AA0680
	.long 0xd7006a56                                           // 0000000459B8: D7006A56
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 0000000459BC: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000459C4: BF870001
	v_add_co_ci_u32_e64 v87, null, 0, v3, vcc_lo               // 0000000459C8: D5207C57 01AA0680
	s_clause 0x7                                               // 0000000459D0: BF850007
	global_store_b32 v[2:3], v69, off                          // 0000000459D4: DC6A0000 007C4502
	global_store_b32 v[2:3], v70, off offset:1024              // 0000000459DC: DC6A0400 007C4602
	global_store_b32 v[2:3], v71, off offset:2048              // 0000000459E4: DC6A0800 007C4702
	global_store_b32 v[2:3], v72, off offset:3072              // 0000000459EC: DC6A0C00 007C4802
	global_store_b32 v[82:83], v73, off offset:1024            // 0000000459F4: DC6A0400 007C4952
	global_store_b32 v[82:83], v151, off offset:2048           // 0000000459FC: DC6A0800 007C9752
	global_store_b32 v[82:83], v152, off offset:3072           // 000000045A04: DC6A0C00 007C9852
	global_store_b32 v[86:87], v68, off offset:1024            // 000000045A0C: DC6A0400 007C4456
	.long 0xd7006a44                                           // 000000045A14: D7006A44
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 000000045A18: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000045A20: BF8700A1
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 000000045A24: D5207C45 01AA0680
	.long 0xd7006a46                                           // 000000045A2C: D7006A46
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000045A30: 0201FF02
	.long 0x00004000                                           // 000000045A34: 00004000
	v_add_co_ci_u32_e64 v71, null, 0, v3, vcc_lo               // 000000045A38: D5207C47 01AA0680
	.long 0xd7006a48                                           // 000000045A40: D7006A48
	v_cndmask_b32_e32 v1, 0x4000, v2, vcc_lo                   // 000000045A44: 020204FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000045A4C: BF870001
	v_add_co_ci_u32_e64 v73, null, 0, v3, vcc_lo               // 000000045A50: D5207C49 01AA0680
	s_clause 0x7                                               // 000000045A58: BF850007
	global_store_b32 v[86:87], v62, off offset:2048            // 000000045A5C: DC6A0800 007C3E56
	global_store_b32 v[86:87], v63, off offset:3072            // 000000045A64: DC6A0C00 007C3F56
	global_store_b32 v[68:69], v64, off offset:1024            // 000000045A6C: DC6A0400 007C4044
	global_store_b32 v[68:69], v66, off offset:2048            // 000000045A74: DC6A0800 007C4244
	global_store_b32 v[68:69], v67, off offset:3072            // 000000045A7C: DC6A0C00 007C4344
	global_store_b32 v[72:73], v59, off offset:1024            // 000000045A84: DC6A0400 007C3B48
	global_store_b32 v[72:73], v60, off offset:2048            // 000000045A8C: DC6A0800 007C3C48
	global_store_b32 v[72:73], v61, off offset:3072            // 000000045A94: DC6A0C00 007C3D48
	.long 0xd7006a3b                                           // 000000045A9C: D7006A3B
	v_cndmask_b32_e32 v1, 0x5000, v2, vcc_lo                   // 000000045AA0: 020204FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000045AA8: BF8700A1
	v_add_co_ci_u32_e64 v60, null, 0, v3, vcc_lo               // 000000045AAC: D5207C3C 01AA0680
	.long 0xd7006a3d                                           // 000000045AB4: D7006A3D
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000045AB8: 0201FF02
	.long 0x00006000                                           // 000000045ABC: 00006000
	v_add_co_ci_u32_e64 v62, null, 0, v3, vcc_lo               // 000000045AC0: D5207C3E 01AA0680
	.long 0xd7006a3f                                           // 000000045AC8: D7006A3F
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 000000045ACC: 020204FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000045AD4: BF8700A1
	v_add_co_ci_u32_e64 v64, null, 0, v3, vcc_lo               // 000000045AD8: D5207C40 01AA0680
	.long 0xd7006a42                                           // 000000045AE0: D7006A42
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 000000045AE4: 020204FF 00007000
	v_add_co_ci_u32_e64 v67, null, 0, v3, vcc_lo               // 000000045AEC: D5207C43 01AA0680
	.long 0xd7006a44                                           // 000000045AF4: D7006A44
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000045AF8: 0201FF02
	.long 0x00008000                                           // 000000045AFC: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000045B00: BF870001
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 000000045B04: D5207C45 01AA0680
	s_clause 0x7                                               // 000000045B0C: BF850007
	global_store_b32 v[59:60], v52, off offset:1024            // 000000045B10: DC6A0400 007C343B
	global_store_b32 v[59:60], v53, off offset:2048            // 000000045B18: DC6A0800 007C353B
	global_store_b32 v[59:60], v54, off offset:3072            // 000000045B20: DC6A0C00 007C363B
	global_store_b32 v[63:64], v55, off offset:1024            // 000000045B28: DC6A0400 007C373F
	global_store_b32 v[63:64], v56, off offset:2048            // 000000045B30: DC6A0800 007C383F
	global_store_b32 v[63:64], v58, off offset:3072            // 000000045B38: DC6A0C00 007C3A3F
	global_store_b32 v[66:67], v50, off offset:1024            // 000000045B40: DC6A0400 007C3242
	global_store_b32 v[66:67], v51, off offset:2048            // 000000045B48: DC6A0800 007C3342
	.long 0xd7006a32                                           // 000000045B50: D7006A32
	v_cndmask_b32_e32 v1, 0x8000, v2, vcc_lo                   // 000000045B54: 020204FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000045B5C: BF8700A1
	v_add_co_ci_u32_e64 v51, null, 0, v3, vcc_lo               // 000000045B60: D5207C33 01AA0680
	.long 0xd7006a34                                           // 000000045B68: D7006A34
	v_cndmask_b32_e32 v1, 0x9000, v2, vcc_lo                   // 000000045B6C: 020204FF 00009000
	v_add_co_ci_u32_e64 v53, null, 0, v3, vcc_lo               // 000000045B74: D5207C35 01AA0680
	.long 0xd7006a36                                           // 000000045B7C: D7006A36
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000045B80: 0201FF02
	.long 0x0000a000                                           // 000000045B84: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000045B88: BF8700A1
	v_add_co_ci_u32_e64 v55, null, 0, v3, vcc_lo               // 000000045B8C: D5207C37 01AA0680
	.long 0xd7006a3a                                           // 000000045B94: D7006A3A
	v_cndmask_b32_e32 v1, 0xa000, v2, vcc_lo                   // 000000045B98: 020204FF 0000A000
	v_add_co_ci_u32_e64 v59, null, 0, v3, vcc_lo               // 000000045BA0: D5207C3B 01AA0680
	s_clause 0x7                                               // 000000045BA8: BF850007
	global_store_b32 v[66:67], v40, off offset:3072            // 000000045BAC: DC6A0C00 007C2842
	global_store_b32 v[50:51], v43, off offset:1024            // 000000045BB4: DC6A0400 007C2B32
	global_store_b32 v[50:51], v44, off offset:2048            // 000000045BBC: DC6A0800 007C2C32
	global_store_b32 v[50:51], v45, off offset:3072            // 000000045BC4: DC6A0C00 007C2D32
	global_store_b32 v[52:53], v46, off offset:1024            // 000000045BCC: DC6A0400 007C2E34
	global_store_b32 v[52:53], v47, off offset:2048            // 000000045BD4: DC6A0800 007C2F34
	global_store_b32 v[52:53], v48, off offset:3072            // 000000045BDC: DC6A0C00 007C3034
	global_store_b32 v[58:59], v42, off offset:1024            // 000000045BE4: DC6A0400 007C2A3A
	.long 0xd7006a2a                                           // 000000045BEC: D7006A2A
	v_cndmask_b32_e32 v1, 0xb000, v2, vcc_lo                   // 000000045BF0: 020204FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000045BF8: BF8700A1
	v_add_co_ci_u32_e64 v43, null, 0, v3, vcc_lo               // 000000045BFC: D5207C2B 01AA0680
	.long 0xd7006a2c                                           // 000000045C04: D7006A2C
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000045C08: 0201FF02
	.long 0x0000c000                                           // 000000045C0C: 0000C000
	v_add_co_ci_u32_e64 v45, null, 0, v3, vcc_lo               // 000000045C10: D5207C2D 01AA0680
	.long 0xd7006a2e                                           // 000000045C18: D7006A2E
	v_cndmask_b32_e32 v1, 0xc000, v2, vcc_lo                   // 000000045C1C: 020204FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000045C24: BF870001
	v_add_co_ci_u32_e64 v47, null, 0, v3, vcc_lo               // 000000045C28: D5207C2F 01AA0680
	s_clause 0x7                                               // 000000045C30: BF850007
	global_store_b32 v[58:59], v35, off offset:2048            // 000000045C34: DC6A0800 007C233A
	global_store_b32 v[58:59], v36, off offset:3072            // 000000045C3C: DC6A0C00 007C243A
	global_store_b32 v[42:43], v37, off offset:1024            // 000000045C44: DC6A0400 007C252A
	global_store_b32 v[42:43], v38, off offset:2048            // 000000045C4C: DC6A0800 007C262A
	global_store_b32 v[42:43], v39, off offset:3072            // 000000045C54: DC6A0C00 007C272A
	global_store_b32 v[46:47], v31, off offset:1024            // 000000045C5C: DC6A0400 007C1F2E
	global_store_b32 v[46:47], v32, off offset:2048            // 000000045C64: DC6A0800 007C202E
	global_store_b32 v[46:47], v34, off offset:3072            // 000000045C6C: DC6A0C00 007C222E
	.long 0xd7006a1f                                           // 000000045C74: D7006A1F
	v_cndmask_b32_e32 v1, 0xd000, v2, vcc_lo                   // 000000045C78: 020204FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000045C80: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v3, vcc_lo               // 000000045C84: D5207C20 01AA0680
	.long 0xd7006a22                                           // 000000045C8C: D7006A22
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000045C90: 0201FF02
	.long 0x0000e000                                           // 000000045C94: 0000E000
	v_add_co_ci_u32_e64 v35, null, 0, v3, vcc_lo               // 000000045C98: D5207C23 01AA0680
	.long 0xd7006a24                                           // 000000045CA0: D7006A24
	v_cndmask_b32_e32 v1, 0xe000, v2, vcc_lo                   // 000000045CA4: 020204FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000045CAC: BF870001
	v_add_co_ci_u32_e64 v37, null, 0, v3, vcc_lo               // 000000045CB0: D5207C25 01AA0680
	.long 0xd7006a02                                           // 000000045CB8: D7006A02
	v_cndmask_b32_e32 v1, 0xf000, v2, vcc_lo                   // 000000045CBC: 020204FF 0000F000
	s_clause 0x7                                               // 000000045CC4: BF850007
	global_store_b32 v[68:69], v11, off offset:-4096           // 000000045CC8: DC6A1000 007C0B44
	global_store_b32 v[68:69], v12, off                        // 000000045CD0: DC6A0000 007C0C44
	global_store_b32 v[54:55], v14, off offset:-4096           // 000000045CD8: DC6A1000 007C0E36
	global_store_b32 v[54:55], v15, off                        // 000000045CE0: DC6A0000 007C0F36
	global_store_b32 v[44:45], v27, off offset:-4096           // 000000045CE8: DC6A1000 007C1B2C
	global_store_b32 v[44:45], v28, off                        // 000000045CF0: DC6A0000 007C1C2C
	global_store_b32 v[34:35], v29, off offset:-4096           // 000000045CF8: DC6A1000 007C1D22
	global_store_b32 v[34:35], v30, off                        // 000000045D00: DC6A0000 007C1E22
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000045D08: D5207C03 01AA0680
	s_clause 0xf                                               // 000000045D10: BF85000F
	global_store_b32 v[31:32], v20, off offset:1024            // 000000045D14: DC6A0400 007C141F
	global_store_b32 v[31:32], v21, off offset:2048            // 000000045D1C: DC6A0800 007C151F
	global_store_b32 v[31:32], v22, off offset:3072            // 000000045D24: DC6A0C00 007C161F
	global_store_b32 v[36:37], v23, off offset:1024            // 000000045D2C: DC6A0400 007C1724
	global_store_b32 v[36:37], v24, off offset:2048            // 000000045D34: DC6A0800 007C1824
	global_store_b32 v[36:37], v26, off offset:3072            // 000000045D3C: DC6A0C00 007C1A24
	global_store_b32 v[2:3], v16, off                          // 000000045D44: DC6A0000 007C1002
	global_store_b32 v[2:3], v18, off offset:1024              // 000000045D4C: DC6A0400 007C1202
	global_store_b32 v[2:3], v19, off offset:2048              // 000000045D54: DC6A0800 007C1302
	global_store_b32 v[84:85], v4, off offset:-4096            // 000000045D5C: DC6A1000 007C0454
	global_store_b32 v[84:85], v5, off                         // 000000045D64: DC6A0000 007C0554
	global_store_b32 v[70:71], v6, off offset:-4096            // 000000045D6C: DC6A1000 007C0646
	global_store_b32 v[70:71], v7, off                         // 000000045D74: DC6A0000 007C0746
	global_store_b32 v[61:62], v8, off offset:-4096            // 000000045D7C: DC6A1000 007C083D
	global_store_b32 v[61:62], v10, off                        // 000000045D84: DC6A0000 007C0A3D
	global_store_b32 v[2:3], v13, off offset:3072              // 000000045D8C: DC6A0C00 007C0D02
	s_branch 60893                                             // 000000045D94: BFA0EDDD <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	v_mov_b32_e32 v54, v41                                     // 000000045D98: 7E6C0329
	v_mov_b32_e32 v53, v33                                     // 000000045D9C: 7E6A0321
	v_mov_b32_e32 v52, v25                                     // 000000045DA0: 7E680319
	v_mov_b32_e32 v51, v17                                     // 000000045DA4: 7E660311
	v_mov_b32_e32 v50, v9                                      // 000000045DA8: 7E640309
	v_mov_b32_e32 v58, v49                                     // 000000045DAC: 7E740331
	v_mov_b32_e32 v152, v57                                    // 000000045DB0: 7F300339
	v_mov_b32_e32 v151, v65                                    // 000000045DB4: 7F2E0341
	s_mov_b32 s7, 0                                            // 000000045DB8: BE870080
	s_branch 1                                                 // 000000045DBC: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x51c4>
	s_mov_b64 s[6:7], 0                                        // 000000045DC0: BE860180
	v_dual_mul_f32 v3, 0x3b800000, v139 :: v_dual_mul_f32 v4, 0x3b800000, v138// 000000045DC4: C8C716FF 030514FF 3B800000
	v_dual_mul_f32 v5, 0x3b800000, v137 :: v_dual_mul_f32 v6, 0x3b800000, v136// 000000045DD0: C8C712FF 050710FF 3B800000
	.long 0xd7006a01                                           // 000000045DDC: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000045DE0: 0201FFBB
	.long 0x00002000                                           // 000000045DE4: 00002000
	v_dual_mul_f32 v7, 0x3b800000, v135 :: v_dual_mul_f32 v8, 0x3b800000, v134// 000000045DE8: C8C70EFF 07090CFF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 000000045DF4: D5207C02 01AB7880
	v_dual_mul_f32 v9, 0x3b800000, v133 :: v_dual_mul_f32 v10, 0x3b800000, v54// 000000045DFC: C8C70AFF 090A6CFF 3B800000
	s_clause 0x7                                               // 000000045E08: BF850007
	global_store_b32 v[187:188], v3, off                       // 000000045E0C: DC6A0000 007C03BB
	global_store_b32 v[187:188], v4, off offset:1024           // 000000045E14: DC6A0400 007C04BB
	global_store_b32 v[187:188], v5, off offset:2048           // 000000045E1C: DC6A0800 007C05BB
	global_store_b32 v[187:188], v6, off offset:3072           // 000000045E24: DC6A0C00 007C06BB
	global_store_b32 v[1:2], v7, off offset:-4096              // 000000045E2C: DC6A1000 007C0701
	global_store_b32 v[1:2], v8, off offset:-3072              // 000000045E34: DC6A1400 007C0801
	global_store_b32 v[1:2], v9, off offset:-2048              // 000000045E3C: DC6A1800 007C0901
	global_store_b32 v[1:2], v10, off offset:-1024             // 000000045E44: DC6A1C00 007C0A01
	v_dual_mul_f32 v5, 0x3b800000, v132 :: v_dual_mul_f32 v6, 0x3b800000, v131// 000000045E4C: C8C708FF 050706FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v130 :: v_dual_mul_f32 v8, 0x3b800000, v129// 000000045E58: C8C704FF 070902FF 3B800000
	.long 0xd7006a03                                           // 000000045E64: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000045E68: 0201FFBB
	.long 0x00004000                                           // 000000045E6C: 00004000
	v_dual_mul_f32 v9, 0x3b800000, v128 :: v_dual_mul_f32 v10, 0x3b800000, v127// 000000045E70: C8C700FF 090AFEFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000045E7C: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v126 :: v_dual_mul_f32 v12, 0x3b800000, v53// 000000045E84: C8C6FCFF 0B0C6AFF 3B800000
	s_clause 0x7                                               // 000000045E90: BF850007
	global_store_b32 v[1:2], v5, off                           // 000000045E94: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 000000045E9C: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 000000045EA4: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 000000045EAC: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 000000045EB4: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 000000045EBC: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 000000045EC4: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 000000045ECC: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v125 :: v_dual_mul_f32 v6, 0x3b800000, v124// 000000045ED4: C8C6FAFF 0506F8FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v123 :: v_dual_mul_f32 v8, 0x3b800000, v122// 000000045EE0: C8C6F6FF 0708F4FF 3B800000
	.long 0xd7006a01                                           // 000000045EEC: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000045EF0: 0201FFBB
	.long 0x00006000                                           // 000000045EF4: 00006000
	v_dual_mul_f32 v9, 0x3b800000, v121 :: v_dual_mul_f32 v10, 0x3b800000, v120// 000000045EF8: C8C6F2FF 090AF0FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 000000045F04: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v119 :: v_dual_mul_f32 v12, 0x3b800000, v52// 000000045F0C: C8C6EEFF 0B0C68FF 3B800000
	s_clause 0x7                                               // 000000045F18: BF850007
	global_store_b32 v[3:4], v5, off                           // 000000045F1C: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 000000045F24: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 000000045F2C: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 000000045F34: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 000000045F3C: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 000000045F44: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000045F4C: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 000000045F54: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v118 :: v_dual_mul_f32 v6, 0x3b800000, v117// 000000045F5C: C8C6ECFF 0506EAFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v116 :: v_dual_mul_f32 v8, 0x3b800000, v115// 000000045F68: C8C6E8FF 0708E6FF 3B800000
	.long 0xd7006a03                                           // 000000045F74: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000045F78: 0201FFBB
	.long 0x00008000                                           // 000000045F7C: 00008000
	v_dual_mul_f32 v9, 0x3b800000, v114 :: v_dual_mul_f32 v10, 0x3b800000, v113// 000000045F80: C8C6E4FF 090AE2FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000045F8C: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v112 :: v_dual_mul_f32 v12, 0x3b800000, v51// 000000045F94: C8C6E0FF 0B0C66FF 3B800000
	s_clause 0x7                                               // 000000045FA0: BF850007
	global_store_b32 v[1:2], v5, off                           // 000000045FA4: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 000000045FAC: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 000000045FB4: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 000000045FBC: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 000000045FC4: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 000000045FCC: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 000000045FD4: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 000000045FDC: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v111 :: v_dual_mul_f32 v6, 0x3b800000, v110// 000000045FE4: C8C6DEFF 0506DCFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v109 :: v_dual_mul_f32 v8, 0x3b800000, v108// 000000045FF0: C8C6DAFF 0708D8FF 3B800000
	.long 0xd7006a01                                           // 000000045FFC: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000046000: 0201FFBB
	.long 0x0000a000                                           // 000000046004: 0000A000
	v_dual_mul_f32 v9, 0x3b800000, v107 :: v_dual_mul_f32 v10, 0x3b800000, v106// 000000046008: C8C6D6FF 090AD4FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 000000046014: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v105 :: v_dual_mul_f32 v12, 0x3b800000, v50// 00000004601C: C8C6D2FF 0B0C64FF 3B800000
	s_clause 0x7                                               // 000000046028: BF850007
	global_store_b32 v[3:4], v5, off                           // 00000004602C: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 000000046034: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 00000004603C: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 000000046044: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 00000004604C: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 000000046054: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 00000004605C: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 000000046064: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v104 :: v_dual_mul_f32 v6, 0x3b800000, v103// 00000004606C: C8C6D0FF 0506CEFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v102 :: v_dual_mul_f32 v8, 0x3b800000, v101// 000000046078: C8C6CCFF 0708CAFF 3B800000
	.long 0xd7006a03                                           // 000000046084: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000046088: 0201FFBB
	.long 0x0000c000                                           // 00000004608C: 0000C000
	v_dual_mul_f32 v9, 0x3b800000, v100 :: v_dual_mul_f32 v10, 0x3b800000, v99// 000000046090: C8C6C8FF 090AC6FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 00000004609C: D5207C04 01AB7880
	v_mul_f32_e32 v11, 0x3b800000, v98                         // 0000000460A4: 1016C4FF 3B800000
	v_mul_f32_e32 v12, 0x3b800000, v58                         // 0000000460AC: 101874FF 3B800000
	s_clause 0x7                                               // 0000000460B4: BF850007
	global_store_b32 v[1:2], v5, off                           // 0000000460B8: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 0000000460C0: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 0000000460C8: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 0000000460D0: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 0000000460D8: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 0000000460E0: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 0000000460E8: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 0000000460F0: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v97 :: v_dual_mul_f32 v6, 0x3b800000, v96// 0000000460F8: C8C6C2FF 0506C0FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v95 :: v_dual_mul_f32 v8, 0x3b800000, v94// 000000046104: C8C6BEFF 0708BCFF 3B800000
	.long 0xd7006a01                                           // 000000046110: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000046114: 0201FFBB
	.long 0x0000e000                                           // 000000046118: 0000E000
	v_dual_mul_f32 v9, 0x3b800000, v93 :: v_dual_mul_f32 v10, 0x3b800000, v92// 00000004611C: C8C6BAFF 090AB8FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 000000046128: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v91 :: v_dual_mul_f32 v12, 0x3b800000, v152// 000000046130: C8C6B6FF 0B0D30FF 3B800000
	s_clause 0x7                                               // 00000004613C: BF850007
	global_store_b32 v[3:4], v5, off                           // 000000046140: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 000000046148: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 000000046150: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 000000046158: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 000000046160: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 000000046168: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000046170: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 000000046178: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v90 :: v_dual_mul_f32 v6, 0x3b800000, v141// 000000046180: C8C6B4FF 05071AFF 3B800000
	v_and_or_b32 v0, v0, 31, s5                                // 00000004618C: D6570000 00153F00
	v_dual_mul_f32 v7, 0x3b800000, v150 :: v_dual_mul_f32 v10, 0x3b800000, v189// 000000046194: C8C72CFF 070B7AFF 3B800000
	.long 0xd7006a03                                           // 0000000461A0: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000461A4: 0201FFBB
	.long 0x0000fc00                                           // 0000000461A8: 0000FC00
	v_dual_mul_f32 v8, 0x3b800000, v142 :: v_dual_mul_f32 v9, 0x3b800000, v191// 0000000461AC: C8C71CFF 08097EFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 0000000461B8: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v190 :: v_dual_mul_f32 v12, 0x3b800000, v151// 0000000461C0: C8C77CFF 0B0D2EFF 3B800000
	s_clause 0x7                                               // 0000000461CC: BF850007
	global_store_b32 v[1:2], v5, off                           // 0000000461D0: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 0000000461D8: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 0000000461E0: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 0000000461E8: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-3072              // 0000000461F0: DC6A1400 007C0903
	global_store_b32 v[3:4], v10, off offset:-2048             // 0000000461F8: DC6A1800 007C0A03
	global_store_b32 v[3:4], v11, off offset:-1024             // 000000046200: DC6A1C00 007C0B03
	global_store_b32 v[3:4], v12, off                          // 000000046208: DC6A0000 007C0C03
	s_mov_b32 s2, exec_lo                                      // 000000046210: BE82007E
	v_cmpx_eq_u32_e32 0, v0                                    // 000000046214: 7D940080
	s_cbranch_execz 8                                          // 000000046218: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi6ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x563c>
	s_load_b64 s[0:1], s[0:1], 0x40                            // 00000004621C: F4040000 F8000040
	v_mov_b32_e32 v0, s6                                       // 000000046224: 7E000206
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, s7              // 000000046228: CA100080 02000007
	s_waitcnt lgkmcnt(0)                                       // 000000046230: BF89FC07
	global_store_b64 v2, v[0:1], s[0:1] offset:40              // 000000046234: DC6E0028 00000002
	s_endpgm                                                   // 00000004623C: BFB00000
		...

