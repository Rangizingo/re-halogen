0000000000056800 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE>:
; _ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE():
	s_clause 0x1                                               // 000000056800: BF850001
	s_load_b256 s[20:27], s[0:1], 0x20                         // 000000056804: F40C0500 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 00000005680C: F40C0200 F8000000
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 5, v0       // 000000056814: CA220080 02020085
	s_ashr_i32 s3, s2, 31                                      // 00000005681C: 86039F02
	s_mov_b32 s28, 0                                           // 000000056820: BE9C0080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056824: BF870001
	v_and_b32_e32 v3, 0x200, v3                                // 000000056828: 360606FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 000000056830: BF89FC07
	s_load_b32 s16, s[20:21], null                             // 000000056834: F400040A F8000000
	v_readfirstlane_b32 s20, v0                                // 00000005683C: 7E280500
	s_lshl_b64 s[4:5], s[22:23], 2                             // 000000056840: 84848216
	s_lshr_b32 s21, s20, 5                                     // 000000056844: 85158514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000056848: BF8704D9
	s_lshl_b32 s33, s21, 4                                     // 00000005684C: 84218415
	s_add_u32 s4, s14, s4                                      // 000000056850: 8004040E
	v_and_or_b32 v1, v0, 15, s33                               // 000000056854: D6570001 00851F00
	s_addc_u32 s5, s15, s5                                     // 00000005685C: 8205050F
	s_lshl_b64 s[6:7], s[2:3], 16                              // 000000056860: 84869002
	s_add_u32 s4, s4, s6                                       // 000000056864: 80040604
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056868: BF870001
	.long 0xd73c0001                                           // 00000005686C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000056870: 02020282
	s_addc_u32 s5, s5, s7                                      // 000000056874: 82050705
	s_waitcnt lgkmcnt(0)                                       // 000000056878: BF89FC07
	s_mul_i32 s14, s16, 0x9000000                              // 00000005687C: 960EFF10 09000000
	s_mul_hi_i32 s15, s16, 0x9000000                           // 000000056884: 970FFF10 09000000
	s_add_u32 s4, s4, s14                                      // 00000005688C: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000056890: 82050F05
	.long 0xd7006a01                                           // 000000056894: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000056898: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000005689C: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000000568A0: D5207C02 01AA0405
	s_or_b32 s5, s21, s2                                       // 0000000568A8: 8C050215
	.long 0xd7006abb                                           // 0000000568AC: D7006ABB
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000000568B0: 02020701
	v_add_co_ci_u32_e64 v188, null, 0, v2, vcc_lo              // 0000000568B4: D5207CBC 01AA0480
	s_cselect_b32 s38, 0, -1                                   // 0000000568BC: 9826C180
	.long 0xd7006a09                                           // 0000000568C0: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v187, vcc_lo                 // 0000000568C4: 020376FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000568CC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v188, vcc_lo             // 0000000568D0: D5207C0A 01AB7880
	.long 0xd7006a34                                           // 0000000568D8: D7006A34
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000568DC: 0201FFBB
	.long 0x00002000                                           // 0000000568E0: 00002000
	v_add_co_ci_u32_e64 v53, null, 0, v188, vcc_lo             // 0000000568E4: D5207C35 01AB7880
	.long 0xd7006a0d                                           // 0000000568EC: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v187, vcc_lo                 // 0000000568F0: 020376FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000568F8: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v188, vcc_lo             // 0000000568FC: D5207C0E 01AB7880
	.long 0xd7006a0f                                           // 000000056904: D7006A0F
	v_cndmask_b32_e32 v1, 0x3000, v187, vcc_lo                 // 000000056908: 020376FF 00003000
	v_add_co_ci_u32_e64 v16, null, 0, v188, vcc_lo             // 000000056910: D5207C10 01AB7880
	.long 0xd7006a3c                                           // 000000056918: D7006A3C
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000005691C: 0201FFBB
	.long 0x00004000                                           // 000000056920: 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056924: BF870001
	v_add_co_ci_u32_e64 v61, null, 0, v188, vcc_lo             // 000000056928: D5207C3D 01AB7880
	.long 0xd7006a11                                           // 000000056930: D7006A11
	v_cndmask_b32_e32 v1, 0x4000, v187, vcc_lo                 // 000000056934: 020376FF 00004000
	s_clause 0x7                                               // 00000005693C: BF850007
	global_load_b32 v5, v[187:188], off                        // 000000056940: DC520000 057C00BB
	global_load_b32 v6, v[187:188], off offset:1024            // 000000056948: DC520400 067C00BB
	global_load_b32 v7, v[187:188], off offset:2048            // 000000056950: DC520800 077C00BB
	global_load_b32 v8, v[187:188], off offset:3072            // 000000056958: DC520C00 087C00BB
	global_load_b32 v2, v[9:10], off offset:1024               // 000000056960: DC520400 027C0009
	global_load_b32 v3, v[9:10], off offset:2048               // 000000056968: DC520800 037C0009
	global_load_b32 v4, v[9:10], off offset:3072               // 000000056970: DC520C00 047C0009
	global_load_b32 v1, v[13:14], off offset:1024              // 000000056978: DC520400 017C000D
	v_add_co_ci_u32_e64 v18, null, 0, v188, vcc_lo             // 000000056980: D5207C12 01AB7880
	s_clause 0x7                                               // 000000056988: BF850007
	global_load_b32 v12, v[13:14], off offset:2048             // 00000005698C: DC520800 0C7C000D
	global_load_b32 v13, v[13:14], off offset:3072             // 000000056994: DC520C00 0D7C000D
	global_load_b32 v9, v[15:16], off offset:1024              // 00000005699C: DC520400 097C000F
	global_load_b32 v10, v[15:16], off offset:2048             // 0000000569A4: DC520800 0A7C000F
	global_load_b32 v11, v[15:16], off offset:3072             // 0000000569AC: DC520C00 0B7C000F
	global_load_b32 v14, v[17:18], off offset:1024             // 0000000569B4: DC520400 0E7C0011
	global_load_b32 v15, v[17:18], off offset:2048             // 0000000569BC: DC520800 0F7C0011
	global_load_b32 v16, v[17:18], off offset:3072             // 0000000569C4: DC520C00 107C0011
	.long 0xd7006a11                                           // 0000000569CC: D7006A11
	v_cndmask_b32_e32 v1, 0x5000, v187, vcc_lo                 // 0000000569D0: 020376FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000569D8: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v188, vcc_lo             // 0000000569DC: D5207C12 01AB7880
	.long 0xd7006a41                                           // 0000000569E4: D7006A41
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000569E8: 0201FFBB
	.long 0x00006000                                           // 0000000569EC: 00006000
	v_add_co_ci_u32_e64 v66, null, 0, v188, vcc_lo             // 0000000569F0: D5207C42 01AB7880
	.long 0xd7006a17                                           // 0000000569F8: D7006A17
	v_cndmask_b32_e32 v1, 0x6000, v187, vcc_lo                 // 0000000569FC: 020376FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056A04: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v188, vcc_lo             // 000000056A08: D5207C18 01AB7880
	.long 0xd7006a19                                           // 000000056A10: D7006A19
	v_cndmask_b32_e32 v1, 0x7000, v187, vcc_lo                 // 000000056A14: 020376FF 00007000
	v_add_co_ci_u32_e64 v26, null, 0, v188, vcc_lo             // 000000056A1C: D5207C1A 01AB7880
	.long 0xd7006a29                                           // 000000056A24: D7006A29
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000056A28: 0201FFBB
	.long 0x00008000                                           // 000000056A2C: 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056A30: BF8700A1
	v_add_co_ci_u32_e64 v42, null, 0, v188, vcc_lo             // 000000056A34: D5207C2A 01AB7880
	.long 0xd7006a20                                           // 000000056A3C: D7006A20
	v_cndmask_b32_e32 v1, 0x8000, v187, vcc_lo                 // 000000056A40: 020376FF 00008000
	v_add_co_ci_u32_e64 v33, null, 0, v188, vcc_lo             // 000000056A48: D5207C21 01AB7880
	.long 0xd7006a22                                           // 000000056A50: D7006A22
	v_cndmask_b32_e32 v1, 0x9000, v187, vcc_lo                 // 000000056A54: 020376FF 00009000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056A5C: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v188, vcc_lo             // 000000056A60: D5207C23 01AB7880
	.long 0xd7006a2b                                           // 000000056A68: D7006A2B
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000056A6C: 0201FFBB
	.long 0x0000a000                                           // 000000056A70: 0000A000
	v_add_co_ci_u32_e64 v44, null, 0, v188, vcc_lo             // 000000056A74: D5207C2C 01AB7880
	.long 0xd7006a25                                           // 000000056A7C: D7006A25
	v_cndmask_b32_e32 v1, 0xa000, v187, vcc_lo                 // 000000056A80: 020376FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056A88: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v188, vcc_lo             // 000000056A8C: D5207C26 01AB7880
	.long 0xd7006a27                                           // 000000056A94: D7006A27
	v_cndmask_b32_e32 v1, 0xb000, v187, vcc_lo                 // 000000056A98: 020376FF 0000B000
	v_add_co_ci_u32_e64 v40, null, 0, v188, vcc_lo             // 000000056AA0: D5207C28 01AB7880
	.long 0xd7006a2d                                           // 000000056AA8: D7006A2D
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000056AAC: 0201FFBB
	.long 0x0000c000                                           // 000000056AB0: 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056AB4: BF8700A1
	v_add_co_ci_u32_e64 v46, null, 0, v188, vcc_lo             // 000000056AB8: D5207C2E 01AB7880
	.long 0xd7006a2f                                           // 000000056AC0: D7006A2F
	v_cndmask_b32_e32 v1, 0xc000, v187, vcc_lo                 // 000000056AC4: 020376FF 0000C000
	v_add_co_ci_u32_e64 v48, null, 0, v188, vcc_lo             // 000000056ACC: D5207C30 01AB7880
	.long 0xd7006a36                                           // 000000056AD4: D7006A36
	v_cndmask_b32_e32 v1, 0xd000, v187, vcc_lo                 // 000000056AD8: 020376FF 0000D000
	s_clause 0x17                                              // 000000056AE0: BF850017
	global_load_b32 v20, v[17:18], off offset:1024             // 000000056AE4: DC520400 147C0011
	global_load_b32 v21, v[17:18], off offset:2048             // 000000056AEC: DC520800 157C0011
	global_load_b32 v22, v[17:18], off offset:3072             // 000000056AF4: DC520C00 167C0011
	global_load_b32 v17, v[23:24], off offset:1024             // 000000056AFC: DC520400 117C0017
	global_load_b32 v18, v[23:24], off offset:2048             // 000000056B04: DC520800 127C0017
	global_load_b32 v19, v[23:24], off offset:3072             // 000000056B0C: DC520C00 137C0017
	global_load_b32 v23, v[25:26], off offset:1024             // 000000056B14: DC520400 177C0019
	global_load_b32 v24, v[25:26], off offset:2048             // 000000056B1C: DC520800 187C0019
	global_load_b32 v31, v[25:26], off offset:3072             // 000000056B24: DC520C00 1F7C0019
	global_load_b32 v28, v[32:33], off offset:1024             // 000000056B2C: DC520400 1C7C0020
	global_load_b32 v29, v[32:33], off offset:2048             // 000000056B34: DC520800 1D7C0020
	global_load_b32 v30, v[32:33], off offset:3072             // 000000056B3C: DC520C00 1E7C0020
	global_load_b32 v25, v[34:35], off offset:1024             // 000000056B44: DC520400 197C0022
	global_load_b32 v26, v[34:35], off offset:2048             // 000000056B4C: DC520800 1A7C0022
	global_load_b32 v27, v[34:35], off offset:3072             // 000000056B54: DC520C00 1B7C0022
	global_load_b32 v32, v[37:38], off offset:1024             // 000000056B5C: DC520400 207C0025
	global_load_b32 v36, v[37:38], off offset:2048             // 000000056B64: DC520800 247C0025
	global_load_b32 v37, v[37:38], off offset:3072             // 000000056B6C: DC520C00 257C0025
	global_load_b32 v33, v[39:40], off offset:1024             // 000000056B74: DC520400 217C0027
	global_load_b32 v34, v[39:40], off offset:2048             // 000000056B7C: DC520800 227C0027
	global_load_b32 v35, v[39:40], off offset:3072             // 000000056B84: DC520C00 237C0027
	global_load_b32 v38, v[47:48], off offset:1024             // 000000056B8C: DC520400 267C002F
	global_load_b32 v39, v[47:48], off offset:2048             // 000000056B94: DC520800 277C002F
	global_load_b32 v40, v[47:48], off offset:3072             // 000000056B9C: DC520C00 287C002F
	v_add_co_ci_u32_e64 v55, null, 0, v188, vcc_lo             // 000000056BA4: D5207C37 01AB7880
	.long 0xd7006a2f                                           // 000000056BAC: D7006A2F
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000056BB0: 0201FFBB
	.long 0x0000e000                                           // 000000056BB4: 0000E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000056BB8: BF8700A1
	v_add_co_ci_u32_e64 v48, null, 0, v188, vcc_lo             // 000000056BBC: D5207C30 01AB7880
	.long 0xd7006a3e                                           // 000000056BC4: D7006A3E
	v_cndmask_b32_e32 v1, 0xe000, v187, vcc_lo                 // 000000056BC8: 020376FF 0000E000
	v_add_co_ci_u32_e64 v63, null, 0, v188, vcc_lo             // 000000056BD0: D5207C3F 01AB7880
	.long 0xd7006a43                                           // 000000056BD8: D7006A43
	v_cndmask_b32_e32 v1, 0xf000, v187, vcc_lo                 // 000000056BDC: 020376FF 0000F000
	s_clause 0x7                                               // 000000056BE4: BF850007
	global_load_b32 v51, v[41:42], off offset:-4096            // 000000056BE8: DC521000 337C0029
	global_load_b32 v58, v[41:42], off                         // 000000056BF0: DC520000 3A7C0029
	global_load_b32 v50, v[43:44], off offset:-4096            // 000000056BF8: DC521000 327C002B
	global_load_b32 v56, v[43:44], off                         // 000000056C00: DC520000 387C002B
	global_load_b32 v44, v[45:46], off offset:-4096            // 000000056C08: DC521000 2C7C002D
	global_load_b32 v43, v[45:46], off                         // 000000056C10: DC520000 2B7C002D
	global_load_b32 v42, v[47:48], off offset:-4096            // 000000056C18: DC521000 2A7C002F
	global_load_b32 v41, v[47:48], off                         // 000000056C20: DC520000 297C002F
	v_add_co_ci_u32_e64 v68, null, 0, v188, vcc_lo             // 000000056C28: D5207C44 01AB7880
	s_clause 0xf                                               // 000000056C30: BF85000F
	global_load_b32 v48, v[54:55], off offset:1024             // 000000056C34: DC520400 307C0036
	global_load_b32 v49, v[54:55], off offset:2048             // 000000056C3C: DC520800 317C0036
	global_load_b32 v55, v[54:55], off offset:3072             // 000000056C44: DC520C00 377C0036
	global_load_b32 v45, v[62:63], off offset:1024             // 000000056C4C: DC520400 2D7C003E
	global_load_b32 v46, v[62:63], off offset:2048             // 000000056C54: DC520800 2E7C003E
	global_load_b32 v47, v[62:63], off offset:3072             // 000000056C5C: DC520C00 2F7C003E
	global_load_b32 v57, v[67:68], off                         // 000000056C64: DC520000 397C0043
	global_load_b32 v59, v[67:68], off offset:1024             // 000000056C6C: DC520400 3B7C0043
	global_load_b32 v54, v[52:53], off offset:-4096            // 000000056C74: DC521000 367C0034
	global_load_b32 v64, v[52:53], off                         // 000000056C7C: DC520000 407C0034
	global_load_b32 v53, v[60:61], off offset:-4096            // 000000056C84: DC521000 357C003C
	global_load_b32 v63, v[60:61], off                         // 000000056C8C: DC520000 3F7C003C
	global_load_b32 v52, v[65:66], off offset:-4096            // 000000056C94: DC521000 347C0041
	global_load_b32 v62, v[65:66], off                         // 000000056C9C: DC520000 3E7C0041
	global_load_b32 v60, v[67:68], off offset:2048             // 000000056CA4: DC520800 3C7C0043
	global_load_b32 v61, v[67:68], off offset:3072             // 000000056CAC: DC520C00 3D7C0043
	v_lshlrev_b32_e32 v65, 3, v0                               // 000000056CB4: 30820083
	s_cbranch_scc1 1                                           // 000000056CB8: BFA20001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4c0>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 000000056CBC: BE9C4D83
	s_load_b32 s39, s[0:1], 0x38                               // 000000056CC0: F40009C0 F8000038
	v_lshrrev_b32_e32 v69, 4, v0                               // 000000056CC8: 328A0084
	s_mul_hi_i32 s4, s2, 0x55555556                            // 000000056CCC: 9704FF02 55555556
	v_and_b32_e32 v67, 0x78, v65                               // 000000056CD4: 368682FF 00000078
	s_lshr_b32 s14, s4, 31                                     // 000000056CDC: 850E9F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000056CE0: BF870499
	s_add_i32 s4, s4, s14                                      // 000000056CE4: 81040E04
	s_lshl_b32 s14, s4, 7                                      // 000000056CE8: 840E8704
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056CEC: BF870001
	v_lshlrev_b32_e32 v67, 1, v67                              // 000000056CF0: 30868681
	s_ashr_i32 s15, s14, 31                                    // 000000056CF4: 860F9F0E
	s_mov_b32 s4, exec_lo                                      // 000000056CF8: BE84007E
	s_lshl_b64 s[14:15], s[14:15], 1                           // 000000056CFC: 848E810E
	s_waitcnt lgkmcnt(0)                                       // 000000056D00: BF89FC07
	s_add_i32 s40, s39, -1                                     // 000000056D04: 8128C127
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056D08: BF870099
	v_min_i32_e32 v66, s40, v69                                // 000000056D0C: 22848A28
	v_mad_i64_i32 v[65:66], null, 0x5000, v66, s[8:9]          // 000000056D10: D6FF7C41 002284FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056D1C: BF870091
	.long 0xd7006a41                                           // 000000056D20: D7006A41
	v_cndmask_b32_e32 v0, v65, v14, vcc_lo                     // 000000056D24: 02001D41
	v_add_co_ci_u32_e64 v66, null, s15, v66, vcc_lo            // 000000056D28: D5207C42 01AA840F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056D30: BF870092
	.long 0xd7006a41                                           // 000000056D34: D7006A41
	v_cndmask_b32_e32 v1, v65, v67, vcc_lo                     // 000000056D38: 02028741
	v_add_co_ci_u32_e64 v66, null, 0, v66, vcc_lo              // 000000056D3C: D5207C42 01AA8480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056D44: BF870092
	.long 0xd7006a43                                           // 000000056D48: D7006A43
	v_cndmask_b32_e32 v1, 0x1000, v65, vcc_lo                  // 000000056D4C: 020282FF 00001000
	v_add_co_ci_u32_e64 v68, null, 0, v66, vcc_lo              // 000000056D54: D5207C44 01AA8480
	s_clause 0x1                                               // 000000056D5C: BF850001
	global_load_b128 v[74:77], v[65:66], off                   // 000000056D60: DC5E0000 4A7C0041
	global_load_b128 v[78:81], v[67:68], off                   // 000000056D68: DC5E0000 4E7C0043
	.long 0xd4c3007e                                           // 000000056D70: D4C3007E
	v_cndmask_b32_e32 v1, s39, v69, vcc_lo                     // 000000056D74: 02028A27
	s_cbranch_execz 11                                         // 000000056D78: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5a8>
	s_waitcnt vmcnt(1)                                         // 000000056D7C: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 000000056D80: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056D84: BF870001
	v_mov_b32_e32 v75, v76                                     // 000000056D88: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 000000056D8C: 7E94034C
	s_waitcnt vmcnt(0)                                         // 000000056D90: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 000000056D94: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 000000056D98: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 000000056D9C: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 000000056DA0: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 000000056DA4: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s4                              // 000000056DA8: 8C7E047E
	v_cmp_gt_u32_e32 vcc_lo, 16, v0                            // 000000056DAC: 7C980090
	.long 0xd4440004                                           // 000000056DB0: D4440004
	v_cndmask_b32_e32 v1, s39, v0, vcc_lo                      // 000000056DB4: 02020027
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v140, 0            // 000000056DB8: CA100080 418C0080
	s_and_b32 s16, vcc_lo, s4                                  // 000000056DC0: 8B10046A
	scratch_store_b32 off, v65, off                            // 000000056DC4: DC690000 007C4100
	s_and_saveexec_b32 s4, s16                                 // 000000056DCC: BE842010
	s_cbranch_execz 30                                         // 000000056DD0: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x64c>
	v_mul_u32_u24_e32 v65, 0xc0, v0                            // 000000056DD4: 168200FF 000000C0
	s_lshl_b64 s[16:17], s[2:3], 2                             // 000000056DDC: 84908202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000056DE0: BF870091
	.long 0xd7001242                                           // 000000056DE4: D7001242
	v_cndmask_b32_e32 v1, s10, v65, vcc_lo                     // 000000056DE8: 0202820A
	v_add_co_ci_u32_e64 v67, null, s11, 0, s18                 // 000000056DEC: D5207C43 0049000B
	.long 0xd7001244                                           // 000000056DF4: D7001244
	v_cndmask_b32_e32 v1, s12, v65, vcc_lo                     // 000000056DF8: 0202820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000056DFC: BF870211
	v_add_co_ci_u32_e64 v69, null, s13, 0, s18                 // 000000056E00: D5207C45 0049000D
	.long 0xd7006a41                                           // 000000056E08: D7006A41
	v_cndmask_b32_e32 v0, v66, v16, vcc_lo                     // 000000056E0C: 02002142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000056E10: BF870211
	v_add_co_ci_u32_e64 v66, null, s17, v67, vcc_lo            // 000000056E14: D5207C42 01AA8611
	.long 0xd7006a43                                           // 000000056E1C: D7006A43
	v_cndmask_b32_e32 v0, v68, v16, vcc_lo                     // 000000056E20: 02002144
	s_delay_alu instid0(VALU_DEP_1)                            // 000000056E24: BF870001
	v_add_co_ci_u32_e64 v68, null, s17, v69, vcc_lo            // 000000056E28: D5207C44 01AA8A11
	global_load_b32 v140, v[65:66], off                        // 000000056E30: DC520000 8C7C0041
	global_load_b32 v65, v[67:68], off                         // 000000056E38: DC520000 417C0043
	s_waitcnt vmcnt(0)                                         // 000000056E40: BF8903F7
	scratch_store_b32 off, v65, off                            // 000000056E44: DC690000 007C4100
	s_or_b32 exec_lo, exec_lo, s4                              // 000000056E4C: 8C7E047E
	s_waitcnt vmcnt(62)                                        // 000000056E50: BF89FBF7
	v_dual_mul_f32 v139, 0x43800000, v5 :: v_dual_mul_f32 v138, 0x43800000, v6// 000000056E54: C8C60AFF 8B8A0CFF 43800000
	v_dual_mul_f32 v137, 0x43800000, v7 :: v_dual_mul_f32 v136, 0x43800000, v8// 000000056E60: C8C60EFF 898810FF 43800000
	s_waitcnt vmcnt(9)                                         // 000000056E6C: BF8927F7
	v_dual_mul_f32 v135, 0x43800000, v54 :: v_dual_mul_f32 v54, 0x43800000, v4// 000000056E70: C8C66CFF 873608FF 43800000
	v_dual_mul_f32 v134, 0x43800000, v2 :: v_dual_mul_f32 v133, 0x43800000, v3// 000000056E7C: C8C604FF 868406FF 43800000
	s_waitcnt vmcnt(8)                                         // 000000056E88: BF8923F7
	v_dual_mul_f32 v132, 0x43800000, v64 :: v_dual_mul_f32 v131, 0x43800000, v1// 000000056E8C: C8C680FF 848202FF 43800000
	v_dual_mul_f32 v130, 0x43800000, v12 :: v_dual_mul_f32 v129, 0x43800000, v13// 000000056E98: C8C618FF 82801AFF 43800000
	s_waitcnt vmcnt(7)                                         // 000000056EA4: BF891FF7
	v_dual_mul_f32 v128, 0x43800000, v53 :: v_dual_mul_f32 v53, 0x43800000, v11// 000000056EA8: C8C66AFF 803416FF 43800000
	v_dual_mul_f32 v127, 0x43800000, v9 :: v_dual_mul_f32 v126, 0x43800000, v10// 000000056EB4: C8C612FF 7F7E14FF 43800000
	s_waitcnt vmcnt(6)                                         // 000000056EC0: BF891BF7
	v_dual_mul_f32 v125, 0x43800000, v63 :: v_dual_mul_f32 v124, 0x43800000, v14// 000000056EC4: C8C67EFF 7D7C1CFF 43800000
	v_dual_mul_f32 v123, 0x43800000, v15 :: v_dual_mul_f32 v122, 0x43800000, v16// 000000056ED0: C8C61EFF 7B7A20FF 43800000
	s_waitcnt vmcnt(5)                                         // 000000056EDC: BF8917F7
	v_dual_mul_f32 v121, 0x43800000, v52 :: v_dual_mul_f32 v52, 0x43800000, v22// 000000056EE0: C8C668FF 79342CFF 43800000
	v_dual_mul_f32 v120, 0x43800000, v20 :: v_dual_mul_f32 v119, 0x43800000, v21// 000000056EEC: C8C628FF 78762AFF 43800000
	s_waitcnt vmcnt(4)                                         // 000000056EF8: BF8913F7
	v_dual_mul_f32 v118, 0x43800000, v62 :: v_dual_mul_f32 v117, 0x43800000, v17// 000000056EFC: C8C67CFF 767422FF 43800000
	v_dual_mul_f32 v116, 0x43800000, v18 :: v_dual_mul_f32 v115, 0x43800000, v19// 000000056F08: C8C624FF 747226FF 43800000
	v_dual_mul_f32 v114, 0x43800000, v51 :: v_dual_mul_f32 v111, 0x43800000, v58// 000000056F14: C8C666FF 726E74FF 43800000
	v_dual_mul_f32 v113, 0x43800000, v23 :: v_dual_mul_f32 v112, 0x43800000, v24// 000000056F20: C8C62EFF 717030FF 43800000
	v_dual_mul_f32 v51, 0x43800000, v31 :: v_dual_mul_f32 v110, 0x43800000, v28// 000000056F2C: C8C63EFF 336E38FF 43800000
	v_dual_mul_f32 v109, 0x43800000, v29 :: v_dual_mul_f32 v108, 0x43800000, v30// 000000056F38: C8C63AFF 6D6C3CFF 43800000
	v_dual_mul_f32 v107, 0x43800000, v50 :: v_dual_mul_f32 v106, 0x43800000, v25// 000000056F44: C8C664FF 6B6A32FF 43800000
	v_dual_mul_f32 v105, 0x43800000, v26 :: v_dual_mul_f32 v50, 0x43800000, v27// 000000056F50: C8C634FF 693236FF 43800000
	v_dual_mul_f32 v104, 0x43800000, v56 :: v_dual_mul_f32 v101, 0x43800000, v37// 000000056F5C: C8C670FF 68644AFF 43800000
	v_dual_mul_f32 v103, 0x43800000, v32 :: v_dual_mul_f32 v98, 0x43800000, v34// 000000056F68: C8C640FF 676244FF 43800000
	v_dual_mul_f32 v102, 0x43800000, v36 :: v_dual_mul_f32 v99, 0x43800000, v33// 000000056F74: C8C648FF 666242FF 43800000
	v_dual_mul_f32 v100, 0x43800000, v44 :: v_dual_mul_f32 v97, 0x43800000, v43// 000000056F80: C8C658FF 646056FF 43800000
	v_dual_mul_f32 v58, 0x43800000, v35 :: v_dual_mul_f32 v93, 0x43800000, v42// 000000056F8C: C8C646FF 3A5C54FF 43800000
	v_dual_mul_f32 v96, 0x43800000, v38 :: v_dual_mul_f32 v95, 0x43800000, v39// 000000056F98: C8C64CFF 605E4EFF 43800000
	v_dual_mul_f32 v94, 0x43800000, v40 :: v_dual_mul_f32 v91, 0x43800000, v49// 000000056FA4: C8C650FF 5E5A62FF 43800000
	v_dual_mul_f32 v92, 0x43800000, v48 :: v_dual_mul_f32 v141, 0x43800000, v45// 000000056FB0: C8C660FF 5C8C5AFF 43800000
	v_dual_mul_f32 v152, 0x43800000, v55 :: v_dual_mul_f32 v191, 0x43800000, v57// 000000056FBC: C8C66EFF 98BE72FF 43800000
	v_dual_mul_f32 v90, 0x43800000, v41 :: v_dual_mul_f32 v189, 0x43800000, v59// 000000056FC8: C8C652FF 5ABC76FF 43800000
	s_waitcnt vmcnt(2)                                         // 000000056FD4: BF890BF7
	v_dual_mul_f32 v150, 0x43800000, v46 :: v_dual_mul_f32 v151, 0x43800000, v61// 000000056FD8: C8C65CFF 96967AFF 43800000
	v_mul_f32_e32 v142, 0x43800000, v47                        // 000000056FE4: 111C5EFF 43800000
	v_mul_f32_e32 v190, 0x43800000, v60                        // 000000056FEC: 117C78FF 43800000
	s_cmp_lt_i32 s39, 1                                        // 000000056FF4: BF048127
	s_cbranch_scc1 4678                                        // 000000056FF8: BFA21246 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5114>
	s_add_u32 s30, s8, s14                                     // 000000056FFC: 801E0E08
	s_addc_u32 s31, s9, s15                                    // 000000057000: 821F0F09
	s_lshl_b64 s[14:15], s[2:3], 2                             // 000000057004: 848E8202
	s_load_b64 s[26:27], s[0:1], 0x68                          // 000000057008: F4040680 F8000068
	s_add_u32 s10, s10, s14                                    // 000000057010: 800A0E0A
	s_addc_u32 s11, s11, s15                                   // 000000057014: 820B0F0B
	s_add_u32 s34, s12, s14                                    // 000000057018: 80220E0C
	s_addc_u32 s35, s13, s15                                   // 00000005701C: 82230F0D
	s_add_i32 s3, s39, 15                                      // 000000057020: 81038F27
	s_load_b256 s[12:19], s[0:1], 0x48                         // 000000057024: F40C0300 F8000048
	s_ashr_i32 s4, s3, 31                                      // 00000005702C: 86049F03
	.long 0xd71f008f                                           // 000000057030: D71F008F
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000057034: 020100C1
	s_lshr_b32 s4, s4, 28                                      // 000000057038: 85049C04
	v_mov_b32_e32 v1, 0                                        // 00000005703C: 7E020280
	s_add_i32 s3, s3, s4                                       // 000000057040: 81030403
	v_mov_b32_e32 v149, 0x1000504                              // 000000057044: 7F2A02FF 01000504
	s_waitcnt lgkmcnt(0)                                       // 00000005704C: BF89FC07
	s_ashr_i32 s15, s3, 4                                      // 000000057050: 860F8403
	s_cmp_lg_u32 s21, 0                                        // 000000057054: BF078015
	s_movk_i32 s3, 0x5f40                                      // 000000057058: B0035F40
	s_cselect_b32 s41, -1, 0                                   // 00000005705C: 982980C1
	s_lshl_b32 s22, s2, 7                                      // 000000057060: 84168702
	v_and_b32_e32 v2, 16, v143                                 // 000000057064: 36051E90
	s_ashr_i32 s23, s22, 31                                    // 000000057068: 86179F16
	s_cmp_gt_u32 s20, 63                                       // 00000005706C: BF08BF14
	v_xor_b32_e32 v146, 2, v143                                // 000000057070: 3B251E82
	s_cselect_b32 s42, -1, 0                                   // 000000057074: 982A80C1
	s_cmp_eq_u32 s21, 0                                        // 000000057078: BF068015
	v_add_nc_u32_e32 v144, 16, v2                              // 00000005707C: 4B200490
	s_cselect_b32 s2, -1, 0                                    // 000000057080: 980280C1
	v_xor_b32_e32 v147, 4, v143                                // 000000057084: 3B271E84
	s_and_b32 s4, s2, exec_lo                                  // 000000057088: 8B047E02
	s_cselect_b32 s43, s3, 0x5f80                              // 00000005708C: 982BFF03 00005F80
	s_lshl_b64 s[36:37], s[22:23], 1                           // 000000057094: 84A48116
	v_xor_b32_e32 v148, 8, v143                                // 000000057098: 3B291E88
	s_add_u32 s44, s24, s36                                    // 00000005709C: 802C2418
	s_addc_u32 s45, s25, s37                                   // 0000000570A0: 822D2519
	s_max_i32 s46, s15, 1                                      // 0000000570A4: 8A2E810F
	s_add_u32 s16, s16, s6                                     // 0000000570A8: 80100610
	s_addc_u32 s17, s17, s7                                    // 0000000570AC: 82110711
	s_add_u32 s18, s18, s6                                     // 0000000570B0: 80120612
	s_mov_b32 s20, 0                                           // 0000000570B4: BE940080
	s_addc_u32 s19, s19, s7                                    // 0000000570B8: 82130713
	s_add_u32 s47, s26, s6                                     // 0000000570BC: 802F061A
	s_addc_u32 s7, s27, s7                                     // 0000000570C0: 8207071B
	s_mov_b32 s48, 0x41800000                                  // 0000000570C4: BEB000FF 41800000
	s_movk_i32 s49, 0x1800                                     // 0000000570CC: B0311800
	s_movk_i32 s50, 0x2900                                     // 0000000570D0: B0322900
	s_mov_b32 s21, s20                                         // 0000000570D4: BE950014
	s_mov_b32 s22, s20                                         // 0000000570D8: BE960014
	s_mov_b32 s23, s20                                         // 0000000570DC: BE970014
	s_mov_b32 s24, s20                                         // 0000000570E0: BE980014
	s_mov_b32 s25, s20                                         // 0000000570E4: BE990014
	s_mov_b32 s26, s20                                         // 0000000570E8: BE9A0014
	s_mov_b32 s27, s20                                         // 0000000570EC: BE9B0014
	s_mov_b32 s51, 0x3d800000                                  // 0000000570F0: BEB300FF 3D800000
	s_mov_b32 s52, 0x76543210                                  // 0000000570F8: BEB400FF 76543210
	s_mov_b32 s53, s20                                         // 000000057100: BEB50014
	s_mov_b32 s6, s20                                          // 000000057104: BE860014
	s_branch 10                                                // 000000057108: BFA0000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x934>
	v_mov_b32_e32 v151, v65                                    // 00000005710C: 7F2E0341
	v_mov_b32_e32 v152, v57                                    // 000000057110: 7F300339
	v_mov_b32_e32 v58, v49                                     // 000000057114: 7E740331
	v_mov_b32_e32 v50, v9                                      // 000000057118: 7E640309
	v_mov_b32_e32 v51, v17                                     // 00000005711C: 7E660311
	v_mov_b32_e32 v52, v25                                     // 000000057120: 7E680319
	v_mov_b32_e32 v53, v33                                     // 000000057124: 7E6A0321
	v_mov_b32_e32 v54, v41                                     // 000000057128: 7E6C0329
	s_cmp_eq_u32 s53, s46                                      // 00000005712C: BF062E35
	s_cbranch_scc1 4590                                        // 000000057130: BFA211EE <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x50ec>
	v_mov_b32_e32 v44, v0                                      // 000000057134: 7E580300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000057138: BF8701B1
	v_ashrrev_i32_e32 v2, 4, v44                               // 00000005713C: 34045884
	v_and_b32_e32 v55, 15, v44                                 // 000000057140: 366E588F
	.long 0xd4440003                                           // 000000057144: D4440003
	v_cndmask_b32_e32 v1, 16, v44, vcc_lo                      // 000000057148: 02025890
	.long 0xd72c0003                                           // 00000005714C: D72C0003
	v_cndmask_b32_e32 v1, 0x110, v2, vcc_lo                    // 000000057150: 020204FF 00000110
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057158: BF870001
	v_lshl_add_u32 v3, v55, 4, v3                              // 00000005715C: D6460003 040D0937
	s_waitcnt vmcnt(1)                                         // 000000057164: BF8907F7
	ds_store_b128 v3, v[74:77] offset:10496                    // 000000057168: DB7C2900 00004A03
	s_waitcnt vmcnt(0)                                         // 000000057170: BF8903F7
	ds_store_b128 v3, v[78:81] offset:6144                     // 000000057174: DB7C1800 00004E03
	s_and_saveexec_b32 s4, s3                                  // 00000005717C: BE842003
	s_cbranch_execz 6                                          // 000000057180: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x99c>
	scratch_load_b32 v4, off, off                              // 000000057184: DC510000 047C0000
	v_lshlrev_b32_e32 v3, 2, v44                               // 00000005718C: 30065882
	s_waitcnt vmcnt(0)                                         // 000000057190: BF8903F7
	ds_store_b32 v3, v4 offset:24064                           // 000000057194: D8345E00 00000403
	s_or_b32 exec_lo, exec_lo, s4                              // 00000005719C: 8C7E047E
	v_and_b32_e32 v34, 1, v44                                  // 0000000571A0: 36445881
	s_lshl_b32 s54, s53, 4                                     // 0000000571A4: 84368435
	v_or_b32_e32 v153, s33, v55                                // 0000000571A8: 39326E21
	s_mov_b32 s29, exec_lo                                     // 0000000571AC: BE9D007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000571B0: BF870112
	v_or_b32_e32 v15, s54, v34                                 // 0000000571B4: 381E4436
	v_and_b32_e32 v6, 0x7ffffffe, v153                         // 0000000571B8: 360D32FF 7FFFFFFE
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000000571C0: BF870232
	v_min_i32_e32 v3, s40, v15                                 // 0000000571C4: 22061E28
	v_or_b32_e32 v5, 2, v15                                    // 0000000571C8: 380A1E82
	v_or_b32_e32 v7, 4, v15                                    // 0000000571CC: 380E1E84
	v_lshlrev_b32_e32 v19, 1, v6                               // 0000000571D0: 30260C81
	v_or_b32_e32 v8, 6, v15                                    // 0000000571D4: 38101E86
	v_mad_i64_i32 v[3:4], null, 0x5000, v3, s[8:9]             // 0000000571D8: D6FF7C03 002206FF 00005000
	v_min_i32_e32 v5, s40, v5                                  // 0000000571E4: 220A0A28
	v_min_i32_e32 v7, s40, v7                                  // 0000000571E8: 220E0E28
	v_or_b32_e32 v17, 12, v15                                  // 0000000571EC: 38221E8C
	v_min_i32_e32 v8, s40, v8                                  // 0000000571F0: 22101028
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000571F4: BF8700A4
	v_mad_i64_i32 v[5:6], null, 0x5000, v5, s[8:9]             // 0000000571F8: D6FF7C05 00220AFF 00005000
	.long 0xd7006a09                                           // 000000057204: D7006A09
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000057208: 02004903
	v_add_co_ci_u32_e64 v10, null, s37, v4, vcc_lo             // 00000005720C: D5207C0A 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v7, s[8:9]             // 000000057214: D6FF7C03 00220EFF 00005000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057220: BF870093
	.long 0xd7006a07                                           // 000000057224: D7006A07
	v_cndmask_b32_e32 v1, v9, v19, vcc_lo                      // 000000057228: 02022709
	v_add_co_ci_u32_e64 v9, null, 0, v10, vcc_lo               // 00000005722C: D5207C09 01AA1480
	.long 0xd7006a0a                                           // 000000057234: D7006A0A
	v_cndmask_b32_e32 v0, v5, v36, vcc_lo                      // 000000057238: 02004905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005723C: BF870211
	v_add_co_ci_u32_e64 v11, null, s37, v6, vcc_lo             // 000000057240: D5207C0B 01AA0C25
	.long 0xd7006a05                                           // 000000057248: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 00000005724C: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000057254: BF870211
	v_add_co_ci_u32_e64 v6, null, 0, v9, vcc_lo                // 000000057258: D5207C06 01AA1280
	.long 0xd7006a07                                           // 000000057260: D7006A07
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 000000057264: 0202270A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000057268: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v11, vcc_lo               // 00000005726C: D5207C09 01AA1680
	.long 0xd7006a0a                                           // 000000057274: D7006A0A
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 000000057278: 02004903
	v_add_co_ci_u32_e64 v11, null, s37, v4, vcc_lo             // 00000005727C: D5207C0B 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v8, s[8:9]             // 000000057284: D6FF7C03 002210FF 00005000
	.long 0xd7006a07                                           // 000000057290: D7006A07
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 000000057294: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005729C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v9, vcc_lo                // 0000000572A0: D5207C08 01AA1280
	.long 0xd7006a09                                           // 0000000572A8: D7006A09
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 0000000572AC: 0202270A
	v_add_co_ci_u32_e64 v10, null, 0, v11, vcc_lo              // 0000000572B0: D5207C0A 01AA1680
	v_or_b32_e32 v11, 8, v15                                   // 0000000572B8: 38161E88
	.long 0xd7006a03                                           // 0000000572BC: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 0000000572C0: 02004903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000572C4: BF870191
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 0000000572C8: D5207C04 01AA0825
	v_min_i32_e32 v11, s40, v11                                // 0000000572D0: 22161628
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000572D4: BF870093
	.long 0xd7006a0c                                           // 0000000572D8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 0000000572DC: 02022703
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 0000000572E0: D5207C0D 01AA0880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000572E8: BF8700A3
	v_mad_i64_i32 v[3:4], null, 0x5000, v11, s[8:9]            // 0000000572EC: D6FF7C03 002216FF 00005000
	.long 0xd7006a09                                           // 0000000572F8: D7006A09
	v_cndmask_b32_e32 v1, 0x2000, v9, vcc_lo                   // 0000000572FC: 020212FF 00002000
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo              // 000000057304: D5207C0A 01AA1480
	.long 0xd7006a0b                                           // 00000005730C: D7006A0B
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 000000057310: 020218FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000057318: BF8700B1
	v_add_co_ci_u32_e64 v12, null, 0, v13, vcc_lo              // 00000005731C: D5207C0C 01AA1A80
	v_or_b32_e32 v13, 10, v15                                  // 000000057324: 381A1E8A
	.long 0xd7006a03                                           // 000000057328: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000005732C: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 000000057330: D5207C04 01AA0825
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000057338: BF870193
	v_min_i32_e32 v13, s40, v13                                // 00000005733C: 221A1A28
	.long 0xd7006a0e                                           // 000000057340: D7006A0E
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000057344: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000057348: BF870191
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000005734C: D5207C10 01AA0880
	v_mad_i64_i32 v[3:4], null, 0x5000, v13, s[8:9]            // 000000057354: D6FF7C03 00221AFF 00005000
	v_or_b32_e32 v15, 14, v15                                  // 000000057360: 381E1E8E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057364: BF870094
	.long 0xd7006a0d                                           // 000000057368: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v14, vcc_lo                  // 00000005736C: 02021CFF 00002000
	v_add_co_ci_u32_e64 v14, null, 0, v16, vcc_lo              // 000000057374: D5207C0E 01AA2080
	v_min_i32_e32 v16, s40, v17                                // 00000005737C: 22202228
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000057380: BF8700A4
	v_min_i32_e32 v15, s40, v15                                // 000000057384: 221E1E28
	.long 0xd7006a11                                           // 000000057388: D7006A11
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000005738C: 02004903
	v_add_co_ci_u32_e64 v18, null, s37, v4, vcc_lo             // 000000057390: D5207C12 01AA0825
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000057398: BF870194
	v_mad_i64_i32 v[3:4], null, 0x5000, v16, s[8:9]            // 00000005739C: D6FF7C03 002220FF 00005000
	.long 0xd7006a11                                           // 0000000573A8: D7006A11
	v_cndmask_b32_e32 v1, v17, v19, vcc_lo                     // 0000000573AC: 02022711
	v_mad_i64_i32 v[15:16], null, 0x5000, v15, s[8:9]          // 0000000573B0: D6FF7C0F 00221EFF 00005000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000573BC: BF870194
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 0000000573C0: D5207C12 01AA2480
	.long 0xd7006a11                                           // 0000000573C8: D7006A11
	v_cndmask_b32_e32 v1, 0x2000, v17, vcc_lo                  // 0000000573CC: 020222FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000573D4: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 0000000573D8: D5207C12 01AA2480
	.long 0xd7006a03                                           // 0000000573E0: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 0000000573E4: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 0000000573E8: D5207C04 01AA0825
	.long 0xd7006a0f                                           // 0000000573F0: D7006A0F
	v_cndmask_b32_e32 v0, v15, v36, vcc_lo                     // 0000000573F4: 0200490F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000573F8: BF870211
	v_add_co_ci_u32_e64 v16, null, s37, v16, vcc_lo            // 0000000573FC: D5207C10 01AA2025
	.long 0xd7006a03                                           // 000000057404: D7006A03
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000057408: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005740C: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000057410: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 000000057418: D7006A0F
	v_cndmask_b32_e32 v1, v15, v19, vcc_lo                     // 00000005741C: 0202270F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000057420: BF870211
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 000000057424: D5207C10 01AA2080
	.long 0xd7006a03                                           // 00000005742C: D7006A03
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 000000057430: 020206FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000057438: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000005743C: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 000000057444: D7006A0F
	v_cndmask_b32_e32 v1, 0x2000, v15, vcc_lo                  // 000000057448: 02021EFF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057450: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 000000057454: D5207C10 01AA2080
	s_clause 0x7                                               // 00000005745C: BF850007
	global_load_b32 v42, v[5:6], off                           // 000000057460: DC520000 2A7C0005
	global_load_b32 v41, v[7:8], off                           // 000000057468: DC520000 297C0007
	global_load_b32 v40, v[9:10], off                          // 000000057470: DC520000 287C0009
	global_load_b32 v39, v[11:12], off                         // 000000057478: DC520000 277C000B
	global_load_b32 v38, v[13:14], off                         // 000000057480: DC520000 267C000D
	global_load_b32 v37, v[17:18], off                         // 000000057488: DC520000 257C0011
	global_load_b32 v35, v[3:4], off                           // 000000057490: DC520000 237C0003
	global_load_b32 v36, v[15:16], off                         // 000000057498: DC520000 247C000F
	v_lshlrev_b32_e32 v5, 16, v78                              // 0000000574A0: 300A9C90
	v_and_b32_e32 v4, 0xffff0000, v74                          // 0000000574A4: 360894FF FFFF0000
	v_and_b32_e32 v8, 0xffff0000, v75                          // 0000000574AC: 361096FF FFFF0000
	v_lshlrev_b32_e32 v3, 16, v74                              // 0000000574B4: 30069490
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000574B8: BF8701A4
	v_dual_mul_f32 v5, v5, v5 :: v_dual_lshlrev_b32 v12, 16, v80// 0000000574BC: C8E20B05 050CA090
	v_lshlrev_b32_e32 v7, 16, v75                              // 0000000574C4: 300E9690
	v_dual_mul_f32 v3, v3, v3 :: v_dual_and_b32 v6, 0xffff0000, v78// 0000000574C8: C8E40703 03069CFF FFFF0000
	v_mul_f32_e32 v4, v4, v4                                   // 0000000574D4: 10080904
	v_and_b32_e32 v13, 0xffff0000, v80                         // 0000000574D8: 361AA0FF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v76                         // 0000000574E0: 361498FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000574E8: BF8701B4
	v_dual_mul_f32 v6, v6, v6 :: v_dual_and_b32 v11, 0xffff0000, v77// 0000000574EC: C8E40D06 060A9AFF FFFF0000
	v_mul_f32_e32 v12, v12, v12                                // 0000000574F8: 1018190C
	v_add_f32_e32 v3, v3, v4                                   // 0000000574FC: 06060903
	v_dual_add_f32 v4, v5, v6 :: v_dual_lshlrev_b32 v9, 16, v76// 000000057500: C9220D05 04089890
	v_dual_mul_f32 v5, v7, v7 :: v_dual_mul_f32 v6, v8, v8     // 000000057508: C8C60F07 05061108
	v_lshlrev_b32_e32 v7, 16, v79                              // 000000057510: 300E9E90
	v_dual_mul_f32 v13, v13, v13 :: v_dual_and_b32 v8, 0xffff0000, v79// 000000057514: C8E41B0D 0D089EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000057520: BF870113
	v_dual_add_f32 v5, v5, v6 :: v_dual_and_b32 v14, 0xffff0000, v81// 000000057524: C9240D05 050EA2FF FFFF0000
	v_dual_mul_f32 v6, v7, v7 :: v_dual_mul_f32 v7, v8, v8     // 000000057530: C8C60F07 06061108
	v_dual_mul_f32 v8, v9, v9 :: v_dual_mul_f32 v9, v10, v10   // 000000057538: C8C61309 0808150A
	v_lshlrev_b32_e32 v10, 16, v77                             // 000000057540: 30149A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000057544: BF870113
	v_dual_add_f32 v6, v6, v7 :: v_dual_add_f32 v7, v12, v13   // 000000057548: C9080F06 06061B0C
	v_dual_add_f32 v8, v8, v9 :: v_dual_mul_f32 v9, v10, v10   // 000000057550: C9061308 0808150A
	v_dual_mul_f32 v10, v11, v11 :: v_dual_lshlrev_b32 v11, 16, v81// 000000057558: C8E2170B 0A0AA290
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000057560: BF870113
	v_add_f32_e32 v4, v4, v6                                   // 000000057564: 06080D04
	v_dual_add_f32 v9, v9, v10 :: v_dual_mul_f32 v10, v11, v11 // 000000057568: C9061509 090A170B
	v_mul_f32_e32 v11, v14, v14                                // 000000057570: 10161D0E
	v_add_f32_e32 v3, v3, v5                                   // 000000057574: 06060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057578: BF870123
	v_add_f32_e32 v5, v8, v9                                   // 00000005757C: 060A1308
	v_xor_b32_e32 v9, 1, v143                                  // 000000057580: 3A131E81
	v_dual_add_f32 v8, v10, v11 :: v_dual_add_f32 v3, v3, v5   // 000000057584: C908170A 08020B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000005758C: BF8701A2
	v_cmp_lt_u32_e32 vcc_lo, v9, v144                          // 000000057590: 7C932109
	v_cndmask_b32_e32 v9, v143, v9, vcc_lo                     // 000000057594: 0212138F
	v_add_f32_e32 v5, v7, v8                                   // 000000057598: 060A1107
	v_cmp_lt_u32_e32 vcc_lo, v146, v144                        // 00000005759C: 7C932192
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000575A0: BF870193
	v_lshlrev_b32_e32 v6, 2, v9                                // 0000000575A4: 300C1282
	v_dual_add_f32 v4, v4, v5 :: v_dual_cndmask_b32 v7, v143, v146// 0000000575A8: C9120B04 0407258F
	v_cmp_lt_u32_e32 vcc_lo, v147, v144                        // 0000000575B0: 7C932193
	ds_bpermute_b32 v5, v6, v3                                 // 0000000575B4: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 0000000575BC: DACC0000 06000406
	s_waitcnt lgkmcnt(0)                                       // 0000000575C4: BF89FC07
	v_dual_add_f32 v4, v4, v6 :: v_dual_add_f32 v3, v3, v5     // 0000000575C8: C9080D04 04020B03
	v_lshlrev_b32_e32 v5, 2, v7                                // 0000000575D0: 300A0E82
	ds_bpermute_b32 v6, v5, v3                                 // 0000000575D4: DACC0000 06000305
	ds_bpermute_b32 v5, v5, v4                                 // 0000000575DC: DACC0000 05000405
	v_cndmask_b32_e32 v7, v143, v147, vcc_lo                   // 0000000575E4: 020F278F
	v_cmp_lt_u32_e32 vcc_lo, v148, v144                        // 0000000575E8: 7C932194
	s_waitcnt lgkmcnt(0)                                       // 0000000575EC: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v5     // 0000000575F0: C9080D03 03040B04
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000575F8: BF870003
	v_dual_cndmask_b32 v7, v143, v148 :: v_dual_lshlrev_b32 v6, 2, v7// 0000000575FC: CA63298F 07060E82
	ds_bpermute_b32 v5, v6, v3                                 // 000000057604: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 00000005760C: DACC0000 06000406
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000057614: 300E0E82
	s_waitcnt lgkmcnt(0)                                       // 000000057618: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 00000005761C: C9080B03 03040D04
	ds_bpermute_b32 v5, v7, v3                                 // 000000057624: DACC0000 05000307
	ds_bpermute_b32 v6, v7, v4                                 // 00000005762C: DACC0000 06000407
	v_cmpx_eq_u32_e32 0, v55                                   // 000000057634: 7D946E80
	s_cbranch_execz 41                                         // 000000057638: BFA50029 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xee0>
	s_waitcnt lgkmcnt(0)                                       // 00000005763C: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 000000057640: C9080B03 03040D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057648: BF870091
	v_dual_add_f32 v3, 0x358637bd, v3 :: v_dual_add_f32 v4, 0x358637bd, v4// 00000005764C: C90806FF 030408FF 358637BD
	v_dual_mul_f32 v5, 0x4b800000, v3 :: v_dual_mul_f32 v6, 0x4b800000, v4// 000000057658: C8C606FF 050608FF 4B800000
	.long 0xd4140004                                           // 000000057664: D4140004
	v_cndmask_b32_e32 v1, 0x800000, v4, vcc_lo                 // 000000057668: 020208FF 00800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v3                      // 000000057670: 7C2806FF 00800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057678: BF870092
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 00000005767C: D5010004 00120D04
	v_rsq_f32_e32 v4, v4                                       // 000000057684: 7E085D04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057688: BF870095
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_mul_f32 v6, 0x45800000, v4// 00000005768C: CA460B03 030608FF 45800000
	v_rsq_f32_e32 v3, v3                                       // 000000057698: 7E065D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 00000005769C: BF870321
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 0000000576A0: D5010004 00120D04
	v_rsq_f32_e32 v6, 0x43000000                               // 0000000576A8: 7E0C5CFF 43000000
	v_mul_f32_e32 v5, 0x45800000, v3                           // 0000000576B0: 100A06FF 45800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000576B8: BF870001
	v_cndmask_b32_e32 v3, v3, v5, vcc_lo                       // 0000000576BC: 02060B03
	v_lshlrev_b32_e32 v5, 2, v2                                // 0000000576C0: 300A0482
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)   // 0000000576C4: BF870105
	v_mul_f32_e32 v3, v6, v3                                   // 0000000576C8: 10060706
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000576CC: BF870002
	v_add_nc_u32_e32 v5, 0x5c00, v5                            // 0000000576D0: 4A0A0AFF 00005C00
	ds_store_2addr_b32 v5, v4, v3 offset0:208 offset1:224      // 0000000576D8: D838E0D0 00030405
	s_or_b32 exec_lo, exec_lo, s29                             // 0000000576E0: 8C7E1D7E
	v_and_b32_e32 v43, 31, v44                                 // 0000000576E4: 3656589F
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 0000000576E8: 916A027E
	s_cbranch_vccnz 119                                        // 0000000576EC: BFA40077 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10cc>
	.long 0xd7600045                                           // 0000000576F0: D7600045
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                   // 0000000576F4: 0201018C
	.long 0xd7600044                                           // 0000000576F8: D7600044
	v_cndmask_b32_e32 v0, v140, v129, vcc_lo                   // 0000000576FC: 0201038C
	.long 0xd7600043                                           // 000000057700: D7600043
	v_cndmask_b32_e32 v0, v140, v130, vcc_lo                   // 000000057704: 0201058C
	.long 0xd7600042                                           // 000000057708: D7600042
	v_cndmask_b32_e32 v0, v140, v131, vcc_lo                   // 00000005770C: 0201078C
	.long 0xd7600041                                           // 000000057710: D7600041
	v_cndmask_b32_e32 v0, v140, v132, vcc_lo                   // 000000057714: 0201098C
	.long 0xd7600040                                           // 000000057718: D7600040
	v_cndmask_b32_e32 v0, v140, v133, vcc_lo                   // 00000005771C: 02010B8C
	.long 0xd760003f                                           // 000000057720: D760003F
	v_cndmask_b32_e32 v0, v140, v134, vcc_lo                   // 000000057724: 02010D8C
	.long 0xd760003e                                           // 000000057728: D760003E
	v_cndmask_b32_e32 v0, v140, v135, vcc_lo                   // 00000005772C: 02010F8C
	.long 0xd760003d                                           // 000000057730: D760003D
	v_cndmask_b32_e32 v0, v140, v136, vcc_lo                   // 000000057734: 0201118C
	.long 0xd760003c                                           // 000000057738: D760003C
	v_cndmask_b32_e32 v0, v140, v137, vcc_lo                   // 00000005773C: 0201138C
	.long 0xd760003b                                           // 000000057740: D760003B
	v_cndmask_b32_e32 v0, v140, v138, vcc_lo                   // 000000057744: 0201158C
	.long 0xd760003a                                           // 000000057748: D760003A
	v_cndmask_b32_e32 v0, v140, v139, vcc_lo                   // 00000005774C: 0201178C
	.long 0xd7600039                                           // 000000057750: D7600039
	v_cndmask_b32_e32 v0, v140, v140, vcc_lo                   // 000000057754: 0201198C
	.long 0xd7600038                                           // 000000057758: D7600038
	v_cndmask_b32_e32 v0, v140, v141, vcc_lo                   // 00000005775C: 02011B8C
	.long 0xd7600037                                           // 000000057760: D7600037
	v_cndmask_b32_e32 v0, v140, v142, vcc_lo                   // 000000057764: 02011D8C
	.long 0xd760001d                                           // 000000057768: D760001D
	v_cndmask_b32_e32 v0, v140, v143, vcc_lo                   // 00000005776C: 02011F8C
	s_mov_b32 s4, exec_lo                                      // 000000057770: BE84007E
	v_cmpx_gt_u32_e32 16, v43                                  // 000000057774: 7D985690
	s_cbranch_execz 83                                         // 000000057778: BFA50053 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10c8>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 00000005777C: 7C945680
	s_add_f32 s69, s69, 0                                      // 000000057780: A0458045
	v_lshlrev_b32_e32 v4, 2, v43                               // 000000057784: 30085682
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000057788: BF8704BA
	s_add_f32 s68, s69, s68                                    // 00000005778C: A0444445
	v_cndmask_b32_e64 v3, 0, s69, vcc_lo                       // 000000057790: D5010003 01A88A80
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 000000057798: 7C945681
	s_add_f32 s67, s68, s67                                    // 00000005779C: A0434344
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000577A0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s68, vcc_lo                      // 0000000577A4: D5010003 01A88903
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 0000000577AC: 7C945682
	s_add_f32 s66, s67, s66                                    // 0000000577B0: A0424243
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000577B4: BF8704A2
	v_cndmask_b32_e64 v3, v3, s67, vcc_lo                      // 0000000577B8: D5010003 01A88703
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 0000000577C0: 7C945683
	s_add_f32 s65, s66, s65                                    // 0000000577C4: A0414142
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000577C8: BF8704A2
	v_cndmask_b32_e64 v3, v3, s66, vcc_lo                      // 0000000577CC: D5010003 01A88503
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 0000000577D4: 7C945684
	s_add_f32 s64, s65, s64                                    // 0000000577D8: A0404041
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000577DC: BF8704A2
	v_cndmask_b32_e64 v3, v3, s65, vcc_lo                      // 0000000577E0: D5010003 01A88303
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 0000000577E8: 7C945685
	s_add_f32 s63, s64, s63                                    // 0000000577EC: A03F3F40
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000577F0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s64, vcc_lo                      // 0000000577F4: D5010003 01A88103
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 0000000577FC: 7C945686
	s_add_f32 s62, s63, s62                                    // 000000057800: A03E3E3F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000057804: BF8704A2
	v_cndmask_b32_e64 v3, v3, s63, vcc_lo                      // 000000057808: D5010003 01A87F03
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 000000057810: 7C945687
	s_add_f32 s61, s62, s61                                    // 000000057814: A03D3D3E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000057818: BF8704A2
	v_cndmask_b32_e64 v3, v3, s62, vcc_lo                      // 00000005781C: D5010003 01A87D03
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 000000057824: 7C945688
	s_add_f32 s60, s61, s60                                    // 000000057828: A03C3C3D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005782C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s61, vcc_lo                      // 000000057830: D5010003 01A87B03
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 000000057838: 7C945689
	s_add_f32 s59, s60, s59                                    // 00000005783C: A03B3B3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000057840: BF8704A2
	v_cndmask_b32_e64 v3, v3, s60, vcc_lo                      // 000000057844: D5010003 01A87903
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 00000005784C: 7C94568A
	s_add_f32 s58, s59, s58                                    // 000000057850: A03A3A3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000057854: BF8704A2
	v_cndmask_b32_e64 v3, v3, s59, vcc_lo                      // 000000057858: D5010003 01A87703
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 000000057860: 7C94568B
	s_add_f32 s57, s58, s57                                    // 000000057864: A039393A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000057868: BF8704A2
	v_cndmask_b32_e64 v3, v3, s58, vcc_lo                      // 00000005786C: D5010003 01A87503
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 000000057874: 7C94568C
	s_add_f32 s56, s57, s56                                    // 000000057878: A0383839
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005787C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s57, vcc_lo                      // 000000057880: D5010003 01A87303
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 000000057888: 7C94568D
	s_add_f32 s55, s56, s55                                    // 00000005788C: A0373738
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000057890: BF8704A2
	v_cndmask_b32_e64 v3, v3, s56, vcc_lo                      // 000000057894: D5010003 01A87103
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 00000005789C: 7C94568E
	s_add_f32 s29, s55, s29                                    // 0000000578A0: A01D1D37
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000578A4: BF870002
	v_cndmask_b32_e64 v3, v3, s55, vcc_lo                      // 0000000578A8: D5010003 01A86F03
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 0000000578B0: 7C94568F
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000000578B4: BF870482
	v_cndmask_b32_e64 v3, v3, s29, vcc_lo                      // 0000000578B8: D5010003 01A83B03
	ds_store_b32 v4, v3 offset:24128                           // 0000000578C0: D8345E40 00000304
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000578C8: 8C7E047E
	s_add_i32 s53, s53, 1                                      // 0000000578CC: 81358135
	s_waitcnt lgkmcnt(0)                                       // 0000000578D0: BF89FC07
	s_barrier                                                  // 0000000578D4: BFBD0000
	s_cmp_ge_i32 s53, s15                                      // 0000000578D8: BF030F35
	s_cbranch_scc1 71                                          // 0000000578DC: BFA20047 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11fc>
	s_lshl_b32 s4, s53, 4                                      // 0000000578E0: 84048435
	v_lshlrev_b32_e32 v4, 4, v44                               // 0000000578E4: 30085884
	s_waitcnt lgkmcnt(0)                                       // 0000000578E8: BF89FC07
	v_add_nc_u32_e32 v6, s4, v2                                // 0000000578EC: 4A0C0404
	s_mov_b32 s29, exec_lo                                     // 0000000578F0: BE9D007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000578F4: BF870112
	v_and_b32_e32 v4, 0xf0, v4                                 // 0000000578F8: 360808FF 000000F0
	v_min_i32_e32 v2, s40, v6                                  // 000000057900: 22040C28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057904: BF870091
	v_mad_i64_i32 v[2:3], null, 0x5000, v2, s[30:31]           // 000000057908: D6FF7C02 007A04FF 00005000
	.long 0xd7006a02                                           // 000000057914: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000057918: 02020902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005791C: BF870111
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000057920: D5207C03 01AA0680
	.long 0xd7006a04                                           // 000000057928: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 00000005792C: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057934: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 000000057938: D5207C05 01AA0680
	s_clause 0x1                                               // 000000057940: BF850001
	global_load_b128 v[74:77], v[2:3], off                     // 000000057944: DC5E0000 4A7C0002
	global_load_b128 v[78:81], v[4:5], off                     // 00000005794C: DC5E0000 4E7C0004
	.long 0xd4c3007e                                           // 000000057954: D4C3007E
	v_cndmask_b32_e32 v1, s39, v6, vcc_lo                      // 000000057958: 02020C27
	s_cbranch_execz 11                                         // 00000005795C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x118c>
	s_waitcnt vmcnt(1)                                         // 000000057960: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 000000057964: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057968: BF870001
	v_mov_b32_e32 v75, v76                                     // 00000005796C: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 000000057970: 7E94034C
	s_waitcnt vmcnt(0)                                         // 000000057974: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 000000057978: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 00000005797C: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 000000057980: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 000000057984: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 000000057988: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s29                             // 00000005798C: 8C7E1D7E
	s_and_saveexec_b32 s29, s3                                 // 000000057990: BE9D2003
	s_cbranch_execz 23                                         // 000000057994: BFA50017 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11f4>
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v2, s4, v44      // 000000057998: CA200080 03025804
	v_mov_b32_e32 v140, 0                                      // 0000000579A0: 7F180280
	s_mov_b32 s3, exec_lo                                      // 0000000579A4: BE83007E
	scratch_store_b32 off, v3, off                             // 0000000579A8: DC690000 007C0300
	.long 0xd4c4007e                                           // 0000000579B0: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 0000000579B4: 02020427
	s_cbranch_execz 13                                         // 0000000579B8: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11f0>
	v_mad_i64_i32 v[3:4], null, 0xc0, v2, s[10:11]             // 0000000579BC: D6FF7C03 002A04FF 000000C0
	v_mad_i64_i32 v[5:6], null, 0xc0, v2, s[34:35]             // 0000000579C8: D6FF7C05 008A04FF 000000C0
	global_load_b32 v140, v[3:4], off                          // 0000000579D4: DC520000 8C7C0003
	global_load_b32 v2, v[5:6], off                            // 0000000579DC: DC520000 027C0005
	s_waitcnt vmcnt(0)                                         // 0000000579E4: BF8903F7
	scratch_store_b32 off, v2, off                             // 0000000579E8: DC690000 007C0200
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000579F0: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000579F4: BF870009
	s_or_b32 exec_lo, exec_lo, s29                             // 0000000579F8: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000579FC: BF870009
	s_and_b32 vcc_lo, exec_lo, s42                             // 000000057A00: 8B6A2A7E
	s_mov_b32 s3, -1                                           // 000000057A04: BE8300C1
	s_cbranch_vccz 81                                          // 000000057A08: BFA30051 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1350>
	v_and_b32_e32 v2, -16, v44                                 // 000000057A0C: 360458D0
	s_mov_b32 s3, exec_lo                                      // 000000057A10: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057A14: BF870001
	v_cmpx_eq_u32_e32 64, v2                                   // 000000057A18: 7D9404C0
	s_cbranch_execz 74                                         // 000000057A1C: BFA5004A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1348>
	v_lshlrev_b32_e32 v4, 2, v44                               // 000000057A20: 30085882
	s_waitcnt lgkmcnt(1)                                       // 000000057A24: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057A28: BF870001
	v_add_nc_u32_e32 v5, 0x5c00, v4                            // 000000057A2C: 4A0A08FF 00005C00
	ds_load_2addr_b32 v[2:3], v5 offset0:64 offset1:80         // 000000057A34: D8DC5040 02000005
	s_waitcnt lgkmcnt(1)                                       // 000000057A3C: BF89FC17
	ds_load_b32 v6, v1 offset:24188                            // 000000057A40: D8D85E7C 06000001
	s_waitcnt lgkmcnt(1)                                       // 000000057A48: BF89FC17
	v_mul_f32_e32 v7, 0x3fb8aa3b, v3                           // 000000057A4C: 100E06FF 3FB8AA3B
	ds_load_b32 v8, v4 offset:24128                            // 000000057A54: D8D85E40 08000004
	s_waitcnt lgkmcnt(1)                                       // 000000057A5C: BF89FC17
	v_sub_f32_e32 v6, v6, v3                                   // 000000057A60: 080C0706
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000057A64: 7C3606FF C2CE8ED0
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v7                          // 000000057A6C: D6130009 841E06FF 3FB8AA3B
	v_rndne_f32_e32 v10, v7                                    // 000000057A78: 7E144707
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000057A7C: BF870114
	v_mul_f32_e32 v11, 0x3fb8aa3b, v6                          // 000000057A80: 10160CFF 3FB8AA3B
	v_sub_f32_e32 v7, v7, v10                                  // 000000057A88: 080E1507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000057A8C: BF8701C2
	v_fma_f32 v12, 0x3fb8aa3b, v6, -v11                        // 000000057A90: D613000C 842E0CFF 3FB8AA3B
	v_fmac_f32_e32 v9, 0x32a5705f, v3                          // 000000057A9C: 561206FF 32A5705F
	v_cvt_i32_f32_e32 v10, v10                                 // 000000057AA4: 7E14110A
	v_rndne_f32_e32 v13, v11                                   // 000000057AA8: 7E1A470B
	v_dual_fmac_f32 v12, 0x32a5705f, v6 :: v_dual_add_f32 v7, v7, v9// 000000057AAC: C8080CFF 0C061307 32A5705F
	s_waitcnt lgkmcnt(0)                                       // 000000057AB8: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000057ABC: BF870112
	v_dual_sub_f32 v9, v11, v13 :: v_dual_mul_f32 v2, v8, v2   // 000000057AC0: C9461B0B 09020508
	v_exp_f32_e32 v7, v7                                       // 000000057AC8: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057ACC: BF870125
	.long 0xd71c0007                                           // 000000057AD0: D71C0007
	v_cndmask_b32_e32 v1, v7, v10, vcc_lo                      // 000000057AD4: 02021507
	v_cvt_i32_f32_e32 v10, v13                                 // 000000057AD8: 7E14110D
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo                        // 000000057ADC: 020E0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000057AE0: 7C3C06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000057AE8: BF8701B2
	v_cndmask_b32_e32 v3, 0x7f800000, v7, vcc_lo               // 000000057AEC: 02060EFF 7F800000
	v_add_f32_e32 v9, v9, v12                                  // 000000057AF4: 06121909
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v6                   // 000000057AF8: 7C360CFF C2CE8ED0
	v_mul_f32_e32 v2, v3, v2                                   // 000000057B00: 10040503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057B04: BF870093
	v_exp_f32_e32 v9, v9                                       // 000000057B08: 7E124B09
	v_mul_f32_e32 v2, 0x41800000, v2                           // 000000057B0C: 100404FF 41800000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057B14: BF870095
	.long 0xd71c0009                                           // 000000057B18: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000057B1C: 02021509
	v_cndmask_b32_e32 v7, 0, v9, vcc_lo                        // 000000057B20: 020E1280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v6                   // 000000057B24: 7C3C0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000057B2C: BF870002
	v_cndmask_b32_e32 v6, 0x7f800000, v7, vcc_lo               // 000000057B30: 020C0EFF 7F800000
	ds_store_b32 v4, v3 offset:24064                           // 000000057B38: D8345E00 00000304
	ds_store_2addr_b32 v5, v6, v2 offset0:96 offset1:112       // 000000057B40: D8387060 00020605
	s_or_b32 exec_lo, exec_lo, s3                              // 000000057B48: 8C7E037E
	s_mov_b32 s3, 0                                            // 000000057B4C: BE830080
	v_lshrrev_b32_e32 v154, 4, v43                             // 000000057B50: 33345684
	v_mul_u32_u24_e32 v57, 0x110, v55                          // 000000057B54: 16726EFF 00000110
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 000000057B5C: 916A037E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000057B60: BF870002
	v_lshlrev_b32_e32 v56, 2, v154                             // 000000057B64: 30713482
	s_cbranch_vccnz 872                                        // 000000057B68: BFA40368 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x210c>
	v_mad_u32_u24 v2, 0x110, v55, s49                          // 000000057B6C: D60B0002 00C66EFF 00000110
	s_and_b32 s3, s2, exec_lo                                  // 000000057B78: 8B037E02
	s_cselect_b32 s3, 0, 0x1100                                // 000000057B7C: 9803FF80 00001100
	v_mad_u32_u24 v3, 0x110, v55, s50                          // 000000057B84: D60B0003 00CA6EFF 00000110
	ds_load_b128 v[10:13], v57 offset:6144                     // 000000057B90: DBFC1800 0A000039
	ds_load_b128 v[14:17], v57 offset:6160                     // 000000057B98: DBFC1810 0E000039
	v_add_nc_u32_e32 v4, s3, v2                                // 000000057BA0: 4A080403
	v_mov_b32_e32 v8, v1                                       // 000000057BA4: 7E100301
	s_waitcnt lgkmcnt(3)                                       // 000000057BA8: BF89FC37
	v_mov_b32_e32 v5, v1                                       // 000000057BAC: 7E0A0301
	v_cndmask_b32_e64 v45, v3, v2, s2                          // 000000057BB0: D501002D 000A0503
	v_mov_b32_e32 v3, v1                                       // 000000057BB8: 7E060301
	ds_load_b128 v[18:21], v4                                  // 000000057BBC: DBFC0000 12000004
	ds_load_b128 v[22:25], v4 offset:16                        // 000000057BC4: DBFC0010 16000004
	ds_load_b128 v[26:29], v57 offset:6176                     // 000000057BCC: DBFC1820 1A000039
	ds_load_b128 v[30:33], v57 offset:6192                     // 000000057BD4: DBFC1830 1E000039
	ds_load_b128 v[59:62], v45 offset:32                       // 000000057BDC: DBFC0020 3B00002D
	ds_load_b128 v[63:66], v45 offset:48                       // 000000057BE4: DBFC0030 3F00002D
	ds_load_b128 v[155:158], v45 offset:64                     // 000000057BEC: DBFC0040 9B00002D
	ds_load_b128 v[159:162], v45 offset:80                     // 000000057BF4: DBFC0050 9F00002D
	ds_load_b128 v[167:170], v57 offset:6224                   // 000000057BFC: DBFC1850 A7000039
	ds_load_b128 v[163:166], v57 offset:6208                   // 000000057C04: DBFC1840 A3000039
	v_mov_b32_e32 v2, v1                                       // 000000057C0C: 7E040301
	v_mov_b32_e32 v4, v1                                       // 000000057C10: 7E080301
	s_waitcnt lgkmcnt(12)                                      // 000000057C14: BF89FCC7
	v_mov_b32_e32 v6, v1                                       // 000000057C18: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000057C1C: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 000000057C20: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000057C24: BF870212
	v_mov_b32_e32 v8, v7                                       // 000000057C28: 7E100307
	v_mov_b32_e32 v7, v6                                       // 000000057C2C: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 000000057C30: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000057C34: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000057C38: 7E080303
	v_mov_b32_e32 v3, v2                                       // 000000057C3C: 7E060302
	v_mov_b32_e32 v2, v1                                       // 000000057C40: 7E040301
	ds_load_b128 v[175:178], v57 offset:6256                   // 000000057C44: DBFC1870 AF000039
	ds_load_b128 v[171:174], v57 offset:6240                   // 000000057C4C: DBFC1860 AB000039
	ds_load_b128 v[183:186], v45 offset:112                    // 000000057C54: DBFC0070 B700002D
	ds_load_b128 v[179:182], v45 offset:96                     // 000000057C5C: DBFC0060 B300002D
	v_or_b32_e32 v49, 6, v154                                  // 000000057C64: 38633486
	v_or_b32_e32 v48, 8, v154                                  // 000000057C68: 38613488
	v_or_b32_e32 v47, 10, v154                                 // 000000057C6C: 385F348A
	s_waitcnt lgkmcnt(12)                                      // 000000057C70: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 000000057C74: CC414002 1C0A1512
	ds_load_b128 v[14:17], v57 offset:6288                     // 000000057C7C: DBFC1890 0E000039
	ds_load_b128 v[10:13], v57 offset:6272                     // 000000057C84: DBFC1880 0A000039
	ds_load_b128 v[22:25], v45 offset:144                      // 000000057C8C: DBFC0090 1600002D
	ds_load_b128 v[18:21], v45 offset:128                      // 000000057C94: DBFC0080 1200002D
	s_and_not1_b32 vcc_lo, exec_lo, s41                        // 000000057C9C: 916A297E
	s_mov_b32 s3, -1                                           // 000000057CA0: BE8300C1
	s_waitcnt lgkmcnt(12)                                      // 000000057CA4: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[59:66], v[26:33], v[2:9]// 000000057CA8: CC414002 1C0A353B
	ds_load_b128 v[30:33], v57 offset:6320                     // 000000057CB0: DBFC18B0 1E000039
	ds_load_b128 v[26:29], v57 offset:6304                     // 000000057CB8: DBFC18A0 1A000039
	ds_load_b128 v[65:68], v45 offset:176                      // 000000057CC0: DBFC00B0 4100002D
	ds_load_b128 v[61:64], v45 offset:160                      // 000000057CC8: DBFC00A0 3D00002D
	v_lshlrev_b32_e32 v60, 2, v55                              // 000000057CD0: 30786E82
	v_or_b32_e32 v59, 4, v154                                  // 000000057CD4: 38773484
	s_waitcnt lgkmcnt(12)                                      // 000000057CD8: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[155:162], v[163:170], v[2:9]// 000000057CDC: CC414002 1C0B479B
	ds_load_b128 v[159:162], v57 offset:6352                   // 000000057CE4: DBFC18D0 9F000039
	ds_load_b128 v[155:158], v57 offset:6336                   // 000000057CEC: DBFC18C0 9B000039
	v_add_nc_u32_e32 v46, 64, v60                              // 000000057CF4: 4A5C78C0
	ds_load_b128 v[167:170], v57 offset:6384                   // 000000057CF8: DBFC18F0 A7000039
	ds_load_b128 v[163:166], v57 offset:6368                   // 000000057D00: DBFC18E0 A3000039
	s_waitcnt lgkmcnt(12)                                      // 000000057D08: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[179:186], v[171:178], v[2:9]// 000000057D0C: CC414002 1C0B57B3
	ds_load_b128 v[175:178], v45 offset:208                    // 000000057D14: DBFC00D0 AF00002D
	ds_load_b128 v[171:174], v45 offset:192                    // 000000057D1C: DBFC00C0 AB00002D
	s_waitcnt lgkmcnt(10)                                      // 000000057D24: BF89FCA7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 000000057D28: CC414002 1C0A1512
	v_add_nc_u32_e32 v10, 0x5c00, v56                          // 000000057D30: 4A1470FF 00005C00
	v_add_nc_u32_e32 v11, s43, v56                             // 000000057D38: 4A16702B
	ds_load_b128 v[183:186], v45 offset:240                    // 000000057D3C: DBFC00F0 B700002D
	ds_load_b128 v[179:182], v45 offset:224                    // 000000057D44: DBFC00E0 B300002D
	ds_load_2addr_stride64_b32 v[12:13], v46 offset0:94 offset1:95// 000000057D4C: D8E05F5E 0C00002E
	v_or_b32_e32 v46, 12, v154                                 // 000000057D54: 385D348C
	s_waitcnt lgkmcnt(9)                                       // 000000057D58: BF89FC97
	v_wmma_f32_16x16x16_bf16 v[2:9], v[61:68], v[26:33], v[2:9]// 000000057D5C: CC414002 1C0A353D
	ds_load_2addr_b32 v[28:29], v10 offset0:144 offset1:146    // 000000057D64: D8DC9290 1C00000A
	ds_load_2addr_b32 v[24:25], v10 offset0:148 offset1:150    // 000000057D6C: D8DC9694 1800000A
	ds_load_2addr_b32 v[20:21], v10 offset0:152 offset1:154    // 000000057D74: D8DC9A98 1400000A
	ds_load_2addr_b32 v[16:17], v10 offset0:156 offset1:158    // 000000057D7C: D8DC9E9C 1000000A
	ds_load_2addr_b32 v[26:27], v11 offset1:2                  // 000000057D84: D8DC0200 1A00000B
	ds_load_2addr_b32 v[22:23], v11 offset0:4 offset1:6        // 000000057D8C: D8DC0604 1600000B
	ds_load_2addr_b32 v[18:19], v11 offset0:8 offset1:10       // 000000057D94: D8DC0A08 1200000B
	ds_load_2addr_b32 v[14:15], v11 offset0:12 offset1:14      // 000000057D9C: D8DC0E0C 0E00000B
	v_or_b32_e32 v61, 2, v154                                  // 000000057DA4: 387B3482
	v_or_b32_e32 v45, 14, v154                                 // 000000057DA8: 385B348E
	s_waitcnt lgkmcnt(11)                                      // 000000057DAC: BF89FCB7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[171:178], v[155:162], v[2:9]// 000000057DB0: CC414002 1C0B37AB
	s_waitcnt lgkmcnt(9)                                       // 000000057DB8: BF89FC97
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057DBC: BF870001
	v_wmma_f32_16x16x16_bf16 v[2:9], v[179:186], v[163:170], v[2:9]// 000000057DC0: CC414002 1C0B47B3
	s_cbranch_vccnz 353                                        // 000000057DC8: BFA40161 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b50>
	.long 0x7e143880                                           // 000000057DCC: 7E143880
	s_mov_b32 s3, exec_lo                                      // 000000057DD0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057DD4: BF870001
	.long 0x7f14390a                                           // 000000057DD8: 7F14390A
	.long 0xd4cb007e                                           // 000000057DDC: D4CB007E
	v_cndmask_b32_e32 v1, v55, v154, vcc_lo                    // 000000057DE0: 02033537
	s_cbranch_execz 34                                         // 000000057DE4: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1670>
	s_waitcnt lgkmcnt(7)                                       // 000000057DE8: BF89FC77
	v_sub_f32_e32 v11, v28, v12                                // 000000057DEC: 0816191C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057DF0: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v11                         // 000000057DF4: 103C16FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v11, -v30                       // 000000057DFC: D613001F 847A16FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 000000057E08: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057E0C: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v11 :: v_dual_sub_f32 v30, v30, v32// 000000057E10: C80A16FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 000000057E1C: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 000000057E20: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000057E24: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000057E2C: BF870293
	v_exp_f32_e32 v30, v30                                     // 000000057E30: 7E3C4B1E
	.long 0xd71c001e                                           // 000000057E34: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 000000057E38: 02023F1E
	s_waitcnt lgkmcnt(3)                                       // 000000057E3C: BF89FC37
	v_mul_f32_e32 v31, v2, v26                                 // 000000057E40: 103E3502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057E44: BF870122
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 000000057E48: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000057E4C: 7C3C16FF 42B17218
	v_dual_cndmask_b32 v11, 0x7f800000, v30 :: v_dual_mul_f32 v30, v13, v31// 000000057E54: CA463CFF 0B1E3F0D 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057E60: BF870091
	v_mul_f32_e32 v11, v11, v30                                // 000000057E64: 10163D0B
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 000000057E68: CC22000A 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000057E70: 8C7E037E
	v_mul_u32_u24_e32 v11, 48, v154                            // 000000057E74: 161734B0
	s_mov_b32 s3, exec_lo                                      // 000000057E78: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057E7C: BF870001
	v_lshl_add_u32 v11, v55, 1, v11                            // 000000057E80: D646000B 042D0337
	ds_store_b16_d16_hi v11, v10 offset:23296                  // 000000057E88: DA845B00 00000A0B
	.long 0xd4cb007e                                           // 000000057E90: D4CB007E
	v_cndmask_b32_e32 v1, v55, v61, vcc_lo                     // 000000057E94: 02027B37
	s_cbranch_execz 34                                         // 000000057E98: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1724>
	s_waitcnt lgkmcnt(8)                                       // 000000057E9C: BF89FC87
	v_sub_f32_e32 v10, v29, v12                                // 000000057EA0: 0814191D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057EA4: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v10                         // 000000057EA8: 103C14FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v30                       // 000000057EB0: D613001F 847A14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 000000057EBC: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057EC0: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v10 :: v_dual_sub_f32 v30, v30, v32// 000000057EC4: C80A14FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 000000057ED0: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 000000057ED4: 7E3E1120
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000057ED8: BF870292
	v_exp_f32_e32 v30, v30                                     // 000000057EDC: 7E3C4B1E
	.long 0xd71c001e                                           // 000000057EE0: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 000000057EE4: 02023F1E
	s_waitcnt lgkmcnt(4)                                       // 000000057EE8: BF89FC47
	v_mul_f32_e32 v31, v3, v27                                 // 000000057EEC: 103E3703
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000057EF0: 7C3614FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057EF8: BF870123
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 000000057EFC: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000057F00: 7C3C14FF 42B17218
	v_cndmask_b32_e32 v10, 0x7f800000, v30, vcc_lo             // 000000057F08: 02143CFF 7F800000
	v_mul_f32_e32 v30, v13, v31                                // 000000057F10: 103C3F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057F14: BF870091
	v_mul_f32_e32 v10, v10, v30                                // 000000057F18: 10143D0A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 000000057F1C: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 000000057F24: 8C7E037E
	.long 0x7f143880                                           // 000000057F28: 7F143880
	v_or_b32_e32 v30, 0x5b00, v11                              // 000000057F2C: 383C16FF 00005B00
	s_mov_b32 s3, exec_lo                                      // 000000057F34: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000057F38: BF870002
	.long 0x7e16398a                                           // 000000057F3C: 7E16398A
	ds_store_b16 v30, v10 offset:96                            // 000000057F40: D87C0060 00000A1E
	.long 0xd4cb007e                                           // 000000057F48: D4CB007E
	v_cndmask_b32_e32 v1, v55, v59, vcc_lo                     // 000000057F4C: 02027737
	s_cbranch_execz 35                                         // 000000057F50: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x17e0>
	s_waitcnt lgkmcnt(8)                                       // 000000057F54: BF89FC87
	v_sub_f32_e32 v11, v24, v12                                // 000000057F58: 08161918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057F5C: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000057F60: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000057F68: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000057F70: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 000000057F7C: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057F80: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000057F84: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000057F90: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000057F94: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000057F98: BF870292
	v_exp_f32_e32 v31, v31                                     // 000000057F9C: 7E3E4B1F
	.long 0xd71c001f                                           // 000000057FA0: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000057FA4: 0202411F
	s_waitcnt lgkmcnt(4)                                       // 000000057FA8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000057FAC: BF870121
	v_dual_mul_f32 v32, v4, v22 :: v_dual_cndmask_b32 v31, 0, v31// 000000057FB0: C8D22D04 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000057FB8: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000057FC0: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000057FC8: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 000000057FCC: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 000000057FD0: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000057FD4: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 000000057FD8: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000057FE0: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000057FE4: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000057FE8: BE83007E
	ds_store_b16 v30, v11 offset:192                           // 000000057FEC: D87C00C0 00000B1E
	.long 0xd4cb007e                                           // 000000057FF4: D4CB007E
	v_cndmask_b32_e32 v1, v55, v49, vcc_lo                     // 000000057FF8: 02026337
	s_cbranch_execz 35                                         // 000000057FFC: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x188c>
	s_waitcnt lgkmcnt(9)                                       // 000000058000: BF89FC97
	v_sub_f32_e32 v10, v25, v12                                // 000000058004: 08141919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058008: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000005800C: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000058014: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000058020: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000058024: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000058028: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000058030: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000058034: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000058038: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000005803C: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000058040: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 000000058048: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000005804C: BF870135
	.long 0xd71c000b                                           // 000000058050: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000058054: 02023F0B
	s_waitcnt lgkmcnt(5)                                       // 000000058058: BF89FC57
	v_mul_f32_e32 v31, v5, v23                                 // 00000005805C: 103E2F05
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000058060: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000058064: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005806C: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000058070: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 000000058078: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005807C: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000058080: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 000000058084: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005808C: 8C7E037E
	.long 0x7e143880                                           // 000000058090: 7E143880
	s_mov_b32 s3, exec_lo                                      // 000000058094: BE83007E
	ds_store_b16_d16_hi v30, v10 offset:288                    // 000000058098: DA840120 00000A1E
	.long 0x7e16390a                                           // 0000000580A0: 7E16390A
	.long 0xd4cb007e                                           // 0000000580A4: D4CB007E
	v_cndmask_b32_e32 v1, v55, v48, vcc_lo                     // 0000000580A8: 02026137
	s_cbranch_execz 34                                         // 0000000580AC: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1938>
	s_waitcnt lgkmcnt(9)                                       // 0000000580B0: BF89FC97
	v_sub_f32_e32 v11, v20, v12                                // 0000000580B4: 08161914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000580B8: BF870091
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 0000000580BC: 103E16FF 3FB8AA3B
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 0000000580C4: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 0000000580D0: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000580D4: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 0000000580D8: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 0000000580E4: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 0000000580E8: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000580EC: BF870292
	v_exp_f32_e32 v31, v31                                     // 0000000580F0: 7E3E4B1F
	.long 0xd71c001f                                           // 0000000580F4: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000000580F8: 0202411F
	s_waitcnt lgkmcnt(5)                                       // 0000000580FC: BF89FC57
	v_mul_f32_e32 v32, v6, v18                                 // 000000058100: 10402506
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000058104: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005810C: BF870123
	v_cndmask_b32_e32 v31, 0, v31, vcc_lo                      // 000000058110: 023E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000058114: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000005811C: 02163EFF 7F800000
	v_mul_f32_e32 v31, v13, v32                                // 000000058124: 103E410D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058128: BF870091
	v_mul_f32_e32 v11, v11, v31                                // 00000005812C: 10163F0B
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 000000058130: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000058138: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000005813C: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000058140: BE83007E
	ds_store_b16 v30, v11 offset:384                           // 000000058144: D87C0180 00000B1E
	.long 0xd4cb007e                                           // 00000005814C: D4CB007E
	v_cndmask_b32_e32 v1, v55, v47, vcc_lo                     // 000000058150: 02025F37
	s_cbranch_execz 35                                         // 000000058154: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x19e4>
	s_waitcnt lgkmcnt(10)                                      // 000000058158: BF89FCA7
	v_sub_f32_e32 v10, v21, v12                                // 00000005815C: 08141915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058160: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 000000058164: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 00000005816C: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000058178: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005817C: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000058180: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000058188: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000005818C: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000058190: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 000000058194: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000058198: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 0000000581A0: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000581A4: BF870135
	.long 0xd71c000b                                           // 0000000581A8: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 0000000581AC: 02023F0B
	s_waitcnt lgkmcnt(6)                                       // 0000000581B0: BF89FC67
	v_mul_f32_e32 v31, v7, v19                                 // 0000000581B4: 103E2707
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 0000000581B8: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 0000000581BC: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000581C4: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 0000000581C8: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 0000000581D0: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000581D4: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 0000000581D8: 1014170A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 0000000581DC: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000581E4: 8C7E037E
	.long 0x7f143880                                           // 0000000581E8: 7F143880
	s_mov_b32 s3, exec_lo                                      // 0000000581EC: BE83007E
	ds_store_b16 v30, v10 offset:480                           // 0000000581F0: D87C01E0 00000A1E
	.long 0x7e16398a                                           // 0000000581F8: 7E16398A
	.long 0xd4cb007e                                           // 0000000581FC: D4CB007E
	v_cndmask_b32_e32 v1, v55, v46, vcc_lo                     // 000000058200: 02025D37
	s_cbranch_execz 35                                         // 000000058204: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1a94>
	s_waitcnt lgkmcnt(10)                                      // 000000058208: BF89FCA7
	v_sub_f32_e32 v11, v16, v12                                // 00000005820C: 08161910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000058210: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000058214: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000005821C: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000058224: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 000000058230: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058234: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000058238: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000058244: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000058248: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005824C: BF870292
	v_exp_f32_e32 v31, v31                                     // 000000058250: 7E3E4B1F
	.long 0xd71c001f                                           // 000000058254: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000058258: 0202411F
	s_waitcnt lgkmcnt(6)                                       // 00000005825C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000058260: BF870121
	v_dual_mul_f32 v32, v8, v14 :: v_dual_cndmask_b32 v31, 0, v31// 000000058264: C8D21D08 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000005826C: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000058274: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005827C: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 000000058280: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 000000058284: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000058288: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 00000005828C: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000058294: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000058298: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000005829C: BE83007E
	ds_store_b16 v30, v11 offset:576                           // 0000000582A0: D87C0240 00000B1E
	.long 0xd4cb007e                                           // 0000000582A8: D4CB007E
	v_cndmask_b32_e32 v1, v55, v45, vcc_lo                     // 0000000582AC: 02025B37
	s_cbranch_execz 35                                         // 0000000582B0: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b40>
	s_waitcnt lgkmcnt(11)                                      // 0000000582B4: BF89FCB7
	v_sub_f32_e32 v10, v17, v12                                // 0000000582B8: 08141911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000582BC: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 0000000582C0: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 0000000582C8: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 0000000582D4: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000582D8: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 0000000582DC: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 0000000582E4: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000582E8: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 0000000582EC: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 0000000582F0: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 0000000582F4: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 0000000582FC: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000058300: BF870135
	.long 0xd71c000b                                           // 000000058304: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000058308: 02023F0B
	s_waitcnt lgkmcnt(7)                                       // 00000005830C: BF89FC77
	v_mul_f32_e32 v31, v9, v15                                 // 000000058310: 103E1F09
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000058314: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000058318: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000058320: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000058324: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000005832C: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058330: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000058334: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 000000058338: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 000000058340: 8C7E037E
	s_mov_b32 s3, 0                                            // 000000058344: BE830080
	ds_store_b16_d16_hi v30, v10 offset:672                    // 000000058348: DA8402A0 00000A1E
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000058350: 8B6A037E
	s_cbranch_vccz 365                                         // 000000058354: BFA3016D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x210c>
	v_or_b32_e32 v10, 0x5e40, v56                              // 000000058358: 381470FF 00005E40
	v_mov_b32_e32 v63, 0                                       // 000000058360: 7E7E0280
	v_mov_b32_e32 v65, 0                                       // 000000058364: 7E820280
	s_mov_b32 s3, exec_lo                                      // 000000058368: BE83007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000005836C: BF870003
	v_subrev_nc_u32_e32 v64, 64, v10                           // 000000058370: 4E8014C0
	ds_load_2addr_b32 v[32:33], v64 offset0:2 offset1:4        // 000000058374: D8DC0402 20000040
	ds_load_2addr_b32 v[30:31], v64 offset0:6 offset1:8        // 00000005837C: D8DC0806 1E000040
	ds_load_2addr_b32 v[10:11], v64 offset0:10 offset1:12      // 000000058384: D8DC0C0A 0A000040
	ds_load_b32 v62, v64 offset:56                             // 00000005838C: D8D80038 3E000040
	.long 0xd4c9007e                                           // 000000058394: D4C9007E
	v_cndmask_b32_e32 v1, v55, v154, vcc_lo                    // 000000058398: 02033537
	s_cbranch_execz 37                                         // 00000005839C: BFA50025 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1c34>
	s_waitcnt lgkmcnt(11)                                      // 0000000583A0: BF89FCB7
	v_sub_f32_e32 v28, v28, v12                                // 0000000583A4: 0838191C
	ds_load_b32 v64, v64                                       // 0000000583A8: D8D80000 40000040
	s_waitcnt lgkmcnt(8)                                       // 0000000583B0: BF89FC87
	v_dual_mul_f32 v2, v2, v26 :: v_dual_mul_f32 v65, 0x3fb8aa3b, v28// 0000000583B4: C8C63502 024038FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000583C0: BF870111
	v_mul_f32_e32 v2, v13, v2                                  // 0000000583C4: 1004050D
	v_fma_f32 v66, 0x3fb8aa3b, v28, -v65                       // 0000000583C8: D6130042 850638FF 3FB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 0000000583D4: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000583D8: BF8701C1
	v_dual_sub_f32 v65, v65, v67 :: v_dual_fmac_f32 v66, 0x32a5705f, v28// 0000000583DC: C9408741 414238FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v28                  // 0000000583E8: 7C3638FF C2CE8ED0
	s_waitcnt lgkmcnt(0)                                       // 0000000583F0: BF89FC07
	v_mul_f32_e32 v2, v64, v2                                  // 0000000583F4: 10040540
	v_add_f32_e32 v65, v65, v66                                // 0000000583F8: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 0000000583FC: 7E841143
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000058400: BF870292
	v_exp_f32_e32 v65, v65                                     // 000000058404: 7E824B41
	.long 0xd71c0041                                           // 000000058408: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000005840C: 02028541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000058410: BF870121
	v_cndmask_b32_e32 v26, 0, v65, vcc_lo                      // 000000058414: 02348280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v28                  // 000000058418: 7C3C38FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 000000058420: 023434FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000058428: BF870001
	.long 0xd5080041                                           // 00000005842C: D5080041
	v_sub_co_ci_u32_e32 v1, vcc_lo, v2, v26, vcc_lo            // 000000058430: 42023502
	s_or_b32 exec_lo, exec_lo, s3                              // 000000058434: 8C7E037E
	v_or_b32_e32 v2, 0x5e40, v60                               // 000000058438: 380478FF 00005E40
	s_waitcnt lgkmcnt(7)                                       // 000000058440: BF89FC77
	v_lshlrev_b32_e32 v26, 6, v154                             // 000000058444: 30353486
	s_mov_b32 s3, exec_lo                                      // 000000058448: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005844C: BF870001
	v_add3_u32 v2, v2, v26, 0xfffff8c0                         // 000000058450: D6550002 03FE3502 FFFFF8C0
	ds_store_b32 v2, v65                                       // 00000005845C: D8340000 00004102
	.long 0xd4c9007e                                           // 000000058464: D4C9007E
	v_cndmask_b32_e32 v1, v55, v61, vcc_lo                     // 000000058468: 02027B37
	s_cbranch_execz 33                                         // 00000005846C: BFA50021 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1cf4>
	v_dual_sub_f32 v26, v29, v12 :: v_dual_mul_f32 v3, v3, v27 // 000000058470: C946191D 1A023703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000058478: BF870121
	v_dual_mul_f32 v28, 0x3fb8aa3b, v26 :: v_dual_mul_f32 v3, v13, v3// 00000005847C: C8C634FF 1C02070D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v26                  // 000000058488: 7C3634FF C2CE8ED0
	v_fma_f32 v29, 0x3fb8aa3b, v26, -v28                       // 000000058490: D613001D 847234FF 3FB8AA3B
	v_rndne_f32_e32 v60, v28                                   // 00000005849C: 7E78471C
	s_waitcnt lgkmcnt(4)                                       // 0000000584A0: BF89FC47
	v_mul_f32_e32 v3, v32, v3                                  // 0000000584A4: 10060720
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000584A8: BF870092
	v_dual_fmac_f32 v29, 0x32a5705f, v26 :: v_dual_sub_f32 v28, v28, v60// 0000000584AC: C80A34FF 1D1C791C 32A5705F
	v_add_f32_e32 v28, v28, v29                                // 0000000584B8: 06383B1C
	v_cvt_i32_f32_e32 v29, v60                                 // 0000000584BC: 7E3A113C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000584C0: BF870292
	v_exp_f32_e32 v28, v28                                     // 0000000584C4: 7E384B1C
	.long 0xd71c001c                                           // 0000000584C8: D71C001C
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                     // 0000000584CC: 02023B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000584D0: BF870121
	v_cndmask_b32_e32 v27, 0, v28, vcc_lo                      // 0000000584D4: 02363880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v26                  // 0000000584D8: 7C3C34FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v27, vcc_lo             // 0000000584E0: 023436FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000584E8: BF870001
	.long 0xd508003f                                           // 0000000584EC: D508003F
	v_sub_co_ci_u32_e32 v1, vcc_lo, v3, v26, vcc_lo            // 0000000584F0: 42023503
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000584F4: 8C7E037E
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v26, 0              // 0000000584F8: CA100080 031A0080
	s_mov_b32 s3, exec_lo                                      // 000000058500: BE83007E
	ds_store_b32 v2, v63 offset:128                            // 000000058504: D8340080 00003F02
	.long 0xd4c9007e                                           // 00000005850C: D4C9007E
	v_cndmask_b32_e32 v1, v55, v59, vcc_lo                     // 000000058510: 02027737
	s_cbranch_execz 35                                         // 000000058514: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1da4>
	v_sub_f32_e32 v24, v24, v12                                // 000000058518: 08301918
	s_waitcnt lgkmcnt(8)                                       // 00000005851C: BF89FC87
	v_mul_f32_e32 v4, v4, v22                                  // 000000058520: 10082D04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000058524: BF8701A2
	v_mul_f32_e32 v26, 0x3fb8aa3b, v24                         // 000000058528: 103430FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v24                  // 000000058530: 7C3630FF C2CE8ED0
	v_mul_f32_e32 v4, v13, v4                                  // 000000058538: 1008090D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000005853C: BF8701B3
	v_fma_f32 v27, 0x3fb8aa3b, v24, -v26                       // 000000058540: D613001B 846A30FF 3FB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000005854C: 7E38471A
	s_waitcnt lgkmcnt(5)                                       // 000000058550: BF89FC57
	v_mul_f32_e32 v4, v33, v4                                  // 000000058554: 10080921
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000058558: BF870193
	v_fmac_f32_e32 v27, 0x32a5705f, v24                        // 00000005855C: 563630FF 32A5705F
	v_sub_f32_e32 v26, v26, v28                                // 000000058564: 0834391A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000058568: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000005856C: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000058570: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000058574: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058578: BF870095
	.long 0xd71c001a                                           // 00000005857C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000058580: 0202371A
	v_cndmask_b32_e32 v22, 0, v26, vcc_lo                      // 000000058584: 022C3480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v24                  // 000000058588: 7C3C30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058590: BF870092
	v_cndmask_b32_e32 v22, 0x7f800000, v22, vcc_lo             // 000000058594: 022C2CFF 7F800000
	.long 0xd508001a                                           // 00000005859C: D508001A
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v22, vcc_lo            // 0000000585A0: 42022D04
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000585A4: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000585A8: BF870009
	s_mov_b32 s3, exec_lo                                      // 0000000585AC: BE83007E
	ds_store_b32 v2, v26 offset:256                            // 0000000585B0: D8340100 00001A02
	.long 0xd4c9007e                                           // 0000000585B8: D4C9007E
	v_cndmask_b32_e32 v1, v55, v49, vcc_lo                     // 0000000585BC: 02026337
	s_cbranch_execz 34                                         // 0000000585C0: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1e4c>
	v_sub_f32_e32 v3, v25, v12                                 // 0000000585C4: 08061919
	s_waitcnt lgkmcnt(9)                                       // 0000000585C8: BF89FC97
	v_mul_f32_e32 v5, v5, v23                                  // 0000000585CC: 100A2F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000585D0: BF870091
	v_dual_mul_f32 v4, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, v13, v5// 0000000585D4: C8C606FF 04040B0D 3FB8AA3B
	v_fma_f32 v22, 0x3fb8aa3b, v3, -v4                         // 0000000585E0: D6130016 841206FF 3FB8AA3B
	v_rndne_f32_e32 v24, v4                                    // 0000000585EC: 7E304704
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000585F0: BF870112
	v_fmac_f32_e32 v22, 0x32a5705f, v3                         // 0000000585F4: 562C06FF 32A5705F
	v_sub_f32_e32 v4, v4, v24                                  // 0000000585FC: 08083104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000058600: BF8701B1
	v_add_f32_e32 v4, v4, v22                                  // 000000058604: 06082D04
	v_cvt_i32_f32_e32 v22, v24                                 // 000000058608: 7E2C1118
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000005860C: 7C3606FF C2CE8ED0
	v_exp_f32_e32 v4, v4                                       // 000000058614: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058618: BF870095
	.long 0xd71c0004                                           // 00000005861C: D71C0004
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 000000058620: 02022D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 000000058624: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000058628: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(5)                                       // 000000058630: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058634: BF870092
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v30, v5// 000000058638: CA4608FF 03040B1E 7F800000
	.long 0xd5080003                                           // 000000058644: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 000000058648: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005864C: 8C7E037E
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 000000058650: CA100080 04040080
	s_mov_b32 s3, exec_lo                                      // 000000058658: BE83007E
	ds_store_b32 v2, v3 offset:384                             // 00000005865C: D8340180 00000302
	.long 0xd4c9007e                                           // 000000058664: D4C9007E
	v_cndmask_b32_e32 v1, v55, v48, vcc_lo                     // 000000058668: 02026137
	s_cbranch_execz 34                                         // 00000005866C: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1ef8>
	s_waitcnt lgkmcnt(9)                                       // 000000058670: BF89FC97
	v_dual_sub_f32 v3, v20, v12 :: v_dual_mul_f32 v6, v6, v18  // 000000058674: C9461914 03062506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005867C: BF870121
	v_dual_mul_f32 v5, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v6, v13, v6// 000000058680: C8C606FF 05060D0D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000005868C: 7C3606FF C2CE8ED0
	v_fma_f32 v20, 0x3fb8aa3b, v3, -v5                         // 000000058694: D6130014 841606FF 3FB8AA3B
	v_rndne_f32_e32 v22, v5                                    // 0000000586A0: 7E2C4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000586A4: BF870091
	v_dual_fmac_f32 v20, 0x32a5705f, v3 :: v_dual_sub_f32 v5, v5, v22// 0000000586A8: C80A06FF 14042D05 32A5705F
	v_add_f32_e32 v5, v5, v20                                  // 0000000586B4: 060A2905
	v_cvt_i32_f32_e32 v20, v22                                 // 0000000586B8: 7E281116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000586BC: BF870292
	v_exp_f32_e32 v5, v5                                       // 0000000586C0: 7E0A4B05
	.long 0xd71c0005                                           // 0000000586C4: D71C0005
	v_cndmask_b32_e32 v1, v5, v20, vcc_lo                      // 0000000586C8: 02022905
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000586CC: BF870121
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo                        // 0000000586D0: 020A0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 0000000586D4: 7C3C06FF 42B17218
	v_cndmask_b32_e32 v3, 0x7f800000, v5, vcc_lo               // 0000000586DC: 02060AFF 7F800000
	s_waitcnt lgkmcnt(6)                                       // 0000000586E4: BF89FC67
	v_mul_f32_e32 v5, v31, v6                                  // 0000000586E8: 100A0D1F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000586EC: BF870001
	.long 0xd5080005                                           // 0000000586F0: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v3, vcc_lo             // 0000000586F4: 42020705
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000586F8: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000586FC: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000058700: BE83007E
	ds_store_b32 v2, v5 offset:512                             // 000000058704: D8340200 00000502
	.long 0xd4c9007e                                           // 00000005870C: D4C9007E
	v_cndmask_b32_e32 v1, v55, v47, vcc_lo                     // 000000058710: 02025F37
	s_cbranch_execz 35                                         // 000000058714: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1fa4>
	v_sub_f32_e32 v3, v21, v12                                 // 000000058718: 08061915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005871C: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 000000058720: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 000000058728: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 000000058734: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000058738: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 00000005873C: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000058740: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 000000058748: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000058750: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 000000058754: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 000000058758: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 00000005875C: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000058760: BF8700A5
	.long 0xd71c0004                                           // 000000058764: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 000000058768: 02020B04
	s_waitcnt lgkmcnt(10)                                      // 00000005876C: BF89FCA7
	v_dual_mul_f32 v5, v7, v19 :: v_dual_cndmask_b32 v4, 0, v4 // 000000058770: C8D22707 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000058778: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 00000005877C: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000058780: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(6)                                       // 000000058788: BF89FC67
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v10, v5// 00000005878C: CA4608FF 03040B0A 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000058798: BF870001
	.long 0xd5080004                                           // 00000005879C: D5080004
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 0000000587A0: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000587A4: 8C7E037E
	v_mov_b32_e32 v3, 0                                        // 0000000587A8: 7E060280
	v_mov_b32_e32 v5, 0                                        // 0000000587AC: 7E0A0280
	s_mov_b32 s3, exec_lo                                      // 0000000587B0: BE83007E
	ds_store_b32 v2, v4 offset:640                             // 0000000587B4: D8340280 00000402
	.long 0xd4c9007e                                           // 0000000587BC: D4C9007E
	v_cndmask_b32_e32 v1, v55, v46, vcc_lo                     // 0000000587C0: 02025D37
	s_cbranch_execz 35                                         // 0000000587C4: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2054>
	v_sub_f32_e32 v4, v16, v12                                 // 0000000587C8: 08081910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000587CC: BF870091
	v_mul_f32_e32 v5, 0x3fb8aa3b, v4                           // 0000000587D0: 100A08FF 3FB8AA3B
	v_fma_f32 v6, 0x3fb8aa3b, v4, -v5                          // 0000000587D8: D6130006 841608FF 3FB8AA3B
	v_rndne_f32_e32 v7, v5                                     // 0000000587E4: 7E0E4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000587E8: BF870221
	v_sub_f32_e32 v5, v5, v7                                   // 0000000587EC: 080A0F05
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 0000000587F0: 7C3608FF C2CE8ED0
	v_fmac_f32_e32 v6, 0x32a5705f, v4                          // 0000000587F8: 560C08FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000058800: BF870121
	v_add_f32_e32 v5, v5, v6                                   // 000000058804: 060A0D05
	v_cvt_i32_f32_e32 v6, v7                                   // 000000058808: 7E0C1107
	v_exp_f32_e32 v5, v5                                       // 00000005880C: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000058810: BF8700A5
	.long 0xd71c0005                                           // 000000058814: D71C0005
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 000000058818: 02020D05
	s_waitcnt lgkmcnt(10)                                      // 00000005881C: BF89FCA7
	v_dual_mul_f32 v6, v8, v14 :: v_dual_cndmask_b32 v5, 0, v5 // 000000058820: C8D21D08 06040A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000058828: BF870131
	v_mul_f32_e32 v6, v13, v6                                  // 00000005882C: 100C0D0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 000000058830: 7C3C08FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 000000058838: BF89FC77
	v_dual_cndmask_b32 v4, 0x7f800000, v5 :: v_dual_mul_f32 v5, v11, v6// 00000005883C: CA460AFF 04040D0B 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000058848: BF870001
	.long 0xd5080005                                           // 00000005884C: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v4, vcc_lo             // 000000058850: 42020905
	s_or_b32 exec_lo, exec_lo, s3                              // 000000058854: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000058858: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000005885C: BE83007E
	ds_store_b32 v2, v5 offset:768                             // 000000058860: D8340300 00000502
	.long 0xd4c9007e                                           // 000000058868: D4C9007E
	v_cndmask_b32_e32 v1, v55, v45, vcc_lo                     // 00000005886C: 02025B37
	s_cbranch_execz 35                                         // 000000058870: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2100>
	v_sub_f32_e32 v3, v17, v12                                 // 000000058874: 08061911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058878: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 00000005887C: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 000000058884: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 000000058890: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000058894: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 000000058898: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000005889C: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 0000000588A4: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000588AC: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 0000000588B0: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 0000000588B4: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 0000000588B8: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000588BC: BF8700A5
	.long 0xd71c0004                                           // 0000000588C0: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 0000000588C4: 02020B04
	s_waitcnt lgkmcnt(11)                                      // 0000000588C8: BF89FCB7
	v_dual_mul_f32 v5, v9, v15 :: v_dual_cndmask_b32 v4, 0, v4 // 0000000588CC: C8D21F09 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000588D4: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 0000000588D8: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 0000000588DC: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 0000000588E4: BF89FC77
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v62, v5// 0000000588E8: CA4608FF 03040B3E 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000588F4: BF870001
	.long 0xd5080003                                           // 0000000588F8: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 0000000588FC: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 000000058900: 8C7E037E
	ds_store_b32 v2, v3 offset:896                             // 000000058904: D8340380 00000302
	s_waitcnt lgkmcnt(0)                                       // 00000005890C: BF89FC07
	s_barrier                                                  // 000000058910: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s41                             // 000000058914: 8B6A297E
	s_mov_b32 s3, -1                                           // 000000058918: BE8300C1
	s_cbranch_vccz 176                                         // 00000005891C: BFA300B0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x23e0>
	s_mov_b32 s3, exec_lo                                      // 000000058920: BE83007E
	v_cmpx_gt_i32_e32 0x120, v44                               // 000000058924: 7D8858FF 00000120
	s_cbranch_execz 170                                        // 00000005892C: BFA500AA <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x23d8>
	v_add_nc_u32_e32 v2, 0xffffff00, v44                       // 000000058930: 4A0458FF FFFFFF00
	s_mov_b32 s4, 0                                            // 000000058938: BE840080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005893C: BF870001
	v_mov_b32_e32 v3, v2                                       // 000000058940: 7E060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000058944: BF8700A1
	v_add_nc_u32_e32 v3, 0xe0, v3                              // 000000058948: 4A0606FF 000000E0
	s_waitcnt lgkmcnt(4)                                       // 000000058950: BF89FC47
	v_ashrrev_i32_e32 v16, 7, v3                               // 000000058954: 34200687
	v_and_b32_e32 v12, 0x7f, v3                                // 000000058958: 361806FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058960: BF870092
	.long 0xd72c0004                                           // 000000058964: D72C0004
	v_cndmask_b32_e32 v1, 0x880, v16, vcc_lo                   // 000000058968: 020220FF 00000880
	v_lshl_add_u32 v4, v12, 1, v4                              // 000000058970: D6460004 0411030C
	ds_load_u16 v20, v4 offset:7776                            // 000000058978: D8F01E60 14000004
	ds_load_u16 v21, v4 offset:7232                            // 000000058980: D8F01C40 15000004
	s_waitcnt lgkmcnt(4)                                       // 000000058988: BF89FC47
	ds_load_u16 v22, v4 offset:6688                            // 00000005898C: D8F01A20 16000004
	ds_load_u16 v23, v4 offset:6144                            // 000000058994: D8F01800 17000004
	ds_load_u16 v24, v4 offset:6416                            // 00000005899C: D8F01910 18000004
	s_waitcnt lgkmcnt(3)                                       // 0000000589A4: BF89FC37
	v_lshlrev_b32_e32 v21, 16, v21                             // 0000000589A8: 302A2A90
	s_waitcnt lgkmcnt(1)                                       // 0000000589AC: BF89FC17
	v_lshlrev_b32_e32 v23, 16, v23                             // 0000000589B0: 302E2E90
	v_lshlrev_b32_e32 v17, 5, v16                              // 0000000589B4: 30222085
	ds_load_u16 v25, v4 offset:6960                            // 0000000589B8: D8F01B30 19000004
	ds_load_u16 v26, v4 offset:7504                            // 0000000589C0: D8F01D50 1A000004
	ds_load_u16 v27, v4 offset:8048                            // 0000000589C8: D8F01F70 1B000004
	ds_load_b128 v[4:7], v17 offset:24384                      // 0000000589D0: DBFC5F40 04000011
	ds_load_b128 v[8:11], v17 offset:24400                     // 0000000589D8: DBFC5F50 08000011
	v_lshlrev_b32_e32 v20, 16, v20                             // 0000000589E0: 30282890
	s_waitcnt lgkmcnt(0)                                       // 0000000589E4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000589E8: BF870091
	v_dual_mul_f32 v10, v10, v20 :: v_dual_lshlrev_b32 v25, 16, v25// 0000000589EC: C8E2290A 0A183290
	v_dual_mul_f32 v7, v7, v25 :: v_dual_lshlrev_b32 v24, 16, v24// 0000000589F4: C8E23307 07183090
	v_mul_f32_e32 v8, v8, v21                                  // 0000000589FC: 10102B08
	s_delay_alu instid0(VALU_DEP_2)                            // 000000058A00: BF870002
	v_dual_mul_f32 v4, v4, v23 :: v_dual_mul_f32 v5, v5, v24   // 000000058A04: C8C62F04 04043105
	v_mul_u32_u24_e32 v18, 48, v12                             // 000000058A0C: 162418B0
	ds_load_b128 v[12:15], v17 offset:24192                    // 000000058A10: DBFC5E80 0C000011
	v_lshlrev_b32_e32 v26, 16, v26                             // 000000058A18: 30343490
	v_lshlrev_b32_e32 v27, 16, v27                             // 000000058A1C: 30363690
	v_lshl_add_u32 v28, v16, 4, v18                            // 000000058A20: D646001C 04490910
	ds_load_b128 v[16:19], v17 offset:24208                    // 000000058A28: DBFC5E90 10000011
	s_waitcnt lgkmcnt(1)                                       // 000000058A30: BF89FC17
	v_mul_f32_e32 v12, v12, v4                                 // 000000058A34: 1018090C
	v_mul_f32_e32 v4, v13, v5                                  // 000000058A38: 10080B0D
	v_dual_mul_f32 v11, v11, v27 :: v_dual_lshlrev_b32 v22, 16, v22// 000000058A3C: C8E2370B 0B162C90
	v_mul_f32_e32 v5, v15, v7                                  // 000000058A44: 100A0F0F
	v_mul_f32_e32 v9, v9, v26                                  // 000000058A48: 10123509
	s_waitcnt lgkmcnt(0)                                       // 000000058A4C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000058A50: BF870243
	v_dual_mul_f32 v7, v16, v8 :: v_dual_mul_f32 v6, v6, v22   // 000000058A54: C8C61110 07062D06
	v_cmp_lt_i32_e32 vcc_lo, 31, v3                            // 000000058A5C: 7C82069F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 000000058A60: CC220004 02006104
	v_dual_mul_f32 v8, v17, v9 :: v_dual_mul_f32 v9, v18, v10  // 000000058A68: C8C61311 08081512
	v_mul_f32_e32 v6, v14, v6                                  // 000000058A70: 100C0D0E
	v_mul_f32_e32 v10, v19, v11                                // 000000058A74: 10141713
	v_fma_mixlo_f16 v4, v12, s48, 0                            // 000000058A78: CC210004 0200610C
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 000000058A80: CC220005 02006105
	s_or_b32 s4, vcc_lo, s4                                    // 000000058A88: 8C04046A
	v_fma_mixlo_f16 v5, v6, s48, 0                             // 000000058A8C: CC210005 02006106
	v_fma_mixhi_f16 v6, v8, s48, 0                             // 000000058A94: CC220006 02006108
	v_fma_mixlo_f16 v6, v7, s48, 0                             // 000000058A9C: CC210006 02006107
	v_fma_mixhi_f16 v7, v10, s48, 0                            // 000000058AA4: CC220007 0200610A
	v_fma_mixlo_f16 v7, v9, s48, 0                             // 000000058AAC: CC210007 02006109
	ds_store_b128 v28, v[4:7]                                  // 000000058AB4: DB7C0000 0000041C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000058ABC: 917E047E
	s_cbranch_execnz 65440                                     // 000000058AC0: BFA6FFA0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2144>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000058AC4: 8C7E047E
	v_lshl_add_u32 v3, v44, 3, 0xffffff00                      // 000000058AC8: D6460003 03FD072C FFFFFF00
	s_mov_b32 s4, 0                                            // 000000058AD4: BE840080
	v_add_nc_u32_e32 v2, 0xe0, v2                              // 000000058AD8: 4A0404FF 000000E0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000058AE0: BF8701A2
	v_and_b32_e32 v4, 0x78, v3                                 // 000000058AE4: 360806FF 00000078
	v_add_nc_u32_e32 v3, 0x700, v3                             // 000000058AEC: 4A0606FF 00000700
	v_ashrrev_i32_e32 v5, 4, v2                                // 000000058AF4: 340A0484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000058AF8: BF870121
	.long 0xd72c0006                                           // 000000058AFC: D72C0006
	v_cndmask_b32_e32 v1, 0x110, v5, vcc_lo                    // 000000058B00: 02020AFF 00000110
	v_lshlrev_b32_e32 v8, 2, v5                                // 000000058B08: 30100A82
	v_lshl_add_u32 v9, v4, 1, v6                               // 000000058B0C: D6460009 04190304
	ds_load_b128 v[4:7], v9 offset:10496                       // 000000058B14: DBFC2900 04000009
	ds_load_b32 v8, v8 offset:24448                            // 000000058B1C: D8D85F80 08000008
	s_waitcnt lgkmcnt(1)                                       // 000000058B24: BF89FC17
	v_and_b32_e32 v12, 0xffff0000, v6                          // 000000058B28: 36180CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000058B30: 300C0C90
	v_and_b32_e32 v13, 0xffff0000, v7                          // 000000058B34: 361A0EFF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v4                          // 000000058B3C: 361408FF FFFF0000
	v_lshlrev_b32_e32 v4, 16, v4                               // 000000058B44: 30080890
	v_and_b32_e32 v11, 0xffff0000, v5                          // 000000058B48: 36160AFF FFFF0000
	v_lshlrev_b32_e32 v5, 16, v5                               // 000000058B50: 300A0A90
	s_waitcnt lgkmcnt(0)                                       // 000000058B54: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000058B58: BF8701A3
	v_dual_mul_f32 v14, v8, v4 :: v_dual_lshlrev_b32 v7, 16, v7// 000000058B5C: C8E20908 0E060E90
	v_mul_f32_e32 v4, v8, v10                                  // 000000058B64: 10081508
	v_mul_f32_e32 v10, v8, v5                                  // 000000058B68: 10140B08
	v_mul_f32_e32 v5, v8, v11                                  // 000000058B6C: 100A1708
	v_mul_f32_e32 v11, v8, v6                                  // 000000058B70: 10160D08
	v_mul_f32_e32 v6, v8, v12                                  // 000000058B74: 100C1908
	v_mul_f32_e32 v12, v8, v7                                  // 000000058B78: 10180F08
	v_mul_f32_e32 v7, v8, v13                                  // 000000058B7C: 100E1B08
	v_cmp_lt_i32_e32 vcc_lo, 31, v2                            // 000000058B80: 7C82049F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 000000058B84: CC220004 02006104
	v_fma_mixlo_f16 v4, v14, s48, 0                            // 000000058B8C: CC210004 0200610E
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 000000058B94: CC220005 02006105
	v_fma_mixlo_f16 v5, v10, s48, 0                            // 000000058B9C: CC210005 0200610A
	v_fma_mixhi_f16 v6, v6, s48, 0                             // 000000058BA4: CC220006 02006106
	v_fma_mixlo_f16 v6, v11, s48, 0                            // 000000058BAC: CC210006 0200610B
	v_fma_mixhi_f16 v7, v7, s48, 0                             // 000000058BB4: CC220007 02006107
	v_fma_mixlo_f16 v7, v12, s48, 0                            // 000000058BBC: CC210007 0200610C
	s_or_b32 s4, vcc_lo, s4                                    // 000000058BC4: 8C04046A
	ds_store_b128 v9, v[4:7] offset:10496                      // 000000058BC8: DB7C2900 00000409
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000058BD0: 917E047E
	s_cbranch_execnz 65472                                     // 000000058BD4: BFA6FFC0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x22d8>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000058BD8: 8C7E037E
	s_mov_b32 s3, 0                                            // 000000058BDC: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000058BE0: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 000000058BE4: 916A037E
	s_cbranch_vccnz 533                                        // 000000058BE8: BFA40215 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c40>
	s_mov_b32 s3, exec_lo                                      // 000000058BEC: BE83007E
	v_cmpx_gt_u32_e32 16, v43                                  // 000000058BF0: 7D985690
	s_cbranch_execz 529                                        // 000000058BF4: BFA50211 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c3c>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 000000058BF8: 7C945680
	s_waitcnt lgkmcnt(0)                                       // 000000058BFC: BF89FC07
	ds_load_b96 v[14:16], v1 offset:23280                      // 000000058C00: DBF85AF0 0E000001
	ds_load_b128 v[59:62], v1 offset:23248                     // 000000058C08: DBFC5AD0 3B000001
	ds_load_b128 v[63:66], v1 offset:23264                     // 000000058C10: DBFC5AE0 3F000001
	ds_load_b128 v[10:13], v1 offset:23168                     // 000000058C18: DBFC5A80 0A000001
	ds_load_b128 v[6:9], v1 offset:23184                       // 000000058C20: DBFC5A90 06000001
	ds_load_b128 v[2:5], v1 offset:23200                       // 000000058C28: DBFC5AA0 02000001
	ds_load_b64 v[17:18], v1 offset:23216                      // 000000058C30: D9D85AB0 11000001
	v_cndmask_b32_e64 v44, 0, 1.0, vcc_lo                      // 000000058C38: D501002C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 000000058C40: 7C945681
	ds_load_b128 v[45:48], v1 offset:23232                     // 000000058C44: DBFC5AC0 2D000001
	v_cndmask_b32_e64 v33, 0, 1.0, vcc_lo                      // 000000058C4C: D5010021 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 000000058C54: 7C945682
	v_cndmask_b32_e64 v32, 0, 1.0, vcc_lo                      // 000000058C58: D5010020 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 000000058C60: 7C945683
	v_cndmask_b32_e64 v31, 0, 1.0, vcc_lo                      // 000000058C64: D501001F 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 000000058C6C: 7C945684
	v_cndmask_b32_e64 v29, 0, 1.0, vcc_lo                      // 000000058C70: D501001D 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 000000058C78: 7C945685
	v_cndmask_b32_e64 v30, 0, 1.0, vcc_lo                      // 000000058C7C: D501001E 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 000000058C84: 7C945686
	v_cndmask_b32_e64 v28, 0, 1.0, vcc_lo                      // 000000058C88: D501001C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 000000058C90: 7C945687
	v_cndmask_b32_e64 v27, 0, 1.0, vcc_lo                      // 000000058C94: D501001B 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 000000058C9C: 7C945688
	v_cndmask_b32_e64 v25, 0, 1.0, vcc_lo                      // 000000058CA0: D5010019 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 000000058CA8: 7C945689
	v_cndmask_b32_e64 v23, 0, 1.0, vcc_lo                      // 000000058CAC: D5010017 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 000000058CB4: 7C94568A
	v_cndmask_b32_e64 v26, 0, 1.0, vcc_lo                      // 000000058CB8: D501001A 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 000000058CC0: 7C94568B
	v_cndmask_b32_e64 v24, 0, 1.0, vcc_lo                      // 000000058CC4: D5010018 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 000000058CCC: 7C94568C
	v_cndmask_b32_e64 v20, 0, 1.0, vcc_lo                      // 000000058CD0: D5010014 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 000000058CD8: 7C94568D
	v_cndmask_b32_e64 v22, 0, 1.0, vcc_lo                      // 000000058CDC: D5010016 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 000000058CE4: 7C94568E
	v_cndmask_b32_e64 v21, 0, 1.0, vcc_lo                      // 000000058CE8: D5010015 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 000000058CF0: 7C94568F
	v_cndmask_b32_e64 v19, 0, 1.0, vcc_lo                      // 000000058CF4: D5010013 01A9E480
	s_waitcnt lgkmcnt(7)                                       // 000000058CFC: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000058D00: BF8700B1
	v_fmac_f32_e32 v22, v19, v15                               // 000000058D04: 562C1F13
	v_fmac_f32_e32 v21, v19, v16                               // 000000058D08: 562A2113
	s_waitcnt lgkmcnt(1)                                       // 000000058D0C: BF89FC17
	v_dual_fmac_f32 v23, v19, v64 :: v_dual_fmac_f32 v22, v21, v18// 000000058D10: C8008113 17162515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000058D18: BF8700D1
	v_dual_fmac_f32 v26, v19, v65 :: v_dual_fmac_f32 v23, v21, v3// 000000058D1C: C8008313 1A160715
	v_fmac_f32_e32 v25, v19, v63                               // 000000058D24: 56327F13
	ds_load_b32 v18, v1 offset:22880                           // 000000058D28: D8D85960 12000001
	v_fmac_f32_e32 v26, v21, v4                                // 000000058D30: 56340915
	v_dual_fmac_f32 v28, v19, v61 :: v_dual_fmac_f32 v25, v21, v2// 000000058D34: C8007B13 1C180515
	v_dual_fmac_f32 v29, v19, v59 :: v_dual_fmac_f32 v28, v21, v8// 000000058D3C: C8007713 1D1C1115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058D44: BF870091
	v_dual_fmac_f32 v30, v19, v60 :: v_dual_fmac_f32 v29, v21, v6// 000000058D48: C8007913 1E1C0D15
	v_dual_fmac_f32 v27, v19, v62 :: v_dual_fmac_f32 v30, v21, v7// 000000058D50: C8007D13 1B1E0F15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058D58: BF870091
	v_dual_fmac_f32 v24, v19, v66 :: v_dual_fmac_f32 v27, v21, v9// 000000058D5C: C8008513 181A1315
	v_fmac_f32_e32 v24, v21, v5                                // 000000058D64: 56300B15
	ds_load_b128 v[2:5], v1 offset:23072                       // 000000058D68: DBFC5A20 02000001
	s_waitcnt lgkmcnt(2)                                       // 000000058D70: BF89FC27
	v_fmac_f32_e32 v31, v19, v48                               // 000000058D74: 563E6113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000058D78: BF870091
	v_dual_fmac_f32 v32, v19, v47 :: v_dual_fmac_f32 v31, v21, v13// 000000058D7C: C8005F13 201E1B15
	v_dual_fmac_f32 v33, v19, v46 :: v_dual_fmac_f32 v32, v21, v12// 000000058D84: C8005D13 21201915
	v_fmac_f32_e32 v44, v19, v45                               // 000000058D8C: 56585B13
	ds_load_b128 v[45:48], v1 offset:24064                     // 000000058D90: DBFC5E00 2D000001
	v_dual_fmac_f32 v33, v21, v11 :: v_dual_fmac_f32 v20, v19, v14// 000000058D98: C8001715 21141D13
	ds_load_b128 v[59:62], v1 offset:23104                     // 000000058DA0: DBFC5A40 3B000001
	ds_load_b128 v[63:66], v1 offset:23136                     // 000000058DA8: DBFC5A60 3F000001
	ds_load_b128 v[67:70], v1 offset:23120                     // 000000058DB0: DBFC5A50 43000001
	ds_load_b32 v14, v1 offset:23152                           // 000000058DB8: D8D85A70 0E000001
	v_fmac_f32_e32 v44, v21, v10                               // 000000058DC0: 56581515
	ds_load_b128 v[6:9], v1 offset:23056                       // 000000058DC4: DBFC5A10 06000001
	ds_load_b128 v[10:13], v1 offset:23040                     // 000000058DCC: DBFC5A00 0A000001
	s_waitcnt lgkmcnt(5)                                       // 000000058DD4: BF89FC57
	v_fmac_f32_e32 v44, v22, v59                               // 000000058DD8: 56587716
	v_dual_fmac_f32 v33, v22, v60 :: v_dual_fmac_f32 v20, v21, v17// 000000058DDC: C8007916 21142315
	s_waitcnt lgkmcnt(3)                                       // 000000058DE4: BF89FC37
	v_fmac_f32_e32 v29, v22, v67                               // 000000058DE8: 563A8716
	v_fmac_f32_e32 v31, v22, v62                               // 000000058DEC: 563E7D16
	s_waitcnt lgkmcnt(2)                                       // 000000058DF0: BF89FC27
	v_fmac_f32_e32 v20, v22, v14                               // 000000058DF4: 56281D16
	ds_load_b128 v[14:17], v1 offset:22976                     // 000000058DF8: DBFC59C0 0E000001
	v_fmac_f32_e32 v24, v22, v66                               // 000000058E00: 56308516
	v_fmac_f32_e32 v32, v22, v61                               // 000000058E04: 56407B16
	ds_load_b64 v[66:67], v1 offset:22944                      // 000000058E08: D9D859A0 42000001
	s_waitcnt lgkmcnt(2)                                       // 000000058E10: BF89FC27
	v_fmac_f32_e32 v33, v20, v11                               // 000000058E14: 56421714
	v_fmac_f32_e32 v24, v20, v5                                // 000000058E18: 56300B14
	s_waitcnt lgkmcnt(1)                                       // 000000058E1C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000058E20: BF8701B1
	v_dual_fmac_f32 v33, v24, v15 :: v_dual_fmac_f32 v30, v22, v68// 000000058E24: C8001F18 211E8916
	v_fmac_f32_e32 v29, v20, v6                                // 000000058E2C: 563A0D14
	v_dual_fmac_f32 v25, v22, v63 :: v_dual_fmac_f32 v44, v20, v10// 000000058E30: C8007F16 192C1514
	v_dual_fmac_f32 v23, v22, v64 :: v_dual_fmac_f32 v30, v20, v7// 000000058E38: C8008116 171E0F14
	v_fmac_f32_e32 v26, v22, v65                               // 000000058E40: 56348316
	ds_load_b128 v[59:62], v1 offset:22992                     // 000000058E44: DBFC59D0 3B000001
	ds_load_b96 v[63:65], v1 offset:23008                      // 000000058E4C: DBF859E0 3F000001
	v_dual_fmac_f32 v28, v22, v69 :: v_dual_fmac_f32 v25, v20, v2// 000000058E54: C8008B16 1C180514
	v_dual_fmac_f32 v27, v22, v70 :: v_dual_fmac_f32 v32, v20, v12// 000000058E5C: C8008D16 1B201914
	v_fmac_f32_e32 v23, v20, v3                                // 000000058E64: 562E0714
	v_fmac_f32_e32 v26, v20, v4                                // 000000058E68: 56340914
	v_fmac_f32_e32 v31, v20, v13                               // 000000058E6C: 563E1B14
	s_delay_alu instid0(VALU_DEP_4)                            // 000000058E70: BF870004
	v_fmac_f32_e32 v27, v20, v9                                // 000000058E74: 56361314
	ds_load_b128 v[2:5], v1 offset:22848                       // 000000058E78: DBFC5940 02000001
	s_waitcnt lgkmcnt(1)                                       // 000000058E80: BF89FC17
	v_fmac_f32_e32 v26, v24, v65                               // 000000058E84: 56348318
	v_fmac_f32_e32 v28, v20, v8                                // 000000058E88: 56381114
	ds_load_b128 v[6:9], v1 offset:22928                       // 000000058E8C: DBFC5990 06000001
	ds_load_b128 v[10:13], v1 offset:22912                     // 000000058E94: DBFC5980 0A000001
	v_fmac_f32_e32 v29, v24, v59                               // 000000058E9C: 563A7718
	s_waitcnt lgkmcnt(1)                                       // 000000058EA0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000058EA4: BF870001
	v_fmac_f32_e32 v29, v26, v6                                // 000000058EA8: 563A0D1A
	v_fmac_f32_e32 v31, v24, v17                               // 000000058EAC: 563E2318
	v_fmac_f32_e32 v44, v24, v14                               // 000000058EB0: 56581D18
	v_fmac_f32_e32 v23, v24, v64                               // 000000058EB4: 562E8118
	v_fmac_f32_e32 v32, v24, v16                               // 000000058EB8: 56402118
	ds_load_b128 v[14:17], v1 offset:22864                     // 000000058EBC: DBFC5950 0E000001
	v_fmac_f32_e32 v23, v26, v67                               // 000000058EC4: 562E871A
	s_waitcnt lgkmcnt(0)                                       // 000000058EC8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000058ECC: BF870001
	v_fmac_f32_e32 v29, v23, v14                               // 000000058ED0: 563A1D17
	v_fmac_f32_e32 v27, v24, v62                               // 000000058ED4: 56367D18
	v_fmac_f32_e32 v30, v24, v60                               // 000000058ED8: 563C7918
	v_fmac_f32_e32 v25, v24, v63                               // 000000058EDC: 56327F18
	v_dual_fmac_f32 v33, v26, v11 :: v_dual_fmac_f32 v28, v24, v61// 000000058EE0: C800171A 211C7B18
	ds_load_b128 v[59:62], v1 offset:22800                     // 000000058EE8: DBFC5910 3B000001
	v_fmac_f32_e32 v32, v26, v12                               // 000000058EF0: 5640191A
	v_fmac_f32_e32 v31, v26, v13                               // 000000058EF4: 563E1B1A
	v_fmac_f32_e32 v44, v26, v10                               // 000000058EF8: 5658151A
	ds_load_b128 v[10:13], v1 offset:22784                     // 000000058EFC: DBFC5900 0A000001
	ds_load_b96 v[63:65], v1 offset:22736                      // 000000058F04: DBF858D0 3F000001
	v_fmac_f32_e32 v27, v26, v9                                // 000000058F0C: 5636131A
	v_fmac_f32_e32 v30, v26, v7                                // 000000058F10: 563C0F1A
	v_fmac_f32_e32 v25, v26, v66                               // 000000058F14: 5632851A
	v_fmac_f32_e32 v28, v26, v8                                // 000000058F18: 5638111A
	ds_load_b128 v[6:9], v1 offset:22720                       // 000000058F1C: DBFC58C0 06000001
	ds_load_b64 v[66:67], v1 offset:22672                      // 000000058F24: D9D85890 42000001
	v_fmac_f32_e32 v33, v23, v3                                // 000000058F2C: 56420717
	v_fmac_f32_e32 v25, v23, v18                               // 000000058F30: 56322517
	v_fmac_f32_e32 v28, v23, v16                               // 000000058F34: 56382117
	v_fmac_f32_e32 v27, v23, v17                               // 000000058F38: 56362317
	v_fmac_f32_e32 v30, v23, v15                               // 000000058F3C: 563C1F17
	ds_load_b128 v[14:17], v1 offset:22528                     // 000000058F40: DBFC5800 0E000001
	s_waitcnt lgkmcnt(5)                                       // 000000058F48: BF89FC57
	v_fmac_f32_e32 v27, v25, v62                               // 000000058F4C: 56367D19
	v_fmac_f32_e32 v28, v25, v61                               // 000000058F50: 56387B19
	v_fmac_f32_e32 v30, v25, v60                               // 000000058F54: 563C7919
	s_waitcnt lgkmcnt(3)                                       // 000000058F58: BF89FC37
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000058F5C: BF870112
	v_fmac_f32_e32 v28, v27, v65                               // 000000058F60: 5638831B
	v_fmac_f32_e32 v30, v27, v64                               // 000000058F64: 563C811B
	s_waitcnt lgkmcnt(1)                                       // 000000058F68: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000058F6C: BF870001
	v_fmac_f32_e32 v30, v28, v67                               // 000000058F70: 563C871C
	v_dual_fmac_f32 v44, v23, v2 :: v_dual_fmac_f32 v33, v25, v11// 000000058F74: C8000517 2C201719
	v_fmac_f32_e32 v31, v23, v5                                // 000000058F7C: 563E0B17
	v_fmac_f32_e32 v32, v23, v4                                // 000000058F80: 56400917
	ds_load_b128 v[2:5], v1 offset:22656                       // 000000058F84: DBFC5880 02000001
	v_fmac_f32_e32 v44, v25, v10                               // 000000058F8C: 56581519
	v_fmac_f32_e32 v29, v25, v59                               // 000000058F90: 563A7719
	v_fmac_f32_e32 v31, v25, v13                               // 000000058F94: 563E1B19
	v_fmac_f32_e32 v32, v25, v12                               // 000000058F98: 56401919
	ds_load_b128 v[10:13], v1 offset:22592                     // 000000058F9C: DBFC5840 0A000001
	ds_load_b32 v18, v1 offset:22608                           // 000000058FA4: D8D85850 12000001
	v_fmac_f32_e32 v33, v27, v7                                // 000000058FAC: 56420F1B
	v_fmac_f32_e32 v29, v27, v63                               // 000000058FB0: 563A7F1B
	ds_load_b64 v[59:60], v1 offset:22400                      // 000000058FB4: D9D85780 3B000001
	v_dual_fmac_f32 v32, v27, v8 :: v_dual_fmac_f32 v29, v28, v66// 000000058FBC: C800111B 201C851C
	ds_load_b128 v[63:66], v1 offset:24304                     // 000000058FC4: DBFC5EF0 3F000001
	s_waitcnt lgkmcnt(2)                                       // 000000058FCC: BF89FC27
	v_fmac_f32_e32 v29, v30, v18                               // 000000058FD0: 563A251E
	v_dual_fmac_f32 v44, v27, v6 :: v_dual_fmac_f32 v33, v28, v3// 000000058FD4: C8000D1B 2C20071C
	v_fmac_f32_e32 v31, v27, v9                                // 000000058FDC: 563E131B
	ds_load_b96 v[6:8], v1 offset:22464                        // 000000058FE0: DBF857C0 06000001
	ds_load_b32 v9, v1 offset:22336                            // 000000058FE8: D8D85740 09000001
	v_fmac_f32_e32 v44, v28, v2                                // 000000058FF0: 5658051C
	v_fmac_f32_e32 v32, v28, v4                                // 000000058FF4: 5640091C
	v_fmac_f32_e32 v31, v28, v5                                // 000000058FF8: 563E0B1C
	v_fmac_f32_e32 v33, v30, v11                               // 000000058FFC: 5642171E
	ds_load_b128 v[2:5], v1 offset:24256                       // 000000059000: DBFC5EC0 02000001
	v_fmac_f32_e32 v44, v30, v10                               // 000000059008: 5658151E
	v_fmac_f32_e32 v32, v30, v12                               // 00000005900C: 5640191E
	v_fmac_f32_e32 v31, v30, v13                               // 000000059010: 563E1B1E
	v_fmac_f32_e32 v33, v29, v15                               // 000000059014: 56421F1D
	s_waitcnt lgkmcnt(3)                                       // 000000059018: BF89FC37
	v_mul_f32_e32 v72, v65, v21                                // 00000005901C: 10902B41
	v_fmac_f32_e32 v44, v29, v14                               // 000000059020: 56581D1D
	v_fmac_f32_e32 v32, v29, v16                               // 000000059024: 5640211D
	v_fmac_f32_e32 v31, v29, v17                               // 000000059028: 563E231D
	s_waitcnt lgkmcnt(2)                                       // 00000005902C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000059030: BF8700A1
	v_fmac_f32_e32 v32, v31, v8                                // 000000059034: 5640111F
	v_fmac_f32_e32 v33, v31, v7                                // 000000059038: 56420F1F
	v_dual_fmac_f32 v44, v31, v6 :: v_dual_fmac_f32 v33, v32, v60// 00000005903C: C8000D1F 2C207920
	s_delay_alu instid0(VALU_DEP_1)                            // 000000059044: BF870001
	v_fmac_f32_e32 v44, v32, v59                               // 000000059048: 56587720
	ds_load_b128 v[59:62], v1 offset:24288                     // 00000005904C: DBFC5EE0 3B000001
	s_waitcnt lgkmcnt(1)                                       // 000000059054: BF89FC17
	v_fma_mixlo_f16 v49, v5, v31, 0                            // 000000059058: CC210031 02023F05
	v_mul_f32_e32 v15, v3, v33                                 // 000000059060: 101E4303
	v_fmac_f32_e32 v44, v33, v9                                // 000000059064: 56581321
	ds_load_b128 v[6:9], v1 offset:24272                       // 000000059068: DBFC5ED0 06000001
	ds_load_b128 v[10:13], v1 offset:24112                     // 000000059070: DBFC5E30 0A000001
	v_fma_mixlo_f16 v18, v3, v33, 0                            // 000000059078: CC210012 02024303
	v_mul_f32_e32 v14, v2, v44                                 // 000000059080: 101C5902
	v_fma_mixlo_f16 v2, v2, v44, 0                             // 000000059084: CC210002 02025902
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005908C: BF870113
	v_fma_mix_f32 v15, v18, -1.0, v15 op_sel_hi:[1,1,0]        // 000000059090: CC20000F 1C3DE712
	v_fma_mix_f32 v3, v2, -1.0, v14 op_sel_hi:[1,1,0]          // 000000059098: CC200003 1C39E702
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000000590A0: BF870232
	.long 0x7f1c150f                                           // 0000000590A4: 7F1C150F
	v_mul_f32_e32 v15, v4, v32                                 // 0000000590A8: 101E4104
	.long 0x7f043912                                           // 0000000590AC: 7F043912
	v_cvt_f16_f32_e32 v14, v3                                  // 0000000590B0: 7E1C1503
	v_fma_mixlo_f16 v3, v4, v32, 0                             // 0000000590B4: CC210003 02024104
	v_mul_f32_e32 v4, v5, v31                                  // 0000000590BC: 10083F05
	s_waitcnt lgkmcnt(2)                                       // 0000000590C0: BF89FC27
	v_fma_mixlo_f16 v69, v60, v23, 0                           // 0000000590C4: CC210045 02022F3C
	s_waitcnt lgkmcnt(1)                                       // 0000000590CC: BF89FC17
	v_mul_f32_e32 v16, v7, v30                                 // 0000000590D0: 10203D07
	v_fma_mixlo_f16 v67, v7, v30, 0                            // 0000000590D4: CC210043 02023D07
	v_fma_mix_f32 v7, v3, -1.0, v15 op_sel_hi:[1,1,0]          // 0000000590DC: CC200007 1C3DE703
	v_mul_f32_e32 v5, v6, v29                                  // 0000000590E4: 100A3B06
	v_fma_mixlo_f16 v68, v9, v27, 0                            // 0000000590E8: CC210044 02023709
	.long 0x7f063931                                           // 0000000590F0: 7F063931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000000590F4: BF8701D4
	v_cvt_f16_f32_e32 v15, v7                                  // 0000000590F8: 7E1E1507
	v_mul_f32_e32 v7, v8, v28                                  // 0000000590FC: 100E3908
	v_fma_mix_f32 v17, v49, -1.0, v4 op_sel_hi:[1,1,0]         // 000000059100: CC200011 1C11E731
	v_fma_mixlo_f16 v4, v6, v29, 0                             // 000000059108: CC210004 02023B06
	v_fma_mix_f32 v6, v67, -1.0, v16 op_sel_hi:[1,1,0]         // 000000059110: CC200006 1C41E743
	.long 0x7f1e1511                                           // 000000059118: 7F1E1511
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000005911C: BF870193
	v_fma_mix_f32 v5, v4, -1.0, v5 op_sel_hi:[1,1,0]           // 000000059120: CC200005 1C15E704
	.long 0x7f201506                                           // 000000059128: 7F201506
	v_fma_mixlo_f16 v6, v59, v25, 0                            // 00000005912C: CC210006 0202333B
	.long 0x7f083943                                           // 000000059134: 7F083943
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000059138: BF8701C4
	v_cvt_f16_f32_e32 v16, v5                                  // 00000005913C: 7E201505
	v_fma_mixlo_f16 v5, v8, v28, 0                             // 000000059140: CC210005 02023908
	v_dual_mul_f32 v8, v9, v27 :: v_dual_mul_f32 v9, v59, v25  // 000000059148: C8C63709 0808333B
	v_dual_mul_f32 v59, v60, v23 :: v_dual_mul_f32 v60, v61, v26// 000000059150: C8C62F3C 3B3C353D
	v_fma_mix_f32 v7, v5, -1.0, v7 op_sel_hi:[1,1,0]           // 000000059158: CC200007 1C1DE705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000059160: BF870213
	v_fma_mix_f32 v8, v68, -1.0, v8 op_sel_hi:[1,1,0]          // 000000059164: CC200008 1C21E744
	v_fma_mix_f32 v9, v6, -1.0, v9 op_sel_hi:[1,1,0]           // 00000005916C: CC200009 1C25E706
	s_delay_alu instid0(VALU_DEP_4)                            // 000000059174: BF870004
	v_fma_mix_f32 v70, v69, -1.0, v59 op_sel_hi:[1,1,0]        // 000000059178: CC200046 1CEDE745
	.long 0x7f0c3945                                           // 000000059180: 7F0C3945
	v_cvt_f16_f32_e32 v17, v7                                  // 000000059184: 7E221507
	v_fma_mixlo_f16 v7, v61, v26, 0                            // 000000059188: CC210007 0202353D
	.long 0x7f221508                                           // 000000059190: 7F221508
	v_cvt_f16_f32_e32 v59, v9                                  // 000000059194: 7E761509
	.long 0x7f761546                                           // 000000059198: 7F761546
	v_mul_f32_e32 v9, v62, v24                                 // 00000005919C: 1012313E
	v_fma_mix_f32 v8, v7, -1.0, v60 op_sel_hi:[1,1,0]          // 0000000591A0: CC200008 1CF1E707
	v_fma_mixlo_f16 v70, v62, v24, 0                           // 0000000591A8: CC210046 0202313E
	v_dual_mul_f32 v61, v63, v20 :: v_dual_mul_f32 v62, v64, v22// 0000000591B0: C8C6293F 3D3E2D40
	v_fma_mixlo_f16 v64, v64, v22, 0                           // 0000000591B8: CC210040 02022D40
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000591C0: BF870214
	v_cvt_f16_f32_e32 v60, v8                                  // 0000000591C4: 7E781508
	v_fma_mix_f32 v71, v70, -1.0, v9 op_sel_hi:[1,1,0]         // 0000000591C8: CC200047 1C25E746
	v_fma_mixlo_f16 v8, v63, v20, 0                            // 0000000591D0: CC210008 0202293F
	v_fma_mixlo_f16 v9, v65, v21, 0                            // 0000000591D8: CC210009 02022B41
	v_fma_mix_f32 v62, v64, -1.0, v62 op_sel_hi:[1,1,0]        // 0000000591E0: CC20003E 1CF9E740
	v_mul_f32_e32 v65, v66, v19                                // 0000000591E8: 10822742
	v_fma_mixlo_f16 v66, v66, v19, 0                           // 0000000591EC: CC210042 02022742
	v_fma_mix_f32 v61, v8, -1.0, v61 op_sel_hi:[1,1,0]         // 0000000591F4: CC20003D 1CF5E708
	v_fma_mix_f32 v63, v9, -1.0, v72 op_sel_hi:[1,1,0]         // 0000000591FC: CC20003F 1D21E709
	.long 0x7f781547                                           // 000000059204: 7F781547
	.long 0x7f103940                                           // 000000059208: 7F103940
	v_fma_mix_f32 v71, v66, -1.0, v65 op_sel_hi:[1,1,0]        // 00000005920C: CC200047 1D05E742
	v_cvt_f16_f32_e32 v61, v61                                 // 000000059214: 7E7A153D
	.long 0x7f7a153e                                           // 000000059218: 7F7A153E
	v_cvt_f16_f32_e32 v62, v63                                 // 00000005921C: 7E7C153F
	.long 0x7f123942                                           // 000000059220: 7F123942
	ds_load_b128 v[63:66], v1 offset:24080                     // 000000059224: DBFC5E10 3F000001
	v_mul_u32_u24_e32 v72, 48, v43                             // 00000005922C: 169056B0
	.long 0x7f0e3946                                           // 000000059230: 7F0E3946
	.long 0x7f0a3944                                           // 000000059234: 7F0A3944
	v_mul_f32_e32 v18, v45, v44                                // 000000059238: 1024592D
	v_fma_mixlo_f16 v43, v45, v44, 0                           // 00000005923C: CC21002B 0202592D
	v_mul_f32_e32 v44, v46, v33                                // 000000059244: 1058432E
	v_fma_mixlo_f16 v33, v46, v33, 0                           // 000000059248: CC210021 0202432E
	ds_store_b128 v72, v[6:9] offset:19216                     // 000000059250: DB7C4B10 00000648
	ds_store_b128 v72, v[2:5] offset:19200                     // 000000059258: DB7C4B00 00000248
	ds_load_b128 v[2:5], v1 offset:24096                       // 000000059260: DBFC5E20 02000001
	v_dual_mul_f32 v7, v47, v32 :: v_dual_mul_f32 v8, v48, v31 // 000000059268: C8C6412F 07083F30
	v_fma_mix_f32 v44, v33, -1.0, v44 op_sel_hi:[1,1,0]        // 000000059270: CC20002C 1CB1E721
	.long 0x7f7c1547                                           // 000000059278: 7F7C1547
	s_delay_alu instid0(VALU_DEP_2)                            // 00000005927C: BF870002
	.long 0x7f0c152c                                           // 000000059280: 7F0C152C
	v_fma_mixlo_f16 v44, v47, v32, 0                           // 000000059284: CC21002C 0202412F
	s_waitcnt lgkmcnt(3)                                       // 00000005928C: BF89FC37
	v_mul_f32_e32 v9, v63, v29                                 // 000000059290: 10123B3F
	v_fma_mix_f32 v18, v43, -1.0, v18 op_sel_hi:[1,1,0]        // 000000059294: CC200012 1C49E72B
	v_fma_mixlo_f16 v45, v63, v29, 0                           // 00000005929C: CC21002D 02023B3F
	v_fma_mix_f32 v7, v44, -1.0, v7 op_sel_hi:[1,1,0]          // 0000000592A4: CC200007 1C1DE72C
	v_fma_mixlo_f16 v46, v65, v28, 0                           // 0000000592AC: CC21002E 02023941
	.long 0x7f563921                                           // 0000000592B4: 7F563921
	v_cvt_f16_f32_e32 v6, v18                                  // 0000000592B8: 7E0C1512
	v_fma_mixlo_f16 v18, v48, v31, 0                           // 0000000592BC: CC210012 02023F30
	v_mul_f32_e32 v31, v64, v30                                // 0000000592C4: 103E3D40
	v_fma_mixlo_f16 v30, v64, v30, 0                           // 0000000592C8: CC21001E 02023D40
	v_fma_mix_f32 v9, v45, -1.0, v9 op_sel_hi:[1,1,0]          // 0000000592D0: CC200009 1C25E72D
	v_cvt_f16_f32_e32 v7, v7                                   // 0000000592D8: 7E0E1507
	.long 0x7f583912                                           // 0000000592DC: 7F583912
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000592E0: BF870004
	v_fma_mix_f32 v29, v30, -1.0, v31 op_sel_hi:[1,1,0]        // 0000000592E4: CC20001D 1C7DE71E
	v_mul_f32_e32 v31, v65, v28                                // 0000000592EC: 103E3941
	v_fma_mix_f32 v8, v18, -1.0, v8 op_sel_hi:[1,1,0]          // 0000000592F0: CC200008 1C21E712
	v_mul_f32_e32 v28, v66, v27                                // 0000000592F8: 10383742
	v_fma_mixlo_f16 v27, v66, v27, 0                           // 0000000592FC: CC21001B 02023742
	.long 0x7f5a391e                                           // 000000059304: 7F5A391E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000059308: BF870004
	.long 0x7f0e1508                                           // 00000005930C: 7F0E1508
	v_cvt_f16_f32_e32 v8, v9                                   // 000000059310: 7E101509
	.long 0x7f10151d                                           // 000000059314: 7F10151D
	v_fma_mix_f32 v9, v46, -1.0, v31 op_sel_hi:[1,1,0]         // 000000059318: CC200009 1C7DE72E
	s_waitcnt lgkmcnt(0)                                       // 000000059320: BF89FC07
	v_mul_f32_e32 v29, v2, v25                                 // 000000059324: 103A3302
	v_fma_mixlo_f16 v2, v2, v25, 0                             // 000000059328: CC210002 02023302
	v_mul_f32_e32 v25, v3, v23                                 // 000000059330: 10322F03
	v_fma_mixlo_f16 v31, v3, v23, 0                            // 000000059334: CC21001F 02022F03
	v_fma_mix_f32 v3, v27, -1.0, v28 op_sel_hi:[1,1,0]         // 00000005933C: CC200003 1C71E71B
	v_cvt_f16_f32_e32 v9, v9                                   // 000000059344: 7E121509
	v_mul_f32_e32 v23, v4, v26                                 // 000000059348: 102E3504
	.long 0x7f5c391b                                           // 00000005934C: 7F5C391B
	v_fma_mix_f32 v25, v31, -1.0, v25 op_sel_hi:[1,1,0]        // 000000059350: CC200019 1C65E71F
	.long 0x7f121503                                           // 000000059358: 7F121503
	v_fma_mixlo_f16 v3, v4, v26, 0                             // 00000005935C: CC210003 02023504
	v_mul_f32_e32 v26, v11, v22                                // 000000059364: 10342D0B
	v_fma_mix_f32 v28, v2, -1.0, v29 op_sel_hi:[1,1,0]         // 000000059368: CC20001C 1C75E702
	v_fma_mixlo_f16 v11, v11, v22, 0                           // 000000059370: CC21000B 02022D0B
	.long 0x7f04391f                                           // 000000059378: 7F04391F
	v_fma_mix_f32 v4, v3, -1.0, v23 op_sel_hi:[1,1,0]          // 00000005937C: CC200004 1C5DE703
	.long 0x7f2e1519                                           // 000000059384: 7F2E1519
	v_cvt_f16_f32_e32 v23, v28                                 // 000000059388: 7E2E151C
	v_mul_f32_e32 v25, v5, v24                                 // 00000005938C: 10323105
	v_fma_mixlo_f16 v28, v5, v24, 0                            // 000000059390: CC21001C 02023105
	v_cvt_f16_f32_e32 v24, v4                                  // 000000059398: 7E301504
	v_mul_f32_e32 v5, v10, v20                                 // 00000005939C: 100A290A
	v_fma_mixlo_f16 v4, v10, v20, 0                            // 0000000593A0: CC210004 0202290A
	v_fma_mix_f32 v20, v11, -1.0, v26 op_sel_hi:[1,1,0]        // 0000000593A8: CC200014 1C69E70B
	v_fma_mix_f32 v22, v28, -1.0, v25 op_sel_hi:[1,1,0]        // 0000000593B0: CC200016 1C65E71C
	v_mul_f32_e32 v25, v12, v21                                // 0000000593B8: 10322B0C
	.long 0x7f06391c                                           // 0000000593BC: 7F06391C
	v_fma_mix_f32 v10, v4, -1.0, v5 op_sel_hi:[1,1,0]          // 0000000593C0: CC20000A 1C15E704
	v_fma_mixlo_f16 v5, v12, v21, 0                            // 0000000593C8: CC210005 02022B0C
	v_mul_f32_e32 v21, v13, v19                                // 0000000593D0: 102A270D
	v_fma_mixlo_f16 v13, v13, v19, 0                           // 0000000593D4: CC21000D 0202270D
	.long 0x7f08390b                                           // 0000000593DC: 7F08390B
	.long 0x7f301516                                           // 0000000593E0: 7F301516
	v_fma_mix_f32 v12, v5, -1.0, v25 op_sel_hi:[1,1,0]         // 0000000593E4: CC20000C 1C65E705
	v_cvt_f16_f32_e32 v25, v10                                 // 0000000593EC: 7E32150A
	v_fma_mix_f32 v10, v13, -1.0, v21 op_sel_hi:[1,1,0]        // 0000000593F0: CC20000A 1C55E70D
	.long 0x7f0a390d                                           // 0000000593F8: 7F0A390D
	.long 0x7f321514                                           // 0000000593FC: 7F321514
	v_cvt_f16_f32_e32 v26, v12                                 // 000000059400: 7E34150C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000059404: BF870004
	.long 0x7f34150a                                           // 000000059408: 7F34150A
	ds_store_b128 v72, v[59:62] offset:19984                   // 00000005940C: DB7C4E10 00003B48
	ds_store_b128 v72, v[14:17] offset:19968                   // 000000059414: DB7C4E00 00000E48
	ds_store_b128 v72, v[2:5] offset:20752                     // 00000005941C: DB7C5110 00000248
	ds_store_b128 v72, v[43:46] offset:20736                   // 000000059424: DB7C5100 00002B48
	ds_store_b128 v72, v[23:26] offset:21520                   // 00000005942C: DB7C5410 00001748
	ds_store_b128 v72, v[6:9] offset:21504                     // 000000059434: DB7C5400 00000648
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005943C: 8C7E037E
	s_waitcnt lgkmcnt(0)                                       // 000000059440: BF89FC07
	s_barrier                                                  // 000000059444: BFBD0000
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 000000059448: 916A267E
	s_cbranch_vccnz 1                                          // 00000005944C: BFA40001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c54>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 000000059450: BE9C4D83
	v_cmp_eq_u32_e32 vcc_lo, 0, v34                            // 000000059454: 7C944480
	v_dual_mov_b32 v162, s27 :: v_dual_lshlrev_b32 v59, 1, v153// 000000059458: CA22001B A23B3281
	s_waitcnt lgkmcnt(0)                                       // 000000059460: BF89FC07
	v_mov_b32_e32 v11, 0                                       // 000000059464: 7E160280
	s_cmp_lt_i32 s54, s39                                      // 000000059468: BF042736
	v_dual_cndmask_b32 v2, 0x7060302, v149 :: v_dual_mov_b32 v3, 0// 00000005946C: CA512AFF 02020080 07060302
	ds_load_u16 v12, v59 offset:6416                           // 000000059478: D8F01910 0C00003B
	ds_load_u16 v13, v59 offset:6960                           // 000000059480: D8F01B30 0D00003B
	ds_load_u16 v14, v59 offset:7504                           // 000000059488: D8F01D50 0E00003B
	ds_load_u16 v15, v59 offset:8048                           // 000000059490: D8F01F70 0F00003B
	ds_load_u16 v16, v59 offset:7776                           // 000000059498: D8F01E60 1000003B
	ds_load_u16 v18, v59 offset:7232                           // 0000000594A0: D8F01C40 1200003B
	ds_load_u16 v19, v59 offset:6688                           // 0000000594A8: D8F01A20 1300003B
	ds_load_u16 v20, v59 offset:6144                           // 0000000594B0: D8F01800 1400003B
	s_waitcnt vmcnt(2)                                         // 0000000594B8: BF890BF7
	v_mov_b32_dpp v11, v37 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 0000000594BC: 7E1602FA FF00B125
	s_cselect_b32 s57, -1, 0                                   // 0000000594C4: 983980C1
	s_or_b32 s3, s54, 1                                        // 0000000594C8: 8C038136
	v_mov_b32_dpp v3, v42 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 0000000594CC: 7E0602FA FF00B12A
	s_cmp_lt_i32 s3, s39                                       // 0000000594D4: BF042703
	v_perm_b32 v22, v37, v11, v2                               // 0000000594D8: D6440016 040A1725
	v_mov_b32_e32 v11, 0                                       // 0000000594E0: 7E160280
	s_cselect_b32 s58, -1, 0                                   // 0000000594E4: 983A80C1
	v_perm_b32 v3, v42, v3, v2                                 // 0000000594E8: D6440003 040A072A
	v_mov_b32_e32 v4, 0                                        // 0000000594F0: 7E080280
	s_or_b32 s3, s54, 2                                        // 0000000594F4: 8C038236
	v_and_b32_e32 v24, 0xffff0000, v22                         // 0000000594F8: 36302CFF FFFF0000
	s_cmp_lt_i32 s3, s39                                       // 000000059500: BF042703
	v_and_b32_e32 v5, 0xffff0000, v3                           // 000000059504: 360A06FF FFFF0000
	v_mov_b32_dpp v4, v41 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000005950C: 7E0802FA FF00B129
	s_waitcnt lgkmcnt(5)                                       // 000000059514: BF89FC57
	v_dual_mov_b32 v157, s22 :: v_dual_lshlrev_b32 v14, 16, v14// 000000059518: CA220016 9D0E1C90
	s_cselect_b32 s59, -1, 0                                   // 000000059520: 983B80C1
	s_or_b32 s3, s54, 3                                        // 000000059524: 8C038336
	v_perm_b32 v4, v41, v4, v2                                 // 000000059528: D6440004 040A0929
	s_cmp_lt_i32 s3, s39                                       // 000000059530: BF042703
	s_waitcnt lgkmcnt(4)                                       // 000000059534: BF89FC47
	v_lshlrev_b32_e32 v15, 16, v15                             // 000000059538: 301E1E90
	v_mov_b32_e32 v7, 0                                        // 00000005953C: 7E0E0280
	s_cselect_b32 s60, -1, 0                                   // 000000059540: 983C80C1
	v_and_b32_e32 v6, 0xffff0000, v4                           // 000000059544: 360C08FF FFFF0000
	s_or_b32 s3, s54, 4                                        // 00000005954C: 8C038436
	v_mov_b32_e32 v10, 0                                       // 000000059550: 7E140280
	v_mov_b32_dpp v7, v40 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000059554: 7E0E02FA FF00B128
	s_cmp_lt_i32 s3, s39                                       // 00000005955C: BF042703
	v_dual_mov_b32 v159, s24 :: v_dual_mov_b32 v156, s21       // 000000059560: CA100018 9F9C0015
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000059568: BF870193
	v_mov_b32_dpp v10, v38 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000005956C: 7E1402FA FF00B126
	v_perm_b32 v7, v40, v7, v2                                 // 000000059574: D6440007 040A0F28
	v_mov_b32_e32 v8, 0                                        // 00000005957C: 7E100280
	s_cselect_b32 s61, -1, 0                                   // 000000059580: 983D80C1
	s_or_b32 s3, s54, 5                                        // 000000059584: 8C038536
	v_perm_b32 v21, v38, v10, v2                               // 000000059588: D6440015 040A1526
	v_and_b32_e32 v9, 0xffff0000, v7                           // 000000059590: 36120EFF FFFF0000
	v_mov_b32_dpp v8, v39 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000059598: 7E1002FA FF00B127
	v_mov_b32_e32 v10, 0                                       // 0000000595A0: 7E140280
	s_cmp_lt_i32 s3, s39                                       // 0000000595A4: BF042703
	v_and_b32_e32 v23, 0xffff0000, v21                         // 0000000595A8: 362E2AFF FFFF0000
	s_cselect_b32 s62, -1, 0                                   // 0000000595B0: 983E80C1
	v_perm_b32 v8, v39, v8, v2                                 // 0000000595B4: D6440008 040A1127
	s_waitcnt vmcnt(1)                                         // 0000000595BC: BF8907F7
	v_mov_b32_dpp v10, v35 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 0000000595C0: 7E1402FA FF00B123
	s_or_b32 s3, s54, 6                                        // 0000000595C8: 8C038636
	v_mov_b32_e32 v158, s23                                    // 0000000595CC: 7F3C0217
	s_cmp_lt_i32 s3, s39                                       // 0000000595D0: BF042703
	v_and_b32_e32 v17, 0xffff0000, v8                          // 0000000595D4: 362210FF FFFF0000
	v_perm_b32 v25, v35, v10, v2                               // 0000000595DC: D6440019 040A1523
	v_lshlrev_b32_e32 v10, 16, v12                             // 0000000595E4: 30141890
	s_waitcnt vmcnt(0)                                         // 0000000595E8: BF8903F7
	v_mov_b32_dpp v11, v36 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 0000000595EC: 7E1602FA FF00B124
	v_lshlrev_b32_e32 v12, 16, v13                             // 0000000595F4: 30181A90
	s_waitcnt lgkmcnt(1)                                       // 0000000595F8: BF89FC17
	v_lshlrev_b32_e32 v13, 16, v19                             // 0000000595FC: 301A2690
	s_cselect_b32 s63, -1, 0                                   // 000000059600: 983F80C1
	.long 0x7f14150a                                           // 000000059604: 7F14150A
	v_perm_b32 v42, v36, v11, v2                               // 000000059608: D644002A 040A1724
	ds_load_u16 v2, v59 offset:8592                            // 000000059610: D8F02190 0200003B
	ds_load_u16 v26, v59 offset:9136                           // 000000059618: D8F023B0 1A00003B
	ds_load_u16 v27, v59 offset:9680                           // 000000059620: D8F025D0 1B00003B
	ds_load_u16 v28, v59 offset:10224                          // 000000059628: D8F027F0 1C00003B
	ds_load_u16 v29, v59 offset:9952                           // 000000059630: D8F026E0 1D00003B
	ds_load_u16 v30, v59 offset:9408                           // 000000059638: D8F024C0 1E00003B
	ds_load_u16 v31, v59 offset:8864                           // 000000059640: D8F022A0 1F00003B
	ds_load_u16 v32, v59 offset:8320                           // 000000059648: D8F02080 2000003B
	s_waitcnt lgkmcnt(8)                                       // 000000059650: BF89FC87
	v_lshlrev_b32_e32 v11, 16, v20                             // 000000059654: 30162890
	s_or_b32 s3, s54, 7                                        // 000000059658: 8C038736
	v_dual_mov_b32 v160, s25 :: v_dual_and_b32 v33, 0xffff0000, v25// 00000005965C: CA240019 A02032FF FFFF0000
	s_cmp_lt_i32 s3, s39                                       // 000000059668: BF042703
	s_delay_alu instid0(VALU_DEP_2)                            // 00000005966C: BF870002
	v_cvt_f16_f32_e32 v10, v11                                 // 000000059670: 7E14150B
	.long 0x7f16150c                                           // 000000059674: 7F16150C
	v_cvt_f16_f32_e32 v11, v13                                 // 000000059678: 7E16150D
	v_lshlrev_b32_e32 v13, 16, v18                             // 00000005967C: 301A2490
	.long 0x7f18150e                                           // 000000059680: 7F18150E
	v_dual_mov_b32 v155, s20 :: v_dual_lshlrev_b32 v14, 16, v16// 000000059684: CA220014 9B0E2090
	s_cselect_b32 s64, -1, 0                                   // 00000005968C: 984080C1
	s_or_b32 s3, s54, 8                                        // 000000059690: 8C038836
	v_dual_mov_b32 v161, s26 :: v_dual_and_b32 v68, 0xffff0000, v42// 000000059694: CA24001A A14454FF FFFF0000
	s_cmp_lt_i32 s3, s39                                       // 0000000596A0: BF042703
	v_cvt_f16_f32_e32 v12, v13                                 // 0000000596A4: 7E18150D
	.long 0x7f1a150f                                           // 0000000596A8: 7F1A150F
	v_cvt_f16_f32_e32 v13, v14                                 // 0000000596AC: 7E1A150E
	s_cselect_b32 s65, -1, 0                                   // 0000000596B0: 984180C1
	s_or_b32 s3, s54, 9                                        // 0000000596B4: 8C038936
	s_waitcnt lgkmcnt(7)                                       // 0000000596B8: BF89FC77
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000000596BC: 30040490
	s_cmp_lt_i32 s3, s39                                       // 0000000596C0: BF042703
	s_waitcnt lgkmcnt(5)                                       // 0000000596C4: BF89FC57
	v_lshlrev_b32_e32 v18, 16, v27                             // 0000000596C8: 30243690
	s_cselect_b32 s66, -1, 0                                   // 0000000596CC: 984280C1
	s_or_b32 s3, s54, 10                                       // 0000000596D0: 8C038A36
	s_waitcnt lgkmcnt(3)                                       // 0000000596D4: BF89FC37
	v_lshlrev_b32_e32 v69, 16, v29                             // 0000000596D8: 308A3A90
	s_cmp_lt_i32 s3, s39                                       // 0000000596DC: BF042703
	.long 0x7f1c1502                                           // 0000000596E0: 7F1C1502
	v_lshlrev_b32_e32 v2, 16, v26                              // 0000000596E4: 30043490
	s_waitcnt lgkmcnt(2)                                       // 0000000596E8: BF89FC27
	v_lshlrev_b32_e32 v19, 16, v30                             // 0000000596EC: 30263C90
	s_cselect_b32 s55, -1, 0                                   // 0000000596F0: 983780C1
	s_or_b32 s3, s54, 11                                       // 0000000596F4: 8C038B36
	s_waitcnt lgkmcnt(1)                                       // 0000000596F8: BF89FC17
	v_lshlrev_b32_e32 v16, 16, v31                             // 0000000596FC: 30203E90
	s_cmp_lt_i32 s3, s39                                       // 000000059700: BF042703
	s_waitcnt lgkmcnt(0)                                       // 000000059704: BF89FC07
	v_lshlrev_b32_e32 v15, 16, v32                             // 000000059708: 301E4090
	s_cselect_b32 s3, -1, 0                                    // 00000005970C: 980380C1
	s_or_b32 s4, s54, 12                                       // 000000059710: 8C048C36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059714: BF870099
	s_cmp_lt_i32 s4, s39                                       // 000000059718: BF042704
	v_cvt_f16_f32_e32 v14, v15                                 // 00000005971C: 7E1C150F
	.long 0x7f1e1502                                           // 000000059720: 7F1E1502
	v_lshlrev_b32_e32 v2, 16, v3                               // 000000059724: 30040690
	v_lshlrev_b32_e32 v3, 16, v4                               // 000000059728: 30060890
	v_lshlrev_b32_e32 v4, 16, v7                               // 00000005972C: 30080E90
	v_cvt_f16_f32_e32 v15, v16                                 // 000000059730: 7E1E1510
	.long 0x7f201512                                           // 000000059734: 7F201512
	v_cvt_f16_f32_e32 v16, v19                                 // 000000059738: 7E201513
	v_cvt_f16_f32_e32 v2, v2                                   // 00000005973C: 7E041502
	.long 0x7f041505                                           // 000000059740: 7F041505
	v_cvt_f16_f32_e32 v3, v3                                   // 000000059744: 7E061503
	v_lshlrev_b32_e32 v5, 16, v28                              // 000000059748: 300A3890
	s_cselect_b32 s4, -1, 0                                    // 00000005974C: 980480C1
	v_cndmask_b16 v18, 0, v2, s57                              // 000000059750: D65D0012 00E60480
	v_cndmask_b16 v18, 0, v2, s58                              // 000000059758: D65D5012 00EA0480
	v_cvt_f16_f32_e32 v2, v6                                   // 000000059760: 7E041506
	.long 0x7f041504                                           // 000000059764: 7F041504
	v_cndmask_b16 v19, 0, v3, s59                              // 000000059768: D65D0013 00EE0680
	v_lshlrev_b32_e32 v4, 16, v8                               // 000000059770: 30081090
	v_cvt_f16_f32_e32 v3, v9                                   // 000000059774: 7E061509
	v_lshlrev_b32_e32 v6, 16, v21                              // 000000059778: 300C2A90
	v_cndmask_b16 v19, 0, v2, s60                              // 00000005977C: D65D4013 00F20480
	v_cndmask_b16 v20, 0, v2, s61                              // 000000059784: D65D1014 00F60480
	v_cvt_f16_f32_e32 v2, v4                                   // 00000005978C: 7E041504
	v_cndmask_b16 v20, 0, v3, s62                              // 000000059790: D65D4014 00FA0680
	.long 0x7f041511                                           // 000000059798: 7F041511
	v_lshlrev_b32_e32 v4, 16, v22                              // 00000005979C: 30082C90
	v_cvt_f16_f32_e32 v3, v6                                   // 0000000597A0: 7E061506
	v_cndmask_b16 v21, 0, v2, s63                              // 0000000597A4: D65D0015 00FE0480
	v_cvt_f16_f32_e32 v2, v23                                  // 0000000597AC: 7E041517
	v_cndmask_b16 v21, 0, v2, s64                              // 0000000597B0: D65D5015 01020480
	.long 0x7f041504                                           // 0000000597B8: 7F041504
	v_cndmask_b16 v22, 0, v3, s65                              // 0000000597BC: D65D0016 01060680
	v_lshlrev_b32_e32 v3, 16, v25                              // 0000000597C4: 30063290
	v_mul_u32_u24_e32 v4, 48, v55                              // 0000000597C8: 16086EB0
	s_or_b32 s29, s54, 13                                      // 0000000597CC: 8C1D8D36
	v_cndmask_b16 v23, 0, v2, s55                              // 0000000597D0: D65D1017 00DE0480
	s_cmp_lt_i32 s29, s39                                      // 0000000597D8: BF04271D
	.long 0x7f041503                                           // 0000000597DC: 7F041503
	v_cvt_f16_f32_e32 v3, v33                                  // 0000000597E0: 7E061521
	ds_load_b128 v[30:33], v4 offset:21520                     // 0000000597E4: DBFC5410 1E000004
	ds_load_b128 v[26:29], v4 offset:21504                     // 0000000597EC: DBFC5400 1A000004
	ds_load_b128 v[38:41], v4 offset:19984                     // 0000000597F4: DBFC4E10 26000004
	ds_load_b128 v[34:37], v4 offset:19968                     // 0000000597FC: DBFC4E00 22000004
	s_cselect_b32 s29, -1, 0                                   // 000000059804: 981D80C1
	s_or_b32 s56, s54, 14                                      // 000000059808: 8C388E36
	v_lshlrev_b32_e32 v6, 16, v42                              // 00000005980C: 300C5490
	ds_load_b128 v[46:49], v4 offset:20752                     // 000000059810: DBFC5110 2E000004
	ds_load_b128 v[42:45], v4 offset:20736                     // 000000059818: DBFC5100 2A000004
	ds_load_b128 v[60:63], v4 offset:19200                     // 000000059820: DBFC4B00 3C000004
	ds_load_b128 v[64:67], v4 offset:19216                     // 000000059828: DBFC4B10 40000004
	s_cmp_lt_i32 s56, s39                                      // 000000059830: BF042738
	v_cndmask_b16 v22, 0, v2, s66                              // 000000059834: D65D4016 010A0480
	s_cselect_b32 s56, -1, 0                                   // 00000005983C: 983880C1
	s_or_b32 s67, s54, 15                                      // 000000059840: 8C438F36
	v_cvt_f16_f32_e32 v2, v24                                  // 000000059844: 7E041518
	.long 0x7f061506                                           // 000000059848: 7F061506
	v_cvt_f16_f32_e32 v4, v68                                  // 00000005984C: 7E081544
	s_cmp_lt_i32 s67, s39                                      // 000000059850: BF042743
	v_cndmask_b16 v24, 0, v2, s4                               // 000000059854: D65D1018 00120480
	s_cselect_b32 s67, -1, 0                                   // 00000005985C: 984380C1
	v_cndmask_b16 v23, 0, v2, s3                               // 000000059860: D65D4017 000E0480
	v_cndmask_b16 v24, 0, v3, s29                              // 000000059868: D65D4018 00760680
	v_cndmask_b16 v25, 0, v3, s56                              // 000000059870: D65D1019 00E20680
	v_cndmask_b16 v25, 0, v4, s67                              // 000000059878: D65D4019 010E0880
	.long 0x7f221505                                           // 000000059880: 7F221505
	v_cvt_f16_f32_e32 v17, v69                                 // 000000059884: 7E221545
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 000000059888: 916A267E
	s_waitcnt lgkmcnt(6)                                       // 00000005988C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[2:9], v[26:33], v[18:25], v[155:162]// 000000059890: CC404002 1E6E251A
	s_waitcnt lgkmcnt(4)                                       // 000000059898: BF89FC47
	v_wmma_f32_16x16x16_f16 v[26:33], v[34:41], v[10:17], v[155:162]// 00000005989C: CC40401A 1E6E1522
	s_waitcnt lgkmcnt(2)                                       // 0000000598A4: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000000598A8: BF870152
	v_wmma_f32_16x16x16_f16 v[2:9], v[42:49], v[18:25], v[2:9] // 0000000598AC: CC404002 1C0A252A
	s_waitcnt lgkmcnt(0)                                       // 0000000598B4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[26:33], v[60:67], v[10:17], v[26:33]// 0000000598B8: CC40401A 1C6A153C
	v_mad_u32_u24 v14, 0x110, v154, v59                        // 0000000598C0: D60B000E 04EF34FF 00000110
	v_cvt_f16_f32_e32 v10, v26                                 // 0000000598CC: 7E14151A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000598D0: BF870213
	.long 0x7f14151b                                           // 0000000598D4: 7F14151B
	v_cvt_f16_f32_e32 v11, v28                                 // 0000000598D8: 7E16151C
	.long 0x7f16151d                                           // 0000000598DC: 7F16151D
	v_cvt_f16_f32_e32 v12, v30                                 // 0000000598E0: 7E18151E
	.long 0x7f18151f                                           // 0000000598E4: 7F18151F
	v_cvt_f16_f32_e32 v13, v32                                 // 0000000598E8: 7E1A1520
	.long 0x7f1a1521                                           // 0000000598EC: 7F1A1521
	ds_store_b16 v14, v10 offset:14848                         // 0000000598F0: D87C3A00 00000A0E
	ds_store_b16_d16_hi v14, v10 offset:15392                  // 0000000598F8: DA843C20 00000A0E
	ds_store_b16 v14, v11 offset:15936                         // 000000059900: D87C3E40 00000B0E
	ds_store_b16_d16_hi v14, v11 offset:16480                  // 000000059908: DA844060 00000B0E
	ds_store_b16 v14, v12 offset:17024                         // 000000059910: D87C4280 00000C0E
	ds_store_b16_d16_hi v14, v12 offset:17568                  // 000000059918: DA8444A0 00000C0E
	ds_store_b16 v14, v13 offset:18112                         // 000000059920: D87C46C0 00000D0E
	ds_store_b16_d16_hi v14, v13 offset:18656                  // 000000059928: DA8448E0 00000D0E
	s_waitcnt lgkmcnt(0)                                       // 000000059930: BF89FC07
	s_barrier                                                  // 000000059934: BFBD0000
	s_cbranch_vccnz 4                                          // 000000059938: BFA40004 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x314c>
	s_sendmsg_rtn_b64 s[56:57], sendmsg(MSG_RTN_GET_REALTIME)  // 00000005993C: BEB84D83
	s_sub_i32 s3, s6, s28                                      // 000000059940: 81831C06
	s_waitcnt lgkmcnt(0)                                       // 000000059944: BF89FC07
	s_add_i32 s6, s3, s56                                      // 000000059948: 81063803
	v_fma_mixlo_f16 v10, v139, s51, 0                          // 00000005994C: CC21000A 0200678B
	v_fma_mixhi_f16 v10, v138, s51, 0                          // 000000059954: CC22000A 0200678A
	v_cmp_eq_u32_e32 vcc_lo, 0, v154                           // 00000005995C: 7C953480
	v_mov_b32_e32 v12, 0x3020706                               // 000000059960: 7E1802FF 03020706
	ds_load_b128 v[46:49], v57 offset:14864                    // 000000059968: DBFC3A10 2E000039
	ds_load_b128 v[42:45], v57 offset:14848                    // 000000059970: DBFC3A00 2A000039
	ds_load_b128 v[66:69], v57 offset:14896                    // 000000059978: DBFC3A30 42000039
	ds_load_b128 v[62:65], v57 offset:14880                    // 000000059980: DBFC3A20 3E000039
	v_dual_mov_b32 v11, v10 :: v_dual_cndmask_b32 v60, 0x5040100, v149// 000000059988: CA12010A 0B3D2AFF 05040100
	v_cndmask_b32_e32 v61, 0x7060302, v12, vcc_lo              // 000000059994: 027A18FF 07060302
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005999C: BF870092
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 0000000599A0: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v26, v10, v11, v60                              // 0000000599AC: D644001A 04F2170A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000599B4: BF8700B3
	v_perm_b32 v27, v10, v11, v61                              // 0000000599B8: D644001B 04F6170A
	v_fma_mixlo_f16 v10, v137, s51, 0                          // 0000000599C0: CC21000A 02006789
	v_fma_mixhi_f16 v10, v136, s51, 0                          // 0000000599C8: CC22000A 02006788
	v_mov_b32_e32 v11, v10                                     // 0000000599D0: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000599D4: BF870091
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 0000000599D8: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v28, v10, v11, v60                              // 0000000599E4: D644001C 04F2170A
	v_perm_b32 v29, v10, v11, v61                              // 0000000599EC: D644001D 04F6170A
	v_fma_mixlo_f16 v10, v135, s51, 0                          // 0000000599F4: CC21000A 02006787
	v_fma_mixhi_f16 v10, v134, s51, 0                          // 0000000599FC: CC22000A 02006786
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059A04: BF870091
	v_mov_b32_e32 v11, v10                                     // 000000059A08: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000059A0C: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000059A18: BF8700C1
	v_perm_b32 v30, v10, v11, v60                              // 000000059A1C: D644001E 04F2170A
	v_perm_b32 v31, v10, v11, v61                              // 000000059A24: D644001F 04F6170A
	v_fma_mixlo_f16 v10, v133, s51, 0                          // 000000059A2C: CC21000A 02006785
	v_fma_mixhi_f16 v10, v54, s51, 0                           // 000000059A34: CC22000A 02006736
	v_mov_b32_e32 v11, v10                                     // 000000059A3C: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059A40: BF870091
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000059A44: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v32, v10, v11, v60                              // 000000059A50: D6440020 04F2170A
	v_perm_b32 v33, v10, v11, v61                              // 000000059A58: D6440021 04F6170A
	v_fma_mixlo_f16 v10, v132, s51, 0                          // 000000059A60: CC21000A 02006784
	v_fma_mixhi_f16 v10, v131, s51, 0                          // 000000059A68: CC22000A 02006783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059A70: BF870091
	v_mov_b32_e32 v11, v10                                     // 000000059A74: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000059A78: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000059A84: BF8700C1
	v_perm_b32 v34, v10, v11, v60                              // 000000059A88: D6440022 04F2170A
	v_perm_b32 v35, v10, v11, v61                              // 000000059A90: D6440023 04F6170A
	v_fma_mixlo_f16 v10, v130, s51, 0                          // 000000059A98: CC21000A 02006782
	v_fma_mixhi_f16 v10, v129, s51, 0                          // 000000059AA0: CC22000A 02006781
	v_mov_b32_e32 v11, v10                                     // 000000059AA8: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059AAC: BF870091
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000059AB0: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v36, v10, v11, v60                              // 000000059ABC: D6440024 04F2170A
	v_perm_b32 v37, v10, v11, v61                              // 000000059AC4: D6440025 04F6170A
	v_fma_mixlo_f16 v10, v128, s51, 0                          // 000000059ACC: CC21000A 02006780
	v_fma_mixhi_f16 v10, v127, s51, 0                          // 000000059AD4: CC22000A 0200677F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059ADC: BF870091
	v_mov_b32_e32 v11, v10                                     // 000000059AE0: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000059AE4: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000059AF0: BF8700C1
	v_perm_b32 v38, v10, v11, v60                              // 000000059AF4: D6440026 04F2170A
	v_perm_b32 v39, v10, v11, v61                              // 000000059AFC: D6440027 04F6170A
	v_fma_mixlo_f16 v10, v126, s51, 0                          // 000000059B04: CC21000A 0200677E
	v_fma_mixhi_f16 v10, v53, s51, 0                           // 000000059B0C: CC22000A 02006735
	v_mov_b32_e32 v11, v10                                     // 000000059B14: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000059B18: BF870091
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000059B1C: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v40, v10, v11, v60                              // 000000059B28: D6440028 04F2170A
	v_perm_b32 v41, v10, v11, v61                              // 000000059B30: D6440029 04F6170A
	v_dual_mov_b32 v10, s20 :: v_dual_mov_b32 v11, s21         // 000000059B38: CA100014 0A0A0015
	v_dual_mov_b32 v12, s22 :: v_dual_mov_b32 v13, s23         // 000000059B40: CA100016 0C0C0017
	v_dual_mov_b32 v14, s24 :: v_dual_mov_b32 v15, s25         // 000000059B48: CA100018 0E0E0019
	v_dual_mov_b32 v16, s26 :: v_dual_mov_b32 v17, s27         // 000000059B50: CA10001A 1010001B
	s_waitcnt lgkmcnt(2)                                       // 000000059B58: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000059B5C: BF8700A1
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[26:33], v[10:17]// 000000059B60: CC404012 1C2A352A
	s_waitcnt lgkmcnt(0)                                       // 000000059B68: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[62:69], v[34:41], v[18:25]// 000000059B6C: CC404012 1C4A453E
	ds_load_b128 v[62:65], v57 offset:10496                    // 000000059B74: DBFC2900 3E000039
	ds_load_b128 v[66:69], v57 offset:10512                    // 000000059B7C: DBFC2910 42000039
	s_waitcnt lgkmcnt(0)                                       // 000000059B84: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[62:69], v[26:33], v[10:17]// 000000059B88: CC40402A 1C2A353E
	ds_load_b128 v[26:29], v57 offset:10528                    // 000000059B90: DBFC2920 1A000039
	ds_load_b128 v[30:33], v57 offset:10544                    // 000000059B98: DBFC2930 1E000039
	s_waitcnt lgkmcnt(0)                                       // 000000059BA0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[26:33], v[34:41], v[42:49]// 000000059BA4: CC40402A 1CAA451A
	v_fma_mixlo_f16 v27, v125, s51, 0                          // 000000059BAC: CC21001B 0200677D
	v_fma_mixhi_f16 v27, v124, s51, 0                          // 000000059BB4: CC22001B 0200677C
	v_fma_mixlo_f16 v29, v123, s51, 0                          // 000000059BBC: CC21001D 0200677B
	v_fma_mixhi_f16 v29, v122, s51, 0                          // 000000059BC4: CC22001D 0200677A
	v_fma_mixlo_f16 v31, v121, s51, 0                          // 000000059BCC: CC21001F 02006779
	v_fma_mixhi_f16 v31, v120, s51, 0                          // 000000059BD4: CC22001F 02006778
	v_fma_mixlo_f16 v33, v119, s51, 0                          // 000000059BDC: CC210021 02006777
	v_fma_mixhi_f16 v33, v52, s51, 0                           // 000000059BE4: CC220021 02006734
	v_mov_b32_e32 v28, v27                                     // 000000059BEC: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000059BF0: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000059BF4: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000059BF8: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000059BFC: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000059C00: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000059C0C: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000059C10: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000059C1C: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000059C28: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000059C2C: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v60                              // 000000059C38: D644001A 04F2391B
	v_perm_b32 v27, v27, v28, v61                              // 000000059C40: D644001B 04F6391B
	v_perm_b32 v28, v29, v30, v60                              // 000000059C48: D644001C 04F23D1D
	v_perm_b32 v29, v29, v30, v61                              // 000000059C50: D644001D 04F63D1D
	v_perm_b32 v30, v31, v32, v60                              // 000000059C58: D644001E 04F2411F
	v_perm_b32 v31, v31, v32, v61                              // 000000059C60: D644001F 04F6411F
	v_perm_b32 v32, v33, v34, v60                              // 000000059C68: D6440020 04F24521
	v_perm_b32 v33, v33, v34, v61                              // 000000059C70: D6440021 04F64521
	ds_load_b128 v[38:41], v57 offset:14928                    // 000000059C78: DBFC3A50 26000039
	ds_load_b128 v[34:37], v57 offset:14912                    // 000000059C80: DBFC3A40 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000059C88: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000059C8C: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10576                    // 000000059C94: DBFC2950 26000039
	ds_load_b128 v[34:37], v57 offset:10560                    // 000000059C9C: DBFC2940 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000059CA4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000059CA8: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v118, s51, 0                          // 000000059CB0: CC21001B 02006776
	v_fma_mixhi_f16 v27, v117, s51, 0                          // 000000059CB8: CC22001B 02006775
	v_fma_mixlo_f16 v29, v116, s51, 0                          // 000000059CC0: CC21001D 02006774
	v_fma_mixhi_f16 v29, v115, s51, 0                          // 000000059CC8: CC22001D 02006773
	v_fma_mixlo_f16 v31, v114, s51, 0                          // 000000059CD0: CC21001F 02006772
	v_fma_mixhi_f16 v31, v113, s51, 0                          // 000000059CD8: CC22001F 02006771
	v_fma_mixlo_f16 v33, v112, s51, 0                          // 000000059CE0: CC210021 02006770
	v_fma_mixhi_f16 v33, v51, s51, 0                           // 000000059CE8: CC220021 02006733
	v_mov_b32_e32 v28, v27                                     // 000000059CF0: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000059CF4: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000059CF8: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000059CFC: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000059D00: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000059D04: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000059D10: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000059D14: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000059D20: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000059D2C: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000059D30: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v60                              // 000000059D3C: D644001A 04F2391B
	v_perm_b32 v27, v27, v28, v61                              // 000000059D44: D644001B 04F6391B
	v_perm_b32 v28, v29, v30, v60                              // 000000059D4C: D644001C 04F23D1D
	v_perm_b32 v29, v29, v30, v61                              // 000000059D54: D644001D 04F63D1D
	v_perm_b32 v30, v31, v32, v60                              // 000000059D5C: D644001E 04F2411F
	v_perm_b32 v31, v31, v32, v61                              // 000000059D64: D644001F 04F6411F
	v_perm_b32 v32, v33, v34, v60                              // 000000059D6C: D6440020 04F24521
	v_perm_b32 v33, v33, v34, v61                              // 000000059D74: D6440021 04F64521
	ds_load_b128 v[38:41], v57 offset:14960                    // 000000059D7C: DBFC3A70 26000039
	ds_load_b128 v[34:37], v57 offset:14944                    // 000000059D84: DBFC3A60 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000059D8C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000059D90: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10608                    // 000000059D98: DBFC2970 26000039
	ds_load_b128 v[34:37], v57 offset:10592                    // 000000059DA0: DBFC2960 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000059DA8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000059DAC: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v111, s51, 0                          // 000000059DB4: CC21001B 0200676F
	v_fma_mixhi_f16 v27, v110, s51, 0                          // 000000059DBC: CC22001B 0200676E
	v_fma_mixlo_f16 v29, v109, s51, 0                          // 000000059DC4: CC21001D 0200676D
	v_fma_mixhi_f16 v29, v108, s51, 0                          // 000000059DCC: CC22001D 0200676C
	v_fma_mixlo_f16 v31, v107, s51, 0                          // 000000059DD4: CC21001F 0200676B
	v_fma_mixhi_f16 v31, v106, s51, 0                          // 000000059DDC: CC22001F 0200676A
	v_fma_mixlo_f16 v33, v105, s51, 0                          // 000000059DE4: CC210021 02006769
	v_fma_mixhi_f16 v33, v50, s51, 0                           // 000000059DEC: CC220021 02006732
	v_mov_b32_e32 v28, v27                                     // 000000059DF4: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000059DF8: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000059DFC: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000059E00: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000059E04: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000059E08: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000059E14: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000059E18: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000059E24: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000059E30: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000059E34: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v60                              // 000000059E40: D644001A 04F2391B
	v_perm_b32 v27, v27, v28, v61                              // 000000059E48: D644001B 04F6391B
	v_perm_b32 v28, v29, v30, v60                              // 000000059E50: D644001C 04F23D1D
	v_perm_b32 v29, v29, v30, v61                              // 000000059E58: D644001D 04F63D1D
	v_perm_b32 v30, v31, v32, v60                              // 000000059E60: D644001E 04F2411F
	v_perm_b32 v31, v31, v32, v61                              // 000000059E68: D644001F 04F6411F
	v_perm_b32 v32, v33, v34, v60                              // 000000059E70: D6440020 04F24521
	v_perm_b32 v33, v33, v34, v61                              // 000000059E78: D6440021 04F64521
	ds_load_b128 v[38:41], v57 offset:14992                    // 000000059E80: DBFC3A90 26000039
	ds_load_b128 v[34:37], v57 offset:14976                    // 000000059E88: DBFC3A80 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000059E90: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000059E94: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10640                    // 000000059E9C: DBFC2990 26000039
	ds_load_b128 v[34:37], v57 offset:10624                    // 000000059EA4: DBFC2980 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000059EAC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000059EB0: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v104, s51, 0                          // 000000059EB8: CC21001B 02006768
	v_fma_mixhi_f16 v27, v103, s51, 0                          // 000000059EC0: CC22001B 02006767
	v_fma_mixlo_f16 v29, v102, s51, 0                          // 000000059EC8: CC21001D 02006766
	v_fma_mixhi_f16 v29, v101, s51, 0                          // 000000059ED0: CC22001D 02006765
	v_fma_mixlo_f16 v31, v100, s51, 0                          // 000000059ED8: CC21001F 02006764
	v_fma_mixhi_f16 v31, v99, s51, 0                           // 000000059EE0: CC22001F 02006763
	v_fma_mixlo_f16 v33, v98, s51, 0                           // 000000059EE8: CC210021 02006762
	v_fma_mixhi_f16 v33, v58, s51, 0                           // 000000059EF0: CC220021 0200673A
	v_mov_b32_e32 v28, v27                                     // 000000059EF8: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000059EFC: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000059F00: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000059F04: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000059F08: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000059F0C: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000059F18: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000059F1C: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000059F28: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000059F34: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000059F38: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v60                              // 000000059F44: D644001A 04F2391B
	v_perm_b32 v27, v27, v28, v61                              // 000000059F4C: D644001B 04F6391B
	v_perm_b32 v28, v29, v30, v60                              // 000000059F54: D644001C 04F23D1D
	v_perm_b32 v29, v29, v30, v61                              // 000000059F5C: D644001D 04F63D1D
	v_perm_b32 v30, v31, v32, v60                              // 000000059F64: D644001E 04F2411F
	v_perm_b32 v31, v31, v32, v61                              // 000000059F6C: D644001F 04F6411F
	v_perm_b32 v32, v33, v34, v60                              // 000000059F74: D6440020 04F24521
	v_perm_b32 v33, v33, v34, v61                              // 000000059F7C: D6440021 04F64521
	ds_load_b128 v[38:41], v57 offset:15024                    // 000000059F84: DBFC3AB0 26000039
	ds_load_b128 v[34:37], v57 offset:15008                    // 000000059F8C: DBFC3AA0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000059F94: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000059F98: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10672                    // 000000059FA0: DBFC29B0 26000039
	ds_load_b128 v[34:37], v57 offset:10656                    // 000000059FA8: DBFC29A0 22000039
	s_waitcnt lgkmcnt(0)                                       // 000000059FB0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000059FB4: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v97, s51, 0                           // 000000059FBC: CC21001B 02006761
	v_fma_mixhi_f16 v27, v96, s51, 0                           // 000000059FC4: CC22001B 02006760
	v_fma_mixlo_f16 v29, v95, s51, 0                           // 000000059FCC: CC21001D 0200675F
	v_fma_mixhi_f16 v29, v94, s51, 0                           // 000000059FD4: CC22001D 0200675E
	v_fma_mixlo_f16 v31, v93, s51, 0                           // 000000059FDC: CC21001F 0200675D
	v_fma_mixhi_f16 v31, v92, s51, 0                           // 000000059FE4: CC22001F 0200675C
	v_fma_mixlo_f16 v33, v91, s51, 0                           // 000000059FEC: CC210021 0200675B
	v_fma_mixhi_f16 v33, v152, s51, 0                          // 000000059FF4: CC220021 02006798
	v_mov_b32_e32 v28, v27                                     // 000000059FFC: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000005A000: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000005A004: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005A008: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000005A00C: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000005A010: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005A01C: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000005A020: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000005A02C: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005A038: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000005A03C: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v60                              // 00000005A048: D644001A 04F2391B
	v_perm_b32 v27, v27, v28, v61                              // 00000005A050: D644001B 04F6391B
	v_perm_b32 v28, v29, v30, v60                              // 00000005A058: D644001C 04F23D1D
	v_perm_b32 v29, v29, v30, v61                              // 00000005A060: D644001D 04F63D1D
	v_perm_b32 v30, v31, v32, v60                              // 00000005A068: D644001E 04F2411F
	v_perm_b32 v31, v31, v32, v61                              // 00000005A070: D644001F 04F6411F
	v_perm_b32 v32, v33, v34, v60                              // 00000005A078: D6440020 04F24521
	v_perm_b32 v33, v33, v34, v61                              // 00000005A080: D6440021 04F64521
	ds_load_b128 v[38:41], v57 offset:15056                    // 00000005A088: DBFC3AD0 26000039
	ds_load_b128 v[34:37], v57 offset:15040                    // 00000005A090: DBFC3AC0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000005A098: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000005A09C: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10704                    // 00000005A0A4: DBFC29D0 26000039
	ds_load_b128 v[34:37], v57 offset:10688                    // 00000005A0AC: DBFC29C0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000005A0B4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000005A0B8: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v90, s51, 0                           // 00000005A0C0: CC21001B 0200675A
	v_fma_mixhi_f16 v27, v141, s51, 0                          // 00000005A0C8: CC22001B 0200678D
	v_fma_mixlo_f16 v29, v150, s51, 0                          // 00000005A0D0: CC21001D 02006796
	v_fma_mixhi_f16 v29, v142, s51, 0                          // 00000005A0D8: CC22001D 0200678E
	v_fma_mixlo_f16 v31, v191, s51, 0                          // 00000005A0E0: CC21001F 020067BF
	v_fma_mixhi_f16 v31, v189, s51, 0                          // 00000005A0E8: CC22001F 020067BD
	v_fma_mixlo_f16 v33, v190, s51, 0                          // 00000005A0F0: CC210021 020067BE
	v_fma_mixhi_f16 v33, v151, s51, 0                          // 00000005A0F8: CC220021 02006797
	v_mov_b32_e32 v28, v27                                     // 00000005A100: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000005A104: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000005A108: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005A10C: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000005A110: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000005A114: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005A120: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000005A124: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000005A130: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005A13C: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000005A140: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v60                              // 00000005A14C: D644001A 04F2391B
	v_perm_b32 v27, v27, v28, v61                              // 00000005A154: D644001B 04F6391B
	v_perm_b32 v28, v29, v30, v60                              // 00000005A15C: D644001C 04F23D1D
	v_perm_b32 v29, v29, v30, v61                              // 00000005A164: D644001D 04F63D1D
	v_perm_b32 v30, v31, v32, v60                              // 00000005A16C: D644001E 04F2411F
	v_perm_b32 v31, v31, v32, v61                              // 00000005A174: D644001F 04F6411F
	v_perm_b32 v32, v33, v34, v60                              // 00000005A17C: D6440020 04F24521
	v_perm_b32 v33, v33, v34, v61                              // 00000005A184: D6440021 04F64521
	ds_load_b128 v[38:41], v57 offset:15088                    // 00000005A18C: DBFC3AF0 26000039
	ds_load_b128 v[34:37], v57 offset:15072                    // 00000005A194: DBFC3AE0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000005A19C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000005A1A0: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10736                    // 00000005A1A8: DBFC29F0 26000039
	ds_load_b128 v[34:37], v57 offset:10720                    // 00000005A1B0: DBFC29E0 22000039
	v_dual_mul_f32 v19, 0x3b800000, v19 :: v_dual_mul_f32 v18, 0x3b800000, v18// 00000005A1B8: C8C626FF 131224FF 3B800000
	v_dual_mul_f32 v20, 0x3b800000, v20 :: v_dual_mul_f32 v21, 0x3b800000, v21// 00000005A1C4: C8C628FF 14142AFF 3B800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005A1D0: BF870222
	v_dual_mul_f32 v22, 0x3b800000, v22 :: v_dual_sub_f32 v3, v3, v19// 00000005A1D4: C8CA2CFF 16022703 3B800000
	v_or_b32_e32 v19, s54, v154                                // 00000005A1E0: 38273436
	v_sub_f32_e32 v2, v2, v18                                  // 00000005A1E4: 08042502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005A1E8: BF870224
	v_dual_sub_f32 v4, v4, v20 :: v_dual_sub_f32 v5, v5, v21   // 00000005A1EC: C94A2904 04042B05
	v_mul_f32_e32 v23, 0x3b800000, v23                         // 00000005A1F4: 102E2EFF 3B800000
	v_or_b32_e32 v18, 2, v19                                   // 00000005A1FC: 38242682
	.long 0xd4440003                                           // 00000005A200: D4440003
	v_cndmask_b32_e32 v1, s39, v19, vcc_lo                     // 00000005A204: 02022627
	v_fma_mixlo_f16 v2, v2, s48, 0                             // 00000005A208: CC210002 02006102
	v_fma_mixhi_f16 v2, v3, s48, 0                             // 00000005A210: CC220002 02006103
	v_sub_f32_e32 v6, v6, v22                                  // 00000005A218: 080C2D06
	v_cmp_gt_i32_e32 vcc_lo, s39, v18                          // 00000005A21C: 7C882427
	v_sub_f32_e32 v7, v7, v23                                  // 00000005A220: 080E2F07
	v_cndmask_b16 v2, 0, v2, s3                                // 00000005A224: D65D0002 000E0480
	v_dual_mul_f32 v24, 0x3b800000, v24 :: v_dual_mul_f32 v25, 0x3b800000, v25// 00000005A22C: C8C630FF 181832FF 3B800000
	v_cndmask_b16 v2, 0, v2, vcc_lo                            // 00000005A238: D65D5002 01AA0480
	v_mad_u32_u24 v18, v55, 48, 0x4b00                         // 00000005A240: D60B0012 03FD6137 00004B00
	s_waitcnt lgkmcnt(0)                                       // 00000005A24C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000005A250: CC40402A 1CAA3522
	v_dual_sub_f32 v8, v8, v24 :: v_dual_sub_f32 v9, v9, v25   // 00000005A258: C94A3108 08083309
	v_mov_b32_e32 v3, v2                                       // 00000005A260: 7E060302
	ds_load_b128 v[20:23], v18 offset:4096                     // 00000005A264: DBFC1000 14000012
	ds_load_b128 v[24:27], v18 offset:4112                     // 00000005A26C: DBFC1010 18000012
	v_permlanex16_b32 v3, v3, s52, 0xfedcba98                  // 00000005A274: D65C0003 03FC6903 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000005A280: BF8700B1
	v_perm_b32 v66, v2, v3, v60                                // 00000005A284: D6440042 04F20702
	v_perm_b32 v67, v2, v3, v61                                // 00000005A28C: D6440043 04F60702
	v_or_b32_e32 v2, 4, v19                                    // 00000005A294: 38042684
	v_cmp_gt_i32_e32 vcc_lo, s39, v2                           // 00000005A298: 7C880427
	v_or_b32_e32 v2, 6, v19                                    // 00000005A29C: 38042686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000005A2A0: BF870131
	.long 0xd4440004                                           // 00000005A2A4: D4440004
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005A2A8: 02020427
	v_fma_mixlo_f16 v2, v4, s48, 0                             // 00000005A2AC: CC210002 02006104
	v_fma_mixhi_f16 v2, v5, s48, 0                             // 00000005A2B4: CC220002 02006105
	v_cndmask_b16 v2, 0, v2, vcc_lo                            // 00000005A2BC: D65D0002 01AA0480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A2C4: BF870092
	v_cndmask_b16 v2, 0, v2, s4                                // 00000005A2C8: D65D5002 00120480
	v_mov_b32_e32 v3, v2                                       // 00000005A2D0: 7E060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A2D4: BF870091
	v_permlanex16_b32 v3, v3, s52, 0xfedcba98                  // 00000005A2D8: D65C0003 03FC6903 FEDCBA98
	v_perm_b32 v68, v2, v3, v60                                // 00000005A2E4: D6440044 04F20702
	v_perm_b32 v69, v2, v3, v61                                // 00000005A2EC: D6440045 04F60702
	v_or_b32_e32 v2, 8, v19                                    // 00000005A2F4: 38042688
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005A2F8: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s39, v2                           // 00000005A2FC: 7C880427
	v_or_b32_e32 v2, 10, v19                                   // 00000005A300: 3804268A
	.long 0xd4440004                                           // 00000005A304: D4440004
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005A308: 02020427
	v_fma_mixlo_f16 v2, v6, s48, 0                             // 00000005A30C: CC210002 02006106
	v_fma_mixhi_f16 v2, v7, s48, 0                             // 00000005A314: CC220002 02006107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005A31C: BF870112
	v_cndmask_b16 v2, 0, v2, vcc_lo                            // 00000005A320: D65D0002 01AA0480
	v_cndmask_b16 v2, 0, v2, s4                                // 00000005A328: D65D5002 00120480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A330: BF870091
	v_mov_b32_e32 v3, v2                                       // 00000005A334: 7E060302
	v_permlanex16_b32 v3, v3, s52, 0xfedcba98                  // 00000005A338: D65C0003 03FC6903 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000005A344: BF8700B1
	v_perm_b32 v70, v2, v3, v60                                // 00000005A348: D6440046 04F20702
	v_perm_b32 v71, v2, v3, v61                                // 00000005A350: D6440047 04F60702
	v_or_b32_e32 v2, 12, v19                                   // 00000005A358: 3804268C
	v_cmp_gt_i32_e32 vcc_lo, s39, v2                           // 00000005A35C: 7C880427
	v_or_b32_e32 v2, 14, v19                                   // 00000005A360: 3804268E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000005A364: BF870131
	.long 0xd4440004                                           // 00000005A368: D4440004
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005A36C: 02020427
	v_fma_mixlo_f16 v2, v8, s48, 0                             // 00000005A370: CC210002 02006108
	v_fma_mixhi_f16 v2, v9, s48, 0                             // 00000005A378: CC220002 02006109
	v_cndmask_b16 v2, 0, v2, vcc_lo                            // 00000005A380: D65D0002 01AA0480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A388: BF870092
	v_cndmask_b16 v2, 0, v2, s4                                // 00000005A38C: D65D5002 00120480
	v_mov_b32_e32 v3, v2                                       // 00000005A394: 7E060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A398: BF870091
	v_permlanex16_b32 v3, v3, s52, 0xfedcba98                  // 00000005A39C: D65C0003 03FC6903 FEDCBA98
	v_perm_b32 v72, v2, v3, v60                                // 00000005A3A8: D6440048 04F20702
	v_perm_b32 v73, v2, v3, v61                                // 00000005A3B0: D6440049 04F60702
	s_waitcnt lgkmcnt(0)                                       // 00000005A3B8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005A3BC: BF8700A1
	v_wmma_f32_16x16x16_f16 v[2:9], v[20:27], v[66:73], v[10:17]// 00000005A3C0: CC404002 1C2A8514
	.long 0xd700040a                                           // 00000005A3C8: D700040A
	v_cndmask_b32_e32 v1, s44, v59, vcc_lo                     // 00000005A3CC: 0202762C
	v_add_co_ci_u32_e64 v11, null, s45, 0, s4                  // 00000005A3D0: D5207C0B 0011002D
	s_and_saveexec_b32 s4, s3                                  // 00000005A3D8: BE842003
	s_cbranch_execz 19                                         // 00000005A3DC: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3c2c>
	ds_load_b32 v12, v56 offset:24320                          // 00000005A3E0: D8D85F00 0C000038
	s_waitcnt lgkmcnt(0)                                       // 00000005A3E8: BF89FC07
	v_mul_f32_e32 v12, v42, v12                                // 00000005A3EC: 1018192A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005A3F0: BF870121
	v_add_f32_e32 v2, v2, v12                                  // 00000005A3F4: 06041902
	v_mad_u64_u32 v[12:13], null, 0x3000, v19, v[10:11]        // 00000005A3F8: D6FE7C0C 042A26FF 00003000
	v_mul_f32_e32 v2, 0x3b800000, v2                           // 00000005A404: 100404FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A40C: BF870091
	v_bfe_u32 v14, v2, 16, 1                                   // 00000005A410: D610000E 02052102
	v_add3_u32 v2, v2, v14, 0x7fff                             // 00000005A418: D6550002 03FE1D02 00007FFF
	global_store_d16_hi_b16 v[12:13], v2, off                  // 00000005A424: DC960000 007C020C
	s_or_b32 exec_lo, exec_lo, s4                              // 00000005A42C: 8C7E047E
	v_or3_b32 v2, v154, s54, 2                                 // 00000005A430: D6580002 02086D9A
	s_mov_b32 s3, exec_lo                                      // 00000005A438: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005A43C: BF870001
	.long 0xd4c4007e                                           // 00000005A440: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005A444: 02020427
	s_cbranch_execz 19                                         // 00000005A448: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3c98>
	ds_load_b32 v12, v56 offset:24328                          // 00000005A44C: D8D85F08 0C000038
	s_waitcnt lgkmcnt(0)                                       // 00000005A454: BF89FC07
	v_mul_f32_e32 v12, v43, v12                                // 00000005A458: 1018192B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A45C: BF870091
	v_add_f32_e32 v3, v3, v12                                  // 00000005A460: 06061903
	v_mul_f32_e32 v12, 0x3b800000, v3                          // 00000005A464: 101806FF 3B800000
	v_mad_u64_u32 v[2:3], null, 0x3000, v2, v[10:11]           // 00000005A46C: D6FE7C02 042A04FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A478: BF870092
	v_bfe_u32 v13, v12, 16, 1                                  // 00000005A47C: D610000D 0205210C
	v_add3_u32 v12, v12, v13, 0x7fff                           // 00000005A484: D655000C 03FE1B0C 00007FFF
	global_store_d16_hi_b16 v[2:3], v12, off                   // 00000005A490: DC960000 007C0C02
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005A498: 8C7E037E
	v_or3_b32 v2, v154, s54, 4                                 // 00000005A49C: D6580002 02106D9A
	s_mov_b32 s3, exec_lo                                      // 00000005A4A4: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005A4A8: BF870001
	.long 0xd4c4007e                                           // 00000005A4AC: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005A4B0: 02020427
	s_cbranch_execz 19                                         // 00000005A4B4: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3d04>
	ds_load_b32 v3, v56 offset:24336                           // 00000005A4B8: D8D85F10 03000038
	s_waitcnt lgkmcnt(0)                                       // 00000005A4C0: BF89FC07
	v_mul_f32_e32 v3, v44, v3                                  // 00000005A4C4: 1006072C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A4C8: BF870091
	v_add_f32_e32 v3, v4, v3                                   // 00000005A4CC: 06060704
	v_mul_f32_e32 v4, 0x3b800000, v3                           // 00000005A4D0: 100806FF 3B800000
	v_mad_u64_u32 v[2:3], null, 0x3000, v2, v[10:11]           // 00000005A4D8: D6FE7C02 042A04FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A4E4: BF870092
	v_bfe_u32 v12, v4, 16, 1                                   // 00000005A4E8: D610000C 02052104
	v_add3_u32 v4, v4, v12, 0x7fff                             // 00000005A4F0: D6550004 03FE1904 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000005A4FC: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005A504: 8C7E037E
	v_or3_b32 v2, v154, s54, 6                                 // 00000005A508: D6580002 02186D9A
	s_mov_b32 s3, exec_lo                                      // 00000005A510: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005A514: BF870001
	.long 0xd4c4007e                                           // 00000005A518: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005A51C: 02020427
	s_cbranch_execz 19                                         // 00000005A520: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3d70>
	ds_load_b32 v3, v56 offset:24344                           // 00000005A524: D8D85F18 03000038
	s_waitcnt lgkmcnt(0)                                       // 00000005A52C: BF89FC07
	v_mul_f32_e32 v3, v45, v3                                  // 00000005A530: 1006072D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A534: BF870091
	v_add_f32_e32 v3, v5, v3                                   // 00000005A538: 06060705
	v_mul_f32_e32 v4, 0x3b800000, v3                           // 00000005A53C: 100806FF 3B800000
	v_mad_u64_u32 v[2:3], null, 0x3000, v2, v[10:11]           // 00000005A544: D6FE7C02 042A04FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A550: BF870092
	v_bfe_u32 v5, v4, 16, 1                                    // 00000005A554: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000005A55C: D6550004 03FE0B04 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000005A568: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005A570: 8C7E037E
	v_or3_b32 v2, v154, s54, 8                                 // 00000005A574: D6580002 02206D9A
	s_mov_b32 s3, exec_lo                                      // 00000005A57C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005A580: BF870001
	.long 0xd4c4007e                                           // 00000005A584: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005A588: 02020427
	s_cbranch_execz 19                                         // 00000005A58C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3ddc>
	ds_load_b32 v3, v56 offset:24352                           // 00000005A590: D8D85F20 03000038
	s_waitcnt lgkmcnt(0)                                       // 00000005A598: BF89FC07
	v_mul_f32_e32 v3, v46, v3                                  // 00000005A59C: 1006072E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A5A0: BF870091
	v_add_f32_e32 v3, v6, v3                                   // 00000005A5A4: 06060706
	v_mul_f32_e32 v4, 0x3b800000, v3                           // 00000005A5A8: 100806FF 3B800000
	v_mad_u64_u32 v[2:3], null, 0x3000, v2, v[10:11]           // 00000005A5B0: D6FE7C02 042A04FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A5BC: BF870092
	v_bfe_u32 v5, v4, 16, 1                                    // 00000005A5C0: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000005A5C8: D6550004 03FE0B04 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000005A5D4: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005A5DC: 8C7E037E
	v_or3_b32 v2, v154, s54, 10                                // 00000005A5E0: D6580002 02286D9A
	s_mov_b32 s3, exec_lo                                      // 00000005A5E8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005A5EC: BF870001
	.long 0xd4c4007e                                           // 00000005A5F0: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005A5F4: 02020427
	s_cbranch_execz 19                                         // 00000005A5F8: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3e48>
	ds_load_b32 v3, v56 offset:24360                           // 00000005A5FC: D8D85F28 03000038
	s_waitcnt lgkmcnt(0)                                       // 00000005A604: BF89FC07
	v_mul_f32_e32 v3, v47, v3                                  // 00000005A608: 1006072F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A60C: BF870091
	v_add_f32_e32 v3, v7, v3                                   // 00000005A610: 06060707
	v_mul_f32_e32 v4, 0x3b800000, v3                           // 00000005A614: 100806FF 3B800000
	v_mad_u64_u32 v[2:3], null, 0x3000, v2, v[10:11]           // 00000005A61C: D6FE7C02 042A04FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A628: BF870092
	v_bfe_u32 v5, v4, 16, 1                                    // 00000005A62C: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000005A634: D6550004 03FE0B04 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000005A640: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005A648: 8C7E037E
	v_or3_b32 v2, v154, s54, 12                                // 00000005A64C: D6580002 02306D9A
	s_mov_b32 s3, exec_lo                                      // 00000005A654: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005A658: BF870001
	.long 0xd4c4007e                                           // 00000005A65C: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005A660: 02020427
	s_cbranch_execz 19                                         // 00000005A664: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3eb4>
	ds_load_b32 v3, v56 offset:24368                           // 00000005A668: D8D85F30 03000038
	s_waitcnt lgkmcnt(0)                                       // 00000005A670: BF89FC07
	v_mul_f32_e32 v3, v48, v3                                  // 00000005A674: 10060730
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A678: BF870091
	v_add_f32_e32 v3, v8, v3                                   // 00000005A67C: 06060708
	v_mul_f32_e32 v4, 0x3b800000, v3                           // 00000005A680: 100806FF 3B800000
	v_mad_u64_u32 v[2:3], null, 0x3000, v2, v[10:11]           // 00000005A688: D6FE7C02 042A04FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A694: BF870092
	v_bfe_u32 v5, v4, 16, 1                                    // 00000005A698: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000005A6A0: D6550004 03FE0B04 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000005A6AC: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005A6B4: 8C7E037E
	v_or3_b32 v2, v154, s54, 14                                // 00000005A6B8: D6580002 02386D9A
	s_mov_b32 s3, exec_lo                                      // 00000005A6C0: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005A6C4: BF870001
	.long 0xd4c4007e                                           // 00000005A6C8: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005A6CC: 02020427
	s_cbranch_execz 19                                         // 00000005A6D0: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3f20>
	ds_load_b32 v3, v56 offset:24376                           // 00000005A6D4: D8D85F38 03000038
	s_waitcnt lgkmcnt(0)                                       // 00000005A6DC: BF89FC07
	v_mul_f32_e32 v3, v49, v3                                  // 00000005A6E0: 10060731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A6E4: BF870091
	v_add_f32_e32 v3, v9, v3                                   // 00000005A6E8: 06060709
	v_mul_f32_e32 v4, 0x3b800000, v3                           // 00000005A6EC: 100806FF 3B800000
	v_mad_u64_u32 v[2:3], null, 0x3000, v2, v[10:11]           // 00000005A6F4: D6FE7C02 042A04FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005A700: BF870092
	v_bfe_u32 v5, v4, 16, 1                                    // 00000005A704: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000005A70C: D6550004 03FE0B04 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000005A718: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005A720: 8C7E037E
	ds_load_b32 v55, v1 offset:24188                           // 00000005A724: D8D85E7C 37000001
	v_add_nc_u32_e32 v56, 0xffffb500, v18                      // 00000005A72C: 4A7024FF FFFFB500
	v_dual_mov_b32 v178, s27 :: v_dual_mov_b32 v171, s20       // 00000005A734: CA10001B B2AA0014
	v_dual_mov_b32 v177, s26 :: v_dual_mov_b32 v176, s25       // 00000005A73C: CA10001A B1B00019
	ds_load_b128 v[2:5], v56                                   // 00000005A744: DBFC0000 02000038
	v_mov_b32_e32 v174, s23                                    // 00000005A74C: 7F5C0217
	v_mov_b32_e32 v172, s21                                    // 00000005A750: 7F580215
	ds_load_b128 v[46:49], v56 offset:1552                     // 00000005A754: DBFC0610 2E000038
	ds_load_b128 v[155:158], v56 offset:2304                   // 00000005A75C: DBFC0900 9B000038
	ds_load_b128 v[167:170], v56 offset:3088                   // 00000005A764: DBFC0C10 A7000038
	ds_load_b128 v[159:162], v56 offset:2320                   // 00000005A76C: DBFC0910 9F000038
	ds_load_b128 v[163:166], v56 offset:3072                   // 00000005A774: DBFC0C00 A3000038
	ds_load_b128 v[179:182], v56 offset:3840                   // 00000005A77C: DBFC0F00 B3000038
	ds_load_b128 v[86:89], v56 offset:4624                     // 00000005A784: DBFC1210 56000038
	ds_load_b128 v[183:186], v56 offset:3856                   // 00000005A78C: DBFC0F10 B7000038
	ds_load_b128 v[82:85], v56 offset:4608                     // 00000005A794: DBFC1200 52000038
	s_add_i32 s54, s54, 16                                     // 00000005A79C: 81369036
	v_mov_b32_e32 v175, s24                                    // 00000005A7A0: 7F5E0218
	v_mov_b32_e32 v173, s22                                    // 00000005A7A4: 7F5A0216
	s_waitcnt lgkmcnt(10)                                      // 00000005A7A8: BF89FCA7
	v_readfirstlane_b32 s3, v55                                // 00000005A7AC: 7E060537
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v55                  // 00000005A7B0: 7C366EFF C2CE8ED0
	s_mul_f32 s3, s3, 0x3fb8aa3b                               // 00000005A7B8: A203FF03 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000005A7C0: BF8700CB
	s_xor_b32 s4, s3, 0x80000000                               // 00000005A7C4: 8D04FF03 80000000
	s_cmp_lg_u32 s12, s54                                      // 00000005A7CC: BF07360C
	v_fma_f32 v6, 0x3fb8aa3b, v55, s4                          // 00000005A7D0: D6130006 00126EFF 3FB8AA3B
	s_rndne_f32 s4, s3                                         // 00000005A7DC: BE846303
	v_fmac_f32_e32 v6, 0x32a5705f, v55                         // 00000005A7E0: 560C6EFF 32A5705F
	s_delay_alu instid0(SALU_CYCLE_2)                          // 00000005A7E8: BF87000A
	s_sub_f32 s3, s3, s4                                       // 00000005A7EC: A0830403
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_3)    // 00000005A7F0: BF870581
	v_add_f32_e32 v18, s3, v6                                  // 00000005A7F4: 06240C03
	ds_load_b128 v[6:9], v56 offset:16                         // 00000005A7F8: DBFC0010 06000038
	ds_load_b128 v[10:13], v56 offset:768                      // 00000005A800: DBFC0300 0A000038
	ds_load_b128 v[14:17], v56 offset:784                      // 00000005A808: DBFC0310 0E000038
	ds_load_b128 v[42:45], v56 offset:1536                     // 00000005A810: DBFC0600 2A000038
	s_cvt_i32_f32 s3, s4                                       // 00000005A818: BE836604
	v_exp_f32_e32 v18, v18                                     // 00000005A81C: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_2) // 00000005A820: BF870505
	.long 0xd71c0012                                           // 00000005A824: D71C0012
	v_cndmask_b32_e32 v0, v18, v3, vcc_lo                      // 00000005A828: 02000712
	s_waitcnt lgkmcnt(3)                                       // 00000005A82C: BF89FC37
	v_wmma_f32_16x16x16_f16 v[34:41], v[2:9], v[66:73], v[171:178]// 00000005A830: CC404022 1EAE8502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005A838: BF870122
	v_cndmask_b32_e32 v2, 0, v18, vcc_lo                       // 00000005A83C: 02042480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v55                  // 00000005A840: 7C3C6EFF 42B17218
	v_cndmask_b32_e32 v145, 0x7f800000, v2, vcc_lo             // 00000005A848: 032204FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005A850: BF870001
	v_fmac_f32_e32 v41, v54, v145                              // 00000005A854: 56532336
	s_waitcnt lgkmcnt(1)                                       // 00000005A858: BF89FC17
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[66:73], v[171:178]// 00000005A85C: CC40401A 1EAE850A
	v_fma_f32 v138, v138, v145, v35                            // 00000005A864: D613008A 048F238A
	v_fma_f32 v136, v136, v145, v37                            // 00000005A86C: D6130088 04972388
	v_fma_f32 v139, v139, v145, v34                            // 00000005A874: D613008B 048B238B
	s_delay_alu instid0(VALU_DEP_4)                            // 00000005A87C: BF870004
	v_fmac_f32_e32 v33, v53, v145                              // 00000005A880: 56432335
	s_waitcnt lgkmcnt(0)                                       // 00000005A884: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[66:73], v[171:178]// 00000005A888: CC404012 1EAE852A
	v_fma_f32 v137, v137, v145, v36                            // 00000005A890: D6130089 04932389
	v_fma_f32 v135, v135, v145, v38                            // 00000005A898: D6130087 049B2387
	v_fma_f32 v134, v134, v145, v39                            // 00000005A8A0: D6130086 049F2386
	s_delay_alu instid0(VALU_DEP_4)                            // 00000005A8A8: BF870004
	v_fmac_f32_e32 v25, v52, v145                              // 00000005A8AC: 56332334
	v_wmma_f32_16x16x16_f16 v[10:17], v[155:162], v[66:73], v[171:178]// 00000005A8B0: CC40400A 1EAE859B
	ds_load_b128 v[159:162], v56 offset:5392                   // 00000005A8B8: DBFC1510 9F000038
	ds_load_b128 v[155:158], v56 offset:5376                   // 00000005A8C0: DBFC1500 9B000038
	v_wmma_f32_16x16x16_f16 v[2:9], v[163:170], v[66:73], v[171:178]// 00000005A8C8: CC404002 1EAE85A3
	v_wmma_f32_16x16x16_f16 v[42:49], v[179:186], v[66:73], v[171:178]// 00000005A8D0: CC40402A 1EAE85B3
	v_fmac_f32_e32 v17, v51, v145                              // 00000005A8D8: 56232333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005A8DC: BF870223
	v_fmac_f32_e32 v9, v50, v145                               // 00000005A8E0: 56132332
	v_wmma_f32_16x16x16_f16 v[50:57], v[82:89], v[66:73], v[171:178]// 00000005A8E4: CC404032 1EAE8552
	v_fmac_f32_e32 v49, v58, v145                              // 00000005A8EC: 5663233A
	v_fma_f32 v133, v133, v145, v40                            // 00000005A8F0: D6130085 04A32385
	v_fma_f32 v132, v132, v145, v26                            // 00000005A8F8: D6130084 046B2384
	v_fma_f32 v131, v131, v145, v27                            // 00000005A900: D6130083 046F2383
	v_fma_f32 v130, v130, v145, v28                            // 00000005A908: D6130082 04732382
	v_fma_f32 v129, v129, v145, v29                            // 00000005A910: D6130081 04772381
	v_fma_f32 v128, v128, v145, v30                            // 00000005A918: D6130080 047B2380
	v_fma_f32 v127, v127, v145, v31                            // 00000005A920: D613007F 047F237F
	v_fma_f32 v126, v126, v145, v32                            // 00000005A928: D613007E 0483237E
	v_fma_f32 v125, v125, v145, v18                            // 00000005A930: D613007D 044B237D
	v_fma_f32 v124, v124, v145, v19                            // 00000005A938: D613007C 044F237C
	s_waitcnt lgkmcnt(0)                                       // 00000005A940: BF89FC07
	v_wmma_f32_16x16x16_f16 v[58:65], v[155:162], v[66:73], v[171:178]// 00000005A944: CC40403A 1EAE859B
	v_fma_f32 v123, v123, v145, v20                            // 00000005A94C: D613007B 0453237B
	v_fma_f32 v122, v122, v145, v21                            // 00000005A954: D613007A 0457237A
	v_fma_f32 v121, v121, v145, v22                            // 00000005A95C: D6130079 045B2379
	v_fma_f32 v120, v120, v145, v23                            // 00000005A964: D6130078 045F2378
	v_fma_f32 v119, v119, v145, v24                            // 00000005A96C: D6130077 04632377
	v_fma_f32 v118, v118, v145, v10                            // 00000005A974: D6130076 042B2376
	v_fma_f32 v117, v117, v145, v11                            // 00000005A97C: D6130075 042F2375
	v_fma_f32 v116, v116, v145, v12                            // 00000005A984: D6130074 04332374
	v_fma_f32 v115, v115, v145, v13                            // 00000005A98C: D6130073 04372373
	v_fma_f32 v114, v114, v145, v14                            // 00000005A994: D6130072 043B2372
	v_fma_f32 v113, v113, v145, v15                            // 00000005A99C: D6130071 043F2371
	v_fma_f32 v112, v112, v145, v16                            // 00000005A9A4: D6130070 04432370
	v_fma_f32 v111, v111, v145, v2                             // 00000005A9AC: D613006F 040B236F
	v_fma_f32 v110, v110, v145, v3                             // 00000005A9B4: D613006E 040F236E
	v_fma_f32 v109, v109, v145, v4                             // 00000005A9BC: D613006D 0413236D
	v_fma_f32 v108, v108, v145, v5                             // 00000005A9C4: D613006C 0417236C
	v_fma_f32 v107, v107, v145, v6                             // 00000005A9CC: D613006B 041B236B
	v_fma_f32 v106, v106, v145, v7                             // 00000005A9D4: D613006A 041F236A
	v_fma_f32 v105, v105, v145, v8                             // 00000005A9DC: D6130069 04232369
	v_fma_f32 v104, v104, v145, v42                            // 00000005A9E4: D6130068 04AB2368
	v_fma_f32 v103, v103, v145, v43                            // 00000005A9EC: D6130067 04AF2367
	v_fma_f32 v102, v102, v145, v44                            // 00000005A9F4: D6130066 04B32366
	v_fma_f32 v101, v101, v145, v45                            // 00000005A9FC: D6130065 04B72365
	v_fma_f32 v100, v100, v145, v46                            // 00000005AA04: D6130064 04BB2364
	v_fma_f32 v99, v99, v145, v47                              // 00000005AA0C: D6130063 04BF2363
	v_fma_f32 v98, v98, v145, v48                              // 00000005AA14: D6130062 04C32362
	v_fma_f32 v97, v97, v145, v50                              // 00000005AA1C: D6130061 04CB2361
	v_fma_f32 v96, v96, v145, v51                              // 00000005AA24: D6130060 04CF2360
	v_fma_f32 v95, v95, v145, v52                              // 00000005AA2C: D613005F 04D3235F
	v_fma_f32 v94, v94, v145, v53                              // 00000005AA34: D613005E 04D7235E
	v_fma_f32 v93, v93, v145, v54                              // 00000005AA3C: D613005D 04DB235D
	v_fma_f32 v92, v92, v145, v55                              // 00000005AA44: D613005C 04DF235C
	v_fma_f32 v91, v91, v145, v56                              // 00000005AA4C: D613005B 04E3235B
	v_dual_fmac_f32 v57, v152, v145 :: v_dual_mul_f32 v4, 0x3b800000, v135// 00000005AA54: C8072398 39050EFF 3B800000
	v_fma_f32 v90, v90, v145, v58                              // 00000005AA60: D613005A 04EB235A
	v_fma_f32 v141, v141, v145, v59                            // 00000005AA68: D613008D 04EF238D
	v_fma_f32 v150, v150, v145, v60                            // 00000005AA70: D6130096 04F32396
	v_fma_f32 v142, v142, v145, v61                            // 00000005AA78: D613008E 04F7238E
	v_fma_f32 v191, v191, v145, v62                            // 00000005AA80: D61300BF 04FB23BF
	v_fma_f32 v189, v189, v145, v63                            // 00000005AA88: D61300BD 04FF23BD
	v_fma_f32 v190, v190, v145, v64                            // 00000005AA90: D61300BE 050323BE
	v_dual_fmac_f32 v65, v151, v145 :: v_dual_mul_f32 v68, 0x3b800000, v131// 00000005AA98: C8072397 414506FF 3B800000
	v_lshl_add_u32 v2, v154, 7, v153                           // 00000005AAA4: D6460002 06650F9A
	v_dual_mul_f32 v69, 0x3b800000, v139 :: v_dual_mul_f32 v152, 0x3b800000, v41// 00000005AAAC: C8C716FF 459852FF 3B800000
	v_dual_mul_f32 v70, 0x3b800000, v138 :: v_dual_mul_f32 v71, 0x3b800000, v137// 00000005AAB8: C8C714FF 464712FF 3B800000
	v_mul_f32_e32 v62, 0x3b800000, v130                        // 00000005AAC4: 107D04FF 3B800000
	v_dual_mul_f32 v72, 0x3b800000, v136 :: v_dual_mul_f32 v73, 0x3b800000, v134// 00000005AACC: C8C710FF 48490CFF 3B800000
	v_dual_mul_f32 v6, 0x3b800000, v128 :: v_dual_mul_f32 v151, 0x3b800000, v133// 00000005AAD8: C8C700FF 06970AFF 3B800000
	v_dual_mul_f32 v64, 0x3b800000, v127 :: v_dual_mul_f32 v5, 0x3b800000, v132// 00000005AAE4: C8C6FEFF 400508FF 3B800000
	v_dual_mul_f32 v66, 0x3b800000, v126 :: v_dual_mul_f32 v63, 0x3b800000, v129// 00000005AAF0: C8C6FCFF 423F02FF 3B800000
	v_dual_mul_f32 v60, 0x3b800000, v123 :: v_dual_mul_f32 v67, 0x3b800000, v33// 00000005AAFC: C8C6F6FF 3C4242FF 3B800000
	v_dual_mul_f32 v52, 0x3b800000, v120 :: v_dual_mul_f32 v7, 0x3b800000, v125// 00000005AB08: C8C6F0FF 3406FAFF 3B800000
	v_dual_mul_f32 v10, 0x3b800000, v118 :: v_dual_mul_f32 v59, 0x3b800000, v124// 00000005AB14: C8C6ECFF 0A3AF8FF 3B800000
	v_dual_mul_f32 v8, 0x3b800000, v121 :: v_dual_mul_f32 v61, 0x3b800000, v122// 00000005AB20: C8C6F2FF 083CF4FF 3B800000
	v_dual_mul_f32 v54, 0x3b800000, v25 :: v_dual_mul_f32 v53, 0x3b800000, v119// 00000005AB2C: C8C632FF 3634EEFF 3B800000
	v_dual_mul_f32 v56, 0x3b800000, v116 :: v_dual_mul_f32 v55, 0x3b800000, v117// 00000005AB38: C8C6E8FF 3836EAFF 3B800000
	v_dual_mul_f32 v58, 0x3b800000, v115 :: v_dual_mul_f32 v11, 0x3b800000, v114// 00000005AB44: C8C6E6FF 3A0AE4FF 3B800000
	v_dual_mul_f32 v50, 0x3b800000, v113 :: v_dual_mul_f32 v51, 0x3b800000, v112// 00000005AB50: C8C6E2FF 3232E0FF 3B800000
	v_mul_f32_e32 v40, 0x3b800000, v17                         // 00000005AB5C: 105022FF 3B800000
	v_dual_mul_f32 v12, 0x3b800000, v111 :: v_dual_mul_f32 v43, 0x3b800000, v110// 00000005AB64: C8C6DEFF 0C2ADCFF 3B800000
	v_dual_mul_f32 v44, 0x3b800000, v109 :: v_dual_mul_f32 v45, 0x3b800000, v108// 00000005AB70: C8C6DAFF 2C2CD8FF 3B800000
	v_dual_mul_f32 v14, 0x3b800000, v107 :: v_dual_mul_f32 v47, 0x3b800000, v105// 00000005AB7C: C8C6D6FF 0E2ED2FF 3B800000
	v_dual_mul_f32 v46, 0x3b800000, v106 :: v_dual_mul_f32 v15, 0x3b800000, v104// 00000005AB88: C8C6D4FF 2E0ED0FF 3B800000
	v_dual_mul_f32 v48, 0x3b800000, v9 :: v_dual_mul_f32 v35, 0x3b800000, v102// 00000005AB94: C8C612FF 3022CCFF 3B800000
	v_dual_mul_f32 v42, 0x3b800000, v103 :: v_dual_mul_f32 v27, 0x3b800000, v100// 00000005ABA0: C8C6CEFF 2A1AC8FF 3B800000
	v_dual_mul_f32 v36, 0x3b800000, v101 :: v_dual_mul_f32 v37, 0x3b800000, v99// 00000005ABAC: C8C6CAFF 2424C6FF 3B800000
	v_dual_mul_f32 v38, 0x3b800000, v98 :: v_dual_mul_f32 v39, 0x3b800000, v49// 00000005ABB8: C8C6C4FF 262662FF 3B800000
	v_dual_mul_f32 v28, 0x3b800000, v97 :: v_dual_mul_f32 v31, 0x3b800000, v96// 00000005ABC4: C8C6C2FF 1C1EC0FF 3B800000
	v_dual_mul_f32 v32, 0x3b800000, v95 :: v_dual_mul_f32 v29, 0x3b800000, v93// 00000005ABD0: C8C6BEFF 201CBAFF 3B800000
	v_dual_mul_f32 v34, 0x3b800000, v94 :: v_dual_mul_f32 v21, 0x3b800000, v91// 00000005ABDC: C8C6BCFF 2214B6FF 3B800000
	v_dual_mul_f32 v20, 0x3b800000, v92 :: v_dual_mul_f32 v23, 0x3b800000, v141// 00000005ABE8: C8C6B8FF 14171AFF 3B800000
	v_dual_mul_f32 v22, 0x3b800000, v57 :: v_dual_mul_f32 v19, 0x3b800000, v190// 00000005ABF4: C8C672FF 16137CFF 3B800000
	v_dual_mul_f32 v30, 0x3b800000, v90 :: v_dual_mul_f32 v13, 0x3b800000, v65// 00000005AC00: C8C6B4FF 1E0C82FF 3B800000
	v_mul_f32_e32 v24, 0x3b800000, v150                        // 00000005AC0C: 10312CFF 3B800000
	v_mul_f32_e32 v26, 0x3b800000, v142                        // 00000005AC14: 10351CFF 3B800000
	v_mul_f32_e32 v16, 0x3b800000, v191                        // 00000005AC1C: 10217EFF 3B800000
	v_mul_f32_e32 v18, 0x3b800000, v189                        // 00000005AC24: 10257AFF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 00000005AC2C: BF89FC07
	s_barrier                                                  // 00000005AC30: BFBD0000
	s_cbranch_scc0 5                                           // 00000005AC34: BFA10005 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x444c>
	s_cmp_lg_u32 s13, s54                                      // 00000005AC38: BF07360D
	s_cbranch_scc0 273                                         // 00000005AC3C: BFA10111 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4884>
	s_cmp_lg_u32 s14, s54                                      // 00000005AC40: BF07360E
	s_cbranch_scc1 61745                                       // 00000005AC44: BFA2F131 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	s_branch 540                                               // 00000005AC48: BFA0021C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4cbc>
	v_mov_b32_e32 v82, v2                                      // 00000005AC4C: 7EA40302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AC50: BF870091
	v_ashrrev_i32_e32 v83, 31, v82                             // 00000005AC54: 34A6A49F
	.long 0xd73c0052                                           // 00000005AC58: D73C0052
	v_cndmask_b32_e32 v1, 2, v82, vcc_lo                       // 00000005AC5C: 0202A482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AC60: BF870091
	.long 0xd7006a52                                           // 00000005AC64: D7006A52
	v_cndmask_b32_e32 v1, s16, v82, vcc_lo                     // 00000005AC68: 0202A410
	v_add_co_ci_u32_e64 v83, null, s17, v83, vcc_lo            // 00000005AC6C: D5207C53 01AAA611
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005AC74: BF870092
	.long 0xd7006a54                                           // 00000005AC78: D7006A54
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 00000005AC7C: 0202A4FF 00001000
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000005AC84: D5207C55 01AAA680
	.long 0xd7006a56                                           // 00000005AC8C: D7006A56
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000005AC90: 0201FF52
	.long 0x00002000                                           // 00000005AC94: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005AC98: BF8700A1
	v_add_co_ci_u32_e64 v87, null, 0, v83, vcc_lo              // 00000005AC9C: D5207C57 01AAA680
	.long 0xd7006a58                                           // 00000005ACA4: D7006A58
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 00000005ACA8: 0202A4FF 00002000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000005ACB0: D5207C59 01AAA680
	s_clause 0x7                                               // 00000005ACB8: BF850007
	global_store_b32 v[82:83], v69, off                        // 00000005ACBC: DC6A0000 007C4552
	global_store_b32 v[82:83], v70, off offset:1024            // 00000005ACC4: DC6A0400 007C4652
	global_store_b32 v[82:83], v71, off offset:2048            // 00000005ACCC: DC6A0800 007C4752
	global_store_b32 v[82:83], v72, off offset:3072            // 00000005ACD4: DC6A0C00 007C4852
	global_store_b32 v[84:85], v73, off offset:1024            // 00000005ACDC: DC6A0400 007C4954
	global_store_b32 v[84:85], v151, off offset:2048           // 00000005ACE4: DC6A0800 007C9754
	global_store_b32 v[84:85], v152, off offset:3072           // 00000005ACEC: DC6A0C00 007C9854
	global_store_b32 v[88:89], v68, off offset:1024            // 00000005ACF4: DC6A0400 007C4458
	.long 0xd7006a54                                           // 00000005ACFC: D7006A54
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 00000005AD00: 0202A4FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005AD08: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000005AD0C: D5207C55 01AAA680
	.long 0xd7006a99                                           // 00000005AD14: D7006A99
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000005AD18: 0201FF52
	.long 0x00004000                                           // 00000005AD1C: 00004000
	v_add_co_ci_u32_e64 v154, null, 0, v83, vcc_lo             // 00000005AD20: D5207C9A 01AAA680
	.long 0xd7006a9b                                           // 00000005AD28: D7006A9B
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 00000005AD2C: 0202A4FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005AD34: BF870001
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000005AD38: D5207C9C 01AAA680
	s_clause 0x7                                               // 00000005AD40: BF850007
	global_store_b32 v[88:89], v62, off offset:2048            // 00000005AD44: DC6A0800 007C3E58
	global_store_b32 v[88:89], v63, off offset:3072            // 00000005AD4C: DC6A0C00 007C3F58
	global_store_b32 v[84:85], v64, off offset:1024            // 00000005AD54: DC6A0400 007C4054
	global_store_b32 v[84:85], v66, off offset:2048            // 00000005AD5C: DC6A0800 007C4254
	global_store_b32 v[84:85], v67, off offset:3072            // 00000005AD64: DC6A0C00 007C4354
	global_store_b32 v[155:156], v59, off offset:1024          // 00000005AD6C: DC6A0400 007C3B9B
	global_store_b32 v[155:156], v60, off offset:2048          // 00000005AD74: DC6A0800 007C3C9B
	global_store_b32 v[155:156], v61, off offset:3072          // 00000005AD7C: DC6A0C00 007C3D9B
	.long 0xd7006a54                                           // 00000005AD84: D7006A54
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 00000005AD88: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005AD90: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000005AD94: D5207C55 01AAA680
	.long 0xd7006a58                                           // 00000005AD9C: D7006A58
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000005ADA0: 0201FF52
	.long 0x00006000                                           // 00000005ADA4: 00006000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000005ADA8: D5207C59 01AAA680
	.long 0xd7006a9b                                           // 00000005ADB0: D7006A9B
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 00000005ADB4: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005ADBC: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000005ADC0: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 00000005ADC8: D7006A9D
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 00000005ADCC: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000005ADD4: D5207C9E 01AAA680
	.long 0xd7006a9f                                           // 00000005ADDC: D7006A9F
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000005ADE0: 0201FF52
	.long 0x00008000                                           // 00000005ADE4: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005ADE8: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v83, vcc_lo             // 00000005ADEC: D5207CA0 01AAA680
	s_clause 0x7                                               // 00000005ADF4: BF850007
	global_store_b32 v[84:85], v52, off offset:1024            // 00000005ADF8: DC6A0400 007C3454
	global_store_b32 v[84:85], v53, off offset:2048            // 00000005AE00: DC6A0800 007C3554
	global_store_b32 v[84:85], v54, off offset:3072            // 00000005AE08: DC6A0C00 007C3654
	global_store_b32 v[155:156], v55, off offset:1024          // 00000005AE10: DC6A0400 007C379B
	global_store_b32 v[155:156], v56, off offset:2048          // 00000005AE18: DC6A0800 007C389B
	global_store_b32 v[155:156], v58, off offset:3072          // 00000005AE20: DC6A0C00 007C3A9B
	global_store_b32 v[157:158], v50, off offset:1024          // 00000005AE28: DC6A0400 007C329D
	global_store_b32 v[157:158], v51, off offset:2048          // 00000005AE30: DC6A0800 007C339D
	.long 0xd7006a54                                           // 00000005AE38: D7006A54
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 00000005AE3C: 0202A4FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005AE44: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000005AE48: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 00000005AE50: D7006A9B
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 00000005AE54: 0202A4FF 00009000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000005AE5C: D5207C9C 01AAA680
	.long 0xd7006aa1                                           // 00000005AE64: D7006AA1
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000005AE68: 0201FF52
	.long 0x0000a000                                           // 00000005AE6C: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005AE70: BF8700A1
	v_add_co_ci_u32_e64 v162, null, 0, v83, vcc_lo             // 00000005AE74: D5207CA2 01AAA680
	.long 0xd7006aa3                                           // 00000005AE7C: D7006AA3
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 00000005AE80: 0202A4FF 0000A000
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000005AE88: D5207CA4 01AAA680
	s_clause 0x7                                               // 00000005AE90: BF850007
	global_store_b32 v[157:158], v40, off offset:3072          // 00000005AE94: DC6A0C00 007C289D
	global_store_b32 v[84:85], v43, off offset:1024            // 00000005AE9C: DC6A0400 007C2B54
	global_store_b32 v[84:85], v44, off offset:2048            // 00000005AEA4: DC6A0800 007C2C54
	global_store_b32 v[84:85], v45, off offset:3072            // 00000005AEAC: DC6A0C00 007C2D54
	global_store_b32 v[155:156], v46, off offset:1024          // 00000005AEB4: DC6A0400 007C2E9B
	global_store_b32 v[155:156], v47, off offset:2048          // 00000005AEBC: DC6A0800 007C2F9B
	global_store_b32 v[155:156], v48, off offset:3072          // 00000005AEC4: DC6A0C00 007C309B
	global_store_b32 v[163:164], v42, off offset:1024          // 00000005AECC: DC6A0400 007C2AA3
	.long 0xd7006a54                                           // 00000005AED4: D7006A54
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 00000005AED8: 0202A4FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005AEE0: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000005AEE4: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 00000005AEEC: D7006A9B
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000005AEF0: 0201FF52
	.long 0x0000c000                                           // 00000005AEF4: 0000C000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000005AEF8: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 00000005AF00: D7006A9D
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 00000005AF04: 0202A4FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005AF0C: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000005AF10: D5207C9E 01AAA680
	s_clause 0x7                                               // 00000005AF18: BF850007
	global_store_b32 v[163:164], v35, off offset:2048          // 00000005AF1C: DC6A0800 007C23A3
	global_store_b32 v[163:164], v36, off offset:3072          // 00000005AF24: DC6A0C00 007C24A3
	global_store_b32 v[84:85], v37, off offset:1024            // 00000005AF2C: DC6A0400 007C2554
	global_store_b32 v[84:85], v38, off offset:2048            // 00000005AF34: DC6A0800 007C2654
	global_store_b32 v[84:85], v39, off offset:3072            // 00000005AF3C: DC6A0C00 007C2754
	global_store_b32 v[157:158], v31, off offset:1024          // 00000005AF44: DC6A0400 007C1F9D
	global_store_b32 v[157:158], v32, off offset:2048          // 00000005AF4C: DC6A0800 007C209D
	global_store_b32 v[157:158], v34, off offset:3072          // 00000005AF54: DC6A0C00 007C229D
	.long 0xd7006a54                                           // 00000005AF5C: D7006A54
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 00000005AF60: 0202A4FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005AF68: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000005AF6C: D5207C55 01AAA680
	.long 0xd7006a9d                                           // 00000005AF74: D7006A9D
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000005AF78: 0201FF52
	.long 0x0000e000                                           // 00000005AF7C: 0000E000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000005AF80: D5207C9E 01AAA680
	.long 0xd7006aa3                                           // 00000005AF88: D7006AA3
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 00000005AF8C: 0202A4FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005AF94: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000005AF98: D5207CA4 01AAA680
	.long 0xd7006a52                                           // 00000005AFA0: D7006A52
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 00000005AFA4: 0202A4FF 0000F000
	s_clause 0x7                                               // 00000005AFAC: BF850007
	global_store_b32 v[159:160], v11, off offset:-4096         // 00000005AFB0: DC6A1000 007C0B9F
	global_store_b32 v[159:160], v12, off                      // 00000005AFB8: DC6A0000 007C0C9F
	global_store_b32 v[161:162], v14, off offset:-4096         // 00000005AFC0: DC6A1000 007C0EA1
	global_store_b32 v[161:162], v15, off                      // 00000005AFC8: DC6A0000 007C0FA1
	global_store_b32 v[155:156], v27, off offset:-4096         // 00000005AFD0: DC6A1000 007C1B9B
	global_store_b32 v[155:156], v28, off                      // 00000005AFD8: DC6A0000 007C1C9B
	global_store_b32 v[157:158], v29, off offset:-4096         // 00000005AFE0: DC6A1000 007C1D9D
	global_store_b32 v[157:158], v30, off                      // 00000005AFE8: DC6A0000 007C1E9D
	v_add_co_ci_u32_e64 v83, null, 0, v83, vcc_lo              // 00000005AFF0: D5207C53 01AAA680
	s_clause 0xf                                               // 00000005AFF8: BF85000F
	global_store_b32 v[84:85], v20, off offset:1024            // 00000005AFFC: DC6A0400 007C1454
	global_store_b32 v[84:85], v21, off offset:2048            // 00000005B004: DC6A0800 007C1554
	global_store_b32 v[84:85], v22, off offset:3072            // 00000005B00C: DC6A0C00 007C1654
	global_store_b32 v[163:164], v23, off offset:1024          // 00000005B014: DC6A0400 007C17A3
	global_store_b32 v[163:164], v24, off offset:2048          // 00000005B01C: DC6A0800 007C18A3
	global_store_b32 v[163:164], v26, off offset:3072          // 00000005B024: DC6A0C00 007C1AA3
	global_store_b32 v[82:83], v16, off                        // 00000005B02C: DC6A0000 007C1052
	global_store_b32 v[82:83], v18, off offset:1024            // 00000005B034: DC6A0400 007C1252
	global_store_b32 v[82:83], v19, off offset:2048            // 00000005B03C: DC6A0800 007C1352
	global_store_b32 v[86:87], v4, off offset:-4096            // 00000005B044: DC6A1000 007C0456
	global_store_b32 v[86:87], v5, off                         // 00000005B04C: DC6A0000 007C0556
	global_store_b32 v[153:154], v6, off offset:-4096          // 00000005B054: DC6A1000 007C0699
	global_store_b32 v[153:154], v7, off                       // 00000005B05C: DC6A0000 007C0799
	global_store_b32 v[88:89], v8, off offset:-4096            // 00000005B064: DC6A1000 007C0858
	global_store_b32 v[88:89], v10, off                        // 00000005B06C: DC6A0000 007C0A58
	global_store_b32 v[82:83], v13, off offset:3072            // 00000005B074: DC6A0C00 007C0D52
	s_cmp_lg_u32 s13, s54                                      // 00000005B07C: BF07360D
	s_cbranch_scc1 65263                                       // 00000005B080: BFA2FEEF <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4440>
	v_mov_b32_e32 v82, v2                                      // 00000005B084: 7EA40302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B088: BF870091
	v_ashrrev_i32_e32 v83, 31, v82                             // 00000005B08C: 34A6A49F
	.long 0xd73c0052                                           // 00000005B090: D73C0052
	v_cndmask_b32_e32 v1, 2, v82, vcc_lo                       // 00000005B094: 0202A482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B098: BF870091
	.long 0xd7006a52                                           // 00000005B09C: D7006A52
	v_cndmask_b32_e32 v1, s18, v82, vcc_lo                     // 00000005B0A0: 0202A412
	v_add_co_ci_u32_e64 v83, null, s19, v83, vcc_lo            // 00000005B0A4: D5207C53 01AAA613
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B0AC: BF870092
	.long 0xd7006a54                                           // 00000005B0B0: D7006A54
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 00000005B0B4: 0202A4FF 00001000
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000005B0BC: D5207C55 01AAA680
	.long 0xd7006a56                                           // 00000005B0C4: D7006A56
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000005B0C8: 0201FF52
	.long 0x00002000                                           // 00000005B0CC: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B0D0: BF8700A1
	v_add_co_ci_u32_e64 v87, null, 0, v83, vcc_lo              // 00000005B0D4: D5207C57 01AAA680
	.long 0xd7006a58                                           // 00000005B0DC: D7006A58
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 00000005B0E0: 0202A4FF 00002000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000005B0E8: D5207C59 01AAA680
	s_clause 0x7                                               // 00000005B0F0: BF850007
	global_store_b32 v[82:83], v69, off                        // 00000005B0F4: DC6A0000 007C4552
	global_store_b32 v[82:83], v70, off offset:1024            // 00000005B0FC: DC6A0400 007C4652
	global_store_b32 v[82:83], v71, off offset:2048            // 00000005B104: DC6A0800 007C4752
	global_store_b32 v[82:83], v72, off offset:3072            // 00000005B10C: DC6A0C00 007C4852
	global_store_b32 v[84:85], v73, off offset:1024            // 00000005B114: DC6A0400 007C4954
	global_store_b32 v[84:85], v151, off offset:2048           // 00000005B11C: DC6A0800 007C9754
	global_store_b32 v[84:85], v152, off offset:3072           // 00000005B124: DC6A0C00 007C9854
	global_store_b32 v[88:89], v68, off offset:1024            // 00000005B12C: DC6A0400 007C4458
	.long 0xd7006a54                                           // 00000005B134: D7006A54
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 00000005B138: 0202A4FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B140: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000005B144: D5207C55 01AAA680
	.long 0xd7006a99                                           // 00000005B14C: D7006A99
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000005B150: 0201FF52
	.long 0x00004000                                           // 00000005B154: 00004000
	v_add_co_ci_u32_e64 v154, null, 0, v83, vcc_lo             // 00000005B158: D5207C9A 01AAA680
	.long 0xd7006a9b                                           // 00000005B160: D7006A9B
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 00000005B164: 0202A4FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005B16C: BF870001
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000005B170: D5207C9C 01AAA680
	s_clause 0x7                                               // 00000005B178: BF850007
	global_store_b32 v[88:89], v62, off offset:2048            // 00000005B17C: DC6A0800 007C3E58
	global_store_b32 v[88:89], v63, off offset:3072            // 00000005B184: DC6A0C00 007C3F58
	global_store_b32 v[84:85], v64, off offset:1024            // 00000005B18C: DC6A0400 007C4054
	global_store_b32 v[84:85], v66, off offset:2048            // 00000005B194: DC6A0800 007C4254
	global_store_b32 v[84:85], v67, off offset:3072            // 00000005B19C: DC6A0C00 007C4354
	global_store_b32 v[155:156], v59, off offset:1024          // 00000005B1A4: DC6A0400 007C3B9B
	global_store_b32 v[155:156], v60, off offset:2048          // 00000005B1AC: DC6A0800 007C3C9B
	global_store_b32 v[155:156], v61, off offset:3072          // 00000005B1B4: DC6A0C00 007C3D9B
	.long 0xd7006a54                                           // 00000005B1BC: D7006A54
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 00000005B1C0: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B1C8: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000005B1CC: D5207C55 01AAA680
	.long 0xd7006a58                                           // 00000005B1D4: D7006A58
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000005B1D8: 0201FF52
	.long 0x00006000                                           // 00000005B1DC: 00006000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000005B1E0: D5207C59 01AAA680
	.long 0xd7006a9b                                           // 00000005B1E8: D7006A9B
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 00000005B1EC: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B1F4: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000005B1F8: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 00000005B200: D7006A9D
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 00000005B204: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000005B20C: D5207C9E 01AAA680
	.long 0xd7006a9f                                           // 00000005B214: D7006A9F
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000005B218: 0201FF52
	.long 0x00008000                                           // 00000005B21C: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005B220: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v83, vcc_lo             // 00000005B224: D5207CA0 01AAA680
	s_clause 0x7                                               // 00000005B22C: BF850007
	global_store_b32 v[84:85], v52, off offset:1024            // 00000005B230: DC6A0400 007C3454
	global_store_b32 v[84:85], v53, off offset:2048            // 00000005B238: DC6A0800 007C3554
	global_store_b32 v[84:85], v54, off offset:3072            // 00000005B240: DC6A0C00 007C3654
	global_store_b32 v[155:156], v55, off offset:1024          // 00000005B248: DC6A0400 007C379B
	global_store_b32 v[155:156], v56, off offset:2048          // 00000005B250: DC6A0800 007C389B
	global_store_b32 v[155:156], v58, off offset:3072          // 00000005B258: DC6A0C00 007C3A9B
	global_store_b32 v[157:158], v50, off offset:1024          // 00000005B260: DC6A0400 007C329D
	global_store_b32 v[157:158], v51, off offset:2048          // 00000005B268: DC6A0800 007C339D
	.long 0xd7006a54                                           // 00000005B270: D7006A54
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 00000005B274: 0202A4FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B27C: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000005B280: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 00000005B288: D7006A9B
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 00000005B28C: 0202A4FF 00009000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000005B294: D5207C9C 01AAA680
	.long 0xd7006aa1                                           // 00000005B29C: D7006AA1
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000005B2A0: 0201FF52
	.long 0x0000a000                                           // 00000005B2A4: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B2A8: BF8700A1
	v_add_co_ci_u32_e64 v162, null, 0, v83, vcc_lo             // 00000005B2AC: D5207CA2 01AAA680
	.long 0xd7006aa3                                           // 00000005B2B4: D7006AA3
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 00000005B2B8: 0202A4FF 0000A000
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000005B2C0: D5207CA4 01AAA680
	s_clause 0x7                                               // 00000005B2C8: BF850007
	global_store_b32 v[157:158], v40, off offset:3072          // 00000005B2CC: DC6A0C00 007C289D
	global_store_b32 v[84:85], v43, off offset:1024            // 00000005B2D4: DC6A0400 007C2B54
	global_store_b32 v[84:85], v44, off offset:2048            // 00000005B2DC: DC6A0800 007C2C54
	global_store_b32 v[84:85], v45, off offset:3072            // 00000005B2E4: DC6A0C00 007C2D54
	global_store_b32 v[155:156], v46, off offset:1024          // 00000005B2EC: DC6A0400 007C2E9B
	global_store_b32 v[155:156], v47, off offset:2048          // 00000005B2F4: DC6A0800 007C2F9B
	global_store_b32 v[155:156], v48, off offset:3072          // 00000005B2FC: DC6A0C00 007C309B
	global_store_b32 v[163:164], v42, off offset:1024          // 00000005B304: DC6A0400 007C2AA3
	.long 0xd7006a54                                           // 00000005B30C: D7006A54
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 00000005B310: 0202A4FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B318: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000005B31C: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 00000005B324: D7006A9B
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000005B328: 0201FF52
	.long 0x0000c000                                           // 00000005B32C: 0000C000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000005B330: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 00000005B338: D7006A9D
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 00000005B33C: 0202A4FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005B344: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000005B348: D5207C9E 01AAA680
	s_clause 0x7                                               // 00000005B350: BF850007
	global_store_b32 v[163:164], v35, off offset:2048          // 00000005B354: DC6A0800 007C23A3
	global_store_b32 v[163:164], v36, off offset:3072          // 00000005B35C: DC6A0C00 007C24A3
	global_store_b32 v[84:85], v37, off offset:1024            // 00000005B364: DC6A0400 007C2554
	global_store_b32 v[84:85], v38, off offset:2048            // 00000005B36C: DC6A0800 007C2654
	global_store_b32 v[84:85], v39, off offset:3072            // 00000005B374: DC6A0C00 007C2754
	global_store_b32 v[157:158], v31, off offset:1024          // 00000005B37C: DC6A0400 007C1F9D
	global_store_b32 v[157:158], v32, off offset:2048          // 00000005B384: DC6A0800 007C209D
	global_store_b32 v[157:158], v34, off offset:3072          // 00000005B38C: DC6A0C00 007C229D
	.long 0xd7006a54                                           // 00000005B394: D7006A54
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 00000005B398: 0202A4FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B3A0: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000005B3A4: D5207C55 01AAA680
	.long 0xd7006a9d                                           // 00000005B3AC: D7006A9D
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000005B3B0: 0201FF52
	.long 0x0000e000                                           // 00000005B3B4: 0000E000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000005B3B8: D5207C9E 01AAA680
	.long 0xd7006aa3                                           // 00000005B3C0: D7006AA3
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 00000005B3C4: 0202A4FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005B3CC: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000005B3D0: D5207CA4 01AAA680
	.long 0xd7006a52                                           // 00000005B3D8: D7006A52
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 00000005B3DC: 0202A4FF 0000F000
	s_clause 0x7                                               // 00000005B3E4: BF850007
	global_store_b32 v[159:160], v11, off offset:-4096         // 00000005B3E8: DC6A1000 007C0B9F
	global_store_b32 v[159:160], v12, off                      // 00000005B3F0: DC6A0000 007C0C9F
	global_store_b32 v[161:162], v14, off offset:-4096         // 00000005B3F8: DC6A1000 007C0EA1
	global_store_b32 v[161:162], v15, off                      // 00000005B400: DC6A0000 007C0FA1
	global_store_b32 v[155:156], v27, off offset:-4096         // 00000005B408: DC6A1000 007C1B9B
	global_store_b32 v[155:156], v28, off                      // 00000005B410: DC6A0000 007C1C9B
	global_store_b32 v[157:158], v29, off offset:-4096         // 00000005B418: DC6A1000 007C1D9D
	global_store_b32 v[157:158], v30, off                      // 00000005B420: DC6A0000 007C1E9D
	v_add_co_ci_u32_e64 v83, null, 0, v83, vcc_lo              // 00000005B428: D5207C53 01AAA680
	s_clause 0xf                                               // 00000005B430: BF85000F
	global_store_b32 v[84:85], v20, off offset:1024            // 00000005B434: DC6A0400 007C1454
	global_store_b32 v[84:85], v21, off offset:2048            // 00000005B43C: DC6A0800 007C1554
	global_store_b32 v[84:85], v22, off offset:3072            // 00000005B444: DC6A0C00 007C1654
	global_store_b32 v[163:164], v23, off offset:1024          // 00000005B44C: DC6A0400 007C17A3
	global_store_b32 v[163:164], v24, off offset:2048          // 00000005B454: DC6A0800 007C18A3
	global_store_b32 v[163:164], v26, off offset:3072          // 00000005B45C: DC6A0C00 007C1AA3
	global_store_b32 v[82:83], v16, off                        // 00000005B464: DC6A0000 007C1052
	global_store_b32 v[82:83], v18, off offset:1024            // 00000005B46C: DC6A0400 007C1252
	global_store_b32 v[82:83], v19, off offset:2048            // 00000005B474: DC6A0800 007C1352
	global_store_b32 v[86:87], v4, off offset:-4096            // 00000005B47C: DC6A1000 007C0456
	global_store_b32 v[86:87], v5, off                         // 00000005B484: DC6A0000 007C0556
	global_store_b32 v[153:154], v6, off offset:-4096          // 00000005B48C: DC6A1000 007C0699
	global_store_b32 v[153:154], v7, off                       // 00000005B494: DC6A0000 007C0799
	global_store_b32 v[88:89], v8, off offset:-4096            // 00000005B49C: DC6A1000 007C0858
	global_store_b32 v[88:89], v10, off                        // 00000005B4A4: DC6A0000 007C0A58
	global_store_b32 v[82:83], v13, off offset:3072            // 00000005B4AC: DC6A0C00 007C0D52
	s_cmp_lg_u32 s14, s54                                      // 00000005B4B4: BF07360E
	s_cbranch_scc1 61204                                       // 00000005B4B8: BFA2EF14 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000005B4BC: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005B4C0: BF870091
	.long 0xd73c0002                                           // 00000005B4C4: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 00000005B4C8: 02020482
	.long 0xd7006a02                                           // 00000005B4CC: D7006A02
	v_cndmask_b32_e32 v1, s47, v2, vcc_lo                      // 00000005B4D0: 0202042F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005B4D4: BF870111
	v_add_co_ci_u32_e64 v3, null, s7, v3, vcc_lo               // 00000005B4D8: D5207C03 01AA0607
	.long 0xd7006a52                                           // 00000005B4E0: D7006A52
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 00000005B4E4: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B4EC: BF8700A1
	v_add_co_ci_u32_e64 v83, null, 0, v3, vcc_lo               // 00000005B4F0: D5207C53 01AA0680
	.long 0xd7006a54                                           // 00000005B4F8: D7006A54
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000005B4FC: 0201FF02
	.long 0x00002000                                           // 00000005B500: 00002000
	v_add_co_ci_u32_e64 v85, null, 0, v3, vcc_lo               // 00000005B504: D5207C55 01AA0680
	.long 0xd7006a56                                           // 00000005B50C: D7006A56
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 00000005B510: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005B518: BF870001
	v_add_co_ci_u32_e64 v87, null, 0, v3, vcc_lo               // 00000005B51C: D5207C57 01AA0680
	s_clause 0x7                                               // 00000005B524: BF850007
	global_store_b32 v[2:3], v69, off                          // 00000005B528: DC6A0000 007C4502
	global_store_b32 v[2:3], v70, off offset:1024              // 00000005B530: DC6A0400 007C4602
	global_store_b32 v[2:3], v71, off offset:2048              // 00000005B538: DC6A0800 007C4702
	global_store_b32 v[2:3], v72, off offset:3072              // 00000005B540: DC6A0C00 007C4802
	global_store_b32 v[82:83], v73, off offset:1024            // 00000005B548: DC6A0400 007C4952
	global_store_b32 v[82:83], v151, off offset:2048           // 00000005B550: DC6A0800 007C9752
	global_store_b32 v[82:83], v152, off offset:3072           // 00000005B558: DC6A0C00 007C9852
	global_store_b32 v[86:87], v68, off offset:1024            // 00000005B560: DC6A0400 007C4456
	.long 0xd7006a44                                           // 00000005B568: D7006A44
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 00000005B56C: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B574: BF8700A1
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 00000005B578: D5207C45 01AA0680
	.long 0xd7006a46                                           // 00000005B580: D7006A46
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000005B584: 0201FF02
	.long 0x00004000                                           // 00000005B588: 00004000
	v_add_co_ci_u32_e64 v71, null, 0, v3, vcc_lo               // 00000005B58C: D5207C47 01AA0680
	.long 0xd7006a48                                           // 00000005B594: D7006A48
	v_cndmask_b32_e32 v1, 0x4000, v2, vcc_lo                   // 00000005B598: 020204FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005B5A0: BF870001
	v_add_co_ci_u32_e64 v73, null, 0, v3, vcc_lo               // 00000005B5A4: D5207C49 01AA0680
	s_clause 0x7                                               // 00000005B5AC: BF850007
	global_store_b32 v[86:87], v62, off offset:2048            // 00000005B5B0: DC6A0800 007C3E56
	global_store_b32 v[86:87], v63, off offset:3072            // 00000005B5B8: DC6A0C00 007C3F56
	global_store_b32 v[68:69], v64, off offset:1024            // 00000005B5C0: DC6A0400 007C4044
	global_store_b32 v[68:69], v66, off offset:2048            // 00000005B5C8: DC6A0800 007C4244
	global_store_b32 v[68:69], v67, off offset:3072            // 00000005B5D0: DC6A0C00 007C4344
	global_store_b32 v[72:73], v59, off offset:1024            // 00000005B5D8: DC6A0400 007C3B48
	global_store_b32 v[72:73], v60, off offset:2048            // 00000005B5E0: DC6A0800 007C3C48
	global_store_b32 v[72:73], v61, off offset:3072            // 00000005B5E8: DC6A0C00 007C3D48
	.long 0xd7006a3b                                           // 00000005B5F0: D7006A3B
	v_cndmask_b32_e32 v1, 0x5000, v2, vcc_lo                   // 00000005B5F4: 020204FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B5FC: BF8700A1
	v_add_co_ci_u32_e64 v60, null, 0, v3, vcc_lo               // 00000005B600: D5207C3C 01AA0680
	.long 0xd7006a3d                                           // 00000005B608: D7006A3D
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000005B60C: 0201FF02
	.long 0x00006000                                           // 00000005B610: 00006000
	v_add_co_ci_u32_e64 v62, null, 0, v3, vcc_lo               // 00000005B614: D5207C3E 01AA0680
	.long 0xd7006a3f                                           // 00000005B61C: D7006A3F
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 00000005B620: 020204FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B628: BF8700A1
	v_add_co_ci_u32_e64 v64, null, 0, v3, vcc_lo               // 00000005B62C: D5207C40 01AA0680
	.long 0xd7006a42                                           // 00000005B634: D7006A42
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 00000005B638: 020204FF 00007000
	v_add_co_ci_u32_e64 v67, null, 0, v3, vcc_lo               // 00000005B640: D5207C43 01AA0680
	.long 0xd7006a44                                           // 00000005B648: D7006A44
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000005B64C: 0201FF02
	.long 0x00008000                                           // 00000005B650: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005B654: BF870001
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 00000005B658: D5207C45 01AA0680
	s_clause 0x7                                               // 00000005B660: BF850007
	global_store_b32 v[59:60], v52, off offset:1024            // 00000005B664: DC6A0400 007C343B
	global_store_b32 v[59:60], v53, off offset:2048            // 00000005B66C: DC6A0800 007C353B
	global_store_b32 v[59:60], v54, off offset:3072            // 00000005B674: DC6A0C00 007C363B
	global_store_b32 v[63:64], v55, off offset:1024            // 00000005B67C: DC6A0400 007C373F
	global_store_b32 v[63:64], v56, off offset:2048            // 00000005B684: DC6A0800 007C383F
	global_store_b32 v[63:64], v58, off offset:3072            // 00000005B68C: DC6A0C00 007C3A3F
	global_store_b32 v[66:67], v50, off offset:1024            // 00000005B694: DC6A0400 007C3242
	global_store_b32 v[66:67], v51, off offset:2048            // 00000005B69C: DC6A0800 007C3342
	.long 0xd7006a32                                           // 00000005B6A4: D7006A32
	v_cndmask_b32_e32 v1, 0x8000, v2, vcc_lo                   // 00000005B6A8: 020204FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B6B0: BF8700A1
	v_add_co_ci_u32_e64 v51, null, 0, v3, vcc_lo               // 00000005B6B4: D5207C33 01AA0680
	.long 0xd7006a34                                           // 00000005B6BC: D7006A34
	v_cndmask_b32_e32 v1, 0x9000, v2, vcc_lo                   // 00000005B6C0: 020204FF 00009000
	v_add_co_ci_u32_e64 v53, null, 0, v3, vcc_lo               // 00000005B6C8: D5207C35 01AA0680
	.long 0xd7006a36                                           // 00000005B6D0: D7006A36
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000005B6D4: 0201FF02
	.long 0x0000a000                                           // 00000005B6D8: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B6DC: BF8700A1
	v_add_co_ci_u32_e64 v55, null, 0, v3, vcc_lo               // 00000005B6E0: D5207C37 01AA0680
	.long 0xd7006a3a                                           // 00000005B6E8: D7006A3A
	v_cndmask_b32_e32 v1, 0xa000, v2, vcc_lo                   // 00000005B6EC: 020204FF 0000A000
	v_add_co_ci_u32_e64 v59, null, 0, v3, vcc_lo               // 00000005B6F4: D5207C3B 01AA0680
	s_clause 0x7                                               // 00000005B6FC: BF850007
	global_store_b32 v[66:67], v40, off offset:3072            // 00000005B700: DC6A0C00 007C2842
	global_store_b32 v[50:51], v43, off offset:1024            // 00000005B708: DC6A0400 007C2B32
	global_store_b32 v[50:51], v44, off offset:2048            // 00000005B710: DC6A0800 007C2C32
	global_store_b32 v[50:51], v45, off offset:3072            // 00000005B718: DC6A0C00 007C2D32
	global_store_b32 v[52:53], v46, off offset:1024            // 00000005B720: DC6A0400 007C2E34
	global_store_b32 v[52:53], v47, off offset:2048            // 00000005B728: DC6A0800 007C2F34
	global_store_b32 v[52:53], v48, off offset:3072            // 00000005B730: DC6A0C00 007C3034
	global_store_b32 v[58:59], v42, off offset:1024            // 00000005B738: DC6A0400 007C2A3A
	.long 0xd7006a2a                                           // 00000005B740: D7006A2A
	v_cndmask_b32_e32 v1, 0xb000, v2, vcc_lo                   // 00000005B744: 020204FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B74C: BF8700A1
	v_add_co_ci_u32_e64 v43, null, 0, v3, vcc_lo               // 00000005B750: D5207C2B 01AA0680
	.long 0xd7006a2c                                           // 00000005B758: D7006A2C
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000005B75C: 0201FF02
	.long 0x0000c000                                           // 00000005B760: 0000C000
	v_add_co_ci_u32_e64 v45, null, 0, v3, vcc_lo               // 00000005B764: D5207C2D 01AA0680
	.long 0xd7006a2e                                           // 00000005B76C: D7006A2E
	v_cndmask_b32_e32 v1, 0xc000, v2, vcc_lo                   // 00000005B770: 020204FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005B778: BF870001
	v_add_co_ci_u32_e64 v47, null, 0, v3, vcc_lo               // 00000005B77C: D5207C2F 01AA0680
	s_clause 0x7                                               // 00000005B784: BF850007
	global_store_b32 v[58:59], v35, off offset:2048            // 00000005B788: DC6A0800 007C233A
	global_store_b32 v[58:59], v36, off offset:3072            // 00000005B790: DC6A0C00 007C243A
	global_store_b32 v[42:43], v37, off offset:1024            // 00000005B798: DC6A0400 007C252A
	global_store_b32 v[42:43], v38, off offset:2048            // 00000005B7A0: DC6A0800 007C262A
	global_store_b32 v[42:43], v39, off offset:3072            // 00000005B7A8: DC6A0C00 007C272A
	global_store_b32 v[46:47], v31, off offset:1024            // 00000005B7B0: DC6A0400 007C1F2E
	global_store_b32 v[46:47], v32, off offset:2048            // 00000005B7B8: DC6A0800 007C202E
	global_store_b32 v[46:47], v34, off offset:3072            // 00000005B7C0: DC6A0C00 007C222E
	.long 0xd7006a1f                                           // 00000005B7C8: D7006A1F
	v_cndmask_b32_e32 v1, 0xd000, v2, vcc_lo                   // 00000005B7CC: 020204FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005B7D4: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v3, vcc_lo               // 00000005B7D8: D5207C20 01AA0680
	.long 0xd7006a22                                           // 00000005B7E0: D7006A22
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000005B7E4: 0201FF02
	.long 0x0000e000                                           // 00000005B7E8: 0000E000
	v_add_co_ci_u32_e64 v35, null, 0, v3, vcc_lo               // 00000005B7EC: D5207C23 01AA0680
	.long 0xd7006a24                                           // 00000005B7F4: D7006A24
	v_cndmask_b32_e32 v1, 0xe000, v2, vcc_lo                   // 00000005B7F8: 020204FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005B800: BF870001
	v_add_co_ci_u32_e64 v37, null, 0, v3, vcc_lo               // 00000005B804: D5207C25 01AA0680
	.long 0xd7006a02                                           // 00000005B80C: D7006A02
	v_cndmask_b32_e32 v1, 0xf000, v2, vcc_lo                   // 00000005B810: 020204FF 0000F000
	s_clause 0x7                                               // 00000005B818: BF850007
	global_store_b32 v[68:69], v11, off offset:-4096           // 00000005B81C: DC6A1000 007C0B44
	global_store_b32 v[68:69], v12, off                        // 00000005B824: DC6A0000 007C0C44
	global_store_b32 v[54:55], v14, off offset:-4096           // 00000005B82C: DC6A1000 007C0E36
	global_store_b32 v[54:55], v15, off                        // 00000005B834: DC6A0000 007C0F36
	global_store_b32 v[44:45], v27, off offset:-4096           // 00000005B83C: DC6A1000 007C1B2C
	global_store_b32 v[44:45], v28, off                        // 00000005B844: DC6A0000 007C1C2C
	global_store_b32 v[34:35], v29, off offset:-4096           // 00000005B84C: DC6A1000 007C1D22
	global_store_b32 v[34:35], v30, off                        // 00000005B854: DC6A0000 007C1E22
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000005B85C: D5207C03 01AA0680
	s_clause 0xf                                               // 00000005B864: BF85000F
	global_store_b32 v[31:32], v20, off offset:1024            // 00000005B868: DC6A0400 007C141F
	global_store_b32 v[31:32], v21, off offset:2048            // 00000005B870: DC6A0800 007C151F
	global_store_b32 v[31:32], v22, off offset:3072            // 00000005B878: DC6A0C00 007C161F
	global_store_b32 v[36:37], v23, off offset:1024            // 00000005B880: DC6A0400 007C1724
	global_store_b32 v[36:37], v24, off offset:2048            // 00000005B888: DC6A0800 007C1824
	global_store_b32 v[36:37], v26, off offset:3072            // 00000005B890: DC6A0C00 007C1A24
	global_store_b32 v[2:3], v16, off                          // 00000005B898: DC6A0000 007C1002
	global_store_b32 v[2:3], v18, off offset:1024              // 00000005B8A0: DC6A0400 007C1202
	global_store_b32 v[2:3], v19, off offset:2048              // 00000005B8A8: DC6A0800 007C1302
	global_store_b32 v[84:85], v4, off offset:-4096            // 00000005B8B0: DC6A1000 007C0454
	global_store_b32 v[84:85], v5, off                         // 00000005B8B8: DC6A0000 007C0554
	global_store_b32 v[70:71], v6, off offset:-4096            // 00000005B8C0: DC6A1000 007C0646
	global_store_b32 v[70:71], v7, off                         // 00000005B8C8: DC6A0000 007C0746
	global_store_b32 v[61:62], v8, off offset:-4096            // 00000005B8D0: DC6A1000 007C083D
	global_store_b32 v[61:62], v10, off                        // 00000005B8D8: DC6A0000 007C0A3D
	global_store_b32 v[2:3], v13, off offset:3072              // 00000005B8E0: DC6A0C00 007C0D02
	s_branch 60936                                             // 00000005B8E8: BFA0EE08 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	v_mov_b32_e32 v54, v41                                     // 00000005B8EC: 7E6C0329
	v_mov_b32_e32 v53, v33                                     // 00000005B8F0: 7E6A0321
	v_mov_b32_e32 v52, v25                                     // 00000005B8F4: 7E680319
	v_mov_b32_e32 v51, v17                                     // 00000005B8F8: 7E660311
	v_mov_b32_e32 v50, v9                                      // 00000005B8FC: 7E640309
	v_mov_b32_e32 v58, v49                                     // 00000005B900: 7E740331
	v_mov_b32_e32 v152, v57                                    // 00000005B904: 7F300339
	v_mov_b32_e32 v151, v65                                    // 00000005B908: 7F2E0341
	s_mov_b32 s7, 0                                            // 00000005B90C: BE870080
	s_branch 1                                                 // 00000005B910: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5118>
	s_mov_b64 s[6:7], 0                                        // 00000005B914: BE860180
	v_dual_mul_f32 v3, 0x3b800000, v139 :: v_dual_mul_f32 v4, 0x3b800000, v138// 00000005B918: C8C716FF 030514FF 3B800000
	v_dual_mul_f32 v5, 0x3b800000, v137 :: v_dual_mul_f32 v6, 0x3b800000, v136// 00000005B924: C8C712FF 050710FF 3B800000
	.long 0xd7006a01                                           // 00000005B930: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000005B934: 0201FFBB
	.long 0x00002000                                           // 00000005B938: 00002000
	v_dual_mul_f32 v7, 0x3b800000, v135 :: v_dual_mul_f32 v8, 0x3b800000, v134// 00000005B93C: C8C70EFF 07090CFF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 00000005B948: D5207C02 01AB7880
	v_dual_mul_f32 v9, 0x3b800000, v133 :: v_dual_mul_f32 v10, 0x3b800000, v54// 00000005B950: C8C70AFF 090A6CFF 3B800000
	s_clause 0x7                                               // 00000005B95C: BF850007
	global_store_b32 v[187:188], v3, off                       // 00000005B960: DC6A0000 007C03BB
	global_store_b32 v[187:188], v4, off offset:1024           // 00000005B968: DC6A0400 007C04BB
	global_store_b32 v[187:188], v5, off offset:2048           // 00000005B970: DC6A0800 007C05BB
	global_store_b32 v[187:188], v6, off offset:3072           // 00000005B978: DC6A0C00 007C06BB
	global_store_b32 v[1:2], v7, off offset:-4096              // 00000005B980: DC6A1000 007C0701
	global_store_b32 v[1:2], v8, off offset:-3072              // 00000005B988: DC6A1400 007C0801
	global_store_b32 v[1:2], v9, off offset:-2048              // 00000005B990: DC6A1800 007C0901
	global_store_b32 v[1:2], v10, off offset:-1024             // 00000005B998: DC6A1C00 007C0A01
	v_dual_mul_f32 v5, 0x3b800000, v132 :: v_dual_mul_f32 v6, 0x3b800000, v131// 00000005B9A0: C8C708FF 050706FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v130 :: v_dual_mul_f32 v8, 0x3b800000, v129// 00000005B9AC: C8C704FF 070902FF 3B800000
	.long 0xd7006a03                                           // 00000005B9B8: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000005B9BC: 0201FFBB
	.long 0x00004000                                           // 00000005B9C0: 00004000
	v_dual_mul_f32 v9, 0x3b800000, v128 :: v_dual_mul_f32 v10, 0x3b800000, v127// 00000005B9C4: C8C700FF 090AFEFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 00000005B9D0: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v126 :: v_dual_mul_f32 v12, 0x3b800000, v53// 00000005B9D8: C8C6FCFF 0B0C6AFF 3B800000
	s_clause 0x7                                               // 00000005B9E4: BF850007
	global_store_b32 v[1:2], v5, off                           // 00000005B9E8: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 00000005B9F0: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 00000005B9F8: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 00000005BA00: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 00000005BA08: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 00000005BA10: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 00000005BA18: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 00000005BA20: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v125 :: v_dual_mul_f32 v6, 0x3b800000, v124// 00000005BA28: C8C6FAFF 0506F8FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v123 :: v_dual_mul_f32 v8, 0x3b800000, v122// 00000005BA34: C8C6F6FF 0708F4FF 3B800000
	.long 0xd7006a01                                           // 00000005BA40: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000005BA44: 0201FFBB
	.long 0x00006000                                           // 00000005BA48: 00006000
	v_dual_mul_f32 v9, 0x3b800000, v121 :: v_dual_mul_f32 v10, 0x3b800000, v120// 00000005BA4C: C8C6F2FF 090AF0FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 00000005BA58: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v119 :: v_dual_mul_f32 v12, 0x3b800000, v52// 00000005BA60: C8C6EEFF 0B0C68FF 3B800000
	s_clause 0x7                                               // 00000005BA6C: BF850007
	global_store_b32 v[3:4], v5, off                           // 00000005BA70: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 00000005BA78: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 00000005BA80: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 00000005BA88: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 00000005BA90: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 00000005BA98: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 00000005BAA0: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 00000005BAA8: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v118 :: v_dual_mul_f32 v6, 0x3b800000, v117// 00000005BAB0: C8C6ECFF 0506EAFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v116 :: v_dual_mul_f32 v8, 0x3b800000, v115// 00000005BABC: C8C6E8FF 0708E6FF 3B800000
	.long 0xd7006a03                                           // 00000005BAC8: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000005BACC: 0201FFBB
	.long 0x00008000                                           // 00000005BAD0: 00008000
	v_dual_mul_f32 v9, 0x3b800000, v114 :: v_dual_mul_f32 v10, 0x3b800000, v113// 00000005BAD4: C8C6E4FF 090AE2FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 00000005BAE0: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v112 :: v_dual_mul_f32 v12, 0x3b800000, v51// 00000005BAE8: C8C6E0FF 0B0C66FF 3B800000
	s_clause 0x7                                               // 00000005BAF4: BF850007
	global_store_b32 v[1:2], v5, off                           // 00000005BAF8: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 00000005BB00: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 00000005BB08: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 00000005BB10: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 00000005BB18: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 00000005BB20: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 00000005BB28: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 00000005BB30: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v111 :: v_dual_mul_f32 v6, 0x3b800000, v110// 00000005BB38: C8C6DEFF 0506DCFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v109 :: v_dual_mul_f32 v8, 0x3b800000, v108// 00000005BB44: C8C6DAFF 0708D8FF 3B800000
	.long 0xd7006a01                                           // 00000005BB50: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000005BB54: 0201FFBB
	.long 0x0000a000                                           // 00000005BB58: 0000A000
	v_dual_mul_f32 v9, 0x3b800000, v107 :: v_dual_mul_f32 v10, 0x3b800000, v106// 00000005BB5C: C8C6D6FF 090AD4FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 00000005BB68: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v105 :: v_dual_mul_f32 v12, 0x3b800000, v50// 00000005BB70: C8C6D2FF 0B0C64FF 3B800000
	s_clause 0x7                                               // 00000005BB7C: BF850007
	global_store_b32 v[3:4], v5, off                           // 00000005BB80: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 00000005BB88: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 00000005BB90: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 00000005BB98: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 00000005BBA0: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 00000005BBA8: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 00000005BBB0: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 00000005BBB8: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v104 :: v_dual_mul_f32 v6, 0x3b800000, v103// 00000005BBC0: C8C6D0FF 0506CEFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v102 :: v_dual_mul_f32 v8, 0x3b800000, v101// 00000005BBCC: C8C6CCFF 0708CAFF 3B800000
	.long 0xd7006a03                                           // 00000005BBD8: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000005BBDC: 0201FFBB
	.long 0x0000c000                                           // 00000005BBE0: 0000C000
	v_dual_mul_f32 v9, 0x3b800000, v100 :: v_dual_mul_f32 v10, 0x3b800000, v99// 00000005BBE4: C8C6C8FF 090AC6FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 00000005BBF0: D5207C04 01AB7880
	v_mul_f32_e32 v11, 0x3b800000, v98                         // 00000005BBF8: 1016C4FF 3B800000
	v_mul_f32_e32 v12, 0x3b800000, v58                         // 00000005BC00: 101874FF 3B800000
	s_clause 0x7                                               // 00000005BC08: BF850007
	global_store_b32 v[1:2], v5, off                           // 00000005BC0C: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 00000005BC14: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 00000005BC1C: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 00000005BC24: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 00000005BC2C: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 00000005BC34: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 00000005BC3C: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 00000005BC44: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v97 :: v_dual_mul_f32 v6, 0x3b800000, v96// 00000005BC4C: C8C6C2FF 0506C0FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v95 :: v_dual_mul_f32 v8, 0x3b800000, v94// 00000005BC58: C8C6BEFF 0708BCFF 3B800000
	.long 0xd7006a01                                           // 00000005BC64: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000005BC68: 0201FFBB
	.long 0x0000e000                                           // 00000005BC6C: 0000E000
	v_dual_mul_f32 v9, 0x3b800000, v93 :: v_dual_mul_f32 v10, 0x3b800000, v92// 00000005BC70: C8C6BAFF 090AB8FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 00000005BC7C: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v91 :: v_dual_mul_f32 v12, 0x3b800000, v152// 00000005BC84: C8C6B6FF 0B0D30FF 3B800000
	s_clause 0x7                                               // 00000005BC90: BF850007
	global_store_b32 v[3:4], v5, off                           // 00000005BC94: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 00000005BC9C: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 00000005BCA4: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 00000005BCAC: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 00000005BCB4: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 00000005BCBC: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 00000005BCC4: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 00000005BCCC: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v90 :: v_dual_mul_f32 v6, 0x3b800000, v141// 00000005BCD4: C8C6B4FF 05071AFF 3B800000
	v_and_or_b32 v0, v0, 31, s5                                // 00000005BCE0: D6570000 00153F00
	v_dual_mul_f32 v7, 0x3b800000, v150 :: v_dual_mul_f32 v10, 0x3b800000, v189// 00000005BCE8: C8C72CFF 070B7AFF 3B800000
	.long 0xd7006a03                                           // 00000005BCF4: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000005BCF8: 0201FFBB
	.long 0x0000fc00                                           // 00000005BCFC: 0000FC00
	v_dual_mul_f32 v8, 0x3b800000, v142 :: v_dual_mul_f32 v9, 0x3b800000, v191// 00000005BD00: C8C71CFF 08097EFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 00000005BD0C: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v190 :: v_dual_mul_f32 v12, 0x3b800000, v151// 00000005BD14: C8C77CFF 0B0D2EFF 3B800000
	s_clause 0x7                                               // 00000005BD20: BF850007
	global_store_b32 v[1:2], v5, off                           // 00000005BD24: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 00000005BD2C: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 00000005BD34: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 00000005BD3C: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-3072              // 00000005BD44: DC6A1400 007C0903
	global_store_b32 v[3:4], v10, off offset:-2048             // 00000005BD4C: DC6A1800 007C0A03
	global_store_b32 v[3:4], v11, off offset:-1024             // 00000005BD54: DC6A1C00 007C0B03
	global_store_b32 v[3:4], v12, off                          // 00000005BD5C: DC6A0000 007C0C03
	s_mov_b32 s2, exec_lo                                      // 00000005BD64: BE82007E
	v_cmpx_eq_u32_e32 0, v0                                    // 00000005BD68: 7D940080
	s_cbranch_execz 8                                          // 00000005BD6C: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi10ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5590>
	s_load_b64 s[0:1], s[0:1], 0x40                            // 00000005BD70: F4040000 F8000040
	v_mov_b32_e32 v0, s6                                       // 00000005BD78: 7E000206
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, s7              // 00000005BD7C: CA100080 02000007
	s_waitcnt lgkmcnt(0)                                       // 00000005BD84: BF89FC07
	global_store_b64 v2, v[0:1], s[0:1] offset:72              // 00000005BD88: DC6E0048 00000002
	s_endpgm                                                   // 00000005BD90: BFB00000
		...

