0000000000124100 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000124100: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 000000124104: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000012410C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 000000124114: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 000000124118: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000012411C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 000000124120: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000124128: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000012412C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 000000124130: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 000000124134: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000012413C: 84928214
	s_add_u32 s25, s16, s18                                    // 000000124140: 80191210
	s_addc_u32 s28, s17, s19                                   // 000000124144: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 000000124148: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000012414C: BF870009
	s_add_u32 s25, s25, s20                                    // 000000124150: 80191419
	s_addc_u32 s30, s28, s21                                   // 000000124154: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 000000124158: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000012415C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 000000124164: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000012416C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 000000124170: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 000000124174: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000124178: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000012417C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 000000124180: 821E191E
	.long 0xd7001f02                                           // 000000124184: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 000000124188: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000012418C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 000000124194: BE9E0080
	s_nop 0                                                    // 000000124198: BF800000
	s_nop 0                                                    // 00000012419C: BF800000
	s_nop 0                                                    // 0000001241A0: BF800000
	s_nop 0                                                    // 0000001241A4: BF800000
	s_nop 0                                                    // 0000001241A8: BF800000
	s_nop 0                                                    // 0000001241AC: BF800000
	s_nop 0                                                    // 0000001241B0: BF800000
	s_nop 0                                                    // 0000001241B4: BF800000
	s_nop 0                                                    // 0000001241B8: BF800000
	s_nop 0                                                    // 0000001241BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000001241C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000001241C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001241CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000001241D0: 300C1089
	.long 0xd7006a06                                           // 0000001241D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000001241D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001241DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000001241E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000001241E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000001241F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000001241F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000001241FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 000000124208: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000012420C: BF8903F7
	ds_store_b32 v6, v9                                        // 000000124210: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 000000124218: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000012421C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 000000124220: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 000000124224: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 00000012422C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 000000124234: 32040084
	s_mov_b32 s0, 0                                            // 000000124238: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000012423C: BF89FC07
	s_barrier                                                  // 000000124240: BFBD0000
	buffer_gl0_inv                                             // 000000124244: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000012424C: BF02801E
	s_cbranch_scc1 12                                          // 000000124250: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 000000124254: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000012425C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000124264: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 000000124268: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 000000124270: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 000000124274: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000124278: 916A007E
	s_cbranch_vccz 2                                           // 00000012427C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2551                                              // 000000124280: BFA009F7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2960>
	v_lshlrev_b32_e32 v39, 2, v5                               // 000000124284: 304E0A82
	s_add_i32 s0, s30, 63                                      // 000000124288: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000012428C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 000000124294: 85218600
	s_add_u32 s34, s10, s24                                    // 000000124298: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000012429C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000001242A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000001242A4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000001242AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000001242B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000001242B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000001242B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000001242BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000001242C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000001242C4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000001242C8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000001242D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000001242D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000001242DC: B00A0204
	.long 0xd7000b2c                                           // 0000001242E0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 0000001242E4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001242E8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 0000001242EC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 0000001242F4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 000000124300: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 000000124304: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 000000124310: 3816500A
	.long 0xd7000a05                                           // 000000124314: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 000000124318: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012431C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 000000124320: D5207C06 00290001
	.long 0xd7000107                                           // 000000124328: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 00000012432C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000124330: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 000000124334: D5207C08 0006180D
	.long 0xd7000109                                           // 00000012433C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 000000124340: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 000000124344: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 00000012434C: 84848E02
	.long 0xd700010b                                           // 000000124350: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 000000124354: 02021606
	s_add_u32 s4, s14, s4                                      // 000000124358: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 00000012435C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 000000124364: 8205050F
	.long 0xd700010d                                           // 000000124368: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 00000012436C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000124370: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 000000124374: D5207C0E 00050005
	.long 0xd700010f                                           // 00000012437C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 000000124380: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 000000124388: D5207C10 00061880
	.long 0xd7000111                                           // 000000124390: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 000000124394: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012439C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000001243A0: D5207C12 00061880
	.long 0xd7000113                                           // 0000001243A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000001243AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000001243B4: D5207C14 00061880
	.long 0xd7000115                                           // 0000001243BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000001243C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001243C8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000001243CC: D5207C16 00061880
	.long 0xd7000117                                           // 0000001243D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000001243D8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000001243E0: D5207C18 00061880
	.long 0xd7000119                                           // 0000001243E8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000001243EC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001243F4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000001243F8: D5207C1A 00061880
	.long 0xd700011b                                           // 000000124400: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 000000124404: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 00000012440C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 000000124414: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000124418: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 000000124420: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 000000124424: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 00000012442C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 000000124434: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 00000012443C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 000000124444: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 00000012444C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 000000124454: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 00000012445C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 000000124464: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 00000012446C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 000000124474: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 00000012447C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 000000124484: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 00000012448C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 000000124494: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 00000012449C: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000001244A0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000001244A4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001244AC: BF870499
	s_add_i32 s6, s31, s1                                      // 0000001244B0: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 0000001244B4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001244B8: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 0000001244BC: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 0000001244C0: 84078605
	s_add_u32 s10, s8, s10                                     // 0000001244C4: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 0000001244C8: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 0000001244CC: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000001244D4: BE84206A
	s_cbranch_execz 77                                         // 0000001244D8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510>
	v_or_b32_e32 v29, s7, v0                                   // 0000001244DC: 383A0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001244E0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000001244E4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000001244EC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001244F0: BF870091
	.long 0xd73c001d                                           // 0000001244F4: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000001244F8: 02023A82
	.long 0xd700011d                                           // 0000001244FC: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 000000124500: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000124504: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 000000124508: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 000000124510: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000124518: BF890007
	v_sub_f32_e32 v30, s6, v29                                 // 00000012451C: 083C3A06
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 000000124520: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000012452C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 000000124530: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 00000012453C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 000000124540: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 00000012454C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000124550: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 000000124554: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 000000124560: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000124564: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 000000124568: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 000000124570: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 000000124574: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 00000012457C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 000000124584: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 000000124588: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012458C: BF870193
	v_exp_f32_e32 v32, v32                                     // 000000124590: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 000000124594: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000124598: BF870296
	.long 0xd71c0020                                           // 00000012459C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000001245A0: 02024520
	.long 0xd71c001f                                           // 0000001245A4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000001245A8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001245AC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000001245B0: D501001F 00063E80
	.long 0xd41b0001                                           // 0000001245B8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000001245BC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000001245C4: D5010020 00064080
	.long 0xd41e0001                                           // 0000001245CC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000001245D0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001245D8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000001245DC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000001245E8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000001245EC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000001245F4: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 000000124600: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 000000124608: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 000000124610: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 000000124614: CA100108 1E1C0107
	s_mov_b32 s10, 0                                           // 00000012461C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000124620: BF89FC07
	s_barrier                                                  // 000000124624: BFBD0000
	buffer_gl0_inv                                             // 000000124628: E0AC0000 00000000
	s_branch 15                                                // 000000124630: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000124634: 8C7E047E
	.long 0xd700011d                                           // 000000124638: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 00000012463C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000124644: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000124648: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 000000124650: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 000000124654: BF08B70A
	s_mov_b32 s10, s1                                          // 000000124658: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 00000012465C: BF89FC07
	s_barrier                                                  // 000000124660: BFBD0000
	buffer_gl0_inv                                             // 000000124664: E0AC0000 00000000
	s_cbranch_scc1 676                                         // 00000012466C: BFA202A4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1000>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 000000124670: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 000000124678: CA100128 21220126
	s_mov_b32 s11, 0                                           // 000000124680: BE8B0080
	s_nop 0                                                    // 000000124684: BF800000
	s_nop 0                                                    // 000000124688: BF800000
	s_nop 0                                                    // 00000012468C: BF800000
	s_nop 0                                                    // 000000124690: BF800000
	s_nop 0                                                    // 000000124694: BF800000
	s_nop 0                                                    // 000000124698: BF800000
	s_nop 0                                                    // 00000012469C: BF800000
	s_nop 0                                                    // 0000001246A0: BF800000
	s_nop 0                                                    // 0000001246A4: BF800000
	s_nop 0                                                    // 0000001246A8: BF800000
	s_nop 0                                                    // 0000001246AC: BF800000
	s_nop 0                                                    // 0000001246B0: BF800000
	s_nop 0                                                    // 0000001246B4: BF800000
	s_nop 0                                                    // 0000001246B8: BF800000
	s_nop 0                                                    // 0000001246BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000001246C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000001246C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000001246D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000001246D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001246DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000001246E0: D5207C20 00064080
	.long 0xd4490004                                           // 0000001246E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000001246EC: 020244FF 0000037F
	s_or_b32 s11, s4, s11                                      // 0000001246F4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 0000001246F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000001246FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 000000124704: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000012470C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000124710: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000124714: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000124718: BF89FC07
	s_barrier                                                  // 00000012471C: BFBD0000
	buffer_gl0_inv                                             // 000000124720: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000124728: BE842000
	s_cbranch_execz 65473                                      // 00000012472C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_or3_b32 v31, s10, s7, v2                                 // 000000124730: D658001F 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000124738: BF870091
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 00000012473C: D6FE7C1F 0009611F
	.long 0xd73c001f                                           // 000000124744: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 000000124748: 02023E89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012474C: BF870091
	.long 0xd700011f                                           // 000000124750: D700011F
	v_cndmask_b32_e32 v1, v44, v31, vcc_lo                     // 000000124754: 02023F2C
	v_add_co_ci_u32_e64 v32, null, v45, v32, s1                // 000000124758: D5207C20 0006412D
	global_load_b32 v68, v[31:32], off                         // 000000124760: DC520000 447C001F
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 000000124768: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v1 offset1:17                  // 000000124770: D8DC1100 21000001
	ds_load_2addr_b32 v[35:36], v1 offset0:34 offset1:51       // 000000124778: D8DC3322 23000001
	ds_load_2addr_b32 v[60:61], v46 offset0:2 offset1:3        // 000000124780: D8DC0302 3C00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:4 offset1:5        // 000000124788: D8DC0504 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:6 offset1:7        // 000000124790: D8DC0706 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 000000124798: D8DC5544 42000001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 0000001247A0: BF890057
	v_fma_f32 v31, -v31, v33, v68                              // 0000001247A4: D613001F 2512431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001247AC: BF8700C1
	v_fma_f32 v33, -v32, v34, v31                              // 0000001247B0: D6130021 247E4520
	ds_load_2addr_b32 v[31:32], v1 offset0:102 offset1:119     // 0000001247B8: D8DC7766 1F000001
	s_waitcnt lgkmcnt(4)                                       // 0000001247C0: BF89FC47
	v_fma_f32 v33, -v60, v35, v33                              // 0000001247C4: D6130021 2486473C
	v_fma_f32 v60, -v61, v36, v33                              // 0000001247CC: D613003C 2486493D
	ds_load_2addr_b32 v[33:34], v46 offset0:8 offset1:9        // 0000001247D4: D8DC0908 2100002E
	ds_load_2addr_b32 v[35:36], v1 offset0:136 offset1:153     // 0000001247DC: D8DC9988 23000001
	s_waitcnt lgkmcnt(3)                                       // 0000001247E4: BF89FC37
	v_fma_f32 v60, -v62, v66, v60                              // 0000001247E8: D613003C 24F2853E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001247F0: BF8700D1
	v_fma_f32 v66, -v63, v67, v60                              // 0000001247F4: D6130042 24F2873F
	ds_load_2addr_b32 v[60:61], v46 offset0:10 offset1:11      // 0000001247FC: D8DC0B0A 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:170 offset1:187     // 000000124804: D8DCBBAA 3E000001
	s_waitcnt lgkmcnt(4)                                       // 00000012480C: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 000000124810: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 000000124818: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:12 offset1:13      // 000000124820: D8DC0D0C 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:14 offset1:15      // 000000124828: D8DC0F0E 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:204 offset1:221     // 000000124830: D8DCDDCC 42000001
	s_waitcnt lgkmcnt(5)                                       // 000000124838: BF89FC57
	v_fma_f32 v33, -v33, v35, v68                              // 00000012483C: D6130021 25124721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000124844: BF8700C1
	v_fma_f32 v35, -v34, v36, v33                              // 000000124848: D6130023 24864922
	ds_load_2addr_b32 v[33:34], v1 offset0:238 offset1:255     // 000000124850: D8DCFFEE 21000001
	s_waitcnt lgkmcnt(4)                                       // 000000124858: BF89FC47
	v_fma_f32 v35, -v60, v62, v35                              // 00000012485C: D6130023 248E7D3C
	v_fma_f32 v62, -v61, v63, v35                              // 000000124864: D613003E 248E7F3D
	ds_load_2addr_b32 v[35:36], v46 offset0:16 offset1:17      // 00000012486C: D8DC1110 2300002E
	ds_load_2addr_b32 v[60:61], v48 offset0:16 offset1:33      // 000000124874: D8DC2110 3C000030
	s_waitcnt lgkmcnt(3)                                       // 00000012487C: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 000000124880: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000124888: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 00000012488C: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:18 offset1:19      // 000000124894: D8DC1312 1F00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:50 offset1:67      // 00000012489C: D8DC4332 3E000030
	s_waitcnt lgkmcnt(4)                                       // 0000001248A4: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 0000001248A8: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 0000001248B0: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:20 offset1:21      // 0000001248B8: D8DC1514 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:22 offset1:23      // 0000001248C0: D8DC1716 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:84 offset1:101     // 0000001248C8: D8DC6554 42000030
	s_waitcnt lgkmcnt(5)                                       // 0000001248D0: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 0000001248D4: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001248DC: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 0000001248E0: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v48 offset0:118 offset1:135    // 0000001248E8: D8DC8776 23000030
	s_waitcnt lgkmcnt(4)                                       // 0000001248F0: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 0000001248F4: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 0000001248FC: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 000000124904: D8DC1918 1F00002E
	ds_load_2addr_b32 v[60:61], v48 offset0:152 offset1:169    // 00000012490C: D8DCA998 3C000030
	s_waitcnt lgkmcnt(3)                                       // 000000124914: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 000000124918: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000124920: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 000000124924: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:26 offset1:27      // 00000012492C: D8DC1B1A 2100002E
	ds_load_2addr_b32 v[62:63], v48 offset0:186 offset1:203    // 000000124934: D8DCCBBA 3E000030
	s_waitcnt lgkmcnt(4)                                       // 00000012493C: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 000000124940: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 000000124948: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:28 offset1:29      // 000000124950: D8DC1D1C 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:30 offset1:31      // 000000124958: D8DC1F1E 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:220 offset1:237    // 000000124960: D8DCEDDC 42000030
	s_waitcnt lgkmcnt(5)                                       // 000000124968: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 00000012496C: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000124974: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 000000124978: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v49 offset0:126 offset1:143    // 000000124980: D8DC8F7E 1F000031
	s_waitcnt lgkmcnt(4)                                       // 000000124988: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 00000012498C: D6130021 24F27D21
	v_fma_f32 v62, -v34, v63, v33                              // 000000124994: D613003E 24867F22
	ds_load_2addr_b32 v[33:34], v46 offset0:32 offset1:33      // 00000012499C: D8DC2120 2100002E
	ds_load_2addr_b32 v[60:61], v50 offset0:32 offset1:49      // 0000001249A4: D8DC3120 3C000032
	s_waitcnt lgkmcnt(3)                                       // 0000001249AC: BF89FC37
	v_fma_f32 v35, -v35, v66, v62                              // 0000001249B0: D6130023 24FA8523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001249B8: BF8700D1
	v_fma_f32 v66, -v36, v67, v35                              // 0000001249BC: D6130042 248E8724
	ds_load_2addr_b32 v[35:36], v46 offset0:34 offset1:35      // 0000001249C4: D8DC2322 2300002E
	ds_load_2addr_b32 v[62:63], v50 offset0:66 offset1:83      // 0000001249CC: D8DC5342 3E000032
	s_waitcnt lgkmcnt(4)                                       // 0000001249D4: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 0000001249D8: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 0000001249E0: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:36 offset1:37      // 0000001249E8: D8DC2524 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:38 offset1:39      // 0000001249F0: D8DC2726 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:100 offset1:117    // 0000001249F8: D8DC7564 42000032
	s_waitcnt lgkmcnt(5)                                       // 000000124A00: BF89FC57
	v_fma_f32 v33, -v33, v60, v68                              // 000000124A04: D6130021 25127921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000124A0C: BF8700C1
	v_fma_f32 v60, -v34, v61, v33                              // 000000124A10: D613003C 24867B22
	ds_load_2addr_b32 v[33:34], v50 offset0:134 offset1:151    // 000000124A18: D8DC9786 21000032
	s_waitcnt lgkmcnt(4)                                       // 000000124A20: BF89FC47
	v_fma_f32 v35, -v35, v62, v60                              // 000000124A24: D6130023 24F27D23
	v_fma_f32 v62, -v36, v63, v35                              // 000000124A2C: D613003E 248E7F24
	ds_load_2addr_b32 v[35:36], v46 offset0:40 offset1:41      // 000000124A34: D8DC2928 2300002E
	ds_load_2addr_b32 v[60:61], v50 offset0:168 offset1:185    // 000000124A3C: D8DCB9A8 3C000032
	s_waitcnt lgkmcnt(3)                                       // 000000124A44: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 000000124A48: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000124A50: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 000000124A54: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:42 offset1:43      // 000000124A5C: D8DC2B2A 1F00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:202 offset1:219    // 000000124A64: D8DCDBCA 3E000032
	s_waitcnt lgkmcnt(4)                                       // 000000124A6C: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 000000124A70: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 000000124A78: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:44 offset1:45      // 000000124A80: D8DC2D2C 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:46 offset1:47      // 000000124A88: D8DC2F2E 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:236 offset1:253    // 000000124A90: D8DCFDEC 42000032
	s_waitcnt lgkmcnt(5)                                       // 000000124A98: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 000000124A9C: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000124AA4: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 000000124AA8: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v51 offset0:14 offset1:31      // 000000124AB0: D8DC1F0E 23000033
	s_waitcnt lgkmcnt(4)                                       // 000000124AB8: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 000000124ABC: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 000000124AC4: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 000000124ACC: D8DC3130 1F00002E
	ds_load_2addr_b32 v[60:61], v51 offset0:48 offset1:65      // 000000124AD4: D8DC4130 3C000033
	s_waitcnt lgkmcnt(3)                                       // 000000124ADC: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 000000124AE0: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000124AE8: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 000000124AEC: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 000000124AF4: D8DC3332 2100002E
	ds_load_2addr_b32 v[62:63], v51 offset0:82 offset1:99      // 000000124AFC: D8DC6352 3E000033
	s_waitcnt lgkmcnt(4)                                       // 000000124B04: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 000000124B08: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 000000124B10: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 000000124B18: D8DC3534 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:54 offset1:55      // 000000124B20: D8DC3736 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:116 offset1:133    // 000000124B28: D8DC8574 42000033
	s_waitcnt lgkmcnt(5)                                       // 000000124B30: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 000000124B34: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000124B3C: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 000000124B40: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v51 offset0:150 offset1:167    // 000000124B48: D8DCA796 1F000033
	s_waitcnt lgkmcnt(4)                                       // 000000124B50: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 000000124B54: D6130021 24F27D21
	v_fma_f32 v62, -v34, v63, v33                              // 000000124B5C: D613003E 24867F22
	ds_load_2addr_b32 v[33:34], v46 offset0:56 offset1:57      // 000000124B64: D8DC3938 2100002E
	ds_load_2addr_b32 v[60:61], v51 offset0:184 offset1:201    // 000000124B6C: D8DCC9B8 3C000033
	s_waitcnt lgkmcnt(3)                                       // 000000124B74: BF89FC37
	v_fma_f32 v35, -v35, v66, v62                              // 000000124B78: D6130023 24FA8523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000124B80: BF8700D1
	v_fma_f32 v66, -v36, v67, v35                              // 000000124B84: D6130042 248E8724
	ds_load_2addr_b32 v[35:36], v46 offset0:58 offset1:59      // 000000124B8C: D8DC3B3A 2300002E
	ds_load_2addr_b32 v[62:63], v51 offset0:218 offset1:235    // 000000124B94: D8DCEBDA 3E000033
	s_waitcnt lgkmcnt(4)                                       // 000000124B9C: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 000000124BA0: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 000000124BA8: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:60 offset1:61      // 000000124BB0: D8DC3D3C 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:62 offset1:63      // 000000124BB8: D8DC3F3E 4000002E
	ds_load_2addr_b32 v[66:67], v52 offset0:124 offset1:141    // 000000124BC0: D8DC8D7C 42000034
	s_waitcnt lgkmcnt(5)                                       // 000000124BC8: BF89FC57
	v_fma_f32 v33, -v33, v60, v68                              // 000000124BCC: D6130021 25127921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000124BD4: BF8700C1
	v_fma_f32 v60, -v34, v61, v33                              // 000000124BD8: D613003C 24867B22
	ds_load_2addr_b32 v[33:34], v53 offset0:30 offset1:47      // 000000124BE0: D8DC2F1E 21000035
	s_waitcnt lgkmcnt(4)                                       // 000000124BE8: BF89FC47
	v_fma_f32 v35, -v35, v62, v60                              // 000000124BEC: D6130023 24F27D23
	v_fma_f32 v62, -v36, v63, v35                              // 000000124BF4: D613003E 248E7F24
	ds_load_2addr_b32 v[35:36], v46 offset0:64 offset1:65      // 000000124BFC: D8DC4140 2300002E
	ds_load_2addr_b32 v[60:61], v53 offset0:64 offset1:81      // 000000124C04: D8DC5140 3C000035
	s_waitcnt lgkmcnt(3)                                       // 000000124C0C: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 000000124C10: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000124C18: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 000000124C1C: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:66 offset1:67      // 000000124C24: D8DC4342 1F00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:98 offset1:115     // 000000124C2C: D8DC7362 3E000035
	s_waitcnt lgkmcnt(4)                                       // 000000124C34: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 000000124C38: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 000000124C40: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:68 offset1:69      // 000000124C48: D8DC4544 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:70 offset1:71      // 000000124C50: D8DC4746 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:132 offset1:149    // 000000124C58: D8DC9584 42000035
	s_waitcnt lgkmcnt(5)                                       // 000000124C60: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 000000124C64: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000124C6C: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 000000124C70: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v53 offset0:166 offset1:183    // 000000124C78: D8DCB7A6 23000035
	s_waitcnt lgkmcnt(4)                                       // 000000124C80: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 000000124C84: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 000000124C8C: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 000000124C94: D8DC4948 1F00002E
	ds_load_2addr_b32 v[60:61], v53 offset0:200 offset1:217    // 000000124C9C: D8DCD9C8 3C000035
	s_waitcnt lgkmcnt(3)                                       // 000000124CA4: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 000000124CA8: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000124CB0: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 000000124CB4: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:74 offset1:75      // 000000124CBC: D8DC4B4A 2100002E
	ds_load_2addr_b32 v[62:63], v53 offset0:234 offset1:251    // 000000124CC4: D8DCFBEA 3E000035
	s_waitcnt lgkmcnt(4)                                       // 000000124CCC: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 000000124CD0: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 000000124CD8: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:76 offset1:77      // 000000124CE0: D8DC4D4C 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:78 offset1:79      // 000000124CE8: D8DC4F4E 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:12 offset1:29      // 000000124CF0: D8DC1D0C 42000036
	s_waitcnt lgkmcnt(5)                                       // 000000124CF8: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 000000124CFC: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000124D04: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 000000124D08: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v54 offset0:46 offset1:63      // 000000124D10: D8DC3F2E 1F000036
	s_waitcnt lgkmcnt(4)                                       // 000000124D18: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 000000124D1C: D6130021 24F27D21
	v_fma_f32 v62, -v34, v63, v33                              // 000000124D24: D613003E 24867F22
	ds_load_2addr_b32 v[33:34], v46 offset0:80 offset1:81      // 000000124D2C: D8DC5150 2100002E
	ds_load_2addr_b32 v[60:61], v54 offset0:80 offset1:97      // 000000124D34: D8DC6150 3C000036
	s_waitcnt lgkmcnt(3)                                       // 000000124D3C: BF89FC37
	v_fma_f32 v35, -v35, v66, v62                              // 000000124D40: D6130023 24FA8523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000124D48: BF8700D1
	v_fma_f32 v66, -v36, v67, v35                              // 000000124D4C: D6130042 248E8724
	ds_load_2addr_b32 v[35:36], v46 offset0:82 offset1:83      // 000000124D54: D8DC5352 2300002E
	ds_load_2addr_b32 v[62:63], v54 offset0:114 offset1:131    // 000000124D5C: D8DC8372 3E000036
	s_waitcnt lgkmcnt(4)                                       // 000000124D64: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 000000124D68: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 000000124D70: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:84 offset1:85      // 000000124D78: D8DC5554 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:86 offset1:87      // 000000124D80: D8DC5756 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:148 offset1:165    // 000000124D88: D8DCA594 42000036
	s_waitcnt lgkmcnt(5)                                       // 000000124D90: BF89FC57
	v_fma_f32 v33, -v33, v60, v68                              // 000000124D94: D6130021 25127921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000124D9C: BF8700C1
	v_fma_f32 v60, -v34, v61, v33                              // 000000124DA0: D613003C 24867B22
	ds_load_2addr_b32 v[33:34], v54 offset0:182 offset1:199    // 000000124DA8: D8DCC7B6 21000036
	s_waitcnt lgkmcnt(4)                                       // 000000124DB0: BF89FC47
	v_fma_f32 v35, -v35, v62, v60                              // 000000124DB4: D6130023 24F27D23
	v_fma_f32 v62, -v36, v63, v35                              // 000000124DBC: D613003E 248E7F24
	ds_load_2addr_b32 v[35:36], v46 offset0:88 offset1:89      // 000000124DC4: D8DC5958 2300002E
	ds_load_2addr_b32 v[60:61], v54 offset0:216 offset1:233    // 000000124DCC: D8DCE9D8 3C000036
	s_waitcnt lgkmcnt(3)                                       // 000000124DD4: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 000000124DD8: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000124DE0: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 000000124DE4: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:90 offset1:91      // 000000124DEC: D8DC5B5A 1F00002E
	ds_load_2addr_b32 v[62:63], v55 offset0:122 offset1:139    // 000000124DF4: D8DC8B7A 3E000037
	s_waitcnt lgkmcnt(4)                                       // 000000124DFC: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 000000124E00: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 000000124E08: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:92 offset1:93      // 000000124E10: D8DC5D5C 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:94 offset1:95      // 000000124E18: D8DC5F5E 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:28 offset1:45      // 000000124E20: D8DC2D1C 42000038
	s_waitcnt lgkmcnt(5)                                       // 000000124E28: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 000000124E2C: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000124E34: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 000000124E38: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v56 offset0:62 offset1:79      // 000000124E40: D8DC4F3E 23000038
	s_waitcnt lgkmcnt(4)                                       // 000000124E48: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 000000124E4C: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 000000124E54: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 000000124E5C: D8DC6160 1F00002E
	ds_load_2addr_b32 v[60:61], v56 offset0:96 offset1:113     // 000000124E64: D8DC7160 3C000038
	s_waitcnt lgkmcnt(3)                                       // 000000124E6C: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 000000124E70: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000124E78: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 000000124E7C: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 000000124E84: D8DC6362 2100002E
	ds_load_2addr_b32 v[62:63], v56 offset0:130 offset1:147    // 000000124E8C: D8DC9382 3E000038
	s_waitcnt lgkmcnt(4)                                       // 000000124E94: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 000000124E98: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 000000124EA0: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 000000124EA8: D8DC6564 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:102 offset1:103    // 000000124EB0: D8DC6766 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:164 offset1:181    // 000000124EB8: D8DCB5A4 42000038
	s_waitcnt lgkmcnt(5)                                       // 000000124EC0: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 000000124EC4: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000124ECC: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 000000124ED0: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v56 offset0:198 offset1:215    // 000000124ED8: D8DCD7C6 1F000038
	s_waitcnt lgkmcnt(4)                                       // 000000124EE0: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 000000124EE4: D6130021 24F27D21
	v_fma_f32 v62, -v34, v63, v33                              // 000000124EEC: D613003E 24867F22
	ds_load_2addr_b32 v[33:34], v46 offset0:104 offset1:105    // 000000124EF4: D8DC6968 2100002E
	ds_load_2addr_b32 v[60:61], v56 offset0:232 offset1:249    // 000000124EFC: D8DCF9E8 3C000038
	s_waitcnt lgkmcnt(3)                                       // 000000124F04: BF89FC37
	v_fma_f32 v35, -v35, v66, v62                              // 000000124F08: D6130023 24FA8523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000124F10: BF8700D1
	v_fma_f32 v66, -v36, v67, v35                              // 000000124F14: D6130042 248E8724
	ds_load_2addr_b32 v[35:36], v46 offset0:106 offset1:107    // 000000124F1C: D8DC6B6A 2300002E
	ds_load_2addr_b32 v[62:63], v57 offset0:10 offset1:27      // 000000124F24: D8DC1B0A 3E000039
	s_waitcnt lgkmcnt(4)                                       // 000000124F2C: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 000000124F30: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 000000124F38: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:108 offset1:109    // 000000124F40: D8DC6D6C 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:110 offset1:111    // 000000124F48: D8DC6F6E 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:44 offset1:61      // 000000124F50: D8DC3D2C 42000039
	s_waitcnt lgkmcnt(5)                                       // 000000124F58: BF89FC57
	v_fma_f32 v33, -v33, v60, v68                              // 000000124F5C: D6130021 25127921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000124F64: BF8700C1
	v_fma_f32 v60, -v34, v61, v33                              // 000000124F68: D613003C 24867B22
	ds_load_2addr_b32 v[33:34], v57 offset0:78 offset1:95      // 000000124F70: D8DC5F4E 21000039
	s_waitcnt lgkmcnt(4)                                       // 000000124F78: BF89FC47
	v_fma_f32 v35, -v35, v62, v60                              // 000000124F7C: D6130023 24F27D23
	v_fma_f32 v60, -v36, v63, v35                              // 000000124F84: D613003C 248E7F24
	ds_load_2addr_b32 v[35:36], v46 offset0:112 offset1:113    // 000000124F8C: D8DC7170 2300002E
	s_waitcnt lgkmcnt(2)                                       // 000000124F94: BF89FC27
	v_fma_f32 v31, -v31, v66, v60                              // 000000124F98: D613001F 24F2851F
	ds_load_2addr_b32 v[60:61], v57 offset0:112 offset1:129    // 000000124FA0: D8DC8170 3C000039
	v_fma_f32 v62, -v32, v67, v31                              // 000000124FA8: D613003E 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:114 offset1:115    // 000000124FB0: D8DC7372 1F00002E
	s_waitcnt lgkmcnt(3)                                       // 000000124FB8: BF89FC37
	v_fma_f32 v33, -v64, v33, v62                              // 000000124FBC: D6130021 24FA4340
	ds_load_2addr_b32 v[62:63], v57 offset0:146 offset1:163    // 000000124FC4: D8DCA392 3E000039
	v_fma_f32 v68, -v65, v34, v33                              // 000000124FCC: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:116 offset1:117    // 000000124FD4: D8DC7574 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:118 offset1:119    // 000000124FDC: D8DC7776 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:180 offset1:197    // 000000124FE4: D8DCC5B4 42000039
	s_waitcnt lgkmcnt(5)                                       // 000000124FEC: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 000000124FF0: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000124FF8: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 000000124FFC: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v57 offset0:214 offset1:231    // 000000125004: D8DCE7D6 23000039
	s_waitcnt lgkmcnt(4)                                       // 00000012500C: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 000000125010: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 000000125018: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 000000125020: D8DC7978 1F00002E
	ds_load_2addr_b32 v[60:61], v58 offset0:120 offset1:137    // 000000125028: D8DC8978 3C00003A
	s_waitcnt lgkmcnt(3)                                       // 000000125030: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 000000125034: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000012503C: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 000000125040: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:122 offset1:123    // 000000125048: D8DC7B7A 2100002E
	ds_load_2addr_b32 v[62:63], v59 offset0:26 offset1:43      // 000000125050: D8DC2B1A 3E00003B
	s_waitcnt lgkmcnt(4)                                       // 000000125058: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 00000012505C: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 000000125064: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:124 offset1:125    // 00000012506C: D8DC7D7C 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:126 offset1:127    // 000000125074: D8DC7F7E 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:60 offset1:77      // 00000012507C: D8DC4D3C 4200003B
	s_waitcnt lgkmcnt(5)                                       // 000000125084: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 000000125088: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000125090: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 000000125094: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v59 offset0:94 offset1:111     // 00000012509C: D8DC6F5E 1F00003B
	s_waitcnt lgkmcnt(4)                                       // 0000001250A4: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 0000001250A8: D6130021 24F27D21
	v_fma_f32 v33, -v34, v63, v33                              // 0000001250B0: D6130021 24867F22
	s_waitcnt lgkmcnt(1)                                       // 0000001250B8: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001250BC: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 0000001250C0: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 0000001250C8: D6130021 24868724
	s_waitcnt lgkmcnt(0)                                       // 0000001250D0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001250D4: BF870121
	v_fma_f32 v31, -v64, v31, v33                              // 0000001250D8: D613001F 24863F40
	v_mad_u64_u32 v[33:34], null, 0x44, s10, v[4:5]            // 0000001250E0: D6FE7C21 041014FF 00000044
	v_fma_f32 v31, -v65, v32, v31                              // 0000001250EC: D613001F 247E4141
	ds_store_b32 v33, v31                                      // 0000001250F4: D8340000 00001F21
	s_branch 64845                                             // 0000001250FC: BFA0FD4D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_dual_mov_b32 v30, v14 :: v_dual_mov_b32 v29, v13         // 000000125100: CA10010E 1E1C010D
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v31, v9          // 000000125108: CA10010A 201E0109
	v_mov_b32_e32 v35, v43                                     // 000000125110: 7E46032B
	s_mov_b32 s10, 0                                           // 000000125114: BE8A0080
	s_branch 21                                                // 000000125118: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1070>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000012511C: 8C7E0B7E
	.long 0xd700011f                                           // 000000125120: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 000000125124: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012512C: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 000000125130: D5207C20 00064080
	.long 0xd700011d                                           // 000000125138: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 00000012513C: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 000000125144: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000125148: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 000000125150: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 000000125154: BF08B70A
	s_mov_b32 s10, s1                                          // 000000125158: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 00000012515C: BC7C0000
	s_barrier                                                  // 000000125160: BFBD0000
	buffer_gl0_inv                                             // 000000125164: E0AC0000 00000000
	s_cbranch_scc1 580                                         // 00000012516C: BFA20244 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1980>
	s_delay_alu instid0(VALU_DEP_2)                            // 000000125170: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 000000125174: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 00000012517C: 7E480328
	v_mov_b32_e32 v60, v38                                     // 000000125180: 7E780326
	s_mov_b32 s11, 0                                           // 000000125184: BE8B0080
	s_nop 0                                                    // 000000125188: BF800000
	s_nop 0                                                    // 00000012518C: BF800000
	s_nop 0                                                    // 000000125190: BF800000
	s_nop 0                                                    // 000000125194: BF800000
	s_nop 0                                                    // 000000125198: BF800000
	s_nop 0                                                    // 00000012519C: BF800000
	s_nop 0                                                    // 0000001251A0: BF800000
	s_nop 0                                                    // 0000001251A4: BF800000
	s_nop 0                                                    // 0000001251A8: BF800000
	s_nop 0                                                    // 0000001251AC: BF800000
	s_nop 0                                                    // 0000001251B0: BF800000
	s_nop 0                                                    // 0000001251B4: BF800000
	s_nop 0                                                    // 0000001251B8: BF800000
	s_nop 0                                                    // 0000001251BC: BF800000
	global_load_b32 v61, v[33:34], off                         // 0000001251C0: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000001251C8: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000001251D0: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000001251D4: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001251DC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000001251E0: D5207C22 00064480
	.long 0xd4490004                                           // 0000001251E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000001251EC: 020278FF 0000037F
	s_or_b32 s11, s4, s11                                      // 0000001251F4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 0000001251F8: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 0000001251FC: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 000000125204: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000012520C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000125210: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000125214: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000125218: BF89FC07
	s_barrier                                                  // 00000012521C: BFBD0000
	buffer_gl0_inv                                             // 000000125220: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 000000125228: BE8B2000
	s_cbranch_execz 65467                                      // 00000012522C: BFA5FFBB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x101c>
	v_or_b32_e32 v33, s10, v2                                  // 000000125230: 3842040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125234: BF870091
	v_or_b32_e32 v36, s7, v33                                  // 000000125238: 38484207
	.long 0xd4440001                                           // 00000012523C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 000000125240: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 000000125244: 8B7E017E
	s_cbranch_execz 65460                                      // 000000125248: BFA5FFB4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x101c>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 00000012524C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 000000125254: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 00000012525C: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v46 offset0:2 offset1:3        // 000000125264: D8DC0302 4200002E
	ds_load_2addr_b32 v[68:69], v46 offset0:4 offset1:5        // 00000012526C: D8DC0504 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:6 offset1:7        // 000000125274: D8DC0706 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 00000012527C: D8DC5544 48000001
	s_mov_b32 s12, 0                                           // 000000125284: BE8C0080
	v_lshlrev_b32_e32 v33, 2, v33                              // 000000125288: 30424282
	s_waitcnt lgkmcnt(5)                                       // 00000012528C: BF89FC57
	v_fma_f32 v74, v60, v62, 0                                 // 000000125290: D613004A 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000125298: BF8700C1
	v_fmac_f32_e32 v74, v61, v63                               // 00000012529C: 56947F3D
	ds_load_2addr_b32 v[60:61], v1 offset0:102 offset1:119     // 0000001252A0: D8DC7766 3C000001
	s_waitcnt lgkmcnt(4)                                       // 0000001252A8: BF89FC47
	v_fmac_f32_e32 v74, v66, v64                               // 0000001252AC: 56948142
	v_fmac_f32_e32 v74, v67, v65                               // 0000001252B0: 56948343
	ds_load_2addr_b32 v[62:63], v46 offset0:8 offset1:9        // 0000001252B4: D8DC0908 3E00002E
	ds_load_2addr_b32 v[64:65], v1 offset0:136 offset1:153     // 0000001252BC: D8DC9988 40000001
	s_waitcnt lgkmcnt(3)                                       // 0000001252C4: BF89FC37
	v_fmac_f32_e32 v74, v68, v72                               // 0000001252C8: 56949144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001252CC: BF8700D1
	v_fmac_f32_e32 v74, v69, v73                               // 0000001252D0: 56949345
	ds_load_2addr_b32 v[66:67], v46 offset0:10 offset1:11      // 0000001252D4: D8DC0B0A 4200002E
	ds_load_2addr_b32 v[68:69], v1 offset0:170 offset1:187     // 0000001252DC: D8DCBBAA 44000001
	s_waitcnt lgkmcnt(4)                                       // 0000001252E4: BF89FC47
	v_fmac_f32_e32 v74, v70, v60                               // 0000001252E8: 56947946
	v_fmac_f32_e32 v74, v71, v61                               // 0000001252EC: 56947B47
	ds_load_2addr_b32 v[60:61], v46 offset0:12 offset1:13      // 0000001252F0: D8DC0D0C 3C00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:14 offset1:15      // 0000001252F8: D8DC0F0E 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 000000125300: D8DCDDCC 48000001
	s_waitcnt lgkmcnt(5)                                       // 000000125308: BF89FC57
	v_fmac_f32_e32 v74, v62, v64                               // 00000012530C: 5694813E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000125310: BF8700C1
	v_fmac_f32_e32 v74, v63, v65                               // 000000125314: 5694833F
	ds_load_2addr_b32 v[62:63], v1 offset0:238 offset1:255     // 000000125318: D8DCFFEE 3E000001
	s_waitcnt lgkmcnt(4)                                       // 000000125320: BF89FC47
	v_fmac_f32_e32 v74, v66, v68                               // 000000125324: 56948942
	v_fmac_f32_e32 v74, v67, v69                               // 000000125328: 56948B43
	ds_load_2addr_b32 v[64:65], v46 offset0:16 offset1:17      // 00000012532C: D8DC1110 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:16 offset1:33      // 000000125334: D8DC2110 42000030
	s_waitcnt lgkmcnt(3)                                       // 00000012533C: BF89FC37
	v_fmac_f32_e32 v74, v60, v72                               // 000000125340: 5694913C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000125344: BF8700D1
	v_fmac_f32_e32 v74, v61, v73                               // 000000125348: 5694933D
	ds_load_2addr_b32 v[60:61], v46 offset0:18 offset1:19      // 00000012534C: D8DC1312 3C00002E
	ds_load_2addr_b32 v[68:69], v48 offset0:50 offset1:67      // 000000125354: D8DC4332 44000030
	s_waitcnt lgkmcnt(4)                                       // 00000012535C: BF89FC47
	v_fmac_f32_e32 v74, v70, v62                               // 000000125360: 56947D46
	v_fmac_f32_e32 v74, v71, v63                               // 000000125364: 56947F47
	ds_load_2addr_b32 v[62:63], v46 offset0:20 offset1:21      // 000000125368: D8DC1514 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:22 offset1:23      // 000000125370: D8DC1716 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:84 offset1:101     // 000000125378: D8DC6554 48000030
	s_waitcnt lgkmcnt(5)                                       // 000000125380: BF89FC57
	v_fmac_f32_e32 v74, v64, v66                               // 000000125384: 56948540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000125388: BF8700C1
	v_fmac_f32_e32 v74, v65, v67                               // 00000012538C: 56948741
	ds_load_2addr_b32 v[64:65], v48 offset0:118 offset1:135    // 000000125390: D8DC8776 40000030
	s_waitcnt lgkmcnt(4)                                       // 000000125398: BF89FC47
	v_fmac_f32_e32 v74, v60, v68                               // 00000012539C: 5694893C
	v_fmac_f32_e32 v74, v61, v69                               // 0000001253A0: 56948B3D
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 0000001253A4: D8DC1918 3C00002E
	ds_load_2addr_b32 v[66:67], v48 offset0:152 offset1:169    // 0000001253AC: D8DCA998 42000030
	s_waitcnt lgkmcnt(3)                                       // 0000001253B4: BF89FC37
	v_fmac_f32_e32 v74, v62, v72                               // 0000001253B8: 5694913E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001253BC: BF8700D1
	v_fmac_f32_e32 v74, v63, v73                               // 0000001253C0: 5694933F
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 0000001253C4: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[68:69], v48 offset0:186 offset1:203    // 0000001253CC: D8DCCBBA 44000030
	s_waitcnt lgkmcnt(4)                                       // 0000001253D4: BF89FC47
	v_fmac_f32_e32 v74, v70, v64                               // 0000001253D8: 56948146
	v_fmac_f32_e32 v74, v71, v65                               // 0000001253DC: 56948347
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 0000001253E0: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000001253E8: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:220 offset1:237    // 0000001253F0: D8DCEDDC 48000030
	s_waitcnt lgkmcnt(5)                                       // 0000001253F8: BF89FC57
	v_fmac_f32_e32 v74, v60, v66                               // 0000001253FC: 5694853C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000125400: BF8700C1
	v_fmac_f32_e32 v74, v61, v67                               // 000000125404: 5694873D
	ds_load_2addr_b32 v[60:61], v49 offset0:126 offset1:143    // 000000125408: D8DC8F7E 3C000031
	s_waitcnt lgkmcnt(4)                                       // 000000125410: BF89FC47
	v_fmac_f32_e32 v74, v62, v68                               // 000000125414: 5694893E
	v_fmac_f32_e32 v74, v63, v69                               // 000000125418: 56948B3F
	ds_load_2addr_b32 v[62:63], v46 offset0:32 offset1:33      // 00000012541C: D8DC2120 3E00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 000000125424: D8DC3120 42000032
	s_waitcnt lgkmcnt(3)                                       // 00000012542C: BF89FC37
	v_fmac_f32_e32 v74, v64, v72                               // 000000125430: 56949140
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000125434: BF8700D1
	v_fmac_f32_e32 v74, v65, v73                               // 000000125438: 56949341
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 00000012543C: D8DC2322 4000002E
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 000000125444: D8DC5342 44000032
	s_waitcnt lgkmcnt(4)                                       // 00000012544C: BF89FC47
	v_fmac_f32_e32 v74, v70, v60                               // 000000125450: 56947946
	v_fmac_f32_e32 v74, v71, v61                               // 000000125454: 56947B47
	ds_load_2addr_b32 v[60:61], v46 offset0:36 offset1:37      // 000000125458: D8DC2524 3C00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:38 offset1:39      // 000000125460: D8DC2726 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 000000125468: D8DC7564 48000032
	s_waitcnt lgkmcnt(5)                                       // 000000125470: BF89FC57
	v_fmac_f32_e32 v74, v62, v66                               // 000000125474: 5694853E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000125478: BF8700C1
	v_fmac_f32_e32 v74, v63, v67                               // 00000012547C: 5694873F
	ds_load_2addr_b32 v[62:63], v50 offset0:134 offset1:151    // 000000125480: D8DC9786 3E000032
	s_waitcnt lgkmcnt(4)                                       // 000000125488: BF89FC47
	v_fmac_f32_e32 v74, v64, v68                               // 00000012548C: 56948940
	v_fmac_f32_e32 v74, v65, v69                               // 000000125490: 56948B41
	ds_load_2addr_b32 v[64:65], v46 offset0:40 offset1:41      // 000000125494: D8DC2928 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:168 offset1:185    // 00000012549C: D8DCB9A8 42000032
	s_waitcnt lgkmcnt(3)                                       // 0000001254A4: BF89FC37
	v_fmac_f32_e32 v74, v60, v72                               // 0000001254A8: 5694913C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001254AC: BF8700D1
	v_fmac_f32_e32 v74, v61, v73                               // 0000001254B0: 5694933D
	ds_load_2addr_b32 v[60:61], v46 offset0:42 offset1:43      // 0000001254B4: D8DC2B2A 3C00002E
	ds_load_2addr_b32 v[68:69], v50 offset0:202 offset1:219    // 0000001254BC: D8DCDBCA 44000032
	s_waitcnt lgkmcnt(4)                                       // 0000001254C4: BF89FC47
	v_fmac_f32_e32 v74, v70, v62                               // 0000001254C8: 56947D46
	v_fmac_f32_e32 v74, v71, v63                               // 0000001254CC: 56947F47
	ds_load_2addr_b32 v[62:63], v46 offset0:44 offset1:45      // 0000001254D0: D8DC2D2C 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:46 offset1:47      // 0000001254D8: D8DC2F2E 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:236 offset1:253    // 0000001254E0: D8DCFDEC 48000032
	s_waitcnt lgkmcnt(5)                                       // 0000001254E8: BF89FC57
	v_fmac_f32_e32 v74, v64, v66                               // 0000001254EC: 56948540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001254F0: BF8700C1
	v_fmac_f32_e32 v74, v65, v67                               // 0000001254F4: 56948741
	ds_load_2addr_b32 v[64:65], v51 offset0:14 offset1:31      // 0000001254F8: D8DC1F0E 40000033
	s_waitcnt lgkmcnt(4)                                       // 000000125500: BF89FC47
	v_fmac_f32_e32 v74, v60, v68                               // 000000125504: 5694893C
	v_fmac_f32_e32 v74, v61, v69                               // 000000125508: 56948B3D
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 00000012550C: D8DC3130 3C00002E
	ds_load_2addr_b32 v[66:67], v51 offset0:48 offset1:65      // 000000125514: D8DC4130 42000033
	s_waitcnt lgkmcnt(3)                                       // 00000012551C: BF89FC37
	v_fmac_f32_e32 v74, v62, v72                               // 000000125520: 5694913E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000125524: BF8700D1
	v_fmac_f32_e32 v74, v63, v73                               // 000000125528: 5694933F
	ds_load_2addr_b32 v[62:63], v46 offset0:50 offset1:51      // 00000012552C: D8DC3332 3E00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:82 offset1:99      // 000000125534: D8DC6352 44000033
	s_waitcnt lgkmcnt(4)                                       // 00000012553C: BF89FC47
	v_fmac_f32_e32 v74, v70, v64                               // 000000125540: 56948146
	v_fmac_f32_e32 v74, v71, v65                               // 000000125544: 56948347
	ds_load_2addr_b32 v[64:65], v46 offset0:52 offset1:53      // 000000125548: D8DC3534 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:54 offset1:55      // 000000125550: D8DC3736 4600002E
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 000000125558: D8DC8574 48000033
	s_waitcnt lgkmcnt(5)                                       // 000000125560: BF89FC57
	v_fmac_f32_e32 v74, v60, v66                               // 000000125564: 5694853C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000125568: BF8700C1
	v_fmac_f32_e32 v74, v61, v67                               // 00000012556C: 5694873D
	ds_load_2addr_b32 v[60:61], v51 offset0:150 offset1:167    // 000000125570: D8DCA796 3C000033
	s_waitcnt lgkmcnt(4)                                       // 000000125578: BF89FC47
	v_fmac_f32_e32 v74, v62, v68                               // 00000012557C: 5694893E
	v_fmac_f32_e32 v74, v63, v69                               // 000000125580: 56948B3F
	ds_load_2addr_b32 v[62:63], v46 offset0:56 offset1:57      // 000000125584: D8DC3938 3E00002E
	ds_load_2addr_b32 v[66:67], v51 offset0:184 offset1:201    // 00000012558C: D8DCC9B8 42000033
	s_waitcnt lgkmcnt(3)                                       // 000000125594: BF89FC37
	v_fmac_f32_e32 v74, v64, v72                               // 000000125598: 56949140
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000012559C: BF8700D1
	v_fmac_f32_e32 v74, v65, v73                               // 0000001255A0: 56949341
	ds_load_2addr_b32 v[64:65], v46 offset0:58 offset1:59      // 0000001255A4: D8DC3B3A 4000002E
	ds_load_2addr_b32 v[68:69], v51 offset0:218 offset1:235    // 0000001255AC: D8DCEBDA 44000033
	s_waitcnt lgkmcnt(4)                                       // 0000001255B4: BF89FC47
	v_fmac_f32_e32 v74, v70, v60                               // 0000001255B8: 56947946
	v_fmac_f32_e32 v74, v71, v61                               // 0000001255BC: 56947B47
	ds_load_2addr_b32 v[60:61], v46 offset0:60 offset1:61      // 0000001255C0: D8DC3D3C 3C00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:62 offset1:63      // 0000001255C8: D8DC3F3E 4600002E
	ds_load_2addr_b32 v[72:73], v52 offset0:124 offset1:141    // 0000001255D0: D8DC8D7C 48000034
	s_waitcnt lgkmcnt(5)                                       // 0000001255D8: BF89FC57
	v_fmac_f32_e32 v74, v62, v66                               // 0000001255DC: 5694853E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001255E0: BF8700C1
	v_fmac_f32_e32 v74, v63, v67                               // 0000001255E4: 5694873F
	ds_load_2addr_b32 v[62:63], v53 offset0:30 offset1:47      // 0000001255E8: D8DC2F1E 3E000035
	s_waitcnt lgkmcnt(4)                                       // 0000001255F0: BF89FC47
	v_fmac_f32_e32 v74, v64, v68                               // 0000001255F4: 56948940
	v_fmac_f32_e32 v74, v65, v69                               // 0000001255F8: 56948B41
	ds_load_2addr_b32 v[64:65], v46 offset0:64 offset1:65      // 0000001255FC: D8DC4140 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:64 offset1:81      // 000000125604: D8DC5140 42000035
	s_waitcnt lgkmcnt(3)                                       // 00000012560C: BF89FC37
	v_fmac_f32_e32 v74, v60, v72                               // 000000125610: 5694913C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000125614: BF8700D1
	v_fmac_f32_e32 v74, v61, v73                               // 000000125618: 5694933D
	ds_load_2addr_b32 v[60:61], v46 offset0:66 offset1:67      // 00000012561C: D8DC4342 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:98 offset1:115     // 000000125624: D8DC7362 44000035
	s_waitcnt lgkmcnt(4)                                       // 00000012562C: BF89FC47
	v_fmac_f32_e32 v74, v70, v62                               // 000000125630: 56947D46
	v_fmac_f32_e32 v74, v71, v63                               // 000000125634: 56947F47
	ds_load_2addr_b32 v[62:63], v46 offset0:68 offset1:69      // 000000125638: D8DC4544 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:70 offset1:71      // 000000125640: D8DC4746 4600002E
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 000000125648: D8DC9584 48000035
	s_waitcnt lgkmcnt(5)                                       // 000000125650: BF89FC57
	v_fmac_f32_e32 v74, v64, v66                               // 000000125654: 56948540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000125658: BF8700C1
	v_fmac_f32_e32 v74, v65, v67                               // 00000012565C: 56948741
	ds_load_2addr_b32 v[64:65], v53 offset0:166 offset1:183    // 000000125660: D8DCB7A6 40000035
	s_waitcnt lgkmcnt(4)                                       // 000000125668: BF89FC47
	v_fmac_f32_e32 v74, v60, v68                               // 00000012566C: 5694893C
	v_fmac_f32_e32 v74, v61, v69                               // 000000125670: 56948B3D
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 000000125674: D8DC4948 3C00002E
	ds_load_2addr_b32 v[66:67], v53 offset0:200 offset1:217    // 00000012567C: D8DCD9C8 42000035
	s_waitcnt lgkmcnt(3)                                       // 000000125684: BF89FC37
	v_fmac_f32_e32 v74, v62, v72                               // 000000125688: 5694913E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000012568C: BF8700D1
	v_fmac_f32_e32 v74, v63, v73                               // 000000125690: 5694933F
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 000000125694: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:234 offset1:251    // 00000012569C: D8DCFBEA 44000035
	s_waitcnt lgkmcnt(4)                                       // 0000001256A4: BF89FC47
	v_fmac_f32_e32 v74, v70, v64                               // 0000001256A8: 56948146
	v_fmac_f32_e32 v74, v71, v65                               // 0000001256AC: 56948347
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 0000001256B0: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:78 offset1:79      // 0000001256B8: D8DC4F4E 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:12 offset1:29      // 0000001256C0: D8DC1D0C 48000036
	s_waitcnt lgkmcnt(5)                                       // 0000001256C8: BF89FC57
	v_fmac_f32_e32 v74, v60, v66                               // 0000001256CC: 5694853C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001256D0: BF8700C1
	v_fmac_f32_e32 v74, v61, v67                               // 0000001256D4: 5694873D
	ds_load_2addr_b32 v[60:61], v54 offset0:46 offset1:63      // 0000001256D8: D8DC3F2E 3C000036
	s_waitcnt lgkmcnt(4)                                       // 0000001256E0: BF89FC47
	v_fmac_f32_e32 v74, v62, v68                               // 0000001256E4: 5694893E
	v_fmac_f32_e32 v74, v63, v69                               // 0000001256E8: 56948B3F
	ds_load_2addr_b32 v[62:63], v46 offset0:80 offset1:81      // 0000001256EC: D8DC5150 3E00002E
	ds_load_2addr_b32 v[66:67], v54 offset0:80 offset1:97      // 0000001256F4: D8DC6150 42000036
	s_waitcnt lgkmcnt(3)                                       // 0000001256FC: BF89FC37
	v_fmac_f32_e32 v74, v64, v72                               // 000000125700: 56949140
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000125704: BF8700D1
	v_fmac_f32_e32 v74, v65, v73                               // 000000125708: 56949341
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 00000012570C: D8DC5352 4000002E
	ds_load_2addr_b32 v[68:69], v54 offset0:114 offset1:131    // 000000125714: D8DC8372 44000036
	s_waitcnt lgkmcnt(4)                                       // 00000012571C: BF89FC47
	v_fmac_f32_e32 v74, v70, v60                               // 000000125720: 56947946
	v_fmac_f32_e32 v74, v71, v61                               // 000000125724: 56947B47
	ds_load_2addr_b32 v[60:61], v46 offset0:84 offset1:85      // 000000125728: D8DC5554 3C00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:86 offset1:87      // 000000125730: D8DC5756 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 000000125738: D8DCA594 48000036
	s_waitcnt lgkmcnt(5)                                       // 000000125740: BF89FC57
	v_fmac_f32_e32 v74, v62, v66                               // 000000125744: 5694853E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000125748: BF8700C1
	v_fmac_f32_e32 v74, v63, v67                               // 00000012574C: 5694873F
	ds_load_2addr_b32 v[62:63], v54 offset0:182 offset1:199    // 000000125750: D8DCC7B6 3E000036
	s_waitcnt lgkmcnt(4)                                       // 000000125758: BF89FC47
	v_fmac_f32_e32 v74, v64, v68                               // 00000012575C: 56948940
	v_fmac_f32_e32 v74, v65, v69                               // 000000125760: 56948B41
	ds_load_2addr_b32 v[64:65], v46 offset0:88 offset1:89      // 000000125764: D8DC5958 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:216 offset1:233    // 00000012576C: D8DCE9D8 42000036
	s_waitcnt lgkmcnt(3)                                       // 000000125774: BF89FC37
	v_fmac_f32_e32 v74, v60, v72                               // 000000125778: 5694913C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000012577C: BF8700D1
	v_fmac_f32_e32 v74, v61, v73                               // 000000125780: 5694933D
	ds_load_2addr_b32 v[60:61], v46 offset0:90 offset1:91      // 000000125784: D8DC5B5A 3C00002E
	ds_load_2addr_b32 v[68:69], v55 offset0:122 offset1:139    // 00000012578C: D8DC8B7A 44000037
	s_waitcnt lgkmcnt(4)                                       // 000000125794: BF89FC47
	v_fmac_f32_e32 v74, v70, v62                               // 000000125798: 56947D46
	v_fmac_f32_e32 v74, v71, v63                               // 00000012579C: 56947F47
	ds_load_2addr_b32 v[62:63], v46 offset0:92 offset1:93      // 0000001257A0: D8DC5D5C 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:94 offset1:95      // 0000001257A8: D8DC5F5E 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:28 offset1:45      // 0000001257B0: D8DC2D1C 48000038
	s_waitcnt lgkmcnt(5)                                       // 0000001257B8: BF89FC57
	v_fmac_f32_e32 v74, v64, v66                               // 0000001257BC: 56948540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001257C0: BF8700C1
	v_fmac_f32_e32 v74, v65, v67                               // 0000001257C4: 56948741
	ds_load_2addr_b32 v[64:65], v56 offset0:62 offset1:79      // 0000001257C8: D8DC4F3E 40000038
	s_waitcnt lgkmcnt(4)                                       // 0000001257D0: BF89FC47
	v_fmac_f32_e32 v74, v60, v68                               // 0000001257D4: 5694893C
	v_fmac_f32_e32 v74, v61, v69                               // 0000001257D8: 56948B3D
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 0000001257DC: D8DC6160 3C00002E
	ds_load_2addr_b32 v[66:67], v56 offset0:96 offset1:113     // 0000001257E4: D8DC7160 42000038
	s_waitcnt lgkmcnt(3)                                       // 0000001257EC: BF89FC37
	v_fmac_f32_e32 v74, v62, v72                               // 0000001257F0: 5694913E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001257F4: BF8700D1
	v_fmac_f32_e32 v74, v63, v73                               // 0000001257F8: 5694933F
	ds_load_2addr_b32 v[62:63], v46 offset0:98 offset1:99      // 0000001257FC: D8DC6362 3E00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:130 offset1:147    // 000000125804: D8DC9382 44000038
	s_waitcnt lgkmcnt(4)                                       // 00000012580C: BF89FC47
	v_fmac_f32_e32 v74, v70, v64                               // 000000125810: 56948146
	v_fmac_f32_e32 v74, v71, v65                               // 000000125814: 56948347
	ds_load_2addr_b32 v[64:65], v46 offset0:100 offset1:101    // 000000125818: D8DC6564 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:102 offset1:103    // 000000125820: D8DC6766 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 000000125828: D8DCB5A4 48000038
	s_waitcnt lgkmcnt(5)                                       // 000000125830: BF89FC57
	v_fmac_f32_e32 v74, v60, v66                               // 000000125834: 5694853C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000125838: BF8700C1
	v_fmac_f32_e32 v74, v61, v67                               // 00000012583C: 5694873D
	ds_load_2addr_b32 v[60:61], v56 offset0:198 offset1:215    // 000000125840: D8DCD7C6 3C000038
	s_waitcnt lgkmcnt(4)                                       // 000000125848: BF89FC47
	v_fmac_f32_e32 v74, v62, v68                               // 00000012584C: 5694893E
	v_fmac_f32_e32 v74, v63, v69                               // 000000125850: 56948B3F
	ds_load_2addr_b32 v[62:63], v46 offset0:104 offset1:105    // 000000125854: D8DC6968 3E00002E
	ds_load_2addr_b32 v[66:67], v56 offset0:232 offset1:249    // 00000012585C: D8DCF9E8 42000038
	s_waitcnt lgkmcnt(3)                                       // 000000125864: BF89FC37
	v_fmac_f32_e32 v74, v64, v72                               // 000000125868: 56949140
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000012586C: BF8700D1
	v_fmac_f32_e32 v74, v65, v73                               // 000000125870: 56949341
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 000000125874: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[68:69], v57 offset0:10 offset1:27      // 00000012587C: D8DC1B0A 44000039
	s_waitcnt lgkmcnt(4)                                       // 000000125884: BF89FC47
	v_fmac_f32_e32 v74, v70, v60                               // 000000125888: 56947946
	v_fmac_f32_e32 v74, v71, v61                               // 00000012588C: 56947B47
	ds_load_2addr_b32 v[60:61], v46 offset0:108 offset1:109    // 000000125890: D8DC6D6C 3C00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:110 offset1:111    // 000000125898: D8DC6F6E 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:44 offset1:61      // 0000001258A0: D8DC3D2C 48000039
	s_waitcnt lgkmcnt(5)                                       // 0000001258A8: BF89FC57
	v_fmac_f32_e32 v74, v62, v66                               // 0000001258AC: 5694853E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001258B0: BF8700C1
	v_fmac_f32_e32 v74, v63, v67                               // 0000001258B4: 5694873F
	ds_load_2addr_b32 v[62:63], v57 offset0:78 offset1:95      // 0000001258B8: D8DC5F4E 3E000039
	s_waitcnt lgkmcnt(4)                                       // 0000001258C0: BF89FC47
	v_fmac_f32_e32 v74, v64, v68                               // 0000001258C4: 56948940
	v_fmac_f32_e32 v74, v65, v69                               // 0000001258C8: 56948B41
	ds_load_2addr_b32 v[64:65], v46 offset0:112 offset1:113    // 0000001258CC: D8DC7170 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:112 offset1:129    // 0000001258D4: D8DC8170 42000039
	s_waitcnt lgkmcnt(3)                                       // 0000001258DC: BF89FC37
	v_fmac_f32_e32 v74, v60, v72                               // 0000001258E0: 5694913C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001258E4: BF8700D1
	v_fmac_f32_e32 v74, v61, v73                               // 0000001258E8: 5694933D
	ds_load_2addr_b32 v[60:61], v46 offset0:114 offset1:115    // 0000001258EC: D8DC7372 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:146 offset1:163    // 0000001258F4: D8DCA392 44000039
	s_waitcnt lgkmcnt(4)                                       // 0000001258FC: BF89FC47
	v_fmac_f32_e32 v74, v70, v62                               // 000000125900: 56947D46
	v_fmac_f32_e32 v74, v71, v63                               // 000000125904: 56947F47
	ds_load_2addr_b32 v[62:63], v46 offset0:116 offset1:117    // 000000125908: D8DC7574 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:118 offset1:119    // 000000125910: D8DC7776 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 000000125918: D8DCC5B4 48000039
	s_waitcnt lgkmcnt(5)                                       // 000000125920: BF89FC57
	v_fmac_f32_e32 v74, v64, v66                               // 000000125924: 56948540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000125928: BF8700C1
	v_fmac_f32_e32 v74, v65, v67                               // 00000012592C: 56948741
	ds_load_2addr_b32 v[64:65], v57 offset0:214 offset1:231    // 000000125930: D8DCE7D6 40000039
	s_waitcnt lgkmcnt(4)                                       // 000000125938: BF89FC47
	v_fmac_f32_e32 v74, v60, v68                               // 00000012593C: 5694893C
	v_fmac_f32_e32 v74, v61, v69                               // 000000125940: 56948B3D
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 000000125944: D8DC7978 3C00002E
	ds_load_2addr_b32 v[66:67], v58 offset0:120 offset1:137    // 00000012594C: D8DC8978 4200003A
	s_waitcnt lgkmcnt(3)                                       // 000000125954: BF89FC37
	v_fmac_f32_e32 v74, v62, v72                               // 000000125958: 5694913E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000012595C: BF8700D1
	v_fmac_f32_e32 v74, v63, v73                               // 000000125960: 5694933F
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 000000125964: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[68:69], v59 offset0:26 offset1:43      // 00000012596C: D8DC2B1A 4400003B
	s_waitcnt lgkmcnt(4)                                       // 000000125974: BF89FC47
	v_fmac_f32_e32 v74, v70, v64                               // 000000125978: 56948146
	v_fmac_f32_e32 v74, v71, v65                               // 00000012597C: 56948347
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 000000125980: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:126 offset1:127    // 000000125988: D8DC7F7E 4600002E
	ds_load_2addr_b32 v[72:73], v59 offset0:60 offset1:77      // 000000125990: D8DC4D3C 4800003B
	s_waitcnt lgkmcnt(5)                                       // 000000125998: BF89FC57
	v_fmac_f32_e32 v74, v60, v66                               // 00000012599C: 5694853C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001259A0: BF870001
	v_fmac_f32_e32 v74, v61, v67                               // 0000001259A4: 5694873D
	ds_load_2addr_b32 v[60:61], v59 offset0:94 offset1:111     // 0000001259A8: D8DC6F5E 3C00003B
	s_waitcnt lgkmcnt(4)                                       // 0000001259B0: BF89FC47
	v_fmac_f32_e32 v74, v62, v68                               // 0000001259B4: 5694893E
	ds_load_b32 v62, v33 offset:17440                          // 0000001259B8: D8D84420 3E000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000001259C0: CA10011E 2220011D
	v_fmac_f32_e32 v74, v63, v69                               // 0000001259C8: 56948B3F
	s_waitcnt lgkmcnt(2)                                       // 0000001259CC: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001259D0: BF870091
	v_fmac_f32_e32 v74, v64, v72                               // 0000001259D4: 56949140
	v_fmac_f32_e32 v74, v65, v73                               // 0000001259D8: 56949341
	s_waitcnt lgkmcnt(1)                                       // 0000001259DC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001259E0: BF870091
	v_fmac_f32_e32 v74, v70, v60                               // 0000001259E4: 56947946
	v_dual_fmac_f32 v74, v71, v61 :: v_dual_mov_b32 v61, v1    // 0000001259E8: C8107B47 4A3C0101
	s_waitcnt lgkmcnt(0)                                       // 0000001259F0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001259F4: BF870001
	v_mul_f32_e32 v60, v74, v62                                // 0000001259F8: 10787D4A
	v_mov_b32_e32 v62, v35                                     // 0000001259FC: 7E7C0323
	global_load_b32 v63, v[33:34], off                         // 000000125A00: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 000000125A08: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 000000125A10: 4A7C7CC1
	.long 0xd7000121                                           // 000000125A14: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 000000125A18: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000125A1C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 000000125A20: D5207C22 00064480
	.long 0xd44a0004                                           // 000000125A28: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 000000125A2C: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 000000125A30: 4A7A7AFF 00000044
	s_or_b32 s12, s4, s12                                      // 000000125A38: 8C0C0C04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000125A3C: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 000000125A40: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 000000125A44: 917E0C7E
	s_cbranch_execnz 65517                                     // 000000125A48: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1900>
	s_or_b32 exec_lo, exec_lo, s12                             // 000000125A4C: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125A50: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 000000125A54: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 000000125A5C: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 000000125A68: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 000000125A74: DC960000 007C2421
	s_branch 64935                                             // 000000125A7C: BFA0FDA7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x101c>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 000000125A80: A201FF06 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 000000125A88: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000125A8C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 000000125A90: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 000000125A98: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 000000125A9C: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 000000125AA4: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 000000125AAC: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000125AB0: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 000000125AB4: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 000000125ABC: A0010401
	s_mov_b32 s4, 0                                            // 000000125AC0: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 000000125AC4: BF87000A
	v_exp_f32_e32 v29, s1                                      // 000000125AC8: 7E3A4A01
	s_cvt_i32_f32 s1, s7                                       // 000000125ACC: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000125AD0: BF870585
	.long 0xd71c001d                                           // 000000125AD4: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 000000125AD8: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 000000125ADC: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 000000125AE0: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000125AE8: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 000000125AEC: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 000000125AF4: 980180C1
	v_mov_b32_e32 v29, v37                                     // 000000125AF8: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 000000125AFC: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 000000125B08: D8D80000 2000001D
	s_waitcnt lgkmcnt(0)                                       // 000000125B10: BF89FC07
	v_dual_mul_f32 v32, v30, v32 :: v_dual_add_nc_u32 v31, 0x80, v31// 000000125B14: C8E0411E 201E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000125B20: BF8704C1
	.long 0xd4490001                                           // 000000125B24: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 000000125B28: 02023EFF 0000077F
	ds_store_b32 v29, v32                                      // 000000125B30: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 000000125B38: 4A3A3AFF 00000220
	s_or_b32 s4, s1, s4                                        // 000000125B40: 8C040401
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000125B44: 917E047E
	s_cbranch_execnz 65519                                     // 000000125B48: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a08>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000125B4C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 000000125B50: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 000000125B58: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 000000125B60: 7E420326
	s_mov_b32 s6, 0                                            // 000000125B64: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000125B68: BF89FC07
	s_barrier                                                  // 000000125B6C: BFBD0000
	buffer_gl0_inv                                             // 000000125B70: E0AC0000 00000000
	s_nop 0                                                    // 000000125B78: BF800000
	s_nop 0                                                    // 000000125B7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000125B80: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 000000125B88: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000125B90: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000125B98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000125B9C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 000000125BA4: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000125BA8: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000125BB0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000125BB4: 10444722
	.long 0xd4490004                                           // 000000125BB8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000125BBC: 020242FF 0000037F
	ds_store_b32 v32, v34 offset:13056                         // 000000125BC4: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 000000125BCC: 4A4040FF 00000204
	s_or_b32 s6, s4, s6                                        // 000000125BD4: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000125BD8: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000125BDC: 917E067E
	s_cbranch_execnz 65511                                     // 000000125BE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a80>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000125BE4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000125BE8: BF89FC07
	s_barrier                                                  // 000000125BEC: BFBD0000
	buffer_gl0_inv                                             // 000000125BF0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 000000125BF8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 000000125C00: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 000000125C08: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 000000125C10: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 000000125C18: 7E780300
	s_mov_b32 s4, 0                                            // 000000125C1C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000125C20: BF840001
	s_nop 0                                                    // 000000125C24: BF800000
	s_nop 0                                                    // 000000125C28: BF800000
	s_nop 0                                                    // 000000125C2C: BF800000
	s_nop 0                                                    // 000000125C30: BF800000
	s_nop 0                                                    // 000000125C34: BF800000
	s_nop 0                                                    // 000000125C38: BF800000
	s_nop 0                                                    // 000000125C3C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125C40: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000125C44: 327A7884
	.long 0xd4490001                                           // 000000125C48: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000125C4C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000125C54: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000125C58: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000125C64: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000125C68: 4A7C88FF 00003200
	ds_load_b32 v69, v61                                       // 000000125C70: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000125C78: D8DCC140 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 000000125C80: BF89FC07
	v_fmac_f32_e32 v69, v62, v29                               // 000000125C84: 568A3B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000125C88: BF870001
	v_dual_fmac_f32 v69, v63, v30 :: v_dual_add_nc_u32 v66, 0x3a00, v68// 000000125C8C: C8203D3F 454288FF 00003A00
	v_add_nc_u32_e32 v62, 0x3e00, v68                          // 000000125C98: 4A7C88FF 00003E00
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000125CA0: D8DCC544 42000042
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000125CA8: 4A8088FF 00003600
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000125CB0: D8DCC746 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000125CB8: D8DCC342 40000040
	s_waitcnt lgkmcnt(0)                                       // 000000125CC0: BF89FC07
	v_fmac_f32_e32 v69, v64, v31                               // 000000125CC4: 568A3F40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125CC8: BF870091
	v_fmac_f32_e32 v69, v65, v32                               // 000000125CCC: 568A4141
	v_fmac_f32_e32 v69, v66, v33                               // 000000125CD0: 568A4342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125CD4: BF870091
	v_fmac_f32_e32 v69, v67, v34                               // 000000125CD8: 568A4543
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000125CDC: C820473E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000125CE8: BF870001
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000125CEC: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000125CF4: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000125CFC: 917E047E
	s_cbranch_execnz 65487                                     // 000000125D00: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b40>
	s_set_inst_prefetch_distance 0x2                           // 000000125D04: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000125D08: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 000000125D0C: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000125D14: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000125D1C: 7E420326
	s_mov_b32 s6, 0                                            // 000000125D20: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000125D24: BF89FC07
	s_barrier                                                  // 000000125D28: BFBD0000
	buffer_gl0_inv                                             // 000000125D2C: E0AC0000 00000000
	s_nop 0                                                    // 000000125D34: BF800000
	s_nop 0                                                    // 000000125D38: BF800000
	s_nop 0                                                    // 000000125D3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000125D40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 000000125D48: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000125D50: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000125D58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000125D5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000125D64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000125D68: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000125D70: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000125D74: 10444722
	.long 0xd4490004                                           // 000000125D78: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000125D7C: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000125D84: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000125D8C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000125D94: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000125D98: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000125D9C: 917E067E
	s_cbranch_execnz 65511                                     // 000000125DA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c40>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000125DA4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000125DA8: BF89FC07
	s_barrier                                                  // 000000125DAC: BFBD0000
	buffer_gl0_inv                                             // 000000125DB0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 000000125DB8: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 000000125DC0: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 000000125DC8: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 000000125DD0: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 000000125DD8: 7E780300
	s_mov_b32 s4, 0                                            // 000000125DDC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000125DE0: BF840001
	s_nop 0                                                    // 000000125DE4: BF800000
	s_nop 0                                                    // 000000125DE8: BF800000
	s_nop 0                                                    // 000000125DEC: BF800000
	s_nop 0                                                    // 000000125DF0: BF800000
	s_nop 0                                                    // 000000125DF4: BF800000
	s_nop 0                                                    // 000000125DF8: BF800000
	s_nop 0                                                    // 000000125DFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000125E00: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000125E04: 327A7884
	.long 0xd4490001                                           // 000000125E08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000125E0C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000125E14: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000125E18: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000125E24: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000125E28: 4A7C88FF 00003200
	ds_load_b32 v69, v61                                       // 000000125E30: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000125E38: D8DCC140 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 000000125E40: BF89FC07
	v_fmac_f32_e32 v69, v62, v29                               // 000000125E44: 568A3B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000125E48: BF870001
	v_dual_fmac_f32 v69, v63, v30 :: v_dual_add_nc_u32 v66, 0x3a00, v68// 000000125E4C: C8203D3F 454288FF 00003A00
	v_add_nc_u32_e32 v62, 0x3e00, v68                          // 000000125E58: 4A7C88FF 00003E00
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000125E60: D8DCC544 42000042
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000125E68: 4A8088FF 00003600
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000125E70: D8DCC746 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000125E78: D8DCC342 40000040
	s_waitcnt lgkmcnt(0)                                       // 000000125E80: BF89FC07
	v_fmac_f32_e32 v69, v64, v31                               // 000000125E84: 568A3F40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125E88: BF870091
	v_fmac_f32_e32 v69, v65, v32                               // 000000125E8C: 568A4141
	v_fmac_f32_e32 v69, v66, v33                               // 000000125E90: 568A4342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000125E94: BF870091
	v_fmac_f32_e32 v69, v67, v34                               // 000000125E98: 568A4543
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000125E9C: C820473E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000125EA8: BF870001
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000125EAC: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000125EB4: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000125EBC: 917E047E
	s_cbranch_execnz 65487                                     // 000000125EC0: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d00>
	s_set_inst_prefetch_distance 0x2                           // 000000125EC4: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000125EC8: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 000000125ECC: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000125ED4: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000125EDC: 7E420326
	s_mov_b32 s6, 0                                            // 000000125EE0: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000125EE4: BF89FC07
	s_barrier                                                  // 000000125EE8: BFBD0000
	buffer_gl0_inv                                             // 000000125EEC: E0AC0000 00000000
	s_nop 0                                                    // 000000125EF4: BF800000
	s_nop 0                                                    // 000000125EF8: BF800000
	s_nop 0                                                    // 000000125EFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000125F00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 000000125F08: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000125F10: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000125F18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000125F1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000125F24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000125F28: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000125F30: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000125F34: 10444722
	.long 0xd4490004                                           // 000000125F38: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000125F3C: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000125F44: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000125F4C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000125F54: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000125F58: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000125F5C: 917E067E
	s_cbranch_execnz 65511                                     // 000000125F60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e00>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000125F64: 8C7E067E
	v_dual_mov_b32 v61, v0 :: v_dual_add_nc_u32 v60, 0x400, v47// 000000125F68: CA200100 3D3C5EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000125F74: BF89FC07
	s_barrier                                                  // 000000125F78: BFBD0000
	buffer_gl0_inv                                             // 000000125F7C: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 000000125F84: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 000000125F8C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 000000125F94: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 000000125F9C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 000000125FA4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000125FA8: BF840001
	s_nop 0                                                    // 000000125FAC: BF800000
	s_nop 0                                                    // 000000125FB0: BF800000
	s_nop 0                                                    // 000000125FB4: BF800000
	s_nop 0                                                    // 000000125FB8: BF800000
	s_nop 0                                                    // 000000125FBC: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000125FC0: 327C7A84
	.long 0xd4490001                                           // 000000125FC4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000125FC8: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000125FD0: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000125FD4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000125FD8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000125FE4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000125FE8: 4A7E8AFF 00003200
	ds_load_b32 v70, v62                                       // 000000125FF0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000125FF8: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000126000: BF89FC07
	v_fmac_f32_e32 v70, v63, v29                               // 000000126004: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000126008: BF870001
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v65, 0x3600, v69// 00000012600C: C8203D40 46408AFF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000126018: D8DCC342 41000041
	s_waitcnt lgkmcnt(0)                                       // 000000126020: BF89FC07
	v_dual_fmac_f32 v70, v65, v31 :: v_dual_add_nc_u32 v67, 0x3a00, v69// 000000126024: C8203F41 46428AFF 00003A00
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000126030: D8DCC544 43000043
	v_fmac_f32_e32 v70, v66, v32                               // 000000126038: 568C4142
	s_waitcnt lgkmcnt(0)                                       // 00000012603C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126040: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000126044: 568C4343
	v_dual_fmac_f32 v70, v68, v34 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000126048: C8204544 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000126054: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 00000012605C: BF89FC07
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000126060: C820473F 463E7AFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012606C: BF870001
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000126070: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000126078: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000126080: 917E047E
	s_cbranch_execnz 65486                                     // 000000126084: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ec0>
	s_set_inst_prefetch_distance 0x2                           // 000000126088: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012608C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 000000126090: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000126098: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000001260A0: 7E420326
	s_mov_b32 s6, 0                                            // 0000001260A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000001260A8: BF89FC07
	s_barrier                                                  // 0000001260AC: BFBD0000
	buffer_gl0_inv                                             // 0000001260B0: E0AC0000 00000000
	s_nop 0                                                    // 0000001260B8: BF800000
	s_nop 0                                                    // 0000001260BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000001260C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 0000001260C8: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000001260D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000001260D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000001260DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000001260E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000001260E8: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001260F0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000001260F4: 10444722
	.long 0xd4490004                                           // 0000001260F8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000001260FC: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000126104: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012610C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000126114: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000126118: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012611C: 917E067E
	s_cbranch_execnz 65511                                     // 000000126120: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000126124: 8C7E067E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 000000126128: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 000000126130: BF89FC07
	s_barrier                                                  // 000000126134: BFBD0000
	buffer_gl0_inv                                             // 000000126138: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 000000126140: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 000000126148: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 000000126150: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 000000126158: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 000000126160: 7E780300
	s_mov_b32 s4, 0                                            // 000000126164: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000126168: BF840001
	s_nop 0                                                    // 00000012616C: BF800000
	s_nop 0                                                    // 000000126170: BF800000
	s_nop 0                                                    // 000000126174: BF800000
	s_nop 0                                                    // 000000126178: BF800000
	s_nop 0                                                    // 00000012617C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000126180: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000126184: 327A7884
	.long 0xd4490001                                           // 000000126188: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012618C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000126194: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000126198: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000001261A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000001261A8: 4A7C88FF 00003200
	ds_load_b32 v69, v61                                       // 0000001261B0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000001261B8: D8DCC140 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 0000001261C0: BF89FC07
	v_fmac_f32_e32 v69, v62, v29                               // 0000001261C4: 568A3B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001261C8: BF870001
	v_dual_fmac_f32 v69, v63, v30 :: v_dual_add_nc_u32 v66, 0x3a00, v68// 0000001261CC: C8203D3F 454288FF 00003A00
	v_add_nc_u32_e32 v62, 0x3e00, v68                          // 0000001261D8: 4A7C88FF 00003E00
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000001261E0: D8DCC544 42000042
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000001261E8: 4A8088FF 00003600
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000001261F0: D8DCC746 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000001261F8: D8DCC342 40000040
	s_waitcnt lgkmcnt(0)                                       // 000000126200: BF89FC07
	v_fmac_f32_e32 v69, v64, v31                               // 000000126204: 568A3F40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126208: BF870091
	v_fmac_f32_e32 v69, v65, v32                               // 00000012620C: 568A4141
	v_fmac_f32_e32 v69, v66, v33                               // 000000126210: 568A4342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126214: BF870091
	v_fmac_f32_e32 v69, v67, v34                               // 000000126218: 568A4543
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000012621C: C820473E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000126228: BF870001
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000012622C: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000126234: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012623C: 917E047E
	s_cbranch_execnz 65487                                     // 000000126240: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2080>
	s_set_inst_prefetch_distance 0x2                           // 000000126244: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000126248: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 00000012624C: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000126254: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012625C: 7E420326
	s_mov_b32 s6, 0                                            // 000000126260: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000126264: BF89FC07
	s_barrier                                                  // 000000126268: BFBD0000
	buffer_gl0_inv                                             // 00000012626C: E0AC0000 00000000
	s_nop 0                                                    // 000000126274: BF800000
	s_nop 0                                                    // 000000126278: BF800000
	s_nop 0                                                    // 00000012627C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000126280: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 000000126288: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000126290: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000126298: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012629C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000001262A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000001262A8: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001262B0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000001262B4: 10444722
	.long 0xd4490004                                           // 0000001262B8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000001262BC: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 0000001262C4: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000001262CC: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 0000001262D4: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001262D8: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000001262DC: 917E067E
	s_cbranch_execnz 65511                                     // 0000001262E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2180>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001262E4: 8C7E067E
	v_dual_mov_b32 v60, v0 :: v_dual_add_nc_u32 v61, 0x800, v47// 0000001262E8: CA200100 3C3C5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000001262F4: BF89FC07
	s_barrier                                                  // 0000001262F8: BFBD0000
	buffer_gl0_inv                                             // 0000001262FC: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 000000126304: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 00000012630C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 000000126314: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 00000012631C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 000000126324: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000126328: BF840001
	s_nop 0                                                    // 00000012632C: BF800000
	s_nop 0                                                    // 000000126330: BF800000
	s_nop 0                                                    // 000000126334: BF800000
	s_nop 0                                                    // 000000126338: BF800000
	s_nop 0                                                    // 00000012633C: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 000000126340: 327C7884
	.long 0xd4490001                                           // 000000126344: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000126348: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000126350: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000126354: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000126358: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000126364: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000126368: 4A7E8AFF 00003200
	ds_load_b32 v70, v62                                       // 000000126370: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000126378: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000126380: BF89FC07
	v_fmac_f32_e32 v70, v63, v29                               // 000000126384: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000126388: BF870001
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v65, 0x3600, v69// 00000012638C: C8203D40 46408AFF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000126398: D8DCC342 41000041
	s_waitcnt lgkmcnt(0)                                       // 0000001263A0: BF89FC07
	v_dual_fmac_f32 v70, v65, v31 :: v_dual_add_nc_u32 v67, 0x3a00, v69// 0000001263A4: C8203F41 46428AFF 00003A00
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000001263B0: D8DCC544 43000043
	v_fmac_f32_e32 v70, v66, v32                               // 0000001263B8: 568C4142
	s_waitcnt lgkmcnt(0)                                       // 0000001263BC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001263C0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000001263C4: 568C4343
	v_dual_fmac_f32 v70, v68, v34 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000001263C8: C8204544 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000001263D4: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 0000001263DC: BF89FC07
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000001263E0: C820473F 463E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001263EC: BF870111
	v_fmac_f32_e32 v70, v64, v36                               // 0000001263F0: 568C4940
	v_mov_b32_e32 v60, v63                                     // 0000001263F4: 7E78033F
	ds_store_b32 v62, v70                                      // 0000001263F8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000126400: 917E047E
	s_cbranch_execnz 65486                                     // 000000126404: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2240>
	s_set_inst_prefetch_distance 0x2                           // 000000126408: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012640C: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 000000126410: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000126418: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000126420: 7E420326
	s_mov_b32 s6, 0                                            // 000000126424: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000126428: BF89FC07
	s_barrier                                                  // 00000012642C: BFBD0000
	buffer_gl0_inv                                             // 000000126430: E0AC0000 00000000
	s_nop 0                                                    // 000000126438: BF800000
	s_nop 0                                                    // 00000012643C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000126440: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 000000126448: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000126450: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000126458: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012645C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000126464: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000126468: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000126470: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000126474: 10444722
	.long 0xd4490004                                           // 000000126478: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012647C: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000126484: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012648C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000126494: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000126498: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012649C: 917E067E
	s_cbranch_execnz 65511                                     // 0000001264A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2340>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001264A4: 8C7E067E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 0000001264A8: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000001264B0: BF89FC07
	s_barrier                                                  // 0000001264B4: BFBD0000
	buffer_gl0_inv                                             // 0000001264B8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 0000001264C0: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 0000001264C8: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 0000001264D0: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 0000001264D8: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000001264E0: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000001264E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001264E8: BF840001
	s_nop 0                                                    // 0000001264EC: BF800000
	s_nop 0                                                    // 0000001264F0: BF800000
	s_nop 0                                                    // 0000001264F4: BF800000
	s_nop 0                                                    // 0000001264F8: BF800000
	s_nop 0                                                    // 0000001264FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000126500: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000126504: 327C7A84
	.long 0xd4490001                                           // 000000126508: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000012650C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000126514: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000126518: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000126524: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000126528: 4A7E8AFF 00003200
	ds_load_b32 v70, v62                                       // 000000126530: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000126538: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000126540: BF89FC07
	v_fmac_f32_e32 v70, v63, v29                               // 000000126544: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000126548: BF870001
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v65, 0x3600, v69// 00000012654C: C8203D40 46408AFF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000126558: D8DCC342 41000041
	s_waitcnt lgkmcnt(0)                                       // 000000126560: BF89FC07
	v_dual_fmac_f32 v70, v65, v31 :: v_dual_add_nc_u32 v67, 0x3a00, v69// 000000126564: C8203F41 46428AFF 00003A00
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000126570: D8DCC544 43000043
	v_fmac_f32_e32 v70, v66, v32                               // 000000126578: 568C4142
	s_waitcnt lgkmcnt(0)                                       // 00000012657C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126580: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000126584: 568C4343
	v_dual_fmac_f32 v70, v68, v34 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000126588: C8204544 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000126594: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 00000012659C: BF89FC07
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000001265A0: C820473F 463E7AFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001265AC: BF870001
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000001265B0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000001265B8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001265C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000001265C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2400>
	s_set_inst_prefetch_distance 0x2                           // 0000001265C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001265CC: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 0000001265D0: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000001265D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000001265E0: 7E420326
	s_mov_b32 s6, 0                                            // 0000001265E4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000001265E8: BF89FC07
	s_barrier                                                  // 0000001265EC: BFBD0000
	buffer_gl0_inv                                             // 0000001265F0: E0AC0000 00000000
	s_nop 0                                                    // 0000001265F8: BF800000
	s_nop 0                                                    // 0000001265FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000126600: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 000000126608: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000126610: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000126618: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012661C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000126624: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000126628: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000126630: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000126634: 10444722
	.long 0xd4490004                                           // 000000126638: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012663C: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000126644: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012664C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000126654: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000126658: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012665C: 917E067E
	s_cbranch_execnz 65511                                     // 000000126660: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2500>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000126664: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000126668: BF89FC07
	s_barrier                                                  // 00000012666C: BFBD0000
	buffer_gl0_inv                                             // 000000126670: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 000000126678: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 000000126680: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 000000126688: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 000000126690: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000126698: 7E7A0300
	s_mov_b32 s4, 0                                            // 00000012669C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001266A0: BF840001
	s_nop 0                                                    // 0000001266A4: BF800000
	s_nop 0                                                    // 0000001266A8: BF800000
	s_nop 0                                                    // 0000001266AC: BF800000
	s_nop 0                                                    // 0000001266B0: BF800000
	s_nop 0                                                    // 0000001266B4: BF800000
	s_nop 0                                                    // 0000001266B8: BF800000
	s_nop 0                                                    // 0000001266BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001266C0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000001266C4: 327C7A84
	.long 0xd4490001                                           // 0000001266C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000001266CC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000001266D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000001266D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000001266E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000001266E8: 4A7E8AFF 00003200
	ds_load_b32 v70, v62                                       // 0000001266F0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000001266F8: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000126700: BF89FC07
	v_fmac_f32_e32 v70, v63, v29                               // 000000126704: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000126708: BF870001
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v65, 0x3600, v69// 00000012670C: C8203D40 46408AFF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000126718: D8DCC342 41000041
	s_waitcnt lgkmcnt(0)                                       // 000000126720: BF89FC07
	v_dual_fmac_f32 v70, v65, v31 :: v_dual_add_nc_u32 v67, 0x3a00, v69// 000000126724: C8203F41 46428AFF 00003A00
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000126730: D8DCC544 43000043
	v_fmac_f32_e32 v70, v66, v32                               // 000000126738: 568C4142
	s_waitcnt lgkmcnt(0)                                       // 00000012673C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126740: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000126744: 568C4343
	v_dual_fmac_f32 v70, v68, v34 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000126748: C8204544 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000126754: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 00000012675C: BF89FC07
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000126760: C820473F 463E7AFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012676C: BF870001
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000126770: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000126778: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000126780: 917E047E
	s_cbranch_execnz 65486                                     // 000000126784: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25c0>
	s_set_inst_prefetch_distance 0x2                           // 000000126788: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012678C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 000000126790: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000126798: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000001267A0: 7E420326
	s_mov_b32 s6, 0                                            // 0000001267A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000001267A8: BF89FC07
	s_barrier                                                  // 0000001267AC: BFBD0000
	buffer_gl0_inv                                             // 0000001267B0: E0AC0000 00000000
	s_nop 0                                                    // 0000001267B8: BF800000
	s_nop 0                                                    // 0000001267BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000001267C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 0000001267C8: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000001267D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000001267D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000001267DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000001267E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000001267E8: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001267F0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000001267F4: 10444722
	.long 0xd4490004                                           // 0000001267F8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000001267FC: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000126804: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012680C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000126814: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000126818: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012681C: 917E067E
	s_cbranch_execnz 65511                                     // 000000126820: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000126824: 8C7E067E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 000000126828: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 000000126830: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 000000126838: BF89FC07
	s_barrier                                                  // 00000012683C: BFBD0000
	buffer_gl0_inv                                             // 000000126840: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 000000126848: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 000000126850: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 000000126858: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 000000126860: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 000000126868: 7E780300
	s_mov_b32 s4, 0                                            // 00000012686C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000126870: BF840001
	s_nop 0                                                    // 000000126874: BF800000
	s_nop 0                                                    // 000000126878: BF800000
	s_nop 0                                                    // 00000012687C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000126880: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000126884: 327A7884
	.long 0xd4490001                                           // 000000126888: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012688C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000126894: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000126898: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000001268A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000001268A8: 4A7C88FF 00003200
	ds_load_b32 v69, v61                                       // 0000001268B0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000001268B8: D8DCC140 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 0000001268C0: BF89FC07
	v_fmac_f32_e32 v69, v62, v29                               // 0000001268C4: 568A3B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001268C8: BF870001
	v_dual_fmac_f32 v69, v63, v30 :: v_dual_add_nc_u32 v66, 0x3a00, v68// 0000001268CC: C8203D3F 454288FF 00003A00
	v_add_nc_u32_e32 v62, 0x3e00, v68                          // 0000001268D8: 4A7C88FF 00003E00
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000001268E0: D8DCC544 42000042
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000001268E8: 4A8088FF 00003600
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000001268F0: D8DCC746 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000001268F8: D8DCC342 40000040
	s_waitcnt lgkmcnt(0)                                       // 000000126900: BF89FC07
	v_fmac_f32_e32 v69, v64, v31                               // 000000126904: 568A3F40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126908: BF870091
	v_fmac_f32_e32 v69, v65, v32                               // 00000012690C: 568A4141
	v_fmac_f32_e32 v69, v66, v33                               // 000000126910: 568A4342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126914: BF870091
	v_fmac_f32_e32 v69, v67, v34                               // 000000126918: 568A4543
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000012691C: C820473E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000126928: BF870001
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000012692C: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000126934: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012693C: 917E047E
	s_cbranch_execnz 65487                                     // 000000126940: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2780>
	s_set_inst_prefetch_distance 0x2                           // 000000126944: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000126948: 8C7E047E
	.long 0xd7000107                                           // 00000012694C: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 000000126950: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000126958: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 00000012695C: D5207C08 00061080
	.long 0xd7000109                                           // 000000126964: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 000000126968: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 000000126970: D5207C0A 00061480
	.long 0xd700010d                                           // 000000126978: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 00000012697C: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000126984: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 000000126988: D5207C0E 00061C80
	.long 0xd700010b                                           // 000000126990: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 000000126994: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 00000012699C: D5207C0C 00061880
	.long 0xd700010f                                           // 0000001269A4: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000001269A8: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001269B0: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000001269B4: D5207C10 00062080
	.long 0xd7000111                                           // 0000001269BC: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000001269C0: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000001269C8: D5207C12 00062480
	.long 0xd7000113                                           // 0000001269D0: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000001269D4: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001269DC: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000001269E0: D5207C14 00062880
	.long 0xd7000115                                           // 0000001269E8: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000001269EC: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000001269F4: D5207C16 00062C80
	.long 0xd7000117                                           // 0000001269FC: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 000000126A00: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000126A08: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 000000126A0C: D5207C18 00063080
	.long 0xd7000119                                           // 000000126A14: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 000000126A18: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 000000126A20: D5207C1A 00063480
	.long 0xd700011b                                           // 000000126A28: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 000000126A2C: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000126A34: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 000000126A38: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 000000126A40: 81058105
	s_waitcnt lgkmcnt(0)                                       // 000000126A44: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 000000126A48: BF062105
	s_barrier                                                  // 000000126A4C: BFBD0000
	buffer_gl0_inv                                             // 000000126A50: E0AC0000 00000000
	s_cbranch_scc0 63122                                       // 000000126A58: BFA1F692 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a4>
	v_mov_b32_e32 v4, v38                                      // 000000126A5C: 7E080326
	s_add_u32 s0, s28, s20                                     // 000000126A60: 8000141C
	.long 0xd73c0000                                           // 000000126A64: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 000000126A68: 02020489
	s_addc_u32 s1, s29, s21                                    // 000000126A6C: 8201151D
	s_add_u32 s2, s24, s18                                     // 000000126A70: 80021218
	s_addc_u32 s3, s25, s19                                    // 000000126A74: 82031319
	s_add_u32 s0, s2, s0                                       // 000000126A78: 80000002
	s_addc_u32 s1, s3, s1                                      // 000000126A7C: 82010103
	.long 0xd7006a00                                           // 000000126A80: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000126A84: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000126A88: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000126A8C: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 000000126A94: BE810080
	.long 0xd7006a00                                           // 000000126A98: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 000000126A9C: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000126AA0: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000126AA8: BF870092
	.long 0xd7006a00                                           // 000000126AAC: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000126AB0: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000126AB4: D5207C01 01AA0211
	s_nop 0                                                    // 000000126ABC: BF800000
	ds_load_b32 v2, v37                                        // 000000126AC0: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 000000126AC8: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 000000126AD0: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000126AD8: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 000000126ADC: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 000000126AE4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 000000126AE8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 000000126AEC: DC6A0000 007C0200
	.long 0xd7000000                                           // 000000126AF4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 000000126AF8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 000000126B00: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000126B08: 917E017E
	s_cbranch_execnz 65516                                     // 000000126B0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x29c0>
	s_endpgm                                                   // 000000126B10: BFB00000
		...

