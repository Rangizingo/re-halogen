000000000007a500 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 00000007A500: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 00000007A504: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 00000007A50C: F4080500 F8000050
	v_and_b32_e32 v131, 31, v0                                 // 00000007A514: 3706009F
	v_lshrrev_b32_e32 v156, 5, v0                              // 00000007A518: 33380085
	s_mov_b32 s24, s3                                          // 00000007A51C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007A520: BF870112
	.long 0xd44c0003                                           // 00000007A524: D44C0003
	v_cndmask_b32_e32 v1, 16, v131, vcc_lo                     // 00000007A528: 02030690
	v_lshlrev_b32_e32 v132, 6, v156                            // 00000007A52C: 31093886
	s_waitcnt lgkmcnt(0)                                       // 00000007A530: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 00000007A534: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 00000007A53C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007A540: BF870001
	v_lshl_add_u32 v1, v131, 2, v132                           // 00000007A544: D6460001 06110583
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 00000007A54C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:156 offset1:162// 00000007A558: D83CA29C 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007A560: 8C7E047E
	v_mul_u32_u24_e32 v1, 0xab, v0                             // 00000007A564: 160200FF 000000AB
	.long 0x7f043880                                           // 00000007A56C: 7F043880
	v_dual_mov_b32 v141, 0 :: v_dual_and_b32 v154, 15, v0      // 00000007A570: CA240080 8D9A008F
	s_cmp_eq_u64 s[14:15], 0                                   // 00000007A578: BF10800E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000007A57C: BF8704B3
	.long 0x7e043981                                           // 00000007A580: 7E043981
	v_mov_b32_e32 v142, 0                                      // 00000007A584: 7F1C0280
	s_cselect_b32 s25, -1, 0                                   // 00000007A588: 981980C1
	s_and_b32 vcc_lo, exec_lo, s25                             // 00000007A58C: 8B6A197E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A590: BF870092
	v_add_lshl_u32 v155, s2, v2, 4                             // 00000007A594: D647009B 02120402
	v_or_b32_e32 v129, v155, v154                              // 00000007A59C: 3903359B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007A5A0: BF870001
	v_ashrrev_i32_e32 v130, 31, v129                           // 00000007A5A4: 3505029F
	s_cbranch_vccnz 10                                         // 00000007A5A8: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xd4>
	v_mad_i64_i32 v[1:2], null, s23, v129, 0                   // 00000007A5AC: D6FF7C01 02030217
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A5B4: BF870091
	.long 0xd73c0001                                           // 00000007A5B8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000007A5BC: 02020282
	.long 0xd7006a8d                                           // 00000007A5C0: D7006A8D
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000007A5C4: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007A5C8: BF870001
	v_add_co_ci_u32_e64 v142, null, s15, v2, vcc_lo            // 00000007A5CC: D5207C8E 01AA040F
	s_clause 0x2                                               // 00000007A5D4: BF850002
	s_load_b64 s[14:15], s[0:1], 0x38                          // 00000007A5D8: F4040380 F8000038
	s_load_b128 s[16:19], s[0:1], 0x20                         // 00000007A5E0: F4080400 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 00000007A5E8: F40C0100 F8000000
	v_mov_b32_e32 v158, 0                                      // 00000007A5F0: 7F3C0280
	s_xor_b32 s0, s25, -1                                      // 00000007A5F4: 8D00C119
	s_waitcnt lgkmcnt(0)                                       // 00000007A5F8: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v129                         // 00000007A5FC: 7C89020E
	s_and_b32 s23, s0, vcc_lo                                  // 00000007A600: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007A604: BF870009
	s_and_saveexec_b32 s0, s23                                 // 00000007A608: BE802017
	s_cbranch_execz 9                                          // 00000007A60C: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x134>
	.long 0xd73c0001                                           // 00000007A610: D73C0001
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 00000007A614: 02030282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A618: BF870091
	.long 0xd7006a01                                           // 00000007A61C: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 00000007A620: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 00000007A624: D5207C02 01AA0415
	global_load_b32 v158, v[1:2], off                          // 00000007A62C: DC520000 9E7C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 00000007A634: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 00000007A638: BF10800C
	s_mov_b64 s[20:21], 0                                      // 00000007A63C: BE940180
	s_cbranch_scc1 10                                          // 00000007A640: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c>
	s_ashr_i32 s0, s22, 31                                     // 00000007A644: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 00000007A648: 96810216
	s_mul_i32 s0, s0, s2                                       // 00000007A64C: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000007A650: BF8704A9
	s_add_i32 s1, s1, s0                                       // 00000007A654: 81010001
	s_mul_i32 s0, s22, s2                                      // 00000007A658: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000007A65C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007A660: BF870009
	s_add_u32 s20, s12, s0                                     // 00000007A664: 8014000C
	s_addc_u32 s21, s13, s1                                    // 00000007A668: 8215010D
	.long 0xd7050001                                           // 00000007A66C: D7050001
	v_cndmask_b32_e32 v0, v156, v150, vcc_lo                   // 00000007A670: 02012D9C
	s_lshl_b32 s0, s2, 4                                       // 00000007A674: 84008402
	s_add_i32 s1, s14, -1                                      // 00000007A678: 8101C10E
	s_or_b32 s0, s0, 15                                        // 00000007A67C: 8C008F00
	v_lshrrev_b32_e32 v157, 4, v131                            // 00000007A680: 333B0684
	.long 0xd7390001                                           // 00000007A684: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 00000007A688: 02020288
	s_min_i32 s0, s0, s1                                       // 00000007A68C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000007A690: BF870499
	s_add_i32 s0, s26, s0                                      // 00000007A694: 8100001A
	s_cmp_lt_i32 s0, -15                                       // 00000007A698: BF04CF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A69C: BF870091
	.long 0xd7050001                                           // 00000007A6A0: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 00000007A6A4: 02011901
	.long 0xd7040001                                           // 00000007A6A8: D7040001
	v_cndmask_b32_e32 v1, v156, v1, vcc_lo                     // 00000007A6AC: 0202039C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007A6B0: BF870091
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 00000007A6B4: CA240080 480002FF 000000FF
	v_mov_b32_e32 v71, v72                                     // 00000007A6C0: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 00000007A6C4: 7E8A0348
	v_mov_b32_e32 v68, v72                                     // 00000007A6C8: 7E880348
	v_mov_b32_e32 v67, v72                                     // 00000007A6CC: 7E860348
	v_mad_u64_u32 v[138:139], null, s24, 12, v[1:2]            // 00000007A6D0: D6FE7C8A 04051818
	v_mov_b32_e32 v70, v72                                     // 00000007A6D8: 7E8C0348
	v_mov_b32_e32 v66, v72                                     // 00000007A6DC: 7E840348
	v_mov_b32_e32 v65, v72                                     // 00000007A6E0: 7E820348
	v_mov_b32_e32 v80, v72                                     // 00000007A6E4: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 00000007A6E8: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 00000007A6EC: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 00000007A6F0: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 00000007A6F4: CA220148 4C011488
	v_mov_b32_e32 v75, v72                                     // 00000007A6FC: 7E960348
	v_mov_b32_e32 v74, v72                                     // 00000007A700: 7E940348
	v_mov_b32_e32 v73, v72                                     // 00000007A704: 7E920348
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007A708: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000007A70C: 3404029F
	v_mov_b32_e32 v88, v72                                     // 00000007A710: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 00000007A714: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 00000007A718: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 00000007A71C: 7EAA0348
	.long 0xd73c008b                                           // 00000007A720: D73C008B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000007A724: 02020281
	v_mov_b32_e32 v84, v72                                     // 00000007A728: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 00000007A72C: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 00000007A730: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 00000007A734: 7EA20348
	v_mov_b32_e32 v96, v72                                     // 00000007A738: 7EC00348
	v_mov_b32_e32 v95, v72                                     // 00000007A73C: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 00000007A740: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 00000007A744: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 00000007A748: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 00000007A74C: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 00000007A750: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 00000007A754: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 00000007A758: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 00000007A75C: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 00000007A760: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 00000007A764: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 00000007A768: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 00000007A76C: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 00000007A770: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 00000007A774: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 00000007A778: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 00000007A77C: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 00000007A780: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 00000007A784: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 00000007A788: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 00000007A78C: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 00000007A790: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 00000007A794: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 00000007A798: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 00000007A79C: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 00000007A7A0: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 00000007A7A4: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 00000007A7A8: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 00000007A7AC: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 00000007A7B0: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 00000007A7B4: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 00000007A7B8: 7F000348
	v_mov_b32_e32 v127, v72                                    // 00000007A7BC: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 00000007A7C0: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 00000007A7C4: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 00000007A7C8: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 00000007A7CC: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 00000007A7D0: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 00000007A7D4: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 00000007A7D8: 7E800348
	v_mov_b32_e32 v63, v72                                     // 00000007A7DC: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 00000007A7E0: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 00000007A7E4: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 00000007A7E8: 7E780348
	v_mov_b32_e32 v59, v72                                     // 00000007A7EC: 7E760348
	v_mov_b32_e32 v58, v72                                     // 00000007A7F0: 7E740348
	v_mov_b32_e32 v57, v72                                     // 00000007A7F4: 7E720348
	v_mov_b32_e32 v56, v72                                     // 00000007A7F8: 7E700348
	v_mov_b32_e32 v55, v72                                     // 00000007A7FC: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 00000007A800: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 00000007A804: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 00000007A808: 7E680348
	v_mov_b32_e32 v51, v72                                     // 00000007A80C: 7E660348
	v_mov_b32_e32 v50, v72                                     // 00000007A810: 7E640348
	v_mov_b32_e32 v49, v72                                     // 00000007A814: 7E620348
	v_mov_b32_e32 v48, v72                                     // 00000007A818: 7E600348
	v_mov_b32_e32 v47, v72                                     // 00000007A81C: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 00000007A820: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 00000007A824: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 00000007A828: 7E580348
	v_mov_b32_e32 v43, v72                                     // 00000007A82C: 7E560348
	v_mov_b32_e32 v42, v72                                     // 00000007A830: 7E540348
	v_mov_b32_e32 v41, v72                                     // 00000007A834: 7E520348
	v_mov_b32_e32 v40, v72                                     // 00000007A838: 7E500348
	v_mov_b32_e32 v39, v72                                     // 00000007A83C: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 00000007A840: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 00000007A844: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 00000007A848: 7E480348
	v_mov_b32_e32 v35, v72                                     // 00000007A84C: 7E460348
	v_mov_b32_e32 v34, v72                                     // 00000007A850: 7E440348
	v_mov_b32_e32 v33, v72                                     // 00000007A854: 7E420348
	v_mov_b32_e32 v32, v72                                     // 00000007A858: 7E400348
	v_mov_b32_e32 v31, v72                                     // 00000007A85C: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 00000007A860: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 00000007A864: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 00000007A868: 7E380348
	v_mov_b32_e32 v27, v72                                     // 00000007A86C: 7E360348
	v_mov_b32_e32 v26, v72                                     // 00000007A870: 7E340348
	v_mov_b32_e32 v25, v72                                     // 00000007A874: 7E320348
	v_mov_b32_e32 v24, v72                                     // 00000007A878: 7E300348
	v_mov_b32_e32 v23, v72                                     // 00000007A87C: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 00000007A880: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 00000007A884: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 00000007A888: 7E280348
	v_mov_b32_e32 v19, v72                                     // 00000007A88C: 7E260348
	v_mov_b32_e32 v18, v72                                     // 00000007A890: 7E240348
	v_mov_b32_e32 v17, v72                                     // 00000007A894: 7E220348
	v_mov_b32_e32 v16, v72                                     // 00000007A898: 7E200348
	v_mov_b32_e32 v15, v72                                     // 00000007A89C: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 00000007A8A0: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 00000007A8A4: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 00000007A8A8: 7E180348
	v_mov_b32_e32 v11, v72                                     // 00000007A8AC: 7E160348
	v_mov_b32_e32 v10, v72                                     // 00000007A8B0: 7E140348
	v_mov_b32_e32 v9, v72                                      // 00000007A8B4: 7E120348
	v_mov_b32_e32 v8, v72                                      // 00000007A8B8: 7E100348
	v_mov_b32_e32 v7, v72                                      // 00000007A8BC: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 00000007A8C0: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 00000007A8C4: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 00000007A8C8: 7E080348
	v_mov_b32_e32 v3, v72                                      // 00000007A8CC: 7E060348
	v_mov_b32_e32 v2, v72                                      // 00000007A8D0: 7E040348
	v_mov_b32_e32 v1, v72                                      // 00000007A8D4: 7E020348
	s_cbranch_scc1 2916                                        // 00000007A8D8: BFA20B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x316c>
	v_mad_i64_i32 v[1:2], null, 0x3000, v129, s[4:5]           // 00000007A8DC: D6FF7C01 001302FF 00003000
	s_ashr_i32 s1, s0, 31                                      // 00000007A8E8: 86019F00
	v_lshlrev_b32_e32 v4, 2, v131                              // 00000007A8EC: 30090682
	s_lshr_b32 s1, s1, 28                                      // 00000007A8F0: 85019C01
	v_add_nc_u32_e32 v160, s26, v155                           // 00000007A8F4: 4B41361A
	s_add_i32 s0, s0, s1                                       // 00000007A8F8: 81000100
	s_movk_i32 s1, 0x440                                       // 00000007A8FC: B0010440
	s_ashr_i32 s12, s0, 4                                      // 00000007A900: 860C8400
	.long 0xd7006a8f                                           // 00000007A904: D7006A8F
	v_cndmask_b32_e32 v1, v1, v139, vcc_lo                     // 00000007A908: 02031701
	v_add3_u32 v1, v129, s26, 1                                // 00000007A90C: D6550001 02043581
	v_add_co_ci_u32_e64 v144, null, v2, v140, vcc_lo           // 00000007A914: D5207C90 01AB1902
	v_mad_u32_u24 v3, v156, s1, 0x1800                         // 00000007A91C: D60B0003 03FC039C 00001800
	s_cmp_eq_u64 s[20:21], 0                                   // 00000007A928: BF108014
	s_delay_alu instid0(VALU_DEP_3)                            // 00000007A92C: BF870003
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000007A930: 3404029F
	v_mov_b32_e32 v129, 0                                      // 00000007A934: 7F020280
	s_cselect_b32 s13, -1, 0                                   // 00000007A938: 980D80C1
	v_mad_u32_u24 v5, 0x44, v157, v3                           // 00000007A93C: D60B0005 040F3AFF 00000044
	v_mad_u32_u24 v165, 0x44, v131, v3                         // 00000007A948: D60B00A5 040F06FF 00000044
	v_lshrrev_b32_e32 v2, 30, v2                               // 00000007A954: 3204049E
	v_dual_mov_b32 v8, v129 :: v_dual_lshlrev_b32 v3, 4, v0    // 00000007A958: CA220181 08020084
	s_cmp_lg_u64 s[20:21], 0                                   // 00000007A960: BF118014
	v_lshl_add_u32 v161, v154, 2, v5                           // 00000007A964: D64600A1 0415059A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000007A96C: BF870003
	v_add_nc_u32_e32 v1, v1, v2                                // 00000007A970: 4A020501
	v_add_nc_u32_e32 v2, v4, v132                              // 00000007A974: 4A050904
	s_cselect_b32 s22, -1, 0                                   // 00000007A978: 981680C1
	s_ashr_i32 s25, s24, 31                                    // 00000007A97C: 86199F18
	s_add_i32 s15, s15, -1                                     // 00000007A980: 810FC10F
	v_ashrrev_i32_e32 v162, 2, v1                              // 00000007A984: 35440282
	v_lshlrev_b32_e32 v1, 9, v156                              // 00000007A988: 30033889
	s_lshl_b64 s[4:5], s[24:25], 9                             // 00000007A98C: 84848918
	v_dual_mov_b32 v6, v129 :: v_dual_add_nc_u32 v5, 0x9f00, v132// 00000007A990: CA200181 060508FF 00009F00
	s_add_u32 s2, s6, s4                                       // 00000007A99C: 80020406
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007A9A0: BF870002
	v_lshl_add_u32 v166, v131, 5, v1                           // 00000007A9A4: D64600A6 04050B83
	v_lshl_or_b32 v170, v154, 5, v1                            // 00000007A9AC: D65600AA 04050B9A
	v_dual_mov_b32 v12, v129 :: v_dual_and_b32 v1, 0x1f0, v3   // 00000007A9B4: CA240181 0C0006FF 000001F0
	v_dual_mov_b32 v3, v129 :: v_dual_add_nc_u32 v164, 0x9c00, v2// 00000007A9C0: CA200181 03A404FF 00009C00
	v_dual_mov_b32 v10, v129 :: v_dual_add_nc_u32 v167, 0xa200, v2// 00000007A9CC: CA200181 0AA604FF 0000A200
	v_mul_u32_u24_e32 v2, 0x210, v156                          // 00000007A9D8: 160538FF 00000210
	s_addc_u32 s1, s7, s5                                      // 00000007A9E0: 82010507
	s_movk_i32 s6, 0x210                                       // 00000007A9E4: B0060210
	.long 0xd70002ac                                           // 00000007A9E8: D70002AC
	v_cndmask_b32_e32 v1, s2, v1, vcc_lo                       // 00000007A9EC: 02020202
	.long 0xd44c0000                                           // 00000007A9F0: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 00000007A9F4: 020200FF 00000200
	v_mad_u32_u24 v159, v154, s6, 0x7b00                       // 00000007A9FC: D60B009F 03FC0D9A 00007B00
	v_dual_mov_b32 v9, 0 :: v_dual_add_nc_u32 v168, v5, v4     // 00000007AA08: CA200080 09A80905
	v_lshl_or_b32 v169, v157, 2, v5                            // 00000007AA10: D65600A9 0415059D
	v_mad_u32_u24 v171, v154, 48, 0x4b00                       // 00000007AA18: D60B00AB 03FD619A 00004B00
	v_add_co_ci_u32_e64 v173, null, s1, 0, s2                  // 00000007AA24: D5207CAD 00090001
	v_lshl_or_b32 v174, v154, 1, 0x4b00                        // 00000007AA2C: D65600AE 03FD039A 00004B00
	v_dual_mov_b32 v14, v129 :: v_dual_add_nc_u32 v175, 0xfffffe80, v0// 00000007AA38: CA200181 0EAE00FF FFFFFE80
	v_lshl_add_u32 v176, v131, 4, v2                           // 00000007AA44: D64600B0 04090983
	v_lshrrev_b32_e32 v0, 1, v0                                // 00000007AA4C: 32000081
	v_mov_b32_e32 v1, 0                                        // 00000007AA50: 7E020280
	v_dual_mov_b32 v4, v129 :: v_dual_add_nc_u32 v163, v160, v131// 00000007AA54: CA200181 04A307A0
	v_mov_b32_e32 v2, v129                                     // 00000007AA5C: 7E040381
	v_mov_b32_e32 v5, v129                                     // 00000007AA60: 7E0A0381
	v_mov_b32_e32 v7, v129                                     // 00000007AA64: 7E0E0381
	v_mov_b32_e32 v11, v129                                    // 00000007AA68: 7E160381
	v_mov_b32_e32 v13, v129                                    // 00000007AA6C: 7E1A0381
	v_mov_b32_e32 v15, v129                                    // 00000007AA70: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v17, 0          // 00000007AA74: CA100181 10100080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v25, 0          // 00000007AA7C: CA100181 12180080
	v_mov_b32_e32 v19, v129                                    // 00000007AA84: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v33, 0          // 00000007AA88: CA100181 14200080
	v_mov_b32_e32 v21, v129                                    // 00000007AA90: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v41, 0          // 00000007AA94: CA100181 16280080
	v_mov_b32_e32 v23, v129                                    // 00000007AA9C: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v49, 0          // 00000007AAA0: CA100181 18300080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v57, 0          // 00000007AAA8: CA100181 1A380080
	v_mov_b32_e32 v27, v129                                    // 00000007AAB0: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v121, 0         // 00000007AAB4: CA100181 1C780080
	v_mov_b32_e32 v29, v129                                    // 00000007AABC: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v113, 0         // 00000007AAC0: CA100181 1E700080
	v_mov_b32_e32 v31, v129                                    // 00000007AAC8: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v105, 0         // 00000007AACC: CA100181 20680080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v97, 0          // 00000007AAD4: CA100181 22600080
	v_mov_b32_e32 v35, v129                                    // 00000007AADC: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v89, 0          // 00000007AAE0: CA100181 24580080
	v_mov_b32_e32 v37, v129                                    // 00000007AAE8: 7E4A0381
	v_dual_mov_b32 v38, v129 :: v_dual_mov_b32 v81, 0          // 00000007AAEC: CA100181 26500080
	v_mov_b32_e32 v39, v129                                    // 00000007AAF4: 7E4E0381
	v_dual_mov_b32 v40, v129 :: v_dual_mov_b32 v73, 0          // 00000007AAF8: CA100181 28480080
	v_dual_mov_b32 v42, v129 :: v_dual_mov_b32 v65, 0          // 00000007AB00: CA100181 2A400080
	v_mov_b32_e32 v43, v129                                    // 00000007AB08: 7E560381
	v_dual_mov_b32 v44, v129 :: v_dual_mov_b32 v177, v156      // 00000007AB0C: CA100181 2CB0019C
	v_mov_b32_e32 v45, v129                                    // 00000007AB14: 7E5A0381
	v_dual_mov_b32 v46, v129 :: v_dual_mov_b32 v145, 0         // 00000007AB18: CA100181 2E900080
	v_mov_b32_e32 v47, v129                                    // 00000007AB20: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 00000007AB24: 7E600381
	v_mov_b32_e32 v50, v129                                    // 00000007AB28: 7E640381
	v_mov_b32_e32 v51, v129                                    // 00000007AB2C: 7E660381
	v_mov_b32_e32 v52, v129                                    // 00000007AB30: 7E680381
	v_mov_b32_e32 v53, v129                                    // 00000007AB34: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 00000007AB38: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 00000007AB3C: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 00000007AB40: 7E700381
	v_mov_b32_e32 v58, v129                                    // 00000007AB44: 7E740381
	v_mov_b32_e32 v59, v129                                    // 00000007AB48: 7E760381
	v_mov_b32_e32 v60, v129                                    // 00000007AB4C: 7E780381
	v_mov_b32_e32 v61, v129                                    // 00000007AB50: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 00000007AB54: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 00000007AB58: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 00000007AB5C: 7E800381
	v_mov_b32_e32 v122, v129                                   // 00000007AB60: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 00000007AB64: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 00000007AB68: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 00000007AB6C: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 00000007AB70: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 00000007AB74: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 00000007AB78: 7F000381
	v_mov_b32_e32 v114, v129                                   // 00000007AB7C: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 00000007AB80: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 00000007AB84: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 00000007AB88: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 00000007AB8C: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 00000007AB90: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 00000007AB94: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 00000007AB98: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 00000007AB9C: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 00000007ABA0: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 00000007ABA4: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 00000007ABA8: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 00000007ABAC: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 00000007ABB0: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 00000007ABB4: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 00000007ABB8: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 00000007ABBC: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 00000007ABC0: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 00000007ABC4: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 00000007ABC8: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 00000007ABCC: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 00000007ABD0: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 00000007ABD4: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 00000007ABD8: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 00000007ABDC: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 00000007ABE0: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 00000007ABE4: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 00000007ABE8: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 00000007ABEC: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 00000007ABF0: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 00000007ABF4: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 00000007ABF8: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 00000007ABFC: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 00000007AC00: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 00000007AC04: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 00000007AC08: 7E940381
	v_mov_b32_e32 v75, v129                                    // 00000007AC0C: 7E960381
	v_mov_b32_e32 v76, v129                                    // 00000007AC10: 7E980381
	v_mov_b32_e32 v77, v129                                    // 00000007AC14: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 00000007AC18: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 00000007AC1C: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 00000007AC20: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 00000007AC24: 7E840381
	v_mov_b32_e32 v67, v129                                    // 00000007AC28: 7E860381
	v_mov_b32_e32 v68, v129                                    // 00000007AC2C: 7E880381
	v_mov_b32_e32 v69, v129                                    // 00000007AC30: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 00000007AC34: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 00000007AC38: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 00000007AC3C: 7E900381
	s_add_u32 s6, s8, s4                                       // 00000007AC40: 80060408
	s_addc_u32 s5, s9, s5                                      // 00000007AC44: 82050509
	s_mov_b32 s7, 0                                            // 00000007AC48: BE870080
	s_branch 117                                               // 00000007AC4C: BFA00075 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x924>
	ds_load_b128 v[146:149], v171                              // 00000007AC50: DBFC0000 920000AB
	ds_load_b128 v[150:153], v171 offset:16                    // 00000007AC58: DBFC0010 960000AB
	s_waitcnt lgkmcnt(0)                                       // 00000007AC60: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[146:153], v[121:128]// 00000007AC64: CC414079 1DE72582
	ds_load_b128 v[150:153], v171 offset:784                   // 00000007AC6C: DBFC0310 960000AB
	ds_load_b128 v[146:149], v171 offset:768                   // 00000007AC74: DBFC0300 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000007AC7C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[146:153], v[113:120]// 00000007AC80: CC414071 1DC72582
	ds_load_b128 v[150:153], v171 offset:1552                  // 00000007AC88: DBFC0610 960000AB
	ds_load_b128 v[146:149], v171 offset:1536                  // 00000007AC90: DBFC0600 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000007AC98: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[146:153], v[105:112]// 00000007AC9C: CC414069 1DA72582
	ds_load_b128 v[150:153], v171 offset:2320                  // 00000007ACA4: DBFC0910 960000AB
	ds_load_b128 v[146:149], v171 offset:2304                  // 00000007ACAC: DBFC0900 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000007ACB4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[146:153], v[97:104]// 00000007ACB8: CC414061 1D872582
	ds_load_b128 v[150:153], v171 offset:3088                  // 00000007ACC0: DBFC0C10 960000AB
	ds_load_b128 v[146:149], v171 offset:3072                  // 00000007ACC8: DBFC0C00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000007ACD0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[146:153], v[89:96]// 00000007ACD4: CC414059 1D672582
	ds_load_b128 v[150:153], v171 offset:3856                  // 00000007ACDC: DBFC0F10 960000AB
	ds_load_b128 v[146:149], v171 offset:3840                  // 00000007ACE4: DBFC0F00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000007ACEC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[146:153], v[81:88]// 00000007ACF0: CC414051 1D472582
	ds_load_b128 v[150:153], v171 offset:4624                  // 00000007ACF8: DBFC1210 960000AB
	ds_load_b128 v[146:149], v171 offset:4608                  // 00000007AD00: DBFC1200 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000007AD08: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[146:153], v[73:80]// 00000007AD0C: CC414049 1D272582
	ds_load_b128 v[150:153], v171 offset:5392                  // 00000007AD14: DBFC1510 960000AB
	ds_load_b128 v[146:149], v171 offset:5376                  // 00000007AD1C: DBFC1500 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000007AD24: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[146:153], v[65:72]// 00000007AD28: CC414041 1D072582
	ds_load_b128 v[150:153], v171 offset:6160                  // 00000007AD30: DBFC1810 960000AB
	ds_load_b128 v[146:149], v171 offset:6144                  // 00000007AD38: DBFC1800 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000007AD40: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[146:153], v[57:64]// 00000007AD44: CC414039 1CE72582
	ds_load_b128 v[150:153], v171 offset:6928                  // 00000007AD4C: DBFC1B10 960000AB
	ds_load_b128 v[146:149], v171 offset:6912                  // 00000007AD54: DBFC1B00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000007AD5C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[146:153], v[49:56]// 00000007AD60: CC414031 1CC72582
	ds_load_b128 v[150:153], v171 offset:7696                  // 00000007AD68: DBFC1E10 960000AB
	ds_load_b128 v[146:149], v171 offset:7680                  // 00000007AD70: DBFC1E00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000007AD78: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[146:153], v[41:48]// 00000007AD7C: CC414029 1CA72582
	ds_load_b128 v[150:153], v171 offset:8464                  // 00000007AD84: DBFC2110 960000AB
	ds_load_b128 v[146:149], v171 offset:8448                  // 00000007AD8C: DBFC2100 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000007AD94: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[146:153], v[33:40]// 00000007AD98: CC414021 1C872582
	ds_load_b128 v[150:153], v171 offset:9232                  // 00000007ADA0: DBFC2410 960000AB
	ds_load_b128 v[146:149], v171 offset:9216                  // 00000007ADA8: DBFC2400 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000007ADB0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[146:153], v[25:32]// 00000007ADB4: CC414019 1C672582
	ds_load_b128 v[150:153], v171 offset:10000                 // 00000007ADBC: DBFC2710 960000AB
	ds_load_b128 v[146:149], v171 offset:9984                  // 00000007ADC4: DBFC2700 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000007ADCC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[146:153], v[17:24]// 00000007ADD0: CC414011 1C472582
	ds_load_b128 v[150:153], v171 offset:10768                 // 00000007ADD8: DBFC2A10 960000AB
	ds_load_b128 v[146:149], v171 offset:10752                 // 00000007ADE0: DBFC2A00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000007ADE8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[146:153], v[9:16]// 00000007ADEC: CC414009 1C272582
	ds_load_b128 v[150:153], v171 offset:11536                 // 00000007ADF4: DBFC2D10 960000AB
	ds_load_b128 v[146:149], v171 offset:11520                 // 00000007ADFC: DBFC2D00 920000AB
	s_waitcnt lgkmcnt(0)                                       // 00000007AE04: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[146:153], v[1:8]// 00000007AE08: CC414001 1C072582
	v_add_nc_u32_e32 v177, 16, v177                            // 00000007AE10: 4B636290
	s_add_i32 s1, s7, 1                                        // 00000007AE14: 81018107
	s_cmp_eq_u32 s7, s12                                       // 00000007AE18: BF060C07
	s_mov_b32 s7, s1                                           // 00000007AE1C: BE870001
	s_cbranch_scc1 2578                                        // 00000007AE20: BFA20A12 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x316c>
	s_and_not1_b32 vcc_lo, exec_lo, s22                        // 00000007AE24: 916A167E
	s_mov_b32 s1, s13                                          // 00000007AE28: BE81000D
	s_cbranch_vccnz 13                                         // 00000007AE2C: BFA4000D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x964>
	s_lshr_b32 s1, s7, 3                                       // 00000007AE30: 85018307
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000007AE34: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 00000007AE38: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 00000007AE40: 7F040201
	global_load_b32 v130, v130, s[20:21]                       // 00000007AE44: DC520000 82140082
	s_waitcnt vmcnt(0)                                         // 00000007AE4C: BF8903F7
	v_lshrrev_b32_e32 v130, s7, v130                           // 00000007AE50: 33050407
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007AE54: BF870091
	v_and_b32_e32 v130, 1, v130                                // 00000007AE58: 37050481
	.long 0xd44a0001                                           // 00000007AE5C: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000007AE60: 02030481
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007AE64: BF870001
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000007AE68: 916A017E
	s_cbranch_vccnz 65512                                      // 00000007AE6C: BFA4FFE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x910>
	s_lshl_b32 s2, s7, 4                                       // 00000007AE70: 84028407
	s_waitcnt vmcnt(0)                                         // 00000007AE74: BF8903F7
	s_barrier                                                  // 00000007AE78: BFBD0000
	buffer_gl0_inv                                             // 00000007AE7C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000007AE84: BE812000
	s_cbranch_execz 117                                        // 00000007AE88: BFA50075 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb60>
	v_dual_mov_b32 v130, v177 :: v_dual_mov_b32 v131, v176     // 00000007AE8C: CA1001B1 828201B0
	v_mov_b32_e32 v132, v175                                   // 00000007AE94: 7F0803AF
	s_mov_b32 s4, 0                                            // 00000007AE98: BE840080
	s_nop 0                                                    // 00000007AE9C: BF800000
	s_nop 0                                                    // 00000007AEA0: BF800000
	s_nop 0                                                    // 00000007AEA4: BF800000
	s_nop 0                                                    // 00000007AEA8: BF800000
	s_nop 0                                                    // 00000007AEAC: BF800000
	s_nop 0                                                    // 00000007AEB0: BF800000
	s_nop 0                                                    // 00000007AEB4: BF800000
	s_nop 0                                                    // 00000007AEB8: BF800000
	s_nop 0                                                    // 00000007AEBC: BF800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007AEC0: BF870112
	v_min_i32_e32 v133, s15, v130                              // 00000007AEC4: 230B040F
	v_add_nc_u32_e32 v132, 0x180, v132                         // 00000007AEC8: 4B0908FF 00000180
	v_add_nc_u32_e32 v130, 12, v130                            // 00000007AED0: 4B05048C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000007AED4: BF8701B3
	v_ashrrev_i32_e32 v135, 31, v133                           // 00000007AED8: 350F0A9F
	.long 0xd72c0088                                           // 00000007AEDC: D72C0088
	v_cndmask_b32_e32 v1, s11, v133, vcc_lo                    // 00000007AEE0: 02030A0B
	v_mad_u64_u32 v[133:134], null, s10, v133, 0               // 00000007AEE4: D6FE7C85 02030A0A
	.long 0xd72c0087                                           // 00000007AEEC: D72C0087
	v_cndmask_b32_e32 v1, s10, v135, vcc_lo                    // 00000007AEF0: 02030E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007AEF4: BF870091
	v_add3_u32 v134, v134, v135, v136                          // 00000007AEF8: D6550086 06230F86
	.long 0xd73c0085                                           // 00000007AF00: D73C0085
	v_cndmask_b32_e32 v1, 1, v133, vcc_lo                      // 00000007AF04: 02030A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007AF08: BF870091
	.long 0xd7006a85                                           // 00000007AF0C: D7006A85
	v_cndmask_b32_e32 v1, v172, v133, vcc_lo                   // 00000007AF10: 02030BAC
	v_add_co_ci_u32_e64 v134, null, v173, v134, vcc_lo         // 00000007AF14: D5207C86 01AB0DAD
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v132                        // 00000007AF1C: 7C9308FF 0000007F
	global_load_b128 v[133:136], v[133:134], off               // 00000007AF24: DC5E0000 857C0085
	s_or_b32 s4, vcc_lo, s4                                    // 00000007AF2C: 8C04046A
	s_waitcnt vmcnt(0)                                         // 00000007AF30: BF8903F7
	ds_store_b128 v131, v[133:136] offset:31488                // 00000007AF34: DB7C7B00 00008583
	v_add_nc_u32_e32 v131, 0x18c0, v131                        // 00000007AF3C: 4B0706FF 000018C0
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007AF44: 917E047E
	s_cbranch_execnz 65501                                     // 00000007AF48: BFA6FFDD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007AF4C: 8C7E047E
	v_or_b32_e32 v130, s2, v154                                // 00000007AF50: 39053402
	s_mov_b32 s4, 0                                            // 00000007AF54: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007AF58: BF870091
	v_min_i32_e32 v130, s15, v130                              // 00000007AF5C: 2305040F
	v_ashrrev_i32_e32 v132, 31, v130                           // 00000007AF60: 3509049F
	.long 0xd72c0085                                           // 00000007AF64: D72C0085
	v_cndmask_b32_e32 v1, s11, v130, vcc_lo                    // 00000007AF68: 0203040B
	v_mad_u64_u32 v[130:131], null, s10, v130, 0               // 00000007AF6C: D6FE7C82 0203040A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007AF74: BF870093
	.long 0xd72c0084                                           // 00000007AF78: D72C0084
	v_cndmask_b32_e32 v1, s10, v132, vcc_lo                    // 00000007AF7C: 0203080A
	v_add3_u32 v131, v131, v132, v133                          // 00000007AF80: D6550083 06170983
	v_mov_b32_e32 v133, v175                                   // 00000007AF88: 7F0A03AF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007AF8C: BF870122
	.long 0xd73c0083                                           // 00000007AF90: D73C0083
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000007AF94: 02030481
	v_mov_b32_e32 v130, v0                                     // 00000007AF98: 7F040300
	.long 0xd7006a83                                           // 00000007AF9C: D7006A83
	v_cndmask_b32_e32 v1, s6, v131, vcc_lo                     // 00000007AFA0: 02030606
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007AFA4: BF870001
	v_add_co_ci_u32_e64 v132, null, s5, v132, vcc_lo           // 00000007AFA8: D5207C84 01AB0805
	s_set_inst_prefetch_distance 0x1                           // 00000007AFB0: BF840001
	s_nop 0                                                    // 00000007AFB4: BF800000
	s_nop 0                                                    // 00000007AFB8: BF800000
	s_nop 0                                                    // 00000007AFBC: BF800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000007AFC0: BF8701B3
	v_and_b32_e32 v146, 0xf8, v130                             // 00000007AFC4: 372504FF 000000F8
	v_add_nc_u32_e32 v133, 0x180, v133                         // 00000007AFCC: 4B0B0AFF 00000180
	v_add_nc_u32_e32 v130, 0xc0, v130                          // 00000007AFD4: 4B0504FF 000000C0
	v_lshlrev_b32_e32 v134, 1, v146                            // 00000007AFDC: 310D2481
	v_mad_u32_u24 v146, v146, 48, v174                         // 00000007AFE0: D60B0092 06B96192
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007AFE8: BF870092
	.long 0xd7006a86                                           // 00000007AFEC: D7006A86
	v_cndmask_b32_e32 v1, v131, v134, vcc_lo                   // 00000007AFF0: 02030D83
	v_add_co_ci_u32_e64 v135, null, 0, v132, vcc_lo            // 00000007AFF4: D5207C87 01AB0880
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v133                        // 00000007AFFC: 7C930AFF 0000007F
	global_load_b128 v[134:137], v[134:135], off               // 00000007B004: DC5E0000 867C0086
	s_waitcnt vmcnt(0)                                         // 00000007B00C: BF8903F7
	ds_store_b16 v146, v134                                    // 00000007B010: D87C0000 00008692
	ds_store_b16_d16_hi v146, v134 offset:48                   // 00000007B018: DA840030 00008692
	ds_store_b16 v146, v135 offset:96                          // 00000007B020: D87C0060 00008792
	ds_store_b16_d16_hi v146, v135 offset:144                  // 00000007B028: DA840090 00008792
	ds_store_b16 v146, v136 offset:192                         // 00000007B030: D87C00C0 00008892
	ds_store_b16_d16_hi v146, v136 offset:240                  // 00000007B038: DA8400F0 00008892
	ds_store_b16 v146, v137 offset:288                         // 00000007B040: D87C0120 00008992
	ds_store_b16_d16_hi v146, v137 offset:336                  // 00000007B048: DA840150 00008992
	s_or_b32 s4, vcc_lo, s4                                    // 00000007B050: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B054: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000007B058: 917E047E
	s_cbranch_execnz 65496                                     // 00000007B05C: BFA6FFD8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac0>
	s_set_inst_prefetch_distance 0x2                           // 00000007B060: BF840002
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007B064: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 00000007B068: BF89FC07
	s_barrier                                                  // 00000007B06C: BFBD0000
	buffer_gl0_inv                                             // 00000007B070: E0AC0000 00000000
	s_clause 0x3                                               // 00000007B078: BF850003
	global_load_b128 v[150:153], v[143:144], off offset:16     // 00000007B07C: DC5E0010 967C008F
	global_load_b128 v[146:149], v[143:144], off               // 00000007B084: DC5E0000 927C008F
	global_load_b128 v[182:185], v[143:144], off offset:48     // 00000007B08C: DC5E0030 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:32     // 00000007B094: DC5E0020 B27C008F
	ds_load_b128 v[186:189], v159                              // 00000007B09C: DBFC0000 BA00009F
	ds_load_b128 v[190:193], v159 offset:16                    // 00000007B0A4: DBFC0010 BE00009F
	v_mov_b32_e32 v136, v129                                   // 00000007B0AC: 7F100381
	v_mov_b32_e32 v130, v129                                   // 00000007B0B0: 7F040381
	v_mov_b32_e32 v131, v129                                   // 00000007B0B4: 7F060381
	v_mov_b32_e32 v132, v129                                   // 00000007B0B8: 7F080381
	v_mov_b32_e32 v133, v129                                   // 00000007B0BC: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 00000007B0C0: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 00000007B0C4: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 00000007B0C8: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000007B0CC: BF870212
	v_mov_b32_e32 v136, v135                                   // 00000007B0D0: 7F100387
	v_mov_b32_e32 v135, v134                                   // 00000007B0D4: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 00000007B0D8: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 00000007B0DC: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 00000007B0E0: 7F080383
	v_mov_b32_e32 v131, v130                                   // 00000007B0E4: 7F060382
	v_mov_b32_e32 v130, v129                                   // 00000007B0E8: 7F040381
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000007B0EC: BF890807
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007B0F0: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 00000007B0F4: CC414082 1E0B7592
	s_clause 0x1                                               // 00000007B0FC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:80     // 00000007B100: DC5E0050 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:64     // 00000007B108: DC5E0040 927C008F
	ds_load_b128 v[186:189], v159 offset:32                    // 00000007B110: DBFC0020 BA00009F
	ds_load_b128 v[190:193], v159 offset:48                    // 00000007B118: DBFC0030 BE00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000007B120: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 00000007B124: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000007B12C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:112    // 00000007B130: DC5E0070 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:96     // 00000007B138: DC5E0060 B27C008F
	ds_load_b128 v[190:193], v159 offset:80                    // 00000007B140: DBFC0050 BE00009F
	ds_load_b128 v[186:189], v159 offset:64                    // 00000007B148: DBFC0040 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000007B150: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 00000007B154: CC414082 1E0B7592
	s_clause 0x1                                               // 00000007B15C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:144    // 00000007B160: DC5E0090 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:128    // 00000007B168: DC5E0080 927C008F
	ds_load_b128 v[190:193], v159 offset:112                   // 00000007B170: DBFC0070 BE00009F
	ds_load_b128 v[186:189], v159 offset:96                    // 00000007B178: DBFC0060 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000007B180: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 00000007B184: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000007B18C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:176    // 00000007B190: DC5E00B0 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:160    // 00000007B198: DC5E00A0 B27C008F
	ds_load_b128 v[190:193], v159 offset:144                   // 00000007B1A0: DBFC0090 BE00009F
	ds_load_b128 v[186:189], v159 offset:128                   // 00000007B1A8: DBFC0080 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000007B1B0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 00000007B1B4: CC414082 1E0B7592
	s_clause 0x1                                               // 00000007B1BC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:208    // 00000007B1C0: DC5E00D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:192    // 00000007B1C8: DC5E00C0 927C008F
	ds_load_b128 v[190:193], v159 offset:176                   // 00000007B1D0: DBFC00B0 BE00009F
	ds_load_b128 v[186:189], v159 offset:160                   // 00000007B1D8: DBFC00A0 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000007B1E0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 00000007B1E4: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000007B1EC: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:240    // 00000007B1F0: DC5E00F0 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:224    // 00000007B1F8: DC5E00E0 B27C008F
	ds_load_b128 v[190:193], v159 offset:208                   // 00000007B200: DBFC00D0 BE00009F
	ds_load_b128 v[186:189], v159 offset:192                   // 00000007B208: DBFC00C0 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000007B210: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 00000007B214: CC414082 1E0B7592
	s_clause 0x1                                               // 00000007B21C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:272    // 00000007B220: DC5E0110 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:256    // 00000007B228: DC5E0100 927C008F
	ds_load_b128 v[190:193], v159 offset:240                   // 00000007B230: DBFC00F0 BE00009F
	ds_load_b128 v[186:189], v159 offset:224                   // 00000007B238: DBFC00E0 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000007B240: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 00000007B244: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000007B24C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:304    // 00000007B250: DC5E0130 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:288    // 00000007B258: DC5E0120 B27C008F
	ds_load_b128 v[190:193], v159 offset:272                   // 00000007B260: DBFC0110 BE00009F
	ds_load_b128 v[186:189], v159 offset:256                   // 00000007B268: DBFC0100 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000007B270: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 00000007B274: CC414082 1E0B7592
	s_clause 0x1                                               // 00000007B27C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:336    // 00000007B280: DC5E0150 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:320    // 00000007B288: DC5E0140 927C008F
	ds_load_b128 v[190:193], v159 offset:304                   // 00000007B290: DBFC0130 BE00009F
	ds_load_b128 v[186:189], v159 offset:288                   // 00000007B298: DBFC0120 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000007B2A0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 00000007B2A4: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000007B2AC: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:368    // 00000007B2B0: DC5E0170 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:352    // 00000007B2B8: DC5E0160 B27C008F
	ds_load_b128 v[190:193], v159 offset:336                   // 00000007B2C0: DBFC0150 BE00009F
	ds_load_b128 v[186:189], v159 offset:320                   // 00000007B2C8: DBFC0140 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000007B2D0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 00000007B2D4: CC414082 1E0B7592
	s_clause 0x1                                               // 00000007B2DC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:400    // 00000007B2E0: DC5E0190 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:384    // 00000007B2E8: DC5E0180 927C008F
	ds_load_b128 v[190:193], v159 offset:368                   // 00000007B2F0: DBFC0170 BE00009F
	ds_load_b128 v[186:189], v159 offset:352                   // 00000007B2F8: DBFC0160 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000007B300: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 00000007B304: CC414082 1E0B75B2
	s_clause 0x1                                               // 00000007B30C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:432    // 00000007B310: DC5E01B0 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:416    // 00000007B318: DC5E01A0 B27C008F
	ds_load_b128 v[190:193], v159 offset:400                   // 00000007B320: DBFC0190 BE00009F
	ds_load_b128 v[186:189], v159 offset:384                   // 00000007B328: DBFC0180 BA00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000007B330: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[186:193], v[130:137]// 00000007B334: CC414082 1E0B7592
	ds_load_b128 v[150:153], v159 offset:432                   // 00000007B33C: DBFC01B0 9600009F
	ds_load_b128 v[146:149], v159 offset:416                   // 00000007B344: DBFC01A0 9200009F
	s_clause 0x1                                               // 00000007B34C: BF850001
	global_load_b128 v[190:193], v[143:144], off offset:464    // 00000007B350: DC5E01D0 BE7C008F
	global_load_b128 v[186:189], v[143:144], off offset:448    // 00000007B358: DC5E01C0 BA7C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000007B360: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[146:153], v[130:137]// 00000007B364: CC414082 1E0B25B2
	s_clause 0x1                                               // 00000007B36C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:496    // 00000007B370: DC5E01F0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:480    // 00000007B378: DC5E01E0 927C008F
	ds_load_b128 v[182:185], v159 offset:464                   // 00000007B380: DBFC01D0 B600009F
	ds_load_b128 v[178:181], v159 offset:448                   // 00000007B388: DBFC01C0 B200009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 00000007B390: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[186:193], v[178:185], v[130:137]// 00000007B394: CC414082 1E0B65BA
	ds_load_b128 v[182:185], v159 offset:496                   // 00000007B39C: DBFC01F0 B600009F
	ds_load_b128 v[178:181], v159 offset:480                   // 00000007B3A4: DBFC01E0 B200009F
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007B3AC: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[178:185], v[130:137]// 00000007B3B0: CC414082 1E0B6592
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007B3B8: BF870111
	v_dual_mul_f32 v130, 0x3d800000, v130 :: v_dual_mul_f32 v131, 0x3d800000, v131// 00000007B3BC: C8C704FF 828306FF 3D800000
	v_mul_f32_e32 v146, 0x3d800000, v133                       // 00000007B3C8: 11250AFF 3D800000
	v_mov_b32_e32 v133, 0xffff                                 // 00000007B3D0: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007B3D8: BF870004
	v_mul_f32_e32 v132, 0x3d800000, v132                       // 00000007B3DC: 110908FF 3D800000
	v_dual_mul_f32 v134, 0x3d800000, v134 :: v_dual_mul_f32 v135, 0x3d800000, v135// 00000007B3E4: C8C70CFF 86870EFF 3D800000
	v_dual_mul_f32 v136, 0x3d800000, v136 :: v_dual_mul_f32 v137, 0x3d800000, v137// 00000007B3F0: C8C710FF 888912FF 3D800000
	ds_store_2addr_b32 v161, v130, v131 offset1:34             // 00000007B3FC: D8382200 008382A1
	ds_store_2addr_b32 v161, v132, v146 offset0:68 offset1:102 // 00000007B404: D8386644 009284A1
	ds_store_2addr_b32 v161, v134, v135 offset0:136 offset1:170// 00000007B40C: D838AA88 008786A1
	ds_store_2addr_b32 v161, v136, v137 offset0:204 offset1:238// 00000007B414: D838EECC 008988A1
	s_and_saveexec_b32 s4, s23                                 // 00000007B41C: BE842017
	s_cbranch_execz 363                                        // 00000007B420: BFA5016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14d0>
	s_lshl_b32 s8, s7, 2                                       // 00000007B424: 84088207
	s_mov_b32 s9, exec_lo                                      // 00000007B428: BE89007E
	.long 0xd4c1007e                                           // 00000007B42C: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 00000007B430: 02033D91
	s_cbranch_execz 48                                         // 00000007B434: BFA50030 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xff8>
	v_ashrrev_i32_e32 v146, 31, v145                           // 00000007B438: 3525229F
	s_mov_b32 s24, 0                                           // 00000007B43C: BE980080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007B440: BF870091
	.long 0xd73c0082                                           // 00000007B444: D73C0082
	v_cndmask_b32_e32 v1, 2, v145, vcc_lo                      // 00000007B448: 02032282
	.long 0xd7006a82                                           // 00000007B44C: D7006A82
	v_cndmask_b32_e32 v1, v141, v130, vcc_lo                   // 00000007B450: 0203058D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007B454: BF870001
	v_add_co_ci_u32_e64 v131, null, v142, v131, vcc_lo         // 00000007B458: D5207C83 01AB078E
	s_branch 15                                                // 00000007B460: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xfa0>
	s_nop 0                                                    // 00000007B464: BF800000
	s_nop 0                                                    // 00000007B468: BF800000
	s_nop 0                                                    // 00000007B46C: BF800000
	s_nop 0                                                    // 00000007B470: BF800000
	s_nop 0                                                    // 00000007B474: BF800000
	s_nop 0                                                    // 00000007B478: BF800000
	s_nop 0                                                    // 00000007B47C: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 00000007B480: 8C7E1A7E
	v_mov_b32_e32 v133, v145                                   // 00000007B484: 7F0A0391
	v_mov_b32_e32 v145, v132                                   // 00000007B488: 7F220384
	s_and_b32 s1, exec_lo, s25                                 // 00000007B48C: 8B01197E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000007B490: BF870499
	s_or_b32 s24, s1, s24                                      // 00000007B494: 8C181801
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 00000007B498: 917E187E
	s_cbranch_execz 20                                         // 00000007B49C: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xff0>
	global_load_b32 v132, v[130:131], off                      // 00000007B4A0: DC520000 847C0082
	s_or_b32 s25, s25, exec_lo                                 // 00000007B4A8: 8C197E19
	s_waitcnt vmcnt(0)                                         // 00000007B4AC: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s8, v132                          // 00000007B4B0: 7C890808
	s_and_saveexec_b32 s26, vcc_lo                             // 00000007B4B4: BE9A206A
	s_cbranch_execz 65521                                      // 00000007B4B8: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	v_dual_mov_b32 v145, v158 :: v_dual_add_nc_u32 v132, 1, v145// 00000007B4BC: CA20019E 91852281
	.long 0xd7000182                                           // 00000007B4C4: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 00000007B4C8: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007B4CC: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 00000007B4D0: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v158, v132                        // 00000007B4D8: 7C95099E
	s_and_not1_b32 s1, s25, exec_lo                            // 00000007B4DC: 91017E19
	s_and_b32 s25, vcc_lo, exec_lo                             // 00000007B4E0: 8B197E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B4E4: BF870009
	s_or_b32 s25, s1, s25                                      // 00000007B4E8: 8C191901
	s_branch 65508                                             // 00000007B4EC: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	s_or_b32 exec_lo, exec_lo, s24                             // 00000007B4F0: 8C7E187E
	v_mov_b32_e32 v145, v133                                   // 00000007B4F4: 7F220385
	s_or_b32 exec_lo, exec_lo, s9                              // 00000007B4F8: 8C7E097E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007B4FC: BF870001
	v_dual_mov_b32 v133, 15 :: v_dual_mov_b32 v130, v145       // 00000007B500: CA10008F 85820191
	s_mov_b32 s1, exec_lo                                      // 00000007B508: BE81007E
	.long 0xd4c1007e                                           // 00000007B50C: D4C1007E
	v_cndmask_b32_e32 v1, s8, v162, vcc_lo                     // 00000007B510: 02034408
	s_cbranch_execz 62                                         // 00000007B514: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1110>
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v145        // 00000007B518: CA100080 85820191
	s_mov_b32 s9, exec_lo                                      // 00000007B520: BE89007E
	.long 0xd4c1007e                                           // 00000007B524: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 00000007B528: 02033D91
	s_cbranch_execz 54                                         // 00000007B52C: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1108>
	v_mov_b32_e32 v130, v145                                   // 00000007B530: 7F040391
	s_mov_b32 s25, 0                                           // 00000007B534: BE990080
	s_set_inst_prefetch_distance 0x1                           // 00000007B538: BF840001
	s_branch 10                                                // 00000007B53C: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1068>
	s_or_b32 exec_lo, exec_lo, s28                             // 00000007B540: 8C7E1C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000007B544: BF870499
	s_and_b32 s28, exec_lo, s27                                // 00000007B548: 8B1C1B7E
	s_or_b32 s25, s28, s25                                     // 00000007B54C: 8C19191C
	s_and_not1_b32 s24, s24, exec_lo                           // 00000007B550: 91187E18
	s_and_b32 s28, s26, exec_lo                                // 00000007B554: 8B1C7E1A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B558: BF870009
	s_or_b32 s24, s24, s28                                     // 00000007B55C: 8C181C18
	s_and_not1_b32 exec_lo, exec_lo, s25                       // 00000007B560: 917E197E
	s_cbranch_execz 28                                         // 00000007B564: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10d8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007B568: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 00000007B56C: 7F060382
	s_or_b32 s26, s26, exec_lo                                 // 00000007B570: 8C1A7E1A
	s_or_b32 s27, s27, exec_lo                                 // 00000007B574: 8C1B7E1B
	s_mov_b32 s28, exec_lo                                     // 00000007B578: BE9C007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000007B57C: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007B580: BF870091
	.long 0xd73c0084                                           // 00000007B584: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000007B588: 02030682
	.long 0xd7006a84                                           // 00000007B58C: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 00000007B590: 0203098D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007B594: BF870001
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 00000007B598: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 00000007B5A0: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 00000007B5A8: BF8903F7
	.long 0xd4c4007e                                           // 00000007B5AC: D4C4007E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 00000007B5B0: 02030808
	s_cbranch_execz 65506                                      // 00000007B5B4: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000007B5B8: 4B050681
	s_and_not1_b32 s27, s27, exec_lo                           // 00000007B5BC: 911B7E1B
	s_and_not1_b32 s26, s26, exec_lo                           // 00000007B5C0: 911A7E1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000007B5C4: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000007B5C8: 7C95059E
	s_and_b32 s29, vcc_lo, exec_lo                             // 00000007B5CC: 8B1D7E6A
	s_or_b32 s27, s27, s29                                     // 00000007B5D0: 8C1B1D1B
	s_branch 65498                                             // 00000007B5D4: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	s_set_inst_prefetch_distance 0x2                           // 00000007B5D8: BF840002
	s_or_b32 exec_lo, exec_lo, s25                             // 00000007B5DC: 8C7E197E
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v158        // 00000007B5E0: CA100080 8582019E
	s_and_saveexec_b32 s25, s24                                // 00000007B5E8: BE992018
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B5EC: BF870009
	s_xor_b32 s24, exec_lo, s25                                // 00000007B5F0: 8D18197E
	v_cmp_eq_u32_e32 vcc_lo, s8, v132                          // 00000007B5F4: 7C950808
	v_mov_b32_e32 v130, v131                                   // 00000007B5F8: 7F040383
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 00000007B5FC: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s24                             // 00000007B604: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B608: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 00000007B60C: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B610: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007B614: 8C7E017E
	s_or_b32 s9, s8, 1                                         // 00000007B618: 8C098108
	s_mov_b32 s1, exec_lo                                      // 00000007B61C: BE81007E
	.long 0xd4c6007e                                           // 00000007B620: D4C6007E
	v_cndmask_b32_e32 v1, s9, v162, vcc_lo                     // 00000007B624: 02034409
	s_xor_b32 s1, exec_lo, s1                                  // 00000007B628: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 00000007B62C: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 00000007B634: BE813001
	s_cbranch_execz 70                                         // 00000007B638: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1254>
	s_mov_b32 s24, exec_lo                                     // 00000007B63C: BE98007E
	.long 0xd4c1007e                                           // 00000007B640: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 00000007B644: 02033D82
	s_cbranch_execz 64                                         // 00000007B648: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x124c>
	s_mov_b32 s26, 0                                           // 00000007B64C: BE9A0080
	s_set_inst_prefetch_distance 0x1                           // 00000007B650: BF840001
	s_branch 20                                                // 00000007B654: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11a8>
	s_nop 0                                                    // 00000007B658: BF800000
	s_nop 0                                                    // 00000007B65C: BF800000
	s_nop 0                                                    // 00000007B660: BF800000
	s_nop 0                                                    // 00000007B664: BF800000
	s_nop 0                                                    // 00000007B668: BF800000
	s_nop 0                                                    // 00000007B66C: BF800000
	s_nop 0                                                    // 00000007B670: BF800000
	s_nop 0                                                    // 00000007B674: BF800000
	s_nop 0                                                    // 00000007B678: BF800000
	s_nop 0                                                    // 00000007B67C: BF800000
	s_or_b32 exec_lo, exec_lo, s29                             // 00000007B680: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000007B684: BF870499
	s_and_b32 s29, exec_lo, s28                                // 00000007B688: 8B1D1C7E
	s_or_b32 s26, s29, s26                                     // 00000007B68C: 8C1A1A1D
	s_and_not1_b32 s25, s25, exec_lo                           // 00000007B690: 91197E19
	s_and_b32 s29, s27, exec_lo                                // 00000007B694: 8B1D7E1B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B698: BF870009
	s_or_b32 s25, s25, s29                                     // 00000007B69C: 8C191D19
	s_and_not1_b32 exec_lo, exec_lo, s26                       // 00000007B6A0: 917E1A7E
	s_cbranch_execz 27                                         // 00000007B6A4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1214>
	v_mov_b32_e32 v131, v130                                   // 00000007B6A8: 7F060382
	s_or_b32 s27, s27, exec_lo                                 // 00000007B6AC: 8C1B7E1B
	s_or_b32 s28, s28, exec_lo                                 // 00000007B6B0: 8C1C7E1C
	s_mov_b32 s29, exec_lo                                     // 00000007B6B4: BE9D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007B6B8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000007B6BC: 3509069F
	.long 0xd73c0086                                           // 00000007B6C0: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000007B6C4: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007B6C8: BF870091
	.long 0xd7006a86                                           // 00000007B6CC: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 00000007B6D0: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 00000007B6D4: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 00000007B6DC: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 00000007B6E4: BF8903F7
	.long 0xd4c6007e                                           // 00000007B6E8: D4C6007E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 00000007B6EC: 02030808
	s_cbranch_execz 65507                                      // 00000007B6F0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000007B6F4: 4B050681
	s_and_not1_b32 s28, s28, exec_lo                           // 00000007B6F8: 911C7E1C
	s_and_not1_b32 s27, s27, exec_lo                           // 00000007B6FC: 911B7E1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000007B700: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000007B704: 7C95059E
	s_and_b32 s30, vcc_lo, exec_lo                             // 00000007B708: 8B1E7E6A
	s_or_b32 s28, s28, s30                                     // 00000007B70C: 8C1C1E1C
	s_branch 65499                                             // 00000007B710: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	s_set_inst_prefetch_distance 0x2                           // 00000007B714: BF840002
	s_or_b32 exec_lo, exec_lo, s26                             // 00000007B718: 8C7E1A7E
	v_mov_b32_e32 v130, v158                                   // 00000007B71C: 7F04039E
	s_and_saveexec_b32 s26, s25                                // 00000007B720: BE9A2019
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B724: BF870009
	s_xor_b32 s25, exec_lo, s26                                // 00000007B728: 8D191A7E
	v_cmp_eq_u32_e32 vcc_lo, s9, v132                          // 00000007B72C: 7C950809
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 00000007B730: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007B73C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 00000007B740: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 00000007B744: 7F040383
	s_or_b32 exec_lo, exec_lo, s25                             // 00000007B748: 8C7E197E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B74C: BF870009
	s_or_b32 exec_lo, exec_lo, s24                             // 00000007B750: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B754: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007B758: 8C7E017E
	s_or_b32 s9, s8, 2                                         // 00000007B75C: 8C098208
	s_mov_b32 s1, exec_lo                                      // 00000007B760: BE81007E
	.long 0xd4c6007e                                           // 00000007B764: D4C6007E
	v_cndmask_b32_e32 v1, s9, v162, vcc_lo                     // 00000007B768: 02034409
	s_xor_b32 s1, exec_lo, s1                                  // 00000007B76C: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 00000007B770: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 00000007B778: BE813001
	s_cbranch_execz 69                                         // 00000007B77C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1394>
	s_mov_b32 s24, exec_lo                                     // 00000007B780: BE98007E
	.long 0xd4c1007e                                           // 00000007B784: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 00000007B788: 02033D82
	s_cbranch_execz 63                                         // 00000007B78C: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x138c>
	s_mov_b32 s26, 0                                           // 00000007B790: BE9A0080
	s_set_inst_prefetch_distance 0x1                           // 00000007B794: BF840001
	s_branch 19                                                // 00000007B798: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12e8>
	s_nop 0                                                    // 00000007B79C: BF800000
	s_nop 0                                                    // 00000007B7A0: BF800000
	s_nop 0                                                    // 00000007B7A4: BF800000
	s_nop 0                                                    // 00000007B7A8: BF800000
	s_nop 0                                                    // 00000007B7AC: BF800000
	s_nop 0                                                    // 00000007B7B0: BF800000
	s_nop 0                                                    // 00000007B7B4: BF800000
	s_nop 0                                                    // 00000007B7B8: BF800000
	s_nop 0                                                    // 00000007B7BC: BF800000
	s_or_b32 exec_lo, exec_lo, s29                             // 00000007B7C0: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000007B7C4: BF870499
	s_and_b32 s29, exec_lo, s28                                // 00000007B7C8: 8B1D1C7E
	s_or_b32 s26, s29, s26                                     // 00000007B7CC: 8C1A1A1D
	s_and_not1_b32 s25, s25, exec_lo                           // 00000007B7D0: 91197E19
	s_and_b32 s29, s27, exec_lo                                // 00000007B7D4: 8B1D7E1B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B7D8: BF870009
	s_or_b32 s25, s25, s29                                     // 00000007B7DC: 8C191D19
	s_and_not1_b32 exec_lo, exec_lo, s26                       // 00000007B7E0: 917E1A7E
	s_cbranch_execz 27                                         // 00000007B7E4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1354>
	v_mov_b32_e32 v131, v130                                   // 00000007B7E8: 7F060382
	s_or_b32 s27, s27, exec_lo                                 // 00000007B7EC: 8C1B7E1B
	s_or_b32 s28, s28, exec_lo                                 // 00000007B7F0: 8C1C7E1C
	s_mov_b32 s29, exec_lo                                     // 00000007B7F4: BE9D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007B7F8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000007B7FC: 3509069F
	.long 0xd73c0086                                           // 00000007B800: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000007B804: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007B808: BF870091
	.long 0xd7006a86                                           // 00000007B80C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 00000007B810: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 00000007B814: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 00000007B81C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 00000007B824: BF8903F7
	.long 0xd4c4007e                                           // 00000007B828: D4C4007E
	v_cndmask_b32_e32 v1, s9, v132, vcc_lo                     // 00000007B82C: 02030809
	s_cbranch_execz 65507                                      // 00000007B830: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12c0>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000007B834: 4B050681
	s_and_not1_b32 s28, s28, exec_lo                           // 00000007B838: 911C7E1C
	s_and_not1_b32 s27, s27, exec_lo                           // 00000007B83C: 911B7E1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000007B840: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000007B844: 7C95059E
	s_and_b32 s30, vcc_lo, exec_lo                             // 00000007B848: 8B1E7E6A
	s_or_b32 s28, s28, s30                                     // 00000007B84C: 8C1C1E1C
	s_branch 65499                                             // 00000007B850: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12c0>
	s_set_inst_prefetch_distance 0x2                           // 00000007B854: BF840002
	s_or_b32 exec_lo, exec_lo, s26                             // 00000007B858: 8C7E1A7E
	v_mov_b32_e32 v130, v158                                   // 00000007B85C: 7F04039E
	s_and_saveexec_b32 s26, s25                                // 00000007B860: BE9A2019
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B864: BF870009
	s_xor_b32 s25, exec_lo, s26                                // 00000007B868: 8D191A7E
	v_cmp_eq_u32_e32 vcc_lo, s9, v132                          // 00000007B86C: 7C950809
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 00000007B870: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007B87C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 00000007B880: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 00000007B884: 7F040383
	s_or_b32 exec_lo, exec_lo, s25                             // 00000007B888: 8C7E197E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B88C: BF870009
	s_or_b32 exec_lo, exec_lo, s24                             // 00000007B890: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B894: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007B898: 8C7E017E
	s_or_b32 s8, s8, 3                                         // 00000007B89C: 8C088308
	s_mov_b32 s1, exec_lo                                      // 00000007B8A0: BE81007E
	.long 0xd4c6007e                                           // 00000007B8A4: D4C6007E
	v_cndmask_b32_e32 v1, s8, v162, vcc_lo                     // 00000007B8A8: 02034408
	s_xor_b32 s1, exec_lo, s1                                  // 00000007B8AC: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 00000007B8B0: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 00000007B8B8: BE813001
	s_cbranch_execz 66                                         // 00000007B8BC: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c8>
	s_mov_b32 s9, exec_lo                                      // 00000007B8C0: BE89007E
	.long 0xd4c1007e                                           // 00000007B8C4: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 00000007B8C8: 02033D82
	s_cbranch_execz 60                                         // 00000007B8CC: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	s_mov_b32 s25, 0                                           // 00000007B8D0: BE990080
	s_set_inst_prefetch_distance 0x1                           // 00000007B8D4: BF840001
	s_branch 19                                                // 00000007B8D8: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1428>
	s_nop 0                                                    // 00000007B8DC: BF800000
	s_nop 0                                                    // 00000007B8E0: BF800000
	s_nop 0                                                    // 00000007B8E4: BF800000
	s_nop 0                                                    // 00000007B8E8: BF800000
	s_nop 0                                                    // 00000007B8EC: BF800000
	s_nop 0                                                    // 00000007B8F0: BF800000
	s_nop 0                                                    // 00000007B8F4: BF800000
	s_nop 0                                                    // 00000007B8F8: BF800000
	s_nop 0                                                    // 00000007B8FC: BF800000
	s_or_b32 exec_lo, exec_lo, s28                             // 00000007B900: 8C7E1C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000007B904: BF870499
	s_and_b32 s28, exec_lo, s27                                // 00000007B908: 8B1C1B7E
	s_or_b32 s25, s28, s25                                     // 00000007B90C: 8C19191C
	s_and_not1_b32 s24, s24, exec_lo                           // 00000007B910: 91187E18
	s_and_b32 s28, s26, exec_lo                                // 00000007B914: 8B1C7E1A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B918: BF870009
	s_or_b32 s24, s24, s28                                     // 00000007B91C: 8C181C18
	s_and_not1_b32 exec_lo, exec_lo, s25                       // 00000007B920: 917E197E
	s_cbranch_execz 26                                         // 00000007B924: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1490>
	v_ashrrev_i32_e32 v131, 31, v130                           // 00000007B928: 3507049F
	s_or_b32 s26, s26, exec_lo                                 // 00000007B92C: 8C1A7E1A
	s_or_b32 s27, s27, exec_lo                                 // 00000007B930: 8C1B7E1B
	s_mov_b32 s28, exec_lo                                     // 00000007B934: BE9C007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007B938: BF870091
	.long 0xd73c0083                                           // 00000007B93C: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 00000007B940: 02030482
	.long 0xd7006a83                                           // 00000007B944: D7006A83
	v_cndmask_b32_e32 v1, v141, v131, vcc_lo                   // 00000007B948: 0203078D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007B94C: BF870001
	v_add_co_ci_u32_e64 v132, null, v142, v132, vcc_lo         // 00000007B950: D5207C84 01AB098E
	global_load_b32 v131, v[131:132], off                      // 00000007B958: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 00000007B960: BF8903F7
	.long 0xd4c4007e                                           // 00000007B964: D4C4007E
	v_cndmask_b32_e32 v1, s8, v131, vcc_lo                     // 00000007B968: 02030608
	s_cbranch_execz 65508                                      // 00000007B96C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	v_add_nc_u32_e32 v130, 1, v130                             // 00000007B970: 4B050481
	s_and_not1_b32 s27, s27, exec_lo                           // 00000007B974: 911B7E1B
	s_and_not1_b32 s26, s26, exec_lo                           // 00000007B978: 911A7E1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000007B97C: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 00000007B980: 7C95059E
	s_and_b32 s29, vcc_lo, exec_lo                             // 00000007B984: 8B1D7E6A
	s_or_b32 s27, s27, s29                                     // 00000007B988: 8C1B1D1B
	s_branch 65500                                             // 00000007B98C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	s_set_inst_prefetch_distance 0x2                           // 00000007B990: BF840002
	s_or_b32 exec_lo, exec_lo, s25                             // 00000007B994: 8C7E197E
	s_and_saveexec_b32 s25, s24                                // 00000007B998: BE992018
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B99C: BF870009
	s_xor_b32 s24, exec_lo, s25                                // 00000007B9A0: 8D18197E
	v_cmp_eq_u32_e32 vcc_lo, s8, v131                          // 00000007B9A4: 7C950608
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 00000007B9A8: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007B9B4: BF870001
	v_or_b32_e32 v133, v130, v133                              // 00000007B9B8: 390B0B82
	s_or_b32 exec_lo, exec_lo, s24                             // 00000007B9BC: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B9C0: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 00000007B9C4: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007B9C8: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007B9CC: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000007B9D0: BF8704C9
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007B9D4: 8C7E047E
	v_cmp_eq_u32_e32 vcc_lo, 0xffff, v133                      // 00000007B9D8: 7C950AFF 0000FFFF
	s_cmp_eq_u32 vcc_lo, -1                                    // 00000007B9E0: BF06C16A
	s_cselect_b32 s1, -1, 0                                    // 00000007B9E4: 980180C1
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 00000007B9E8: D5010082 00050280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007B9F0: BF870001
	v_readfirstlane_b32 s1, v130                               // 00000007B9F4: 7E020582
	s_bitcmp0_b32 s1, 0                                        // 00000007B9F8: BF0C8001
	s_mov_b32 s1, 0                                            // 00000007B9FC: BE810080
	s_cbranch_scc1 8                                           // 00000007BA00: BFA20008 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1524>
	s_or_b32 s1, s2, 15                                        // 00000007BA04: 8C018F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007BA08: BF8700A9
	v_cmp_le_i32_e32 vcc_lo, s1, v160                          // 00000007BA0C: 7C874001
	v_cndmask_b32_e64 v130, 0, 1, vcc_lo                       // 00000007BA10: D5010082 01A90280
	v_readfirstlane_b32 s1, v130                               // 00000007BA18: 7E020582
	s_bitcmp1_b32 s1, 0                                        // 00000007BA1C: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 00000007BA20: 980180C1
	s_and_saveexec_b32 s4, s3                                  // 00000007BA24: BE842003
	s_cbranch_execz 1626                                       // 00000007BA28: BFA5065A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2e94>
	ds_load_b32 v130, v164                                     // 00000007BA2C: D8D80000 820000A4
	s_xor_b32 s1, s1, -1                                       // 00000007BA34: 8D01C101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007BA38: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000007BA3C: 916A017E
	s_mov_b32 s1, -1                                           // 00000007BA40: BE8100C1
	s_cbranch_vccnz 990                                        // 00000007BA44: BFA403DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x24c0>
	v_and_b32_e32 v131, 1, v133                                // 00000007BA48: 37070A81
	v_cmp_le_i32_e32 vcc_lo, s2, v163                          // 00000007BA4C: 7C874602
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000007BA50: BF8704C2
	.long 0xd44a0001                                           // 00000007BA54: D44A0001
	v_cndmask_b32_e32 v1, 1, v131, vcc_lo                      // 00000007BA58: 02030681
	s_waitcnt lgkmcnt(0)                                       // 00000007BA5C: BF89FC07
	v_mov_b32_e32 v131, v130                                   // 00000007BA60: 7F060382
	s_and_b32 s37, vcc_lo, s1                                  // 00000007BA64: 8B25016A
	s_and_saveexec_b32 s1, s37                                 // 00000007BA68: BE812025
	s_cbranch_execz 7                                          // 00000007BA6C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x158c>
	ds_load_b32 v131, v165                                     // 00000007BA70: D8D80000 830000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BA78: BF89FC07
	v_dual_max_f32 v132, v130, v130 :: v_dual_max_f32 v131, v131, v131// 00000007BA7C: CA950582 84830783
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BA84: BF870001
	v_max_f32_e32 v131, v132, v131                             // 00000007BA88: 21070784
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007BA8C: 8C7E017E
	v_and_b32_e32 v132, 2, v133                                // 00000007BA90: 37090A82
	v_cmp_lt_i32_e32 vcc_lo, s2, v163                          // 00000007BA94: 7C834602
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000007BA98: BF8704A2
	.long 0xd44d0001                                           // 00000007BA9C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000007BAA0: 02030880
	s_and_b32 s36, vcc_lo, s1                                  // 00000007BAA4: 8B24016A
	s_and_saveexec_b32 s1, s36                                 // 00000007BAA8: BE812024
	s_cbranch_execz 7                                          // 00000007BAAC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15cc>
	ds_load_b32 v132, v165 offset:4                            // 00000007BAB0: D8D80004 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BAB8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000007BABC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BAC4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000007BAC8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007BACC: 8C7E017E
	v_and_b32_e32 v132, 4, v133                                // 00000007BAD0: 37090A84
	s_or_b32 s1, s2, 2                                         // 00000007BAD4: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007BAD8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000007BADC: 7C874601
	.long 0xd44d0001                                           // 00000007BAE0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000007BAE4: 02030880
	s_and_b32 s35, vcc_lo, s1                                  // 00000007BAE8: 8B23016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007BAEC: BF870009
	s_and_saveexec_b32 s1, s35                                 // 00000007BAF0: BE812023
	s_cbranch_execz 7                                          // 00000007BAF4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1614>
	ds_load_b32 v132, v165 offset:8                            // 00000007BAF8: D8D80008 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BB00: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000007BB04: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BB0C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000007BB10: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007BB14: 8C7E017E
	v_and_b32_e32 v132, 8, v133                                // 00000007BB18: 37090A88
	s_or_b32 s1, s2, 3                                         // 00000007BB1C: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007BB20: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000007BB24: 7C874601
	.long 0xd44d0001                                           // 00000007BB28: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000007BB2C: 02030880
	s_and_b32 s34, vcc_lo, s1                                  // 00000007BB30: 8B22016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007BB34: BF870009
	s_and_saveexec_b32 s1, s34                                 // 00000007BB38: BE812022
	s_cbranch_execz 7                                          // 00000007BB3C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x165c>
	ds_load_b32 v132, v165 offset:12                           // 00000007BB40: D8D8000C 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BB48: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000007BB4C: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BB54: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000007BB58: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007BB5C: 8C7E017E
	v_and_b32_e32 v132, 16, v133                               // 00000007BB60: 37090A90
	s_or_b32 s1, s2, 4                                         // 00000007BB64: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007BB68: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000007BB6C: 7C874601
	.long 0xd44d0001                                           // 00000007BB70: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000007BB74: 02030880
	s_and_b32 s33, vcc_lo, s1                                  // 00000007BB78: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007BB7C: BF870009
	s_and_saveexec_b32 s1, s33                                 // 00000007BB80: BE812021
	s_cbranch_execz 7                                          // 00000007BB84: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16a4>
	ds_load_b32 v132, v165 offset:16                           // 00000007BB88: D8D80010 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BB90: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000007BB94: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BB9C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000007BBA0: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007BBA4: 8C7E017E
	v_and_b32_e32 v132, 32, v133                               // 00000007BBA8: 37090AA0
	s_or_b32 s1, s2, 5                                         // 00000007BBAC: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007BBB0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000007BBB4: 7C874601
	.long 0xd44d0001                                           // 00000007BBB8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000007BBBC: 02030880
	s_and_b32 s31, vcc_lo, s1                                  // 00000007BBC0: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007BBC4: BF870009
	s_and_saveexec_b32 s1, s31                                 // 00000007BBC8: BE81201F
	s_cbranch_execz 7                                          // 00000007BBCC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16ec>
	ds_load_b32 v132, v165 offset:20                           // 00000007BBD0: D8D80014 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BBD8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000007BBDC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BBE4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000007BBE8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007BBEC: 8C7E017E
	v_and_b32_e32 v132, 64, v133                               // 00000007BBF0: 37090AC0
	s_or_b32 s1, s2, 6                                         // 00000007BBF4: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007BBF8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000007BBFC: 7C874601
	.long 0xd44d0001                                           // 00000007BC00: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000007BC04: 02030880
	s_and_b32 s30, vcc_lo, s1                                  // 00000007BC08: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007BC0C: BF870009
	s_and_saveexec_b32 s1, s30                                 // 00000007BC10: BE81201E
	s_cbranch_execz 7                                          // 00000007BC14: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1734>
	ds_load_b32 v132, v165 offset:24                           // 00000007BC18: D8D80018 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BC20: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000007BC24: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BC2C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000007BC30: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007BC34: 8C7E017E
	v_and_b32_e32 v132, 0x80, v133                             // 00000007BC38: 37090AFF 00000080
	s_or_b32 s1, s2, 7                                         // 00000007BC40: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007BC44: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000007BC48: 7C874601
	.long 0xd44d0001                                           // 00000007BC4C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000007BC50: 02030880
	s_and_b32 s29, vcc_lo, s1                                  // 00000007BC54: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007BC58: BF870009
	s_and_saveexec_b32 s1, s29                                 // 00000007BC5C: BE81201D
	s_cbranch_execz 7                                          // 00000007BC60: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1780>
	ds_load_b32 v132, v165 offset:28                           // 00000007BC64: D8D8001C 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BC6C: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000007BC70: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BC78: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000007BC7C: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007BC80: 8C7E017E
	v_and_b32_e32 v132, 0x100, v133                            // 00000007BC84: 37090AFF 00000100
	s_or_b32 s1, s2, 8                                         // 00000007BC8C: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007BC90: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000007BC94: 7C874601
	.long 0xd44d0001                                           // 00000007BC98: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000007BC9C: 02030880
	s_and_b32 s28, vcc_lo, s1                                  // 00000007BCA0: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007BCA4: BF870009
	s_and_saveexec_b32 s1, s28                                 // 00000007BCA8: BE81201C
	s_cbranch_execz 7                                          // 00000007BCAC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17cc>
	ds_load_b32 v132, v165 offset:32                           // 00000007BCB0: D8D80020 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BCB8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000007BCBC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BCC4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000007BCC8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007BCCC: 8C7E017E
	v_and_b32_e32 v132, 0x200, v133                            // 00000007BCD0: 37090AFF 00000200
	s_or_b32 s1, s2, 9                                         // 00000007BCD8: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007BCDC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000007BCE0: 7C874601
	.long 0xd44d0001                                           // 00000007BCE4: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000007BCE8: 02030880
	s_and_b32 s27, vcc_lo, s1                                  // 00000007BCEC: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007BCF0: BF870009
	s_and_saveexec_b32 s1, s27                                 // 00000007BCF4: BE81201B
	s_cbranch_execz 7                                          // 00000007BCF8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1818>
	ds_load_b32 v132, v165 offset:36                           // 00000007BCFC: D8D80024 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BD04: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000007BD08: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BD10: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000007BD14: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007BD18: 8C7E017E
	v_and_b32_e32 v132, 0x400, v133                            // 00000007BD1C: 37090AFF 00000400
	s_or_b32 s1, s2, 10                                        // 00000007BD24: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007BD28: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000007BD2C: 7C874601
	.long 0xd44d0001                                           // 00000007BD30: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000007BD34: 02030880
	s_and_b32 s26, vcc_lo, s1                                  // 00000007BD38: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007BD3C: BF870009
	s_and_saveexec_b32 s1, s26                                 // 00000007BD40: BE81201A
	s_cbranch_execz 7                                          // 00000007BD44: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1864>
	ds_load_b32 v132, v165 offset:40                           // 00000007BD48: D8D80028 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BD50: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000007BD54: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BD5C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000007BD60: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007BD64: 8C7E017E
	v_and_b32_e32 v132, 0x800, v133                            // 00000007BD68: 37090AFF 00000800
	s_or_b32 s1, s2, 11                                        // 00000007BD70: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007BD74: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000007BD78: 7C874601
	.long 0xd44d0001                                           // 00000007BD7C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000007BD80: 02030880
	s_and_b32 s25, vcc_lo, s1                                  // 00000007BD84: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007BD88: BF870009
	s_and_saveexec_b32 s1, s25                                 // 00000007BD8C: BE812019
	s_cbranch_execz 7                                          // 00000007BD90: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18b0>
	ds_load_b32 v132, v165 offset:44                           // 00000007BD94: D8D8002C 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BD9C: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000007BDA0: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BDA8: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000007BDAC: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007BDB0: 8C7E017E
	v_and_b32_e32 v132, 0x1000, v133                           // 00000007BDB4: 37090AFF 00001000
	s_or_b32 s1, s2, 12                                        // 00000007BDBC: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007BDC0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000007BDC4: 7C874601
	.long 0xd44d0001                                           // 00000007BDC8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000007BDCC: 02030880
	s_and_b32 s24, vcc_lo, s1                                  // 00000007BDD0: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007BDD4: BF870009
	s_and_saveexec_b32 s1, s24                                 // 00000007BDD8: BE812018
	s_cbranch_execz 7                                          // 00000007BDDC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18fc>
	ds_load_b32 v132, v165 offset:48                           // 00000007BDE0: D8D80030 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BDE8: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000007BDEC: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BDF4: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000007BDF8: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007BDFC: 8C7E017E
	v_and_b32_e32 v132, 0x2000, v133                           // 00000007BE00: 37090AFF 00002000
	s_or_b32 s1, s2, 13                                        // 00000007BE08: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007BE0C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000007BE10: 7C874601
	.long 0xd44d0001                                           // 00000007BE14: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000007BE18: 02030880
	s_and_b32 s9, vcc_lo, s1                                   // 00000007BE1C: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007BE20: BF870009
	s_and_saveexec_b32 s1, s9                                  // 00000007BE24: BE812009
	s_cbranch_execz 7                                          // 00000007BE28: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1948>
	ds_load_b32 v132, v165 offset:52                           // 00000007BE2C: D8D80034 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BE34: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000007BE38: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BE40: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000007BE44: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007BE48: 8C7E017E
	v_and_b32_e32 v132, 0x4000, v133                           // 00000007BE4C: 37090AFF 00004000
	s_or_b32 s1, s2, 14                                        // 00000007BE54: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007BE58: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v163                          // 00000007BE5C: 7C874601
	.long 0xd44d0001                                           // 00000007BE60: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000007BE64: 02030880
	s_and_b32 s8, vcc_lo, s1                                   // 00000007BE68: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007BE6C: BF870009
	s_and_saveexec_b32 s1, s8                                  // 00000007BE70: BE812008
	s_cbranch_execz 7                                          // 00000007BE74: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1994>
	ds_load_b32 v132, v165 offset:56                           // 00000007BE78: D8D80038 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BE80: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000007BE84: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BE8C: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000007BE90: 21070983
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007BE94: 8C7E017E
	v_and_b32_e32 v132, 0x8000, v133                           // 00000007BE98: 37090AFF 00008000
	s_or_b32 s2, s2, 15                                        // 00000007BEA0: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007BEA4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v163                          // 00000007BEA8: 7C874602
	.long 0xd44d0001                                           // 00000007BEAC: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000007BEB0: 02030880
	s_and_b32 s1, vcc_lo, s1                                   // 00000007BEB4: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007BEB8: BF870009
	s_and_saveexec_b32 s2, s1                                  // 00000007BEBC: BE822001
	s_cbranch_execz 7                                          // 00000007BEC0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19e0>
	ds_load_b32 v132, v165 offset:60                           // 00000007BEC4: D8D8003C 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BECC: BF89FC07
	v_dual_max_f32 v131, v131, v131 :: v_dual_max_f32 v132, v132, v132// 00000007BED0: CA950783 83850984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007BED8: BF870001
	v_max_f32_e32 v131, v131, v132                             // 00000007BEDC: 21070983
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007BEE0: 8C7E027E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v133, 0           // 00000007BEE4: CA100080 84840080
	s_and_saveexec_b32 s2, s37                                 // 00000007BEEC: BE822025
	s_cbranch_execz 30                                         // 00000007BEF0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a6c>
	ds_load_b32 v133, v165                                     // 00000007BEF4: D8D80000 850000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BEFC: BF89FC07
	v_sub_f32_e32 v133, v133, v131                             // 00000007BF00: 090B0785
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007BF04: BF870091
	v_mul_f32_e32 v134, 0x3fb8aa3b, v133                       // 00000007BF08: 110D0AFF 3FB8AA3B
	v_fma_f32 v135, 0x3fb8aa3b, v133, -v134                    // 00000007BF10: D6130087 861B0AFF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 00000007BF1C: 7F104786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007BF20: BF870221
	v_sub_f32_e32 v134, v134, v136                             // 00000007BF24: 090D1186
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 00000007BF28: 7C370AFF C2CE8ED0
	v_fmac_f32_e32 v135, 0x32a5705f, v133                      // 00000007BF30: 570F0AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007BF38: BF870121
	v_add_f32_e32 v134, v134, v135                             // 00000007BF3C: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 00000007BF40: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 00000007BF44: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007BF48: BF870095
	.long 0xd71c0086                                           // 00000007BF4C: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 00000007BF50: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 00000007BF54: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 00000007BF58: 7C3D0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007BF60: BF870002
	v_cndmask_b32_e32 v133, 0x7f800000, v134, vcc_lo           // 00000007BF64: 030B0CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007BF6C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007BF70: BF870091
	v_bfe_u32 v134, v133, 16, 1                                // 00000007BF74: D6100086 02052185
	v_add3_u32 v134, v133, v134, 0x7fff                        // 00000007BF7C: D6550086 03FF0D85 00007FFF
	ds_store_b16_d16_hi v166, v134                             // 00000007BF88: DA840000 000086A6
	s_and_saveexec_b32 s2, s36                                 // 00000007BF90: BE822024
	s_cbranch_execz 30                                         // 00000007BF94: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b10>
	ds_load_b32 v132, v165 offset:4                            // 00000007BF98: D8D80004 840000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007BFA0: BF89FC07
	v_sub_f32_e32 v132, v132, v131                             // 00000007BFA4: 09090784
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007BFA8: BF870121
	v_mul_f32_e32 v134, 0x3fb8aa3b, v132                       // 00000007BFAC: 110D08FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v132                 // 00000007BFB4: 7C3708FF C2CE8ED0
	v_fma_f32 v135, 0x3fb8aa3b, v132, -v134                    // 00000007BFBC: D6130087 861B08FF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 00000007BFC8: 7F104786
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007BFCC: BF870112
	v_fmac_f32_e32 v135, 0x32a5705f, v132                      // 00000007BFD0: 570F08FF 32A5705F
	v_sub_f32_e32 v134, v134, v136                             // 00000007BFD8: 090D1186
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007BFDC: BF870121
	v_add_f32_e32 v134, v134, v135                             // 00000007BFE0: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 00000007BFE4: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 00000007BFE8: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007BFEC: BF870095
	.long 0xd71c0086                                           // 00000007BFF0: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 00000007BFF4: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 00000007BFF8: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v132                 // 00000007BFFC: 7C3D08FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007C004: BF870002
	v_cndmask_b32_e32 v132, 0x7f800000, v134, vcc_lo           // 00000007C008: 03090CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007C010: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C014: BF870121
	v_bfe_u32 v134, v132, 16, 1                                // 00000007C018: D6100086 02052184
	v_mov_b32_e32 v135, 0                                      // 00000007C020: 7F0E0280
	v_add3_u32 v136, v132, v134, 0x7fff                        // 00000007C024: D6550088 03FF0D84 00007FFF
	v_mov_b32_e32 v134, 0                                      // 00000007C030: 7F0C0280
	ds_store_b16_d16_hi v166, v136 offset:2                    // 00000007C034: DA840002 000088A6
	s_and_saveexec_b32 s2, s35                                 // 00000007C03C: BE822023
	s_cbranch_execz 30                                         // 00000007C040: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1bbc>
	ds_load_b32 v135, v165 offset:8                            // 00000007C044: D8D80008 870000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007C04C: BF89FC07
	v_sub_f32_e32 v135, v135, v131                             // 00000007C050: 090F0787
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C054: BF870091
	v_mul_f32_e32 v136, 0x3fb8aa3b, v135                       // 00000007C058: 11110EFF 3FB8AA3B
	v_fma_f32 v137, 0x3fb8aa3b, v135, -v136                    // 00000007C060: D6130089 86230EFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 00000007C06C: 7F244788
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007C070: BF870221
	v_sub_f32_e32 v136, v136, v146                             // 00000007C074: 09112588
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 00000007C078: 7C370EFF C2CE8ED0
	v_fmac_f32_e32 v137, 0x32a5705f, v135                      // 00000007C080: 57130EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C088: BF870121
	v_add_f32_e32 v136, v136, v137                             // 00000007C08C: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 00000007C090: 7F121192
	v_exp_f32_e32 v136, v136                                   // 00000007C094: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C098: BF870095
	.long 0xd71c0088                                           // 00000007C09C: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 00000007C0A0: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 00000007C0A4: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 00000007C0A8: 7C3D0EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007C0B0: BF870002
	v_cndmask_b32_e32 v135, 0x7f800000, v136, vcc_lo           // 00000007C0B4: 030F10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007C0BC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C0C0: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 00000007C0C4: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 00000007C0CC: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v166, v136 offset:4                    // 00000007C0D8: DA840004 000088A6
	s_and_saveexec_b32 s2, s34                                 // 00000007C0E0: BE822022
	s_cbranch_execz 30                                         // 00000007C0E4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c60>
	ds_load_b32 v134, v165 offset:12                           // 00000007C0E8: D8D8000C 860000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007C0F0: BF89FC07
	v_sub_f32_e32 v134, v134, v131                             // 00000007C0F4: 090D0786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C0F8: BF870121
	v_mul_f32_e32 v136, 0x3fb8aa3b, v134                       // 00000007C0FC: 11110CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 00000007C104: 7C370CFF C2CE8ED0
	v_fma_f32 v137, 0x3fb8aa3b, v134, -v136                    // 00000007C10C: D6130089 86230CFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 00000007C118: 7F244788
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007C11C: BF870112
	v_fmac_f32_e32 v137, 0x32a5705f, v134                      // 00000007C120: 57130CFF 32A5705F
	v_sub_f32_e32 v136, v136, v146                             // 00000007C128: 09112588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C12C: BF870121
	v_add_f32_e32 v136, v136, v137                             // 00000007C130: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 00000007C134: 7F121192
	v_exp_f32_e32 v136, v136                                   // 00000007C138: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C13C: BF870095
	.long 0xd71c0088                                           // 00000007C140: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 00000007C144: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 00000007C148: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 00000007C14C: 7C3D0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007C154: BF870002
	v_cndmask_b32_e32 v134, 0x7f800000, v136, vcc_lo           // 00000007C158: 030D10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007C160: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C164: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 00000007C168: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 00000007C170: 7F120280
	v_add3_u32 v146, v134, v136, 0x7fff                        // 00000007C174: D6550092 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 00000007C180: 7F100280
	ds_store_b16_d16_hi v166, v146 offset:6                    // 00000007C184: DA840006 000092A6
	s_and_saveexec_b32 s2, s33                                 // 00000007C18C: BE822021
	s_cbranch_execz 30                                         // 00000007C190: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d0c>
	ds_load_b32 v137, v165 offset:16                           // 00000007C194: D8D80010 890000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007C19C: BF89FC07
	v_sub_f32_e32 v137, v137, v131                             // 00000007C1A0: 09130789
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C1A4: BF870091
	v_mul_f32_e32 v146, 0x3fb8aa3b, v137                       // 00000007C1A8: 112512FF 3FB8AA3B
	v_fma_f32 v147, 0x3fb8aa3b, v137, -v146                    // 00000007C1B0: D6130093 864B12FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 00000007C1BC: 7F284792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007C1C0: BF870221
	v_sub_f32_e32 v146, v146, v148                             // 00000007C1C4: 09252992
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v137                 // 00000007C1C8: 7C3712FF C2CE8ED0
	v_fmac_f32_e32 v147, 0x32a5705f, v137                      // 00000007C1D0: 572712FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C1D8: BF870121
	v_add_f32_e32 v146, v146, v147                             // 00000007C1DC: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 00000007C1E0: 7F261194
	v_exp_f32_e32 v146, v146                                   // 00000007C1E4: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C1E8: BF870095
	.long 0xd71c0092                                           // 00000007C1EC: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 00000007C1F0: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 00000007C1F4: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v137                 // 00000007C1F8: 7C3D12FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007C200: BF870002
	v_cndmask_b32_e32 v137, 0x7f800000, v146, vcc_lo           // 00000007C204: 031324FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007C20C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C210: BF870091
	v_bfe_u32 v146, v137, 16, 1                                // 00000007C214: D6100092 02052189
	v_add3_u32 v146, v137, v146, 0x7fff                        // 00000007C21C: D6550092 03FF2589 00007FFF
	ds_store_b16_d16_hi v166, v146 offset:8                    // 00000007C228: DA840008 000092A6
	s_and_saveexec_b32 s2, s31                                 // 00000007C230: BE82201F
	s_cbranch_execz 30                                         // 00000007C234: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1db0>
	ds_load_b32 v136, v165 offset:20                           // 00000007C238: D8D80014 880000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007C240: BF89FC07
	v_sub_f32_e32 v136, v136, v131                             // 00000007C244: 09110788
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C248: BF870121
	v_mul_f32_e32 v146, 0x3fb8aa3b, v136                       // 00000007C24C: 112510FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 00000007C254: 7C3710FF C2CE8ED0
	v_fma_f32 v147, 0x3fb8aa3b, v136, -v146                    // 00000007C25C: D6130093 864B10FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 00000007C268: 7F284792
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007C26C: BF870112
	v_fmac_f32_e32 v147, 0x32a5705f, v136                      // 00000007C270: 572710FF 32A5705F
	v_sub_f32_e32 v146, v146, v148                             // 00000007C278: 09252992
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C27C: BF870121
	v_add_f32_e32 v146, v146, v147                             // 00000007C280: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 00000007C284: 7F261194
	v_exp_f32_e32 v146, v146                                   // 00000007C288: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C28C: BF870095
	.long 0xd71c0092                                           // 00000007C290: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 00000007C294: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 00000007C298: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 00000007C29C: 7C3D10FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007C2A4: BF870002
	v_cndmask_b32_e32 v136, 0x7f800000, v146, vcc_lo           // 00000007C2A8: 031124FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007C2B0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C2B4: BF870121
	v_bfe_u32 v146, v136, 16, 1                                // 00000007C2B8: D6100092 02052188
	v_mov_b32_e32 v147, 0                                      // 00000007C2C0: 7F260280
	v_add3_u32 v148, v136, v146, 0x7fff                        // 00000007C2C4: D6550094 03FF2588 00007FFF
	v_mov_b32_e32 v146, 0                                      // 00000007C2D0: 7F240280
	ds_store_b16_d16_hi v166, v148 offset:10                   // 00000007C2D4: DA84000A 000094A6
	s_and_saveexec_b32 s2, s30                                 // 00000007C2DC: BE82201E
	s_cbranch_execz 30                                         // 00000007C2E0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e5c>
	ds_load_b32 v147, v165 offset:24                           // 00000007C2E4: D8D80018 930000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007C2EC: BF89FC07
	v_sub_f32_e32 v147, v147, v131                             // 00000007C2F0: 09270793
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C2F4: BF870091
	v_mul_f32_e32 v148, 0x3fb8aa3b, v147                       // 00000007C2F8: 112926FF 3FB8AA3B
	v_fma_f32 v149, 0x3fb8aa3b, v147, -v148                    // 00000007C300: D6130095 865326FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 00000007C30C: 7F2C4794
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007C310: BF870221
	v_sub_f32_e32 v148, v148, v150                             // 00000007C314: 09292D94
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v147                 // 00000007C318: 7C3726FF C2CE8ED0
	v_fmac_f32_e32 v149, 0x32a5705f, v147                      // 00000007C320: 572B26FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C328: BF870121
	v_add_f32_e32 v148, v148, v149                             // 00000007C32C: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 00000007C330: 7F2A1196
	v_exp_f32_e32 v148, v148                                   // 00000007C334: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C338: BF870095
	.long 0xd71c0094                                           // 00000007C33C: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 00000007C340: 02032B94
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 00000007C344: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v147                 // 00000007C348: 7C3D26FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007C350: BF870002
	v_cndmask_b32_e32 v147, 0x7f800000, v148, vcc_lo           // 00000007C354: 032728FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007C35C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C360: BF870091
	v_bfe_u32 v148, v147, 16, 1                                // 00000007C364: D6100094 02052193
	v_add3_u32 v148, v147, v148, 0x7fff                        // 00000007C36C: D6550094 03FF2993 00007FFF
	ds_store_b16_d16_hi v166, v148 offset:12                   // 00000007C378: DA84000C 000094A6
	s_and_saveexec_b32 s2, s29                                 // 00000007C380: BE82201D
	s_cbranch_execz 30                                         // 00000007C384: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f00>
	ds_load_b32 v146, v165 offset:28                           // 00000007C388: D8D8001C 920000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007C390: BF89FC07
	v_sub_f32_e32 v146, v146, v131                             // 00000007C394: 09250792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C398: BF870121
	v_mul_f32_e32 v148, 0x3fb8aa3b, v146                       // 00000007C39C: 112924FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 00000007C3A4: 7C3724FF C2CE8ED0
	v_fma_f32 v149, 0x3fb8aa3b, v146, -v148                    // 00000007C3AC: D6130095 865324FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 00000007C3B8: 7F2C4794
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007C3BC: BF870112
	v_fmac_f32_e32 v149, 0x32a5705f, v146                      // 00000007C3C0: 572B24FF 32A5705F
	v_sub_f32_e32 v148, v148, v150                             // 00000007C3C8: 09292D94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C3CC: BF870121
	v_add_f32_e32 v148, v148, v149                             // 00000007C3D0: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 00000007C3D4: 7F2A1196
	v_exp_f32_e32 v148, v148                                   // 00000007C3D8: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C3DC: BF870095
	.long 0xd71c0094                                           // 00000007C3E0: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 00000007C3E4: 02032B94
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 00000007C3E8: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 00000007C3EC: 7C3D24FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007C3F4: BF870002
	v_cndmask_b32_e32 v146, 0x7f800000, v148, vcc_lo           // 00000007C3F8: 032528FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007C400: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C404: BF870121
	v_bfe_u32 v148, v146, 16, 1                                // 00000007C408: D6100094 02052192
	v_mov_b32_e32 v149, 0                                      // 00000007C410: 7F2A0280
	v_add3_u32 v150, v146, v148, 0x7fff                        // 00000007C414: D6550096 03FF2992 00007FFF
	v_mov_b32_e32 v148, 0                                      // 00000007C420: 7F280280
	ds_store_b16_d16_hi v166, v150 offset:14                   // 00000007C424: DA84000E 000096A6
	s_and_saveexec_b32 s2, s28                                 // 00000007C42C: BE82201C
	s_cbranch_execz 30                                         // 00000007C430: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1fac>
	ds_load_b32 v149, v165 offset:32                           // 00000007C434: D8D80020 950000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007C43C: BF89FC07
	v_sub_f32_e32 v149, v149, v131                             // 00000007C440: 092B0795
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C444: BF870091
	v_mul_f32_e32 v150, 0x3fb8aa3b, v149                       // 00000007C448: 112D2AFF 3FB8AA3B
	v_fma_f32 v151, 0x3fb8aa3b, v149, -v150                    // 00000007C450: D6130097 865B2AFF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 00000007C45C: 7F304796
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007C460: BF870221
	v_sub_f32_e32 v150, v150, v152                             // 00000007C464: 092D3196
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 00000007C468: 7C372AFF C2CE8ED0
	v_fmac_f32_e32 v151, 0x32a5705f, v149                      // 00000007C470: 572F2AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C478: BF870121
	v_add_f32_e32 v150, v150, v151                             // 00000007C47C: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 00000007C480: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 00000007C484: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C488: BF870095
	.long 0xd71c0096                                           // 00000007C48C: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 00000007C490: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 00000007C494: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 00000007C498: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007C4A0: BF870002
	v_cndmask_b32_e32 v149, 0x7f800000, v150, vcc_lo           // 00000007C4A4: 032B2CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007C4AC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C4B0: BF870091
	v_bfe_u32 v150, v149, 16, 1                                // 00000007C4B4: D6100096 02052195
	v_add3_u32 v150, v149, v150, 0x7fff                        // 00000007C4BC: D6550096 03FF2D95 00007FFF
	ds_store_b16_d16_hi v166, v150 offset:16                   // 00000007C4C8: DA840010 000096A6
	s_and_saveexec_b32 s2, s27                                 // 00000007C4D0: BE82201B
	s_cbranch_execz 30                                         // 00000007C4D4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2050>
	ds_load_b32 v148, v165 offset:36                           // 00000007C4D8: D8D80024 940000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007C4E0: BF89FC07
	v_sub_f32_e32 v148, v148, v131                             // 00000007C4E4: 09290794
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C4E8: BF870121
	v_mul_f32_e32 v150, 0x3fb8aa3b, v148                       // 00000007C4EC: 112D28FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v148                 // 00000007C4F4: 7C3728FF C2CE8ED0
	v_fma_f32 v151, 0x3fb8aa3b, v148, -v150                    // 00000007C4FC: D6130097 865B28FF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 00000007C508: 7F304796
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007C50C: BF870112
	v_fmac_f32_e32 v151, 0x32a5705f, v148                      // 00000007C510: 572F28FF 32A5705F
	v_sub_f32_e32 v150, v150, v152                             // 00000007C518: 092D3196
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C51C: BF870121
	v_add_f32_e32 v150, v150, v151                             // 00000007C520: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 00000007C524: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 00000007C528: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C52C: BF870095
	.long 0xd71c0096                                           // 00000007C530: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 00000007C534: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 00000007C538: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v148                 // 00000007C53C: 7C3D28FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007C544: BF870002
	v_cndmask_b32_e32 v148, 0x7f800000, v150, vcc_lo           // 00000007C548: 03292CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007C550: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C554: BF870121
	v_bfe_u32 v150, v148, 16, 1                                // 00000007C558: D6100096 02052194
	v_mov_b32_e32 v151, 0                                      // 00000007C560: 7F2E0280
	v_add3_u32 v152, v148, v150, 0x7fff                        // 00000007C564: D6550098 03FF2D94 00007FFF
	v_mov_b32_e32 v150, 0                                      // 00000007C570: 7F2C0280
	ds_store_b16_d16_hi v166, v152 offset:18                   // 00000007C574: DA840012 000098A6
	s_and_saveexec_b32 s2, s26                                 // 00000007C57C: BE82201A
	s_cbranch_execz 30                                         // 00000007C580: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x20fc>
	ds_load_b32 v151, v165 offset:40                           // 00000007C584: D8D80028 970000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007C58C: BF89FC07
	v_sub_f32_e32 v151, v151, v131                             // 00000007C590: 092F0797
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C594: BF870091
	v_mul_f32_e32 v152, 0x3fb8aa3b, v151                       // 00000007C598: 11312EFF 3FB8AA3B
	v_fma_f32 v153, 0x3fb8aa3b, v151, -v152                    // 00000007C5A0: D6130099 86632EFF 3FB8AA3B
	v_rndne_f32_e32 v178, v152                                 // 00000007C5AC: 7F644798
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007C5B0: BF870221
	v_sub_f32_e32 v152, v152, v178                             // 00000007C5B4: 09316598
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 00000007C5B8: 7C372EFF C2CE8ED0
	v_fmac_f32_e32 v153, 0x32a5705f, v151                      // 00000007C5C0: 57332EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C5C8: BF870121
	v_add_f32_e32 v152, v152, v153                             // 00000007C5CC: 07313398
	v_cvt_i32_f32_e32 v153, v178                               // 00000007C5D0: 7F3211B2
	v_exp_f32_e32 v152, v152                                   // 00000007C5D4: 7F304B98
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C5D8: BF870095
	.long 0xd71c0098                                           // 00000007C5DC: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 00000007C5E0: 02033398
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 00000007C5E4: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 00000007C5E8: 7C3D2EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007C5F0: BF870002
	v_cndmask_b32_e32 v151, 0x7f800000, v152, vcc_lo           // 00000007C5F4: 032F30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007C5FC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C600: BF870091
	v_bfe_u32 v152, v151, 16, 1                                // 00000007C604: D6100098 02052197
	v_add3_u32 v152, v151, v152, 0x7fff                        // 00000007C60C: D6550098 03FF3197 00007FFF
	ds_store_b16_d16_hi v166, v152 offset:20                   // 00000007C618: DA840014 000098A6
	s_and_saveexec_b32 s2, s25                                 // 00000007C620: BE822019
	s_cbranch_execz 30                                         // 00000007C624: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21a0>
	ds_load_b32 v150, v165 offset:44                           // 00000007C628: D8D8002C 960000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007C630: BF89FC07
	v_sub_f32_e32 v150, v150, v131                             // 00000007C634: 092D0796
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C638: BF870121
	v_mul_f32_e32 v152, 0x3fb8aa3b, v150                       // 00000007C63C: 11312CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 00000007C644: 7C372CFF C2CE8ED0
	v_fma_f32 v153, 0x3fb8aa3b, v150, -v152                    // 00000007C64C: D6130099 86632CFF 3FB8AA3B
	v_rndne_f32_e32 v178, v152                                 // 00000007C658: 7F644798
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007C65C: BF870112
	v_fmac_f32_e32 v153, 0x32a5705f, v150                      // 00000007C660: 57332CFF 32A5705F
	v_sub_f32_e32 v152, v152, v178                             // 00000007C668: 09316598
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C66C: BF870121
	v_add_f32_e32 v152, v152, v153                             // 00000007C670: 07313398
	v_cvt_i32_f32_e32 v153, v178                               // 00000007C674: 7F3211B2
	v_exp_f32_e32 v152, v152                                   // 00000007C678: 7F304B98
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C67C: BF870095
	.long 0xd71c0098                                           // 00000007C680: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 00000007C684: 02033398
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 00000007C688: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 00000007C68C: 7C3D2CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007C694: BF870002
	v_cndmask_b32_e32 v150, 0x7f800000, v152, vcc_lo           // 00000007C698: 032D30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007C6A0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C6A4: BF870121
	v_bfe_u32 v152, v150, 16, 1                                // 00000007C6A8: D6100098 02052196
	v_mov_b32_e32 v153, 0                                      // 00000007C6B0: 7F320280
	v_add3_u32 v178, v150, v152, 0x7fff                        // 00000007C6B4: D65500B2 03FF3196 00007FFF
	v_mov_b32_e32 v152, 0                                      // 00000007C6C0: 7F300280
	ds_store_b16_d16_hi v166, v178 offset:22                   // 00000007C6C4: DA840016 0000B2A6
	s_and_saveexec_b32 s2, s24                                 // 00000007C6CC: BE822018
	s_cbranch_execz 30                                         // 00000007C6D0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x224c>
	ds_load_b32 v153, v165 offset:48                           // 00000007C6D4: D8D80030 990000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007C6DC: BF89FC07
	v_sub_f32_e32 v153, v153, v131                             // 00000007C6E0: 09330799
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C6E4: BF870091
	v_mul_f32_e32 v178, 0x3fb8aa3b, v153                       // 00000007C6E8: 116532FF 3FB8AA3B
	v_fma_f32 v179, 0x3fb8aa3b, v153, -v178                    // 00000007C6F0: D61300B3 86CB32FF 3FB8AA3B
	v_rndne_f32_e32 v180, v178                                 // 00000007C6FC: 7F6847B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007C700: BF870221
	v_sub_f32_e32 v178, v178, v180                             // 00000007C704: 096569B2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 00000007C708: 7C3732FF C2CE8ED0
	v_fmac_f32_e32 v179, 0x32a5705f, v153                      // 00000007C710: 576732FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C718: BF870121
	v_add_f32_e32 v178, v178, v179                             // 00000007C71C: 076567B2
	v_cvt_i32_f32_e32 v179, v180                               // 00000007C720: 7F6611B4
	v_exp_f32_e32 v178, v178                                   // 00000007C724: 7F644BB2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C728: BF870095
	.long 0xd71c00b2                                           // 00000007C72C: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 00000007C730: 020367B2
	v_cndmask_b32_e32 v178, 0, v178, vcc_lo                    // 00000007C734: 03656480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 00000007C738: 7C3D32FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007C740: BF870002
	v_cndmask_b32_e32 v153, 0x7f800000, v178, vcc_lo           // 00000007C744: 033364FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007C74C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C750: BF870091
	v_bfe_u32 v178, v153, 16, 1                                // 00000007C754: D61000B2 02052199
	v_add3_u32 v178, v153, v178, 0x7fff                        // 00000007C75C: D65500B2 03FF6599 00007FFF
	ds_store_b16_d16_hi v166, v178 offset:24                   // 00000007C768: DA840018 0000B2A6
	s_and_saveexec_b32 s2, s9                                  // 00000007C770: BE822009
	s_cbranch_execz 30                                         // 00000007C774: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x22f0>
	ds_load_b32 v152, v165 offset:52                           // 00000007C778: D8D80034 980000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007C780: BF89FC07
	v_sub_f32_e32 v152, v152, v131                             // 00000007C784: 09310798
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C788: BF870121
	v_mul_f32_e32 v178, 0x3fb8aa3b, v152                       // 00000007C78C: 116530FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 00000007C794: 7C3730FF C2CE8ED0
	v_fma_f32 v179, 0x3fb8aa3b, v152, -v178                    // 00000007C79C: D61300B3 86CB30FF 3FB8AA3B
	v_rndne_f32_e32 v180, v178                                 // 00000007C7A8: 7F6847B2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007C7AC: BF870112
	v_fmac_f32_e32 v179, 0x32a5705f, v152                      // 00000007C7B0: 576730FF 32A5705F
	v_sub_f32_e32 v178, v178, v180                             // 00000007C7B8: 096569B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C7BC: BF870121
	v_add_f32_e32 v178, v178, v179                             // 00000007C7C0: 076567B2
	v_cvt_i32_f32_e32 v179, v180                               // 00000007C7C4: 7F6611B4
	v_exp_f32_e32 v178, v178                                   // 00000007C7C8: 7F644BB2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C7CC: BF870095
	.long 0xd71c00b2                                           // 00000007C7D0: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 00000007C7D4: 020367B2
	v_cndmask_b32_e32 v178, 0, v178, vcc_lo                    // 00000007C7D8: 03656480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 00000007C7DC: 7C3D30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007C7E4: BF870002
	v_cndmask_b32_e32 v152, 0x7f800000, v178, vcc_lo           // 00000007C7E8: 033164FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007C7F0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C7F4: BF870121
	v_bfe_u32 v178, v152, 16, 1                                // 00000007C7F8: D61000B2 02052198
	v_mov_b32_e32 v179, 0                                      // 00000007C800: 7F660280
	v_add3_u32 v180, v152, v178, 0x7fff                        // 00000007C804: D65500B4 03FF6598 00007FFF
	v_mov_b32_e32 v178, 0                                      // 00000007C810: 7F640280
	ds_store_b16_d16_hi v166, v180 offset:26                   // 00000007C814: DA84001A 0000B4A6
	s_and_saveexec_b32 s2, s8                                  // 00000007C81C: BE822008
	s_cbranch_execz 30                                         // 00000007C820: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x239c>
	ds_load_b32 v179, v165 offset:56                           // 00000007C824: D8D80038 B30000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007C82C: BF89FC07
	v_sub_f32_e32 v179, v179, v131                             // 00000007C830: 096707B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C834: BF870091
	v_mul_f32_e32 v180, 0x3fb8aa3b, v179                       // 00000007C838: 116966FF 3FB8AA3B
	v_fma_f32 v181, 0x3fb8aa3b, v179, -v180                    // 00000007C840: D61300B5 86D366FF 3FB8AA3B
	v_rndne_f32_e32 v182, v180                                 // 00000007C84C: 7F6C47B4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007C850: BF870221
	v_sub_f32_e32 v180, v180, v182                             // 00000007C854: 09696DB4
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v179                 // 00000007C858: 7C3766FF C2CE8ED0
	v_fmac_f32_e32 v181, 0x32a5705f, v179                      // 00000007C860: 576B66FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C868: BF870121
	v_add_f32_e32 v180, v180, v181                             // 00000007C86C: 07696BB4
	v_cvt_i32_f32_e32 v181, v182                               // 00000007C870: 7F6A11B6
	v_exp_f32_e32 v180, v180                                   // 00000007C874: 7F684BB4
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C878: BF870095
	.long 0xd71c00b4                                           // 00000007C87C: D71C00B4
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                   // 00000007C880: 02036BB4
	v_cndmask_b32_e32 v180, 0, v180, vcc_lo                    // 00000007C884: 03696880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v179                 // 00000007C888: 7C3D66FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007C890: BF870002
	v_cndmask_b32_e32 v179, 0x7f800000, v180, vcc_lo           // 00000007C894: 036768FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007C89C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C8A0: BF870091
	v_bfe_u32 v180, v179, 16, 1                                // 00000007C8A4: D61000B4 020521B3
	v_add3_u32 v180, v179, v180, 0x7fff                        // 00000007C8AC: D65500B4 03FF69B3 00007FFF
	ds_store_b16_d16_hi v166, v180 offset:28                   // 00000007C8B8: DA84001C 0000B4A6
	s_and_saveexec_b32 s2, s1                                  // 00000007C8C0: BE822001
	s_cbranch_execz 30                                         // 00000007C8C4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2440>
	ds_load_b32 v178, v165 offset:60                           // 00000007C8C8: D8D8003C B20000A5
	s_waitcnt lgkmcnt(0)                                       // 00000007C8D0: BF89FC07
	v_sub_f32_e32 v178, v178, v131                             // 00000007C8D4: 096507B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C8D8: BF870121
	v_mul_f32_e32 v180, 0x3fb8aa3b, v178                       // 00000007C8DC: 116964FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v178                 // 00000007C8E4: 7C3764FF C2CE8ED0
	v_fma_f32 v181, 0x3fb8aa3b, v178, -v180                    // 00000007C8EC: D61300B5 86D364FF 3FB8AA3B
	v_rndne_f32_e32 v182, v180                                 // 00000007C8F8: 7F6C47B4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007C8FC: BF870112
	v_fmac_f32_e32 v181, 0x32a5705f, v178                      // 00000007C900: 576B64FF 32A5705F
	v_sub_f32_e32 v180, v180, v182                             // 00000007C908: 09696DB4
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C90C: BF870121
	v_add_f32_e32 v180, v180, v181                             // 00000007C910: 07696BB4
	v_cvt_i32_f32_e32 v181, v182                               // 00000007C914: 7F6A11B6
	v_exp_f32_e32 v180, v180                                   // 00000007C918: 7F684BB4
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C91C: BF870095
	.long 0xd71c00b4                                           // 00000007C920: D71C00B4
	v_cndmask_b32_e32 v1, v180, v181, vcc_lo                   // 00000007C924: 02036BB4
	v_cndmask_b32_e32 v180, 0, v180, vcc_lo                    // 00000007C928: 03696880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v178                 // 00000007C92C: 7C3D64FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007C934: BF870002
	v_cndmask_b32_e32 v178, 0x7f800000, v180, vcc_lo           // 00000007C938: 036568FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007C940: 8C7E027E
	v_add_f32_e32 v132, v133, v132                             // 00000007C944: 07090985
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007C948: BF870122
	v_bfe_u32 v133, v178, 16, 1                                // 00000007C94C: D6100085 020521B2
	s_mov_b32 s1, 0                                            // 00000007C954: BE810080
	v_add_f32_e32 v132, v132, v135                             // 00000007C958: 07090F84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007C95C: BF870112
	v_add3_u32 v133, v178, v133, 0x7fff                        // 00000007C960: D6550085 03FF0BB2 00007FFF
	v_add_f32_e32 v132, v132, v134                             // 00000007C96C: 07090D84
	ds_store_b16_d16_hi v166, v133 offset:30                   // 00000007C970: DA84001E 000085A6
	v_add_f32_e32 v132, v132, v137                             // 00000007C978: 07091384
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C97C: BF870091
	v_add_f32_e32 v132, v132, v136                             // 00000007C980: 07091184
	v_add_f32_e32 v132, v132, v147                             // 00000007C984: 07092784
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C988: BF870091
	v_add_f32_e32 v132, v132, v146                             // 00000007C98C: 07092584
	v_add_f32_e32 v132, v132, v149                             // 00000007C990: 07092B84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C994: BF870091
	v_add_f32_e32 v132, v132, v148                             // 00000007C998: 07092984
	v_add_f32_e32 v132, v132, v151                             // 00000007C99C: 07092F84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C9A0: BF870091
	v_add_f32_e32 v132, v132, v150                             // 00000007C9A4: 07092D84
	v_add_f32_e32 v132, v132, v153                             // 00000007C9A8: 07093384
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007C9AC: BF870091
	v_add_f32_e32 v132, v132, v152                             // 00000007C9B0: 07093184
	v_add_f32_e32 v132, v132, v179                             // 00000007C9B4: 07096784
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007C9B8: BF870001
	v_add_f32_e32 v132, v132, v178                             // 00000007C9BC: 07096584
	s_and_b32 vcc_lo, exec_lo, s1                              // 00000007C9C0: 8B6A017E
	s_cbranch_vccz 584                                         // 00000007C9C4: BFA30248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2de8>
	ds_load_2addr_b32 v[133:134], v165 offset1:1               // 00000007C9C8: D8DC0100 850000A5
	ds_load_2addr_b32 v[135:136], v165 offset0:2 offset1:3     // 00000007C9D0: D8DC0302 870000A5
	ds_load_2addr_b32 v[146:147], v165 offset0:4 offset1:5     // 00000007C9D8: D8DC0504 920000A5
	ds_load_2addr_b32 v[148:149], v165 offset0:6 offset1:7     // 00000007C9E0: D8DC0706 940000A5
	ds_load_2addr_b32 v[150:151], v165 offset0:8 offset1:9     // 00000007C9E8: D8DC0908 960000A5
	ds_load_2addr_b32 v[152:153], v165 offset0:10 offset1:11   // 00000007C9F0: D8DC0B0A 980000A5
	ds_load_2addr_b32 v[178:179], v165 offset0:12 offset1:13   // 00000007C9F8: D8DC0D0C B20000A5
	ds_load_2addr_b32 v[180:181], v165 offset0:14 offset1:15   // 00000007CA00: D8DC0F0E B40000A5
	.long 0xd59c4084                                           // 00000007CA08: D59C4084
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 00000007CA0C: 02010080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000007CA10: BF8700D1
	.long 0xd59c4889                                           // 00000007CA14: D59C4889
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000007CA18: 02010184
	.long 0xd59c48b6                                           // 00000007CA1C: D59C48B6
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000007CA20: 02010184
	s_waitcnt lgkmcnt(7)                                       // 00000007CA24: BF89FC77
	v_max3_f32 v131, v130, v133, v134                          // 00000007CA28: D61C0083 061B0B82
	s_waitcnt lgkmcnt(6)                                       // 00000007CA30: BF89FC67
	v_max3_f32 v131, v131, v135, v136                          // 00000007CA34: D61C0083 06230F83
	s_waitcnt lgkmcnt(5)                                       // 00000007CA3C: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007CA40: BF8700A1
	v_max3_f32 v131, v131, v146, v147                          // 00000007CA44: D61C0083 064F2583
	s_waitcnt lgkmcnt(4)                                       // 00000007CA4C: BF89FC47
	v_max3_f32 v131, v131, v148, v149                          // 00000007CA50: D61C0083 06572983
	s_waitcnt lgkmcnt(3)                                       // 00000007CA58: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007CA5C: BF8700A1
	v_max3_f32 v131, v131, v150, v151                          // 00000007CA60: D61C0083 065F2D83
	s_waitcnt lgkmcnt(2)                                       // 00000007CA68: BF89FC27
	v_max3_f32 v131, v131, v152, v153                          // 00000007CA6C: D61C0083 06673183
	s_waitcnt lgkmcnt(1)                                       // 00000007CA74: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007CA78: BF8700A1
	v_max3_f32 v131, v131, v178, v179                          // 00000007CA7C: D61C0083 06CF6583
	s_waitcnt lgkmcnt(0)                                       // 00000007CA84: BF89FC07
	v_max3_f32 v131, v131, v180, v181                          // 00000007CA88: D61C0083 06D76983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000007CA90: BF870241
	v_sub_f32_e32 v133, v133, v131                             // 00000007CA94: 090B0785
	v_sub_f32_e32 v134, v134, v131                             // 00000007CA98: 090D0786
	v_sub_f32_e32 v150, v150, v131                             // 00000007CA9C: 092D0796
	v_sub_f32_e32 v153, v153, v131                             // 00000007CAA0: 09330799
	v_dual_sub_f32 v152, v152, v131 :: v_dual_mul_f32 v183, 0x3fb8aa3b, v133// 00000007CAA4: C9470798 98B70AFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007CAB0: BF870004
	v_mul_f32_e32 v184, 0x3fb8aa3b, v134                       // 00000007CAB4: 11710CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 00000007CABC: 7C370AFF C2CE8ED0
	v_sub_f32_e32 v151, v151, v131                             // 00000007CAC4: 092F0797
	v_sub_f32_e32 v178, v178, v131                             // 00000007CAC8: 096507B2
	v_fma_f32 v191, 0x3fb8aa3b, v133, -v183                    // 00000007CACC: D61300BF 86DF0AFF 3FB8AA3B
	v_rndne_f32_e32 v194, v184                                 // 00000007CAD8: 7F8447B8
	v_sub_f32_e32 v149, v149, v131                             // 00000007CADC: 092B0795
	v_fma_f32 v193, 0x3fb8aa3b, v134, -v184                    // 00000007CAE0: D61300C1 86E30CFF 3FB8AA3B
	v_rndne_f32_e32 v192, v183                                 // 00000007CAEC: 7F8047B7
	v_dual_sub_f32 v148, v148, v131 :: v_dual_fmac_f32 v191, 0x32a5705f, v133// 00000007CAF0: C9410794 94BF0AFF 32A5705F
	v_sub_f32_e32 v184, v184, v194                             // 00000007CAFC: 097185B8
	v_dual_sub_f32 v136, v136, v131 :: v_dual_mul_f32 v189, 0x3fb8aa3b, v149// 00000007CB00: C9470788 88BD2AFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000007CB0C: BF8701A4
	v_dual_sub_f32 v146, v146, v131 :: v_dual_sub_f32 v183, v183, v192// 00000007CB10: C94B0792 92B781B7
	v_cvt_i32_f32_e32 v192, v192                               // 00000007CB18: 7F8011C0
	v_mul_f32_e32 v185, 0x3fb8aa3b, v136                       // 00000007CB1C: 117310FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000007CB24: BF870213
	v_dual_sub_f32 v135, v135, v131 :: v_dual_mul_f32 v188, 0x3fb8aa3b, v146// 00000007CB28: C9470787 87BD24FF 3FB8AA3B
	v_add_f32_e32 v183, v183, v191                             // 00000007CB34: 076F7FB7
	v_dual_sub_f32 v147, v147, v131 :: v_dual_mul_f32 v190, 0x3fb8aa3b, v148// 00000007CB38: C9470793 93BF28FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007CB44: BF870223
	v_mul_f32_e32 v186, 0x3fb8aa3b, v135                       // 00000007CB48: 11750EFF 3FB8AA3B
	v_fma_f32 v195, 0x3fb8aa3b, v136, -v185                    // 00000007CB50: D61300C3 86E710FF 3FB8AA3B
	v_exp_f32_e32 v183, v183                                   // 00000007CB5C: 7F6E4BB7
	v_fma_f32 v201, 0x3fb8aa3b, v146, -v188                    // 00000007CB60: D61300C9 86F324FF 3FB8AA3B
	v_rndne_f32_e32 v202, v188                                 // 00000007CB6C: 7F9447BC
	v_fma_f32 v197, 0x3fb8aa3b, v135, -v186                    // 00000007CB70: D61300C5 86EB0EFF 3FB8AA3B
	v_rndne_f32_e32 v198, v186                                 // 00000007CB7C: 7F8C47BA
	v_fmac_f32_e32 v195, 0x32a5705f, v136                      // 00000007CB80: 578710FF 32A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007CB88: BF870224
	v_dual_mul_f32 v187, 0x3fb8aa3b, v147 :: v_dual_sub_f32 v188, v188, v202// 00000007CB8C: C8CB26FF BBBD95BC 3FB8AA3B
	v_rndne_f32_e32 v196, v185                                 // 00000007CB98: 7F8847B9
	v_sub_f32_e32 v186, v186, v198                             // 00000007CB9C: 09758DBA
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000007CBA0: BF870005
	.long 0xd71c00b7                                           // 00000007CBA4: D71C00B7
	v_cndmask_b32_e32 v1, v183, v192, vcc_lo                   // 00000007CBA8: 020381B7
	v_cvt_i32_f32_e32 v194, v194                               // 00000007CBAC: 7F8411C2
	v_fma_f32 v199, 0x3fb8aa3b, v147, -v187                    // 00000007CBB0: D61300C7 86EF26FF 3FB8AA3B
	v_rndne_f32_e32 v200, v187                                 // 00000007CBBC: 7F9047BB
	v_cvt_i32_f32_e32 v198, v198                               // 00000007CBC0: 7F8C11C6
	v_cndmask_b32_e32 v183, 0, v183, vcc_lo                    // 00000007CBC4: 036F6E80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 00000007CBC8: 7C370CFF C2CE8ED0
	v_fmac_f32_e32 v201, 0x32a5705f, v146                      // 00000007CBD0: 579324FF 32A5705F
	v_fmac_f32_e32 v197, 0x32a5705f, v135                      // 00000007CBD8: 578B0EFF 32A5705F
	v_rndne_f32_e32 v206, v190                                 // 00000007CBE0: 7F9C47BE
	v_fmac_f32_e32 v199, 0x32a5705f, v147                      // 00000007CBE4: 578F26FF 32A5705F
	v_fma_f32 v205, 0x3fb8aa3b, v148, -v190                    // 00000007CBEC: D61300CD 86FB28FF 3FB8AA3B
	v_dual_add_f32 v188, v188, v201 :: v_dual_fmac_f32 v193, 0x32a5705f, v134// 00000007CBF8: C90193BC BCC10CFF 32A5705F
	v_dual_add_f32 v186, v186, v197 :: v_dual_sub_f32 v185, v185, v196// 00000007CC04: C90B8BBA BAB989B9
	v_cvt_i32_f32_e32 v196, v196                               // 00000007CC0C: 7F8811C4
	v_sub_f32_e32 v190, v190, v206                             // 00000007CC10: 097D9DBE
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000007CC14: BF870214
	v_add_f32_e32 v184, v184, v193                             // 00000007CC18: 077183B8
	v_exp_f32_e32 v186, v186                                   // 00000007CC1C: 7F744BBA
	v_add_f32_e32 v185, v185, v195                             // 00000007CC20: 077387B9
	v_exp_f32_e32 v188, v188                                   // 00000007CC24: 7F784BBC
	v_cvt_i32_f32_e32 v202, v202                               // 00000007CC28: 7F9411CA
	v_exp_f32_e32 v184, v184                                   // 00000007CC2C: 7F704BB8
	v_fma_f32 v203, 0x3fb8aa3b, v149, -v189                    // 00000007CC30: D61300CB 86F72AFF 3FB8AA3B
	v_exp_f32_e32 v185, v185                                   // 00000007CC3C: 7F724BB9
	v_rndne_f32_e32 v204, v189                                 // 00000007CC40: 7F9847BD
	v_sub_f32_e32 v180, v180, v131                             // 00000007CC44: 096907B4
	.long 0xd71c00ba                                           // 00000007CC48: D71C00BA
	v_cndmask_b32_e32 v1, v186, v198, vcc_lo                   // 00000007CC4C: 02038DBA
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000007CC50: BF870317
	.long 0xd71c00bc                                           // 00000007CC54: D71C00BC
	v_cndmask_b32_e32 v1, v188, v202, vcc_lo                   // 00000007CC58: 020395BC
	.long 0xd71c00b8                                           // 00000007CC5C: D71C00B8
	v_cndmask_b32_e32 v1, v184, v194, vcc_lo                   // 00000007CC60: 020385B8
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007CC64: BF870115
	.long 0xd71c00b9                                           // 00000007CC68: D71C00B9
	v_cndmask_b32_e32 v1, v185, v196, vcc_lo                   // 00000007CC6C: 020389B9
	v_cndmask_b32_e32 v184, 0, v184, vcc_lo                    // 00000007CC70: 03717080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 00000007CC74: 7C3710FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000007CC7C: BF870143
	v_cndmask_b32_e32 v185, 0, v185, vcc_lo                    // 00000007CC80: 03737280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 00000007CC84: 7C370EFF C2CE8ED0
	v_sub_f32_e32 v187, v187, v200                             // 00000007CC8C: 097791BB
	v_cvt_i32_f32_e32 v200, v200                               // 00000007CC90: 7F9011C8
	v_dual_cndmask_b32 v186, 0, v186 :: v_dual_add_f32 v187, v187, v199// 00000007CC94: CA497480 BABB8FBB
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v147                 // 00000007CC9C: 7C3726FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007CCA4: BF870292
	v_exp_f32_e32 v187, v187                                   // 00000007CCA8: 7F764BBB
	.long 0xd71c00bb                                           // 00000007CCAC: D71C00BB
	v_cndmask_b32_e32 v1, v187, v200, vcc_lo                   // 00000007CCB0: 020391BB
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000007CCB4: BF870141
	v_cndmask_b32_e32 v187, 0, v187, vcc_lo                    // 00000007CCB8: 03777680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 00000007CCBC: 7C3D0CFF 42B17218
	v_cndmask_b32_e32 v134, 0x7f800000, v184, vcc_lo           // 00000007CCC4: 030D70FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 00000007CCCC: 7C3D0AFF 42B17218
	.long 0xd59c0884                                           // 00000007CCD4: D59C0884
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 00000007CCD8: 02010186
	v_cndmask_b32_e32 v133, 0x7f800000, v183, vcc_lo           // 00000007CCDC: 030B6EFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 00000007CCE4: 7C3D0EFF 42B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007CCEC: BF870193
	v_and_b32_e32 v184, 1, v132                                // 00000007CCF0: 37710881
	.long 0xd59c0889                                           // 00000007CCF4: D59C0889
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 00000007CCF8: 02010185
	v_cndmask_b32_e32 v135, 0x7f800000, v186, vcc_lo           // 00000007CCFC: 030F74FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 00000007CD04: 7C3D10FF 42B17218
	v_add_f32_e32 v183, v133, v134                             // 00000007CD0C: 076F0D85
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000007CD10: BF870214
	v_and_b32_e32 v137, 1, v137                                // 00000007CD14: 37131281
	.long 0xd59c08b6                                           // 00000007CD18: D59C08B6
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 00000007CD1C: 02010187
	v_cndmask_b32_e32 v136, 0x7f800000, v185, vcc_lo           // 00000007CD20: 031172FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 00000007CD28: 7C3724FF C2CE8ED0
	v_fmac_f32_e32 v203, 0x32a5705f, v149                      // 00000007CD30: 57972AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007CD38: BF870004
	v_dual_add_f32 v183, v183, v135 :: v_dual_and_b32 v182, 1, v182// 00000007CD3C: C9250FB7 B7B76C81
	v_fmac_f32_e32 v205, 0x32a5705f, v148                      // 00000007CD44: 579B28FF 32A5705F
	v_sub_f32_e32 v189, v189, v204                             // 00000007CD4C: 097B99BD
	v_cndmask_b32_e32 v185, 0, v188, vcc_lo                    // 00000007CD50: 03737880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 00000007CD54: 7C3D24FF 42B17218
	.long 0xd59c0884                                           // 00000007CD5C: D59C0884
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 00000007CD60: 02010188
	v_add3_u32 v137, v133, v137, 0x7fff                        // 00000007CD64: D6550089 03FF1385 00007FFF
	v_add3_u32 v133, v134, v184, 0x7fff                        // 00000007CD70: D6550085 03FF7186 00007FFF
	v_add3_u32 v182, v135, v182, 0x7fff                        // 00000007CD7C: D65500B6 03FF6D87 00007FFF
	v_cndmask_b32_e32 v135, 0x7f800000, v185, vcc_lo           // 00000007CD88: 030F72FF 7F800000
	v_add_f32_e32 v184, v190, v205                             // 00000007CD90: 07719BBE
	v_add_f32_e32 v146, v189, v203                             // 00000007CD94: 072597BD
	v_and_b32_e32 v186, 1, v132                                // 00000007CD98: 37750881
	.long 0xd59c48b9                                           // 00000007CD9C: D59C48B9
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000007CDA0: 02010184
	.long 0xd59c08b9                                           // 00000007CDA4: D59C08B9
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 00000007CDA8: 02010187
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v147                 // 00000007CDAC: 7C3D26FF 42B17218
	v_exp_f32_e32 v146, v146                                   // 00000007CDB4: 7F244B92
	v_add3_u32 v134, v136, v186, 0x7fff                        // 00000007CDB8: D6550086 03FF7588 00007FFF
	v_exp_f32_e32 v184, v184                                   // 00000007CDC4: 7F704BB8
	v_add_f32_e32 v136, v183, v136                             // 00000007CDC8: 071111B7
	v_cvt_i32_f32_e32 v183, v204                               // 00000007CDCC: 7F6E11CC
	v_and_b32_e32 v185, 1, v185                                // 00000007CDD0: 37737281
	.long 0xd59c0885                                           // 00000007CDD4: D59C0885
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 00000007CDD8: 02010189
	.long 0xd59c0886                                           // 00000007CDDC: D59C0886
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                   // 00000007CDE0: 020101B6
	v_add_f32_e32 v136, v136, v135                             // 00000007CDE4: 07110F88
	s_delay_alu instid0(TRANS32_DEP_2)                         // 00000007CDE8: BF870006
	.long 0xd71c0092                                           // 00000007CDEC: D71C0092
	v_cndmask_b32_e32 v1, v146, v183, vcc_lo                   // 00000007CDF0: 02036F92
	v_add3_u32 v183, v135, v185, 0x7fff                        // 00000007CDF4: D65500B7 03FF7387 00007FFF
	.long 0xd59c48b9                                           // 00000007CE00: D59C48B9
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000007CE04: 02010184
	v_cndmask_b32_e32 v147, 0x7f800000, v187, vcc_lo           // 00000007CE08: 032776FF 7F800000
	v_cvt_i32_f32_e32 v187, v206                               // 00000007CE10: 7F7611CE
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 00000007CE14: 7C372AFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007CE1C: BF870193
	.long 0xd59c0884                                           // 00000007CE20: D59C0884
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 00000007CE24: 02010193
	.long 0xd71c00b8                                           // 00000007CE28: D71C00B8
	v_cndmask_b32_e32 v1, v184, v187, vcc_lo                   // 00000007CE2C: 020377B8
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 00000007CE30: 03252480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v148                 // 00000007CE34: 7C3728FF C2CE8ED0
	v_add_f32_e32 v136, v136, v147                             // 00000007CE3C: 07112788
	v_and_b32_e32 v186, 1, v132                                // 00000007CE40: 37750881
	v_cndmask_b32_e32 v184, 0, v184, vcc_lo                    // 00000007CE44: 03717080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 00000007CE48: 7C3D2AFF 42B17218
	v_mul_f32_e32 v149, 0x3fb8aa3b, v151                       // 00000007CE50: 112B2EFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000007CE58: BF8701D4
	v_add3_u32 v135, v147, v186, 0x7fff                        // 00000007CE5C: D6550087 03FF7593 00007FFF
	.long 0xd59c0887                                           // 00000007CE68: D59C0887
	v_cndmask_b32_e32 v0, v183, v128, vcc_lo                   // 00000007CE6C: 020101B7
	v_cndmask_b32_e32 v146, 0x7f800000, v146, vcc_lo           // 00000007CE70: 032524FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v148                 // 00000007CE78: 7C3D28FF 42B17218
	v_fma_f32 v148, 0x3fb8aa3b, v151, -v149                    // 00000007CE80: D6130094 86572EFF 3FB8AA3B
	.long 0xd59c0884                                           // 00000007CE8C: D59C0884
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                   // 00000007CE90: 02010192
	v_cndmask_b32_e32 v147, 0x7f800000, v184, vcc_lo           // 00000007CE94: 032770FF 7F800000
	v_rndne_f32_e32 v184, v149                                 // 00000007CE9C: 7F704795
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007CEA0: BF870194
	v_fmac_f32_e32 v148, 0x32a5705f, v151                      // 00000007CEA4: 57292EFF 32A5705F
	.long 0xd59c08b9                                           // 00000007CEAC: D59C08B9
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 00000007CEB0: 02010193
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007CEB4: BF870113
	v_dual_sub_f32 v149, v149, v184 :: v_dual_mul_f32 v186, 0x3fb8aa3b, v150// 00000007CEB8: C9477195 95BB2CFF 3FB8AA3B
	v_dual_add_f32 v187, v136, v147 :: v_dual_and_b32 v136, 1, v185// 00000007CEC4: C9252788 BB897281
	v_and_b32_e32 v185, 1, v132                                // 00000007CECC: 37730881
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000007CED0: BF870213
	v_add_f32_e32 v148, v149, v148                             // 00000007CED4: 07292995
	v_fma_f32 v149, 0x3fb8aa3b, v150, -v186                    // 00000007CED8: D6130095 86EB2CFF 3FB8AA3B
	v_rndne_f32_e32 v188, v186                                 // 00000007CEE4: 7F7847BA
	v_add3_u32 v147, v147, v136, 0x7fff                        // 00000007CEE8: D6550093 03FF1193 00007FFF
	v_add3_u32 v136, v146, v185, 0x7fff                        // 00000007CEF4: D6550088 03FF7392 00007FFF
	v_exp_f32_e32 v148, v148                                   // 00000007CF00: 7F284B94
	v_fmac_f32_e32 v149, 0x32a5705f, v150                      // 00000007CF04: 572B2CFF 32A5705F
	v_sub_f32_e32 v185, v186, v188                             // 00000007CF0C: 097379BA
	.long 0xd59c0888                                           // 00000007CF10: D59C0888
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 00000007CF14: 02010193
	v_cvt_i32_f32_e32 v147, v184                               // 00000007CF18: 7F2611B8
	v_cvt_i32_f32_e32 v182, v188                               // 00000007CF1C: 7F6C11BC
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007CF20: BF870004
	v_add_f32_e32 v149, v185, v149                             // 00000007CF24: 072B2BB9
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 00000007CF28: BF870185
	.long 0xd71c0089                                           // 00000007CF2C: D71C0089
	v_cndmask_b32_e32 v1, v148, v147, vcc_lo                   // 00000007CF30: 02032794
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000007CF34: BF870132
	v_exp_f32_e32 v147, v149                                   // 00000007CF38: 7F264B95
	v_dual_mul_f32 v149, 0x3fb8aa3b, v153 :: v_dual_mul_f32 v148, 0x3fb8aa3b, v152// 00000007CF3C: C8C732FF 959530FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 00000007CF48: 7C372EFF C2CE8ED0
	v_fma_f32 v185, 0x3fb8aa3b, v153, -v149                    // 00000007CF50: D61300B9 865732FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 00000007CF5C: BF8702B3
	v_fma_f32 v183, 0x3fb8aa3b, v152, -v148                    // 00000007CF60: D61300B7 865330FF 3FB8AA3B
	v_cndmask_b32_e32 v137, 0, v137, vcc_lo                    // 00000007CF6C: 03131280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 00000007CF70: 7C372CFF C2CE8ED0
	.long 0xd71c0093                                           // 00000007CF78: D71C0093
	v_cndmask_b32_e32 v1, v147, v182, vcc_lo                   // 00000007CF7C: 02036D93
	v_rndne_f32_e32 v184, v148                                 // 00000007CF80: 7F704794
	v_rndne_f32_e32 v186, v149                                 // 00000007CF84: 7F744795
	v_fmac_f32_e32 v183, 0x32a5705f, v152                      // 00000007CF88: 576F30FF 32A5705F
	v_fmac_f32_e32 v185, 0x32a5705f, v153                      // 00000007CF90: 577332FF 32A5705F
	v_cndmask_b32_e32 v147, 0, v147, vcc_lo                    // 00000007CF98: 03272680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 00000007CF9C: 7C3D2EFF 42B17218
	v_dual_sub_f32 v148, v148, v184 :: v_dual_sub_f32 v149, v149, v186// 00000007CFA4: C94B7194 94957595
	v_cvt_i32_f32_e32 v151, v184                               // 00000007CFAC: 7F2E11B8
	v_cvt_i32_f32_e32 v182, v186                               // 00000007CFB0: 7F6C11BA
	v_cndmask_b32_e32 v137, 0x7f800000, v137, vcc_lo           // 00000007CFB4: 031312FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 00000007CFBC: 7C3D2CFF 42B17218
	v_dual_add_f32 v148, v148, v183 :: v_dual_add_f32 v149, v149, v185// 00000007CFC4: C9096F94 94957395
	.long 0xd59c4896                                           // 00000007CFCC: D59C4896
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000007CFD0: 02010184
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007CFD4: BF870224
	.long 0xd59c0884                                           // 00000007CFD8: D59C0884
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 00000007CFDC: 02010189
	v_cndmask_b32_e32 v147, 0x7f800000, v147, vcc_lo           // 00000007CFE0: 032726FF 7F800000
	v_exp_f32_e32 v148, v148                                   // 00000007CFE8: 7F284B94
	v_exp_f32_e32 v149, v149                                   // 00000007CFEC: 7F2A4B95
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 00000007CFF0: 7C3730FF C2CE8ED0
	v_and_b32_e32 v183, 1, v132                                // 00000007CFF8: 376F0881
	.long 0xd59c0896                                           // 00000007CFFC: D59C0896
	v_cndmask_b32_e32 v0, v147, v128, vcc_lo                   // 00000007D000: 02010193
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 00000007D004: BF870321
	v_dual_mul_f32 v185, 0x3fb8aa3b, v180 :: v_dual_and_b32 v150, 1, v150// 00000007D008: C8E568FF B9972C81 3FB8AA3B
	v_add_f32_e32 v146, v187, v146                             // 00000007D014: 072525BB
	.long 0xd71c0094                                           // 00000007D018: D71C0094
	v_cndmask_b32_e32 v1, v148, v151, vcc_lo                   // 00000007D01C: 02032F94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000007D020: BF870215
	.long 0xd71c0095                                           // 00000007D024: D71C0095
	v_cndmask_b32_e32 v1, v149, v182, vcc_lo                   // 00000007D028: 02036D95
	v_fma_f32 v187, 0x3fb8aa3b, v180, -v185                    // 00000007D02C: D61300BB 86E768FF 3FB8AA3B
	v_add3_u32 v150, v147, v150, 0x7fff                        // 00000007D038: D6550096 03FF2D93 00007FFF
	v_add_f32_e32 v146, v146, v147                             // 00000007D044: 07252792
	v_rndne_f32_e32 v188, v185                                 // 00000007D048: 7F7847B9
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007D04C: BF870194
	v_fmac_f32_e32 v187, 0x32a5705f, v180                      // 00000007D050: 577768FF 32A5705F
	v_dual_add_f32 v151, v146, v137 :: v_dual_cndmask_b32 v146, 0, v148// 00000007D058: C9131392 97932880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 00000007D060: 7C3732FF C2CE8ED0
	v_dual_cndmask_b32 v148, 0, v149 :: v_dual_sub_f32 v149, v179, v131// 00000007D068: CA4B2A80 949507B3
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 00000007D070: 7C3D30FF 42B17218
	.long 0xd59c48b3                                           // 00000007D078: D59C48B3
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000007D07C: 02010184
	v_cndmask_b32_e32 v152, 0x7f800000, v146, vcc_lo           // 00000007D080: 033124FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 00000007D088: 7C3D32FF 42B17218
	v_mul_f32_e32 v153, 0x3fb8aa3b, v149                       // 00000007D090: 11332AFF 3FB8AA3B
	v_add3_u32 v146, v137, v183, 0x7fff                        // 00000007D098: D6550092 03FF6F89 00007FFF
	v_mul_f32_e32 v183, 0x3fb8aa3b, v178                       // 00000007D0A4: 116F64FF 3FB8AA3B
	v_add_f32_e32 v137, v151, v152                             // 00000007D0AC: 07133197
	.long 0xd59c08b3                                           // 00000007D0B0: D59C08B3
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                   // 00000007D0B4: 02010198
	v_fma_f32 v147, 0x3fb8aa3b, v149, -v153                    // 00000007D0B8: D6130093 86672AFF 3FB8AA3B
	v_rndne_f32_e32 v151, v153                                 // 00000007D0C4: 7F2E4799
	v_rndne_f32_e32 v184, v183                                 // 00000007D0C8: 7F7047B7
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000007D0CC: BF870214
	v_dual_cndmask_b32 v148, 0x7f800000, v148 :: v_dual_and_b32 v179, 1, v179// 00000007D0D0: CA6528FF 94B36681 7F800000
	v_fmac_f32_e32 v147, 0x32a5705f, v149                      // 00000007D0DC: 57272AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007D0E4: BF870004
	v_sub_f32_e32 v153, v153, v151                             // 00000007D0E8: 09332F99
	v_cvt_i32_f32_e32 v151, v151                               // 00000007D0EC: 7F2E1197
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 00000007D0F0: 7C372AFF C2CE8ED0
	v_add3_u32 v152, v152, v179, 0x7fff                        // 00000007D0F8: D6550098 03FF6798 00007FFF
	.long 0xd59c0884                                           // 00000007D104: D59C0884
	v_cndmask_b32_e32 v0, v148, v128, vcc_lo                   // 00000007D108: 02010194
	v_add_f32_e32 v147, v153, v147                             // 00000007D10C: 07272799
	v_sub_f32_e32 v153, v181, v131                             // 00000007D110: 093307B5
	v_fma_f32 v181, 0x3fb8aa3b, v178, -v183                    // 00000007D114: D61300B5 86DF64FF 3FB8AA3B
	v_sub_f32_e32 v183, v183, v184                             // 00000007D120: 096F71B7
	v_add_f32_e32 v137, v137, v148                             // 00000007D124: 07132989
	v_exp_f32_e32 v147, v147                                   // 00000007D128: 7F264B93
	v_mul_f32_e32 v186, 0x3fb8aa3b, v153                       // 00000007D12C: 117532FF 3FB8AA3B
	v_dual_fmac_f32 v181, 0x32a5705f, v178 :: v_dual_and_b32 v182, 1, v132// 00000007D134: C82564FF B5B70881 32A5705F
	.long 0xd59c0892                                           // 00000007D140: D59C0892
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                   // 00000007D144: 02010196
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007D148: BF870193
	v_fma_f32 v189, 0x3fb8aa3b, v153, -v186                    // 00000007D14C: D61300BD 86EB32FF 3FB8AA3B
	v_add_f32_e32 v181, v183, v181                             // 00000007D158: 076B6BB7
	v_sub_f32_e32 v183, v185, v188                             // 00000007D15C: 096F79B9
	v_rndne_f32_e32 v190, v186                                 // 00000007D160: 7F7C47BA
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000007D164: BF870005
	.long 0xd71c0093                                           // 00000007D168: D71C0093
	v_cndmask_b32_e32 v1, v147, v151, vcc_lo                   // 00000007D16C: 02032F93
	v_fmac_f32_e32 v189, 0x32a5705f, v153                      // 00000007D170: 577B32FF 32A5705F
	v_exp_f32_e32 v181, v181                                   // 00000007D178: 7F6A4BB5
	v_add_f32_e32 v179, v183, v187                             // 00000007D17C: 076777B7
	v_sub_f32_e32 v185, v186, v190                             // 00000007D180: 09737DBA
	v_cndmask_b32_e32 v147, 0, v147, vcc_lo                    // 00000007D184: 03272680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 00000007D188: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 00000007D190: BF870004
	v_exp_f32_e32 v151, v179                                   // 00000007D194: 7F2E4BB3
	v_cvt_i32_f32_e32 v179, v184                               // 00000007D198: 7F6611B8
	v_add_f32_e32 v183, v185, v189                             // 00000007D19C: 076F7BB9
	v_cvt_i32_f32_e32 v184, v188                               // 00000007D1A0: 7F7011BC
	v_cndmask_b32_e32 v149, 0x7f800000, v147, vcc_lo           // 00000007D1A4: 032B26FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v178                 // 00000007D1AC: 7C3764FF C2CE8ED0
	.long 0xd71c00b3                                           // 00000007D1B4: D71C00B3
	v_cndmask_b32_e32 v1, v181, v179, vcc_lo                   // 00000007D1B8: 020367B5
	v_exp_f32_e32 v183, v183                                   // 00000007D1BC: 7F6E4BB7
	v_cvt_i32_f32_e32 v181, v190                               // 00000007D1C0: 7F6A11BE
	.long 0xd59c0884                                           // 00000007D1C4: D59C0884
	v_cndmask_b32_e32 v0, v149, v128, vcc_lo                   // 00000007D1C8: 02010195
	.long 0xd71c0093                                           // 00000007D1CC: D71C0093
	v_cndmask_b32_e32 v1, v151, v184, vcc_lo                   // 00000007D1D0: 02037197
	v_cndmask_b32_e32 v151, 0, v179, vcc_lo                    // 00000007D1D4: 032F6680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v180                 // 00000007D1D8: 7C3768FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 00000007D1E0: BF8702A3
	v_cndmask_b32_e32 v147, 0, v147, vcc_lo                    // 00000007D1E4: 03272680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v178                 // 00000007D1E8: 7C3D64FF 42B17218
	.long 0xd71c00b3                                           // 00000007D1F0: D71C00B3
	v_cndmask_b32_e32 v1, v183, v181, vcc_lo                   // 00000007D1F4: 02036BB7
	v_cndmask_b32_e32 v151, 0x7f800000, v151, vcc_lo           // 00000007D1F8: 032F2EFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 00000007D200: 7C3732FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000007D208: BF870212
	v_add_f32_e32 v137, v137, v151                             // 00000007D20C: 07132F89
	v_cndmask_b32_e32 v178, 0, v179, vcc_lo                    // 00000007D210: 03656680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v180                 // 00000007D214: 7C3D68FF 42B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000007D21C: BF870253
	v_dual_add_f32 v137, v137, v149 :: v_dual_and_b32 v180, 1, v132// 00000007D220: C9252B89 89B50881
	v_cndmask_b32_e32 v179, 0x7f800000, v147, vcc_lo           // 00000007D228: 036726FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 00000007D230: 7C3D32FF 42B17218
	.long 0xd59c0893                                           // 00000007D238: D59C0893
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                   // 00000007D23C: 02010197
	.long 0xd59c4893                                           // 00000007D240: D59C4893
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000007D244: 02010184
	v_add_f32_e32 v137, v137, v179                             // 00000007D248: 07136789
	v_cndmask_b32_e32 v153, 0x7f800000, v178, vcc_lo           // 00000007D24C: 033364FF 7F800000
	.long 0xd59c08b2                                           // 00000007D254: D59C08B2
	v_cndmask_b32_e32 v0, v179, v128, vcc_lo                   // 00000007D258: 020101B3
	.long 0xd59c48b2                                           // 00000007D25C: D59C48B2
	v_cndmask_b32_e32 v0, v132, v128, vcc_lo                   // 00000007D260: 02010184
	v_and_b32_e32 v181, 1, v147                                // 00000007D264: 376B2681
	v_add3_u32 v147, v148, v182, 0x7fff                        // 00000007D268: D6550093 03FF6D94 00007FFF
	.long 0xd59c0884                                           // 00000007D274: D59C0884
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                   // 00000007D278: 02010199
	v_add3_u32 v148, v149, v180, 0x7fff                        // 00000007D27C: D6550094 03FF6995 00007FFF
	v_and_b32_e32 v178, 1, v178                                // 00000007D288: 37656481
	v_add3_u32 v151, v151, v181, 0x7fff                        // 00000007D28C: D6550097 03FF6B97 00007FFF
	.long 0xd59c0893                                           // 00000007D298: D59C0893
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                   // 00000007D29C: 02010198
	v_and_b32_e32 v132, 1, v132                                // 00000007D2A0: 37090881
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000007D2A4: BF870214
	v_add3_u32 v178, v179, v178, 0x7fff                        // 00000007D2A8: D65500B2 03FF65B3 00007FFF
	.long 0xd59c0894                                           // 00000007D2B4: D59C0894
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                   // 00000007D2B8: 02010197
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007D2BC: BF870223
	v_add3_u32 v149, v153, v132, 0x7fff                        // 00000007D2C0: D6550095 03FF0999 00007FFF
	v_add_f32_e32 v132, v137, v153                             // 00000007D2CC: 07093389
	.long 0xd59c0895                                           // 00000007D2D0: D59C0895
	v_cndmask_b32_e32 v0, v178, v128, vcc_lo                   // 00000007D2D4: 020101B2
	ds_store_b128 v166, v[133:136]                             // 00000007D2D8: DB7C0000 000085A6
	ds_store_b128 v166, v[146:149] offset:16                   // 00000007D2E0: DB7C0010 000092A6
	v_mov_b32_e32 v133, 0                                      // 00000007D2E8: 7F0A0280
	s_mov_b32 s1, exec_lo                                      // 00000007D2EC: BE81007E
	s_waitcnt lgkmcnt(0)                                       // 00000007D2F0: BF89FC07
	v_cmpx_lt_f32_e32 0xefa18f08, v130                         // 00000007D2F4: 7D2304FF EFA18F08
	s_cbranch_execz 26                                         // 00000007D2FC: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2e68>
	v_sub_f32_e32 v130, v130, v131                             // 00000007D300: 09050782
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D304: BF870091
	v_mul_f32_e32 v133, 0x3fb8aa3b, v130                       // 00000007D308: 110B04FF 3FB8AA3B
	v_fma_f32 v134, 0x3fb8aa3b, v130, -v133                    // 00000007D310: D6130086 861704FF 3FB8AA3B
	v_rndne_f32_e32 v135, v133                                 // 00000007D31C: 7F0E4785
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D320: BF870091
	v_dual_fmac_f32 v134, 0x32a5705f, v130 :: v_dual_sub_f32 v133, v133, v135// 00000007D324: C80B04FF 86850F85 32A5705F
	v_add_f32_e32 v133, v133, v134                             // 00000007D330: 070B0D85
	v_cvt_i32_f32_e32 v134, v135                               // 00000007D334: 7F0C1187
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 00000007D338: 7C3704FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007D340: BF870293
	v_exp_f32_e32 v133, v133                                   // 00000007D344: 7F0A4B85
	.long 0xd71c0085                                           // 00000007D348: D71C0085
	v_cndmask_b32_e32 v1, v133, v134, vcc_lo                   // 00000007D34C: 02030D85
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007D350: BF870121
	v_cndmask_b32_e32 v133, 0, v133, vcc_lo                    // 00000007D354: 030B0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 00000007D358: 7C3D04FF 42B17218
	v_cndmask_b32_e32 v133, 0x7f800000, v133, vcc_lo           // 00000007D360: 030B0AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007D368: 8C7E017E
	ds_load_b32 v130, v167                                     // 00000007D36C: D8D80000 820000A7
	s_waitcnt lgkmcnt(0)                                       // 00000007D374: BF89FC07
	v_fmac_f32_e32 v132, v133, v130                            // 00000007D378: 57090585
	ds_store_b32 v164, v131                                    // 00000007D37C: D8340000 000083A4
	ds_store_b32 v167, v132                                    // 00000007D384: D8340000 000084A7
	ds_store_b32 v168, v133                                    // 00000007D38C: D8340000 000085A8
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007D394: 8C7E047E
	ds_load_2addr_b32 v[152:153], v169 offset1:2               // 00000007D398: D8DC0200 980000A9
	ds_load_2addr_b32 v[150:151], v169 offset0:4 offset1:6     // 00000007D3A0: D8DC0604 960000A9
	ds_load_2addr_b32 v[148:149], v169 offset0:8 offset1:10    // 00000007D3A8: D8DC0A08 940000A9
	ds_load_2addr_b32 v[146:147], v169 offset0:12 offset1:14   // 00000007D3B0: D8DC0E0C 920000A9
	s_waitcnt lgkmcnt(3)                                       // 00000007D3B8: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v152                         // 00000007D3BC: 7C2530F2
	.long 0xd4120001                                           // 00000007D3C0: D4120001
	v_cndmask_b32_e32 v1, 1.0, v153, vcc_lo                    // 00000007D3C4: 020332F2
	s_waitcnt lgkmcnt(2)                                       // 00000007D3C8: BF89FC27
	.long 0xd4120002                                           // 00000007D3CC: D4120002
	v_cndmask_b32_e32 v1, 1.0, v150, vcc_lo                    // 00000007D3D0: 02032CF2
	.long 0xd4120004                                           // 00000007D3D4: D4120004
	v_cndmask_b32_e32 v1, 1.0, v151, vcc_lo                    // 00000007D3D8: 02032EF2
	s_and_b32 s1, vcc_lo, s1                                   // 00000007D3DC: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 00000007D3E0: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v148                         // 00000007D3E4: 7C2528F2
	s_and_b32 s2, s1, s2                                       // 00000007D3E8: 8B020201
	.long 0xd4120001                                           // 00000007D3EC: D4120001
	v_cndmask_b32_e32 v1, 1.0, v149, vcc_lo                    // 00000007D3F0: 02032AF2
	s_and_b32 s4, s2, s4                                       // 00000007D3F4: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 00000007D3F8: BF89FC07
	.long 0xd4120002                                           // 00000007D3FC: D4120002
	v_cndmask_b32_e32 v1, 1.0, v146, vcc_lo                    // 00000007D400: 020324F2
	s_and_b32 s4, s4, vcc_lo                                   // 00000007D404: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v147                         // 00000007D408: 7C2526F2
	s_and_b32 s1, s4, s1                                       // 00000007D40C: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000007D410: BF870499
	s_and_b32 s1, s1, s2                                       // 00000007D414: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 00000007D418: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D41C: BF870099
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 00000007D420: D5010082 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v130                           // 00000007D428: 7C9B0480
	ds_load_b128 v[130:133], v170                              // 00000007D42C: DBFC0000 820000AA
	ds_load_b128 v[134:137], v170 offset:16                    // 00000007D434: DBFC0010 860000AA
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 00000007D43C: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 00000007D440: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D444: BF870099
	v_cndmask_b32_e64 v178, 0, 1, s1                           // 00000007D448: D50100B2 00050280
	v_readfirstlane_b32 s1, v178                               // 00000007D450: 7E0205B2
	s_bitcmp1_b32 s1, 0                                        // 00000007D454: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 00000007D458: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007D45C: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 00000007D460: 8B6A017E
	s_cbranch_vccnz 62970                                      // 00000007D464: BFA4F5FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x750>
	v_dual_mul_f32 v121, v152, v121 :: v_dual_mul_f32 v122, v153, v122// 00000007D468: C8C6F398 797AF599
	v_dual_mul_f32 v123, v150, v123 :: v_dual_mul_f32 v124, v151, v124// 00000007D470: C8C6F796 7B7CF997
	v_dual_mul_f32 v125, v148, v125 :: v_dual_mul_f32 v126, v149, v126// 00000007D478: C8C6FB94 7D7EFD95
	v_dual_mul_f32 v127, v146, v127 :: v_dual_mul_f32 v128, v147, v128// 00000007D480: C8C6FF92 7F810193
	v_dual_mul_f32 v113, v152, v113 :: v_dual_mul_f32 v114, v153, v114// 00000007D488: C8C6E398 7172E599
	v_dual_mul_f32 v115, v150, v115 :: v_dual_mul_f32 v116, v151, v116// 00000007D490: C8C6E796 7374E997
	v_dual_mul_f32 v117, v148, v117 :: v_dual_mul_f32 v118, v149, v118// 00000007D498: C8C6EB94 7576ED95
	v_dual_mul_f32 v119, v146, v119 :: v_dual_mul_f32 v120, v147, v120// 00000007D4A0: C8C6EF92 7778F193
	v_dual_mul_f32 v105, v152, v105 :: v_dual_mul_f32 v106, v153, v106// 00000007D4A8: C8C6D398 696AD599
	v_dual_mul_f32 v107, v150, v107 :: v_dual_mul_f32 v108, v151, v108// 00000007D4B0: C8C6D796 6B6CD997
	v_dual_mul_f32 v109, v148, v109 :: v_dual_mul_f32 v110, v149, v110// 00000007D4B8: C8C6DB94 6D6EDD95
	v_dual_mul_f32 v111, v146, v111 :: v_dual_mul_f32 v112, v147, v112// 00000007D4C0: C8C6DF92 6F70E193
	v_dual_mul_f32 v97, v152, v97 :: v_dual_mul_f32 v98, v153, v98// 00000007D4C8: C8C6C398 6162C599
	v_dual_mul_f32 v99, v150, v99 :: v_dual_mul_f32 v100, v151, v100// 00000007D4D0: C8C6C796 6364C997
	v_dual_mul_f32 v101, v148, v101 :: v_dual_mul_f32 v102, v149, v102// 00000007D4D8: C8C6CB94 6566CD95
	v_dual_mul_f32 v103, v146, v103 :: v_dual_mul_f32 v104, v147, v104// 00000007D4E0: C8C6CF92 6768D193
	v_dual_mul_f32 v89, v152, v89 :: v_dual_mul_f32 v90, v153, v90// 00000007D4E8: C8C6B398 595AB599
	v_dual_mul_f32 v91, v150, v91 :: v_dual_mul_f32 v92, v151, v92// 00000007D4F0: C8C6B796 5B5CB997
	v_dual_mul_f32 v93, v148, v93 :: v_dual_mul_f32 v94, v149, v94// 00000007D4F8: C8C6BB94 5D5EBD95
	v_dual_mul_f32 v95, v146, v95 :: v_dual_mul_f32 v96, v147, v96// 00000007D500: C8C6BF92 5F60C193
	v_dual_mul_f32 v81, v152, v81 :: v_dual_mul_f32 v82, v153, v82// 00000007D508: C8C6A398 5152A599
	v_dual_mul_f32 v83, v150, v83 :: v_dual_mul_f32 v84, v151, v84// 00000007D510: C8C6A796 5354A997
	v_dual_mul_f32 v85, v148, v85 :: v_dual_mul_f32 v86, v149, v86// 00000007D518: C8C6AB94 5556AD95
	v_dual_mul_f32 v87, v146, v87 :: v_dual_mul_f32 v88, v147, v88// 00000007D520: C8C6AF92 5758B193
	v_dual_mul_f32 v73, v152, v73 :: v_dual_mul_f32 v74, v153, v74// 00000007D528: C8C69398 494A9599
	v_dual_mul_f32 v75, v150, v75 :: v_dual_mul_f32 v76, v151, v76// 00000007D530: C8C69796 4B4C9997
	v_dual_mul_f32 v77, v148, v77 :: v_dual_mul_f32 v78, v149, v78// 00000007D538: C8C69B94 4D4E9D95
	v_dual_mul_f32 v79, v146, v79 :: v_dual_mul_f32 v80, v147, v80// 00000007D540: C8C69F92 4F50A193
	v_dual_mul_f32 v65, v152, v65 :: v_dual_mul_f32 v66, v153, v66// 00000007D548: C8C68398 41428599
	v_dual_mul_f32 v67, v150, v67 :: v_dual_mul_f32 v68, v151, v68// 00000007D550: C8C68796 43448997
	v_dual_mul_f32 v69, v148, v69 :: v_dual_mul_f32 v70, v149, v70// 00000007D558: C8C68B94 45468D95
	v_dual_mul_f32 v71, v146, v71 :: v_dual_mul_f32 v72, v147, v72// 00000007D560: C8C68F92 47489193
	v_dual_mul_f32 v57, v152, v57 :: v_dual_mul_f32 v58, v153, v58// 00000007D568: C8C67398 393A7599
	v_dual_mul_f32 v59, v150, v59 :: v_dual_mul_f32 v60, v151, v60// 00000007D570: C8C67796 3B3C7997
	v_dual_mul_f32 v61, v148, v61 :: v_dual_mul_f32 v62, v149, v62// 00000007D578: C8C67B94 3D3E7D95
	v_dual_mul_f32 v63, v146, v63 :: v_dual_mul_f32 v64, v147, v64// 00000007D580: C8C67F92 3F408193
	v_dual_mul_f32 v49, v152, v49 :: v_dual_mul_f32 v50, v153, v50// 00000007D588: C8C66398 31326599
	v_dual_mul_f32 v51, v150, v51 :: v_dual_mul_f32 v52, v151, v52// 00000007D590: C8C66796 33346997
	v_dual_mul_f32 v53, v148, v53 :: v_dual_mul_f32 v54, v149, v54// 00000007D598: C8C66B94 35366D95
	v_dual_mul_f32 v55, v146, v55 :: v_dual_mul_f32 v56, v147, v56// 00000007D5A0: C8C66F92 37387193
	v_dual_mul_f32 v41, v152, v41 :: v_dual_mul_f32 v42, v153, v42// 00000007D5A8: C8C65398 292A5599
	v_dual_mul_f32 v43, v150, v43 :: v_dual_mul_f32 v44, v151, v44// 00000007D5B0: C8C65796 2B2C5997
	v_dual_mul_f32 v45, v148, v45 :: v_dual_mul_f32 v46, v149, v46// 00000007D5B8: C8C65B94 2D2E5D95
	v_dual_mul_f32 v47, v146, v47 :: v_dual_mul_f32 v48, v147, v48// 00000007D5C0: C8C65F92 2F306193
	v_dual_mul_f32 v33, v152, v33 :: v_dual_mul_f32 v34, v153, v34// 00000007D5C8: C8C64398 21224599
	v_dual_mul_f32 v35, v150, v35 :: v_dual_mul_f32 v36, v151, v36// 00000007D5D0: C8C64796 23244997
	v_dual_mul_f32 v37, v148, v37 :: v_dual_mul_f32 v38, v149, v38// 00000007D5D8: C8C64B94 25264D95
	v_dual_mul_f32 v39, v146, v39 :: v_dual_mul_f32 v40, v147, v40// 00000007D5E0: C8C64F92 27285193
	v_dual_mul_f32 v25, v152, v25 :: v_dual_mul_f32 v26, v153, v26// 00000007D5E8: C8C63398 191A3599
	v_dual_mul_f32 v27, v150, v27 :: v_dual_mul_f32 v28, v151, v28// 00000007D5F0: C8C63796 1B1C3997
	v_dual_mul_f32 v29, v148, v29 :: v_dual_mul_f32 v30, v149, v30// 00000007D5F8: C8C63B94 1D1E3D95
	v_dual_mul_f32 v31, v146, v31 :: v_dual_mul_f32 v32, v147, v32// 00000007D600: C8C63F92 1F204193
	v_dual_mul_f32 v17, v152, v17 :: v_dual_mul_f32 v18, v153, v18// 00000007D608: C8C62398 11122599
	v_dual_mul_f32 v19, v150, v19 :: v_dual_mul_f32 v20, v151, v20// 00000007D610: C8C62796 13142997
	v_dual_mul_f32 v21, v148, v21 :: v_dual_mul_f32 v22, v149, v22// 00000007D618: C8C62B94 15162D95
	v_dual_mul_f32 v23, v146, v23 :: v_dual_mul_f32 v24, v147, v24// 00000007D620: C8C62F92 17183193
	v_dual_mul_f32 v9, v152, v9 :: v_dual_mul_f32 v10, v153, v10// 00000007D628: C8C61398 090A1599
	v_dual_mul_f32 v11, v150, v11 :: v_dual_mul_f32 v12, v151, v12// 00000007D630: C8C61796 0B0C1997
	v_dual_mul_f32 v13, v148, v13 :: v_dual_mul_f32 v14, v149, v14// 00000007D638: C8C61B94 0D0E1D95
	v_dual_mul_f32 v15, v146, v15 :: v_dual_mul_f32 v16, v147, v16// 00000007D640: C8C61F92 0F102193
	v_dual_mul_f32 v1, v152, v1 :: v_dual_mul_f32 v2, v153, v2 // 00000007D648: C8C60398 01020599
	v_dual_mul_f32 v3, v150, v3 :: v_dual_mul_f32 v4, v151, v4 // 00000007D650: C8C60796 03040997
	v_dual_mul_f32 v5, v148, v5 :: v_dual_mul_f32 v6, v149, v6 // 00000007D658: C8C60B94 05060D95
	v_dual_mul_f32 v7, v146, v7 :: v_dual_mul_f32 v8, v147, v8 // 00000007D660: C8C60F92 07081193
	s_branch 62841                                             // 00000007D668: BFA0F579 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x750>
	v_lshlrev_b32_e32 v0, 2, v157                              // 00000007D66C: 30013A82
	.long 0xd700008b                                           // 00000007D670: D700008B
	v_cndmask_b32_e32 v1, s18, v139, vcc_lo                    // 00000007D674: 02031612
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007D678: BF870191
	v_add_co_ci_u32_e64 v140, null, s19, v140, s0              // 00000007D67C: D5207C8C 00031813
	v_lshl_or_b32 v0, v156, 6, v0                              // 00000007D684: D6560000 04010D9C
	v_lshlrev_b32_e32 v147, 1, v154                            // 00000007D68C: 31273481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000007D690: BF870152
	v_add_nc_u32_e32 v133, 0xa000, v0                          // 00000007D694: 4B0A00FF 0000A000
	ds_load_2addr_b32 v[141:142], v133 offset0:128 offset1:130 // 00000007D69C: D8DC8280 8D000085
	s_waitcnt lgkmcnt(0)                                       // 00000007D6A4: BF89FC07
	v_div_scale_f32 v143, null, v141, v141, 1.0                // 00000007D6A8: D6FC7C8F 03CB1B8D
	v_div_scale_f32 v145, vcc_lo, 1.0, v141, 1.0               // 00000007D6B0: D6FC6A91 03CB1AF2
	v_rcp_f32_e32 v144, v143                                   // 00000007D6B8: 7F20558F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000007D6BC: BF870005
	v_fma_f32 v0, -v143, v144, 1.0                             // 00000007D6C0: D6130000 23CB218F
	v_lshlrev_b32_e32 v129, 9, v138                            // 00000007D6C8: 31031489
	ds_load_2addr_b32 v[137:138], v133 offset0:132 offset1:134 // 00000007D6CC: D8DC8684 89000085
	ds_load_2addr_b32 v[135:136], v133 offset0:136 offset1:138 // 00000007D6D4: D8DC8A88 87000085
	ds_load_2addr_b32 v[133:134], v133 offset0:140 offset1:142 // 00000007D6DC: D8DC8E8C 85000085
	v_fmac_f32_e32 v144, v0, v144                              // 00000007D6E4: 57212100
	v_ashrrev_i32_e32 v130, 31, v129                           // 00000007D6E8: 3505029F
	v_or_b32_e32 v0, v155, v157                                // 00000007D6EC: 38013B9B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007D6F0: BF870193
	v_mul_f32_e32 v146, v145, v144                             // 00000007D6F4: 11252191
	.long 0xd73c0083                                           // 00000007D6F8: D73C0083
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 00000007D6FC: 02030281
	.long 0xd7000081                                           // 00000007D700: D7000081
	v_cndmask_b32_e32 v1, v139, v147, vcc_lo                   // 00000007D704: 0203278B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000007D708: BF870211
	v_add_co_ci_u32_e64 v130, null, 0, v140, s0                // 00000007D70C: D5207C82 00031880
	v_fma_f32 v148, -v143, v146, v145                          // 00000007D714: D6130094 2647258F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D71C: BF870094
	.long 0xd7000083                                           // 00000007D720: D7000083
	v_cndmask_b32_e32 v1, s16, v131, vcc_lo                    // 00000007D724: 02030610
	v_add_co_ci_u32_e64 v132, null, s17, v132, s0              // 00000007D728: D5207C84 00030811
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007D730: BF870123
	v_fmac_f32_e32 v146, v148, v144                            // 00000007D734: 57252194
	.long 0xd4440000                                           // 00000007D738: D4440000
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 00000007D73C: 0202000E
	v_fma_f32 v139, -v143, v146, v145                          // 00000007D740: D613008B 2647258F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007D748: BF8700A1
	v_div_fmas_f32 v139, v139, v144, v146                      // 00000007D74C: D637008B 064B218B
	.long 0xd7006a83                                           // 00000007D754: D7006A83
	v_cndmask_b32_e32 v1, v131, v147, vcc_lo                   // 00000007D758: 02032783
	v_add_co_ci_u32_e64 v132, null, 0, v132, vcc_lo            // 00000007D75C: D5207C84 01AB0880
	s_delay_alu instid0(VALU_DEP_3)                            // 00000007D764: BF870003
	v_div_fixup_f32 v139, v139, v141, 1.0                      // 00000007D768: D627008B 03CB1B8B
	s_and_saveexec_b32 s1, s0                                  // 00000007D770: BE812000
	s_cbranch_execz 70                                         // 00000007D774: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3390>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007D778: BF870112
	v_mad_i64_i32 v[140:141], null, 0x6000, v0, v[131:132]     // 00000007D77C: D6FF7C8C 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 00000007D788: 10F2F38B
	global_load_u16 v140, v[140:141], off offset:512           // 00000007D78C: DC4A0200 8C7C008C
	s_waitcnt vmcnt(0)                                         // 00000007D794: BF8903F7
	v_lshlrev_b32_e32 v140, 16, v140                           // 00000007D798: 31191890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D79C: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v140                       // 00000007D7A0: 111B18FF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v140, -v141                    // 00000007D7A8: D613008F 863718FF BFB8AA3B
	v_rndne_f32_e32 v144, v141                                 // 00000007D7B4: 7F20478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007D7B8: BF870112
	v_fmamk_f32 v143, v140, 0xb2a5705f, v143                   // 00000007D7BC: 591F1F8C B2A5705F
	v_sub_f32_e32 v141, v141, v144                             // 00000007D7C4: 091B218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000007D7C8: BF8701B1
	v_add_f32_e32 v141, v141, v143                             // 00000007D7CC: 071B1F8D
	v_cvt_i32_f32_e32 v143, v144                               // 00000007D7D0: 7F1E1190
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v140                 // 00000007D7D4: 7C3D18FF 42CE8ED0
	v_exp_f32_e32 v141, v141                                   // 00000007D7DC: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D7E0: BF870095
	.long 0xd71c008d                                           // 00000007D7E4: D71C008D
	v_cndmask_b32_e32 v1, v141, v143, vcc_lo                   // 00000007D7E8: 02031F8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 00000007D7EC: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v140                 // 00000007D7F0: 7C3718FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D7F8: BF870092
	v_cndmask_b32_e32 v140, 0x7f800000, v141, vcc_lo           // 00000007D7FC: 03191AFF 7F800000
	v_add_f32_e32 v140, 1.0, v140                              // 00000007D804: 071918F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D808: BF870091
	v_div_scale_f32 v141, null, v140, v140, v121               // 00000007D80C: D6FC7C8D 05E7198C
	v_rcp_f32_e32 v143, v141                                   // 00000007D814: 7F1E558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D818: BF870095
	v_fma_f32 v144, -v141, v143, 1.0                           // 00000007D81C: D6130090 23CB1F8D
	v_fmac_f32_e32 v143, v144, v143                            // 00000007D824: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v140, v121             // 00000007D828: D6FC6A90 05E71979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D830: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000007D834: 11231F90
	v_fma_f32 v146, -v141, v145, v144                          // 00000007D838: D6130092 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D840: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000007D844: 57231F92
	v_fma_f32 v141, -v141, v145, v144                          // 00000007D848: D613008D 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D850: BF870091
	v_div_fmas_f32 v141, v141, v143, v145                      // 00000007D854: D637008D 06471F8D
	v_div_fixup_f32 v121, v141, v140, v121                     // 00000007D85C: D6270079 05E7198D
	v_mad_i64_i32 v[140:141], null, 0x3000, v0, v[129:130]     // 00000007D864: D6FF7C8C 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D870: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 00000007D874: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 00000007D87C: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[140:141], v121, off              // 00000007D888: DC960000 007C798C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000007D890: 8C7E017E
	v_div_scale_f32 v121, null, v142, v142, 1.0                // 00000007D894: D6FC7C79 03CB1D8E
	v_div_scale_f32 v143, vcc_lo, 1.0, v142, 1.0               // 00000007D89C: D6FC6A8F 03CB1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007D8A4: BF870292
	v_rcp_f32_e32 v140, v121                                   // 00000007D8A8: 7F185579
	v_fma_f32 v141, -v121, v140, 1.0                           // 00000007D8AC: D613008D 23CB1979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D8B4: BF870091
	v_fmac_f32_e32 v140, v141, v140                            // 00000007D8B8: 5719198D
	v_mul_f32_e32 v141, v143, v140                             // 00000007D8BC: 111B198F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D8C0: BF870091
	v_fma_f32 v144, -v121, v141, v143                          // 00000007D8C4: D6130090 263F1B79
	v_fmac_f32_e32 v141, v144, v140                            // 00000007D8CC: 571B1990
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D8D0: BF870091
	v_fma_f32 v121, -v121, v141, v143                          // 00000007D8D4: D6130079 263F1B79
	v_div_fmas_f32 v140, v121, v140, v141                      // 00000007D8DC: D637008C 06371979
	v_or_b32_e32 v121, 2, v0                                   // 00000007D8E4: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007D8E8: BF870112
	v_div_fixup_f32 v140, v140, v142, 1.0                      // 00000007D8EC: D627008C 03CB1D8C
	.long 0xd4440001                                           // 00000007D8F4: D4440001
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 00000007D8F8: 0202F20E
	s_and_saveexec_b32 s2, s1                                  // 00000007D8FC: BE822001
	s_cbranch_execz 69                                         // 00000007D900: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3518>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 00000007D904: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 00000007D910: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 00000007D914: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000007D91C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000007D920: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D924: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000007D928: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000007D930: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000007D93C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007D940: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000007D944: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000007D948: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000007D950: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007D958: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000007D95C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000007D960: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000007D964: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D968: BF870095
	.long 0xd71c008e                                           // 00000007D96C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000007D970: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000007D974: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000007D978: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D980: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000007D984: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000007D98C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D990: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 00000007D994: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000007D99C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D9A0: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000007D9A4: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000007D9AC: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 00000007D9B0: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D9B8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000007D9BC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000007D9C0: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D9C8: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000007D9CC: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000007D9D0: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D9D8: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000007D9DC: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 00000007D9E4: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 00000007D9EC: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007D9F8: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 00000007D9FC: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 00000007DA04: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 00000007DA10: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 00000007DA18: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 00000007DA1C: BF89FC27
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 00000007DA20: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 00000007DA28: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007DA30: BF870292
	v_rcp_f32_e32 v141, v122                                   // 00000007DA34: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 00000007DA38: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DA40: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000007DA44: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000007DA48: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DA4C: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 00000007DA50: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 00000007DA58: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DA5C: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 00000007DA60: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 00000007DA68: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 00000007DA70: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007DA74: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 00000007DA78: D6270089 03CB138D
	.long 0xd4440002                                           // 00000007DA80: D4440002
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 00000007DA84: 0202F40E
	s_and_saveexec_b32 s3, s2                                  // 00000007DA88: BE832002
	s_cbranch_execz 69                                         // 00000007DA8C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36a4>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 00000007DA90: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 00000007DA9C: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 00000007DAA0: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000007DAA8: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000007DAAC: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DAB0: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000007DAB4: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000007DABC: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000007DAC8: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007DACC: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000007DAD0: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000007DAD4: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000007DADC: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007DAE4: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000007DAE8: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000007DAEC: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000007DAF0: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DAF4: BF870095
	.long 0xd71c008e                                           // 00000007DAF8: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000007DAFC: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000007DB00: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000007DB04: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DB0C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000007DB10: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000007DB18: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DB1C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 00000007DB20: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000007DB28: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DB2C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000007DB30: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000007DB38: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 00000007DB3C: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DB44: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000007DB48: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000007DB4C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DB54: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000007DB58: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000007DB5C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DB64: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000007DB68: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 00000007DB70: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 00000007DB78: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DB84: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 00000007DB88: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 00000007DB90: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 00000007DB9C: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 00000007DBA4: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 00000007DBA8: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 00000007DBB0: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007DBB8: BF870292
	v_rcp_f32_e32 v141, v123                                   // 00000007DBBC: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 00000007DBC0: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DBC8: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000007DBCC: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000007DBD0: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DBD4: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 00000007DBD8: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 00000007DBE0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DBE4: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 00000007DBE8: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 00000007DBF0: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 00000007DBF8: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007DBFC: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 00000007DC00: D627008A 03CB158D
	.long 0xd4440003                                           // 00000007DC08: D4440003
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 00000007DC0C: 0202F60E
	s_and_saveexec_b32 s4, s3                                  // 00000007DC10: BE842003
	s_cbranch_execz 69                                         // 00000007DC14: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x382c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 00000007DC18: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 00000007DC24: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 00000007DC28: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000007DC30: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000007DC34: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DC38: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000007DC3C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000007DC44: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000007DC50: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007DC54: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000007DC58: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000007DC5C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000007DC64: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007DC6C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000007DC70: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000007DC74: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000007DC78: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DC7C: BF870095
	.long 0xd71c008e                                           // 00000007DC80: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000007DC84: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000007DC88: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000007DC8C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DC94: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000007DC98: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000007DCA0: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DCA4: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 00000007DCA8: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 00000007DCB0: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DCB4: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000007DCB8: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000007DCC0: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 00000007DCC4: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DCCC: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000007DCD0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000007DCD4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DCDC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000007DCE0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000007DCE4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DCEC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000007DCF0: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 00000007DCF8: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 00000007DD00: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DD0C: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 00000007DD10: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 00000007DD18: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 00000007DD24: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007DD2C: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 00000007DD30: BF89FC17
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 00000007DD34: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 00000007DD3C: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007DD44: BF870292
	v_rcp_f32_e32 v141, v124                                   // 00000007DD48: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 00000007DD4C: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DD54: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000007DD58: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000007DD5C: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DD60: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 00000007DD64: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 00000007DD6C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DD70: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 00000007DD74: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 00000007DD7C: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 00000007DD84: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007DD88: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 00000007DD8C: D6270087 03CB0F8D
	.long 0xd4440004                                           // 00000007DD94: D4440004
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 00000007DD98: 0202F80E
	s_and_saveexec_b32 s5, s4                                  // 00000007DD9C: BE852004
	s_cbranch_execz 69                                         // 00000007DDA0: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39b8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 00000007DDA4: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 00000007DDB0: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 00000007DDB4: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000007DDBC: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000007DDC0: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DDC4: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000007DDC8: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000007DDD0: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000007DDDC: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007DDE0: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000007DDE4: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000007DDE8: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000007DDF0: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007DDF8: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000007DDFC: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000007DE00: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000007DE04: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DE08: BF870095
	.long 0xd71c008e                                           // 00000007DE0C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000007DE10: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000007DE14: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000007DE18: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DE20: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000007DE24: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000007DE2C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DE30: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 00000007DE34: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 00000007DE3C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DE40: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000007DE44: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000007DE4C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 00000007DE50: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DE58: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000007DE5C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000007DE60: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DE68: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000007DE6C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000007DE70: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DE78: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000007DE7C: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 00000007DE84: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 00000007DE8C: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DE98: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 00000007DE9C: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 00000007DEA4: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 00000007DEB0: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 00000007DEB8: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 00000007DEBC: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 00000007DEC4: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007DECC: BF870292
	v_rcp_f32_e32 v141, v125                                   // 00000007DED0: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 00000007DED4: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DEDC: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000007DEE0: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000007DEE4: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DEE8: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 00000007DEEC: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 00000007DEF4: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DEF8: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 00000007DEFC: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 00000007DF04: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 00000007DF0C: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007DF10: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 00000007DF14: D6270088 03CB118D
	.long 0xd4440005                                           // 00000007DF1C: D4440005
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 00000007DF20: 0202FA0E
	s_and_saveexec_b32 s6, s5                                  // 00000007DF24: BE862005
	s_cbranch_execz 69                                         // 00000007DF28: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b40>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 00000007DF2C: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 00000007DF38: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 00000007DF3C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000007DF44: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000007DF48: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DF4C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000007DF50: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000007DF58: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000007DF64: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007DF68: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000007DF6C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000007DF70: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000007DF78: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007DF80: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000007DF84: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000007DF88: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000007DF8C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DF90: BF870095
	.long 0xd71c008e                                           // 00000007DF94: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000007DF98: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000007DF9C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000007DFA0: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DFA8: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000007DFAC: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000007DFB4: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DFB8: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 00000007DFBC: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000007DFC4: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DFC8: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000007DFCC: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000007DFD4: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 00000007DFD8: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DFE0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000007DFE4: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000007DFE8: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007DFF0: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000007DFF4: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000007DFF8: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E000: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000007E004: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 00000007E00C: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 00000007E014: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E020: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 00000007E024: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 00000007E02C: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 00000007E038: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 00000007E040: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000007E044: BF89FC07
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 00000007E048: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 00000007E050: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007E058: BF870292
	v_rcp_f32_e32 v141, v126                                   // 00000007E05C: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 00000007E060: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E068: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000007E06C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000007E070: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E074: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 00000007E078: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 00000007E080: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E084: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 00000007E088: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 00000007E090: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 00000007E098: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007E09C: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 00000007E0A0: D6270085 03CB0B8D
	.long 0xd4440006                                           // 00000007E0A8: D4440006
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 00000007E0AC: 0202FC0E
	s_and_saveexec_b32 s7, s6                                  // 00000007E0B0: BE872006
	s_cbranch_execz 69                                         // 00000007E0B4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ccc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 00000007E0B8: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 00000007E0C4: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 00000007E0C8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000007E0D0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000007E0D4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E0D8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000007E0DC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000007E0E4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000007E0F0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007E0F4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000007E0F8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000007E0FC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000007E104: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007E10C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000007E110: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000007E114: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000007E118: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E11C: BF870095
	.long 0xd71c008e                                           // 00000007E120: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000007E124: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000007E128: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000007E12C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E134: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000007E138: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000007E140: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E144: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 00000007E148: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000007E150: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E154: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000007E158: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000007E160: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 00000007E164: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E16C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000007E170: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000007E174: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E17C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000007E180: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000007E184: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E18C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000007E190: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 00000007E198: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 00000007E1A0: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E1AC: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 00000007E1B0: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 00000007E1B8: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 00000007E1C4: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 00000007E1CC: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 00000007E1D0: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 00000007E1D8: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007E1E0: BF870292
	v_rcp_f32_e32 v141, v127                                   // 00000007E1E4: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 00000007E1E8: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E1F0: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000007E1F4: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000007E1F8: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E1FC: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 00000007E200: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 00000007E208: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E20C: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 00000007E210: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 00000007E218: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 00000007E220: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007E224: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 00000007E228: D6270086 03CB0D8D
	.long 0xd4440007                                           // 00000007E230: D4440007
	v_cndmask_b32_e32 v1, s14, v127, vcc_lo                    // 00000007E234: 0202FE0E
	s_and_saveexec_b32 s8, s7                                  // 00000007E238: BE882007
	s_cbranch_execnz 363                                       // 00000007E23C: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E240: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007E244: BE882000
	s_cbranch_execnz 432                                       // 00000007E248: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x440c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E24C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007E250: BE882001
	s_cbranch_execnz 501                                       // 00000007E254: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x452c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E258: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007E25C: BE882002
	s_cbranch_execnz 570                                       // 00000007E260: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x464c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E264: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007E268: BE882003
	s_cbranch_execnz 639                                       // 00000007E26C: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x476c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E270: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007E274: BE882004
	s_cbranch_execnz 708                                       // 00000007E278: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x488c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E27C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000007E280: BE882005
	s_cbranch_execnz 777                                       // 00000007E284: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x49ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E288: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007E28C: BE882006
	s_cbranch_execnz 846                                       // 00000007E290: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4acc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E294: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000007E298: BE882007
	s_cbranch_execnz 915                                       // 00000007E29C: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4bec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E2A0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007E2A4: BE882000
	s_cbranch_execnz 984                                       // 00000007E2A8: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4d0c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E2AC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007E2B0: BE882001
	s_cbranch_execnz 1053                                      // 00000007E2B4: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4e2c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E2B8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007E2BC: BE882002
	s_cbranch_execnz 1122                                      // 00000007E2C0: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4f4c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E2C4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007E2C8: BE882003
	s_cbranch_execnz 1191                                      // 00000007E2CC: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x506c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E2D0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007E2D4: BE882004
	s_cbranch_execnz 1260                                      // 00000007E2D8: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x518c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E2DC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000007E2E0: BE882005
	s_cbranch_execnz 1329                                      // 00000007E2E4: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x52ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E2E8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007E2EC: BE882006
	s_cbranch_execnz 1398                                      // 00000007E2F0: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x53cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E2F4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000007E2F8: BE882007
	s_cbranch_execnz 1467                                      // 00000007E2FC: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x54ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E300: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007E304: BE882000
	s_cbranch_execnz 1536                                      // 00000007E308: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x560c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E30C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007E310: BE882001
	s_cbranch_execnz 1605                                      // 00000007E314: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x572c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E318: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007E31C: BE882002
	s_cbranch_execnz 1674                                      // 00000007E320: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x584c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E324: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007E328: BE882003
	s_cbranch_execnz 1743                                      // 00000007E32C: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x596c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E330: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007E334: BE882004
	s_cbranch_execnz 1812                                      // 00000007E338: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5a8c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E33C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000007E340: BE882005
	s_cbranch_execnz 1881                                      // 00000007E344: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5bac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E348: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007E34C: BE882006
	s_cbranch_execnz 1950                                      // 00000007E350: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5ccc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E354: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000007E358: BE882007
	s_cbranch_execnz 2019                                      // 00000007E35C: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5dec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E360: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007E364: BE882000
	s_cbranch_execnz 2088                                      // 00000007E368: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5f0c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E36C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007E370: BE882001
	s_cbranch_execnz 2157                                      // 00000007E374: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x602c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E378: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007E37C: BE882002
	s_cbranch_execnz 2226                                      // 00000007E380: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x614c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E384: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007E388: BE882003
	s_cbranch_execnz 2295                                      // 00000007E38C: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x626c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E390: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007E394: BE882004
	s_cbranch_execnz 2364                                      // 00000007E398: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x638c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E39C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000007E3A0: BE882005
	s_cbranch_execnz 2433                                      // 00000007E3A4: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x64ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E3A8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007E3AC: BE882006
	s_cbranch_execnz 2502                                      // 00000007E3B0: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x65cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E3B4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000007E3B8: BE882007
	s_cbranch_execnz 2571                                      // 00000007E3BC: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x66ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E3C0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007E3C4: BE882000
	s_cbranch_execnz 2640                                      // 00000007E3C8: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x680c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E3CC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007E3D0: BE882001
	s_cbranch_execnz 2709                                      // 00000007E3D4: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x692c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E3D8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007E3DC: BE882002
	s_cbranch_execnz 2778                                      // 00000007E3E0: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6a4c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E3E4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007E3E8: BE882003
	s_cbranch_execnz 2847                                      // 00000007E3EC: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6b6c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E3F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007E3F4: BE882004
	s_cbranch_execnz 2916                                      // 00000007E3F8: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6c8c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E3FC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000007E400: BE882005
	s_cbranch_execnz 2985                                      // 00000007E404: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6dac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E408: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007E40C: BE882006
	s_cbranch_execnz 3054                                      // 00000007E410: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6ecc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E414: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000007E418: BE882007
	s_cbranch_execnz 3123                                      // 00000007E41C: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6fec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E420: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007E424: BE882000
	s_cbranch_execnz 3192                                      // 00000007E428: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x710c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E42C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007E430: BE882001
	s_cbranch_execnz 3261                                      // 00000007E434: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x722c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E438: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007E43C: BE882002
	s_cbranch_execnz 3330                                      // 00000007E440: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x734c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E444: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007E448: BE882003
	s_cbranch_execnz 3399                                      // 00000007E44C: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x746c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E450: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007E454: BE882004
	s_cbranch_execnz 3468                                      // 00000007E458: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x758c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E45C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000007E460: BE882005
	s_cbranch_execnz 3537                                      // 00000007E464: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x76ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E468: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007E46C: BE882006
	s_cbranch_execnz 3606                                      // 00000007E470: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x77cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E474: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000007E478: BE882007
	s_cbranch_execnz 3675                                      // 00000007E47C: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x78ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E480: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007E484: BE882000
	s_cbranch_execnz 3744                                      // 00000007E488: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7a0c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E48C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007E490: BE882001
	s_cbranch_execnz 3813                                      // 00000007E494: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7b2c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E498: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007E49C: BE882002
	s_cbranch_execnz 3882                                      // 00000007E4A0: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7c4c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E4A4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007E4A8: BE882003
	s_cbranch_execnz 3951                                      // 00000007E4AC: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7d6c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E4B0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007E4B4: BE882004
	s_cbranch_execnz 4020                                      // 00000007E4B8: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7e8c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E4BC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000007E4C0: BE882005
	s_cbranch_execnz 4089                                      // 00000007E4C4: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7fac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E4C8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007E4CC: BE882006
	s_cbranch_execnz 4158                                      // 00000007E4D0: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x80cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E4D4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000007E4D8: BE882007
	s_cbranch_execnz 4227                                      // 00000007E4DC: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x81ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E4E0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007E4E4: BE882000
	s_cbranch_execnz 4296                                      // 00000007E4E8: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x830c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E4EC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007E4F0: BE882001
	s_cbranch_execnz 4365                                      // 00000007E4F4: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x842c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E4F8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007E4FC: BE882002
	s_cbranch_execnz 4434                                      // 00000007E500: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x854c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E504: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007E508: BE882003
	s_cbranch_execnz 4503                                      // 00000007E50C: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x866c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E510: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007E514: BE882004
	s_cbranch_execnz 4572                                      // 00000007E518: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x878c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E51C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000007E520: BE882005
	s_cbranch_execnz 4641                                      // 00000007E524: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x88ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E528: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007E52C: BE882006
	s_cbranch_execnz 4710                                      // 00000007E530: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x89cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E534: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000007E538: BE882007
	s_cbranch_execnz 4779                                      // 00000007E53C: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8aec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E540: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007E544: BE882000
	s_cbranch_execnz 4848                                      // 00000007E548: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8c0c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E54C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007E550: BE882001
	s_cbranch_execnz 4917                                      // 00000007E554: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8d2c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E558: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007E55C: BE882002
	s_cbranch_execnz 4986                                      // 00000007E560: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8e4c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E564: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007E568: BE882003
	s_cbranch_execnz 5055                                      // 00000007E56C: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8f6c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E570: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007E574: BE882004
	s_cbranch_execnz 5124                                      // 00000007E578: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x908c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E57C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000007E580: BE882005
	s_cbranch_execnz 5193                                      // 00000007E584: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x91ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E588: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007E58C: BE882006
	s_cbranch_execnz 5262                                      // 00000007E590: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x92cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E594: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000007E598: BE882007
	s_cbranch_execnz 5331                                      // 00000007E59C: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x93ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E5A0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007E5A4: BE882000
	s_cbranch_execnz 5400                                      // 00000007E5A8: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x950c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E5AC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007E5B0: BE882001
	s_cbranch_execnz 5469                                      // 00000007E5B4: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x962c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E5B8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007E5BC: BE882002
	s_cbranch_execnz 5538                                      // 00000007E5C0: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x974c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E5C4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007E5C8: BE882003
	s_cbranch_execnz 5607                                      // 00000007E5CC: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x986c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E5D0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007E5D4: BE882004
	s_cbranch_execnz 5676                                      // 00000007E5D8: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x998c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E5DC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000007E5E0: BE882005
	s_cbranch_execnz 5745                                      // 00000007E5E4: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9aac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E5E8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007E5EC: BE882006
	s_cbranch_execnz 5814                                      // 00000007E5F0: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9bcc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E5F4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000007E5F8: BE882007
	s_cbranch_execnz 5883                                      // 00000007E5FC: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9cec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E600: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007E604: BE882000
	s_cbranch_execnz 5952                                      // 00000007E608: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9e0c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E60C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007E610: BE882001
	s_cbranch_execnz 6021                                      // 00000007E614: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9f2c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E618: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007E61C: BE882002
	s_cbranch_execnz 6090                                      // 00000007E620: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa04c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E624: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007E628: BE882003
	s_cbranch_execnz 6159                                      // 00000007E62C: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa16c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E630: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007E634: BE882004
	s_cbranch_execnz 6228                                      // 00000007E638: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa28c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E63C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000007E640: BE882005
	s_cbranch_execnz 6297                                      // 00000007E644: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa3ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E648: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007E64C: BE882006
	s_cbranch_execnz 6366                                      // 00000007E650: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa4cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E654: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000007E658: BE882007
	s_cbranch_execnz 6435                                      // 00000007E65C: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa5ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E660: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007E664: BE882000
	s_cbranch_execnz 6504                                      // 00000007E668: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa70c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E66C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007E670: BE882001
	s_cbranch_execnz 6573                                      // 00000007E674: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa82c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E678: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007E67C: BE882002
	s_cbranch_execnz 6642                                      // 00000007E680: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa94c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E684: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007E688: BE882003
	s_cbranch_execnz 6711                                      // 00000007E68C: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaa6c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E690: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007E694: BE882004
	s_cbranch_execnz 6780                                      // 00000007E698: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xab8c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E69C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000007E6A0: BE882005
	s_cbranch_execnz 6849                                      // 00000007E6A4: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xacac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E6A8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007E6AC: BE882006
	s_cbranch_execnz 6918                                      // 00000007E6B0: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xadcc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E6B4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000007E6B8: BE882007
	s_cbranch_execnz 6987                                      // 00000007E6BC: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaeec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E6C0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007E6C4: BE882000
	s_cbranch_execnz 7056                                      // 00000007E6C8: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb00c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E6CC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007E6D0: BE882001
	s_cbranch_execnz 7125                                      // 00000007E6D4: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb12c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E6D8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007E6DC: BE882002
	s_cbranch_execnz 7194                                      // 00000007E6E0: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb24c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E6E4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007E6E8: BE882003
	s_cbranch_execnz 7263                                      // 00000007E6EC: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb36c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E6F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007E6F4: BE882004
	s_cbranch_execnz 7332                                      // 00000007E6F8: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb48c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E6FC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000007E700: BE882005
	s_cbranch_execnz 7401                                      // 00000007E704: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb5ac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E708: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007E70C: BE882006
	s_cbranch_execnz 7470                                      // 00000007E710: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb6cc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E714: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000007E718: BE882007
	s_cbranch_execnz 7539                                      // 00000007E71C: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb7ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E720: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007E724: BE882000
	s_cbranch_execnz 7608                                      // 00000007E728: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb90c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E72C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007E730: BE882001
	s_cbranch_execnz 7677                                      // 00000007E734: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xba2c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E738: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007E73C: BE882002
	s_cbranch_execnz 7746                                      // 00000007E740: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbb4c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E744: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007E748: BE882003
	s_cbranch_execnz 7815                                      // 00000007E74C: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbc6c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E750: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007E754: BE882004
	s_cbranch_execnz 7884                                      // 00000007E758: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbd8c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E75C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000007E760: BE882005
	s_cbranch_execnz 7953                                      // 00000007E764: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbeac>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E768: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007E76C: BE882006
	s_cbranch_execnz 8022                                      // 00000007E770: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbfcc>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E774: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000007E778: BE882007
	s_cbranch_execnz 8091                                      // 00000007E77C: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc0ec>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E780: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007E784: BE882000
	s_cbranch_execnz 8160                                      // 00000007E788: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc20c>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E78C: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 00000007E790: BE802001
	s_cbranch_execnz 8229                                      // 00000007E794: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc32c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000007E798: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 00000007E79C: BE802002
	s_cbranch_execnz 8298                                      // 00000007E7A0: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc44c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000007E7A4: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 00000007E7A8: BE802003
	s_cbranch_execnz 8367                                      // 00000007E7AC: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc56c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000007E7B0: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000007E7B4: BE802004
	s_cbranch_execnz 8436                                      // 00000007E7B8: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc68c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000007E7BC: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000007E7C0: BE802005
	s_cbranch_execnz 8505                                      // 00000007E7C4: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc7ac>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000007E7C8: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000007E7CC: BE802006
	s_cbranch_execnz 8574                                      // 00000007E7D0: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc8cc>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000007E7D4: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000007E7D8: BE802007
	s_cbranch_execnz 8643                                      // 00000007E7DC: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc9ec>
	s_nop 0                                                    // 00000007E7E0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000007E7E4: BFB60003
	s_endpgm                                                   // 00000007E7E8: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 00000007E7EC: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 00000007E7F8: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 00000007E7FC: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000007E804: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000007E808: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E80C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000007E810: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000007E818: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000007E824: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007E828: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000007E82C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000007E830: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000007E838: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007E840: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000007E844: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000007E848: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000007E84C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E850: BF870095
	.long 0xd71c008e                                           // 00000007E854: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000007E858: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000007E85C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000007E860: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E868: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000007E86C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000007E874: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E878: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 00000007E87C: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 00000007E884: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E888: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000007E88C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000007E894: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 00000007E898: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E8A0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000007E8A4: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000007E8A8: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E8B0: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000007E8B4: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000007E8B8: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E8C0: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000007E8C4: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 00000007E8CC: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 00000007E8D4: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E8E0: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 00000007E8E4: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 00000007E8EC: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 00000007E8F8: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007E900: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007E904: BE882000
	s_cbranch_execz 65104                                      // 00000007E908: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d4c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 00000007E90C: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 00000007E918: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 00000007E91C: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 00000007E924: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 00000007E928: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E92C: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 00000007E930: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 00000007E938: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 00000007E944: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007E948: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 00000007E94C: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 00000007E950: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 00000007E958: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007E960: BF870121
	v_add_f32_e32 v141, v141, v142                             // 00000007E964: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 00000007E968: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 00000007E96C: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E970: BF870095
	.long 0xd71c008d                                           // 00000007E974: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 00000007E978: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 00000007E97C: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 00000007E980: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E988: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 00000007E98C: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 00000007E994: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E998: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 00000007E99C: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 00000007E9A4: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E9A8: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 00000007E9AC: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 00000007E9B4: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 00000007E9B8: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E9C0: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 00000007E9C4: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 00000007E9C8: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E9D0: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 00000007E9D4: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 00000007E9D8: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007E9E0: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 00000007E9E4: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 00000007E9EC: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 00000007E9F4: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EA00: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 00000007EA04: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 00000007EA0C: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 00000007EA18: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007EA20: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007EA24: BE882001
	s_cbranch_execz 65035                                      // 00000007EA28: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d58>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 00000007EA2C: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 00000007EA38: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 00000007EA3C: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 00000007EA44: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000007EA48: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EA4C: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 00000007EA50: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 00000007EA58: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 00000007EA64: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007EA68: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 00000007EA6C: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000007EA70: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 00000007EA78: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007EA80: BF870121
	v_add_f32_e32 v128, v128, v141                             // 00000007EA84: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 00000007EA88: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 00000007EA8C: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EA90: BF870095
	.long 0xd71c0080                                           // 00000007EA94: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 00000007EA98: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 00000007EA9C: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000007EAA0: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EAA8: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 00000007EAAC: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000007EAB4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EAB8: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 00000007EABC: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 00000007EAC4: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EAC8: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 00000007EACC: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 00000007EAD4: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 00000007EAD8: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EAE0: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 00000007EAE4: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 00000007EAE8: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EAF0: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 00000007EAF4: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 00000007EAF8: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EB00: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 00000007EB04: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 00000007EB0C: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 00000007EB14: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EB20: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 00000007EB24: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 00000007EB2C: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 00000007EB38: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007EB40: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007EB44: BE882002
	s_cbranch_execz 64966                                      // 00000007EB48: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d64>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 00000007EB4C: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000007EB58: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000007EB60: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000007EB64: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EB68: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000007EB6C: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 00000007EB74: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 00000007EB80: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007EB84: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 00000007EB88: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 00000007EB90: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000007EB94: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 00000007EB98: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 00000007EB9C: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000007EBA0: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 00000007EBA8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EBAC: BF870095
	.long 0xd71c0072                                           // 00000007EBB0: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 00000007EBB4: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000007EBB8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000007EBBC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EBC4: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 00000007EBC8: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000007EBD4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EBD8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000007EBDC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 00000007EBE4: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EBE8: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 00000007EBEC: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 00000007EBF4: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 00000007EBF8: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EC00: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 00000007EC04: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 00000007EC08: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EC10: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 00000007EC14: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 00000007EC18: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EC20: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 00000007EC24: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000007EC2C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 00000007EC34: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EC40: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 00000007EC44: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 00000007EC4C: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000007EC58: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007EC60: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007EC64: BE882003
	s_cbranch_execz 64897                                      // 00000007EC68: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d70>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 00000007EC6C: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000007EC78: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000007EC80: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000007EC84: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EC88: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000007EC8C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000007EC94: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 00000007ECA0: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007ECA4: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 00000007ECA8: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000007ECAC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000007ECB4: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007ECBC: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000007ECC0: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 00000007ECC4: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 00000007ECC8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007ECCC: BF870095
	.long 0xd71c0072                                           // 00000007ECD0: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000007ECD4: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000007ECD8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000007ECDC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007ECE4: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 00000007ECE8: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000007ECF4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007ECF8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000007ECFC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000007ED04: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007ED08: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 00000007ED0C: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 00000007ED14: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 00000007ED18: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007ED20: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 00000007ED24: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 00000007ED28: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007ED30: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 00000007ED34: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 00000007ED38: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007ED40: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 00000007ED44: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000007ED4C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 00000007ED54: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007ED60: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000007ED64: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000007ED6C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000007ED78: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007ED80: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007ED84: BE882004
	s_cbranch_execz 64828                                      // 00000007ED88: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d7c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 00000007ED8C: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000007ED98: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000007EDA0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000007EDA4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EDA8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000007EDAC: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000007EDB4: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000007EDC0: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007EDC4: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000007EDC8: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000007EDCC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000007EDD4: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007EDDC: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000007EDE0: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000007EDE4: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000007EDE8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EDEC: BF870095
	.long 0xd71c0072                                           // 00000007EDF0: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000007EDF4: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000007EDF8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000007EDFC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EE04: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 00000007EE08: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000007EE14: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EE18: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000007EE1C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000007EE24: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EE28: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000007EE2C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000007EE34: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000007EE38: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EE40: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 00000007EE44: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 00000007EE48: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EE50: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 00000007EE54: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 00000007EE58: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EE60: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 00000007EE64: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000007EE6C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 00000007EE74: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EE80: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000007EE84: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000007EE8C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000007EE98: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007EEA0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000007EEA4: BE882005
	s_cbranch_execz 64759                                      // 00000007EEA8: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d88>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 00000007EEAC: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000007EEB8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000007EEC0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000007EEC4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EEC8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000007EECC: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000007EED4: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000007EEE0: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007EEE4: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000007EEE8: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000007EEEC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000007EEF4: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007EEFC: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000007EF00: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000007EF04: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000007EF08: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EF0C: BF870095
	.long 0xd71c0072                                           // 00000007EF10: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000007EF14: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000007EF18: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000007EF1C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EF24: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 00000007EF28: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 00000007EF30: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EF38: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000007EF3C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000007EF44: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EF48: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000007EF4C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000007EF54: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000007EF58: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EF60: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 00000007EF64: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 00000007EF68: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EF70: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 00000007EF74: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 00000007EF78: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EF80: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 00000007EF84: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000007EF8C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 00000007EF94: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EFA0: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000007EFA4: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000007EFAC: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000007EFB8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007EFC0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007EFC4: BE882006
	s_cbranch_execz 64690                                      // 00000007EFC8: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d94>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 00000007EFCC: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000007EFD8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000007EFE0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000007EFE4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007EFE8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000007EFEC: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000007EFF4: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000007F000: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007F004: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000007F008: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000007F00C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000007F014: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007F01C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000007F020: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000007F024: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000007F028: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F02C: BF870095
	.long 0xd71c0072                                           // 00000007F030: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000007F034: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000007F038: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000007F03C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F044: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 00000007F048: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000007F054: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F058: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000007F05C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000007F064: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F068: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000007F06C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000007F074: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000007F078: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F080: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 00000007F084: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 00000007F088: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F090: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 00000007F094: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 00000007F098: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F0A0: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 00000007F0A4: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000007F0AC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 00000007F0B4: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F0C0: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000007F0C4: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000007F0CC: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000007F0D8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007F0E0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000007F0E4: BE882007
	s_cbranch_execz 64621                                      // 00000007F0E8: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3da0>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 00000007F0EC: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000007F0F8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 00000007F100: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000007F104: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F108: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000007F10C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000007F114: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000007F120: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007F124: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000007F128: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000007F12C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000007F134: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007F13C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000007F140: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000007F144: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000007F148: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F14C: BF870095
	.long 0xd71c0072                                           // 00000007F150: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000007F154: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000007F158: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000007F15C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F164: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 00000007F168: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000007F174: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F178: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 00000007F17C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 00000007F184: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F188: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 00000007F18C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 00000007F194: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000007F198: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F1A0: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 00000007F1A4: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 00000007F1A8: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F1B0: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 00000007F1B4: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 00000007F1B8: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F1C0: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 00000007F1C4: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 00000007F1CC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 00000007F1D4: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F1E0: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 00000007F1E4: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 00000007F1EC: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000007F1F8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007F200: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007F204: BE882000
	s_cbranch_execz 64552                                      // 00000007F208: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dac>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 00000007F20C: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 00000007F218: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 00000007F21C: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 00000007F224: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000007F228: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F22C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 00000007F230: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000007F238: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 00000007F244: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007F248: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000007F24C: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000007F250: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000007F258: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007F260: BF870121
	v_add_f32_e32 v114, v114, v115                             // 00000007F264: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 00000007F268: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000007F26C: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F270: BF870095
	.long 0xd71c0072                                           // 00000007F274: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 00000007F278: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000007F27C: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000007F280: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F288: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 00000007F28C: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000007F294: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F298: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 00000007F29C: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 00000007F2A4: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F2A8: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 00000007F2AC: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 00000007F2B4: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 00000007F2B8: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F2C0: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 00000007F2C4: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 00000007F2C8: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F2D0: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 00000007F2D4: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 00000007F2D8: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F2E0: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 00000007F2E4: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 00000007F2EC: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 00000007F2F4: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F300: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 00000007F304: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 00000007F30C: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 00000007F318: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007F320: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007F324: BE882001
	s_cbranch_execz 64483                                      // 00000007F328: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3db8>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 00000007F32C: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 00000007F338: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 00000007F33C: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 00000007F344: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000007F348: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007F34C: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 00000007F350: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000007F358: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 00000007F360: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 00000007F36C: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007F370: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 00000007F374: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 00000007F37C: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007F380: BF870121
	v_add_f32_e32 v113, v113, v114                             // 00000007F384: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 00000007F388: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 00000007F38C: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F390: BF870095
	.long 0xd71c0071                                           // 00000007F394: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 00000007F398: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 00000007F39C: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000007F3A0: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F3A8: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 00000007F3AC: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000007F3B4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F3B8: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 00000007F3BC: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 00000007F3C4: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F3C8: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 00000007F3CC: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 00000007F3D4: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 00000007F3D8: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F3E0: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 00000007F3E4: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 00000007F3E8: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F3F0: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 00000007F3F4: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 00000007F3F8: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F400: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 00000007F404: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 00000007F40C: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 00000007F414: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F420: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 00000007F424: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 00000007F42C: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 00000007F438: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007F440: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007F444: BE882002
	s_cbranch_execz 64414                                      // 00000007F448: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dc4>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 00000007F44C: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000007F458: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000007F460: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000007F464: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F468: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000007F46C: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 00000007F474: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 00000007F480: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007F484: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 00000007F488: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000007F48C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 00000007F494: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007F49C: BF870121
	v_add_f32_e32 v106, v106, v113                             // 00000007F4A0: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 00000007F4A4: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 00000007F4A8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F4AC: BF870095
	.long 0xd71c006a                                           // 00000007F4B0: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 00000007F4B4: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000007F4B8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000007F4BC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F4C4: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 00000007F4C8: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000007F4D4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F4D8: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000007F4DC: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 00000007F4E4: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F4E8: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 00000007F4EC: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 00000007F4F4: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 00000007F4F8: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F500: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 00000007F504: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 00000007F508: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F510: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 00000007F514: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 00000007F518: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F520: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 00000007F524: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000007F52C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 00000007F534: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F540: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 00000007F544: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 00000007F54C: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000007F558: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007F560: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007F564: BE882003
	s_cbranch_execz 64345                                      // 00000007F568: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dd0>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 00000007F56C: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000007F578: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000007F580: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000007F584: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F588: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000007F58C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000007F594: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 00000007F5A0: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F5A4: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 00000007F5A8: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 00000007F5B4: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 00000007F5B8: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000007F5BC: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007F5C4: BF870293
	v_exp_f32_e32 v106, v106                                   // 00000007F5C8: 7ED44B6A
	.long 0xd71c006a                                           // 00000007F5CC: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000007F5D0: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007F5D4: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000007F5D8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000007F5DC: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 00000007F5E4: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F5F0: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 00000007F5F4: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000007F5F8: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007F600: BF870291
	v_rcp_f32_e32 v108, v107                                   // 00000007F604: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 00000007F608: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007F610: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 00000007F614: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 00000007F618: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 00000007F620: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F624: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 00000007F628: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 00000007F630: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F634: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 00000007F638: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 00000007F640: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007F648: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000007F64C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 00000007F654: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 00000007F660: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007F668: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000007F66C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000007F678: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007F680: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007F684: BE882004
	s_cbranch_execz 64276                                      // 00000007F688: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ddc>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 00000007F68C: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000007F698: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000007F6A0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000007F6A4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F6A8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000007F6AC: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000007F6B4: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000007F6C0: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007F6C4: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000007F6C8: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000007F6CC: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000007F6D4: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007F6DC: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000007F6E0: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000007F6E4: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000007F6E8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F6EC: BF870095
	.long 0xd71c006a                                           // 00000007F6F0: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000007F6F4: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000007F6F8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000007F6FC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F704: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 00000007F708: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000007F714: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F718: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000007F71C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000007F724: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F728: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000007F72C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000007F734: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000007F738: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F740: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 00000007F744: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 00000007F748: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F750: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 00000007F754: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 00000007F758: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F760: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 00000007F764: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000007F76C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 00000007F774: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F780: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000007F784: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000007F78C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000007F798: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007F7A0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000007F7A4: BE882005
	s_cbranch_execz 64207                                      // 00000007F7A8: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3de8>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 00000007F7AC: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000007F7B8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000007F7C0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000007F7C4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F7C8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000007F7CC: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000007F7D4: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000007F7E0: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007F7E4: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000007F7E8: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000007F7EC: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000007F7F4: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007F7FC: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000007F800: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000007F804: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000007F808: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F80C: BF870095
	.long 0xd71c006a                                           // 00000007F810: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000007F814: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000007F818: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000007F81C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F824: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 00000007F828: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 00000007F830: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F838: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000007F83C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000007F844: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F848: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000007F84C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000007F854: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000007F858: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F860: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 00000007F864: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 00000007F868: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F870: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 00000007F874: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 00000007F878: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F880: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 00000007F884: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000007F88C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 00000007F894: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F8A0: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000007F8A4: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000007F8AC: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000007F8B8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007F8C0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000007F8C4: BE882006
	s_cbranch_execz 64138                                      // 00000007F8C8: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3df4>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 00000007F8CC: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000007F8D8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000007F8E0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000007F8E4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F8E8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000007F8EC: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000007F8F4: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000007F900: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007F904: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000007F908: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000007F90C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000007F914: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007F91C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000007F920: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000007F924: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000007F928: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F92C: BF870095
	.long 0xd71c006a                                           // 00000007F930: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000007F934: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000007F938: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000007F93C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F944: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 00000007F948: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000007F954: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F958: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000007F95C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000007F964: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F968: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000007F96C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000007F974: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000007F978: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F980: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 00000007F984: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 00000007F988: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F990: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 00000007F994: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 00000007F998: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F9A0: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 00000007F9A4: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000007F9AC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 00000007F9B4: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F9C0: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000007F9C4: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000007F9CC: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000007F9D8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007F9E0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000007F9E4: BE882007
	s_cbranch_execz 64069                                      // 00000007F9E8: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e00>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 00000007F9EC: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000007F9F8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 00000007FA00: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000007FA04: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FA08: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000007FA0C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000007FA14: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000007FA20: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007FA24: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000007FA28: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000007FA2C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000007FA34: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007FA3C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000007FA40: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000007FA44: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000007FA48: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FA4C: BF870095
	.long 0xd71c006a                                           // 00000007FA50: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000007FA54: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000007FA58: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000007FA5C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FA64: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 00000007FA68: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000007FA74: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FA78: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 00000007FA7C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 00000007FA84: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FA88: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 00000007FA8C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 00000007FA94: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 00000007FA98: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FAA0: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 00000007FAA4: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 00000007FAA8: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FAB0: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 00000007FAB4: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 00000007FAB8: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FAC0: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 00000007FAC4: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 00000007FACC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 00000007FAD4: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FAE0: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 00000007FAE4: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 00000007FAEC: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000007FAF8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007FB00: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000007FB04: BE882000
	s_cbranch_execz 64000                                      // 00000007FB08: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e0c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 00000007FB0C: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 00000007FB18: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 00000007FB1C: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 00000007FB24: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000007FB28: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FB2C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 00000007FB30: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000007FB38: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 00000007FB44: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007FB48: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 00000007FB4C: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000007FB50: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000007FB58: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007FB60: BF870121
	v_add_f32_e32 v106, v106, v107                             // 00000007FB64: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 00000007FB68: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 00000007FB6C: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FB70: BF870095
	.long 0xd71c006a                                           // 00000007FB74: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 00000007FB78: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 00000007FB7C: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 00000007FB80: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FB88: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 00000007FB8C: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 00000007FB94: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FB98: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 00000007FB9C: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 00000007FBA4: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FBA8: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 00000007FBAC: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 00000007FBB4: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 00000007FBB8: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FBC0: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 00000007FBC4: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 00000007FBC8: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FBD0: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 00000007FBD4: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 00000007FBD8: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FBE0: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 00000007FBE4: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 00000007FBEC: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 00000007FBF4: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FC00: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 00000007FC04: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 00000007FC0C: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 00000007FC18: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007FC20: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000007FC24: BE882001
	s_cbranch_execz 63931                                      // 00000007FC28: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e18>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 00000007FC2C: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 00000007FC38: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 00000007FC3C: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 00000007FC44: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000007FC48: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007FC4C: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 00000007FC50: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000007FC58: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 00000007FC60: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 00000007FC6C: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007FC70: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 00000007FC74: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 00000007FC7C: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007FC80: BF870121
	v_add_f32_e32 v105, v105, v106                             // 00000007FC84: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 00000007FC88: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 00000007FC8C: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FC90: BF870095
	.long 0xd71c0069                                           // 00000007FC94: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 00000007FC98: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 00000007FC9C: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000007FCA0: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FCA8: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 00000007FCAC: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000007FCB4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FCB8: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 00000007FCBC: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 00000007FCC4: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FCC8: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 00000007FCCC: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 00000007FCD4: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 00000007FCD8: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FCE0: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 00000007FCE4: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 00000007FCE8: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FCF0: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 00000007FCF4: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 00000007FCF8: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FD00: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 00000007FD04: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 00000007FD0C: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 00000007FD14: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FD20: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 00000007FD24: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 00000007FD2C: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 00000007FD38: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007FD40: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000007FD44: BE882002
	s_cbranch_execz 63862                                      // 00000007FD48: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e24>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 00000007FD4C: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000007FD58: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000007FD60: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000007FD64: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FD68: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000007FD6C: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 00000007FD74: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 00000007FD80: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007FD84: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 00000007FD88: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000007FD8C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 00000007FD94: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007FD9C: BF870121
	v_add_f32_e32 v98, v98, v105                               // 00000007FDA0: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 00000007FDA4: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 00000007FDA8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FDAC: BF870095
	.long 0xd71c0062                                           // 00000007FDB0: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 00000007FDB4: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000007FDB8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000007FDBC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FDC4: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 00000007FDC8: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 00000007FDD4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FDD8: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000007FDDC: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 00000007FDE4: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FDE8: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 00000007FDEC: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 00000007FDF4: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 00000007FDF8: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FE00: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 00000007FE04: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 00000007FE08: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FE10: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 00000007FE14: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 00000007FE18: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FE20: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 00000007FE24: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000007FE2C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 00000007FE34: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FE40: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 00000007FE44: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 00000007FE4C: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000007FE58: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007FE60: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000007FE64: BE882003
	s_cbranch_execz 63793                                      // 00000007FE68: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e30>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 00000007FE6C: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000007FE78: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000007FE80: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000007FE84: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FE88: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000007FE8C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000007FE94: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 00000007FEA0: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FEA4: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 00000007FEA8: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 00000007FEB4: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 00000007FEB8: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000007FEBC: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007FEC4: BF870293
	v_exp_f32_e32 v98, v98                                     // 00000007FEC8: 7EC44B62
	.long 0xd71c0062                                           // 00000007FECC: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000007FED0: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007FED4: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000007FED8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000007FEDC: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 00000007FEE4: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FEF0: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 00000007FEF4: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000007FEF8: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007FF00: BF870291
	v_rcp_f32_e32 v100, v99                                    // 00000007FF04: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 00000007FF08: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007FF10: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 00000007FF14: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 00000007FF18: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 00000007FF20: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FF24: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 00000007FF28: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 00000007FF30: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FF34: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 00000007FF38: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 00000007FF40: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007FF48: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000007FF4C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 00000007FF54: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 00000007FF60: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007FF68: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000007FF6C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000007FF78: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 00000007FF80: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000007FF84: BE882004
	s_cbranch_execz 63724                                      // 00000007FF88: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e3c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 00000007FF8C: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000007FF98: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 00000007FFA0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000007FFA4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FFA8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000007FFAC: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000007FFB4: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 00000007FFC0: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000007FFC4: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000007FFC8: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000007FFCC: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000007FFD4: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007FFDC: BF870121
	v_add_f32_e32 v98, v98, v99                                // 00000007FFE0: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 00000007FFE4: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000007FFE8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FFEC: BF870095
	.long 0xd71c0062                                           // 00000007FFF0: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 00000007FFF4: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000007FFF8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000007FFFC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080004: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 000000080008: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000080014: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080018: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000008001C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000080024: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080028: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000008002C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000080034: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000080038: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080040: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 000000080044: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 000000080048: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080050: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 000000080054: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 000000080058: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080060: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 000000080064: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000008006C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 000000080074: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080080: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000080084: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 00000008008C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 000000080098: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000800A0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000800A4: BE882005
	s_cbranch_execz 63655                                      // 0000000800A8: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e48>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 0000000800AC: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000800B8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000800C0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000800C4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000800C8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000800CC: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000800D4: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000800E0: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000800E4: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000800E8: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000800EC: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000800F4: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000800FC: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000080100: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000080104: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000080108: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008010C: BF870095
	.long 0xd71c0062                                           // 000000080110: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000080114: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000080118: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000008011C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080124: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 000000080128: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 000000080130: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080138: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000008013C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000080144: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080148: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000008014C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000080154: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000080158: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080160: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 000000080164: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 000000080168: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080170: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 000000080174: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 000000080178: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080180: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 000000080184: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 00000008018C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 000000080194: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000801A0: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000801A4: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000801AC: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000801B8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000801C0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000801C4: BE882006
	s_cbranch_execz 63586                                      // 0000000801C8: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e54>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 0000000801CC: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000801D8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000801E0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000801E4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000801E8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000801EC: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000801F4: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000080200: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000080204: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000080208: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000008020C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000080214: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008021C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000080220: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000080224: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000080228: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008022C: BF870095
	.long 0xd71c0062                                           // 000000080230: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000080234: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000080238: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000008023C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080244: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 000000080248: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000080254: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080258: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000008025C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000080264: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080268: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000008026C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000080274: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000080278: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080280: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 000000080284: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 000000080288: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080290: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 000000080294: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 000000080298: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000802A0: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000802A4: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000802AC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 0000000802B4: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000802C0: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000802C4: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000802CC: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000802D8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000802E0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000802E4: BE882007
	s_cbranch_execz 63517                                      // 0000000802E8: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e60>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 0000000802EC: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000802F8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000080300: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000080304: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080308: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 00000008030C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000080314: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000080320: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000080324: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000080328: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000008032C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000080334: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008033C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000080340: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000080344: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 000000080348: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008034C: BF870095
	.long 0xd71c0062                                           // 000000080350: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000080354: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 000000080358: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 00000008035C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080364: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 000000080368: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000080374: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080378: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000008037C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000080384: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080388: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 00000008038C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000080394: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 000000080398: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000803A0: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000803A4: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000000803A8: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000803B0: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000000803B4: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000000803B8: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000803C0: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000803C4: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000803CC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 0000000803D4: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000803E0: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000803E4: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000803EC: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000803F8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000080400: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000080404: BE882000
	s_cbranch_execz 63448                                      // 000000080408: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e6c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 00000008040C: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 000000080418: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 00000008041C: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 000000080424: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000080428: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008042C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000080430: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000080438: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000080444: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000080448: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000008044C: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000080450: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000080458: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000080460: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000080464: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000080468: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000008046C: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080470: BF870095
	.long 0xd71c0062                                           // 000000080474: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000080478: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000008047C: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000080480: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080488: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 00000008048C: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000080494: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080498: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 00000008049C: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 0000000804A4: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000804A8: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 0000000804AC: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 0000000804B4: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 0000000804B8: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000804C0: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 0000000804C4: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 0000000804C8: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000804D0: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 0000000804D4: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 0000000804D8: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000804E0: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 0000000804E4: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 0000000804EC: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 0000000804F4: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080500: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 000000080504: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 00000008050C: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 000000080518: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 000000080520: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000080524: BE882001
	s_cbranch_execz 63379                                      // 000000080528: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e78>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 00000008052C: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 000000080538: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 00000008053C: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 000000080544: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000080548: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008054C: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 000000080550: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000080558: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 000000080560: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 00000008056C: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000080570: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 000000080574: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 00000008057C: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000080580: BF870121
	v_add_f32_e32 v97, v97, v98                                // 000000080584: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 000000080588: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 00000008058C: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080590: BF870095
	.long 0xd71c0061                                           // 000000080594: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 000000080598: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 00000008059C: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000805A0: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000805A8: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 0000000805AC: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000805B4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000805B8: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 0000000805BC: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 0000000805C4: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000805C8: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 0000000805CC: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 0000000805D4: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 0000000805D8: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000805E0: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 0000000805E4: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 0000000805E8: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000805F0: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 0000000805F4: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 0000000805F8: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080600: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 000000080604: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 00000008060C: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 000000080614: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080620: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 000000080624: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 00000008062C: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 000000080638: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 000000080640: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000080644: BE882002
	s_cbranch_execz 63310                                      // 000000080648: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e84>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 00000008064C: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000080658: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000080660: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000080664: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080668: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000008066C: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 000000080674: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 000000080680: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000080684: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 000000080688: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 00000008068C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 000000080694: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008069C: BF870121
	v_add_f32_e32 v90, v90, v97                                // 0000000806A0: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 0000000806A4: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 0000000806A8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000806AC: BF870095
	.long 0xd71c005a                                           // 0000000806B0: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 0000000806B4: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000806B8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000806BC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000806C4: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 0000000806C8: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000806D4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000806D8: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000806DC: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 0000000806E4: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000806E8: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 0000000806EC: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 0000000806F4: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 0000000806F8: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080700: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 000000080704: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 000000080708: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080710: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 000000080714: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 000000080718: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080720: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 000000080724: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000008072C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 000000080734: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080740: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 000000080744: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 00000008074C: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000080758: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000080760: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000080764: BE882003
	s_cbranch_execz 63241                                      // 000000080768: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e90>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 00000008076C: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000080778: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000080780: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000080784: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080788: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 00000008078C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000080794: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 0000000807A0: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000807A4: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 0000000807A8: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 0000000807B4: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 0000000807B8: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000807BC: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000807C4: BF870293
	v_exp_f32_e32 v90, v90                                     // 0000000807C8: 7EB44B5A
	.long 0xd71c005a                                           // 0000000807CC: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000807D0: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000807D4: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000807D8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000807DC: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 0000000807E4: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000807F0: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 0000000807F4: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000807F8: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000080800: BF870291
	v_rcp_f32_e32 v92, v91                                     // 000000080804: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 000000080808: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080810: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 000000080814: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 000000080818: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 000000080820: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080824: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 000000080828: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 000000080830: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080834: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 000000080838: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 000000080840: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000080848: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000008084C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 000000080854: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 000000080860: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000080868: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000008086C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000080878: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000080880: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000080884: BE882004
	s_cbranch_execz 63172                                      // 000000080888: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e9c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 00000008088C: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000080898: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000808A0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000808A4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000808A8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000808AC: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000808B4: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000808C0: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000808C4: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000808C8: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000808CC: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000808D4: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000808DC: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000808E0: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000808E4: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000808E8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000808EC: BF870095
	.long 0xd71c005a                                           // 0000000808F0: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000808F4: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000808F8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000808FC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080904: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 000000080908: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000080914: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080918: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 00000008091C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000080924: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080928: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 00000008092C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000080934: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000080938: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080940: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 000000080944: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 000000080948: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080950: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 000000080954: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 000000080958: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080960: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 000000080964: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 00000008096C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 000000080974: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080980: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000080984: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 00000008098C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000080998: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000809A0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000809A4: BE882005
	s_cbranch_execz 63103                                      // 0000000809A8: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ea8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 0000000809AC: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000809B8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000809C0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000809C4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000809C8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000809CC: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000809D4: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000809E0: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000809E4: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000809E8: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000809EC: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000809F4: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000809FC: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000080A00: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000080A04: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000080A08: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080A0C: BF870095
	.long 0xd71c005a                                           // 000000080A10: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000080A14: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000080A18: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000080A1C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080A24: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 000000080A28: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 000000080A30: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080A38: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000080A3C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000080A44: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080A48: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000080A4C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000080A54: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000080A58: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080A60: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000080A64: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 000000080A68: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080A70: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 000000080A74: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 000000080A78: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080A80: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000080A84: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000080A8C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 000000080A94: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080AA0: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000080AA4: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000080AAC: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000080AB8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000080AC0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000080AC4: BE882006
	s_cbranch_execz 63034                                      // 000000080AC8: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3eb4>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 000000080ACC: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000080AD8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000080AE0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000080AE4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080AE8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000080AEC: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000080AF4: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000080B00: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000080B04: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000080B08: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000080B0C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000080B14: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000080B1C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000080B20: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000080B24: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000080B28: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080B2C: BF870095
	.long 0xd71c005a                                           // 000000080B30: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000080B34: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000080B38: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000080B3C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080B44: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 000000080B48: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000080B54: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080B58: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000080B5C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000080B64: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080B68: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000080B6C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000080B74: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000080B78: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080B80: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000080B84: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 000000080B88: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080B90: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 000000080B94: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 000000080B98: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080BA0: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000080BA4: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000080BAC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 000000080BB4: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080BC0: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000080BC4: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000080BCC: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000080BD8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000080BE0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000080BE4: BE882007
	s_cbranch_execz 62965                                      // 000000080BE8: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ec0>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 000000080BEC: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000080BF8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000080C00: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000080C04: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080C08: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000080C0C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000080C14: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000080C20: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000080C24: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000080C28: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000080C2C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000080C34: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000080C3C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000080C40: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000080C44: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000080C48: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080C4C: BF870095
	.long 0xd71c005a                                           // 000000080C50: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000080C54: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000080C58: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000080C5C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080C64: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 000000080C68: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000080C74: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080C78: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000080C7C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000080C84: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080C88: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000080C8C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000080C94: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000080C98: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080CA0: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000080CA4: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 000000080CA8: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080CB0: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 000000080CB4: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 000000080CB8: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080CC0: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000080CC4: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000080CCC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 000000080CD4: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080CE0: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000080CE4: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000080CEC: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000080CF8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000080D00: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000080D04: BE882000
	s_cbranch_execz 62896                                      // 000000080D08: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ecc>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 000000080D0C: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 000000080D18: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 000000080D1C: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 000000080D24: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000080D28: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080D2C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000080D30: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000080D38: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000080D44: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000080D48: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000080D4C: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000080D50: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000080D58: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000080D60: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000080D64: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000080D68: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000080D6C: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080D70: BF870095
	.long 0xd71c005a                                           // 000000080D74: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000080D78: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000080D7C: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000080D80: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080D88: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 000000080D8C: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000080D94: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080D98: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 000000080D9C: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 000000080DA4: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080DA8: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 000000080DAC: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 000000080DB4: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 000000080DB8: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080DC0: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 000000080DC4: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 000000080DC8: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080DD0: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 000000080DD4: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 000000080DD8: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080DE0: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 000000080DE4: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 000000080DEC: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 000000080DF4: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080E00: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 000000080E04: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 000000080E0C: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 000000080E18: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 000000080E20: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000080E24: BE882001
	s_cbranch_execz 62827                                      // 000000080E28: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ed8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 000000080E2C: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 000000080E38: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 000000080E3C: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 000000080E44: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000080E48: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000080E4C: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 000000080E50: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000080E58: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 000000080E60: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 000000080E6C: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000080E70: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 000000080E74: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 000000080E7C: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000080E80: BF870121
	v_add_f32_e32 v89, v89, v90                                // 000000080E84: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 000000080E88: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 000000080E8C: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080E90: BF870095
	.long 0xd71c0059                                           // 000000080E94: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 000000080E98: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 000000080E9C: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000080EA0: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080EA8: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 000000080EAC: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000080EB4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080EB8: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 000000080EBC: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 000000080EC4: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080EC8: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 000000080ECC: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 000000080ED4: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 000000080ED8: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080EE0: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 000000080EE4: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 000000080EE8: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080EF0: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 000000080EF4: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 000000080EF8: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080F00: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 000000080F04: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 000000080F0C: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 000000080F14: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080F20: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 000000080F24: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 000000080F2C: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 000000080F38: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 000000080F40: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000080F44: BE882002
	s_cbranch_execz 62758                                      // 000000080F48: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ee4>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 000000080F4C: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000080F58: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000080F60: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000080F64: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080F68: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000080F6C: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 000000080F74: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 000000080F80: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000080F84: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 000000080F88: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000080F8C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 000000080F94: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000080F9C: BF870121
	v_add_f32_e32 v82, v82, v89                                // 000000080FA0: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 000000080FA4: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 000000080FA8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080FAC: BF870095
	.long 0xd71c0052                                           // 000000080FB0: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 000000080FB4: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000080FB8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000080FBC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080FC4: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 000000080FC8: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000080FD4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080FD8: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000080FDC: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 000000080FE4: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080FE8: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 000000080FEC: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 000000080FF4: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 000000080FF8: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081000: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 000000081004: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 000000081008: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081010: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 000000081014: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 000000081018: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081020: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 000000081024: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000008102C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 000000081034: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081040: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 000000081044: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 00000008104C: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000081058: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000081060: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000081064: BE882003
	s_cbranch_execz 62689                                      // 000000081068: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ef0>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 00000008106C: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000081078: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000081080: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000081084: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081088: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000008108C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000081094: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 0000000810A0: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000810A4: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 0000000810A8: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 0000000810B4: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 0000000810B8: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000810BC: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000810C4: BF870293
	v_exp_f32_e32 v82, v82                                     // 0000000810C8: 7EA44B52
	.long 0xd71c0052                                           // 0000000810CC: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000810D0: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000810D4: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000810D8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000810DC: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 0000000810E4: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000810F0: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 0000000810F4: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000810F8: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000081100: BF870291
	v_rcp_f32_e32 v84, v83                                     // 000000081104: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 000000081108: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000081110: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 000000081114: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 000000081118: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 000000081120: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081124: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 000000081128: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 000000081130: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081134: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 000000081138: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 000000081140: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000081148: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000008114C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 000000081154: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 000000081160: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 000000081168: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000008116C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000081178: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000081180: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000081184: BE882004
	s_cbranch_execz 62620                                      // 000000081188: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3efc>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 00000008118C: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000081198: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000811A0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000811A4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000811A8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000811AC: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000811B4: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000811C0: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000811C4: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000811C8: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000811CC: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000811D4: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000811DC: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000811E0: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000811E4: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000811E8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000811EC: BF870095
	.long 0xd71c0052                                           // 0000000811F0: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000811F4: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000811F8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000811FC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081204: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 000000081208: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000081214: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081218: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000008121C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000081224: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081228: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000008122C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000081234: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000081238: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081240: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 000000081244: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 000000081248: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081250: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 000000081254: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 000000081258: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081260: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 000000081264: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000008126C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 000000081274: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081280: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000081284: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 00000008128C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000081298: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000812A0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000812A4: BE882005
	s_cbranch_execz 62551                                      // 0000000812A8: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f08>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 0000000812AC: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000812B8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000812C0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000812C4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000812C8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000812CC: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000812D4: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000812E0: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000812E4: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000812E8: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000812EC: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000812F4: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000812FC: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000081300: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000081304: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000081308: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008130C: BF870095
	.long 0xd71c0052                                           // 000000081310: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000081314: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000081318: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000008131C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081324: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 000000081328: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 000000081330: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081338: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000008133C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000081344: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081348: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000008134C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000081354: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000081358: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081360: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 000000081364: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 000000081368: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081370: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 000000081374: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 000000081378: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081380: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 000000081384: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 00000008138C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 000000081394: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000813A0: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000813A4: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000813AC: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000813B8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000813C0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000813C4: BE882006
	s_cbranch_execz 62482                                      // 0000000813C8: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f14>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 0000000813CC: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000813D8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000813E0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000813E4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000813E8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000813EC: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000813F4: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000081400: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000081404: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000081408: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000008140C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000081414: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008141C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000081420: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000081424: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000081428: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008142C: BF870095
	.long 0xd71c0052                                           // 000000081430: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000081434: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000081438: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000008143C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081444: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 000000081448: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000081454: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081458: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000008145C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000081464: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081468: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000008146C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000081474: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000081478: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081480: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 000000081484: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 000000081488: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081490: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 000000081494: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 000000081498: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000814A0: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000814A4: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000814AC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 0000000814B4: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000814C0: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000814C4: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000814CC: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000814D8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000814E0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000814E4: BE882007
	s_cbranch_execz 62413                                      // 0000000814E8: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f20>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 0000000814EC: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000814F8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000081500: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000081504: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081508: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 00000008150C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000081514: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000081520: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000081524: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000081528: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000008152C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000081534: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008153C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000081540: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000081544: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000081548: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008154C: BF870095
	.long 0xd71c0052                                           // 000000081550: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000081554: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000081558: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 00000008155C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081564: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 000000081568: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000081574: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081578: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000008157C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000081584: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081588: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 00000008158C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000081594: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000081598: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000815A0: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000815A4: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000000815A8: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000815B0: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000000815B4: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000000815B8: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000815C0: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000815C4: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000815CC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 0000000815D4: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000815E0: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000815E4: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000815EC: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000815F8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000081600: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000081604: BE882000
	s_cbranch_execz 62344                                      // 000000081608: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f2c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 00000008160C: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 000000081618: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 00000008161C: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000081624: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000081628: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008162C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000081630: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000081638: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000081644: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000081648: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000008164C: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000081650: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000081658: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000081660: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000081664: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000081668: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000008166C: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081670: BF870095
	.long 0xd71c0052                                           // 000000081674: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000081678: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000008167C: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000081680: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081688: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 00000008168C: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000081694: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081698: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 00000008169C: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 0000000816A4: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000816A8: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 0000000816AC: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 0000000816B4: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 0000000816B8: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000816C0: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 0000000816C4: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 0000000816C8: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000816D0: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 0000000816D4: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 0000000816D8: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000816E0: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 0000000816E4: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 0000000816EC: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 0000000816F4: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081700: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 000000081704: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 00000008170C: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 000000081718: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 000000081720: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000081724: BE882001
	s_cbranch_execz 62275                                      // 000000081728: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f38>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 00000008172C: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 000000081738: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 00000008173C: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 000000081744: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000081748: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008174C: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 000000081750: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000081758: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 000000081760: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 00000008176C: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000081770: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 000000081774: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 00000008177C: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000081780: BF870121
	v_add_f32_e32 v81, v81, v82                                // 000000081784: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 000000081788: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 00000008178C: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081790: BF870095
	.long 0xd71c0051                                           // 000000081794: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 000000081798: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000008179C: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000817A0: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000817A8: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 0000000817AC: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000817B4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000817B8: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 0000000817BC: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 0000000817C4: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000817C8: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 0000000817CC: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 0000000817D4: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 0000000817D8: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000817E0: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 0000000817E4: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 0000000817E8: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000817F0: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 0000000817F4: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 0000000817F8: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081800: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 000000081804: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 00000008180C: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 000000081814: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081820: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 000000081824: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 00000008182C: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 000000081838: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 000000081840: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000081844: BE882002
	s_cbranch_execz 62206                                      // 000000081848: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f44>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 00000008184C: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000081858: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000081860: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000081864: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081868: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000008186C: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 000000081874: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 000000081880: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000081884: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 000000081888: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 00000008188C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 000000081894: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008189C: BF870121
	v_add_f32_e32 v74, v74, v81                                // 0000000818A0: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 0000000818A4: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 0000000818A8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000818AC: BF870095
	.long 0xd71c004a                                           // 0000000818B0: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 0000000818B4: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000818B8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000818BC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000818C4: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 0000000818C8: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000818D4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000818D8: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000818DC: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 0000000818E4: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000818E8: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 0000000818EC: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 0000000818F4: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 0000000818F8: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081900: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 000000081904: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 000000081908: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081910: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 000000081914: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 000000081918: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081920: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 000000081924: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 00000008192C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 000000081934: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081940: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 000000081944: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 00000008194C: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000081958: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000081960: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000081964: BE882003
	s_cbranch_execz 62137                                      // 000000081968: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f50>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 00000008196C: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000081978: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000081980: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000081984: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081988: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 00000008198C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000081994: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 0000000819A0: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000819A4: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 0000000819A8: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 0000000819B4: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 0000000819B8: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000819BC: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000819C4: BF870293
	v_exp_f32_e32 v74, v74                                     // 0000000819C8: 7E944B4A
	.long 0xd71c004a                                           // 0000000819CC: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000819D0: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000819D4: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000819D8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000819DC: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 0000000819E4: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000819F0: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 0000000819F4: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000819F8: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000081A00: BF870291
	v_rcp_f32_e32 v76, v75                                     // 000000081A04: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 000000081A08: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000081A10: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 000000081A14: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 000000081A18: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 000000081A20: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081A24: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 000000081A28: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 000000081A30: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081A34: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 000000081A38: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 000000081A40: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000081A48: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000081A4C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 000000081A54: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 000000081A60: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000081A68: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000081A6C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000081A78: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000081A80: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000081A84: BE882004
	s_cbranch_execz 62068                                      // 000000081A88: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f5c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 000000081A8C: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000081A98: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000081AA0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000081AA4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081AA8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000081AAC: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000081AB4: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000081AC0: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000081AC4: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000081AC8: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000081ACC: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000081AD4: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000081ADC: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000081AE0: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000081AE4: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000081AE8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081AEC: BF870095
	.long 0xd71c004a                                           // 000000081AF0: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000081AF4: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000081AF8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000081AFC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081B04: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 000000081B08: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000081B14: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081B18: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000081B1C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000081B24: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081B28: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000081B2C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000081B34: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000081B38: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081B40: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 000000081B44: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 000000081B48: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081B50: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 000000081B54: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 000000081B58: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081B60: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 000000081B64: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000081B6C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 000000081B74: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081B80: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000081B84: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000081B8C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000081B98: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000081BA0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000081BA4: BE882005
	s_cbranch_execz 61999                                      // 000000081BA8: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f68>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 000000081BAC: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000081BB8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000081BC0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000081BC4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081BC8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000081BCC: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000081BD4: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000081BE0: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000081BE4: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000081BE8: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000081BEC: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000081BF4: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000081BFC: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000081C00: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000081C04: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000081C08: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081C0C: BF870095
	.long 0xd71c004a                                           // 000000081C10: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000081C14: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000081C18: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000081C1C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081C24: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 000000081C28: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 000000081C30: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081C38: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000081C3C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000081C44: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081C48: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000081C4C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000081C54: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000081C58: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081C60: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 000000081C64: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 000000081C68: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081C70: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 000000081C74: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 000000081C78: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081C80: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 000000081C84: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000081C8C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 000000081C94: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081CA0: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000081CA4: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000081CAC: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000081CB8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000081CC0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000081CC4: BE882006
	s_cbranch_execz 61930                                      // 000000081CC8: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f74>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 000000081CCC: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000081CD8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000081CE0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000081CE4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081CE8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000081CEC: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000081CF4: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000081D00: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000081D04: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000081D08: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000081D0C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000081D14: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000081D1C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000081D20: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000081D24: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000081D28: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081D2C: BF870095
	.long 0xd71c004a                                           // 000000081D30: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000081D34: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000081D38: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000081D3C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081D44: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 000000081D48: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000081D54: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081D58: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000081D5C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000081D64: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081D68: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000081D6C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000081D74: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000081D78: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081D80: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 000000081D84: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 000000081D88: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081D90: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 000000081D94: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 000000081D98: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081DA0: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 000000081DA4: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000081DAC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 000000081DB4: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081DC0: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000081DC4: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000081DCC: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000081DD8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000081DE0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000081DE4: BE882007
	s_cbranch_execz 61861                                      // 000000081DE8: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f80>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 000000081DEC: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000081DF8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000081E00: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000081E04: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081E08: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000081E0C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000081E14: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000081E20: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000081E24: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000081E28: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000081E2C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000081E34: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000081E3C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000081E40: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000081E44: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000081E48: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081E4C: BF870095
	.long 0xd71c004a                                           // 000000081E50: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000081E54: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000081E58: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000081E5C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081E64: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 000000081E68: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000081E74: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081E78: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000081E7C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000081E84: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081E88: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000081E8C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000081E94: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 000000081E98: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081EA0: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 000000081EA4: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 000000081EA8: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081EB0: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 000000081EB4: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 000000081EB8: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081EC0: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 000000081EC4: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000081ECC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 000000081ED4: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081EE0: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000081EE4: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000081EEC: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000081EF8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000081F00: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000081F04: BE882000
	s_cbranch_execz 61792                                      // 000000081F08: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f8c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 000000081F0C: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 000000081F18: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 000000081F1C: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000081F24: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000081F28: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081F2C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000081F30: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000081F38: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000081F44: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000081F48: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000081F4C: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000081F50: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000081F58: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000081F60: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000081F64: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000081F68: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 000000081F6C: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081F70: BF870095
	.long 0xd71c004a                                           // 000000081F74: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000081F78: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000081F7C: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000081F80: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081F88: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 000000081F8C: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000081F94: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081F98: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 000000081F9C: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 000000081FA4: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081FA8: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 000000081FAC: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 000000081FB4: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 000000081FB8: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081FC0: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 000000081FC4: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 000000081FC8: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081FD0: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 000000081FD4: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 000000081FD8: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081FE0: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 000000081FE4: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 000000081FEC: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 000000081FF4: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082000: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 000000082004: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 00000008200C: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 000000082018: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 000000082020: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000082024: BE882001
	s_cbranch_execz 61723                                      // 000000082028: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f98>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 00000008202C: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 000000082038: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 00000008203C: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 000000082044: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000082048: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008204C: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 000000082050: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000082058: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 000000082060: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 00000008206C: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000082070: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 000000082074: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 00000008207C: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000082080: BF870121
	v_add_f32_e32 v73, v73, v74                                // 000000082084: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 000000082088: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 00000008208C: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082090: BF870095
	.long 0xd71c0049                                           // 000000082094: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 000000082098: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000008209C: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000820A0: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000820A8: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 0000000820AC: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000820B4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000820B8: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 0000000820BC: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 0000000820C4: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000820C8: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 0000000820CC: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 0000000820D4: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 0000000820D8: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000820E0: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 0000000820E4: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 0000000820E8: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000820F0: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 0000000820F4: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 0000000820F8: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082100: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 000000082104: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 00000008210C: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 000000082114: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082120: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 000000082124: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 00000008212C: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 000000082138: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 000000082140: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000082144: BE882002
	s_cbranch_execz 61654                                      // 000000082148: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fa4>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 00000008214C: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000082158: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000082160: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000082164: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082168: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000008216C: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 000000082174: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 000000082180: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000082184: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 000000082188: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000008218C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 000000082194: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008219C: BF870121
	v_add_f32_e32 v66, v66, v73                                // 0000000821A0: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 0000000821A4: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 0000000821A8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000821AC: BF870095
	.long 0xd71c0042                                           // 0000000821B0: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 0000000821B4: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000821B8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000821BC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000821C4: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 0000000821C8: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000821D4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000821D8: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000821DC: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 0000000821E4: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000821E8: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 0000000821EC: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 0000000821F4: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 0000000821F8: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082200: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 000000082204: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 000000082208: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082210: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 000000082214: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 000000082218: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082220: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 000000082224: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000008222C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 000000082234: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082240: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 000000082244: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 00000008224C: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000082258: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000082260: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000082264: BE882003
	s_cbranch_execz 61585                                      // 000000082268: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fb0>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 00000008226C: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000082278: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000082280: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000082284: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082288: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000008228C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000082294: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 0000000822A0: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000822A4: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 0000000822A8: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 0000000822B4: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 0000000822B8: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000822BC: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000822C4: BF870293
	v_exp_f32_e32 v66, v66                                     // 0000000822C8: 7E844B42
	.long 0xd71c0042                                           // 0000000822CC: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000822D0: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000822D4: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000822D8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000822DC: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 0000000822E4: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000822F0: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 0000000822F4: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000822F8: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000082300: BF870291
	v_rcp_f32_e32 v68, v67                                     // 000000082304: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 000000082308: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000082310: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 000000082314: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 000000082318: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 000000082320: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082324: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 000000082328: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 000000082330: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082334: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 000000082338: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 000000082340: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000082348: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000008234C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 000000082354: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 000000082360: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 000000082368: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000008236C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000082378: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000082380: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000082384: BE882004
	s_cbranch_execz 61516                                      // 000000082388: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fbc>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 00000008238C: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000082398: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000823A0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000823A4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000823A8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000823AC: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000823B4: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000823C0: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000823C4: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000823C8: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000823CC: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000823D4: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000823DC: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000823E0: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000823E4: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000823E8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000823EC: BF870095
	.long 0xd71c0042                                           // 0000000823F0: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000823F4: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000823F8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000823FC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082404: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 000000082408: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000082414: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082418: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000008241C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000082424: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082428: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000008242C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000082434: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000082438: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082440: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 000000082444: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 000000082448: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082450: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 000000082454: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 000000082458: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082460: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 000000082464: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000008246C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 000000082474: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082480: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000082484: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 00000008248C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000082498: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000824A0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000824A4: BE882005
	s_cbranch_execz 61447                                      // 0000000824A8: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fc8>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 0000000824AC: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000824B8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000824C0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000824C4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000824C8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000824CC: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000824D4: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000824E0: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000824E4: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000824E8: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000824EC: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000824F4: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000824FC: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000082500: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000082504: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000082508: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008250C: BF870095
	.long 0xd71c0042                                           // 000000082510: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000082514: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000082518: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000008251C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082524: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000082528: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 000000082530: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082538: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000008253C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000082544: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082548: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000008254C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000082554: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000082558: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082560: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000082564: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 000000082568: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082570: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 000000082574: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 000000082578: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082580: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000082584: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 00000008258C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 000000082594: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000825A0: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000825A4: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000825AC: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000825B8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000825C0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000825C4: BE882006
	s_cbranch_execz 61378                                      // 0000000825C8: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fd4>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 0000000825CC: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000825D8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000825E0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000825E4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000825E8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000825EC: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000825F4: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000082600: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000082604: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000082608: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000008260C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000082614: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008261C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000082620: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000082624: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000082628: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008262C: BF870095
	.long 0xd71c0042                                           // 000000082630: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000082634: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000082638: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000008263C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082644: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 000000082648: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000082654: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082658: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000008265C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000082664: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082668: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000008266C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000082674: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000082678: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082680: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000082684: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000082688: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082690: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 000000082694: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 000000082698: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000826A0: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000826A4: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000826AC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 0000000826B4: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000826C0: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000826C4: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000826CC: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000826D8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000826E0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000826E4: BE882007
	s_cbranch_execz 61309                                      // 0000000826E8: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fe0>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 0000000826EC: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000826F8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000082700: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000082704: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082708: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 00000008270C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000082714: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000082720: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000082724: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000082728: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000008272C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000082734: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008273C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000082740: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000082744: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000082748: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008274C: BF870095
	.long 0xd71c0042                                           // 000000082750: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000082754: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000082758: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 00000008275C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082764: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 000000082768: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000082774: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082778: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000008277C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000082784: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082788: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 00000008278C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000082794: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000082798: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000827A0: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000827A4: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 0000000827A8: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000827B0: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 0000000827B4: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 0000000827B8: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000827C0: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000827C4: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000827CC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 0000000827D4: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000827E0: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000827E4: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000827EC: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000827F8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000082800: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000082804: BE882000
	s_cbranch_execz 61240                                      // 000000082808: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fec>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 00000008280C: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 000000082818: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 00000008281C: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 000000082824: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000082828: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008282C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000082830: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000082838: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000082844: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000082848: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 00000008284C: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000082850: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000082858: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000082860: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000082864: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000082868: 7E861144
	v_exp_f32_e32 v66, v66                                     // 00000008286C: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082870: BF870095
	.long 0xd71c0042                                           // 000000082874: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000082878: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000008287C: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000082880: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082888: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 00000008288C: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000082894: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082898: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 00000008289C: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 0000000828A4: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000828A8: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 0000000828AC: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 0000000828B4: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 0000000828B8: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000828C0: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 0000000828C4: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 0000000828C8: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000828D0: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 0000000828D4: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 0000000828D8: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000828E0: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 0000000828E4: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 0000000828EC: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 0000000828F4: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082900: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 000000082904: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 00000008290C: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 000000082918: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 000000082920: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000082924: BE882001
	s_cbranch_execz 61171                                      // 000000082928: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ff8>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 00000008292C: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 000000082938: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 00000008293C: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 000000082944: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000082948: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008294C: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 000000082950: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000082958: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 000000082960: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000008296C: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000082970: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 000000082974: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 00000008297C: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000082980: BF870121
	v_add_f32_e32 v65, v65, v66                                // 000000082984: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000082988: 7E841143
	v_exp_f32_e32 v65, v65                                     // 00000008298C: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082990: BF870095
	.long 0xd71c0041                                           // 000000082994: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000082998: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000008299C: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000829A0: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000829A8: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 0000000829AC: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000829B4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000829B8: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 0000000829BC: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 0000000829C4: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000829C8: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 0000000829CC: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 0000000829D4: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 0000000829D8: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000829E0: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 0000000829E4: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 0000000829E8: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000829F0: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 0000000829F4: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 0000000829F8: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082A00: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 000000082A04: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 000000082A0C: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 000000082A14: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082A20: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 000000082A24: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 000000082A2C: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 000000082A38: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 000000082A40: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000082A44: BE882002
	s_cbranch_execz 61102                                      // 000000082A48: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4004>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 000000082A4C: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000082A58: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000082A60: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000082A64: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082A68: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000082A6C: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 000000082A74: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 000000082A80: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000082A84: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 000000082A88: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000082A8C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 000000082A94: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000082A9C: BF870121
	v_add_f32_e32 v58, v58, v65                                // 000000082AA0: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 000000082AA4: 7E821142
	v_exp_f32_e32 v58, v58                                     // 000000082AA8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082AAC: BF870095
	.long 0xd71c003a                                           // 000000082AB0: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 000000082AB4: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000082AB8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000082ABC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082AC4: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 000000082AC8: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000082AD4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082AD8: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000082ADC: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 000000082AE4: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082AE8: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 000000082AEC: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 000000082AF4: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 000000082AF8: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082B00: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 000000082B04: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 000000082B08: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082B10: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 000000082B14: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 000000082B18: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082B20: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 000000082B24: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000082B2C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 000000082B34: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082B40: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 000000082B44: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 000000082B4C: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000082B58: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000082B60: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000082B64: BE882003
	s_cbranch_execz 61033                                      // 000000082B68: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4010>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 000000082B6C: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000082B78: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000082B80: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000082B84: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082B88: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000082B8C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000082B94: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 000000082BA0: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082BA4: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 000000082BA8: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 000000082BB4: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 000000082BB8: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000082BBC: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000082BC4: BF870293
	v_exp_f32_e32 v58, v58                                     // 000000082BC8: 7E744B3A
	.long 0xd71c003a                                           // 000000082BCC: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000082BD0: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000082BD4: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000082BD8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000082BDC: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 000000082BE4: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082BF0: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 000000082BF4: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000082BF8: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000082C00: BF870291
	v_rcp_f32_e32 v60, v59                                     // 000000082C04: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 000000082C08: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000082C10: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 000000082C14: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 000000082C18: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 000000082C20: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082C24: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 000000082C28: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 000000082C30: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082C34: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 000000082C38: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 000000082C40: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000082C48: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000082C4C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 000000082C54: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 000000082C60: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000082C68: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000082C6C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000082C78: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000082C80: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000082C84: BE882004
	s_cbranch_execz 60964                                      // 000000082C88: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x401c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 000000082C8C: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000082C98: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000082CA0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000082CA4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082CA8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000082CAC: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000082CB4: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000082CC0: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000082CC4: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000082CC8: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000082CCC: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000082CD4: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000082CDC: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000082CE0: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000082CE4: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000082CE8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082CEC: BF870095
	.long 0xd71c003a                                           // 000000082CF0: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000082CF4: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000082CF8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000082CFC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082D04: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 000000082D08: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000082D14: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082D18: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000082D1C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000082D24: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082D28: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000082D2C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 000000082D34: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000082D38: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082D40: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 000000082D44: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 000000082D48: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082D50: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 000000082D54: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 000000082D58: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082D60: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 000000082D64: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000082D6C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 000000082D74: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082D80: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 000000082D84: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000082D8C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000082D98: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000082DA0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000082DA4: BE882005
	s_cbranch_execz 60895                                      // 000000082DA8: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4028>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 000000082DAC: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000082DB8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000082DC0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000082DC4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082DC8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000082DCC: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000082DD4: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000082DE0: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000082DE4: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000082DE8: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000082DEC: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000082DF4: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000082DFC: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000082E00: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000082E04: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000082E08: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082E0C: BF870095
	.long 0xd71c003a                                           // 000000082E10: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000082E14: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000082E18: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000082E1C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082E24: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 000000082E28: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 000000082E30: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082E38: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000082E3C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000082E44: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082E48: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000082E4C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 000000082E54: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000082E58: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082E60: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 000000082E64: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 000000082E68: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082E70: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 000000082E74: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 000000082E78: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082E80: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 000000082E84: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000082E8C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 000000082E94: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082EA0: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 000000082EA4: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000082EAC: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000082EB8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000082EC0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000082EC4: BE882006
	s_cbranch_execz 60826                                      // 000000082EC8: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4034>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 000000082ECC: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000082ED8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000082EE0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000082EE4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082EE8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000082EEC: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000082EF4: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000082F00: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000082F04: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000082F08: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000082F0C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000082F14: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000082F1C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000082F20: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000082F24: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000082F28: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082F2C: BF870095
	.long 0xd71c003a                                           // 000000082F30: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000082F34: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000082F38: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000082F3C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082F44: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 000000082F48: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000082F54: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082F58: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000082F5C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000082F64: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082F68: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000082F6C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 000000082F74: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000082F78: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082F80: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 000000082F84: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 000000082F88: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082F90: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 000000082F94: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 000000082F98: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082FA0: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 000000082FA4: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000082FAC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 000000082FB4: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082FC0: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 000000082FC4: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000082FCC: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 000000082FD8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000082FE0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000082FE4: BE882007
	s_cbranch_execz 60757                                      // 000000082FE8: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4040>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 000000082FEC: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000082FF8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000083000: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000083004: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083008: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 00000008300C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000083014: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000083020: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000083024: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000083028: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 00000008302C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000083034: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008303C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000083040: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000083044: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 000000083048: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008304C: BF870095
	.long 0xd71c003a                                           // 000000083050: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000083054: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000083058: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 00000008305C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083064: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 000000083068: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000083074: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083078: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000008307C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000083084: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083088: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 00000008308C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 000000083094: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 000000083098: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000830A0: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000830A4: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000000830A8: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000830B0: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000830B4: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000830B8: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000830C0: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000830C4: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000830CC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 0000000830D4: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000830E0: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000830E4: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000830EC: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000830F8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000083100: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000083104: BE882000
	s_cbranch_execz 60688                                      // 000000083108: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x404c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 00000008310C: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 000000083118: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 00000008311C: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 000000083124: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000083128: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008312C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000083130: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000083138: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000083144: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000083148: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000008314C: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000083150: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000083158: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000083160: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000083164: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000083168: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000008316C: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083170: BF870095
	.long 0xd71c003a                                           // 000000083174: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000083178: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000008317C: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000083180: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083188: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 00000008318C: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000083194: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083198: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 00000008319C: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 0000000831A4: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000831A8: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 0000000831AC: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 0000000831B4: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 0000000831B8: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000831C0: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 0000000831C4: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 0000000831C8: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000831D0: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 0000000831D4: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 0000000831D8: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000831E0: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 0000000831E4: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 0000000831EC: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 0000000831F4: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083200: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 000000083204: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 00000008320C: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 000000083218: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 000000083220: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000083224: BE882001
	s_cbranch_execz 60619                                      // 000000083228: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4058>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 00000008322C: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 000000083238: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 00000008323C: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 000000083244: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000083248: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008324C: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 000000083250: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000083258: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 000000083260: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000008326C: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000083270: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 000000083274: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 00000008327C: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000083280: BF870121
	v_add_f32_e32 v57, v57, v58                                // 000000083284: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 000000083288: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000008328C: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083290: BF870095
	.long 0xd71c0039                                           // 000000083294: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 000000083298: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000008329C: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000832A0: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000832A8: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 0000000832AC: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000832B4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000832B8: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 0000000832BC: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 0000000832C4: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000832C8: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 0000000832CC: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 0000000832D4: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 0000000832D8: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000832E0: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 0000000832E4: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 0000000832E8: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000832F0: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 0000000832F4: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 0000000832F8: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083300: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 000000083304: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 00000008330C: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 000000083314: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083320: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 000000083324: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 00000008332C: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 000000083338: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 000000083340: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000083344: BE882002
	s_cbranch_execz 60550                                      // 000000083348: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4064>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 00000008334C: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000083358: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000083360: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000083364: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083368: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000008336C: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 000000083374: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 000000083380: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000083384: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 000000083388: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000008338C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 000000083394: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008339C: BF870121
	v_add_f32_e32 v50, v50, v57                                // 0000000833A0: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 0000000833A4: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 0000000833A8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000833AC: BF870095
	.long 0xd71c0032                                           // 0000000833B0: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 0000000833B4: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000833B8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000833BC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000833C4: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 0000000833C8: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000833D4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000833D8: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000833DC: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 0000000833E4: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000833E8: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 0000000833EC: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 0000000833F4: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 0000000833F8: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083400: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 000000083404: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 000000083408: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083410: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 000000083414: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 000000083418: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083420: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 000000083424: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000008342C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 000000083434: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083440: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 000000083444: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 00000008344C: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000083458: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000083460: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000083464: BE882003
	s_cbranch_execz 60481                                      // 000000083468: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4070>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 00000008346C: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000083478: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000083480: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000083484: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083488: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000008348C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000083494: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 0000000834A0: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000834A4: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 0000000834A8: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 0000000834B4: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 0000000834B8: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000834BC: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000834C4: BF870293
	v_exp_f32_e32 v50, v50                                     // 0000000834C8: 7E644B32
	.long 0xd71c0032                                           // 0000000834CC: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000834D0: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000834D4: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000834D8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000834DC: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 0000000834E4: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000834F0: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 0000000834F4: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000834F8: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000083500: BF870291
	v_rcp_f32_e32 v52, v51                                     // 000000083504: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 000000083508: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083510: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 000000083514: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 000000083518: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 000000083520: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083524: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 000000083528: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 000000083530: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083534: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 000000083538: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 000000083540: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000083548: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000008354C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 000000083554: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 000000083560: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 000000083568: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000008356C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000083578: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000083580: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000083584: BE882004
	s_cbranch_execz 60412                                      // 000000083588: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x407c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 00000008358C: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000083598: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000835A0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000835A4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000835A8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000835AC: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000835B4: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000835C0: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000835C4: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000835C8: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000835CC: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000835D4: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000835DC: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000835E0: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000835E4: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000835E8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000835EC: BF870095
	.long 0xd71c0032                                           // 0000000835F0: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000835F4: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000835F8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000835FC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083604: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 000000083608: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000083614: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083618: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000008361C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000083624: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083628: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000008362C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000083634: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000083638: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083640: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 000000083644: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 000000083648: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083650: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 000000083654: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 000000083658: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083660: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 000000083664: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000008366C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 000000083674: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083680: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000083684: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 00000008368C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000083698: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000836A0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000836A4: BE882005
	s_cbranch_execz 60343                                      // 0000000836A8: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4088>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 0000000836AC: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000836B8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000836C0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000836C4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000836C8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000836CC: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000836D4: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000836E0: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000836E4: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000836E8: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000836EC: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000836F4: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000836FC: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000083700: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000083704: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000083708: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008370C: BF870095
	.long 0xd71c0032                                           // 000000083710: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000083714: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000083718: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000008371C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083724: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 000000083728: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 000000083730: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083738: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000008373C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000083744: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083748: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000008374C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000083754: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000083758: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083760: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000083764: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 000000083768: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083770: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 000000083774: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 000000083778: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083780: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000083784: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 00000008378C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 000000083794: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000837A0: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000837A4: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000837AC: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000837B8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000837C0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000837C4: BE882006
	s_cbranch_execz 60274                                      // 0000000837C8: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4094>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 0000000837CC: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000837D8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000837E0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000837E4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000837E8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000837EC: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000837F4: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000083800: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000083804: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000083808: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000008380C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000083814: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008381C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000083820: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000083824: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000083828: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008382C: BF870095
	.long 0xd71c0032                                           // 000000083830: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000083834: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000083838: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000008383C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083844: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 000000083848: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000083854: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083858: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000008385C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000083864: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083868: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000008386C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000083874: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000083878: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083880: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000083884: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 000000083888: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083890: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 000000083894: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 000000083898: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000838A0: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000838A4: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000838AC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 0000000838B4: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000838C0: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000838C4: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000838CC: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000838D8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000838E0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000838E4: BE882007
	s_cbranch_execz 60205                                      // 0000000838E8: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40a0>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 0000000838EC: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000838F8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000083900: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000083904: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083908: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 00000008390C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000083914: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000083920: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000083924: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000083928: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000008392C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000083934: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008393C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000083940: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000083944: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000083948: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008394C: BF870095
	.long 0xd71c0032                                           // 000000083950: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000083954: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000083958: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 00000008395C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083964: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 000000083968: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000083974: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083978: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 00000008397C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000083984: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083988: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 00000008398C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000083994: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000083998: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000839A0: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000839A4: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 0000000839A8: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000839B0: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 0000000839B4: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 0000000839B8: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000839C0: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000839C4: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000839CC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 0000000839D4: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000839E0: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000839E4: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000839EC: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000839F8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000083A00: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000083A04: BE882000
	s_cbranch_execz 60136                                      // 000000083A08: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40ac>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 000000083A0C: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 000000083A18: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 000000083A1C: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 000000083A24: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000083A28: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083A2C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000083A30: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000083A38: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000083A44: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000083A48: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000083A4C: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000083A50: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000083A58: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000083A60: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000083A64: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000083A68: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000083A6C: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083A70: BF870095
	.long 0xd71c0032                                           // 000000083A74: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000083A78: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000083A7C: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000083A80: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083A88: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 000000083A8C: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000083A94: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083A98: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 000000083A9C: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 000000083AA4: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083AA8: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 000000083AAC: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 000000083AB4: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 000000083AB8: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083AC0: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 000000083AC4: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 000000083AC8: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083AD0: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 000000083AD4: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 000000083AD8: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083AE0: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 000000083AE4: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 000000083AEC: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 000000083AF4: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083B00: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 000000083B04: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 000000083B0C: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 000000083B18: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 000000083B20: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000083B24: BE882001
	s_cbranch_execz 60067                                      // 000000083B28: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40b8>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 000000083B2C: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 000000083B38: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 000000083B3C: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 000000083B44: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000083B48: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000083B4C: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 000000083B50: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000083B58: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 000000083B60: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 000000083B6C: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000083B70: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 000000083B74: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 000000083B7C: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000083B80: BF870121
	v_add_f32_e32 v49, v49, v50                                // 000000083B84: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 000000083B88: 7E641133
	v_exp_f32_e32 v49, v49                                     // 000000083B8C: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083B90: BF870095
	.long 0xd71c0031                                           // 000000083B94: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 000000083B98: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 000000083B9C: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000083BA0: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083BA8: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 000000083BAC: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000083BB4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083BB8: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 000000083BBC: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 000000083BC4: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083BC8: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 000000083BCC: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 000000083BD4: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 000000083BD8: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083BE0: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 000000083BE4: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 000000083BE8: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083BF0: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 000000083BF4: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 000000083BF8: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083C00: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 000000083C04: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 000000083C0C: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 000000083C14: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083C20: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 000000083C24: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 000000083C2C: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 000000083C38: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 000000083C40: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000083C44: BE882002
	s_cbranch_execz 59998                                      // 000000083C48: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40c4>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 000000083C4C: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000083C58: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000083C60: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000083C64: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083C68: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000083C6C: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 000000083C74: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 000000083C80: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000083C84: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 000000083C88: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000083C8C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 000000083C94: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000083C9C: BF870121
	v_add_f32_e32 v42, v42, v49                                // 000000083CA0: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 000000083CA4: 7E621132
	v_exp_f32_e32 v42, v42                                     // 000000083CA8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083CAC: BF870095
	.long 0xd71c002a                                           // 000000083CB0: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 000000083CB4: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000083CB8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000083CBC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083CC4: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 000000083CC8: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000083CD4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083CD8: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000083CDC: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 000000083CE4: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083CE8: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 000000083CEC: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 000000083CF4: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 000000083CF8: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083D00: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 000000083D04: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 000000083D08: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083D10: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 000000083D14: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 000000083D18: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083D20: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 000000083D24: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000083D2C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 000000083D34: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083D40: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 000000083D44: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 000000083D4C: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000083D58: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000083D60: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000083D64: BE882003
	s_cbranch_execz 59929                                      // 000000083D68: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40d0>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 000000083D6C: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000083D78: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000083D80: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000083D84: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083D88: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000083D8C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000083D94: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 000000083DA0: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083DA4: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 000000083DA8: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 000000083DB4: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 000000083DB8: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000083DBC: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000083DC4: BF870293
	v_exp_f32_e32 v42, v42                                     // 000000083DC8: 7E544B2A
	.long 0xd71c002a                                           // 000000083DCC: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000083DD0: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000083DD4: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000083DD8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000083DDC: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 000000083DE4: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083DF0: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 000000083DF4: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000083DF8: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000083E00: BF870291
	v_rcp_f32_e32 v44, v43                                     // 000000083E04: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 000000083E08: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000083E10: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 000000083E14: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 000000083E18: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 000000083E20: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083E24: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 000000083E28: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 000000083E30: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083E34: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 000000083E38: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 000000083E40: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000083E48: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000083E4C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 000000083E54: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 000000083E60: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000083E68: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000083E6C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000083E78: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000083E80: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000083E84: BE882004
	s_cbranch_execz 59860                                      // 000000083E88: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40dc>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 000000083E8C: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000083E98: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000083EA0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000083EA4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083EA8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000083EAC: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000083EB4: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000083EC0: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000083EC4: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000083EC8: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000083ECC: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000083ED4: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000083EDC: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000083EE0: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000083EE4: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000083EE8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083EEC: BF870095
	.long 0xd71c002a                                           // 000000083EF0: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000083EF4: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000083EF8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000083EFC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083F04: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 000000083F08: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000083F14: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083F18: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000083F1C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000083F24: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083F28: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 000000083F2C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000083F34: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000083F38: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083F40: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 000000083F44: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 000000083F48: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083F50: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 000000083F54: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 000000083F58: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083F60: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 000000083F64: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000083F6C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 000000083F74: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083F80: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000083F84: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000083F8C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 000000083F98: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000083FA0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000083FA4: BE882005
	s_cbranch_execz 59791                                      // 000000083FA8: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40e8>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 000000083FAC: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 000000083FB8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000083FC0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000083FC4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000083FC8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000083FCC: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000083FD4: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000083FE0: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000083FE4: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000083FE8: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000083FEC: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000083FF4: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000083FFC: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000084000: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000084004: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000084008: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008400C: BF870095
	.long 0xd71c002a                                           // 000000084010: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000084014: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000084018: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000008401C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084024: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 000000084028: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 000000084030: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084038: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000008403C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000084044: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084048: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000008404C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000084054: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000084058: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084060: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 000000084064: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 000000084068: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084070: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 000000084074: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 000000084078: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084080: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 000000084084: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 00000008408C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 000000084094: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000840A0: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000840A4: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000840AC: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000840B8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000840C0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000840C4: BE882006
	s_cbranch_execz 59722                                      // 0000000840C8: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40f4>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 0000000840CC: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000840D8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000840E0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000840E4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000840E8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000840EC: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000840F4: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000084100: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000084104: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000084108: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000008410C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000084114: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008411C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000084120: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000084124: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000084128: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008412C: BF870095
	.long 0xd71c002a                                           // 000000084130: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000084134: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000084138: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000008413C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084144: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 000000084148: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000084154: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084158: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000008415C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000084164: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084168: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000008416C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000084174: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000084178: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084180: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 000000084184: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 000000084188: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084190: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 000000084194: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 000000084198: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000841A0: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000841A4: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000841AC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 0000000841B4: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000841C0: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000841C4: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000841CC: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000841D8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000841E0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000841E4: BE882007
	s_cbranch_execz 59653                                      // 0000000841E8: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4100>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 0000000841EC: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000841F8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000084200: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000084204: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084208: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 00000008420C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000084214: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000084220: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000084224: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000084228: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000008422C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000084234: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008423C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000084240: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000084244: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 000000084248: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008424C: BF870095
	.long 0xd71c002a                                           // 000000084250: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000084254: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000084258: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 00000008425C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084264: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 000000084268: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000084274: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084278: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000008427C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000084284: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084288: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 00000008428C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000084294: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 000000084298: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000842A0: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000842A4: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000000842A8: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000842B0: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000000842B4: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000000842B8: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000842C0: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000842C4: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000842CC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 0000000842D4: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000842E0: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000842E4: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000842EC: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000842F8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000084300: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000084304: BE882000
	s_cbranch_execz 59584                                      // 000000084308: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x410c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 00000008430C: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 000000084318: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 00000008431C: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 000000084324: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000084328: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008432C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000084330: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000084338: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000084344: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000084348: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000008434C: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000084350: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000084358: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000084360: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000084364: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000084368: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000008436C: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084370: BF870095
	.long 0xd71c002a                                           // 000000084374: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000084378: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000008437C: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000084380: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084388: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 00000008438C: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000084394: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084398: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 00000008439C: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 0000000843A4: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000843A8: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 0000000843AC: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 0000000843B4: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 0000000843B8: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000843C0: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 0000000843C4: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 0000000843C8: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000843D0: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 0000000843D4: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 0000000843D8: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000843E0: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 0000000843E4: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 0000000843EC: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 0000000843F4: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084400: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 000000084404: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 00000008440C: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 000000084418: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 000000084420: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000084424: BE882001
	s_cbranch_execz 59515                                      // 000000084428: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4118>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 00000008442C: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 000000084438: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 00000008443C: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 000000084444: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000084448: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008444C: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 000000084450: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000084458: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 000000084460: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 00000008446C: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000084470: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 000000084474: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 00000008447C: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000084480: BF870121
	v_add_f32_e32 v41, v41, v42                                // 000000084484: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 000000084488: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 00000008448C: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084490: BF870095
	.long 0xd71c0029                                           // 000000084494: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 000000084498: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000008449C: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000844A0: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000844A8: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 0000000844AC: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000844B4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000844B8: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 0000000844BC: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 0000000844C4: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000844C8: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 0000000844CC: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 0000000844D4: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 0000000844D8: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000844E0: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 0000000844E4: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 0000000844E8: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000844F0: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 0000000844F4: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 0000000844F8: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084500: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 000000084504: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 00000008450C: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 000000084514: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084520: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 000000084524: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 00000008452C: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 000000084538: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 000000084540: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000084544: BE882002
	s_cbranch_execz 59446                                      // 000000084548: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4124>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 00000008454C: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000084558: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000084560: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000084564: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084568: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000008456C: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 000000084574: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 000000084580: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000084584: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 000000084588: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000008458C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 000000084594: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008459C: BF870121
	v_add_f32_e32 v34, v34, v41                                // 0000000845A0: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 0000000845A4: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 0000000845A8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000845AC: BF870095
	.long 0xd71c0022                                           // 0000000845B0: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 0000000845B4: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000845B8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000845BC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000845C4: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 0000000845C8: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000845D4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000845D8: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000845DC: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 0000000845E4: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000845E8: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 0000000845EC: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 0000000845F4: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 0000000845F8: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084600: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 000000084604: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 000000084608: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084610: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 000000084614: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 000000084618: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084620: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 000000084624: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000008462C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 000000084634: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084640: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 000000084644: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 00000008464C: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000084658: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000084660: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000084664: BE882003
	s_cbranch_execz 59377                                      // 000000084668: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4130>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 00000008466C: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000084678: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000084680: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000084684: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084688: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 00000008468C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000084694: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 0000000846A0: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000846A4: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 0000000846A8: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 0000000846B4: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 0000000846B8: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000846BC: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000846C4: BF870293
	v_exp_f32_e32 v34, v34                                     // 0000000846C8: 7E444B22
	.long 0xd71c0022                                           // 0000000846CC: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000846D0: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000846D4: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000846D8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000846DC: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 0000000846E4: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000846F0: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 0000000846F4: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000846F8: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000084700: BF870291
	v_rcp_f32_e32 v36, v35                                     // 000000084704: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 000000084708: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000084710: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 000000084714: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 000000084718: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 000000084720: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084724: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 000000084728: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 000000084730: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084734: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 000000084738: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 000000084740: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000084748: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000008474C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 000000084754: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 000000084760: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 000000084768: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000008476C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000084778: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000084780: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000084784: BE882004
	s_cbranch_execz 59308                                      // 000000084788: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x413c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 00000008478C: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000084798: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000847A0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000847A4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000847A8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000847AC: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000847B4: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000847C0: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000847C4: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000847C8: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000847CC: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000847D4: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000847DC: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000847E0: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000847E4: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000847E8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000847EC: BF870095
	.long 0xd71c0022                                           // 0000000847F0: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000847F4: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000847F8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000847FC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084804: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 000000084808: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000084814: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084818: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000008481C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000084824: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084828: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 00000008482C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000084834: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000084838: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084840: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 000000084844: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 000000084848: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084850: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 000000084854: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 000000084858: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084860: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 000000084864: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000008486C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 000000084874: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084880: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000084884: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 00000008488C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000084898: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000848A0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000848A4: BE882005
	s_cbranch_execz 59239                                      // 0000000848A8: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4148>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 0000000848AC: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000848B8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000848C0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000848C4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000848C8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000848CC: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000848D4: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000848E0: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000848E4: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000848E8: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000848EC: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000848F4: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000848FC: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000084900: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000084904: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000084908: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008490C: BF870095
	.long 0xd71c0022                                           // 000000084910: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000084914: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000084918: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 00000008491C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084924: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 000000084928: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 000000084930: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084938: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 00000008493C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000084944: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084948: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 00000008494C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000084954: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000084958: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084960: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000084964: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 000000084968: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084970: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 000000084974: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 000000084978: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084980: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000084984: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 00000008498C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 000000084994: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000849A0: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000849A4: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000849AC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000849B8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000849C0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000849C4: BE882006
	s_cbranch_execz 59170                                      // 0000000849C8: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4154>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 0000000849CC: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000849D8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000849E0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000849E4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000849E8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000849EC: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000849F4: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000084A00: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000084A04: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000084A08: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000084A0C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000084A14: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000084A1C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000084A20: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000084A24: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000084A28: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084A2C: BF870095
	.long 0xd71c0022                                           // 000000084A30: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000084A34: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000084A38: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000084A3C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084A44: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 000000084A48: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000084A54: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084A58: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000084A5C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000084A64: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084A68: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000084A6C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000084A74: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000084A78: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084A80: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000084A84: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 000000084A88: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084A90: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 000000084A94: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 000000084A98: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084AA0: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000084AA4: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000084AAC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 000000084AB4: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084AC0: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000084AC4: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000084ACC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000084AD8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000084AE0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000084AE4: BE882007
	s_cbranch_execz 59101                                      // 000000084AE8: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4160>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 000000084AEC: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000084AF8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000084B00: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000084B04: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084B08: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000084B0C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000084B14: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000084B20: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000084B24: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000084B28: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000084B2C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000084B34: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000084B3C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000084B40: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000084B44: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000084B48: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084B4C: BF870095
	.long 0xd71c0022                                           // 000000084B50: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000084B54: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000084B58: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000084B5C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084B64: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 000000084B68: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000084B74: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084B78: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000084B7C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000084B84: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084B88: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000084B8C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000084B94: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000084B98: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084BA0: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000084BA4: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 000000084BA8: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084BB0: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 000000084BB4: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 000000084BB8: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084BC0: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000084BC4: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000084BCC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 000000084BD4: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084BE0: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000084BE4: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000084BEC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000084BF8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000084C00: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000084C04: BE882000
	s_cbranch_execz 59032                                      // 000000084C08: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x416c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 000000084C0C: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 000000084C18: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 000000084C1C: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 000000084C24: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000084C28: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084C2C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000084C30: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000084C38: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000084C44: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000084C48: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000084C4C: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000084C50: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000084C58: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000084C60: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000084C64: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000084C68: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000084C6C: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084C70: BF870095
	.long 0xd71c0022                                           // 000000084C74: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000084C78: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000084C7C: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000084C80: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084C88: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 000000084C8C: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000084C94: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084C98: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 000000084C9C: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 000000084CA4: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084CA8: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 000000084CAC: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 000000084CB4: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 000000084CB8: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084CC0: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 000000084CC4: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 000000084CC8: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084CD0: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 000000084CD4: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 000000084CD8: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084CE0: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 000000084CE4: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 000000084CEC: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 000000084CF4: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084D00: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 000000084D04: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 000000084D0C: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 000000084D18: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 000000084D20: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000084D24: BE882001
	s_cbranch_execz 58963                                      // 000000084D28: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4178>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 000000084D2C: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 000000084D38: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 000000084D3C: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 000000084D44: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000084D48: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000084D4C: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 000000084D50: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000084D58: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 000000084D60: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 000000084D6C: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000084D70: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 000000084D74: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 000000084D7C: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000084D80: BF870121
	v_add_f32_e32 v33, v33, v34                                // 000000084D84: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 000000084D88: 7E441123
	v_exp_f32_e32 v33, v33                                     // 000000084D8C: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084D90: BF870095
	.long 0xd71c0021                                           // 000000084D94: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 000000084D98: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 000000084D9C: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000084DA0: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084DA8: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 000000084DAC: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000084DB4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084DB8: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 000000084DBC: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 000000084DC4: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084DC8: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 000000084DCC: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 000000084DD4: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 000000084DD8: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084DE0: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 000000084DE4: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 000000084DE8: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084DF0: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 000000084DF4: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 000000084DF8: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084E00: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 000000084E04: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 000000084E0C: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 000000084E14: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084E20: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 000000084E24: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 000000084E2C: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 000000084E38: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 000000084E40: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000084E44: BE882002
	s_cbranch_execz 58894                                      // 000000084E48: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4184>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 000000084E4C: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000084E58: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000084E60: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000084E64: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084E68: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000084E6C: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 000000084E74: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 000000084E80: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000084E84: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 000000084E88: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000084E8C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 000000084E94: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000084E9C: BF870121
	v_add_f32_e32 v26, v26, v33                                // 000000084EA0: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 000000084EA4: 7E421122
	v_exp_f32_e32 v26, v26                                     // 000000084EA8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084EAC: BF870095
	.long 0xd71c001a                                           // 000000084EB0: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 000000084EB4: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000084EB8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000084EBC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084EC4: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 000000084EC8: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000084ED4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084ED8: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000084EDC: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 000000084EE4: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084EE8: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 000000084EEC: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 000000084EF4: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 000000084EF8: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084F00: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 000000084F04: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 000000084F08: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084F10: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 000000084F14: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 000000084F18: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084F20: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 000000084F24: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000084F2C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 000000084F34: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084F40: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 000000084F44: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 000000084F4C: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000084F58: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000084F60: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000084F64: BE882003
	s_cbranch_execz 58825                                      // 000000084F68: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4190>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 000000084F6C: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000084F78: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000084F80: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000084F84: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084F88: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000084F8C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000084F94: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 000000084FA0: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084FA4: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 000000084FA8: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 000000084FB4: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 000000084FB8: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000084FBC: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000084FC4: BF870293
	v_exp_f32_e32 v26, v26                                     // 000000084FC8: 7E344B1A
	.long 0xd71c001a                                           // 000000084FCC: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000084FD0: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000084FD4: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000084FD8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000084FDC: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 000000084FE4: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000084FF0: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 000000084FF4: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000084FF8: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000085000: BF870291
	v_rcp_f32_e32 v28, v27                                     // 000000085004: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 000000085008: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000085010: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 000000085014: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 000000085018: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 000000085020: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085024: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 000000085028: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 000000085030: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085034: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 000000085038: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 000000085040: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000085048: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000008504C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 000000085054: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 000000085060: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000085068: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000008506C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000085078: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000085080: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000085084: BE882004
	s_cbranch_execz 58756                                      // 000000085088: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x419c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 00000008508C: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 000000085098: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000850A0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000850A4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000850A8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000850AC: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000850B4: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000850C0: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000850C4: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000850C8: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000850CC: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000850D4: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000850DC: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000850E0: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000850E4: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000850E8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000850EC: BF870095
	.long 0xd71c001a                                           // 0000000850F0: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000850F4: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000850F8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000850FC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085104: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 000000085108: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000085114: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085118: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000008511C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000085124: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085128: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000008512C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000085134: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000085138: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085140: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 000000085144: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 000000085148: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085150: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 000000085154: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 000000085158: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085160: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 000000085164: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000008516C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 000000085174: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085180: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000085184: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 00000008518C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000085198: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000851A0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000851A4: BE882005
	s_cbranch_execz 58687                                      // 0000000851A8: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41a8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 0000000851AC: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000851B8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000851C0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000851C4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000851C8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000851CC: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000851D4: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000851E0: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000851E4: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000851E8: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000851EC: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000851F4: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000851FC: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000085200: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000085204: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000085208: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008520C: BF870095
	.long 0xd71c001a                                           // 000000085210: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000085214: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000085218: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000008521C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085224: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 000000085228: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 000000085230: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085238: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000008523C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000085244: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085248: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000008524C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000085254: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000085258: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085260: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 000000085264: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 000000085268: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085270: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 000000085274: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 000000085278: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085280: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 000000085284: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 00000008528C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 000000085294: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000852A0: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000852A4: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000852AC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000852B8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000852C0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000852C4: BE882006
	s_cbranch_execz 58618                                      // 0000000852C8: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41b4>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 0000000852CC: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000852D8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000852E0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000852E4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000852E8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000852EC: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000852F4: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000085300: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000085304: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000085308: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000008530C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000085314: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008531C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000085320: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000085324: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000085328: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008532C: BF870095
	.long 0xd71c001a                                           // 000000085330: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000085334: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000085338: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000008533C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085344: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 000000085348: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000085354: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085358: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000008535C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000085364: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085368: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000008536C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000085374: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000085378: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085380: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 000000085384: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 000000085388: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085390: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 000000085394: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 000000085398: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000853A0: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000853A4: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000853AC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 0000000853B4: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000853C0: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000853C4: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000853CC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000853D8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000853E0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000853E4: BE882007
	s_cbranch_execz 58549                                      // 0000000853E8: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41c0>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 0000000853EC: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000853F8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000085400: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000085404: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085408: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 00000008540C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000085414: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000085420: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000085424: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000085428: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000008542C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000085434: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008543C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000085440: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000085444: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000085448: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008544C: BF870095
	.long 0xd71c001a                                           // 000000085450: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000085454: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000085458: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 00000008545C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085464: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 000000085468: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000085474: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085478: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000008547C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000085484: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085488: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 00000008548C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000085494: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 000000085498: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000854A0: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000854A4: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000000854A8: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000854B0: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000000854B4: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000000854B8: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000854C0: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000854C4: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000854CC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 0000000854D4: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000854E0: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000854E4: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000854EC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000854F8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000085500: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000085504: BE882000
	s_cbranch_execz 58480                                      // 000000085508: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41cc>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 00000008550C: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 000000085518: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 00000008551C: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 000000085524: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000085528: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008552C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000085530: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000085538: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000085544: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000085548: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000008554C: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000085550: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000085558: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000085560: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000085564: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000085568: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000008556C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085570: BF870095
	.long 0xd71c001a                                           // 000000085574: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000085578: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000008557C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000085580: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085588: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 00000008558C: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000085594: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085598: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 00000008559C: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 0000000855A4: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000855A8: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 0000000855AC: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 0000000855B4: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 0000000855B8: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000855C0: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 0000000855C4: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 0000000855C8: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000855D0: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 0000000855D4: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 0000000855D8: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000855E0: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 0000000855E4: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 0000000855EC: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 0000000855F4: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085600: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 000000085604: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 00000008560C: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 000000085618: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 000000085620: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000085624: BE882001
	s_cbranch_execz 58411                                      // 000000085628: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41d8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 00000008562C: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 000000085638: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 00000008563C: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 000000085644: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000085648: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008564C: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 000000085650: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000085658: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 000000085660: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000008566C: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000085670: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 000000085674: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 00000008567C: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000085680: BF870121
	v_add_f32_e32 v25, v25, v26                                // 000000085684: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 000000085688: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 00000008568C: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085690: BF870095
	.long 0xd71c0019                                           // 000000085694: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000085698: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000008569C: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000856A0: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000856A8: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 0000000856AC: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000856B4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000856B8: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 0000000856BC: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 0000000856C4: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000856C8: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 0000000856CC: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 0000000856D4: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 0000000856D8: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000856E0: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 0000000856E4: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 0000000856E8: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000856F0: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 0000000856F4: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 0000000856F8: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085700: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 000000085704: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 00000008570C: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 000000085714: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085720: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 000000085724: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 00000008572C: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 000000085738: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 000000085740: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000085744: BE882002
	s_cbranch_execz 58342                                      // 000000085748: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41e4>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 00000008574C: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000085758: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000085760: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000085764: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085768: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000008576C: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 000000085774: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 000000085780: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000085784: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 000000085788: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 00000008578C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 000000085794: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008579C: BF870121
	v_add_f32_e32 v18, v18, v25                                // 0000000857A0: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 0000000857A4: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 0000000857A8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000857AC: BF870095
	.long 0xd71c0012                                           // 0000000857B0: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 0000000857B4: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000857B8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000857BC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000857C4: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 0000000857C8: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000857D4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000857D8: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000857DC: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 0000000857E4: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000857E8: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 0000000857EC: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 0000000857F4: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 0000000857F8: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085800: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 000000085804: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 000000085808: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085810: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 000000085814: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 000000085818: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085820: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 000000085824: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000008582C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 000000085834: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085840: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 000000085844: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 00000008584C: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000085858: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000085860: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000085864: BE882003
	s_cbranch_execz 58273                                      // 000000085868: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41f0>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 00000008586C: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000085878: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000085880: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000085884: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085888: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 00000008588C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000085894: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 0000000858A0: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000858A4: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 0000000858A8: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 0000000858B4: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 0000000858B8: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000858BC: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000858C4: BF870293
	v_exp_f32_e32 v18, v18                                     // 0000000858C8: 7E244B12
	.long 0xd71c0012                                           // 0000000858CC: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000858D0: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000858D4: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000858D8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000858DC: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 0000000858E4: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000858F0: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 0000000858F4: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000858F8: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000085900: BF870291
	v_rcp_f32_e32 v20, v19                                     // 000000085904: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 000000085908: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000085910: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 000000085914: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 000000085918: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 000000085920: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085924: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 000000085928: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 000000085930: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085934: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 000000085938: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 000000085940: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000085948: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 00000008594C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 000000085954: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 000000085960: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000085968: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000008596C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000085978: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000085980: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000085984: BE882004
	s_cbranch_execz 58204                                      // 000000085988: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41fc>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 00000008598C: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000085998: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000859A0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000859A4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000859A8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000859AC: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000859B4: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000859C0: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000859C4: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000859C8: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000859CC: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000859D4: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000859DC: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000859E0: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000859E4: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000859E8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000859EC: BF870095
	.long 0xd71c0012                                           // 0000000859F0: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000859F4: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000859F8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000859FC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085A04: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 000000085A08: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000085A14: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085A18: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000085A1C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000085A24: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085A28: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000085A2C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 000000085A34: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000085A38: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085A40: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 000000085A44: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 000000085A48: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085A50: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 000000085A54: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 000000085A58: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085A60: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 000000085A64: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000085A6C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 000000085A74: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085A80: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000085A84: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000085A8C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000085A98: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000085AA0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000085AA4: BE882005
	s_cbranch_execz 58135                                      // 000000085AA8: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4208>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 000000085AAC: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000085AB8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000085AC0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000085AC4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085AC8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000085ACC: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000085AD4: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000085AE0: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000085AE4: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000085AE8: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000085AEC: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000085AF4: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000085AFC: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000085B00: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000085B04: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000085B08: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085B0C: BF870095
	.long 0xd71c0012                                           // 000000085B10: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000085B14: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000085B18: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000085B1C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085B24: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 000000085B28: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 000000085B30: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085B38: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000085B3C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000085B44: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085B48: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000085B4C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 000000085B54: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000085B58: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085B60: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 000000085B64: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 000000085B68: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085B70: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 000000085B74: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 000000085B78: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085B80: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 000000085B84: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000085B8C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 000000085B94: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085BA0: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000085BA4: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000085BAC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000085BB8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000085BC0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000085BC4: BE882006
	s_cbranch_execz 58066                                      // 000000085BC8: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4214>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 000000085BCC: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000085BD8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000085BE0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000085BE4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085BE8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000085BEC: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000085BF4: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000085C00: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000085C04: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000085C08: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000085C0C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000085C14: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000085C1C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000085C20: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000085C24: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000085C28: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085C2C: BF870095
	.long 0xd71c0012                                           // 000000085C30: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000085C34: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000085C38: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000085C3C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085C44: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 000000085C48: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000085C54: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085C58: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000085C5C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000085C64: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085C68: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000085C6C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 000000085C74: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000085C78: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085C80: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 000000085C84: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 000000085C88: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085C90: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 000000085C94: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 000000085C98: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085CA0: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 000000085CA4: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000085CAC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 000000085CB4: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085CC0: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000085CC4: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000085CCC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000085CD8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000085CE0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000085CE4: BE882007
	s_cbranch_execz 57997                                      // 000000085CE8: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4220>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 000000085CEC: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000085CF8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000085D00: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000085D04: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085D08: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000085D0C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000085D14: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000085D20: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000085D24: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000085D28: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000085D2C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000085D34: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000085D3C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000085D40: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000085D44: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000085D48: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085D4C: BF870095
	.long 0xd71c0012                                           // 000000085D50: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000085D54: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000085D58: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000085D5C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085D64: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 000000085D68: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000085D74: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085D78: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000085D7C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000085D84: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085D88: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000085D8C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 000000085D94: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000085D98: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085DA0: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 000000085DA4: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 000000085DA8: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085DB0: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 000000085DB4: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 000000085DB8: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085DC0: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 000000085DC4: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000085DCC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 000000085DD4: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085DE0: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000085DE4: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000085DEC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000085DF8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000085E00: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000085E04: BE882000
	s_cbranch_execz 57928                                      // 000000085E08: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x422c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 000000085E0C: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 000000085E18: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 000000085E1C: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000085E24: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000085E28: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085E2C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000085E30: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000085E38: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000085E44: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000085E48: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000085E4C: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000085E50: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000085E58: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000085E60: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000085E64: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000085E68: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000085E6C: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085E70: BF870095
	.long 0xd71c0012                                           // 000000085E74: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000085E78: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000085E7C: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000085E80: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085E88: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 000000085E8C: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000085E94: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085E98: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 000000085E9C: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 000000085EA4: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085EA8: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 000000085EAC: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 000000085EB4: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 000000085EB8: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085EC0: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 000000085EC4: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 000000085EC8: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085ED0: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 000000085ED4: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 000000085ED8: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085EE0: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 000000085EE4: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 000000085EEC: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 000000085EF4: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085F00: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 000000085F04: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 000000085F0C: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 000000085F18: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 000000085F20: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000085F24: BE882001
	s_cbranch_execz 57859                                      // 000000085F28: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4238>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 000000085F2C: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 000000085F38: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 000000085F3C: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 000000085F44: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000085F48: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000085F4C: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 000000085F50: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000085F58: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 000000085F60: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 000000085F6C: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000085F70: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 000000085F74: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 000000085F7C: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000085F80: BF870121
	v_add_f32_e32 v17, v17, v18                                // 000000085F84: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 000000085F88: 7E241113
	v_exp_f32_e32 v17, v17                                     // 000000085F8C: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085F90: BF870095
	.long 0xd71c0011                                           // 000000085F94: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000085F98: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000085F9C: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000085FA0: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085FA8: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 000000085FAC: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000085FB4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085FB8: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 000000085FBC: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 000000085FC4: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085FC8: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 000000085FCC: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 000000085FD4: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 000000085FD8: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085FE0: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 000000085FE4: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 000000085FE8: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000085FF0: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 000000085FF4: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 000000085FF8: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086000: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 000000086004: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 00000008600C: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 000000086014: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086020: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 000000086024: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 00000008602C: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 000000086038: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 000000086040: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000086044: BE882002
	s_cbranch_execz 57790                                      // 000000086048: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4244>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 00000008604C: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000086058: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000086060: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000086064: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086068: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000008606C: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 000000086074: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 000000086080: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000086084: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 000000086088: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000008608C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 000000086094: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008609C: BF870121
	v_add_f32_e32 v10, v10, v17                                // 0000000860A0: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 0000000860A4: 7E221112
	v_exp_f32_e32 v10, v10                                     // 0000000860A8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000860AC: BF870095
	.long 0xd71c000a                                           // 0000000860B0: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 0000000860B4: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000860B8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000860BC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000860C4: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 0000000860C8: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000860D4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000860D8: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000860DC: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 0000000860E4: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000860E8: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 0000000860EC: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 0000000860F4: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 0000000860F8: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086100: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 000000086104: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 000000086108: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086110: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 000000086114: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 000000086118: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086120: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 000000086124: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000008612C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 000000086134: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086140: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 000000086144: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 00000008614C: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000086158: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000086160: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000086164: BE882003
	s_cbranch_execz 57721                                      // 000000086168: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4250>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 00000008616C: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000086178: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000086180: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000086184: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086188: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000008618C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000086194: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 0000000861A0: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000861A4: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 0000000861A8: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 0000000861B4: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 0000000861B8: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000861BC: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000861C4: BF870293
	v_exp_f32_e32 v10, v10                                     // 0000000861C8: 7E144B0A
	.long 0xd71c000a                                           // 0000000861CC: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000861D0: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000861D4: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000861D8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000861DC: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 0000000861E4: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000861F0: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000861F4: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000861F8: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000086200: BF870291
	v_rcp_f32_e32 v12, v11                                     // 000000086204: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 000000086208: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000086210: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 000000086214: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 000000086218: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 000000086220: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086224: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 000000086228: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 000000086230: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086234: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 000000086238: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 000000086240: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000086248: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000008624C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 000000086254: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 000000086260: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000086268: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000008626C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000086278: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000086280: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000086284: BE882004
	s_cbranch_execz 57652                                      // 000000086288: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x425c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 00000008628C: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000086298: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000862A0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000862A4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000862A8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000862AC: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000862B4: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000862C0: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000862C4: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000862C8: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000862CC: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000862D4: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000862DC: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000862E0: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000862E4: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000862E8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000862EC: BF870095
	.long 0xd71c000a                                           // 0000000862F0: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000862F4: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000862F8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000862FC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086304: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 000000086308: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000086314: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086318: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000008631C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000086324: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086328: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000008632C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000086334: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000086338: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086340: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 000000086344: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 000000086348: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086350: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 000000086354: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 000000086358: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086360: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 000000086364: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000008636C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 000000086374: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086380: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000086384: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000008638C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000086398: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000863A0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000863A4: BE882005
	s_cbranch_execz 57583                                      // 0000000863A8: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4268>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 0000000863AC: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000863B8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000863C0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000863C4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000863C8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000863CC: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000863D4: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000863E0: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000863E4: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000863E8: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000863EC: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000863F4: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000863FC: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000086400: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000086404: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000086408: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008640C: BF870095
	.long 0xd71c000a                                           // 000000086410: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000086414: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000086418: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000008641C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086424: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 000000086428: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 000000086430: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086438: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000008643C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000086444: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086448: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000008644C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000086454: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000086458: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086460: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000086464: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 000000086468: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086470: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 000000086474: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 000000086478: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086480: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000086484: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 00000008648C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 000000086494: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000864A0: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000864A4: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000864AC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000864B8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000864C0: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000864C4: BE882006
	s_cbranch_execz 57514                                      // 0000000864C8: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4274>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 0000000864CC: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000864D8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000864E0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000864E4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000864E8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000864EC: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000864F4: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000086500: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000086504: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000086508: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000008650C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000086514: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008651C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000086520: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000086524: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000086528: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008652C: BF870095
	.long 0xd71c000a                                           // 000000086530: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000086534: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000086538: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000008653C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086544: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 000000086548: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000086554: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086558: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000008655C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000086564: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086568: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000008656C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000086574: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000086578: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086580: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000086584: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 000000086588: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086590: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 000000086594: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 000000086598: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000865A0: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000865A4: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000865AC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 0000000865B4: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000865C0: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000865C4: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000865CC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000865D8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000865E0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000865E4: BE882007
	s_cbranch_execz 57445                                      // 0000000865E8: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4280>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 0000000865EC: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000865F8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000086600: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000086604: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086608: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 00000008660C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000086614: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000086620: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000086624: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000086628: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000008662C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000086634: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008663C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000086640: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000086644: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000086648: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008664C: BF870095
	.long 0xd71c000a                                           // 000000086650: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000086654: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000086658: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 00000008665C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086664: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 000000086668: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000086674: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086678: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000008667C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000086684: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086688: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 00000008668C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000086694: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000086698: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000866A0: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000866A4: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 0000000866A8: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000866B0: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000000866B4: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 0000000866B8: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000866C0: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000866C4: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000866CC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 0000000866D4: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000866E0: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000866E4: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000866EC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000866F8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000086700: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000086704: BE882000
	s_cbranch_execz 57376                                      // 000000086708: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x428c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 00000008670C: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 000000086718: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 00000008671C: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000086724: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000086728: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008672C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000086730: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000086738: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000086744: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000086748: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000008674C: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000086750: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000086758: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000086760: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000086764: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000086768: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000008676C: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086770: BF870095
	.long 0xd71c000a                                           // 000000086774: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000086778: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000008677C: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000086780: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086788: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 00000008678C: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000086794: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086798: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 00000008679C: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 0000000867A4: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000867A8: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 0000000867AC: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 0000000867B4: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 0000000867B8: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000867C0: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 0000000867C4: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 0000000867C8: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000867D0: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 0000000867D4: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 0000000867D8: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000867E0: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 0000000867E4: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 0000000867EC: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 0000000867F4: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086800: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 000000086804: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 00000008680C: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 000000086818: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 000000086820: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 000000086824: BE802001
	s_cbranch_execz 57307                                      // 000000086828: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4298>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 00000008682C: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000086838: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000086840: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000086844: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086848: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000008684C: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 000000086854: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 000000086860: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000086864: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 000000086868: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 00000008686C: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000086874: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008687C: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 000000086880: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 000000086884: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 000000086888: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008688C: BF870095
	.long 0xd71c0001                                           // 000000086890: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 000000086894: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000086898: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000008689C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000868A4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 0000000868A8: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000868B4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000868B8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000868BC: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 0000000868C4: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000868C8: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 0000000868CC: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 0000000868D4: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 0000000868D8: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000868E0: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 0000000868E4: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 0000000868E8: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000868F0: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 0000000868F4: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 0000000868F8: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086900: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 000000086904: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000008690C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 000000086914: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086920: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 000000086924: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 00000008692C: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000086938: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000086940: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 000000086944: BE802002
	s_cbranch_execz 57238                                      // 000000086948: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42a4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 00000008694C: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000086958: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000086960: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000086964: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086968: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000008696C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000086974: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 000000086980: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000086984: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 000000086988: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000008698C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000086994: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008699C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000869A0: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 0000000869A4: 7E041109
	v_exp_f32_e32 v1, v1                                       // 0000000869A8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000869AC: BF870095
	.long 0xd71c0001                                           // 0000000869B0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000869B4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000869B8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000869BC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000869C4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 0000000869C8: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000869D4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000869D8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000869DC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000869E4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000869E8: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 0000000869EC: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 0000000869F4: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 0000000869F8: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086A00: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 000000086A04: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 000000086A08: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086A10: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 000000086A14: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 000000086A18: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086A20: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 000000086A24: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000086A2C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 000000086A34: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086A40: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000086A44: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000086A4C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000086A58: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000086A60: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 000000086A64: BE802003
	s_cbranch_execz 57169                                      // 000000086A68: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42b0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 000000086A6C: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000086A78: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000086A80: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000086A84: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086A88: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000086A8C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000086A94: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000086AA0: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000086AA4: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000086AA8: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000086AAC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000086AB4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000086ABC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000086AC0: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000086AC4: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000086AC8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086ACC: BF870095
	.long 0xd71c0001                                           // 000000086AD0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000086AD4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000086AD8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000086ADC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086AE4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 000000086AE8: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000086AF4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086AF8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000086AFC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000086B04: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086B08: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000086B0C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000086B14: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000086B18: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086B20: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 000000086B24: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 000000086B28: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086B30: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 000000086B34: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 000000086B38: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086B40: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 000000086B44: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000086B4C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 000000086B54: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086B60: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000086B64: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000086B6C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000086B78: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000086B80: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000086B84: BE802004
	s_cbranch_execz 57100                                      // 000000086B88: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42bc>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 000000086B8C: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000086B98: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000086BA0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000086BA4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086BA8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000086BAC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000086BB4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000086BC0: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000086BC4: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000086BC8: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000086BCC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000086BD4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000086BDC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000086BE0: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000086BE4: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000086BE8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086BEC: BF870095
	.long 0xd71c0001                                           // 000000086BF0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000086BF4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000086BF8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000086BFC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086C04: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 000000086C08: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 000000086C10: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086C18: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000086C1C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000086C24: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086C28: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000086C2C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000086C34: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000086C38: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086C40: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000086C44: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 000000086C48: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086C50: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 000000086C54: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 000000086C58: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086C60: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000086C64: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000086C6C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 000000086C74: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086C80: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000086C84: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000086C8C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000086C98: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000086CA0: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 000000086CA4: BE802005
	s_cbranch_execz 57031                                      // 000000086CA8: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42c8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 000000086CAC: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000086CB8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000086CC0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000086CC4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086CC8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000086CCC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000086CD4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000086CE0: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000086CE4: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000086CE8: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000086CEC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000086CF4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000086CFC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000086D00: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000086D04: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000086D08: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086D0C: BF870095
	.long 0xd71c0001                                           // 000000086D10: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000086D14: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000086D18: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000086D1C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086D24: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 000000086D28: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000086D34: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086D38: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000086D3C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000086D44: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086D48: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000086D4C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000086D54: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000086D58: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086D60: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000086D64: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 000000086D68: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086D70: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 000000086D74: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 000000086D78: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086D80: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000086D84: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000086D8C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 000000086D94: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086DA0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000086DA4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000086DAC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000086DB8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000086DC0: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000086DC4: BE802006
	s_cbranch_execz 56962                                      // 000000086DC8: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42d4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 000000086DCC: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000086DD8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000086DE0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000086DE4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086DE8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000086DEC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000086DF4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000086E00: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000086E04: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000086E08: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000086E0C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000086E14: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000086E1C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000086E20: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000086E24: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000086E28: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086E2C: BF870095
	.long 0xd71c0001                                           // 000000086E30: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000086E34: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000086E38: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000086E3C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086E44: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 000000086E48: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000086E54: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086E58: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000086E5C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000086E64: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086E68: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000086E6C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000086E74: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000086E78: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086E80: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000086E84: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 000000086E88: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086E90: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 000000086E94: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 000000086E98: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086EA0: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000086EA4: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000086EAC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 000000086EB4: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086EC0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000086EC4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000086ECC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000086ED8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000086EE0: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000086EE4: BE802007
	s_cbranch_execz 56893                                      // 000000086EE8: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi5ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42e0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 000000086EEC: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000086EF8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000086F00: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000086F04: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086F08: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000086F0C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000086F14: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000086F20: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000086F24: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000086F28: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000086F2C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000086F34: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000086F3C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000086F40: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000086F44: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000086F48: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086F4C: BF870095
	.long 0xd71c0001                                           // 000000086F50: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000086F54: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000086F58: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000086F5C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086F64: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 000000086F68: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000086F74: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086F78: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000086F7C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000086F84: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086F88: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000086F8C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000086F94: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000086F98: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086FA0: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000086FA4: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 000000086FA8: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086FB0: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 000000086FB4: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 000000086FB8: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086FC0: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000086FC4: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000086FCC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 000000086FD4: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000086FE0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000086FE4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000086FEC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000086FF8: DC9601E0 007C0200
	s_nop 0                                                    // 000000087000: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000087004: BFB60003
	s_endpgm                                                   // 000000087008: BFB00000
		...

