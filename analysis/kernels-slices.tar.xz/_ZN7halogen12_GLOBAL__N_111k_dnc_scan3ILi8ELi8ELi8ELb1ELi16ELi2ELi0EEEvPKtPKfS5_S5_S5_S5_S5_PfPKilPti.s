00000000000c8300 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000C8300: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000C8304: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000C830C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000C8314: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000C8318: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000C831C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000C8320: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000C8328: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000C832C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000C8330: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000C8334: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000C833C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000C8340: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000C8344: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000C8348: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C834C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000C8350: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000C8354: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000C8358: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000C835C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000C8364: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000C836C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000C8370: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000C8374: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000C8378: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000C837C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000C8380: 821E191E
	.long 0xd7001f02                                           // 0000000C8384: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000C8388: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000C838C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000C8394: BE9E0080
	s_nop 0                                                    // 0000000C8398: BF800000
	s_nop 0                                                    // 0000000C839C: BF800000
	s_nop 0                                                    // 0000000C83A0: BF800000
	s_nop 0                                                    // 0000000C83A4: BF800000
	s_nop 0                                                    // 0000000C83A8: BF800000
	s_nop 0                                                    // 0000000C83AC: BF800000
	s_nop 0                                                    // 0000000C83B0: BF800000
	s_nop 0                                                    // 0000000C83B4: BF800000
	s_nop 0                                                    // 0000000C83B8: BF800000
	s_nop 0                                                    // 0000000C83BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000C83C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000C83C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C83CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000C83D0: 300C1089
	.long 0xd7006a06                                           // 0000000C83D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000C83D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C83DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000C83E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000C83E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000C83F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000C83F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000C83FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000C8408: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000C840C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000C8410: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000C8418: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000C841C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000C8420: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000C8424: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 0000000C842C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000C8434: 32040084
	s_mov_b32 s0, 0                                            // 0000000C8438: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000C843C: BF89FC07
	s_barrier                                                  // 0000000C8440: BFBD0000
	buffer_gl0_inv                                             // 0000000C8444: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000C844C: BF02801E
	s_cbranch_scc1 12                                          // 0000000C8450: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000C8454: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000C845C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C8464: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 0000000C8468: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000C8470: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000C8474: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000C8478: 916A007E
	s_cbranch_vccz 2                                           // 0000000C847C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2200                                              // 0000000C8480: BFA00898 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23e4>
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000C8484: 304E0A82
	s_add_i32 s0, s30, 63                                      // 0000000C8488: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000C848C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000C8494: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000C8498: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000C849C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000C84A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000000C84A4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000000C84AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000C84B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000C84B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000C84B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000C84BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000C84C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000C84C4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000000C84C8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000C84D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000C84D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000C84DC: B00A0204
	.long 0xd7000b2c                                           // 0000000C84E0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 0000000C84E4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000C84E8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 0000000C84EC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 0000000C84F4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000C8500: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 0000000C8504: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 0000000C8510: 3816500A
	.long 0xd7000a05                                           // 0000000C8514: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000C8518: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C851C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000C8520: D5207C06 00290001
	.long 0xd7000107                                           // 0000000C8528: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000C852C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C8530: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000C8534: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000C853C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000C8540: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000C8544: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000C854C: 84848E02
	.long 0xd700010b                                           // 0000000C8550: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000C8554: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000C8558: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000C855C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000C8564: 8205050F
	.long 0xd700010d                                           // 0000000C8568: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000C856C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C8570: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000C8574: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000C857C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000C8580: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000C8588: D5207C10 00061880
	.long 0xd7000111                                           // 0000000C8590: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000C8594: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C859C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000C85A0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000C85A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000C85AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000C85B4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000C85BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000C85C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C85C8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000C85CC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000C85D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000C85D8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000C85E0: D5207C18 00061880
	.long 0xd7000119                                           // 0000000C85E8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000C85EC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C85F4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000C85F8: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000C8600: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000C8604: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 0000000C860C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 0000000C8614: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000C8618: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 0000000C8620: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 0000000C8624: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 0000000C862C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000C8634: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 0000000C863C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 0000000C8644: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 0000000C864C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 0000000C8654: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 0000000C865C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 0000000C8664: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 0000000C866C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 0000000C8674: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 0000000C867C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 0000000C8684: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 0000000C868C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 0000000C8694: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 0000000C869C: BE850080
	s_mov_b32 s6, 0x43800000                                   // 0000000C86A0: BE8600FF 43800000
	s_mov_b32 s7, 0x3b800000                                   // 0000000C86A8: BE8700FF 3B800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000C86B0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000C86B4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000C86BC: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000C86C0: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000C86C4: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C86C8: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000C86CC: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000C86D0: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000C86D4: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000C86D8: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000C86DC: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000C86E4: BE84206A
	s_cbranch_execz 77                                         // 0000000C86E8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x520>
	v_or_b32_e32 v29, s11, v0                                  // 0000000C86EC: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C86F0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000C86F4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000C86FC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8700: BF870091
	.long 0xd73c001d                                           // 0000000C8704: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000C8708: 02023A82
	.long 0xd700011d                                           // 0000000C870C: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000C8710: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000C8714: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000C8718: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000C8720: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C8728: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000C872C: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000C8730: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000C873C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 0000000C8740: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 0000000C874C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000C8750: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000C875C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000C8760: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 0000000C8764: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000C8770: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C8774: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 0000000C8778: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 0000000C8780: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000C8784: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 0000000C878C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000C8794: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 0000000C8798: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C879C: BF870193
	v_exp_f32_e32 v32, v32                                     // 0000000C87A0: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 0000000C87A4: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000C87A8: BF870296
	.long 0xd71c0020                                           // 0000000C87AC: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000C87B0: 02024520
	.long 0xd71c001f                                           // 0000000C87B4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000C87B8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C87BC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000C87C0: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000C87C8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000C87CC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000C87D4: D5010020 00064080
	.long 0xd41e0001                                           // 0000000C87DC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000C87E0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C87E8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000C87EC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000C87F8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000C87FC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000C8804: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 0000000C8810: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 0000000C8818: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C8820: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000C8824: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000C882C: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C8830: BF89FC07
	s_barrier                                                  // 0000000C8834: BFBD0000
	buffer_gl0_inv                                             // 0000000C8838: E0AC0000 00000000
	s_branch 15                                                // 0000000C8840: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C8844: 8C7E047E
	.long 0xd700011d                                           // 0000000C8848: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000C884C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C8854: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C8858: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000C8860: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000C8864: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000C8868: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000C886C: BF89FC07
	s_barrier                                                  // 0000000C8870: BFBD0000
	buffer_gl0_inv                                             // 0000000C8874: E0AC0000 00000000
	s_cbranch_scc1 702                                         // 0000000C887C: BFA202BE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000C8880: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 0000000C8888: CA100128 21220126
	s_mov_b32 s13, 0                                           // 0000000C8890: BE8D0080
	s_nop 0                                                    // 0000000C8894: BF800000
	s_nop 0                                                    // 0000000C8898: BF800000
	s_nop 0                                                    // 0000000C889C: BF800000
	s_nop 0                                                    // 0000000C88A0: BF800000
	s_nop 0                                                    // 0000000C88A4: BF800000
	s_nop 0                                                    // 0000000C88A8: BF800000
	s_nop 0                                                    // 0000000C88AC: BF800000
	s_nop 0                                                    // 0000000C88B0: BF800000
	s_nop 0                                                    // 0000000C88B4: BF800000
	s_nop 0                                                    // 0000000C88B8: BF800000
	s_nop 0                                                    // 0000000C88BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000000C88C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000C88C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000C88D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000C88D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C88DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000C88E0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000C88E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000C88EC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000C88F4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000C88F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000000C88FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000C8904: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000C890C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000C8910: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000C8914: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000C8918: BF89FC07
	s_barrier                                                  // 0000000C891C: BFBD0000
	buffer_gl0_inv                                             // 0000000C8920: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000C8928: BE842000
	s_cbranch_execz 65477                                      // 0000000C892C: BFA5FFC5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 0000000C8930: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 0000000C8938: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 0000000C8940: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 0000000C8948: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000C8950: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 0000000C8958: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 0000000C8960: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 0000000C8968: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v46 offset0:14 offset1:15      // 0000000C8970: D8DC0F0E 4800002E
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 0000000C8978: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 0000000C8980: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 0000000C8988: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 0000000C8990: D8DCFFEE 50000001
	v_or3_b32 v70, s12, s11, v2                                // 0000000C8998: D6580046 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C89A0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 0000000C89A4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 0000000C89AC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 0000000C89B0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C89B4: BF870091
	.long 0xd7000146                                           // 0000000C89B8: D7000146
	v_cndmask_b32_e32 v1, v44, v70, vcc_lo                     // 0000000C89BC: 02028D2C
	v_add_co_ci_u32_e64 v71, null, v45, v71, s1                // 0000000C89C0: D5207C47 00068F2D
	global_load_b32 v70, v[70:71], off                         // 0000000C89C8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 0000000C89D0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 0000000C89D4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000C89DC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 0000000C89E0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 0000000C89E8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 0000000C89EC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 0000000C89F4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:10 offset1:11      // 0000000C89FC: D8DC0B0A 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:12 offset1:13      // 0000000C8A04: D8DC0D0C 4600002E
	v_fma_f32 v33, -v34, v65, v33                              // 0000000C8A0C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 0000000C8A14: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8A18: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 0000000C8A1C: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 0000000C8A24: D6130021 24868724
	s_waitcnt lgkmcnt(8)                                       // 0000000C8A2C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8A30: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 0000000C8A34: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 0000000C8A3C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 0000000C8A44: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8A48: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 0000000C8A4C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 0000000C8A54: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 0000000C8A5C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C8A60: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000C8A64: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 0000000C8A6C: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 0000000C8A74: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 0000000C8A7C: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 0000000C8A84: D8DC1716 3C00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:16 offset1:33      // 0000000C8A8C: D8DC2110 40000030
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000C8A94: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:84 offset1:101     // 0000000C8A9C: D8DC6554 44000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000C8AA4: D8DC8776 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 0000000C8AAC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 0000000C8AB4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8AB8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 0000000C8ABC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 0000000C8AC4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8ACC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 0000000C8AD0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 0000000C8AD8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 0000000C8AE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8AE4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 0000000C8AE8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 0000000C8AF0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 0000000C8AF8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C8AFC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 0000000C8B00: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 0000000C8B08: D8DC1918 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 0000000C8B10: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 0000000C8B18: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000C8B20: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:152 offset1:169    // 0000000C8B28: D8DCA998 48000030
	ds_load_2addr_b32 v[76:77], v48 offset0:186 offset1:203    // 0000000C8B30: D8DCCBBA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:220 offset1:237    // 0000000C8B38: D8DCEDDC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:126 offset1:143    // 0000000C8B40: D8DC8F7E 50000031
	v_fma_f32 v33, -v34, v67, v33                              // 0000000C8B48: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 0000000C8B50: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8B54: BF870091
	v_fma_f32 v33, -v35, v68, v33                              // 0000000C8B58: D6130021 24868923
	v_fma_f32 v33, -v36, v69, v33                              // 0000000C8B60: D6130021 24868B24
	s_waitcnt lgkmcnt(8)                                       // 0000000C8B68: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8B6C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000C8B70: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000C8B78: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000C8B80: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8B84: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 0000000C8B88: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 0000000C8B90: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 0000000C8B98: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C8B9C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000C8BA0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 0000000C8BA8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 0000000C8BB0: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 0000000C8BB8: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 0000000C8BC0: D8DC2726 3C00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 0000000C8BC8: D8DC3120 42000032
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 0000000C8BD0: D8DC5342 44000032
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000C8BD8: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000C8BE0: D8DC9786 4A000032
	v_fma_f32 v62, -v63, v77, v62                              // 0000000C8BE8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000C8BF0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8BF4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000C8BF8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000C8C00: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000C8C08: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8C0C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 0000000C8C10: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 0000000C8C18: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 0000000C8C20: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8C24: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 0000000C8C28: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 0000000C8C30: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 0000000C8C38: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C8C3C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 0000000C8C40: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 0000000C8C48: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 0000000C8C50: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:44 offset1:45      // 0000000C8C58: D8DC2D2C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:46 offset1:47      // 0000000C8C60: D8DC2F2E 4200002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 0000000C8C68: D8DCB9A8 46000032
	ds_load_2addr_b32 v[76:77], v50 offset0:202 offset1:219    // 0000000C8C70: D8DCDBCA 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:236 offset1:253    // 0000000C8C78: D8DCFDEC 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:14 offset1:31      // 0000000C8C80: D8DC1F0E 50000033
	v_fma_f32 v33, -v34, v69, v33                              // 0000000C8C88: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 0000000C8C90: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8C94: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000C8C98: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000C8CA0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000C8CA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8CAC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000C8CB0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000C8CB8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000C8CC0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8CC4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 0000000C8CC8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 0000000C8CD0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 0000000C8CD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C8CDC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000C8CE0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 0000000C8CE8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 0000000C8CF0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 0000000C8CF8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 0000000C8D00: D8DC3736 3C00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:48 offset1:65      // 0000000C8D08: D8DC4130 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:82 offset1:99      // 0000000C8D10: D8DC6352 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000C8D18: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000C8D20: D8DCA796 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 0000000C8D28: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000C8D30: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8D34: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000C8D38: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000C8D40: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000C8D48: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8D4C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000C8D50: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000C8D58: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000C8D60: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8D64: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000C8D68: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000C8D70: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000C8D78: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C8D7C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000C8D80: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 0000000C8D88: D8DC3938 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:58 offset1:59      // 0000000C8D90: D8DC3B3A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:60 offset1:61      // 0000000C8D98: D8DC3D3C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:62 offset1:63      // 0000000C8DA0: D8DC3F3E 4200002E
	ds_load_2addr_b32 v[68:69], v51 offset0:184 offset1:201    // 0000000C8DA8: D8DCC9B8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:218 offset1:235    // 0000000C8DB0: D8DCEBDA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:124 offset1:141    // 0000000C8DB8: D8DC8D7C 4E000034
	ds_load_2addr_b32 v[80:81], v53 offset0:30 offset1:47      // 0000000C8DC0: D8DC2F1E 50000035
	v_fma_f32 v33, -v34, v71, v33                              // 0000000C8DC8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000C8DD0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8DD4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000C8DD8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000C8DE0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000C8DE8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8DEC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000C8DF0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000C8DF8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000C8E00: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8E04: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000C8E08: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000C8E10: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000C8E18: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C8E1C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000C8E20: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 0000000C8E28: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 0000000C8E30: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 0000000C8E38: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 0000000C8E40: D8DC4746 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:64 offset1:81      // 0000000C8E48: D8DC5140 44000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 0000000C8E50: D8DC7362 46000035
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000C8E58: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000C8E60: D8DCB7A6 4A000035
	v_fma_f32 v62, -v63, v77, v62                              // 0000000C8E68: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000C8E70: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8E74: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000C8E78: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000C8E80: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000C8E88: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8E8C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000C8E90: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000C8E98: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000C8EA0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8EA4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000C8EA8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000C8EB0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000C8EB8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C8EBC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000C8EC0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 0000000C8EC8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 0000000C8ED0: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 0000000C8ED8: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:78 offset1:79      // 0000000C8EE0: D8DC4F4E 4200002E
	ds_load_2addr_b32 v[68:69], v53 offset0:200 offset1:217    // 0000000C8EE8: D8DCD9C8 44000035
	ds_load_2addr_b32 v[76:77], v53 offset0:234 offset1:251    // 0000000C8EF0: D8DCFBEA 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:12 offset1:29      // 0000000C8EF8: D8DC1D0C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:46 offset1:63      // 0000000C8F00: D8DC3F2E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 0000000C8F08: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000C8F10: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8F14: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000C8F18: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000C8F20: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000C8F28: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8F2C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000C8F30: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000C8F38: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000C8F40: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8F44: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000C8F48: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000C8F50: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000C8F58: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C8F5C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000C8F60: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 0000000C8F68: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 0000000C8F70: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 0000000C8F78: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 0000000C8F80: D8DC5756 3C00002E
	ds_load_2addr_b32 v[68:69], v54 offset0:80 offset1:97      // 0000000C8F88: D8DC6150 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 0000000C8F90: D8DC8372 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000C8F98: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000C8FA0: D8DCC7B6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 0000000C8FA8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000C8FB0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8FB4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000C8FB8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000C8FC0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000C8FC8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8FCC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000C8FD0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000C8FD8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000C8FE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C8FE4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000C8FE8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000C8FF0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000C8FF8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C8FFC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000C9000: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 0000000C9008: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 0000000C9010: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:92 offset1:93      // 0000000C9018: D8DC5D5C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:94 offset1:95      // 0000000C9020: D8DC5F5E 4200002E
	ds_load_2addr_b32 v[68:69], v54 offset0:216 offset1:233    // 0000000C9028: D8DCE9D8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:122 offset1:139    // 0000000C9030: D8DC8B7A 4C000037
	ds_load_2addr_b32 v[78:79], v56 offset0:28 offset1:45      // 0000000C9038: D8DC2D1C 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:62 offset1:79      // 0000000C9040: D8DC4F3E 50000038
	v_fma_f32 v33, -v34, v71, v33                              // 0000000C9048: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000C9050: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9054: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000C9058: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000C9060: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000C9068: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C906C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000C9070: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000C9078: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000C9080: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9084: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000C9088: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000C9090: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000C9098: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C909C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000C90A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 0000000C90A8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 0000000C90B0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 0000000C90B8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 0000000C90C0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:96 offset1:113     // 0000000C90C8: D8DC7160 44000038
	ds_load_2addr_b32 v[70:71], v56 offset0:130 offset1:147    // 0000000C90D0: D8DC9382 46000038
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000C90D8: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000C90E0: D8DCD7C6 4A000038
	v_fma_f32 v62, -v63, v77, v62                              // 0000000C90E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000C90F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C90F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000C90F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000C9100: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000C9108: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C910C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000C9110: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000C9118: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000C9120: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9124: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000C9128: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000C9130: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000C9138: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C913C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000C9140: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 0000000C9148: D8DC6968 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:106 offset1:107    // 0000000C9150: D8DC6B6A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:108 offset1:109    // 0000000C9158: D8DC6D6C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:110 offset1:111    // 0000000C9160: D8DC6F6E 4200002E
	ds_load_2addr_b32 v[68:69], v56 offset0:232 offset1:249    // 0000000C9168: D8DCF9E8 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:10 offset1:27      // 0000000C9170: D8DC1B0A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:44 offset1:61      // 0000000C9178: D8DC3D2C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:78 offset1:95      // 0000000C9180: D8DC5F4E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 0000000C9188: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000C9190: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9194: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000C9198: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000C91A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000C91A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C91AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000C91B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000C91B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000C91C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C91C4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000C91C8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000C91D0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000C91D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C91DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000C91E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 0000000C91E8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 0000000C91F0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 0000000C91F8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 0000000C9200: D8DC7776 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 0000000C9208: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 0000000C9210: D8DCA392 46000039
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000C9218: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000C9220: D8DCE7D6 4A000039
	v_fma_f32 v62, -v63, v77, v62                              // 0000000C9228: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000C9230: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9234: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000C9238: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000C9240: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000C9248: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C924C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000C9250: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000C9258: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000C9260: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9264: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000C9268: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000C9270: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000C9278: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C927C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000C9280: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 0000000C9288: D8DC7978 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 0000000C9290: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 0000000C9298: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:126 offset1:127    // 0000000C92A0: D8DC7F7E 4200002E
	ds_load_2addr_b32 v[68:69], v58 offset0:120 offset1:137    // 0000000C92A8: D8DC8978 4400003A
	ds_load_2addr_b32 v[76:77], v59 offset0:26 offset1:43      // 0000000C92B0: D8DC2B1A 4C00003B
	ds_load_2addr_b32 v[78:79], v59 offset0:60 offset1:77      // 0000000C92B8: D8DC4D3C 4E00003B
	ds_load_2addr_b32 v[80:81], v59 offset0:94 offset1:111     // 0000000C92C0: D8DC6F5E 5000003B
	v_fma_f32 v33, -v34, v71, v33                              // 0000000C92C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000C92D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C92D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000C92D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000C92E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000C92E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C92EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000C92F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000C92F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000C9300: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9304: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000C9308: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000C9310: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000C9318: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C931C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 0000000C9320: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 0000000C9328: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 0000000C9330: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9334: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 0000000C9338: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 0000000C9340: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 0000000C9348: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C934C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 0000000C9350: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s12, v[4:5]            // 0000000C9358: D6FE7C1F 041018FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 0000000C9364: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 0000000C936C: D8340000 0000201F
	s_branch 64819                                             // 0000000C9374: BFA0FD33 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	v_mov_b32_e32 v30, v14                                     // 0000000C9378: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000C937C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000C9384: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 0000000C9388: 7E46032B
	s_mov_b32 s12, 0                                           // 0000000C938C: BE8C0080
	s_branch 21                                                // 0000000C9390: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000C9394: 8C7E0D7E
	.long 0xd700011f                                           // 0000000C9398: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000C939C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C93A4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000C93A8: D5207C20 00064080
	.long 0xd700011d                                           // 0000000C93B0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000C93B4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 0000000C93BC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C93C0: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000C93C8: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000C93CC: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000C93D0: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000C93D4: BC7C0000
	s_barrier                                                  // 0000000C93D8: BFBD0000
	buffer_gl0_inv                                             // 0000000C93DC: E0AC0000 00000000
	s_cbranch_scc1 198                                         // 0000000C93E4: BFA200C6 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1400>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C93E8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000C93EC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 0000000C93F4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 0000000C93F8: 7E780326
	s_mov_b32 s13, 0                                           // 0000000C93FC: BE8D0080
	global_load_b32 v61, v[33:34], off                         // 0000000C9400: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000000C9408: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000000C9410: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000C9414: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C941C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000C9420: D5207C22 00064480
	.long 0xd4490004                                           // 0000000C9428: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000000C942C: 020278FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000C9434: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000C9438: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 0000000C943C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 0000000C9444: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000C944C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000C9450: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000C9454: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000C9458: BF89FC07
	s_barrier                                                  // 0000000C945C: BFBD0000
	buffer_gl0_inv                                             // 0000000C9460: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000C9468: BE8D2000
	s_cbranch_execz 65481                                      // 0000000C946C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s12, v2                                  // 0000000C9470: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9474: BF870091
	v_or_b32_e32 v36, s11, v33                                 // 0000000C9478: 3848420B
	.long 0xd4440001                                           // 0000000C947C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 0000000C9480: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000C9484: 8B7E017E
	s_cbranch_execz 65474                                      // 0000000C9488: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_mov_b32_e32 v60, 0                                       // 0000000C948C: 7E780280
	s_mov_b32 s1, 0                                            // 0000000C9490: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000C9494: BF870009
	v_lshl_add_u32 v34, s1, 2, v46                             // 0000000C9498: D6460022 04B90401
	s_add_i32 s4, s1, 8                                        // 0000000C94A0: 81048801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000C94A4: B6810078
	ds_load_2addr_b32 v[70:71], v34 offset1:1                  // 0000000C94A8: D8DC0100 46000022
	ds_load_2addr_b32 v[72:73], v34 offset0:2 offset1:3        // 0000000C94B0: D8DC0302 48000022
	ds_load_2addr_b32 v[74:75], v34 offset0:4 offset1:5        // 0000000C94B8: D8DC0504 4A000022
	ds_load_2addr_b32 v[76:77], v34 offset0:6 offset1:7        // 0000000C94C0: D8DC0706 4C000022
	v_mad_u64_u32 v[61:62], null, 0x44, s1, v[1:2]             // 0000000C94C8: D6FE7C3D 040402FF 00000044
	s_mov_b32 s1, s4                                           // 0000000C94D4: BE810004
	ds_load_2addr_b32 v[62:63], v61 offset1:17                 // 0000000C94D8: D8DC1100 3E00003D
	ds_load_2addr_b32 v[64:65], v61 offset0:34 offset1:51      // 0000000C94E0: D8DC3322 4000003D
	ds_load_2addr_b32 v[66:67], v61 offset0:68 offset1:85      // 0000000C94E8: D8DC5544 4200003D
	ds_load_2addr_b32 v[68:69], v61 offset0:102 offset1:119    // 0000000C94F0: D8DC7766 4400003D
	s_waitcnt lgkmcnt(7)                                       // 0000000C94F8: BF89FC77
	v_fma_mixlo_f16 v61, v70, s6, 0                            // 0000000C94FC: CC21003D 02000D46
	s_waitcnt lgkmcnt(6)                                       // 0000000C9504: BF89FC67
	v_fma_mixlo_f16 v70, v72, s6, 0                            // 0000000C9508: CC210046 02000D48
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C9510: BF870002
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C9514: CC20003D 8A000F3D
	s_waitcnt lgkmcnt(3)                                       // 0000000C951C: BF89FC37
	v_fma_mixlo_f16 v34, v62, s6, 0                            // 0000000C9520: CC210022 02000D3E
	v_fma_mixlo_f16 v62, v63, s6, 0                            // 0000000C9528: CC21003E 02000D3F
	v_fma_mixlo_f16 v63, v71, s6, 0                            // 0000000C9530: CC21003F 02000D47
	s_waitcnt lgkmcnt(2)                                       // 0000000C9538: BF89FC27
	v_fma_mixlo_f16 v64, v64, s6, 0                            // 0000000C953C: CC210040 02000D40
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C9544: CC200022 8A000F22
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C954C: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C9554: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000C955C: BF870214
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C9560: CC200040 8A000F40
	v_fmac_f32_e32 v60, v61, v34                               // 0000000C9568: 5678453D
	v_fma_mixlo_f16 v34, v65, s6, 0                            // 0000000C956C: CC210022 02000D41
	v_fma_mixlo_f16 v61, v73, s6, 0                            // 0000000C9574: CC21003D 02000D49
	v_fma_mix_f32 v65, v70, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C957C: CC200041 8A000F46
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C9584: BF870004
	v_fmac_f32_e32 v60, v63, v62                               // 0000000C9588: 56787D3F
	s_waitcnt lgkmcnt(1)                                       // 0000000C958C: BF89FC17
	v_fma_mixlo_f16 v62, v66, s6, 0                            // 0000000C9590: CC21003E 02000D42
	v_fma_mixlo_f16 v63, v74, s6, 0                            // 0000000C9598: CC21003F 02000D4A
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C95A0: CC200022 8A000F22
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C95A8: CC20003D 8A000F3D
	v_fmac_f32_e32 v60, v65, v64                               // 0000000C95B0: 56788141
	v_fma_mixlo_f16 v64, v67, s6, 0                            // 0000000C95B4: CC210040 02000D43
	v_fma_mixlo_f16 v65, v75, s6, 0                            // 0000000C95BC: CC210041 02000D4B
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C95C4: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C95CC: CC20003F 8A000F3F
	v_fmac_f32_e32 v60, v61, v34                               // 0000000C95D4: 5678453D
	s_waitcnt lgkmcnt(0)                                       // 0000000C95D8: BF89FC07
	v_fma_mixlo_f16 v34, v68, s6, 0                            // 0000000C95DC: CC210022 02000D44
	v_fma_mixlo_f16 v61, v76, s6, 0                            // 0000000C95E4: CC21003D 02000D4C
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C95EC: CC200040 8A000F40
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C95F4: CC200041 8A000F41
	v_fmac_f32_e32 v60, v63, v62                               // 0000000C95FC: 56787D3F
	v_fma_mixlo_f16 v62, v69, s6, 0                            // 0000000C9600: CC21003E 02000D45
	v_fma_mixlo_f16 v63, v77, s6, 0                            // 0000000C9608: CC21003F 02000D4D
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C9610: CC200022 8A000F22
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C9618: CC20003D 8A000F3D
	v_fmac_f32_e32 v60, v65, v64                               // 0000000C9620: 56788141
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C9624: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000C962C: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9634: BF870093
	v_fmac_f32_e32 v60, v61, v34                               // 0000000C9638: 5678453D
	v_fmac_f32_e32 v60, v63, v62                               // 0000000C963C: 56787D3F
	s_cbranch_scc1 65428                                       // 0000000C9640: BFA2FF94 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1194>
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000000C9644: 30424282
	v_mov_b32_e32 v61, v1                                      // 0000000C9648: 7E7A0301
	s_mov_b32 s14, 0                                           // 0000000C964C: BE8E0080
	ds_load_b32 v62, v33 offset:17440                          // 0000000C9650: D8D84420 3E000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000C9658: CA10011E 2220011D
	s_waitcnt lgkmcnt(0)                                       // 0000000C9660: BF89FC07
	v_mul_f32_e32 v60, v60, v62                                // 0000000C9664: 10787D3C
	v_mov_b32_e32 v62, v35                                     // 0000000C9668: 7E7C0323
	s_nop 0                                                    // 0000000C966C: BF800000
	s_nop 0                                                    // 0000000C9670: BF800000
	s_nop 0                                                    // 0000000C9674: BF800000
	s_nop 0                                                    // 0000000C9678: BF800000
	s_nop 0                                                    // 0000000C967C: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000C9680: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000C9688: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000C9690: 4A7C7CC1
	.long 0xd7000121                                           // 0000000C9694: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000C9698: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000C969C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000C96A0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000C96A8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000C96AC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000C96B0: 4A7A7AFF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000C96B8: 8C0E0E04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C96BC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 0000000C96C0: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000C96C4: 917E0E7E
	s_cbranch_execnz 65517                                     // 0000000C96C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1380>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000C96CC: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C96D0: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 0000000C96D4: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 0000000C96DC: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 0000000C96E8: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 0000000C96F4: DC960000 007C2421
	s_branch 65317                                             // 0000000C96FC: BFA0FF25 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000C9700: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 0000000C9708: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000C970C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000C9710: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000C9718: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000C971C: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000C9724: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000C972C: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000C9730: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000C9734: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000C973C: A0010401
	s_mov_b32 s4, 0                                            // 0000000C9740: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000C9744: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000C9748: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000C974C: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000C9750: BF870585
	.long 0xd71c001d                                           // 0000000C9754: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000C9758: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000C975C: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000C9760: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000C9768: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000C976C: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000C9774: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000000C9778: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000C977C: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000C9788: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000C9790: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000C9798: BF870001
	.long 0xd4490001                                           // 0000000C979C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000C97A0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000C97A8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000C97AC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000C97B0: 1040411E
	ds_store_b32 v29, v32                                      // 0000000C97B4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000C97BC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C97C4: 917E047E
	s_cbranch_execnz 65519                                     // 0000000C97C8: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1488>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C97CC: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000C97D0: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 0000000C97D8: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 0000000C97E0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000C97E4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C97E8: BF89FC07
	s_barrier                                                  // 0000000C97EC: BFBD0000
	buffer_gl0_inv                                             // 0000000C97F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000C97F8: BF800000
	s_nop 0                                                    // 0000000C97FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000C9800: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 0000000C9808: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000C9810: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000C9818: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000C981C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000C9824: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C9828: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C9830: BF870004
	.long 0xd4490004                                           // 0000000C9834: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000C9838: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000C9840: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C9844: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000C9848: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 0000000C984C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000C9854: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000C985C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000C9860: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1500>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000C9864: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000C9868: BF89FC07
	s_barrier                                                  // 0000000C986C: BFBD0000
	buffer_gl0_inv                                             // 0000000C9870: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000000C9878: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 0000000C9880: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 0000000C9888: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 0000000C9890: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000C9898: 7E780300
	s_mov_b32 s4, 0                                            // 0000000C989C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000C98A0: BF840001
	s_nop 0                                                    // 0000000C98A4: BF800000
	s_nop 0                                                    // 0000000C98A8: BF800000
	s_nop 0                                                    // 0000000C98AC: BF800000
	s_nop 0                                                    // 0000000C98B0: BF800000
	s_nop 0                                                    // 0000000C98B4: BF800000
	s_nop 0                                                    // 0000000C98B8: BF800000
	s_nop 0                                                    // 0000000C98BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C98C0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000C98C4: 327A7884
	.long 0xd4490001                                           // 0000000C98C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000C98CC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000C98D4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000C98D8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000C98E4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000C98E8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000C98F0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000C98F8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000C9900: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000C9908: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000C9910: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000C9918: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000C9920: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000C9924: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000C9930: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000C9934: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000C9938: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000C9940: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000C9944: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000C9948: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000C994C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9950: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000C9954: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000C9958: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000C995C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9960: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000C9964: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000C9970: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000C9978: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C9980: 917E047E
	s_cbranch_execnz 65486                                     // 0000000C9984: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000C9988: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C998C: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 0000000C9990: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000C9998: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000C99A0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000C99A4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C99A8: BF89FC07
	s_barrier                                                  // 0000000C99AC: BFBD0000
	buffer_gl0_inv                                             // 0000000C99B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000C99B8: BF800000
	s_nop 0                                                    // 0000000C99BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000C99C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 0000000C99C8: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000C99D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000C99D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000C99DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000C99E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C99E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C99F0: BF870004
	.long 0xd4490004                                           // 0000000C99F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000C99F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000C9A00: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C9A04: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000C9A08: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000C9A0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000C9A14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000C9A1C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000C9A20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x16c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000C9A24: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000C9A28: BF89FC07
	s_barrier                                                  // 0000000C9A2C: BFBD0000
	buffer_gl0_inv                                             // 0000000C9A30: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000000C9A38: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 0000000C9A40: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 0000000C9A48: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 0000000C9A50: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000C9A58: 7E780300
	s_mov_b32 s4, 0                                            // 0000000C9A5C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000C9A60: BF840001
	s_nop 0                                                    // 0000000C9A64: BF800000
	s_nop 0                                                    // 0000000C9A68: BF800000
	s_nop 0                                                    // 0000000C9A6C: BF800000
	s_nop 0                                                    // 0000000C9A70: BF800000
	s_nop 0                                                    // 0000000C9A74: BF800000
	s_nop 0                                                    // 0000000C9A78: BF800000
	s_nop 0                                                    // 0000000C9A7C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C9A80: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000C9A84: 327A7884
	.long 0xd4490001                                           // 0000000C9A88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000C9A8C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000C9A94: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000C9A98: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000C9AA4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000C9AA8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000C9AB0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000C9AB8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000C9AC0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000C9AC8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000C9AD0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000C9AD8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000C9AE0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000C9AE4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000C9AF0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000C9AF4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000C9AF8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000C9B00: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000C9B04: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000C9B08: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000C9B0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9B10: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000C9B14: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000C9B18: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000C9B1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9B20: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000C9B24: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000C9B30: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000C9B38: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C9B40: 917E047E
	s_cbranch_execnz 65486                                     // 0000000C9B44: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1780>
	s_set_inst_prefetch_distance 0x2                           // 0000000C9B48: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C9B4C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 0000000C9B50: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000C9B58: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000C9B60: 7E420326
	s_mov_b32 s10, 0                                           // 0000000C9B64: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C9B68: BF89FC07
	s_barrier                                                  // 0000000C9B6C: BFBD0000
	buffer_gl0_inv                                             // 0000000C9B70: E0AC0000 00000000
	s_nop 0                                                    // 0000000C9B78: BF800000
	s_nop 0                                                    // 0000000C9B7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000C9B80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 0000000C9B88: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000C9B90: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000C9B98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000C9B9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000C9BA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C9BA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C9BB0: BF870004
	.long 0xd4490004                                           // 0000000C9BB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000C9BB8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000C9BC0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C9BC4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000C9BC8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000C9BCC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000C9BD4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000C9BDC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000C9BE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1880>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000C9BE4: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 0000000C9BE8: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000C9BF0: BF89FC07
	s_barrier                                                  // 0000000C9BF4: BFBD0000
	buffer_gl0_inv                                             // 0000000C9BF8: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000C9C00: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 0000000C9C04: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 0000000C9C0C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 0000000C9C14: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 0000000C9C1C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000000C9C24: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000C9C28: BF840001
	s_nop 0                                                    // 0000000C9C2C: BF800000
	s_nop 0                                                    // 0000000C9C30: BF800000
	s_nop 0                                                    // 0000000C9C34: BF800000
	s_nop 0                                                    // 0000000C9C38: BF800000
	s_nop 0                                                    // 0000000C9C3C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000C9C40: 327C7A84
	.long 0xd4490001                                           // 0000000C9C44: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000C9C48: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C9C50: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000C9C54: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000C9C58: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000C9C64: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000C9C68: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000C9C70: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000C9C78: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000C9C80: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000C9C88: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000C9C90: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000C9C98: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000C9CA0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000C9CA4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000C9CA8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000C9CAC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000C9CB8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000C9CC0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000C9CC4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000C9CC8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000C9CCC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9CD0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000C9CD4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000C9CD8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000C9CDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9CE0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000C9CE4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000C9CF0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000C9CF8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C9D00: 917E047E
	s_cbranch_execnz 65486                                     // 0000000C9D04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1940>
	s_set_inst_prefetch_distance 0x2                           // 0000000C9D08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C9D0C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 0000000C9D10: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000C9D18: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000C9D20: 7E420326
	s_mov_b32 s10, 0                                           // 0000000C9D24: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C9D28: BF89FC07
	s_barrier                                                  // 0000000C9D2C: BFBD0000
	buffer_gl0_inv                                             // 0000000C9D30: E0AC0000 00000000
	s_nop 0                                                    // 0000000C9D38: BF800000
	s_nop 0                                                    // 0000000C9D3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000C9D40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 0000000C9D48: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000C9D50: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000C9D58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000C9D5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000C9D64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C9D68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C9D70: BF870004
	.long 0xd4490004                                           // 0000000C9D74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000C9D78: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000C9D80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C9D84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000C9D88: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000C9D8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000C9D94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000C9D9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000C9DA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a40>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000C9DA4: 8C7E0A7E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000000C9DA8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000C9DB0: BF89FC07
	s_barrier                                                  // 0000000C9DB4: BFBD0000
	buffer_gl0_inv                                             // 0000000C9DB8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 0000000C9DC0: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 0000000C9DC8: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 0000000C9DD0: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 0000000C9DD8: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000C9DE0: 7E780300
	s_mov_b32 s4, 0                                            // 0000000C9DE4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000C9DE8: BF840001
	s_nop 0                                                    // 0000000C9DEC: BF800000
	s_nop 0                                                    // 0000000C9DF0: BF800000
	s_nop 0                                                    // 0000000C9DF4: BF800000
	s_nop 0                                                    // 0000000C9DF8: BF800000
	s_nop 0                                                    // 0000000C9DFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000C9E00: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000C9E04: 327A7884
	.long 0xd4490001                                           // 0000000C9E08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000C9E0C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000C9E14: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000C9E18: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000C9E24: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000C9E28: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000C9E30: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000C9E38: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000C9E40: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000C9E48: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000C9E50: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000C9E58: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000C9E60: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000C9E64: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000C9E70: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000C9E74: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000C9E78: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000C9E80: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000C9E84: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000C9E88: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000C9E8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9E90: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000C9E94: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000C9E98: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000C9E9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000C9EA0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000C9EA4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000C9EB0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000C9EB8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000C9EC0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000C9EC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b00>
	s_set_inst_prefetch_distance 0x2                           // 0000000C9EC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000C9ECC: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 0000000C9ED0: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000C9ED8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000C9EE0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000C9EE4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000C9EE8: BF89FC07
	s_barrier                                                  // 0000000C9EEC: BFBD0000
	buffer_gl0_inv                                             // 0000000C9EF0: E0AC0000 00000000
	s_nop 0                                                    // 0000000C9EF8: BF800000
	s_nop 0                                                    // 0000000C9EFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000C9F00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 0000000C9F08: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000C9F10: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000C9F18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000C9F1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000C9F24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000C9F28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000C9F30: BF870004
	.long 0xd4490004                                           // 0000000C9F34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000C9F38: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000C9F40: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000C9F44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000C9F48: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000C9F4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000C9F54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000C9F5C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000C9F60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000C9F64: 8C7E0A7E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 0000000C9F68: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000000C9F70: BF89FC07
	s_barrier                                                  // 0000000C9F74: BFBD0000
	buffer_gl0_inv                                             // 0000000C9F78: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 0000000C9F80: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 0000000C9F84: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 0000000C9F8C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 0000000C9F94: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 0000000C9F9C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000000C9FA4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000C9FA8: BF840001
	s_nop 0                                                    // 0000000C9FAC: BF800000
	s_nop 0                                                    // 0000000C9FB0: BF800000
	s_nop 0                                                    // 0000000C9FB4: BF800000
	s_nop 0                                                    // 0000000C9FB8: BF800000
	s_nop 0                                                    // 0000000C9FBC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 0000000C9FC0: 327C7884
	.long 0xd4490001                                           // 0000000C9FC4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000C9FC8: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000C9FD0: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000C9FD4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000C9FD8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000C9FE4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000C9FE8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000C9FF0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000C9FF8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000CA000: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000CA008: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000CA010: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000CA018: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000CA020: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000CA024: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000CA028: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000CA02C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000CA038: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000CA040: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000CA044: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000CA048: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000CA04C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA050: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000CA054: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000CA058: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000CA05C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA060: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000000CA064: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 0000000CA070: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000CA074: BF870002
	v_mov_b32_e32 v60, v63                                     // 0000000CA078: 7E78033F
	ds_store_b32 v62, v70                                      // 0000000CA07C: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CA084: 917E047E
	s_cbranch_execnz 65485                                     // 0000000CA088: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	s_set_inst_prefetch_distance 0x2                           // 0000000CA08C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CA090: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 0000000CA094: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000CA09C: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000CA0A4: 7E420326
	s_mov_b32 s10, 0                                           // 0000000CA0A8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CA0AC: BF89FC07
	s_barrier                                                  // 0000000CA0B0: BFBD0000
	buffer_gl0_inv                                             // 0000000CA0B4: E0AC0000 00000000
	s_nop 0                                                    // 0000000CA0BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000CA0C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 0000000CA0C8: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000CA0D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000CA0D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CA0DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000CA0E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CA0E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CA0F0: BF870004
	.long 0xd4490004                                           // 0000000CA0F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000CA0F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CA100: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CA104: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000CA108: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000CA10C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000CA114: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CA11C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CA120: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dc0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CA124: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 0000000CA128: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000CA130: BF89FC07
	s_barrier                                                  // 0000000CA134: BFBD0000
	buffer_gl0_inv                                             // 0000000CA138: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 0000000CA140: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 0000000CA148: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 0000000CA150: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 0000000CA158: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000CA160: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000CA164: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000CA168: BF840001
	s_nop 0                                                    // 0000000CA16C: BF800000
	s_nop 0                                                    // 0000000CA170: BF800000
	s_nop 0                                                    // 0000000CA174: BF800000
	s_nop 0                                                    // 0000000CA178: BF800000
	s_nop 0                                                    // 0000000CA17C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CA180: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000CA184: 327C7A84
	.long 0xd4490001                                           // 0000000CA188: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000CA18C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000CA194: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000CA198: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CA1A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000CA1A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000CA1B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000CA1B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000CA1C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000CA1C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000CA1D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000CA1D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000CA1E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000CA1E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000CA1E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000CA1EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000CA1F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000CA200: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000CA204: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000CA208: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000CA20C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA210: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000CA214: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000CA218: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000CA21C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA220: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000CA224: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000CA230: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000CA238: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CA240: 917E047E
	s_cbranch_execnz 65486                                     // 0000000CA244: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e80>
	s_set_inst_prefetch_distance 0x2                           // 0000000CA248: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CA24C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 0000000CA250: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000CA258: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000CA260: 7E420326
	s_mov_b32 s10, 0                                           // 0000000CA264: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CA268: BF89FC07
	s_barrier                                                  // 0000000CA26C: BFBD0000
	buffer_gl0_inv                                             // 0000000CA270: E0AC0000 00000000
	s_nop 0                                                    // 0000000CA278: BF800000
	s_nop 0                                                    // 0000000CA27C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000CA280: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 0000000CA288: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000CA290: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000CA298: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CA29C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000CA2A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CA2A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CA2B0: BF870004
	.long 0xd4490004                                           // 0000000CA2B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000CA2B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CA2C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CA2C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000CA2C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000CA2CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000CA2D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CA2DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CA2E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CA2E4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000CA2E8: BF89FC07
	s_barrier                                                  // 0000000CA2EC: BFBD0000
	buffer_gl0_inv                                             // 0000000CA2F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 0000000CA2F8: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 0000000CA300: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 0000000CA308: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 0000000CA310: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000CA318: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000CA31C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000CA320: BF840001
	s_nop 0                                                    // 0000000CA324: BF800000
	s_nop 0                                                    // 0000000CA328: BF800000
	s_nop 0                                                    // 0000000CA32C: BF800000
	s_nop 0                                                    // 0000000CA330: BF800000
	s_nop 0                                                    // 0000000CA334: BF800000
	s_nop 0                                                    // 0000000CA338: BF800000
	s_nop 0                                                    // 0000000CA33C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CA340: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000CA344: 327C7A84
	.long 0xd4490001                                           // 0000000CA348: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000CA34C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000CA354: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000CA358: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CA364: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000CA368: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000CA370: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000CA378: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000CA380: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000CA388: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000CA390: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000CA398: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000CA3A0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000CA3A4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000CA3A8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000CA3AC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000CA3B8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000CA3C0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000CA3C4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000CA3C8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000CA3CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA3D0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000CA3D4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000CA3D8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000CA3DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA3E0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000CA3E4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000CA3F0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000CA3F8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CA400: 917E047E
	s_cbranch_execnz 65486                                     // 0000000CA404: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_set_inst_prefetch_distance 0x2                           // 0000000CA408: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CA40C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000CA410: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000CA418: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000CA420: 7E420326
	s_mov_b32 s10, 0                                           // 0000000CA424: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000CA428: BF89FC07
	s_barrier                                                  // 0000000CA42C: BFBD0000
	buffer_gl0_inv                                             // 0000000CA430: E0AC0000 00000000
	s_nop 0                                                    // 0000000CA438: BF800000
	s_nop 0                                                    // 0000000CA43C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000CA440: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 0000000CA448: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000CA450: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000CA458: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000CA45C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000CA464: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000CA468: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000CA470: BF870004
	.long 0xd4490004                                           // 0000000CA474: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000CA478: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000CA480: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000CA484: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000CA488: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000CA48C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000CA494: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000CA49C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000CA4A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2140>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000CA4A4: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 0000000CA4A8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 0000000CA4B0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000CA4B8: BF89FC07
	s_barrier                                                  // 0000000CA4BC: BFBD0000
	buffer_gl0_inv                                             // 0000000CA4C0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 0000000CA4C8: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 0000000CA4D0: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000CA4D8: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 0000000CA4E0: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000CA4E8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000CA4EC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000CA4F0: BF840001
	s_nop 0                                                    // 0000000CA4F4: BF800000
	s_nop 0                                                    // 0000000CA4F8: BF800000
	s_nop 0                                                    // 0000000CA4FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000CA500: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000CA504: 327A7884
	.long 0xd4490001                                           // 0000000CA508: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000CA50C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000CA514: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000CA518: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000CA524: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000CA528: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000CA530: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000CA538: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000CA540: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000CA548: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000CA550: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000CA558: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000CA560: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000CA564: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000CA570: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000CA574: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000CA578: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000CA580: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000CA584: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000CA588: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000CA58C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA590: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000CA594: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000CA598: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000CA59C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA5A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000CA5A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000CA5B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000CA5B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000CA5C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000CA5C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2200>
	s_set_inst_prefetch_distance 0x2                           // 0000000CA5C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000CA5CC: 8C7E047E
	.long 0xd7000107                                           // 0000000CA5D0: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000CA5D4: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CA5DC: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000CA5E0: D5207C08 00061080
	.long 0xd7000109                                           // 0000000CA5E8: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000CA5EC: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000CA5F4: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000CA5FC: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000CA600: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CA608: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000CA60C: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000CA614: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000CA618: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000CA620: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000CA628: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000CA62C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CA634: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000CA638: D5207C10 00062080
	.long 0xd7000111                                           // 0000000CA640: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000CA644: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000CA64C: D5207C12 00062480
	.long 0xd7000113                                           // 0000000CA654: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000CA658: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CA660: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000CA664: D5207C14 00062880
	.long 0xd7000115                                           // 0000000CA66C: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000CA670: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000CA678: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000CA680: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000CA684: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000CA68C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000CA690: D5207C18 00063080
	.long 0xd7000119                                           // 0000000CA698: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000CA69C: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000CA6A4: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000CA6AC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000CA6B0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000CA6B8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000CA6BC: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000CA6C4: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000CA6C8: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000CA6CC: BF062105
	s_barrier                                                  // 0000000CA6D0: BFBD0000
	buffer_gl0_inv                                             // 0000000CA6D4: E0AC0000 00000000
	s_cbranch_scc0 63477                                       // 0000000CA6DC: BFA1F7F5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b4>
	v_mov_b32_e32 v4, v38                                      // 0000000CA6E0: 7E080326
	s_add_u32 s0, s28, s20                                     // 0000000CA6E4: 8000141C
	.long 0xd73c0000                                           // 0000000CA6E8: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000CA6EC: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000CA6F0: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000CA6F4: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000CA6F8: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000CA6FC: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000CA700: 82010103
	.long 0xd7006a00                                           // 0000000CA704: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000CA708: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000CA70C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000CA710: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000CA718: BE810080
	.long 0xd7006a00                                           // 0000000CA71C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 0000000CA720: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000CA724: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000CA72C: BF870092
	.long 0xd7006a00                                           // 0000000CA730: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000CA734: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000CA738: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 0000000CA740: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000CA748: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 0000000CA750: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000CA758: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000CA75C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000CA764: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000CA768: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000CA76C: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000CA774: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000CA778: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000CA780: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000CA788: 917E017E
	s_cbranch_execnz 65516                                     // 0000000CA78C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi16ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2440>
	s_endpgm                                                   // 0000000CA790: BFB00000
		...

