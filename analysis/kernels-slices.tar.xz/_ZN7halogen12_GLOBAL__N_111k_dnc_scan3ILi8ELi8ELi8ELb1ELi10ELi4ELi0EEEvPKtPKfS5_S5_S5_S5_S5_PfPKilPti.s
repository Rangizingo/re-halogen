00000000000a4100 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000A4100: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000A4104: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000A410C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000A4114: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000A4118: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000A411C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000A4120: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000A4128: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000A412C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000A4130: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000A4134: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000A413C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000A4140: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000A4144: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000A4148: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A414C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000A4150: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000A4154: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000A4158: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000A415C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000A4164: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000A416C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000A4170: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000A4174: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000A4178: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000A417C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000A4180: 821E191E
	.long 0xd7001f02                                           // 0000000A4184: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000A4188: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000A418C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000A4194: BE9E0080
	s_nop 0                                                    // 0000000A4198: BF800000
	s_nop 0                                                    // 0000000A419C: BF800000
	s_nop 0                                                    // 0000000A41A0: BF800000
	s_nop 0                                                    // 0000000A41A4: BF800000
	s_nop 0                                                    // 0000000A41A8: BF800000
	s_nop 0                                                    // 0000000A41AC: BF800000
	s_nop 0                                                    // 0000000A41B0: BF800000
	s_nop 0                                                    // 0000000A41B4: BF800000
	s_nop 0                                                    // 0000000A41B8: BF800000
	s_nop 0                                                    // 0000000A41BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000A41C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000A41C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A41CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000A41D0: 300C1089
	.long 0xd7006a06                                           // 0000000A41D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000A41D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A41DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000A41E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000A41E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000A41F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000A41F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000A41FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000A4208: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000A420C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000A4210: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000A4218: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000A421C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000A4220: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000A4224: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 0000000A422C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000A4234: 32040084
	s_mov_b32 s0, 0                                            // 0000000A4238: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000A423C: BF89FC07
	s_barrier                                                  // 0000000A4240: BFBD0000
	buffer_gl0_inv                                             // 0000000A4244: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000A424C: BF02801E
	s_cbranch_scc1 12                                          // 0000000A4250: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000A4254: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000A425C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A4264: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 0000000A4268: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000A4270: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000A4274: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000A4278: 916A007E
	s_cbranch_vccz 2                                           // 0000000A427C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2616                                              // 0000000A4280: BFA00A38 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a64>
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000A4284: 304E0A82
	s_add_i32 s0, s30, 63                                      // 0000000A4288: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000A428C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000A4294: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000A4298: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000A429C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000A42A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000000A42A4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000000A42AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000A42B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000A42B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000A42B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000A42BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000A42C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000A42C4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000000A42C8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000A42D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000A42D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000A42DC: B00A0204
	.long 0xd7000b2c                                           // 0000000A42E0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 0000000A42E4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000A42E8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 0000000A42EC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 0000000A42F4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000A4300: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 0000000A4304: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 0000000A4310: 3816500A
	.long 0xd7000a05                                           // 0000000A4314: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000A4318: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000A431C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000A4320: D5207C06 00290001
	.long 0xd7000107                                           // 0000000A4328: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000A432C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A4330: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000A4334: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000A433C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000A4340: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000A4344: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000A434C: 84848E02
	.long 0xd700010b                                           // 0000000A4350: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000A4354: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000A4358: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000A435C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000A4364: 8205050F
	.long 0xd700010d                                           // 0000000A4368: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000A436C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A4370: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000A4374: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000A437C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000A4380: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000A4388: D5207C10 00061880
	.long 0xd7000111                                           // 0000000A4390: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000A4394: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A439C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000A43A0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000A43A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000A43AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000A43B4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000A43BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000A43C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A43C8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000A43CC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000A43D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000A43D8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000A43E0: D5207C18 00061880
	.long 0xd7000119                                           // 0000000A43E8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000A43EC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A43F4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000A43F8: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000A4400: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000A4404: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 0000000A440C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 0000000A4414: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000A4418: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 0000000A4420: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 0000000A4424: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 0000000A442C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000A4434: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 0000000A443C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 0000000A4444: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 0000000A444C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 0000000A4454: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 0000000A445C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 0000000A4464: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 0000000A446C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 0000000A4474: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 0000000A447C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 0000000A4484: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 0000000A448C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 0000000A4494: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 0000000A449C: BE850080
	s_mov_b32 s6, 4.0                                          // 0000000A44A0: BE8600F6
	s_mov_b32 s7, 0x3e800000                                   // 0000000A44A4: BE8700FF 3E800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000A44AC: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000A44B0: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000A44B8: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000A44BC: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000A44C0: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A44C4: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000A44C8: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000A44CC: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000A44D0: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000A44D4: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000A44D8: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000A44E0: BE84206A
	s_cbranch_execz 77                                         // 0000000A44E4: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51c>
	v_or_b32_e32 v29, s11, v0                                  // 0000000A44E8: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A44EC: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000A44F0: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000A44F8: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A44FC: BF870091
	.long 0xd73c001d                                           // 0000000A4500: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000A4504: 02023A82
	.long 0xd700011d                                           // 0000000A4508: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000A450C: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A4510: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000A4514: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000A451C: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A4524: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000A4528: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000A452C: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000A4538: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 0000000A453C: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 0000000A4548: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000A454C: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000A4558: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A455C: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 0000000A4560: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000A456C: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A4570: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 0000000A4574: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 0000000A457C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000A4580: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 0000000A4588: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000A4590: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 0000000A4594: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000A4598: BF870193
	v_exp_f32_e32 v32, v32                                     // 0000000A459C: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 0000000A45A0: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A45A4: BF870296
	.long 0xd71c0020                                           // 0000000A45A8: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000A45AC: 02024520
	.long 0xd71c001f                                           // 0000000A45B0: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000A45B4: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A45B8: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000A45BC: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000A45C4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000A45C8: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000A45D0: D5010020 00064080
	.long 0xd41e0001                                           // 0000000A45D8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000A45DC: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A45E4: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000A45E8: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000A45F4: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000A45F8: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000A4600: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 0000000A460C: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 0000000A4614: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A461C: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000A4620: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000A4628: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A462C: BF89FC07
	s_barrier                                                  // 0000000A4630: BFBD0000
	buffer_gl0_inv                                             // 0000000A4634: E0AC0000 00000000
	s_branch 15                                                // 0000000A463C: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x57c>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A4640: 8C7E047E
	.long 0xd700011d                                           // 0000000A4644: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000A4648: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A4650: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A4654: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000A465C: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000A4660: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000A4664: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000A4668: BF89FC07
	s_barrier                                                  // 0000000A466C: BFBD0000
	buffer_gl0_inv                                             // 0000000A4670: E0AC0000 00000000
	s_cbranch_scc1 703                                         // 0000000A4678: BFA202BF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000A467C: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 0000000A4684: CA100128 21220126
	s_mov_b32 s13, 0                                           // 0000000A468C: BE8D0080
	s_nop 0                                                    // 0000000A4690: BF800000
	s_nop 0                                                    // 0000000A4694: BF800000
	s_nop 0                                                    // 0000000A4698: BF800000
	s_nop 0                                                    // 0000000A469C: BF800000
	s_nop 0                                                    // 0000000A46A0: BF800000
	s_nop 0                                                    // 0000000A46A4: BF800000
	s_nop 0                                                    // 0000000A46A8: BF800000
	s_nop 0                                                    // 0000000A46AC: BF800000
	s_nop 0                                                    // 0000000A46B0: BF800000
	s_nop 0                                                    // 0000000A46B4: BF800000
	s_nop 0                                                    // 0000000A46B8: BF800000
	s_nop 0                                                    // 0000000A46BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000000A46C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000A46C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000A46D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000A46D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000A46DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000A46E0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000A46E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000A46EC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000A46F4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000A46F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000000A46FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000A4704: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000A470C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000A4710: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000A4714: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000A4718: BF89FC07
	s_barrier                                                  // 0000000A471C: BFBD0000
	buffer_gl0_inv                                             // 0000000A4720: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000A4728: BE842000
	s_cbranch_execz 65476                                      // 0000000A472C: BFA5FFC4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x540>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 0000000A4730: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 0000000A4738: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 0000000A4740: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 0000000A4748: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000A4750: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 0000000A4758: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 0000000A4760: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 0000000A4768: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v46 offset0:14 offset1:15      // 0000000A4770: D8DC0F0E 4800002E
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 0000000A4778: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 0000000A4780: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 0000000A4788: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 0000000A4790: D8DCFFEE 50000001
	v_or3_b32 v70, s12, s11, v2                                // 0000000A4798: D6580046 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A47A0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 0000000A47A4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 0000000A47AC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 0000000A47B0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A47B4: BF870091
	.long 0xd7000146                                           // 0000000A47B8: D7000146
	v_cndmask_b32_e32 v1, v44, v70, vcc_lo                     // 0000000A47BC: 02028D2C
	v_add_co_ci_u32_e64 v71, null, v45, v71, s1                // 0000000A47C0: D5207C47 00068F2D
	global_load_b32 v70, v[70:71], off                         // 0000000A47C8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 0000000A47D0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 0000000A47D4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A47DC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 0000000A47E0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 0000000A47E8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 0000000A47EC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 0000000A47F4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:10 offset1:11      // 0000000A47FC: D8DC0B0A 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:12 offset1:13      // 0000000A4804: D8DC0D0C 4600002E
	v_fma_f32 v33, -v34, v65, v33                              // 0000000A480C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 0000000A4814: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4818: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 0000000A481C: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 0000000A4824: D6130021 24868724
	s_waitcnt lgkmcnt(8)                                       // 0000000A482C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4830: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 0000000A4834: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 0000000A483C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 0000000A4844: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4848: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 0000000A484C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 0000000A4854: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 0000000A485C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A4860: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000A4864: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 0000000A486C: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 0000000A4874: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 0000000A487C: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 0000000A4884: D8DC1716 3C00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:16 offset1:33      // 0000000A488C: D8DC2110 40000030
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000A4894: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:84 offset1:101     // 0000000A489C: D8DC6554 44000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000A48A4: D8DC8776 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 0000000A48AC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 0000000A48B4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A48B8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 0000000A48BC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 0000000A48C4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A48CC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 0000000A48D0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 0000000A48D8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 0000000A48E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A48E4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 0000000A48E8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 0000000A48F0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 0000000A48F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A48FC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 0000000A4900: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 0000000A4908: D8DC1918 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 0000000A4910: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 0000000A4918: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000A4920: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:152 offset1:169    // 0000000A4928: D8DCA998 48000030
	ds_load_2addr_b32 v[76:77], v48 offset0:186 offset1:203    // 0000000A4930: D8DCCBBA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:220 offset1:237    // 0000000A4938: D8DCEDDC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:126 offset1:143    // 0000000A4940: D8DC8F7E 50000031
	v_fma_f32 v33, -v34, v67, v33                              // 0000000A4948: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 0000000A4950: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4954: BF870091
	v_fma_f32 v33, -v35, v68, v33                              // 0000000A4958: D6130021 24868923
	v_fma_f32 v33, -v36, v69, v33                              // 0000000A4960: D6130021 24868B24
	s_waitcnt lgkmcnt(8)                                       // 0000000A4968: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A496C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000A4970: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000A4978: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000A4980: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4984: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 0000000A4988: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 0000000A4990: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 0000000A4998: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A499C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000A49A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 0000000A49A8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 0000000A49B0: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 0000000A49B8: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 0000000A49C0: D8DC2726 3C00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 0000000A49C8: D8DC3120 42000032
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 0000000A49D0: D8DC5342 44000032
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000A49D8: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000A49E0: D8DC9786 4A000032
	v_fma_f32 v62, -v63, v77, v62                              // 0000000A49E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000A49F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A49F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000A49F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000A4A00: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000A4A08: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4A0C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 0000000A4A10: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 0000000A4A18: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 0000000A4A20: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4A24: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 0000000A4A28: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 0000000A4A30: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 0000000A4A38: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A4A3C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 0000000A4A40: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 0000000A4A48: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 0000000A4A50: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:44 offset1:45      // 0000000A4A58: D8DC2D2C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:46 offset1:47      // 0000000A4A60: D8DC2F2E 4200002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 0000000A4A68: D8DCB9A8 46000032
	ds_load_2addr_b32 v[76:77], v50 offset0:202 offset1:219    // 0000000A4A70: D8DCDBCA 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:236 offset1:253    // 0000000A4A78: D8DCFDEC 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:14 offset1:31      // 0000000A4A80: D8DC1F0E 50000033
	v_fma_f32 v33, -v34, v69, v33                              // 0000000A4A88: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 0000000A4A90: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4A94: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000A4A98: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000A4AA0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000A4AA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4AAC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000A4AB0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000A4AB8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000A4AC0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4AC4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 0000000A4AC8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 0000000A4AD0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 0000000A4AD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A4ADC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000A4AE0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 0000000A4AE8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 0000000A4AF0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 0000000A4AF8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 0000000A4B00: D8DC3736 3C00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:48 offset1:65      // 0000000A4B08: D8DC4130 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:82 offset1:99      // 0000000A4B10: D8DC6352 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000A4B18: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000A4B20: D8DCA796 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 0000000A4B28: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000A4B30: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4B34: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000A4B38: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000A4B40: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000A4B48: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4B4C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000A4B50: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000A4B58: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000A4B60: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4B64: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000A4B68: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A4B70: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A4B78: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A4B7C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000A4B80: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 0000000A4B88: D8DC3938 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:58 offset1:59      // 0000000A4B90: D8DC3B3A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:60 offset1:61      // 0000000A4B98: D8DC3D3C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:62 offset1:63      // 0000000A4BA0: D8DC3F3E 4200002E
	ds_load_2addr_b32 v[68:69], v51 offset0:184 offset1:201    // 0000000A4BA8: D8DCC9B8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:218 offset1:235    // 0000000A4BB0: D8DCEBDA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:124 offset1:141    // 0000000A4BB8: D8DC8D7C 4E000034
	ds_load_2addr_b32 v[80:81], v53 offset0:30 offset1:47      // 0000000A4BC0: D8DC2F1E 50000035
	v_fma_f32 v33, -v34, v71, v33                              // 0000000A4BC8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000A4BD0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4BD4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000A4BD8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000A4BE0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000A4BE8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4BEC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000A4BF0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000A4BF8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000A4C00: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4C04: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000A4C08: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A4C10: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A4C18: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A4C1C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000A4C20: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 0000000A4C28: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 0000000A4C30: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 0000000A4C38: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 0000000A4C40: D8DC4746 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:64 offset1:81      // 0000000A4C48: D8DC5140 44000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 0000000A4C50: D8DC7362 46000035
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000A4C58: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000A4C60: D8DCB7A6 4A000035
	v_fma_f32 v62, -v63, v77, v62                              // 0000000A4C68: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000A4C70: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4C74: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000A4C78: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000A4C80: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000A4C88: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4C8C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000A4C90: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000A4C98: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000A4CA0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4CA4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000A4CA8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A4CB0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A4CB8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A4CBC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000A4CC0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 0000000A4CC8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 0000000A4CD0: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 0000000A4CD8: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:78 offset1:79      // 0000000A4CE0: D8DC4F4E 4200002E
	ds_load_2addr_b32 v[68:69], v53 offset0:200 offset1:217    // 0000000A4CE8: D8DCD9C8 44000035
	ds_load_2addr_b32 v[76:77], v53 offset0:234 offset1:251    // 0000000A4CF0: D8DCFBEA 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:12 offset1:29      // 0000000A4CF8: D8DC1D0C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:46 offset1:63      // 0000000A4D00: D8DC3F2E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 0000000A4D08: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000A4D10: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4D14: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000A4D18: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000A4D20: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000A4D28: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4D2C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000A4D30: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000A4D38: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000A4D40: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4D44: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000A4D48: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A4D50: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A4D58: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A4D5C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000A4D60: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 0000000A4D68: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 0000000A4D70: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 0000000A4D78: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 0000000A4D80: D8DC5756 3C00002E
	ds_load_2addr_b32 v[68:69], v54 offset0:80 offset1:97      // 0000000A4D88: D8DC6150 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 0000000A4D90: D8DC8372 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000A4D98: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000A4DA0: D8DCC7B6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 0000000A4DA8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000A4DB0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4DB4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000A4DB8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000A4DC0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000A4DC8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4DCC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000A4DD0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000A4DD8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000A4DE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4DE4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000A4DE8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A4DF0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A4DF8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A4DFC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000A4E00: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 0000000A4E08: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 0000000A4E10: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:92 offset1:93      // 0000000A4E18: D8DC5D5C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:94 offset1:95      // 0000000A4E20: D8DC5F5E 4200002E
	ds_load_2addr_b32 v[68:69], v54 offset0:216 offset1:233    // 0000000A4E28: D8DCE9D8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:122 offset1:139    // 0000000A4E30: D8DC8B7A 4C000037
	ds_load_2addr_b32 v[78:79], v56 offset0:28 offset1:45      // 0000000A4E38: D8DC2D1C 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:62 offset1:79      // 0000000A4E40: D8DC4F3E 50000038
	v_fma_f32 v33, -v34, v71, v33                              // 0000000A4E48: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000A4E50: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4E54: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000A4E58: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000A4E60: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000A4E68: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4E6C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000A4E70: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000A4E78: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000A4E80: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4E84: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000A4E88: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A4E90: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A4E98: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A4E9C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000A4EA0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 0000000A4EA8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 0000000A4EB0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 0000000A4EB8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 0000000A4EC0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:96 offset1:113     // 0000000A4EC8: D8DC7160 44000038
	ds_load_2addr_b32 v[70:71], v56 offset0:130 offset1:147    // 0000000A4ED0: D8DC9382 46000038
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000A4ED8: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000A4EE0: D8DCD7C6 4A000038
	v_fma_f32 v62, -v63, v77, v62                              // 0000000A4EE8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000A4EF0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4EF4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000A4EF8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000A4F00: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000A4F08: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4F0C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000A4F10: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000A4F18: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000A4F20: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4F24: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000A4F28: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A4F30: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A4F38: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A4F3C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000A4F40: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 0000000A4F48: D8DC6968 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:106 offset1:107    // 0000000A4F50: D8DC6B6A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:108 offset1:109    // 0000000A4F58: D8DC6D6C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:110 offset1:111    // 0000000A4F60: D8DC6F6E 4200002E
	ds_load_2addr_b32 v[68:69], v56 offset0:232 offset1:249    // 0000000A4F68: D8DCF9E8 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:10 offset1:27      // 0000000A4F70: D8DC1B0A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:44 offset1:61      // 0000000A4F78: D8DC3D2C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:78 offset1:95      // 0000000A4F80: D8DC5F4E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 0000000A4F88: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000A4F90: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4F94: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000A4F98: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000A4FA0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000A4FA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4FAC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000A4FB0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000A4FB8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000A4FC0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4FC4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000A4FC8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A4FD0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A4FD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A4FDC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000A4FE0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 0000000A4FE8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 0000000A4FF0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 0000000A4FF8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 0000000A5000: D8DC7776 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 0000000A5008: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 0000000A5010: D8DCA392 46000039
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000A5018: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000A5020: D8DCE7D6 4A000039
	v_fma_f32 v62, -v63, v77, v62                              // 0000000A5028: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000A5030: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5034: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000A5038: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000A5040: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000A5048: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A504C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000A5050: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000A5058: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000A5060: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5064: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000A5068: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A5070: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A5078: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A507C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000A5080: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 0000000A5088: D8DC7978 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 0000000A5090: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 0000000A5098: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:126 offset1:127    // 0000000A50A0: D8DC7F7E 4200002E
	ds_load_2addr_b32 v[68:69], v58 offset0:120 offset1:137    // 0000000A50A8: D8DC8978 4400003A
	ds_load_2addr_b32 v[76:77], v59 offset0:26 offset1:43      // 0000000A50B0: D8DC2B1A 4C00003B
	ds_load_2addr_b32 v[78:79], v59 offset0:60 offset1:77      // 0000000A50B8: D8DC4D3C 4E00003B
	ds_load_2addr_b32 v[80:81], v59 offset0:94 offset1:111     // 0000000A50C0: D8DC6F5E 5000003B
	v_fma_f32 v33, -v34, v71, v33                              // 0000000A50C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000A50D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A50D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000A50D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000A50E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000A50E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A50EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000A50F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000A50F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000A5100: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5104: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000A5108: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A5110: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A5118: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A511C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 0000000A5120: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 0000000A5128: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 0000000A5130: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5134: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 0000000A5138: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 0000000A5140: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 0000000A5148: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A514C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 0000000A5150: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s12, v[4:5]            // 0000000A5158: D6FE7C1F 041018FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 0000000A5164: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 0000000A516C: D8340000 0000201F
	s_branch 64818                                             // 0000000A5174: BFA0FD32 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x540>
	v_mov_b32_e32 v30, v14                                     // 0000000A5178: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000A517C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000A5184: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 0000000A5188: 7E46032B
	s_mov_b32 s12, 0                                           // 0000000A518C: BE8C0080
	s_branch 21                                                // 0000000A5190: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000A5194: 8C7E0D7E
	.long 0xd700011f                                           // 0000000A5198: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000A519C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A51A4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000A51A8: D5207C20 00064080
	.long 0xd700011d                                           // 0000000A51B0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000A51B4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 0000000A51BC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A51C0: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000A51C8: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000A51CC: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000A51D0: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000A51D4: BC7C0000
	s_barrier                                                  // 0000000A51D8: BFBD0000
	buffer_gl0_inv                                             // 0000000A51DC: E0AC0000 00000000
	s_cbranch_scc1 609                                         // 0000000A51E4: BFA20261 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a6c>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A51E8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000A51EC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 0000000A51F4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 0000000A51F8: 7E780326
	s_mov_b32 s13, 0                                           // 0000000A51FC: BE8D0080
	global_load_b32 v61, v[33:34], off                         // 0000000A5200: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000000A5208: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000000A5210: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000A5214: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000A521C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000A5220: D5207C22 00064480
	.long 0xd4490004                                           // 0000000A5228: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000000A522C: 020278FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000A5234: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000A5238: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 0000000A523C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 0000000A5244: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000A524C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000A5250: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000A5254: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000A5258: BF89FC07
	s_barrier                                                  // 0000000A525C: BFBD0000
	buffer_gl0_inv                                             // 0000000A5260: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000A5268: BE8D2000
	s_cbranch_execz 65481                                      // 0000000A526C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s12, v2                                  // 0000000A5270: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5274: BF870091
	v_or_b32_e32 v36, s11, v33                                 // 0000000A5278: 3848420B
	.long 0xd4440001                                           // 0000000A527C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 0000000A5280: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000A5284: 8B7E017E
	s_cbranch_execz 65474                                      // 0000000A5288: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 0000000A528C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000A5294: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:2 offset1:3        // 0000000A529C: D8DC0302 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 0000000A52A4: D8DC3322 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:4 offset1:5        // 0000000A52AC: D8DC0504 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:6 offset1:7        // 0000000A52B4: D8DC0706 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 0000000A52BC: D8DC5544 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:102 offset1:119     // 0000000A52C4: D8DC7766 4A000001
	s_mov_b32 s14, 0                                           // 0000000A52CC: BE8E0080
	s_waitcnt lgkmcnt(6)                                       // 0000000A52D0: BF89FC67
	v_fma_f32 v76, v60, v62, 0                                 // 0000000A52D4: D613004C 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A52DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A52E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A52E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A52E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A52EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A52F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A52F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A52F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A52FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A5300: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A5304: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A5308: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A530C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A5310: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:8 offset1:9        // 0000000A5314: D8DC0908 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 0000000A531C: D8DC9988 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:10 offset1:11      // 0000000A5324: D8DC0B0A 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:170 offset1:187     // 0000000A532C: D8DCBBAA 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:12 offset1:13      // 0000000A5334: D8DC0D0C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:14 offset1:15      // 0000000A533C: D8DC0F0E 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 0000000A5344: D8DCDDCC 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:238 offset1:255     // 0000000A534C: D8DCFFEE 4A000001
	s_waitcnt lgkmcnt(6)                                       // 0000000A5354: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A5358: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A535C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A5360: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A5364: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A5368: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A536C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A5370: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A5374: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A5378: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A537C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A5380: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A5384: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A5388: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A538C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A5390: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:16 offset1:17      // 0000000A5394: D8DC1110 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:16 offset1:33      // 0000000A539C: D8DC2110 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:18 offset1:19      // 0000000A53A4: D8DC1312 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000A53AC: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:20 offset1:21      // 0000000A53B4: D8DC1514 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:22 offset1:23      // 0000000A53BC: D8DC1716 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:84 offset1:101     // 0000000A53C4: D8DC6554 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000A53CC: D8DC8776 4A000030
	s_waitcnt lgkmcnt(6)                                       // 0000000A53D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A53D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A53DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A53E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A53E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A53E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A53EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A53F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A53F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A53F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A53FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A5400: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A5404: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A5408: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A540C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A5410: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 0000000A5414: D8DC1918 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:152 offset1:169    // 0000000A541C: D8DCA998 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:26 offset1:27      // 0000000A5424: D8DC1B1A 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:186 offset1:203    // 0000000A542C: D8DCCBBA 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:28 offset1:29      // 0000000A5434: D8DC1D1C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000A543C: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:220 offset1:237    // 0000000A5444: D8DCEDDC 48000030
	ds_load_2addr_b32 v[74:75], v49 offset0:126 offset1:143    // 0000000A544C: D8DC8F7E 4A000031
	s_waitcnt lgkmcnt(6)                                       // 0000000A5454: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A5458: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A545C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A5460: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A5464: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A5468: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A546C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A5470: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A5474: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A5478: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A547C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A5480: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A5484: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A5488: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A548C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A5490: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:32 offset1:33      // 0000000A5494: D8DC2120 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:32 offset1:49      // 0000000A549C: D8DC3120 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 0000000A54A4: D8DC2322 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:66 offset1:83      // 0000000A54AC: D8DC5342 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:36 offset1:37      // 0000000A54B4: D8DC2524 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:38 offset1:39      // 0000000A54BC: D8DC2726 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000A54C4: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000A54CC: D8DC9786 4A000032
	s_waitcnt lgkmcnt(6)                                       // 0000000A54D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A54D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A54DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A54E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A54E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A54E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A54EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A54F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A54F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A54F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A54FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A5500: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A5504: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A5508: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A550C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A5510: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:40 offset1:41      // 0000000A5514: D8DC2928 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:168 offset1:185    // 0000000A551C: D8DCB9A8 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:42 offset1:43      // 0000000A5524: D8DC2B2A 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:202 offset1:219    // 0000000A552C: D8DCDBCA 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:44 offset1:45      // 0000000A5534: D8DC2D2C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:46 offset1:47      // 0000000A553C: D8DC2F2E 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:236 offset1:253    // 0000000A5544: D8DCFDEC 48000032
	ds_load_2addr_b32 v[74:75], v51 offset0:14 offset1:31      // 0000000A554C: D8DC1F0E 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000A5554: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A5558: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A555C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A5560: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A5564: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A5568: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A556C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A5570: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A5574: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A5578: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A557C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A5580: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A5584: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A5588: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A558C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A5590: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 0000000A5594: D8DC3130 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:48 offset1:65      // 0000000A559C: D8DC4130 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:50 offset1:51      // 0000000A55A4: D8DC3332 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:82 offset1:99      // 0000000A55AC: D8DC6352 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:52 offset1:53      // 0000000A55B4: D8DC3534 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:54 offset1:55      // 0000000A55BC: D8DC3736 4600002E
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000A55C4: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000A55CC: D8DCA796 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000A55D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A55D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A55DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A55E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A55E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A55E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A55EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A55F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A55F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A55F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A55FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A5600: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A5604: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A5608: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A560C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A5610: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:56 offset1:57      // 0000000A5614: D8DC3938 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:184 offset1:201    // 0000000A561C: D8DCC9B8 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:58 offset1:59      // 0000000A5624: D8DC3B3A 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:218 offset1:235    // 0000000A562C: D8DCEBDA 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:60 offset1:61      // 0000000A5634: D8DC3D3C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:62 offset1:63      // 0000000A563C: D8DC3F3E 4600002E
	ds_load_2addr_b32 v[72:73], v52 offset0:124 offset1:141    // 0000000A5644: D8DC8D7C 48000034
	ds_load_2addr_b32 v[74:75], v53 offset0:30 offset1:47      // 0000000A564C: D8DC2F1E 4A000035
	s_waitcnt lgkmcnt(6)                                       // 0000000A5654: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A5658: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A565C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A5660: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A5664: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A5668: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A566C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A5670: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A5674: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A5678: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A567C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A5680: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A5684: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A5688: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A568C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A5690: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:64 offset1:65      // 0000000A5694: D8DC4140 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:64 offset1:81      // 0000000A569C: D8DC5140 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:66 offset1:67      // 0000000A56A4: D8DC4342 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:98 offset1:115     // 0000000A56AC: D8DC7362 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:68 offset1:69      // 0000000A56B4: D8DC4544 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:70 offset1:71      // 0000000A56BC: D8DC4746 4600002E
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000A56C4: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000A56CC: D8DCB7A6 4A000035
	s_waitcnt lgkmcnt(6)                                       // 0000000A56D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A56D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A56DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A56E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A56E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A56E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A56EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A56F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A56F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A56F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A56FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A5700: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A5704: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A5708: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A570C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A5710: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 0000000A5714: D8DC4948 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:200 offset1:217    // 0000000A571C: D8DCD9C8 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:74 offset1:75      // 0000000A5724: D8DC4B4A 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:234 offset1:251    // 0000000A572C: D8DCFBEA 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:76 offset1:77      // 0000000A5734: D8DC4D4C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:78 offset1:79      // 0000000A573C: D8DC4F4E 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:12 offset1:29      // 0000000A5744: D8DC1D0C 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:46 offset1:63      // 0000000A574C: D8DC3F2E 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000A5754: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A5758: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A575C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A5760: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A5764: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A5768: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A576C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A5770: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A5774: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A5778: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A577C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A5780: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A5784: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A5788: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A578C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A5790: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:80 offset1:81      // 0000000A5794: D8DC5150 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:80 offset1:97      // 0000000A579C: D8DC6150 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 0000000A57A4: D8DC5352 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:114 offset1:131    // 0000000A57AC: D8DC8372 42000036
	ds_load_2addr_b32 v[68:69], v46 offset0:84 offset1:85      // 0000000A57B4: D8DC5554 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:86 offset1:87      // 0000000A57BC: D8DC5756 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000A57C4: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000A57CC: D8DCC7B6 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000A57D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A57D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A57DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A57E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A57E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A57E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A57EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A57F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A57F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A57F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A57FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A5800: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A5804: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A5808: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A580C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A5810: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:88 offset1:89      // 0000000A5814: D8DC5958 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:216 offset1:233    // 0000000A581C: D8DCE9D8 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:90 offset1:91      // 0000000A5824: D8DC5B5A 4000002E
	ds_load_2addr_b32 v[66:67], v55 offset0:122 offset1:139    // 0000000A582C: D8DC8B7A 42000037
	ds_load_2addr_b32 v[68:69], v46 offset0:92 offset1:93      // 0000000A5834: D8DC5D5C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:94 offset1:95      // 0000000A583C: D8DC5F5E 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:28 offset1:45      // 0000000A5844: D8DC2D1C 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:62 offset1:79      // 0000000A584C: D8DC4F3E 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000A5854: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A5858: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A585C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A5860: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A5864: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A5868: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A586C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A5870: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A5874: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A5878: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A587C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A5880: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A5884: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A5888: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A588C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A5890: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 0000000A5894: D8DC6160 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:96 offset1:113     // 0000000A589C: D8DC7160 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:98 offset1:99      // 0000000A58A4: D8DC6362 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:130 offset1:147    // 0000000A58AC: D8DC9382 42000038
	ds_load_2addr_b32 v[68:69], v46 offset0:100 offset1:101    // 0000000A58B4: D8DC6564 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:102 offset1:103    // 0000000A58BC: D8DC6766 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000A58C4: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000A58CC: D8DCD7C6 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000A58D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A58D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A58DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A58E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A58E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A58E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A58EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A58F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A58F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A58F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A58FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A5900: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A5904: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A5908: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A590C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A5910: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:104 offset1:105    // 0000000A5914: D8DC6968 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:232 offset1:249    // 0000000A591C: D8DCF9E8 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 0000000A5924: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:10 offset1:27      // 0000000A592C: D8DC1B0A 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:108 offset1:109    // 0000000A5934: D8DC6D6C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:110 offset1:111    // 0000000A593C: D8DC6F6E 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:44 offset1:61      // 0000000A5944: D8DC3D2C 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:78 offset1:95      // 0000000A594C: D8DC5F4E 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000A5954: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A5958: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A595C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A5960: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A5964: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A5968: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A596C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A5970: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A5974: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A5978: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A597C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A5980: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A5984: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A5988: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A598C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A5990: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:112 offset1:113    // 0000000A5994: D8DC7170 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:112 offset1:129    // 0000000A599C: D8DC8170 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:114 offset1:115    // 0000000A59A4: D8DC7372 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:146 offset1:163    // 0000000A59AC: D8DCA392 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:116 offset1:117    // 0000000A59B4: D8DC7574 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:118 offset1:119    // 0000000A59BC: D8DC7776 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000A59C4: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000A59CC: D8DCE7D6 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000A59D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A59D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A59DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A59E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A59E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A59E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A59EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A59F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A59F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A59F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A59FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A5A00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A5A04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A5A08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A5A0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A5A10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 0000000A5A14: D8DC7978 3C00002E
	ds_load_2addr_b32 v[62:63], v58 offset0:120 offset1:137    // 0000000A5A1C: D8DC8978 3E00003A
	ds_load_2addr_b32 v[64:65], v46 offset0:122 offset1:123    // 0000000A5A24: D8DC7B7A 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:26 offset1:43      // 0000000A5A2C: D8DC2B1A 4200003B
	ds_load_2addr_b32 v[68:69], v46 offset0:124 offset1:125    // 0000000A5A34: D8DC7D7C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:126 offset1:127    // 0000000A5A3C: D8DC7F7E 4600002E
	ds_load_2addr_b32 v[72:73], v59 offset0:60 offset1:77      // 0000000A5A44: D8DC4D3C 4800003B
	ds_load_2addr_b32 v[74:75], v59 offset0:94 offset1:111     // 0000000A5A4C: D8DC6F5E 4A00003B
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000000A5A54: 30424282
	s_waitcnt lgkmcnt(6)                                       // 0000000A5A58: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A5A5C: 56987D3C
	ds_load_b32 v60, v33 offset:17440                          // 0000000A5A60: D8D84420 3C000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000A5A68: CA10011E 2220011D
	v_mov_b32_e32 v62, v35                                     // 0000000A5A70: 7E7C0323
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A5A74: 56987F3D
	v_mov_b32_e32 v61, v1                                      // 0000000A5A78: 7E7A0301
	s_waitcnt lgkmcnt(5)                                       // 0000000A5A7C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5A80: BF870092
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A5A84: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A5A88: 56988741
	s_waitcnt lgkmcnt(2)                                       // 0000000A5A8C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5A90: BF870091
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A5A94: 56989144
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A5A98: 56989345
	s_waitcnt lgkmcnt(1)                                       // 0000000A5A9C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5AA0: BF870091
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A5AA4: 56989546
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A5AA8: 56989747
	s_waitcnt lgkmcnt(0)                                       // 0000000A5AAC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A5AB0: BF870001
	v_mul_f32_e32 v60, v76, v60                                // 0000000A5AB4: 1078794C
	s_nop 0                                                    // 0000000A5AB8: BF800000
	s_nop 0                                                    // 0000000A5ABC: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000A5AC0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000A5AC8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000A5AD0: 4A7C7CC1
	.long 0xd7000121                                           // 0000000A5AD4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000A5AD8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000A5ADC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000A5AE0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000A5AE8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000A5AEC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000A5AF0: 4A7A7AFF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000A5AF8: 8C0E0E04
	s_waitcnt lgkmcnt(0)                                       // 0000000A5AFC: BF89FC07
	v_fma_mixlo_f16 v64, v64, s6, 0                            // 0000000A5B00: CC210040 02000D40
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000A5B08: BF8700B1
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A5B0C: CC200040 8A000F40
	s_waitcnt vmcnt(0)                                         // 0000000A5B14: BF8903F7
	v_fma_mixlo_f16 v63, v63, s6, 0                            // 0000000A5B18: CC21003F 02000D3F
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A5B20: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A5B28: BF870001
	v_fmac_f32_e32 v60, v63, v64                               // 0000000A5B2C: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000A5B30: 917E0E7E
	s_cbranch_execnz 65506                                     // 0000000A5B34: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19c0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000A5B38: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A5B3C: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 0000000A5B40: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 0000000A5B48: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 0000000A5B54: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 0000000A5B60: DC960000 007C2421
	s_branch 64906                                             // 0000000A5B68: BFA0FD8A <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000A5B6C: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 0000000A5B74: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000A5B78: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000A5B7C: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000A5B84: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000A5B88: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000A5B90: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000A5B98: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000A5B9C: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000A5BA0: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000A5BA8: A0010401
	s_mov_b32 s4, 0                                            // 0000000A5BAC: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000A5BB0: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000A5BB4: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000A5BB8: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000A5BBC: BF870585
	.long 0xd71c001d                                           // 0000000A5BC0: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000A5BC4: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000A5BC8: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000A5BCC: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000A5BD4: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000A5BD8: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000A5BE0: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000000A5BE4: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000A5BE8: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000A5BF4: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000A5BFC: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A5C04: BF870001
	.long 0xd4490001                                           // 0000000A5C08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000A5C0C: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000A5C14: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000A5C18: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000A5C1C: 1040411E
	ds_store_b32 v29, v32                                      // 0000000A5C20: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000A5C28: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A5C30: 917E047E
	s_cbranch_execnz 65519                                     // 0000000A5C34: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1af4>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A5C38: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000A5C3C: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 0000000A5C44: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 0000000A5C4C: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A5C50: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A5C54: BF89FC07
	s_barrier                                                  // 0000000A5C58: BFBD0000
	buffer_gl0_inv                                             // 0000000A5C5C: E0AC0000 00000000
	s_nop 0                                                    // 0000000A5C64: BF800000
	s_nop 0                                                    // 0000000A5C68: BF800000
	s_nop 0                                                    // 0000000A5C6C: BF800000
	s_nop 0                                                    // 0000000A5C70: BF800000
	s_nop 0                                                    // 0000000A5C74: BF800000
	s_nop 0                                                    // 0000000A5C78: BF800000
	s_nop 0                                                    // 0000000A5C7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A5C80: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 0000000A5C88: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A5C90: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A5C98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A5C9C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000A5CA4: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A5CA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A5CB0: BF870004
	.long 0xd4490004                                           // 0000000A5CB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A5CB8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A5CC0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A5CC4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A5CC8: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 0000000A5CCC: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000A5CD4: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A5CDC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A5CE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A5CE4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000A5CE8: BF89FC07
	s_barrier                                                  // 0000000A5CEC: BFBD0000
	buffer_gl0_inv                                             // 0000000A5CF0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000000A5CF8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 0000000A5D00: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 0000000A5D08: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 0000000A5D10: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000A5D18: 7E780300
	s_mov_b32 s4, 0                                            // 0000000A5D1C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A5D20: BF840001
	s_nop 0                                                    // 0000000A5D24: BF800000
	s_nop 0                                                    // 0000000A5D28: BF800000
	s_nop 0                                                    // 0000000A5D2C: BF800000
	s_nop 0                                                    // 0000000A5D30: BF800000
	s_nop 0                                                    // 0000000A5D34: BF800000
	s_nop 0                                                    // 0000000A5D38: BF800000
	s_nop 0                                                    // 0000000A5D3C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A5D40: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000A5D44: 327A7884
	.long 0xd4490001                                           // 0000000A5D48: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000A5D4C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000A5D54: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000A5D58: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A5D64: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000A5D68: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000A5D70: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000A5D78: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000A5D80: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000A5D88: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000A5D90: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000A5D98: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000A5DA0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000A5DA4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A5DB0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000A5DB4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000A5DB8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000A5DC0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000A5DC4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000A5DC8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000A5DCC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5DD0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000A5DD4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000A5DD8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000A5DDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5DE0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000A5DE4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000A5DF0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000A5DF8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A5E00: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A5E04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c40>
	s_set_inst_prefetch_distance 0x2                           // 0000000A5E08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A5E0C: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 0000000A5E10: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A5E18: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A5E20: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A5E24: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A5E28: BF89FC07
	s_barrier                                                  // 0000000A5E2C: BFBD0000
	buffer_gl0_inv                                             // 0000000A5E30: E0AC0000 00000000
	s_nop 0                                                    // 0000000A5E38: BF800000
	s_nop 0                                                    // 0000000A5E3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A5E40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 0000000A5E48: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A5E50: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A5E58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A5E5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A5E64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A5E68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A5E70: BF870004
	.long 0xd4490004                                           // 0000000A5E74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A5E78: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A5E80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A5E84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A5E88: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A5E8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A5E94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A5E9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A5EA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d40>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A5EA4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000A5EA8: BF89FC07
	s_barrier                                                  // 0000000A5EAC: BFBD0000
	buffer_gl0_inv                                             // 0000000A5EB0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000000A5EB8: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 0000000A5EC0: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 0000000A5EC8: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 0000000A5ED0: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000A5ED8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000A5EDC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A5EE0: BF840001
	s_nop 0                                                    // 0000000A5EE4: BF800000
	s_nop 0                                                    // 0000000A5EE8: BF800000
	s_nop 0                                                    // 0000000A5EEC: BF800000
	s_nop 0                                                    // 0000000A5EF0: BF800000
	s_nop 0                                                    // 0000000A5EF4: BF800000
	s_nop 0                                                    // 0000000A5EF8: BF800000
	s_nop 0                                                    // 0000000A5EFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A5F00: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000A5F04: 327A7884
	.long 0xd4490001                                           // 0000000A5F08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000A5F0C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000A5F14: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000A5F18: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A5F24: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000A5F28: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000A5F30: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000A5F38: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000A5F40: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000A5F48: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000A5F50: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000A5F58: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000A5F60: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000A5F64: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A5F70: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000A5F74: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000A5F78: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000A5F80: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000A5F84: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000A5F88: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000A5F8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5F90: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000A5F94: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000A5F98: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000A5F9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5FA0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000A5FA4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000A5FB0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000A5FB8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A5FC0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A5FC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e00>
	s_set_inst_prefetch_distance 0x2                           // 0000000A5FC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A5FCC: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 0000000A5FD0: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A5FD8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A5FE0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A5FE4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A5FE8: BF89FC07
	s_barrier                                                  // 0000000A5FEC: BFBD0000
	buffer_gl0_inv                                             // 0000000A5FF0: E0AC0000 00000000
	s_nop 0                                                    // 0000000A5FF8: BF800000
	s_nop 0                                                    // 0000000A5FFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A6000: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 0000000A6008: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A6010: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A6018: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A601C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A6024: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A6028: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A6030: BF870004
	.long 0xd4490004                                           // 0000000A6034: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A6038: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A6040: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A6044: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A6048: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A604C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A6054: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A605C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A6060: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A6064: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 0000000A6068: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000A6070: BF89FC07
	s_barrier                                                  // 0000000A6074: BFBD0000
	buffer_gl0_inv                                             // 0000000A6078: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000A6080: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 0000000A6084: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 0000000A608C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 0000000A6094: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 0000000A609C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000000A60A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A60A8: BF840001
	s_nop 0                                                    // 0000000A60AC: BF800000
	s_nop 0                                                    // 0000000A60B0: BF800000
	s_nop 0                                                    // 0000000A60B4: BF800000
	s_nop 0                                                    // 0000000A60B8: BF800000
	s_nop 0                                                    // 0000000A60BC: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000A60C0: 327C7A84
	.long 0xd4490001                                           // 0000000A60C4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000A60C8: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A60D0: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000A60D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000A60D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A60E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000A60E8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000A60F0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000A60F8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000A6100: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000A6108: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000A6110: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000A6118: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000A6120: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000A6124: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A6128: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000A612C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000A6138: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000A6140: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000A6144: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000A6148: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000A614C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6150: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000A6154: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000A6158: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000A615C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6160: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000A6164: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000A6170: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000A6178: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A6180: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A6184: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fc0>
	s_set_inst_prefetch_distance 0x2                           // 0000000A6188: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A618C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 0000000A6190: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A6198: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A61A0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A61A4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A61A8: BF89FC07
	s_barrier                                                  // 0000000A61AC: BFBD0000
	buffer_gl0_inv                                             // 0000000A61B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000A61B8: BF800000
	s_nop 0                                                    // 0000000A61BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A61C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 0000000A61C8: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A61D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A61D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A61DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A61E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A61E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A61F0: BF870004
	.long 0xd4490004                                           // 0000000A61F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A61F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A6200: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A6204: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A6208: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A620C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A6214: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A621C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A6220: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x20c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A6224: 8C7E0A7E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000000A6228: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000A6230: BF89FC07
	s_barrier                                                  // 0000000A6234: BFBD0000
	buffer_gl0_inv                                             // 0000000A6238: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 0000000A6240: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 0000000A6248: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 0000000A6250: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 0000000A6258: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000A6260: 7E780300
	s_mov_b32 s4, 0                                            // 0000000A6264: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A6268: BF840001
	s_nop 0                                                    // 0000000A626C: BF800000
	s_nop 0                                                    // 0000000A6270: BF800000
	s_nop 0                                                    // 0000000A6274: BF800000
	s_nop 0                                                    // 0000000A6278: BF800000
	s_nop 0                                                    // 0000000A627C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A6280: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000A6284: 327A7884
	.long 0xd4490001                                           // 0000000A6288: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000A628C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000A6294: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000A6298: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A62A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000A62A8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000A62B0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000A62B8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000A62C0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000A62C8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000A62D0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000A62D8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000A62E0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000A62E4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A62F0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000A62F4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000A62F8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000A6300: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000A6304: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000A6308: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000A630C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6310: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000A6314: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000A6318: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000A631C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6320: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000A6324: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000A6330: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000A6338: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A6340: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A6344: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2180>
	s_set_inst_prefetch_distance 0x2                           // 0000000A6348: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A634C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 0000000A6350: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A6358: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A6360: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A6364: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A6368: BF89FC07
	s_barrier                                                  // 0000000A636C: BFBD0000
	buffer_gl0_inv                                             // 0000000A6370: E0AC0000 00000000
	s_nop 0                                                    // 0000000A6378: BF800000
	s_nop 0                                                    // 0000000A637C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A6380: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 0000000A6388: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A6390: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A6398: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A639C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A63A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A63A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A63B0: BF870004
	.long 0xd4490004                                           // 0000000A63B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A63B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A63C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A63C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A63C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A63CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A63D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A63DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A63E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2280>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A63E4: 8C7E0A7E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 0000000A63E8: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000000A63F0: BF89FC07
	s_barrier                                                  // 0000000A63F4: BFBD0000
	buffer_gl0_inv                                             // 0000000A63F8: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 0000000A6400: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 0000000A6404: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 0000000A640C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 0000000A6414: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 0000000A641C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000000A6424: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A6428: BF840001
	s_nop 0                                                    // 0000000A642C: BF800000
	s_nop 0                                                    // 0000000A6430: BF800000
	s_nop 0                                                    // 0000000A6434: BF800000
	s_nop 0                                                    // 0000000A6438: BF800000
	s_nop 0                                                    // 0000000A643C: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 0000000A6440: 327C7884
	.long 0xd4490001                                           // 0000000A6444: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000A6448: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A6450: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000A6454: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000A6458: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A6464: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000A6468: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000A6470: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000A6478: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000A6480: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000A6488: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000A6490: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000A6498: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000A64A0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000A64A4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A64A8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000A64AC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000A64B8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000A64C0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000A64C4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000A64C8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000A64CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A64D0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000A64D4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000A64D8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000A64DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A64E0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000000A64E4: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 0000000A64F0: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A64F4: BF870002
	v_mov_b32_e32 v60, v63                                     // 0000000A64F8: 7E78033F
	ds_store_b32 v62, v70                                      // 0000000A64FC: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A6504: 917E047E
	s_cbranch_execnz 65485                                     // 0000000A6508: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2340>
	s_set_inst_prefetch_distance 0x2                           // 0000000A650C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A6510: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 0000000A6514: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A651C: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A6524: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A6528: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A652C: BF89FC07
	s_barrier                                                  // 0000000A6530: BFBD0000
	buffer_gl0_inv                                             // 0000000A6534: E0AC0000 00000000
	s_nop 0                                                    // 0000000A653C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A6540: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 0000000A6548: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A6550: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A6558: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A655C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A6564: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A6568: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A6570: BF870004
	.long 0xd4490004                                           // 0000000A6574: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A6578: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A6580: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A6584: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A6588: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A658C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A6594: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A659C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A65A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2440>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A65A4: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 0000000A65A8: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000A65B0: BF89FC07
	s_barrier                                                  // 0000000A65B4: BFBD0000
	buffer_gl0_inv                                             // 0000000A65B8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 0000000A65C0: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 0000000A65C8: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 0000000A65D0: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 0000000A65D8: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000A65E0: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000A65E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A65E8: BF840001
	s_nop 0                                                    // 0000000A65EC: BF800000
	s_nop 0                                                    // 0000000A65F0: BF800000
	s_nop 0                                                    // 0000000A65F4: BF800000
	s_nop 0                                                    // 0000000A65F8: BF800000
	s_nop 0                                                    // 0000000A65FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A6600: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000A6604: 327C7A84
	.long 0xd4490001                                           // 0000000A6608: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000A660C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000A6614: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000A6618: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A6624: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000A6628: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000A6630: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000A6638: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000A6640: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000A6648: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000A6650: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000A6658: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000A6660: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000A6664: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A6668: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000A666C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000A6678: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000A6680: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000A6684: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000A6688: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000A668C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6690: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000A6694: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000A6698: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000A669C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A66A0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000A66A4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000A66B0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000A66B8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A66C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A66C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2500>
	s_set_inst_prefetch_distance 0x2                           // 0000000A66C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A66CC: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 0000000A66D0: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A66D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A66E0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A66E4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A66E8: BF89FC07
	s_barrier                                                  // 0000000A66EC: BFBD0000
	buffer_gl0_inv                                             // 0000000A66F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000A66F8: BF800000
	s_nop 0                                                    // 0000000A66FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A6700: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 0000000A6708: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A6710: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A6718: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A671C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A6724: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A6728: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A6730: BF870004
	.long 0xd4490004                                           // 0000000A6734: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A6738: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A6740: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A6744: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A6748: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A674C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A6754: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A675C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A6760: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2600>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A6764: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000A6768: BF89FC07
	s_barrier                                                  // 0000000A676C: BFBD0000
	buffer_gl0_inv                                             // 0000000A6770: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 0000000A6778: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 0000000A6780: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 0000000A6788: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 0000000A6790: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000A6798: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000A679C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A67A0: BF840001
	s_nop 0                                                    // 0000000A67A4: BF800000
	s_nop 0                                                    // 0000000A67A8: BF800000
	s_nop 0                                                    // 0000000A67AC: BF800000
	s_nop 0                                                    // 0000000A67B0: BF800000
	s_nop 0                                                    // 0000000A67B4: BF800000
	s_nop 0                                                    // 0000000A67B8: BF800000
	s_nop 0                                                    // 0000000A67BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A67C0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000A67C4: 327C7A84
	.long 0xd4490001                                           // 0000000A67C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000A67CC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000A67D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000A67D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A67E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000A67E8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000A67F0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000A67F8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000A6800: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000A6808: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000A6810: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000A6818: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000A6820: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000A6824: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A6828: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000A682C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000A6838: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000A6840: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000A6844: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000A6848: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000A684C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6850: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000A6854: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000A6858: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000A685C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6860: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000A6864: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000A6870: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000A6878: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A6880: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A6884: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000A6888: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A688C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000A6890: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A6898: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A68A0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A68A4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A68A8: BF89FC07
	s_barrier                                                  // 0000000A68AC: BFBD0000
	buffer_gl0_inv                                             // 0000000A68B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000A68B8: BF800000
	s_nop 0                                                    // 0000000A68BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A68C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 0000000A68C8: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A68D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A68D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A68DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A68E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A68E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A68F0: BF870004
	.long 0xd4490004                                           // 0000000A68F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A68F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A6900: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A6904: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A6908: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A690C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A6914: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A691C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A6920: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A6924: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 0000000A6928: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 0000000A6930: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000A6938: BF89FC07
	s_barrier                                                  // 0000000A693C: BFBD0000
	buffer_gl0_inv                                             // 0000000A6940: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 0000000A6948: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 0000000A6950: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000A6958: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 0000000A6960: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000A6968: 7E780300
	s_mov_b32 s4, 0                                            // 0000000A696C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A6970: BF840001
	s_nop 0                                                    // 0000000A6974: BF800000
	s_nop 0                                                    // 0000000A6978: BF800000
	s_nop 0                                                    // 0000000A697C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A6980: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000A6984: 327A7884
	.long 0xd4490001                                           // 0000000A6988: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000A698C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000A6994: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000A6998: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A69A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000A69A8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000A69B0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000A69B8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000A69C0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000A69C8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000A69D0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000A69D8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000A69E0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000A69E4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A69F0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000A69F4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000A69F8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000A6A00: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000A6A04: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000A6A08: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000A6A0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6A10: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000A6A14: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000A6A18: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000A6A1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6A20: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000A6A24: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000A6A30: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000A6A38: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A6A40: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A6A44: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2880>
	s_set_inst_prefetch_distance 0x2                           // 0000000A6A48: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A6A4C: 8C7E047E
	.long 0xd7000107                                           // 0000000A6A50: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000A6A54: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A6A5C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000A6A60: D5207C08 00061080
	.long 0xd7000109                                           // 0000000A6A68: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000A6A6C: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000A6A74: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000A6A7C: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000A6A80: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A6A88: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000A6A8C: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000A6A94: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000A6A98: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000A6AA0: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000A6AA8: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000A6AAC: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A6AB4: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000A6AB8: D5207C10 00062080
	.long 0xd7000111                                           // 0000000A6AC0: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000A6AC4: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000A6ACC: D5207C12 00062480
	.long 0xd7000113                                           // 0000000A6AD4: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000A6AD8: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A6AE0: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000A6AE4: D5207C14 00062880
	.long 0xd7000115                                           // 0000000A6AEC: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000A6AF0: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000A6AF8: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000A6B00: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000A6B04: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A6B0C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000A6B10: D5207C18 00063080
	.long 0xd7000119                                           // 0000000A6B18: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000A6B1C: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000A6B24: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000A6B2C: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000A6B30: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A6B38: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000A6B3C: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000A6B44: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000A6B48: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000A6B4C: BF062105
	s_barrier                                                  // 0000000A6B50: BFBD0000
	buffer_gl0_inv                                             // 0000000A6B54: E0AC0000 00000000
	s_cbranch_scc0 63060                                       // 0000000A6B5C: BFA1F654 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b0>
	v_mov_b32_e32 v4, v38                                      // 0000000A6B60: 7E080326
	s_add_u32 s0, s28, s20                                     // 0000000A6B64: 8000141C
	.long 0xd73c0000                                           // 0000000A6B68: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000A6B6C: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000A6B70: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000A6B74: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000A6B78: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000A6B7C: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000A6B80: 82010103
	.long 0xd7006a00                                           // 0000000A6B84: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000A6B88: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000A6B8C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000A6B90: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000A6B98: BE810080
	.long 0xd7006a00                                           // 0000000A6B9C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 0000000A6BA0: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000A6BA4: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6BAC: BF870092
	.long 0xd7006a00                                           // 0000000A6BB0: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000A6BB4: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000A6BB8: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 0000000A6BC0: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000A6BC8: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 0000000A6BD0: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000A6BD8: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000A6BDC: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000A6BE4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000A6BE8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000A6BEC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000A6BF4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000A6BF8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000A6C00: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000A6C08: 917E017E
	s_cbranch_execnz 65516                                     // 0000000A6C0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ac0>
	s_endpgm                                                   // 0000000A6C10: BFB00000
		...

