00000000001d4400 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_clause 0x1                                               // 0000001D4400: BF850001
	s_load_b128 s[12:15], s[0:1], 0x20                         // 0000001D4404: F4080300 F8000020
	s_load_b128 s[16:19], s[0:1], 0x38                         // 0000001D440C: F4080400 F8000038
	s_mov_b32 s20, s3                                          // 0000001D4414: BE940003
	s_ashr_i32 s3, s2, 31                                      // 0000001D4418: 86039F02
	s_waitcnt lgkmcnt(0)                                       // 0000001D441C: BF89FC07
	s_load_b32 s22, s[14:15], null                             // 0000001D4420: F4000587 F8000000
	s_clause 0x1                                               // 0000001D4428: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 0000001D442C: F40C0100 F8000000
	s_load_b32 s15, s[0:1], 0x48                               // 0000001D4434: F40003C0 F8000048
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000001D443C: 84808202
	s_waitcnt lgkmcnt(0)                                       // 0000001D4440: BF89FC07
	s_add_i32 s22, s22, s2                                     // 0000001D4444: 81160216
	s_add_u32 s0, s18, s0                                      // 0000001D4448: 80000012
	s_addc_u32 s1, s19, s1                                     // 0000001D444C: 82010113
	s_add_i32 s3, s22, 1                                       // 0000001D4450: 81038116
	s_load_b32 s19, s[0:1], null                               // 0000001D4454: F40004C0 F8000000
	s_ashr_i32 s0, s3, 31                                      // 0000001D445C: 86009F03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001D4460: BF870499
	s_lshr_b32 s0, s0, 30                                      // 0000001D4464: 85009E00
	s_add_i32 s0, s3, s0                                       // 0000001D4468: 81000003
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001D446C: BF870009
	s_and_b32 s3, s0, -4                                       // 0000001D4470: 8B03C400
	s_ashr_i32 s14, s0, 2                                      // 0000001D4474: 860E8200
	s_sub_i32 s1, s22, s3                                      // 0000001D4478: 81810316
	s_mul_i32 s0, s15, s2                                      // 0000001D447C: 9600020F
	s_cmp_gt_i32 s1, -1                                        // 0000001D4480: BF02C101
	s_mul_hi_i32 s1, s15, s2                                   // 0000001D4484: 9701020F
	s_cselect_b32 s18, -1, 0                                   // 0000001D4488: 981280C1
	s_mov_b32 s15, s14                                         // 0000001D448C: BE8F000E
	s_and_b32 vcc_lo, exec_lo, s18                             // 0000001D4490: 8B6A127E
	s_cbranch_vccnz 15                                         // 0000001D4494: BFA4000F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd4>
	s_lshl_b64 s[24:25], s[0:1], 2                             // 0000001D4498: 84988200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001D449C: BF8704D9
	s_add_u32 s15, s16, s24                                    // 0000001D44A0: 800F1810
	s_addc_u32 s21, s17, s25                                   // 0000001D44A4: 82151911
	s_waitcnt lgkmcnt(0)                                       // 0000001D44A8: BF89FC07
	s_max_i32 s24, s19, 1                                      // 0000001D44AC: 8A188113
	s_mov_b32 s25, 0                                           // 0000001D44B0: BE990080
	s_lshl_b64 s[24:25], s[24:25], 2                           // 0000001D44B4: 84988218
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001D44B8: BF870009
	s_add_u32 s15, s15, s24                                    // 0000001D44BC: 800F180F
	s_addc_u32 s21, s21, s25                                   // 0000001D44C0: 82151915
	s_add_u32 s24, s15, -4                                     // 0000001D44C4: 8018C40F
	s_addc_u32 s25, s21, -1                                    // 0000001D44C8: 8219C115
	s_load_b32 s15, s[24:25], null                             // 0000001D44CC: F40003CC F8000000
	v_cndmask_b32_e64 v1, 0, 1, s18                            // 0000001D44D4: D5010001 00490280
	s_mov_b32 s24, exec_lo                                     // 0000001D44DC: BE98007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001D44E0: BF8704B1
	v_readfirstlane_b32 s18, v1                                // 0000001D44E4: 7E240501
	s_waitcnt lgkmcnt(0)                                       // 0000001D44E8: BF89FC07
	s_add_i32 s21, s19, s18                                    // 0000001D44EC: 81151213
	s_add_i32 s18, s21, 3                                      // 0000001D44F0: 81128315
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001D44F4: BF870499
	s_and_b32 s23, s18, -4                                     // 0000001D44F8: 8B17C412
	.long 0xd4c4007e                                           // 0000001D44FC: D4C4007E
	v_cndmask_b32_e32 v1, s23, v0, vcc_lo                      // 0000001D4500: 02020017
	s_cbranch_execz 46                                         // 0000001D4504: BFA5002E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1c0>
	v_dual_mov_b32 v4, v0 :: v_dual_lshlrev_b32 v3, 2, v0      // 0000001D4508: CA220100 04020082
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000001D4510: 84808200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D4514: BF8700A9
	s_add_u32 s0, s16, s0                                      // 0000001D4518: 80000010
	s_addc_u32 s1, s17, s1                                     // 0000001D451C: 82010111
	.long 0xd7000001                                           // 0000001D4520: D7000001
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000001D4524: 02020600
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D4528: BF870001
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 0000001D452C: D5207C02 00010001
	s_mov_b32 s1, 0                                            // 0000001D4534: BE810080
	s_set_inst_prefetch_distance 0x1                           // 0000001D4538: BF840001
	s_branch 19                                                // 0000001D453C: BFA00013 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x18c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001D4540: 8C7E007E
	v_add_nc_u32_e32 v6, 0x200, v3                             // 0000001D4544: 4A0C06FF 00000200
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001D454C: 4A0808FF 00000080
	s_waitcnt vmcnt(0)                                         // 0000001D4554: BF8903F7
	ds_store_b32 v3, v5 offset:512                             // 0000001D4558: D8340200 00000503
	.long 0xd7000001                                           // 0000001D4560: D7000001
	v_cndmask_b32_e32 v1, 0x200, v1, vcc_lo                    // 0000001D4564: 020202FF 00000200
	v_mov_b32_e32 v3, v6                                       // 0000001D456C: 7E060306
	v_cmp_le_i32_e32 vcc_lo, s23, v4                           // 0000001D4570: 7C860817
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001D4574: D5207C02 00020480
	s_or_b32 s1, vcc_lo, s1                                    // 0000001D457C: 8C01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001D4580: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001D4584: 917E017E
	s_cbranch_execz 13                                         // 0000001D4588: BFA5000D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1c0>
	s_mov_b32 s0, exec_lo                                      // 0000001D458C: BE80007E
	.long 0xd4c3007e                                           // 0000001D4590: D4C3007E
	v_cndmask_b32_e32 v1, s19, v4, vcc_lo                      // 0000001D4594: 02020813
	s_xor_b32 s0, exec_lo, s0                                  // 0000001D4598: 8D00007E
	v_mov_b32_e32 v5, s14                                      // 0000001D459C: 7E0A020E
	v_cmp_gt_i32_e32 vcc_lo, s21, v4                           // 0000001D45A0: 7C880815
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001D45A4: BF870002
	v_cndmask_b32_e32 v5, s15, v5, vcc_lo                      // 0000001D45A8: 020A0A0F
	s_and_not1_saveexec_b32 s0, s0                             // 0000001D45AC: BE803000
	s_cbranch_execz 65507                                      // 0000001D45B0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	global_load_b32 v5, v[1:2], off                            // 0000001D45B4: DC520000 057C0001
	s_branch 65504                                             // 0000001D45BC: BFA0FFE0 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	s_set_inst_prefetch_distance 0x2                           // 0000001D45C0: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 0000001D45C4: 8C7E187E
	v_dual_mov_b32 v110, 0 :: v_dual_and_b32 v105, 15, v0      // 0000001D45C8: CA240080 6E68008F
	v_bfe_u32 v108, v0, 4, 1                                   // 0000001D45D0: D610006C 02050900
	s_mul_i32 s16, s20, 12                                     // 0000001D45D8: 96108C14
	s_mul_hi_i32 s15, s2, 0x1800                               // 0000001D45DC: 970FFF02 00001800
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001D45E4: BF870002
	v_cmp_gt_u32_e32 vcc_lo, 12, v105                          // 0000001D45E8: 7C98D28C
	s_mul_i32 s14, s2, 0x1800                                  // 0000001D45EC: 960EFF02 00001800
	v_lshrrev_b32_e32 v106, 5, v0                              // 0000001D45F4: 32D40085
	s_lshl_b64 s[0:1], s[14:15], 1                             // 0000001D45F8: 8480810E
	s_ashr_i32 s17, s18, 2                                     // 0000001D45FC: 86118212
	v_dual_cndmask_b32 v1, 0, v105 :: v_dual_lshlrev_b32 v104, 5, v108// 0000001D4600: CA62D280 0168D885
	s_add_u32 s0, s4, s0                                       // 0000001D4608: 80000004
	s_addc_u32 s1, s5, s1                                      // 0000001D460C: 82010105
	v_lshlrev_b32_e32 v107, 6, v106                            // 0000001D4610: 30D6D486
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001D4614: BF8700B2
	v_add_lshl_u32 v1, v1, s16, 8                              // 0000001D4618: D6470001 02202101
	s_mov_b32 s18, 0                                           // 0000001D4620: BE920080
	s_cmp_gt_i32 s17, 0                                        // 0000001D4624: BF028011
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000001D4628: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D462C: BF870121
	.long 0xd73c0002                                           // 0000001D4630: D73C0002
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000001D4634: 02020281
	v_lshlrev_b32_e32 v1, 7, v106                              // 0000001D4638: 3002D487
	.long 0xd7006a02                                           // 0000001D463C: D7006A02
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 0000001D4640: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D4644: BF870111
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 0000001D4648: D5207C03 01AA0601
	.long 0xd7006a02                                           // 0000001D4650: D7006A02
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000001D4654: 02020302
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D4658: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000001D465C: D5207C03 01AA0680
	s_clause 0x7                                               // 0000001D4664: BF850007
	global_load_b128 v[36:39], v[2:3], off offset:16           // 0000001D4668: DC5E0010 247C0002
	global_load_b128 v[32:35], v[2:3], off                     // 0000001D4670: DC5E0000 207C0002
	global_load_b128 v[44:47], v[2:3], off offset:48           // 0000001D4678: DC5E0030 2C7C0002
	global_load_b128 v[40:43], v[2:3], off offset:32           // 0000001D4680: DC5E0020 287C0002
	global_load_b128 v[52:55], v[2:3], off offset:80           // 0000001D4688: DC5E0050 347C0002
	global_load_b128 v[48:51], v[2:3], off offset:64           // 0000001D4690: DC5E0040 307C0002
	global_load_b128 v[60:63], v[2:3], off offset:112          // 0000001D4698: DC5E0070 3C7C0002
	global_load_b128 v[56:59], v[2:3], off offset:96           // 0000001D46A0: DC5E0060 387C0002
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001D46A8: BF890007
	s_barrier                                                  // 0000001D46AC: BFBD0000
	buffer_gl0_inv                                             // 0000001D46B0: E0AC0000 00000000
	s_cbranch_scc0 529                                         // 0000001D46B8: BFA10211 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xb00>
	v_dual_mov_b32 v109, 0 :: v_dual_lshlrev_b32 v2, 6, v108   // 0000001D46BC: CA220080 6D02D886
	s_ashr_i32 s21, s20, 31                                    // 0000001D46C4: 86159F14
	v_dual_mov_b32 v64, 0 :: v_dual_lshlrev_b32 v115, 5, v105  // 0000001D46C8: CA220080 4072D285
	v_lshlrev_b32_e32 v4, 9, v106                              // 0000001D46D0: 3008D489
	v_lshlrev_b32_e32 v0, 5, v0                                // 0000001D46D4: 30000085
	s_lshl_b64 s[0:1], s[20:21], 11                            // 0000001D46D8: 84808B14
	v_lshl_or_b32 v2, v105, 2, v2                              // 0000001D46DC: D6560002 04090569
	s_add_u32 s0, s6, s0                                       // 0000001D46E4: 80000006
	s_addc_u32 s1, s7, s1                                      // 0000001D46E8: 82010107
	v_mov_b32_e32 v65, v64                                     // 0000001D46EC: 7E820340
	.long 0xd7000004                                           // 0000001D46F0: D7000004
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 0000001D46F4: 02020800
	v_dual_mov_b32 v67, v64 :: v_dual_and_b32 v0, 0x60, v0     // 0000001D46F8: CA240140 430000FF 00000060
	v_dual_mov_b32 v71, v64 :: v_dual_add_nc_u32 v2, 0x2210, v2// 0000001D4704: CA200140 470204FF 00002210
	v_mov_b32_e32 v69, v64                                     // 0000001D4710: 7E8A0340
	v_add_co_ci_u32_e64 v5, null, s1, 0, s0                    // 0000001D4714: D5207C05 00010001
	s_lshl_b64 s[0:1], s[20:21], 8                             // 0000001D471C: 84808814
	v_lshlrev_b32_e32 v3, 8, v106                              // 0000001D4720: 3006D488
	.long 0xd7006a6f                                           // 0000001D4724: D7006A6F
	v_cndmask_b32_e32 v1, v4, v0, vcc_lo                       // 0000001D4728: 02020104
	v_or_b32_e32 v0, s0, v105                                  // 0000001D472C: 3800D200
	v_add_co_ci_u32_e64 v112, null, 0, v5, vcc_lo              // 0000001D4730: D5207C70 01AA0A80
	v_or_b32_e32 v113, 0x3210, v104                            // 0000001D4738: 38E2D0FF 00003210
	v_mov_b32_e32 v4, s1                                       // 0000001D4740: 7E080201
	v_lshl_or_b32 v5, v105, 1, v104                            // 0000001D4744: D6560005 05A10369
	v_or_b32_e32 v6, 64, v1                                    // 0000001D474C: 380C02C0
	v_dual_mov_b32 v127, 0xf149f2ca :: v_dual_add_nc_u32 v120, v2, v3// 0000001D4750: CA2000FF 7F780702 F149F2CA
	.long 0xd7006a75                                           // 0000001D475C: D7006A75
	v_cndmask_b32_e32 v1, v0, v107, vcc_lo                     // 0000001D4760: 0202D700
	s_lshl2_add_u32 s0, s19, s22                               // 0000001D4764: 87801613
	v_lshl_or_b32 v114, v106, 10, v2                           // 0000001D4768: D6560072 0409156A
	v_lshl_add_u32 v116, v106, 3, v113                         // 0000001D4770: D6460074 05C5076A
	v_add_co_ci_u32_e64 v118, null, 0, v4, vcc_lo              // 0000001D4778: D5207C76 01AA0880
	v_dual_mov_b32 v126, 0xf149f2ca :: v_dual_and_b32 v119, 12, v105// 0000001D4780: CA2400FF 7E76D28C F149F2CA
	v_dual_mov_b32 v66, v64 :: v_dual_add_nc_u32 v121, v5, v1  // 0000001D478C: CA200140 42780305
	v_dual_mov_b32 v68, v64 :: v_dual_add_nc_u32 v123, 0x400, v120// 0000001D4794: CA200140 447AF0FF 00000400
	v_dual_mov_b32 v70, v64 :: v_dual_add_nc_u32 v125, 0xc00, v120// 0000001D47A0: CA200140 467CF0FF 00000C00
	v_add_nc_u32_e32 v122, v5, v6                              // 0000001D47AC: 4AF40D05
	v_dual_mov_b32 v25, v109 :: v_dual_add_nc_u32 v124, 0x800, v120// 0000001D47B0: CA20016D 197CF0FF 00000800
	v_dual_mov_b32 v110, 0 :: v_dual_mov_b32 v27, v109         // 0000001D47BC: CA100080 6E1A016D
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v29, v109          // 0000001D47C4: CA100080 181C016D
	v_mov_b32_e32 v26, v109                                    // 0000001D47CC: 7E34036D
	v_mov_b32_e32 v28, v109                                    // 0000001D47D0: 7E38036D
	v_mov_b32_e32 v30, v109                                    // 0000001D47D4: 7E3C036D
	v_dual_mov_b32 v31, v109 :: v_dual_mov_b32 v16, 0          // 0000001D47D8: CA10016D 1F100080
	v_dual_mov_b32 v17, v109 :: v_dual_mov_b32 v8, 0           // 0000001D47E0: CA10016D 11080080
	v_mov_b32_e32 v18, v109                                    // 0000001D47E8: 7E24036D
	v_dual_mov_b32 v19, v109 :: v_dual_mov_b32 v0, 0           // 0000001D47EC: CA10016D 13000080
	v_mov_b32_e32 v20, v109                                    // 0000001D47F4: 7E28036D
	v_mov_b32_e32 v21, v109                                    // 0000001D47F8: 7E2A036D
	v_mov_b32_e32 v22, v109                                    // 0000001D47FC: 7E2C036D
	v_mov_b32_e32 v23, v109                                    // 0000001D4800: 7E2E036D
	v_mov_b32_e32 v9, v109                                     // 0000001D4804: 7E12036D
	v_mov_b32_e32 v10, v109                                    // 0000001D4808: 7E14036D
	v_mov_b32_e32 v11, v109                                    // 0000001D480C: 7E16036D
	v_mov_b32_e32 v12, v109                                    // 0000001D4810: 7E18036D
	v_mov_b32_e32 v13, v109                                    // 0000001D4814: 7E1A036D
	v_mov_b32_e32 v14, v109                                    // 0000001D4818: 7E1C036D
	v_mov_b32_e32 v15, v109                                    // 0000001D481C: 7E1E036D
	v_mov_b32_e32 v1, v109                                     // 0000001D4820: 7E02036D
	v_mov_b32_e32 v2, v109                                     // 0000001D4824: 7E04036D
	v_mov_b32_e32 v3, v109                                     // 0000001D4828: 7E06036D
	v_mov_b32_e32 v4, v109                                     // 0000001D482C: 7E08036D
	v_mov_b32_e32 v5, v109                                     // 0000001D4830: 7E0A036D
	v_mov_b32_e32 v6, v109                                     // 0000001D4834: 7E0C036D
	v_mov_b32_e32 v7, v109                                     // 0000001D4838: 7E0E036D
	s_sub_i32 s0, s0, s3                                       // 0000001D483C: 81800300
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001D4840: BF870009
	s_add_i32 s7, s0, 1                                        // 0000001D4844: 81078100
	v_dual_mov_b32 v73, s18 :: v_dual_add_nc_u32 v72, s18, v119// 0000001D4848: CA200012 4948EE12
	s_add_i32 s17, s17, -1                                     // 0000001D4850: 8111C111
	s_add_i32 s18, s18, 16                                     // 0000001D4854: 81129012
	ds_load_b32 v77, v72 offset:512                            // 0000001D4858: D8D80200 4D000048
	ds_load_b128 v[72:75], v73 offset:512                      // 0000001D4860: DBFC0200 48000049
	s_waitcnt lgkmcnt(1)                                       // 0000001D4868: BF89FC17
	v_ashrrev_i32_e32 v78, 31, v77                             // 0000001D486C: 349C9A9F
	s_waitcnt lgkmcnt(0)                                       // 0000001D4870: BF89FC07
	v_ashrrev_i32_e32 v129, 31, v72                            // 0000001D4874: 3502909F
	v_mov_b32_e32 v128, v72                                    // 0000001D4878: 7F000348
	v_ashrrev_i32_e32 v131, 31, v73                            // 0000001D487C: 3506929F
	v_mov_b32_e32 v130, v73                                    // 0000001D4880: 7F040349
	.long 0xd73c0048                                           // 0000001D4884: D73C0048
	v_cndmask_b32_e32 v1, 12, v77, vcc_lo                      // 0000001D4888: 02029A8C
	v_ashrrev_i32_e32 v76, 31, v75                             // 0000001D488C: 3498969F
	v_ashrrev_i32_e32 v133, 31, v74                            // 0000001D4890: 350A949F
	v_mov_b32_e32 v132, v74                                    // 0000001D4894: 7F08034A
	.long 0xd73c0080                                           // 0000001D4898: D73C0080
	v_cndmask_b32_e32 v1, 9, v128, vcc_lo                      // 0000001D489C: 02030089
	.long 0xd73c0082                                           // 0000001D48A0: D73C0082
	v_cndmask_b32_e32 v1, 9, v130, vcc_lo                      // 0000001D48A4: 02030489
	.long 0xd7006a60                                           // 0000001D48A8: D7006A60
	v_cndmask_b32_e32 v1, v111, v72, vcc_lo                    // 0000001D48AC: 0202916F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D48B0: BF870001
	v_add_co_ci_u32_e64 v97, null, v112, v73, vcc_lo           // 0000001D48B4: D5207C61 01AA9370
	.long 0xd73c0086                                           // 0000001D48BC: D73C0086
	v_cndmask_b32_e32 v1, 9, v75, vcc_lo                       // 0000001D48C0: 02029689
	.long 0xd7006a80                                           // 0000001D48C4: D7006A80
	v_cndmask_b32_e32 v1, v128, v117, vcc_lo                   // 0000001D48C8: 0202EB80
	s_clause 0x7                                               // 0000001D48CC: BF850007
	global_load_b128 v[76:79], v[96:97], off offset:16         // 0000001D48D0: DC5E0010 4C7C0060
	global_load_b128 v[72:75], v[96:97], off                   // 0000001D48D8: DC5E0000 487C0060
	global_load_b128 v[84:87], v[96:97], off offset:144        // 0000001D48E0: DC5E0090 547C0060
	global_load_b128 v[80:83], v[96:97], off offset:128        // 0000001D48E8: DC5E0080 507C0060
	global_load_b128 v[92:95], v[96:97], off offset:272        // 0000001D48F0: DC5E0110 5C7C0060
	global_load_b128 v[88:91], v[96:97], off offset:256        // 0000001D48F8: DC5E0100 587C0060
	global_load_b128 v[100:103], v[96:97], off offset:400      // 0000001D4900: DC5E0190 647C0060
	global_load_b128 v[96:99], v[96:97], off offset:384        // 0000001D4908: DC5E0180 607C0060
	v_add_co_ci_u32_e64 v129, null, v129, v118, vcc_lo         // 0000001D4910: D5207C81 01AAED81
	.long 0xd73c0084                                           // 0000001D4918: D73C0084
	v_cndmask_b32_e32 v1, 9, v132, vcc_lo                      // 0000001D491C: 02030889
	.long 0xd7006a82                                           // 0000001D4920: D7006A82
	v_cndmask_b32_e32 v1, v130, v117, vcc_lo                   // 0000001D4924: 0202EB82
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D4928: BF870223
	.long 0xd73c0080                                           // 0000001D492C: D73C0080
	v_cndmask_b32_e32 v1, 3, v128, vcc_lo                      // 0000001D4930: 02030083
	v_add_co_ci_u32_e64 v131, null, v131, v118, vcc_lo         // 0000001D4934: D5207C83 01AAED83
	.long 0xd7006a84                                           // 0000001D493C: D7006A84
	v_cndmask_b32_e32 v1, v132, v117, vcc_lo                   // 0000001D4940: 0202EB84
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D4944: BF8700A1
	v_add_co_ci_u32_e64 v133, null, v133, v118, vcc_lo         // 0000001D4948: D5207C85 01AAED85
	.long 0xd7006a86                                           // 0000001D4950: D7006A86
	v_cndmask_b32_e32 v1, v134, v117, vcc_lo                   // 0000001D4954: 0202EB86
	v_add_co_ci_u32_e64 v135, null, v135, v118, vcc_lo         // 0000001D4958: D5207C87 01AAED87
	.long 0xd7006a88                                           // 0000001D4960: D7006A88
	v_cndmask_b32_e32 v1, s8, v128, vcc_lo                     // 0000001D4964: 02030008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D4968: BF8700A1
	v_add_co_ci_u32_e64 v137, null, s9, v129, vcc_lo           // 0000001D496C: D5207C89 01AB0209
	.long 0xd73c0080                                           // 0000001D4974: D73C0080
	v_cndmask_b32_e32 v1, 3, v130, vcc_lo                      // 0000001D4978: 02030483
	.long 0xd7006a8a                                           // 0000001D497C: D7006A8A
	v_cndmask_b32_e32 v1, s8, v128, vcc_lo                     // 0000001D4980: 02030008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D4984: BF8700A1
	v_add_co_ci_u32_e64 v139, null, s9, v129, vcc_lo           // 0000001D4988: D5207C8B 01AB0209
	.long 0xd73c0080                                           // 0000001D4990: D73C0080
	v_cndmask_b32_e32 v1, 3, v132, vcc_lo                      // 0000001D4994: 02030883
	.long 0xd7006a8c                                           // 0000001D4998: D7006A8C
	v_cndmask_b32_e32 v1, s8, v128, vcc_lo                     // 0000001D499C: 02030008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D49A0: BF8700A1
	v_add_co_ci_u32_e64 v141, null, s9, v129, vcc_lo           // 0000001D49A4: D5207C8D 01AB0209
	.long 0xd73c0080                                           // 0000001D49AC: D73C0080
	v_cndmask_b32_e32 v1, 3, v134, vcc_lo                      // 0000001D49B0: 02030C83
	.long 0xd7006a8e                                           // 0000001D49B4: D7006A8E
	v_cndmask_b32_e32 v1, s8, v128, vcc_lo                     // 0000001D49B8: 02030008
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D49BC: BF870001
	v_add_co_ci_u32_e64 v143, null, s9, v129, vcc_lo           // 0000001D49C0: D5207C8F 01AB0209
	v_cmp_gt_i32_e32 vcc_lo, s7, v105                          // 0000001D49C8: 7C88D207
	s_add_i32 s7, s7, -16                                      // 0000001D49CC: 8107D007
	s_cmp_eq_u32 s17, 0                                        // 0000001D49D0: BF068011
	s_waitcnt vmcnt(6)                                         // 0000001D49D4: BF891BF7
	v_wmma_f32_16x16x16_bf16 v[128:135], v[32:39], v[72:79], v[64:71]// 0000001D49D8: CC414080 1D029120
	global_load_b64 v[74:75], v[138:139], off                  // 0000001D49E0: DC560000 4A7C008A
	s_waitcnt vmcnt(5)                                         // 0000001D49E8: BF8917F7
	v_wmma_f32_16x16x16_bf16 v[128:135], v[40:47], v[80:87], v[128:135]// 0000001D49EC: CC414080 1E02A128
	global_load_b64 v[82:83], v[138:139], off offset:128       // 0000001D49F4: DC560080 527C008A
	s_waitcnt vmcnt(4)                                         // 0000001D49FC: BF8913F7
	v_wmma_f32_16x16x16_bf16 v[128:135], v[48:55], v[88:95], v[128:135]// 0000001D4A00: CC414080 1E02B130
	s_waitcnt vmcnt(2)                                         // 0000001D4A08: BF890BF7
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D4A0C: BF870001
	v_wmma_f32_16x16x16_bf16 v[128:135], v[56:63], v[96:103], v[128:135]// 0000001D4A10: CC414080 1E02C138
	s_clause 0xd                                               // 0000001D4A18: BF85000D
	global_load_b64 v[90:91], v[138:139], off offset:256       // 0000001D4A1C: DC560100 5A7C008A
	global_load_b64 v[72:73], v[136:137], off                  // 0000001D4A24: DC560000 487C0088
	global_load_b64 v[80:81], v[136:137], off offset:128       // 0000001D4A2C: DC560080 507C0088
	global_load_b64 v[88:89], v[136:137], off offset:256       // 0000001D4A34: DC560100 587C0088
	global_load_b64 v[96:97], v[136:137], off offset:384       // 0000001D4A3C: DC560180 607C0088
	global_load_b64 v[98:99], v[138:139], off offset:384       // 0000001D4A44: DC560180 627C008A
	global_load_b64 v[76:77], v[140:141], off                  // 0000001D4A4C: DC560000 4C7C008C
	global_load_b64 v[84:85], v[140:141], off offset:128       // 0000001D4A54: DC560080 547C008C
	global_load_b64 v[92:93], v[140:141], off offset:256       // 0000001D4A5C: DC560100 5C7C008C
	global_load_b64 v[100:101], v[140:141], off offset:384     // 0000001D4A64: DC560180 647C008C
	global_load_b64 v[78:79], v[142:143], off                  // 0000001D4A6C: DC560000 4E7C008E
	global_load_b64 v[86:87], v[142:143], off offset:128       // 0000001D4A74: DC560080 567C008E
	global_load_b64 v[94:95], v[142:143], off offset:256       // 0000001D4A7C: DC560100 5E7C008E
	global_load_b64 v[102:103], v[142:143], off offset:384     // 0000001D4A84: DC560180 667C008E
	ds_store_2addr_b32 v114, v128, v129 offset1:32             // 0000001D4A8C: D8382000 00818072
	ds_store_2addr_b32 v114, v130, v131 offset0:64 offset1:96  // 0000001D4A94: D8386040 00838272
	ds_store_2addr_b32 v114, v132, v133 offset0:128 offset1:160// 0000001D4A9C: D838A080 00858472
	ds_store_2addr_b32 v114, v134, v135 offset0:192 offset1:224// 0000001D4AA4: D838E0C0 00878672
	s_waitcnt lgkmcnt(0)                                       // 0000001D4AAC: BF89FC07
	s_barrier                                                  // 0000001D4AB0: BFBD0000
	ds_load_2addr_b32 v[128:129], v120 offset1:32              // 0000001D4AB4: D8DC2000 80000078
	ds_load_2addr_b32 v[130:131], v123 offset1:32              // 0000001D4ABC: D8DC2000 8200007B
	ds_load_2addr_b32 v[132:133], v124 offset1:32              // 0000001D4AC4: D8DC2000 8400007C
	ds_load_2addr_b32 v[134:135], v125 offset1:32              // 0000001D4ACC: D8DC2000 8600007D
	s_waitcnt lgkmcnt(2)                                       // 0000001D4AD4: BF89FC27
	v_add_f32_e32 v129, v129, v131                             // 0000001D4AD8: 07030781
	s_waitcnt lgkmcnt(1)                                       // 0000001D4ADC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D4AE0: BF8700A1
	v_dual_add_f32 v129, v129, v133 :: v_dual_add_f32 v128, v128, v130// 0000001D4AE4: C9090B81 81810580
	s_waitcnt lgkmcnt(0)                                       // 0000001D4AEC: BF89FC07
	v_add_f32_e32 v129, v129, v135                             // 0000001D4AF0: 07030F81
	v_mov_b32_e32 v135, v110                                   // 0000001D4AF4: 7F0E036E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D4AF8: BF870092
	v_dual_mul_f32 v129, 0x3d800000, v129 :: v_dual_add_f32 v128, v128, v132// 0000001D4AFC: C8C902FF 81810980 3D800000
	v_cndmask_b32_e32 v129, 0xf149f2ca, v129, vcc_lo           // 0000001D4B08: 030302FF F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D4B10: BF870091
	v_mov_b32_dpp v131, v129 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D4B14: 7F0602FA FF096181
	v_dual_add_f32 v128, v128, v134 :: v_dual_max_f32 v131, v131, v131// 0000001D4B1C: C9150D80 80830783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D4B24: BF870091
	v_dual_mul_f32 v128, 0x3d800000, v128 :: v_dual_max_f32 v131, v129, v131// 0000001D4B28: C8D500FF 80830781 3D800000
	v_mov_b32_dpp v133, v131 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D4B34: 7F0A02FA FF096283
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D4B3C: BF870091
	v_dual_cndmask_b32 v128, 0xf149f2ca, v128 :: v_dual_max_f32 v133, v133, v133// 0000001D4B40: CA5500FF 80850B85 F149F2CA
	v_mov_b32_dpp v130, v128 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D4B4C: 7F0402FA FF096180
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D4B54: BF870091
	v_dual_max_f32 v131, v131, v133 :: v_dual_max_f32 v130, v130, v130// 0000001D4B58: CA950B83 83830582
	v_mov_b32_dpp v133, v131 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D4B60: 7F0A02FA FF096483
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D4B68: BF870091
	v_dual_max_f32 v130, v128, v130 :: v_dual_max_f32 v133, v133, v133// 0000001D4B6C: CA950580 82850B85
	v_mov_b32_dpp v132, v130 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D4B74: 7F0802FA FF096282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D4B7C: BF870091
	v_dual_max_f32 v131, v131, v133 :: v_dual_max_f32 v132, v132, v132// 0000001D4B80: CA950B83 83850984
	v_mov_b32_dpp v133, v131 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D4B88: 7F0A02FA FF096883
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D4B90: BF870091
	v_max3_f32 v137, v127, v131, v133                          // 0000001D4B94: D61C0089 0617077F
	v_dual_max_f32 v130, v130, v132 :: v_dual_sub_f32 v129, v129, v137// 0000001D4B9C: CA8B0982 82811381
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D4BA4: BF870121
	v_mov_b32_dpp v132, v130 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D4BA8: 7F0802FA FF096482
	v_sub_f32_e32 v127, v127, v137                             // 0000001D4BB0: 08FF137F
	v_dual_mul_f32 v131, 0x3fb8aa3b, v129 :: v_dual_max_f32 v132, v132, v132// 0000001D4BB4: C8D502FF 83850984 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001D4BC0: BF870002
	v_mul_f32_e32 v133, 0x3fb8aa3b, v127                       // 0000001D4BC4: 110AFEFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v129                 // 0000001D4BCC: 7C3702FF C2CE8ED0
	.long 0xd41e0004                                           // 0000001D4BD4: D41E0004
	v_cndmask_b32_e32 v1, 0x42b17218, v129, vcc_lo             // 0000001D4BD8: 020302FF 42B17218
	.long 0xd41b0001                                           // 0000001D4BE0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v127, vcc_lo             // 0000001D4BE4: 0202FEFF C2CE8ED0
	v_max_f32_e32 v130, v130, v132                             // 0000001D4BEC: 21050982
	.long 0xd41e0005                                           // 0000001D4BF0: D41E0005
	v_cndmask_b32_e32 v1, 0x42b17218, v127, vcc_lo             // 0000001D4BF4: 0202FEFF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D4BFC: BF870092
	v_mov_b32_dpp v132, v130 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D4C00: 7F0802FA FF096882
	v_max3_f32 v136, v126, v130, v132                          // 0000001D4C08: D61C0088 0613057E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D4C10: BF870121
	v_sub_f32_e32 v126, v126, v136                             // 0000001D4C14: 08FD117E
	v_sub_f32_e32 v128, v128, v136                             // 0000001D4C18: 09011180
	v_mul_f32_e32 v130, 0x3fb8aa3b, v126                       // 0000001D4C1C: 1104FCFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001D4C24: BF870002
	v_mul_f32_e32 v132, 0x3fb8aa3b, v128                       // 0000001D4C28: 110900FF 3FB8AA3B
	.long 0xd41b0002                                           // 0000001D4C30: D41B0002
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v126, vcc_lo             // 0000001D4C34: 0202FCFF C2CE8ED0
	.long 0xd41e0003                                           // 0000001D4C3C: D41E0003
	v_cndmask_b32_e32 v1, 0x42b17218, v126, vcc_lo             // 0000001D4C40: 0202FCFF 42B17218
	.long 0xd41b0000                                           // 0000001D4C48: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v128, vcc_lo             // 0000001D4C4C: 020300FF C2CE8ED0
	v_fma_f32 v134, 0x3fb8aa3b, v126, -v130                    // 0000001D4C54: D6130086 860AFCFF 3FB8AA3B
	.long 0xd41e0006                                           // 0000001D4C60: D41E0006
	v_cndmask_b32_e32 v1, 0x42b17218, v128, vcc_lo             // 0000001D4C64: 020300FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D4C6C: BF8700A2
	v_fmac_f32_e32 v134, 0x32a5705f, v126                      // 0000001D4C70: 570CFCFF 32A5705F
	v_fma_f32 v126, 0x3fb8aa3b, v129, -v131                    // 0000001D4C78: D613007E 860F02FF 3FB8AA3B
	v_fmac_f32_e32 v126, 0x32a5705f, v129                      // 0000001D4C84: 56FD02FF 32A5705F
	v_fma_f32 v129, 0x3fb8aa3b, v128, -v132                    // 0000001D4C8C: D6130081 861300FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D4C98: BF8700A1
	v_fmac_f32_e32 v129, 0x32a5705f, v128                      // 0000001D4C9C: 570300FF 32A5705F
	v_fma_f32 v128, 0x3fb8aa3b, v127, -v133                    // 0000001D4CA4: D6130080 8616FEFF 3FB8AA3B
	v_fmac_f32_e32 v128, 0x32a5705f, v127                      // 0000001D4CB0: 5700FEFF 32A5705F
	v_rndne_f32_e32 v127, v130                                 // 0000001D4CB8: 7EFE4782
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D4CBC: BF870121
	v_sub_f32_e32 v130, v130, v127                             // 0000001D4CC0: 0904FF82
	v_cvt_i32_f32_e32 v127, v127                               // 0000001D4CC4: 7EFE117F
	v_add_f32_e32 v130, v130, v134                             // 0000001D4CC8: 07050D82
	v_rndne_f32_e32 v134, v131                                 // 0000001D4CCC: 7F0C4783
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D4CD0: BF870092
	v_exp_f32_e32 v130, v130                                   // 0000001D4CD4: 7F044B82
	v_sub_f32_e32 v131, v131, v134                             // 0000001D4CD8: 09070D83
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001D4CDC: BF8702A1
	v_add_f32_e32 v126, v131, v126                             // 0000001D4CE0: 06FCFD83
	v_rndne_f32_e32 v131, v132                                 // 0000001D4CE4: 7F064784
	.long 0xd71c007f                                           // 0000001D4CE8: D71C007F
	v_cndmask_b32_e32 v1, v130, v127, vcc_lo                   // 0000001D4CEC: 0202FF82
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D4CF0: BF870113
	v_exp_f32_e32 v126, v126                                   // 0000001D4CF4: 7EFC4B7E
	v_sub_f32_e32 v132, v132, v131                             // 0000001D4CF8: 09090784
	v_cvt_i32_f32_e32 v110, v131                               // 0000001D4CFC: 7EDC1183
	v_cvt_i32_f32_e32 v131, v134                               // 0000001D4D00: 7F061186
	v_cndmask_b32_e64 v127, 0, v127, s2                        // 0000001D4D04: D501007F 000AFE80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D4D0C: BF870004
	v_add_f32_e32 v129, v132, v129                             // 0000001D4D10: 07030384
	v_rndne_f32_e32 v132, v133                                 // 0000001D4D14: 7F084785
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 0000001D4D18: BF870205
	.long 0xd71c007e                                           // 0000001D4D1C: D71C007E
	v_cndmask_b32_e32 v1, v126, v131, vcc_lo                   // 0000001D4D20: 0203077E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D4D24: BF870113
	v_exp_f32_e32 v129, v129                                   // 0000001D4D28: 7F024B81
	v_sub_f32_e32 v133, v133, v132                             // 0000001D4D2C: 090B0985
	v_cvt_i32_f32_e32 v132, v132                               // 0000001D4D30: 7F081184
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D4D34: BF870193
	v_cndmask_b32_e32 v126, 0, v126, vcc_lo                    // 0000001D4D38: 02FCFC80
	v_add_f32_e32 v128, v133, v128                             // 0000001D4D3C: 07010185
	.long 0xd59c4085                                           // 0000001D4D40: D59C4085
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 0000001D4D44: 02010080
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D4D48: BF870195
	.long 0xd71c006e                                           // 0000001D4D4C: D71C006E
	v_cndmask_b32_e32 v1, v129, v110, vcc_lo                   // 0000001D4D50: 0202DD81
	v_exp_f32_e32 v128, v128                                   // 0000001D4D54: 7F004B80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D4D58: BF870112
	.long 0xd59c4881                                           // 0000001D4D5C: D59C4881
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 0000001D4D60: 02010185
	v_cndmask_b32_e64 v110, 0, v110, s0                        // 0000001D4D64: D501006E 0002DC80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001D4D6C: BF870291
	v_cndmask_b32_e64 v130, 0x7f800000, v110, s6               // 0000001D4D70: D5010082 001ADCFF 7F800000
	.long 0xd71c0080                                           // 0000001D4D7C: D71C0080
	v_cndmask_b32_e32 v1, v128, v132, vcc_lo                   // 0000001D4D80: 02030980
	v_cndmask_b32_e64 v110, 0x7f800000, v126, s4               // 0000001D4D84: D501006E 0012FCFF 7F800000
	v_cndmask_b32_e64 v126, 0x7f800000, v127, s3               // 0000001D4D90: D501007E 000EFEFF 7F800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D4D9C: BF870214
	.long 0xd59c0881                                           // 0000001D4DA0: D59C0881
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                   // 0000001D4DA4: 02010182
	v_cndmask_b32_e64 v128, 0, v128, s1                        // 0000001D4DA8: D5010080 00070080
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D4DB0: BF870214
	.long 0xd59c0885                                           // 0000001D4DB4: D59C0885
	v_cndmask_b32_e32 v0, v110, v128, vcc_lo                   // 0000001D4DB8: 0201016E
	v_fma_f32 v109, v109, v126, v130                           // 0000001D4DBC: D613006D 060AFD6D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D4DC4: BF870193
	v_cndmask_b32_e64 v127, 0x7f800000, v128, s5               // 0000001D4DC8: D501007F 001700FF 7F800000
	v_and_b32_e32 v128, 1, v133                                // 0000001D4DD4: 37010A81
	ds_store_b64 v116, v[126:127]                              // 0000001D4DD8: D9340000 00007E74
	v_and_b32_e32 v126, 1, v129                                // 0000001D4DE0: 36FD0281
	v_add3_u32 v128, v110, v128, 0x7fff                        // 0000001D4DE4: D6550080 03FF016E 00007FFF
	v_fmac_f32_e32 v110, v135, v127                            // 0000001D4DF0: 56DCFF87
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D4DF4: BF870003
	v_add3_u32 v126, v130, v126, 0x7fff                        // 0000001D4DF8: D655007E 03FEFD82 00007FFF
	ds_store_b16_d16_hi v121, v126                             // 0000001D4E04: DA840000 00007E79
	ds_store_b16_d16_hi v122, v128                             // 0000001D4E0C: DA840000 0000807A
	s_waitcnt lgkmcnt(0)                                       // 0000001D4E14: BF89FC07
	s_barrier                                                  // 0000001D4E18: BFBD0000
	ds_load_b128 v[126:129], v113                              // 0000001D4E1C: DBFC0000 7E000071
	ds_load_b128 v[130:133], v113 offset:16                    // 0000001D4E24: DBFC0010 82000071
	s_waitcnt lgkmcnt(0)                                       // 0000001D4E2C: BF89FC07
	v_dual_mul_f32 v24, v126, v24 :: v_dual_mul_f32 v29, v131, v29// 0000001D4E30: C8C6317E 181C3B83
	v_dual_mul_f32 v26, v128, v26 :: v_dual_mul_f32 v21, v131, v21// 0000001D4E38: C8C63580 1A142B83
	v_dual_mul_f32 v27, v129, v27 :: v_dual_mul_f32 v16, v126, v16// 0000001D4E40: C8C63781 1B10217E
	v_dual_mul_f32 v23, v133, v23 :: v_dual_mul_f32 v18, v128, v18// 0000001D4E48: C8C62F85 17122580
	v_mul_f32_e32 v13, v131, v13                               // 0000001D4E50: 101A1B83
	v_dual_mul_f32 v19, v129, v19 :: v_dual_mul_f32 v8, v126, v8// 0000001D4E54: C8C62781 1308117E
	v_dual_mul_f32 v15, v133, v15 :: v_dual_mul_f32 v10, v128, v10// 0000001D4E5C: C8C61F85 0F0A1580
	v_mul_f32_e32 v5, v131, v5                                 // 0000001D4E64: 100A0B83
	v_dual_mul_f32 v11, v129, v11 :: v_dual_mul_f32 v0, v126, v0// 0000001D4E68: C8C61781 0B00017E
	v_dual_mul_f32 v7, v133, v7 :: v_dual_mul_f32 v2, v128, v2 // 0000001D4E70: C8C60F85 07020580
	v_dual_mul_f32 v3, v129, v3 :: v_dual_mul_f32 v28, v130, v28// 0000001D4E78: C8C60781 031C3982
	v_dual_mul_f32 v30, v132, v30 :: v_dual_mul_f32 v31, v133, v31// 0000001D4E80: C8C63D84 1E1E3F85
	v_mul_f32_e32 v20, v130, v20                               // 0000001D4E88: 10282982
	v_mul_f32_e32 v22, v132, v22                               // 0000001D4E8C: 102C2D84
	v_mul_f32_e32 v12, v130, v12                               // 0000001D4E90: 10181982
	v_mul_f32_e32 v14, v132, v14                               // 0000001D4E94: 101C1D84
	v_mul_f32_e32 v4, v130, v4                                 // 0000001D4E98: 10080982
	v_mul_f32_e32 v6, v132, v6                                 // 0000001D4E9C: 100C0D84
	ds_load_b128 v[128:131], v115                              // 0000001D4EA0: DBFC0000 80000073
	ds_load_b128 v[132:135], v115 offset:16                    // 0000001D4EA8: DBFC0010 84000073
	v_mul_f32_e32 v25, v127, v25                               // 0000001D4EB0: 1032337F
	v_mul_f32_e32 v17, v127, v17                               // 0000001D4EB4: 1022237F
	v_mul_f32_e32 v9, v127, v9                                 // 0000001D4EB8: 1012137F
	v_dual_mul_f32 v1, v127, v1 :: v_dual_mov_b32 v126, v136   // 0000001D4EBC: C8D0037F 017E0188
	v_mov_b32_e32 v127, v137                                   // 0000001D4EC4: 7EFE0389
	s_waitcnt vmcnt(3) lgkmcnt(0)                              // 0000001D4EC8: BF890C07
	v_wmma_f32_16x16x16_bf16 v[24:31], v[128:135], v[72:79], v[24:31]// 0000001D4ECC: CC414018 1C629180
	s_waitcnt vmcnt(2)                                         // 0000001D4ED4: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[16:23], v[128:135], v[80:87], v[16:23]// 0000001D4ED8: CC414010 1C42A180
	s_waitcnt vmcnt(1)                                         // 0000001D4EE0: BF8907F7
	v_wmma_f32_16x16x16_bf16 v[8:15], v[128:135], v[88:95], v[8:15]// 0000001D4EE4: CC414008 1C22B180
	s_waitcnt vmcnt(0)                                         // 0000001D4EEC: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[0:7], v[128:135], v[96:103], v[0:7]// 0000001D4EF0: CC414000 1C02C180
	s_cbranch_scc0 65107                                       // 0000001D4EF8: BFA1FE53 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x448>
	s_branch 25                                                // 0000001D4EFC: BFA00019 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xb64>
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v1, 0               // 0000001D4F00: CA100080 00000080
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 0000001D4F08: CA100080 02020080
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 0000001D4F10: CA100080 04040080
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000001D4F18: CA100080 08080080
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 0000001D4F20: CA100080 0A0A0080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 0000001D4F28: CA100080 0C0C0080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v17, 0             // 0000001D4F30: CA100080 10100080
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 0000001D4F38: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 0000001D4F40: CA100080 14140080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 0000001D4F48: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 0000001D4F50: CA100080 1A1A0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0             // 0000001D4F58: CA100080 1C1C0080
	v_mov_b32_e32 v109, 0                                      // 0000001D4F60: 7EDA0280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D4F64: BF870111
	v_add_f32_dpp v7, v110, v110 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D4F68: 060EDCFA FF09616E
	v_add_f32_dpp v6, v109, v109 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D4F70: 060CDAFA FF09616D
	v_or_b32_e32 v35, v107, v105                               // 0000001D4F78: 3846D36B
	s_barrier                                                  // 0000001D4F7C: BFBD0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D4F80: BF870193
	v_add_f32_dpp v7, v7, v7 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D4F84: 060E0EFA FF096207
	v_add_f32_dpp v6, v6, v6 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D4F8C: 060C0CFA FF096206
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D4F94: BF870223
	v_or_b32_e32 v40, s14, v35                                 // 0000001D4F98: 3850460E
	.long 0x7f6c3880                                           // 0000001D4F9C: 7F6C3880
	v_add_f32_dpp v7, v7, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D4FA0: 060E0EFA FF096407
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D4FA8: BF870194
	v_add_f32_dpp v6, v6, v6 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D4FAC: 060C0CFA FF096406
	.long 0x7f7839b6                                           // 0000001D4FB4: 7F7839B6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D4FB8: BF870193
	v_add_f32_dpp v31, v7, v7 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D4FBC: 063E0EFA FF096807
	v_add_f32_dpp v30, v6, v6 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D4FC4: 063C0CFA FF096806
	v_or_b32_e32 v6, s16, v108                                 // 0000001D4FCC: 380CD810
	v_or_b32_e32 v7, 0x3210, v104                              // 0000001D4FD0: 380ED0FF 00003210
	.long 0x7f7239b6                                           // 0000001D4FD8: 7F7239B6
	v_div_scale_f32 v33, null, v31, v31, 1.0                   // 0000001D4FDC: D6FC7C21 03CA3F1F
	v_div_scale_f32 v32, null, v30, v30, 1.0                   // 0000001D4FE4: D6FC7C20 03CA3D1E
	v_div_scale_f32 v42, vcc_lo, 1.0, v30, 1.0                 // 0000001D4FEC: D6FC6A2A 03CA3CF2
	v_lshl_add_u32 v39, v106, 3, v7                            // 0000001D4FF4: D6460027 041D076A
	.long 0x7f7a39b6                                           // 0000001D4FFC: 7F7A39B6
	v_rcp_f32_e32 v37, v33                                     // 0000001D5000: 7E4A5521
	v_rcp_f32_e32 v34, v32                                     // 0000001D5004: 7E445520
	.long 0x7f7639b6                                           // 0000001D5008: 7F7639B6
	.long 0x7f7439b6                                           // 0000001D500C: 7F7439B6
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001D5010: BF8702A6
	v_fma_f32 v15, -v33, v37, 1.0                              // 0000001D5014: D613000F 23CA4B21
	v_lshlrev_b32_e32 v36, 8, v6                               // 0000001D501C: 30480C88
	v_fma_f32 v6, -v32, v34, 1.0                               // 0000001D5020: D6130006 23CA4520
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D5028: BF870193
	v_dual_fmac_f32 v37, v15, v37 :: v_dual_mov_b32 v38, s15   // 0000001D502C: C8104B0F 2526000F
	v_add_nc_u32_e32 v41, 0x800, v36                           // 0000001D5034: 4A5248FF 00000800
	v_ashrrev_i32_e32 v7, 31, v36                              // 0000001D503C: 340E489F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001D5040: BF870234
	v_fmac_f32_e32 v34, v6, v34                                // 0000001D5044: 56444506
	.long 0xd7000006                                           // 0000001D5048: D7000006
	v_cndmask_b32_e32 v1, v40, v36, vcc_lo                     // 0000001D504C: 02024928
	v_add_nc_u32_e32 v14, 0x400, v36                           // 0000001D5050: 4A1C48FF 00000400
	v_add_co_ci_u32_e64 v7, null, v38, v7, s0                  // 0000001D5058: D5207C07 00020F26
	v_div_scale_f32 v43, s0, 1.0, v31, 1.0                     // 0000001D5060: D6FC002B 03CA3EF2
	v_mul_f32_e32 v44, v42, v34                                // 0000001D5068: 1058452A
	v_add_nc_u32_e32 v22, 0x600, v36                           // 0000001D506C: 4A2C48FF 00000600
	v_ashrrev_i32_e32 v15, 31, v14                             // 0000001D5074: 341E1C9F
	.long 0xd700010e                                           // 0000001D5078: D700010E
	v_cndmask_b32_e32 v1, v40, v14, vcc_lo                     // 0000001D507C: 02021D28
	v_mul_f32_e32 v46, v43, v37                                // 0000001D5080: 105C4B2B
	v_fma_f32 v47, -v32, v44, v42                              // 0000001D5084: D613002F 24AA5920
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000001D508C: 342E2C9F
	v_add_co_ci_u32_e64 v15, null, v38, v15, s1                // 0000001D5090: D5207C0F 00061F26
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D5098: BF870214
	v_fma_f32 v48, -v33, v46, v43                              // 0000001D509C: D6130030 24AE5D21
	v_fmac_f32_e32 v44, v47, v34                               // 0000001D50A4: 5658452F
	.long 0xd7000116                                           // 0000001D50A8: D7000116
	v_cndmask_b32_e32 v1, v40, v22, vcc_lo                     // 0000001D50AC: 02022D28
	.long 0xd73c0006                                           // 0000001D50B0: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000001D50B4: 02020C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D50B8: BF870214
	v_fmac_f32_e32 v46, v48, v37                               // 0000001D50BC: 565C4B30
	v_fma_f32 v32, -v32, v44, v42                              // 0000001D50C0: D6130020 24AA5920
	v_add_co_ci_u32_e64 v23, null, v38, v23, s1                // 0000001D50C8: D5207C17 00062F26
	.long 0xd73c000e                                           // 0000001D50D0: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000001D50D4: 02021C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D50D8: BF870214
	v_fma_f32 v33, -v33, v46, v43                              // 0000001D50DC: D6130021 24AE5D21
	v_div_fmas_f32 v32, v32, v34, v44                          // 0000001D50E4: D6370020 04B24520
	s_mov_b32 vcc_lo, s0                                       // 0000001D50EC: BEEA0000
	.long 0xd73c0016                                           // 0000001D50F0: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000001D50F4: 02022C81
	v_ashrrev_i32_e32 v45, 31, v41                             // 0000001D50F8: 345A529F
	v_div_fmas_f32 v33, v33, v37, v46                          // 0000001D50FC: D6370021 04BA4B21
	v_div_fixup_f32 v30, v32, v30, 1.0                         // 0000001D5104: D627001E 03CA3D20
	.long 0xd7006a32                                           // 0000001D510C: D7006A32
	v_cndmask_b32_e32 v1, s10, v6, vcc_lo                      // 0000001D5110: 02020C0A
	v_add_nc_u32_e32 v32, 0xa00, v36                           // 0000001D5114: 4A4048FF 00000A00
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001D511C: BF8700B4
	v_div_fixup_f32 v31, v33, v31, 1.0                         // 0000001D5120: D627001F 03CA3F21
	v_add_co_ci_u32_e64 v51, null, s11, v7, vcc_lo             // 0000001D5128: D5207C33 01AA0E0B
	.long 0xd7006a2a                                           // 0000001D5130: D7006A2A
	v_cndmask_b32_e32 v1, s10, v14, vcc_lo                     // 0000001D5134: 02021C0A
	v_add_co_ci_u32_e64 v43, null, s11, v15, vcc_lo            // 0000001D5138: D5207C2B 01AA1E0B
	ds_store_b64 v39, v[30:31]                                 // 0000001D5140: D9340000 00001E27
	.long 0xd7006a1e                                           // 0000001D5148: D7006A1E
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                     // 0000001D514C: 02025328
	v_ashrrev_i32_e32 v33, 31, v32                             // 0000001D5150: 3442409F
	v_add_co_ci_u32_e64 v31, null, v38, v45, vcc_lo            // 0000001D5154: D5207C1F 01AA5B26
	.long 0xd7006a2c                                           // 0000001D515C: D7006A2C
	v_cndmask_b32_e32 v1, s10, v22, vcc_lo                     // 0000001D5160: 02022C0A
	v_or_b32_e32 v34, 0x200, v36                               // 0000001D5164: 384448FF 00000200
	v_add_co_ci_u32_e64 v45, null, s11, v23, vcc_lo            // 0000001D516C: D5207C2D 01AA2E0B
	.long 0xd7006a20                                           // 0000001D5174: D7006A20
	v_cndmask_b32_e32 v1, v40, v32, vcc_lo                     // 0000001D5178: 02024128
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D517C: BF8700A1
	v_add_co_ci_u32_e64 v33, null, v38, v33, vcc_lo            // 0000001D5180: D5207C21 01AA4326
	.long 0xd7000023                                           // 0000001D5188: D7000023
	v_cndmask_b32_e32 v1, s14, v35, vcc_lo                     // 0000001D518C: 0202460E
	v_add_co_ci_u32_e64 v38, null, s15, 0, s0                  // 0000001D5190: D5207C26 0001000F
	v_ashrrev_i32_e32 v39, 31, v34                             // 0000001D5198: 344E449F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D519C: BF870214
	.long 0xd73c0024                                           // 0000001D51A0: D73C0024
	v_cndmask_b32_e32 v1, 1, v32, vcc_lo                       // 0000001D51A4: 02024081
	.long 0xd7006a20                                           // 0000001D51A8: D7006A20
	v_cndmask_b32_e32 v1, v35, v34, vcc_lo                     // 0000001D51AC: 02024523
	.long 0xd73c001e                                           // 0000001D51B0: D73C001E
	v_cndmask_b32_e32 v1, 1, v30, vcc_lo                       // 0000001D51B4: 02023C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001D51B8: BF8700B4
	v_add_co_ci_u32_e64 v33, null, v38, v39, vcc_lo            // 0000001D51BC: D5207C21 01AA4F26
	s_waitcnt lgkmcnt(0)                                       // 0000001D51C4: BF89FC07
	s_barrier                                                  // 0000001D51C8: BFBD0000
	.long 0xd73c0026                                           // 0000001D51CC: D73C0026
	v_cndmask_b32_e32 v1, 1, v32, vcc_lo                       // 0000001D51D0: 02024081
	s_clause 0x1                                               // 0000001D51D4: BF850001
	global_load_u16 v55, v[50:51], off                         // 0000001D51D8: DC4A0000 377C0032
	global_load_u16 v56, v[50:51], off offset:1024             // 0000001D51E0: DC4A0400 387C0032
	.long 0xd7006a2e                                           // 0000001D51E8: D7006A2E
	v_cndmask_b32_e32 v1, s10, v30, vcc_lo                     // 0000001D51EC: 02023C0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D51F0: BF8700A1
	v_add_co_ci_u32_e64 v47, null, s11, v31, vcc_lo            // 0000001D51F4: D5207C2F 01AA3E0B
	.long 0xd7006a30                                           // 0000001D51FC: D7006A30
	v_cndmask_b32_e32 v1, s10, v36, vcc_lo                     // 0000001D5200: 0202480A
	v_add_co_ci_u32_e64 v49, null, s11, v37, vcc_lo            // 0000001D5204: D5207C31 01AA4A0B
	.long 0xd7006a34                                           // 0000001D520C: D7006A34
	v_cndmask_b32_e32 v1, s10, v38, vcc_lo                     // 0000001D5210: 02024C0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D5214: BF870001
	v_add_co_ci_u32_e64 v53, null, s11, v39, vcc_lo            // 0000001D5218: D5207C35 01AA4E0B
	s_clause 0xb                                               // 0000001D5220: BF85000B
	global_load_u16 v64, v[44:45], off                         // 0000001D5224: DC4A0000 407C002C
	global_load_u16 v63, v[42:43], off                         // 0000001D522C: DC4A0000 3F7C002A
	global_load_u16 v66, v[48:49], off                         // 0000001D5234: DC4A0000 427C0030
	global_load_u16 v65, v[46:47], off                         // 0000001D523C: DC4A0000 417C002E
	global_load_u16 v68, v[52:53], off offset:32               // 0000001D5244: DC4A0020 447C0034
	global_load_u16 v67, v[50:51], off offset:32               // 0000001D524C: DC4A0020 437C0032
	global_load_u16 v70, v[44:45], off offset:32               // 0000001D5254: DC4A0020 467C002C
	global_load_u16 v69, v[42:43], off offset:32               // 0000001D525C: DC4A0020 457C002A
	global_load_u16 v73, v[48:49], off offset:32               // 0000001D5264: DC4A0020 497C0030
	global_load_u16 v74, v[46:47], off offset:32               // 0000001D526C: DC4A0020 4A7C002E
	global_load_u16 v75, v[52:53], off offset:64               // 0000001D5274: DC4A0040 4B7C0034
	global_load_u16 v76, v[50:51], off offset:64               // 0000001D527C: DC4A0040 4C7C0032
	.long 0xd7006a22                                           // 0000001D5284: D7006A22
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 0000001D5288: 02020C0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D528C: BF8700A1
	v_add_co_ci_u32_e64 v35, null, s13, v7, vcc_lo             // 0000001D5290: D5207C23 01AA0E0D
	.long 0xd7006a06                                           // 0000001D5298: D7006A06
	v_cndmask_b32_e32 v1, s12, v14, vcc_lo                     // 0000001D529C: 02021C0C
	v_add_co_ci_u32_e64 v7, null, s13, v15, vcc_lo             // 0000001D52A0: D5207C07 01AA1E0D
	.long 0xd7006a0e                                           // 0000001D52A8: D7006A0E
	v_cndmask_b32_e32 v1, s12, v22, vcc_lo                     // 0000001D52AC: 02022C0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D52B0: BF8700A1
	v_add_co_ci_u32_e64 v15, null, s13, v23, vcc_lo            // 0000001D52B4: D5207C0F 01AA2E0D
	.long 0xd7006a16                                           // 0000001D52BC: D7006A16
	v_cndmask_b32_e32 v1, s12, v30, vcc_lo                     // 0000001D52C0: 02023C0C
	v_add_co_ci_u32_e64 v23, null, s13, v31, vcc_lo            // 0000001D52C4: D5207C17 01AA3E0D
	ds_load_b128 v[30:33], v104 offset:12816                   // 0000001D52CC: DBFC3210 1E000068
	ds_load_b64 v[40:41], v104 offset:12832                    // 0000001D52D4: D9D83220 28000068
	s_clause 0x9                                               // 0000001D52DC: BF850009
	global_load_u16 v62, v[42:43], off offset:64               // 0000001D52E0: DC4A0040 3E7C002A
	global_load_u16 v50, v[50:51], off offset:96               // 0000001D52E8: DC4A0060 327C0032
	global_load_u16 v71, v[44:45], off offset:64               // 0000001D52F0: DC4A0040 477C002C
	global_load_u16 v51, v[46:47], off offset:64               // 0000001D52F8: DC4A0040 337C002E
	global_load_u16 v44, v[44:45], off offset:96               // 0000001D5300: DC4A0060 2C7C002C
	global_load_u16 v42, v[42:43], off offset:96               // 0000001D5308: DC4A0060 2A7C002A
	global_load_u16 v72, v[48:49], off offset:64               // 0000001D5310: DC4A0040 487C0030
	global_load_u16 v52, v[52:53], off offset:96               // 0000001D5318: DC4A0060 347C0034
	global_load_u16 v43, v[48:49], off offset:96               // 0000001D5320: DC4A0060 2B7C0030
	global_load_u16 v45, v[46:47], off offset:96               // 0000001D5328: DC4A0060 2D7C002E
	.long 0xd7006a24                                           // 0000001D5330: D7006A24
	v_cndmask_b32_e32 v1, s12, v36, vcc_lo                     // 0000001D5334: 0202480C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D5338: BF8700A1
	v_add_co_ci_u32_e64 v37, null, s13, v37, vcc_lo            // 0000001D533C: D5207C25 01AA4A0D
	.long 0xd7006a26                                           // 0000001D5344: D7006A26
	v_cndmask_b32_e32 v1, s12, v38, vcc_lo                     // 0000001D5348: 02024C0C
	v_add_co_ci_u32_e64 v39, null, s13, v39, vcc_lo            // 0000001D534C: D5207C27 01AA4E0D
	s_waitcnt lgkmcnt(1)                                       // 0000001D5354: BF89FC17
	v_mul_f32_e32 v26, v26, v32                                // 0000001D5358: 1034411A
	v_mul_f32_e32 v24, v24, v30                                // 0000001D535C: 10303D18
	v_mul_f32_e32 v16, v16, v30                                // 0000001D5360: 10203D10
	s_waitcnt lgkmcnt(0)                                       // 0000001D5364: BF89FC07
	v_mul_f32_e32 v28, v28, v40                                // 0000001D5368: 1038511C
	v_dual_mul_f32 v18, v18, v32 :: v_dual_mul_f32 v29, v29, v41// 0000001D536C: C8C64112 121C531D
	v_mul_f32_e32 v25, v25, v31                                // 0000001D5374: 10323F19
	v_mul_f32_e32 v27, v27, v33                                // 0000001D5378: 1036431B
	v_mul_f32_e32 v21, v21, v41                                // 0000001D537C: 102A5315
	v_mul_f32_e32 v17, v17, v31                                // 0000001D5380: 10223F11
	v_dual_mul_f32 v19, v19, v33 :: v_dual_mul_f32 v8, v8, v30 // 0000001D5384: C8C64313 13083D08
	v_mul_f32_e32 v10, v10, v32                                // 0000001D538C: 1014410A
	v_mul_f32_e32 v2, v2, v32                                  // 0000001D5390: 10044102
	v_mul_f32_e32 v12, v12, v40                                // 0000001D5394: 1018510C
	v_mul_f32_e32 v0, v0, v30                                  // 0000001D5398: 10003D00
	v_dual_mul_f32 v4, v4, v40 :: v_dual_mul_f32 v9, v9, v31   // 0000001D539C: C8C65104 04083F09
	v_mul_f32_e32 v11, v11, v33                                // 0000001D53A4: 1016430B
	v_mul_f32_e32 v13, v13, v41                                // 0000001D53A8: 101A530D
	v_mul_f32_e32 v1, v1, v31                                  // 0000001D53AC: 10023F01
	v_mul_f32_e32 v3, v3, v33                                  // 0000001D53B0: 10064303
	v_mul_f32_e32 v5, v5, v41                                  // 0000001D53B4: 100A5305
	s_waitcnt vmcnt(23)                                        // 0000001D53B8: BF895FF7
	v_lshlrev_b32_e32 v47, 16, v55                             // 0000001D53BC: 305E6E90
	s_waitcnt vmcnt(20)                                        // 0000001D53C0: BF8953F7
	v_lshlrev_b32_e32 v49, 16, v63                             // 0000001D53C4: 30627E90
	s_waitcnt vmcnt(19)                                        // 0000001D53C8: BF894FF7
	v_lshlrev_b32_e32 v53, 16, v66                             // 0000001D53CC: 306A8490
	v_lshlrev_b32_e32 v46, 16, v56                             // 0000001D53D0: 305C7090
	s_waitcnt vmcnt(18)                                        // 0000001D53D4: BF894BF7
	v_lshlrev_b32_e32 v55, 16, v65                             // 0000001D53D8: 306E8290
	s_waitcnt vmcnt(16)                                        // 0000001D53DC: BF8943F7
	v_lshlrev_b32_e32 v63, 16, v67                             // 0000001D53E0: 307E8690
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v47                  // 0000001D53E4: 7C3C5EFF 42CE8ED0
	v_dual_mul_f32 v77, 0xbfb8aa3b, v53 :: v_dual_mul_f32 v20, v20, v40// 0000001D53EC: C8C66AFF 4D145114 BFB8AA3B
	s_waitcnt vmcnt(13)                                        // 0000001D53F8: BF8937F7
	v_dual_mul_f32 v73, 0xbfb8aa3b, v46 :: v_dual_lshlrev_b32 v66, 16, v73// 0000001D53FC: C8E25CFF 49429290 BFB8AA3B
	v_lshlrev_b32_e32 v65, 16, v69                             // 0000001D5408: 30828A90
	s_waitcnt vmcnt(10)                                        // 0000001D540C: BF892BF7
	v_lshlrev_b32_e32 v69, 16, v76                             // 0000001D5410: 308A9890
	v_fma_f32 v96, 0xbfb8aa3b, v53, -v77                       // 0000001D5414: D6130060 85366AFF BFB8AA3B
	v_rndne_f32_e32 v97, v77                                   // 0000001D5420: 7EC2474D
	v_rndne_f32_e32 v89, v73                                   // 0000001D5424: 7EB24749
	v_lshlrev_b32_e32 v56, 16, v68                             // 0000001D5428: 30708890
	v_fma_f32 v88, 0xbfb8aa3b, v46, -v73                       // 0000001D542C: D6130058 85265CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D5438: BF870214
	v_dual_mul_f32 v78, 0xbfb8aa3b, v63 :: v_dual_sub_f32 v77, v77, v97// 0000001D543C: C8CA7EFF 4E4CC34D BFB8AA3B
	v_sub_f32_e32 v73, v73, v89                                // 0000001D5448: 0892B349
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001D544C: BF8701C4
	v_mul_f32_e32 v79, 0xbfb8aa3b, v56                         // 0000001D5450: 109E70FF BFB8AA3B
	v_dual_mul_f32 v83, 0xbfb8aa3b, v66 :: v_dual_lshlrev_b32 v48, 16, v64// 0000001D5458: C8E284FF 53308090 BFB8AA3B
	v_lshlrev_b32_e32 v64, 16, v70                             // 0000001D5464: 30808C90
	v_mul_f32_e32 v70, 0xbfb8aa3b, v47                         // 0000001D5468: 108C5EFF BFB8AA3B
	v_dual_mul_f32 v75, 0xbfb8aa3b, v48 :: v_dual_lshlrev_b32 v68, 16, v75// 0000001D5470: C8E260FF 4B449690 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D547C: BF870214
	v_rndne_f32_e32 v109, v83                                  // 0000001D5480: 7EDA4753
	v_mul_f32_e32 v81, 0xbfb8aa3b, v64                         // 0000001D5484: 10A280FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D548C: BF870004
	v_fma_f32 v86, 0xbfb8aa3b, v47, -v70                       // 0000001D5490: D6130056 851A5EFF BFB8AA3B
	v_rndne_f32_e32 v87, v70                                   // 0000001D549C: 7EAE4746
	v_fma_f32 v108, 0xbfb8aa3b, v66, -v83                      // 0000001D54A0: D613006C 854E84FF BFB8AA3B
	v_fmac_f32_e32 v96, 0xb2a5705f, v53                        // 0000001D54AC: 56C06AFF B2A5705F
	v_rndne_f32_e32 v105, v81                                  // 0000001D54B4: 7ED24751
	v_fmac_f32_e32 v86, 0xb2a5705f, v47                        // 0000001D54B8: 56AC5EFF B2A5705F
	v_dual_sub_f32 v70, v70, v87 :: v_dual_sub_f32 v83, v83, v109// 0000001D54C0: C94AAF46 4652DB53
	v_fma_f32 v104, 0xbfb8aa3b, v64, -v81                      // 0000001D54C8: D6130068 854680FF BFB8AA3B
	v_dual_fmac_f32 v88, 0xb2a5705f, v46 :: v_dual_add_f32 v77, v77, v96// 0000001D54D4: C8085CFF 584CC14D B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001D54E0: BF870233
	v_dual_sub_f32 v81, v81, v105 :: v_dual_add_f32 v70, v70, v86// 0000001D54E4: C948D351 5146AD46
	v_dual_mul_f32 v74, 0xbfb8aa3b, v49 :: v_dual_lshlrev_b32 v67, 16, v74// 0000001D54EC: C8E262FF 4A429490 BFB8AA3B
	v_dual_mul_f32 v85, 0xbfb8aa3b, v68 :: v_dual_mul_f32 v80, 0xbfb8aa3b, v65// 0000001D54F8: C8C688FF 555082FF BFB8AA3B
	v_add_f32_e32 v73, v73, v88                                // 0000001D5504: 0692B149
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D5508: BF870194
	v_exp_f32_e32 v70, v70                                     // 0000001D550C: 7E8C4B46
	v_fma_f32 v90, 0xbfb8aa3b, v49, -v74                       // 0000001D5510: D613005A 852A62FF BFB8AA3B
	v_rndne_f32_e32 v91, v74                                   // 0000001D551C: 7EB6474A
	v_fma_f32 v100, 0xbfb8aa3b, v56, -v79                      // 0000001D5520: D6130064 853E70FF BFB8AA3B
	v_rndne_f32_e32 v101, v79                                  // 0000001D552C: 7ECA474F
	v_cvt_i32_f32_e32 v87, v87                                 // 0000001D5530: 7EAE1157
	v_exp_f32_e32 v73, v73                                     // 0000001D5534: 7E924B49
	v_mul_f32_e32 v82, 0xbfb8aa3b, v67                         // 0000001D5538: 10A486FF BFB8AA3B
	v_fma_f32 v92, 0xbfb8aa3b, v48, -v75                       // 0000001D5540: D613005C 852E60FF BFB8AA3B
	v_rndne_f32_e32 v93, v75                                   // 0000001D554C: 7EBA474B
	v_mul_f32_e32 v76, 0xbfb8aa3b, v55                         // 0000001D5550: 10986EFF BFB8AA3B
	v_cvt_i32_f32_e32 v89, v89                                 // 0000001D5558: 7EB21159
	v_dual_fmac_f32 v100, 0xb2a5705f, v56 :: v_dual_sub_f32 v79, v79, v101// 0000001D555C: C80A70FF 644ECB4F B2A5705F
	v_fmac_f32_e32 v90, 0xb2a5705f, v49                        // 0000001D5568: 56B462FF B2A5705F
	v_fmac_f32_e32 v104, 0xb2a5705f, v64                       // 0000001D5570: 56D080FF B2A5705F
	v_sub_f32_e32 v74, v74, v91                                // 0000001D5578: 0894B74A
	v_exp_f32_e32 v77, v77                                     // 0000001D557C: 7E9A4B4D
	.long 0xd71c0046                                           // 0000001D5580: D71C0046
	v_cndmask_b32_e32 v1, v70, v87, vcc_lo                     // 0000001D5584: 0202AF46
	v_sub_f32_e32 v75, v75, v93                                // 0000001D5588: 0896BB4B
	v_fma_f32 v94, 0xbfb8aa3b, v55, -v76                       // 0000001D558C: D613005E 85326EFF BFB8AA3B
	v_rndne_f32_e32 v95, v76                                   // 0000001D5598: 7EBE474C
	v_cvt_i32_f32_e32 v97, v97                                 // 0000001D559C: 7EC21161
	v_add_f32_e32 v79, v79, v100                               // 0000001D55A0: 069EC94F
	v_dual_add_f32 v81, v81, v104 :: v_dual_add_f32 v74, v74, v90// 0000001D55A4: C908D151 514AB54A
	.long 0xd71c0049                                           // 0000001D55AC: D71C0049
	v_cndmask_b32_e32 v1, v73, v89, vcc_lo                     // 0000001D55B0: 0202B349
	v_cndmask_b32_e32 v70, 0, v70, vcc_lo                      // 0000001D55B4: 028C8C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v46                  // 0000001D55B8: 7C3C5CFF 42CE8ED0
	v_fmac_f32_e32 v92, 0xb2a5705f, v48                        // 0000001D55C0: 56B860FF B2A5705F
	v_fmac_f32_e32 v108, 0xb2a5705f, v66                       // 0000001D55C8: 56D884FF B2A5705F
	v_fmac_f32_e32 v94, 0xb2a5705f, v55                        // 0000001D55D0: 56BC6EFF B2A5705F
	v_exp_f32_e32 v74, v74                                     // 0000001D55D8: 7E944B4A
	v_exp_f32_e32 v81, v81                                     // 0000001D55DC: 7EA24B51
	.long 0xd71c004d                                           // 0000001D55E0: D71C004D
	v_cndmask_b32_e32 v1, v77, v97, vcc_lo                     // 0000001D55E4: 0202C34D
	v_dual_sub_f32 v76, v76, v95 :: v_dual_cndmask_b32 v73, 0, v73// 0000001D55E8: C952BF4C 4C489280
	v_dual_mul_f32 v84, 0xbfb8aa3b, v69 :: v_dual_add_f32 v75, v75, v92// 0000001D55F0: C8C88AFF 544AB94B BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v63, -v78                       // 0000001D55FC: D6130062 853A7EFF BFB8AA3B
	v_rndne_f32_e32 v99, v78                                   // 0000001D5608: 7EC6474E
	v_cvt_i32_f32_e32 v91, v91                                 // 0000001D560C: 7EB6115B
	v_cvt_i32_f32_e32 v105, v105                               // 0000001D5610: 7ED21169
	v_dual_add_f32 v83, v83, v108 :: v_dual_add_f32 v76, v76, v94// 0000001D5614: C908D953 534CBD4C
	v_exp_f32_e32 v75, v75                                     // 0000001D561C: 7E964B4B
	v_cvt_i32_f32_e32 v93, v93                                 // 0000001D5620: 7EBA115D
	v_sub_f32_e32 v78, v78, v99                                // 0000001D5624: 089CC74E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D5628: BF870003
	v_exp_f32_e32 v83, v83                                     // 0000001D562C: 7EA64B53
	v_exp_f32_e32 v76, v76                                     // 0000001D5630: 7E984B4C
	.long 0xd71c004a                                           // 0000001D5634: D71C004A
	v_cndmask_b32_e32 v1, v74, v91, vcc_lo                     // 0000001D5638: 0202B74A
	.long 0xd71c0051                                           // 0000001D563C: D71C0051
	v_cndmask_b32_e32 v1, v81, v105, vcc_lo                    // 0000001D5640: 0202D351
	v_fmac_f32_e32 v98, 0xb2a5705f, v63                        // 0000001D5644: 56C47EFF B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001D564C: 7C3C62FF 42CE8ED0
	v_fma_f32 v102, 0xbfb8aa3b, v65, -v80                      // 0000001D5654: D6130066 854282FF BFB8AA3B
	v_rndne_f32_e32 v103, v80                                  // 0000001D5660: 7ECE4750
	v_cvt_i32_f32_e32 v95, v95                                 // 0000001D5664: 7EBE115F
	v_cvt_i32_f32_e32 v109, v109                               // 0000001D5668: 7EDA116D
	v_add_f32_e32 v78, v78, v98                                // 0000001D566C: 069CC54E
	.long 0xd71c004b                                           // 0000001D5670: D71C004B
	v_cndmask_b32_e32 v1, v75, v93, vcc_lo                     // 0000001D5674: 0202BB4B
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000001D5678: 02949480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 0000001D567C: 7C3C60FF 42CE8ED0
	v_sub_f32_e32 v80, v80, v103                               // 0000001D5684: 08A0CF50
	v_exp_f32_e32 v78, v78                                     // 0000001D5688: 7E9C4B4E
	.long 0xd71c004c                                           // 0000001D568C: D71C004C
	v_cndmask_b32_e32 v1, v76, v95, vcc_lo                     // 0000001D5690: 0202BF4C
	.long 0xd71c0053                                           // 0000001D5694: D71C0053
	v_cndmask_b32_e32 v1, v83, v109, vcc_lo                    // 0000001D5698: 0202DB53
	v_dual_fmac_f32 v102, 0xb2a5705f, v65 :: v_dual_cndmask_b32 v75, 0, v75// 0000001D569C: C81282FF 664A9680 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v55                  // 0000001D56A8: 7C3C6EFF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v67, -v82                      // 0000001D56B0: D613006A 854A86FF BFB8AA3B
	v_rndne_f32_e32 v107, v82                                  // 0000001D56BC: 7ED64752
	v_cvt_i32_f32_e32 v99, v99                                 // 0000001D56C0: 7EC61163
	v_add_f32_e32 v80, v80, v102                               // 0000001D56C4: 06A0CD50
	v_exp_f32_e32 v79, v79                                     // 0000001D56C8: 7E9E4B4F
	v_cndmask_b32_e32 v76, 0, v76, vcc_lo                      // 0000001D56CC: 02989880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v53                  // 0000001D56D0: 7C3C6AFF 42CE8ED0
	v_cvt_i32_f32_e32 v101, v101                               // 0000001D56D8: 7ECA1165
	v_fmac_f32_e32 v106, 0xb2a5705f, v67                       // 0000001D56DC: 56D486FF B2A5705F
	v_sub_f32_e32 v82, v82, v107                               // 0000001D56E4: 08A4D752
	v_exp_f32_e32 v80, v80                                     // 0000001D56E8: 7EA04B50
	.long 0xd71c004e                                           // 0000001D56EC: D71C004E
	v_cndmask_b32_e32 v1, v78, v99, vcc_lo                     // 0000001D56F0: 0202C74E
	v_cndmask_b32_e32 v77, 0, v77, vcc_lo                      // 0000001D56F4: 029A9A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v63                  // 0000001D56F8: 7C3C7EFF 42CE8ED0
	v_cvt_i32_f32_e32 v103, v103                               // 0000001D5700: 7ECE1167
	v_add_f32_e32 v82, v82, v106                               // 0000001D5704: 06A4D552
	.long 0xd71c004f                                           // 0000001D5708: D71C004F
	v_cndmask_b32_e32 v1, v79, v101, vcc_lo                    // 0000001D570C: 0202CB4F
	v_cvt_i32_f32_e32 v107, v107                               // 0000001D5710: 7ED6116B
	v_cndmask_b32_e32 v78, 0, v78, vcc_lo                      // 0000001D5714: 029C9C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 0000001D5718: 7C3C70FF 42CE8ED0
	v_exp_f32_e32 v82, v82                                     // 0000001D5720: 7EA44B52
	.long 0xd71c0050                                           // 0000001D5724: D71C0050
	v_cndmask_b32_e32 v1, v80, v103, vcc_lo                    // 0000001D5728: 0202CF50
	v_rndne_f32_e32 v111, v84                                  // 0000001D572C: 7EDE4754
	v_fma_f32 v110, 0xbfb8aa3b, v69, -v84                      // 0000001D5730: D613006E 85528AFF BFB8AA3B
	v_cndmask_b32_e32 v79, 0, v79, vcc_lo                      // 0000001D573C: 029E9E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000001D5740: 7C3C82FF 42CE8ED0
	v_fma_f32 v112, 0xbfb8aa3b, v68, -v85                      // 0000001D5748: D6130070 855688FF BFB8AA3B
	v_rndne_f32_e32 v113, v85                                  // 0000001D5754: 7EE24755
	s_waitcnt vmcnt(1)                                         // 0000001D5758: BF8907F7
	v_lshlrev_b32_e32 v32, 16, v43                             // 0000001D575C: 30405690
	v_cndmask_b32_e32 v80, 0, v80, vcc_lo                      // 0000001D5760: 02A0A080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 0000001D5764: 7C3C80FF 42CE8ED0
	.long 0xd71c0052                                           // 0000001D576C: D71C0052
	v_cndmask_b32_e32 v1, v82, v107, vcc_lo                    // 0000001D5770: 0202D752
	v_dual_fmac_f32 v112, 0xb2a5705f, v68 :: v_dual_cndmask_b32 v81, 0, v81// 0000001D5774: C81288FF 7050A280 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v67                  // 0000001D5780: 7C3C86FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D5788: BF870003
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000001D578C: 02A4A480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v66                  // 0000001D5790: 7C3C84FF 42CE8ED0
	v_cndmask_b32_e32 v83, 0, v83, vcc_lo                      // 0000001D5798: 02A6A680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v47                  // 0000001D579C: 7C365EFF C2B17218
	v_cndmask_b32_e32 v47, 0x7f800000, v70, vcc_lo             // 0000001D57A4: 025E8CFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v46                  // 0000001D57AC: 7C365CFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D57B4: BF870122
	v_dual_add_f32 v47, 1.0, v47 :: v_dual_cndmask_b32 v46, 0x7f800000, v73// 0000001D57B8: C9125EF2 2F2E92FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001D57C4: 7C3662FF C2B17218
	v_div_scale_f32 v70, null, v47, v47, v24                   // 0000001D57CC: D6FC7C46 04625F2F
	v_cndmask_b32_e32 v49, 0x7f800000, v74, vcc_lo             // 0000001D57D4: 026294FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 0000001D57DC: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D57E4: BF870113
	v_rcp_f32_e32 v98, v70                                     // 0000001D57E8: 7EC45546
	v_dual_add_f32 v49, 1.0, v49 :: v_dual_cndmask_b32 v48, 0x7f800000, v75// 0000001D57EC: C91262F2 313096FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v55                  // 0000001D57F8: 7C366EFF C2B17218
	v_cndmask_b32_e32 v55, 0x7f800000, v76, vcc_lo             // 0000001D5800: 026E98FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v53                  // 0000001D5808: 7C366AFF C2B17218
	v_sub_f32_e32 v84, v84, v111                               // 0000001D5810: 08A8DF54
	v_fmac_f32_e32 v110, 0xb2a5705f, v69                       // 0000001D5814: 56DC8AFF B2A5705F
	v_div_scale_f32 v76, null, v49, v49, v26                   // 0000001D581C: D6FC7C4C 046A6331
	v_add_f32_e32 v55, 1.0, v55                                // 0000001D5824: 066E6EF2
	v_cndmask_b32_e32 v53, 0x7f800000, v77, vcc_lo             // 0000001D5828: 026A9AFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v63                  // 0000001D5830: 7C367EFF C2B17218
	v_div_scale_f32 v77, s1, v26, v49, v26                     // 0000001D5838: D6FC014D 046A631A
	v_rcp_f32_e32 v100, v76                                    // 0000001D5840: 7EC8554C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001D5844: BF870133
	v_add_f32_e32 v53, 1.0, v53                                // 0000001D5848: 066A6AF2
	v_cndmask_b32_e32 v63, 0x7f800000, v78, vcc_lo             // 0000001D584C: 027E9CFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 0000001D5854: 7C3670FF C2B17218
	v_add_f32_e32 v63, 1.0, v63                                // 0000001D585C: 067E7EF2
	v_cndmask_b32_e32 v56, 0x7f800000, v79, vcc_lo             // 0000001D5860: 02709EFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000001D5868: 7C3682FF C2B17218
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D5870: BF870215
	v_fma_f32 v115, -v76, v100, 1.0                            // 0000001D5874: D6130073 23CAC94C
	v_div_scale_f32 v86, null, v63, v63, v16                   // 0000001D587C: D6FC7C56 04427F3F
	v_div_scale_f32 v87, s5, v16, v63, v16                     // 0000001D5884: D6FC0557 04427F10
	v_cndmask_b32_e32 v65, 0x7f800000, v80, vcc_lo             // 0000001D588C: 0282A0FF 7F800000
	v_div_scale_f32 v80, null, v55, v55, v28                   // 0000001D5894: D6FC7C50 04726F37
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 0000001D589C: 7C3680FF C2B17218
	v_rcp_f32_e32 v104, v86                                    // 0000001D58A4: 7ED05556
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D58A8: BF870193
	v_dual_fmac_f32 v100, v115, v100 :: v_dual_add_f32 v65, 1.0, v65// 0000001D58AC: C808C973 644082F2
	v_rcp_f32_e32 v102, v80                                    // 0000001D58B4: 7ECC5550
	v_cndmask_b32_e32 v64, 0x7f800000, v81, vcc_lo             // 0000001D58B8: 0280A2FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v67                  // 0000001D58C0: 7C3686FF C2B17218
	v_div_scale_f32 v81, s3, v28, v55, v28                     // 0000001D58C8: D6FC0351 04726F1C
	v_mul_f32_e32 v115, v77, v100                              // 0000001D58D0: 10E6C94D
	v_div_scale_f32 v90, null, v65, v65, v18                   // 0000001D58D4: D6FC7C5A 044A8341
	v_div_scale_f32 v91, s7, v18, v65, v18                     // 0000001D58DC: D6FC075B 044A8312
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001D58E4: BF870256
	v_fma_f32 v119, -v86, v104, 1.0                            // 0000001D58E8: D6130077 23CAD156
	v_cndmask_b32_e32 v67, 0x7f800000, v82, vcc_lo             // 0000001D58F0: 0286A4FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v66                  // 0000001D58F8: 7C3684FF C2B17218
	v_fma_f32 v117, -v80, v102, 1.0                            // 0000001D5900: D6130075 23CACD50
	v_div_scale_f32 v82, null, v53, v53, v29                   // 0000001D5908: D6FC7C52 04766B35
	v_dual_fmac_f32 v104, v119, v104 :: v_dual_add_f32 v67, 1.0, v67// 0000001D5910: C808D177 684286F2
	v_fma_f32 v126, -v76, v115, v77                            // 0000001D5918: D613007E 2536E74C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D5920: BF870194
	v_fmac_f32_e32 v102, v117, v102                            // 0000001D5924: 56CCCD75
	v_dual_cndmask_b32 v66, 0x7f800000, v83 :: v_dual_mul_f32 v119, v87, v104// 0000001D5928: CA46A6FF 4276D157 7F800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D5934: BF8701A4
	v_div_scale_f32 v94, null, v67, v67, v20                   // 0000001D5938: D6FC7C5E 04528743
	v_rcp_f32_e32 v103, v82                                    // 0000001D5940: 7ECE5552
	v_mul_f32_e32 v117, v81, v102                              // 0000001D5944: 10EACD51
	v_fmac_f32_e32 v115, v126, v100                            // 0000001D5948: 56E6C97E
	v_fma_f32 v130, -v86, v119, v87                            // 0000001D594C: D6130082 255EEF56
	v_add_f32_e32 v46, 1.0, v46                                // 0000001D5954: 065C5CF2
	v_add_f32_e32 v66, 1.0, v66                                // 0000001D5958: 068484F2
	v_fma_f32 v128, -v80, v117, v81                            // 0000001D595C: D6130080 2546EB50
	v_add_f32_e32 v48, 1.0, v48                                // 0000001D5964: 066060F2
	v_fmac_f32_e32 v119, v130, v104                            // 0000001D5968: 56EED182
	v_div_scale_f32 v74, null, v46, v46, v25                   // 0000001D596C: D6FC7C4A 04665D2E
	v_rcp_f32_e32 v108, v94                                    // 0000001D5974: 7ED8555E
	v_fmac_f32_e32 v117, v128, v102                            // 0000001D5978: 56EACD80
	v_div_scale_f32 v78, null, v48, v48, v27                   // 0000001D597C: D6FC7C4E 046E6130
	v_div_scale_f32 v96, null, v66, v66, v21                   // 0000001D5984: D6FC7C60 04568542
	v_rcp_f32_e32 v99, v74                                     // 0000001D598C: 7EC6554A
	v_fma_f32 v118, -v82, v103, 1.0                            // 0000001D5990: D6130076 23CACF52
	v_add_f32_e32 v84, v84, v110                               // 0000001D5998: 06A8DD54
	v_rcp_f32_e32 v101, v78                                    // 0000001D599C: 7ECA554E
	v_rcp_f32_e32 v109, v96                                    // 0000001D59A0: 7EDA5560
	v_fma_f32 v110, -v70, v98, 1.0                             // 0000001D59A4: D613006E 23CAC546
	v_fma_f32 v123, -v94, v108, 1.0                            // 0000001D59AC: D613007B 23CAD95E
	v_div_scale_f32 v73, vcc_lo, v24, v47, v24                 // 0000001D59B4: D6FC6A49 04625F18
	v_div_scale_f32 v75, s0, v25, v46, v25                     // 0000001D59BC: D6FC004B 04665D19
	v_div_scale_f32 v95, s9, v20, v67, v20                     // 0000001D59C4: D6FC095F 04528714
	v_fma_f32 v114, -v74, v99, 1.0                             // 0000001D59CC: D6130072 23CAC74A
	v_fmac_f32_e32 v98, v110, v98                              // 0000001D59D4: 56C4C56E
	v_fmac_f32_e32 v108, v123, v108                            // 0000001D59D8: 56D8D97B
	v_fma_f32 v116, -v78, v101, 1.0                            // 0000001D59DC: D6130074 23CACB4E
	v_fma_f32 v124, -v96, v109, 1.0                            // 0000001D59E4: D613007C 23CADB60
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001D59EC: BF8701C4
	v_dual_fmac_f32 v99, v114, v99 :: v_dual_mul_f32 v110, v73, v98// 0000001D59F0: C806C772 636EC549
	v_rcp_f32_e32 v106, v90                                    // 0000001D59F8: 7ED4555A
	v_mul_f32_e32 v123, v95, v108                              // 0000001D59FC: 10F6D95F
	v_div_scale_f32 v79, s2, v27, v48, v27                     // 0000001D5A00: D6FC024F 046E611B
	v_dual_mul_f32 v114, v75, v99 :: v_dual_fmac_f32 v101, v116, v101// 0000001D5A08: C8C0C74B 7264CB74
	v_fmac_f32_e32 v109, v124, v109                            // 0000001D5A10: 56DADB7C
	v_fma_f32 v124, -v70, v110, v73                            // 0000001D5A14: D613007C 2526DD46
	v_div_scale_f32 v83, s4, v29, v53, v29                     // 0000001D5A1C: D6FC0453 04766B1D
	v_fmac_f32_e32 v103, v118, v103                            // 0000001D5A24: 56CECF76
	v_fma_f32 v125, -v74, v114, v75                            // 0000001D5A28: D613007D 252EE54A
	v_mul_f32_e32 v116, v79, v101                              // 0000001D5A30: 10E8CB4F
	v_fmac_f32_e32 v110, v124, v98                             // 0000001D5A34: 56DCC57C
	v_fma_f32 v121, -v90, v106, 1.0                            // 0000001D5A38: D6130079 23CAD55A
	v_mul_f32_e32 v118, v83, v103                              // 0000001D5A40: 10ECCF53
	v_fmac_f32_e32 v114, v125, v99                             // 0000001D5A44: 56E4C77D
	v_fma_f32 v127, -v78, v116, v79                            // 0000001D5A48: D613007F 253EE94E
	v_fma_f32 v70, -v70, v110, v73                             // 0000001D5A50: D6130046 2526DD46
	v_fmac_f32_e32 v106, v121, v106                            // 0000001D5A58: 56D4D579
	v_fma_f32 v129, -v82, v118, v83                            // 0000001D5A5C: D6130081 254EED52
	v_fma_f32 v73, -v74, v114, v75                             // 0000001D5A64: D6130049 252EE54A
	v_fmac_f32_e32 v116, v127, v101                            // 0000001D5A6C: 56E8CB7F
	v_div_fmas_f32 v70, v70, v98, v110                         // 0000001D5A70: D6370046 05BAC546
	s_mov_b32 vcc_lo, s0                                       // 0000001D5A78: BEEA0000
	v_fma_f32 v74, -v76, v115, v77                             // 0000001D5A7C: D613004A 2536E74C
	v_dual_mul_f32 v121, v91, v106 :: v_dual_fmac_f32 v118, v129, v103// 0000001D5A84: C8C0D55B 7976CF81
	v_div_fmas_f32 v73, v73, v99, v114                         // 0000001D5A8C: D6370049 05CAC749
	v_fma_f32 v75, -v78, v116, v79                             // 0000001D5A94: D613004B 253EE94E
	s_mov_b32 vcc_lo, s1                                       // 0000001D5A9C: BEEA0001
	v_fma_f32 v76, -v80, v117, v81                             // 0000001D5AA0: D613004C 2546EB50
	v_div_fmas_f32 v74, v74, v100, v115                        // 0000001D5AA8: D637004A 05CEC94A
	s_mov_b32 vcc_lo, s2                                       // 0000001D5AB0: BEEA0002
	v_fma_f32 v132, -v90, v121, v91                            // 0000001D5AB4: D6130084 256EF35A
	v_add_f32_e32 v56, 1.0, v56                                // 0000001D5ABC: 067070F2
	v_fma_f32 v77, -v82, v118, v83                             // 0000001D5AC0: D613004D 254EED52
	v_div_fixup_f32 v25, v73, v46, v25                         // 0000001D5AC8: D6270019 04665D49
	v_div_fixup_f32 v24, v70, v47, v24                         // 0000001D5AD0: D6270018 04625F46
	v_div_fmas_f32 v47, v75, v101, v116                        // 0000001D5AD8: D637002F 05D2CB4B
	s_mov_b32 vcc_lo, s3                                       // 0000001D5AE0: BEEA0003
	v_fmac_f32_e32 v121, v132, v106                            // 0000001D5AE4: 56F2D584
	v_div_fmas_f32 v46, v76, v102, v117                        // 0000001D5AE8: D637002E 05D6CD4C
	s_mov_b32 vcc_lo, s4                                       // 0000001D5AF0: BEEA0004
	v_div_scale_f32 v88, null, v56, v56, v17                   // 0000001D5AF4: D6FC7C58 04467138
	v_div_fixup_f32 v26, v74, v49, v26                         // 0000001D5AFC: D627001A 046A634A
	v_div_fmas_f32 v49, v77, v103, v118                        // 0000001D5B04: D6370031 05DACF4D
	.long 0x7e6c3999                                           // 0000001D5B0C: 7E6C3999
	v_add_f32_e32 v64, 1.0, v64                                // 0000001D5B10: 068080F2
	v_rcp_f32_e32 v105, v88                                    // 0000001D5B14: 7ED25558
	v_div_scale_f32 v89, s6, v17, v56, v17                     // 0000001D5B18: D6FC0659 04467111
	v_div_fixup_f32 v29, v49, v53, v29                         // 0000001D5B20: D627001D 04766B31
	v_and_b32_e32 v53, 1, v54                                  // 0000001D5B28: 366A6C81
	v_div_scale_f32 v92, null, v64, v64, v19                   // 0000001D5B2C: D6FC7C5C 044E8140
	v_div_scale_f32 v93, s8, v19, v64, v19                     // 0000001D5B34: D6FC085D 044E8113
	v_fma_f32 v78, -v86, v119, v87                             // 0000001D5B3C: D613004E 255EEF56
	v_div_fixup_f32 v27, v47, v48, v27                         // 0000001D5B44: D627001B 046E612F
	s_mov_b32 vcc_lo, s5                                       // 0000001D5B4C: BEEA0005
	v_rcp_f32_e32 v107, v92                                    // 0000001D5B50: 7ED6555C
	v_fma_f32 v120, -v88, v105, 1.0                            // 0000001D5B54: D6130078 23CAD358
	v_fma_f32 v80, -v90, v121, v91                             // 0000001D5B5C: D6130050 256EF35A
	v_div_fmas_f32 v47, v78, v104, v119                        // 0000001D5B64: D637002F 05DED14E
	s_mov_b32 vcc_lo, s6                                       // 0000001D5B6C: BEEA0006
	.long 0x7e7a3998                                           // 0000001D5B70: 7E7A3998
	v_fmac_f32_e32 v105, v120, v105                            // 0000001D5B74: 56D2D378
	v_div_fixup_f32 v28, v46, v55, v28                         // 0000001D5B78: D627001C 04726F2E
	.long 0x7e6c399b                                           // 0000001D5B80: 7E6C399B
	v_div_fixup_f32 v16, v47, v63, v16                         // 0000001D5B84: D6270010 04427F2F
	v_fma_f32 v122, -v92, v107, 1.0                            // 0000001D5B8C: D613007A 23CAD75C
	v_mul_f32_e32 v120, v89, v105                              // 0000001D5B94: 10F0D359
	v_and_b32_e32 v48, 1, v61                                  // 0000001D5B98: 36607A81
	.long 0x7e78399a                                           // 0000001D5B9C: 7E78399A
	.long 0x7e76399c                                           // 0000001D5BA0: 7E76399C
	v_fmac_f32_e32 v107, v122, v107                            // 0000001D5BA4: 56D6D77A
	v_fma_f32 v131, -v88, v120, v89                            // 0000001D5BA8: D6130083 2566F158
	v_add3_u32 v24, v24, v48, 0x7fff                           // 0000001D5BB0: D6550018 03FE6118 00007FFF
	.long 0x7e743990                                           // 0000001D5BBC: 7E743990
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D5BC0: BF870214
	v_dual_mul_f32 v122, v93, v107 :: v_dual_and_b32 v55, 1, v60// 0000001D5BC4: C8E4D75D 7A367881
	v_fmac_f32_e32 v120, v131, v105                            // 0000001D5BCC: 56F0D383
	v_add3_u32 v25, v25, v53, 0x7fff                           // 0000001D5BD0: D6550019 03FE6B19 00007FFF
	v_and_b32_e32 v48, 1, v59                                  // 0000001D5BDC: 36607681
	s_clause 0x1                                               // 0000001D5BE0: BF850001
	global_store_d16_hi_b16 v[34:35], v24, off                 // 0000001D5BE4: DC960000 007C1822
	global_store_d16_hi_b16 v[34:35], v25, off offset:1024     // 0000001D5BEC: DC960400 007C1922
	v_fma_f32 v133, -v92, v122, v93                            // 0000001D5BF4: D6130085 2576F55C
	v_fma_f32 v79, -v88, v120, v89                             // 0000001D5BFC: D613004F 2566F158
	v_and_b32_e32 v24, 1, v58                                  // 0000001D5C04: 36307481
	v_add3_u32 v26, v26, v55, 0x7fff                           // 0000001D5C08: D655001A 03FE6F1A 00007FFF
	v_add3_u32 v28, v28, v48, 0x7fff                           // 0000001D5C14: D655001C 03FE611C 00007FFF
	v_fmac_f32_e32 v122, v133, v107                            // 0000001D5C20: 56F4D785
	v_div_fmas_f32 v46, v79, v105, v120                        // 0000001D5C24: D637002E 05E2D34F
	s_mov_b32 vcc_lo, s7                                       // 0000001D5C2C: BEEA0007
	v_exp_f32_e32 v84, v84                                     // 0000001D5C30: 7EA84B54
	v_div_fmas_f32 v49, v80, v106, v121                        // 0000001D5C34: D6370031 05E6D550
	v_fma_f32 v81, -v92, v122, v93                             // 0000001D5C3C: D6130051 2576F55C
	s_mov_b32 vcc_lo, s8                                       // 0000001D5C44: BEEA0008
	v_div_fixup_f32 v17, v46, v56, v17                         // 0000001D5C48: D6270011 0446712E
	v_and_b32_e32 v46, 1, v54                                  // 0000001D5C50: 365C6C81
	.long 0x7e6c399d                                           // 0000001D5C54: 7E6C399D
	v_div_fmas_f32 v47, v81, v107, v122                        // 0000001D5C58: D637002F 05EAD751
	v_add3_u32 v16, v16, v24, 0x7fff                           // 0000001D5C60: D6550010 03FE3110 00007FFF
	v_div_scale_f32 v97, s10, v21, v66, v21                    // 0000001D5C6C: D6FC0A61 04568515
	v_add3_u32 v25, v27, v46, 0x7fff                           // 0000001D5C74: D6550019 03FE5D1B 00007FFF
	v_cvt_i32_f32_e32 v24, v111                                // 0000001D5C80: 7E30116F
	v_div_fixup_f32 v19, v47, v64, v19                         // 0000001D5C84: D6270013 044E812F
	v_and_b32_e32 v47, 1, v54                                  // 0000001D5C8C: 365E6C81
	.long 0x7e6c3991                                           // 0000001D5C90: 7E6C3991
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v69                  // 0000001D5C94: 7C3C8AFF 42CE8ED0
	.long 0xd71c0018                                           // 0000001D5C9C: D71C0018
	v_cndmask_b32_e32 v1, v84, v24, vcc_lo                     // 0000001D5CA0: 02023154
	v_div_fixup_f32 v18, v49, v65, v18                         // 0000001D5CA4: D6270012 044A8331
	v_add3_u32 v29, v29, v47, 0x7fff                           // 0000001D5CAC: D655001D 03FE5F1D 00007FFF
	v_and_b32_e32 v27, 1, v54                                  // 0000001D5CB8: 36366C81
	.long 0x7e6c3993                                           // 0000001D5CBC: 7E6C3993
	v_cndmask_b32_e32 v24, 0, v24, vcc_lo                      // 0000001D5CC0: 02303080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v69                  // 0000001D5CC4: 7C368AFF C2B17218
	.long 0x7e723992                                           // 0000001D5CCC: 7E723992
	v_add3_u32 v17, v17, v27, 0x7fff                           // 0000001D5CD0: D6550011 03FE3711 00007FFF
	s_clause 0x5                                               // 0000001D5CDC: BF850005
	global_store_d16_hi_b16 v[6:7], v26, off                   // 0000001D5CE0: DC960000 007C1A06
	global_store_d16_hi_b16 v[14:15], v25, off                 // 0000001D5CE8: DC960000 007C190E
	global_store_d16_hi_b16 v[22:23], v28, off                 // 0000001D5CF0: DC960000 007C1C16
	global_store_d16_hi_b16 v[36:37], v29, off                 // 0000001D5CF8: DC960000 007C1D24
	global_store_d16_hi_b16 v[34:35], v16, off offset:32       // 0000001D5D00: DC960020 007C1022
	global_store_d16_hi_b16 v[38:39], v17, off offset:32       // 0000001D5D08: DC960020 007C1126
	v_sub_f32_e32 v16, v85, v113                               // 0000001D5D10: 0820E355
	v_fma_f32 v25, -v94, v123, v95                             // 0000001D5D14: D6130019 257EF75E
	v_dual_mul_f32 v26, v97, v109 :: v_dual_and_b32 v17, 1, v54// 0000001D5D1C: C8E4DB61 1A106C81
	v_cndmask_b32_e32 v24, 0x7f800000, v24, vcc_lo             // 0000001D5D24: 023030FF 7F800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D5D2C: BF870214
	v_add_f32_e32 v16, v16, v112                               // 0000001D5D30: 0620E110
	v_fmac_f32_e32 v123, v25, v108                             // 0000001D5D34: 56F6D919
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D5D38: BF870004
	v_fma_f32 v25, -v96, v26, v97                              // 0000001D5D3C: D6130019 25863560
	s_mov_b32 vcc_lo, s9                                       // 0000001D5D44: BEEA0009
	v_add_f32_e32 v24, 1.0, v24                                // 0000001D5D48: 063030F2
	v_exp_f32_e32 v16, v16                                     // 0000001D5D4C: 7E204B10
	v_fma_f32 v28, -v94, v123, v95                             // 0000001D5D50: D613001C 257EF75E
	v_fmac_f32_e32 v26, v25, v109                              // 0000001D5D58: 5634DB19
	v_cvt_i32_f32_e32 v25, v113                                // 0000001D5D5C: 7E321171
	v_and_b32_e32 v27, 1, v57                                  // 0000001D5D60: 36367281
	v_add3_u32 v17, v19, v17, 0x7fff                           // 0000001D5D64: D6550011 03FE2313 00007FFF
	v_div_fmas_f32 v28, v28, v108, v123                        // 0000001D5D70: D637001C 05EED91C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v68                  // 0000001D5D78: 7C3C88FF 42CE8ED0
	v_lshlrev_b32_e32 v49, 16, v71                             // 0000001D5D80: 30628E90
	v_add3_u32 v18, v18, v27, 0x7fff                           // 0000001D5D84: D6550012 03FE3712 00007FFF
	.long 0xd71c0010                                           // 0000001D5D90: D71C0010
	v_cndmask_b32_e32 v1, v16, v25, vcc_lo                     // 0000001D5D94: 02023310
	v_fma_f32 v25, -v96, v26, v97                              // 0000001D5D98: D6130019 25863560
	v_div_fixup_f32 v20, v28, v67, v20                         // 0000001D5DA0: D6270014 0452871C
	v_mul_f32_e32 v56, 0xbfb8aa3b, v49                         // 0000001D5DA8: 107062FF BFB8AA3B
	.long 0x7f3839b6                                           // 0000001D5DB0: 7F3839B6
	v_cndmask_b32_e32 v16, 0, v16, vcc_lo                      // 0000001D5DB4: 02202080
	s_mov_b32 vcc_lo, s10                                      // 0000001D5DB8: BEEA000A
	.long 0x7e383994                                           // 0000001D5DBC: 7E383994
	v_div_fmas_f32 v25, v25, v109, v26                         // 0000001D5DC0: D6370019 046ADB19
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v68                  // 0000001D5DC8: 7C3688FF C2B17218
	v_div_scale_f32 v26, null, v24, v24, v8                    // 0000001D5DD0: D6FC7C1A 04223118
	v_fma_f32 v59, 0xbfb8aa3b, v49, -v56                       // 0000001D5DD8: D613003B 84E262FF BFB8AA3B
	v_rndne_f32_e32 v60, v56                                   // 0000001D5DE4: 7E784738
	v_div_fixup_f32 v19, v25, v66, v21                         // 0000001D5DE8: D6270013 04568519
	v_cndmask_b32_e32 v16, 0x7f800000, v16, vcc_lo             // 0000001D5DF0: 022020FF 7F800000
	v_rcp_f32_e32 v21, v26                                     // 0000001D5DF8: 7E2A551A
	v_lshlrev_b32_e32 v25, 16, v62                             // 0000001D5DFC: 30327C90
	v_fmac_f32_e32 v59, 0xb2a5705f, v49                        // 0000001D5E00: 567662FF B2A5705F
	.long 0x7e6c3993                                           // 0000001D5E08: 7E6C3993
	v_add_f32_e32 v16, 1.0, v16                                // 0000001D5E0C: 062020F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D5E10: BF870224
	v_dual_sub_f32 v56, v56, v60 :: v_dual_mul_f32 v29, 0xbfb8aa3b, v25// 0000001D5E14: C9467938 381C32FF BFB8AA3B
	.long 0xd41e0001                                           // 0000001D5E20: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001D5E24: 020232FF 42CE8ED0
	v_and_b32_e32 v48, 1, v54                                  // 0000001D5E2C: 36606C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001D5E30: BF870294
	v_div_scale_f32 v27, null, v16, v16, v9                    // 0000001D5E34: D6FC7C1B 04262110
	v_fma_f32 v46, -v26, v21, 1.0                              // 0000001D5E3C: D613002E 23CA2B1A
	v_fma_f32 v53, 0xbfb8aa3b, v25, -v29                       // 0000001D5E44: D6130035 847632FF BFB8AA3B
	v_rndne_f32_e32 v55, v29                                   // 0000001D5E50: 7E6E471D
	v_add_f32_e32 v56, v56, v59                                // 0000001D5E54: 06707738
	v_rcp_f32_e32 v47, v27                                     // 0000001D5E58: 7E5E551B
	v_fmac_f32_e32 v21, v46, v21                               // 0000001D5E5C: 562A2B2E
	v_div_scale_f32 v46, vcc_lo, v8, v24, v8                   // 0000001D5E60: D6FC6A2E 04223108
	v_fmac_f32_e32 v53, 0xb2a5705f, v25                        // 0000001D5E68: 566A32FF B2A5705F
	v_sub_f32_e32 v29, v29, v55                                // 0000001D5E70: 083A6F1D
	v_cvt_i32_f32_e32 v55, v55                                 // 0000001D5E74: 7E6E1137
	v_add3_u32 v19, v19, v48, 0x7fff                           // 0000001D5E78: D6550013 03FE6113 00007FFF
	v_mul_f32_e32 v58, v46, v21                                // 0000001D5E84: 10742B2E
	v_exp_f32_e32 v48, v56                                     // 0000001D5E88: 7E604B38
	v_add_f32_e32 v29, v29, v53                                // 0000001D5E8C: 063A6B1D
	v_fma_f32 v57, -v27, v47, 1.0                              // 0000001D5E90: D6130039 23CA5F1B
	v_div_scale_f32 v53, s0, v9, v16, v9                       // 0000001D5E98: D6FC0035 04262109
	v_and_b32_e32 v28, 1, v28                                  // 0000001D5EA0: 36383881
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D5EA4: BF870194
	v_exp_f32_e32 v29, v29                                     // 0000001D5EA8: 7E3A4B1D
	v_fmac_f32_e32 v47, v57, v47                               // 0000001D5EAC: 565E5F39
	v_fma_f32 v57, -v26, v58, v46                              // 0000001D5EB0: D6130039 24BA751A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D5EB8: BF870003
	v_add3_u32 v20, v20, v28, 0x7fff                           // 0000001D5EBC: D6550014 03FE3914 00007FFF
	s_clause 0x3                                               // 0000001D5EC8: BF850003
	global_store_d16_hi_b16 v[6:7], v18, off offset:32         // 0000001D5ECC: DC960020 007C1206
	global_store_d16_hi_b16 v[14:15], v17, off offset:32       // 0000001D5ED4: DC960020 007C110E
	global_store_d16_hi_b16 v[22:23], v20, off offset:32       // 0000001D5EDC: DC960020 007C1416
	global_store_d16_hi_b16 v[36:37], v19, off offset:32       // 0000001D5EE4: DC960020 007C1324
	v_fmac_f32_e32 v58, v57, v21                               // 0000001D5EEC: 56742B39
	v_mul_f32_e32 v61, v53, v47                                // 0000001D5EF0: 107A5F35
	.long 0xd71c001d                                           // 0000001D5EF4: D71C001D
	v_cndmask_b32_e32 v1, v29, v55, vcc_lo                     // 0000001D5EF8: 02026F1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D5EFC: BF870193
	v_fma_f32 v26, -v26, v58, v46                              // 0000001D5F00: D613001A 24BA751A
	v_fma_f32 v57, -v27, v61, v53                              // 0000001D5F08: D6130039 24D67B1B
	v_cvt_i32_f32_e32 v46, v60                                 // 0000001D5F10: 7E5C113C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D5F14: BF870214
	v_cndmask_b32_e64 v29, 0, v29, s1                          // 0000001D5F18: D501001D 00063A80
	v_div_fmas_f32 v21, v26, v21, v58                          // 0000001D5F20: D6370015 04EA2B1A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001D5F28: 7C3632FF C2B17218
	v_fmac_f32_e32 v61, v57, v47                               // 0000001D5F30: 567A5F39
	.long 0xd71c001a                                           // 0000001D5F34: D71C001A
	v_cndmask_b32_e32 v1, v48, v46, vcc_lo                     // 0000001D5F38: 02025D30
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D5F3C: BF870004
	v_div_fixup_f32 v8, v21, v24, v8                           // 0000001D5F40: D6270008 04223115
	v_cndmask_b32_e32 v25, 0x7f800000, v29, vcc_lo             // 0000001D5F48: 02323AFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001D5F50: 7C3C62FF 42CE8ED0
	v_fma_f32 v27, -v27, v61, v53                              // 0000001D5F58: D613001B 24D67B1B
	v_lshlrev_b32_e32 v29, 16, v51                             // 0000001D5F60: 303A6690
	.long 0x7e303988                                           // 0000001D5F64: 7E303988
	v_dual_add_f32 v25, 1.0, v25 :: v_dual_cndmask_b32 v26, 0, v26// 0000001D5F68: C91232F2 191A3480
	s_mov_b32 vcc_lo, s0                                       // 0000001D5F70: BEEA0000
	.long 0x7f3039b6                                           // 0000001D5F74: 7F3039B6
	v_div_fmas_f32 v27, v27, v47, v61                          // 0000001D5F78: D637001B 04F65F1B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001D5F80: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D5F88: BF870193
	v_dual_mul_f32 v47, 0xbfb8aa3b, v29 :: v_dual_and_b32 v24, 1, v24// 0000001D5F8C: C8E43AFF 2F183081 BFB8AA3B
	v_div_fixup_f32 v9, v27, v16, v9                           // 0000001D5F98: D6270009 0426211B
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 0000001D5FA0: 023434FF 7F800000
	v_div_scale_f32 v16, null, v25, v25, v10                   // 0000001D5FA8: D6FC7C10 042A3319
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D5FB0: BF870004
	v_fma_f32 v18, 0xbfb8aa3b, v29, -v47                       // 0000001D5FB4: D6130012 84BE3AFF BFB8AA3B
	v_rndne_f32_e32 v19, v47                                   // 0000001D5FC0: 7E26472F
	.long 0x7e6c3989                                           // 0000001D5FC4: 7E6C3989
	v_add_f32_e32 v21, 1.0, v26                                // 0000001D5FC8: 062A34F2
	v_rcp_f32_e32 v26, v16                                     // 0000001D5FCC: 7E345510
	v_add3_u32 v8, v8, v24, 0x7fff                             // 0000001D5FD0: D6550008 03FE3108 00007FFF
	v_fmac_f32_e32 v18, 0xb2a5705f, v29                        // 0000001D5FDC: 56243AFF B2A5705F
	v_and_b32_e32 v28, 1, v54                                  // 0000001D5FE4: 36386C81
	v_div_scale_f32 v27, null, v21, v21, v11                   // 0000001D5FE8: D6FC7C1B 042E2B15
	v_sub_f32_e32 v24, v47, v19                                // 0000001D5FF0: 0830272F
	global_store_d16_hi_b16 v[34:35], v8, off offset:64        // 0000001D5FF4: DC960040 007C0822
	v_cvt_i32_f32_e32 v19, v19                                 // 0000001D5FFC: 7E261113
	v_add3_u32 v9, v9, v28, 0x7fff                             // 0000001D6000: D6550009 03FE3909 00007FFF
	v_rcp_f32_e32 v46, v27                                     // 0000001D600C: 7E5C551B
	v_fma_f32 v17, -v16, v26, 1.0                              // 0000001D6010: D6130011 23CA3510
	v_lshlrev_b32_e32 v28, 16, v72                             // 0000001D6018: 30389090
	v_add_f32_e32 v18, v24, v18                                // 0000001D601C: 06242518
	global_store_d16_hi_b16 v[38:39], v9, off offset:64        // 0000001D6020: DC960040 007C0926
	v_fmac_f32_e32 v26, v17, v26                               // 0000001D6028: 56343511
	v_div_scale_f32 v17, vcc_lo, v10, v25, v10                 // 0000001D602C: D6FC6A11 042A330A
	v_mul_f32_e32 v24, 0xbfb8aa3b, v28                         // 0000001D6034: 103038FF BFB8AA3B
	v_exp_f32_e32 v18, v18                                     // 0000001D603C: 7E244B12
	v_fma_f32 v20, -v27, v46, 1.0                              // 0000001D6040: D6130014 23CA5D1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D6048: BF870193
	v_mul_f32_e32 v47, v17, v26                                // 0000001D604C: 105E3511
	v_fma_f32 v49, 0xbfb8aa3b, v28, -v24                       // 0000001D6050: D6130031 846238FF BFB8AA3B
	v_rndne_f32_e32 v51, v24                                   // 0000001D605C: 7E664718
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001D6060: BF870234
	v_fmac_f32_e32 v46, v20, v46                               // 0000001D6064: 565C5D14
	v_div_scale_f32 v20, s0, v11, v21, v11                     // 0000001D6068: D6FC0014 042E2B0B
	v_fma_f32 v8, -v16, v47, v17                               // 0000001D6070: D6130008 24465F10
	v_dual_fmac_f32 v49, 0xb2a5705f, v28 :: v_dual_sub_f32 v24, v24, v51// 0000001D6078: C80A38FF 31186718 B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D6084: BF870193
	v_mul_f32_e32 v48, v20, v46                                // 0000001D6088: 10605D14
	v_fmac_f32_e32 v47, v8, v26                                // 0000001D608C: 565E3508
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D6090: BF870112
	v_fma_f32 v8, -v27, v48, v20                               // 0000001D6094: D6130008 2452611B
	v_fma_f32 v9, -v16, v47, v17                               // 0000001D609C: D6130009 24465F10
	v_add_f32_e32 v16, v24, v49                                // 0000001D60A4: 06206318
	v_lshlrev_b32_e32 v24, 16, v52                             // 0000001D60A8: 30306890
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D60AC: BF870004
	v_fmac_f32_e32 v48, v8, v46                                // 0000001D60B0: 56605D08
	.long 0xd71c0008                                           // 0000001D60B4: D71C0008
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000001D60B8: 02022712
	v_div_fmas_f32 v9, v9, v26, v47                            // 0000001D60BC: D6370009 04BE3509
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001D60C4: 7C3C3AFF 42CE8ED0
	v_exp_f32_e32 v16, v16                                     // 0000001D60CC: 7E204B10
	v_fma_f32 v17, -v27, v48, v20                              // 0000001D60D0: D6130011 2452611B
	v_cvt_i32_f32_e32 v18, v51                                 // 0000001D60D8: 7E241133
	v_div_fixup_f32 v9, v9, v25, v10                           // 0000001D60DC: D6270009 042A3309
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo                        // 0000001D60E4: 02101080
	s_mov_b32 vcc_lo, s0                                       // 0000001D60E8: BEEA0000
	v_mul_f32_e32 v27, 0xbfb8aa3b, v24                         // 0000001D60EC: 103630FF BFB8AA3B
	v_div_fmas_f32 v17, v17, v46, v48                          // 0000001D60F4: D6370011 04C25D11
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001D60FC: 7C363AFF C2B17218
	.long 0x7e323989                                           // 0000001D6104: 7E323989
	.long 0x7f3239b6                                           // 0000001D6108: 7F3239B6
	v_fma_f32 v29, 0xbfb8aa3b, v24, -v27                       // 0000001D610C: D613001D 846E30FF BFB8AA3B
	v_div_fixup_f32 v10, v17, v21, v11                         // 0000001D6118: D627000A 042E2B11
	v_cndmask_b32_e32 v8, 0x7f800000, v8, vcc_lo               // 0000001D6120: 021010FF 7F800000
	.long 0xd71c000b                                           // 0000001D6128: D71C000B
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 0000001D612C: 02022510
	v_lshlrev_b32_e32 v16, 16, v50                             // 0000001D6130: 30206490
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v28                  // 0000001D6134: 7C3C38FF 42CE8ED0
	v_rndne_f32_e32 v46, v27                                   // 0000001D613C: 7E5C471B
	v_add_f32_e32 v8, 1.0, v8                                  // 0000001D6140: 061010F2
	v_fmac_f32_e32 v29, 0xb2a5705f, v24                        // 0000001D6144: 563A30FF B2A5705F
	v_dual_mul_f32 v18, 0xbfb8aa3b, v16 :: v_dual_cndmask_b32 v11, 0, v11// 0000001D614C: C8D220FF 120A1680 BFB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v28                  // 0000001D6158: 7C3638FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D6160: BF870224
	v_div_scale_f32 v17, null, v8, v8, v12                     // 0000001D6164: D6FC7C11 04321108
	v_sub_f32_e32 v27, v27, v46                                // 0000001D616C: 08365D1B
	v_fma_f32 v20, 0xbfb8aa3b, v16, -v18                       // 0000001D6170: D6130014 844A20FF BFB8AA3B
	v_rndne_f32_e32 v21, v18                                   // 0000001D617C: 7E2A4712
	v_cndmask_b32_e32 v11, 0x7f800000, v11, vcc_lo             // 0000001D6180: 021616FF 7F800000
	v_rcp_f32_e32 v19, v17                                     // 0000001D6188: 7E265511
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D618C: BF870113
	v_dual_add_f32 v27, v27, v29 :: v_dual_fmac_f32 v20, 0xb2a5705f, v16// 0000001D6190: C9003B1B 1B1420FF B2A5705F
	v_dual_sub_f32 v18, v18, v21 :: v_dual_add_f32 v11, 1.0, v11// 0000001D619C: C9482B12 120A16F2
	v_cvt_i32_f32_e32 v21, v21                                 // 0000001D61A4: 7E2A1115
	.long 0xd41e0001                                           // 0000001D61A8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v16, vcc_lo              // 0000001D61AC: 020220FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D61B4: BF870194
	v_exp_f32_e32 v27, v27                                     // 0000001D61B8: 7E364B1B
	v_add_f32_e32 v18, v18, v20                                // 0000001D61BC: 06242912
	v_div_scale_f32 v26, null, v11, v11, v13                   // 0000001D61C0: D6FC7C1A 0436170B
	s_delay_alu instid0(TRANS32_DEP_2)                         // 0000001D61C8: BF870006
	v_fma_f32 v28, -v17, v19, 1.0                              // 0000001D61CC: D613001C 23CA2711
	v_cvt_i32_f32_e32 v46, v46                                 // 0000001D61D4: 7E5C112E
	v_and_b32_e32 v25, 1, v25                                  // 0000001D61D8: 36323281
	v_exp_f32_e32 v18, v18                                     // 0000001D61DC: 7E244B12
	v_rcp_f32_e32 v20, v26                                     // 0000001D61E0: 7E28551A
	v_fmac_f32_e32 v19, v28, v19                               // 0000001D61E4: 5626271C
	v_div_scale_f32 v28, vcc_lo, v12, v8, v12                  // 0000001D61E8: D6FC6A1C 0432110C
	.long 0xd71c001b                                           // 0000001D61F0: D71C001B
	v_cndmask_b32_e32 v1, v27, v46, vcc_lo                     // 0000001D61F4: 02025D1B
	v_add3_u32 v9, v9, v25, 0x7fff                             // 0000001D61F8: D6550009 03FE3309 00007FFF
	.long 0x7e6c398a                                           // 0000001D6204: 7E6C398A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001D6208: BF870314
	v_mul_f32_e32 v29, v28, v19                                // 0000001D620C: 103A271C
	.long 0xd71c0012                                           // 0000001D6210: D71C0012
	v_cndmask_b32_e32 v1, v18, v21, vcc_lo                     // 0000001D6214: 02022B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001D6218: BF870235
	v_fma_f32 v48, -v26, v20, 1.0                              // 0000001D621C: D6130030 23CA291A
	v_div_scale_f32 v21, s0, v13, v11, v13                     // 0000001D6224: D6FC0015 0436170D
	v_and_b32_e32 v47, 1, v54                                  // 0000001D622C: 365E6C81
	v_cndmask_b32_e64 v18, 0, v18, s1                          // 0000001D6230: D5010012 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001D6238: BF870244
	v_fmac_f32_e32 v20, v48, v20                               // 0000001D623C: 56282930
	.long 0xd41b0001                                           // 0000001D6240: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v16, vcc_lo              // 0000001D6244: 020220FF C2B17218
	v_fma_f32 v48, -v17, v29, v28                              // 0000001D624C: D6130030 24723B11
	v_add3_u32 v10, v10, v47, 0x7fff                           // 0000001D6254: D655000A 03FE5F0A 00007FFF
	v_mul_f32_e32 v49, v21, v20                                // 0000001D6260: 10622915
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D6264: BF870214
	v_cndmask_b32_e64 v16, 0x7f800000, v18, s1                 // 0000001D6268: D5010010 000624FF 7F800000
	v_fmac_f32_e32 v29, v48, v19                               // 0000001D6274: 563A2730
	.long 0xd41e0001                                           // 0000001D6278: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v24, vcc_lo              // 0000001D627C: 020230FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D6284: BF870214
	v_fma_f32 v18, -v26, v49, v21                              // 0000001D6288: D6130012 2456631A
	v_add_f32_e32 v16, 1.0, v16                                // 0000001D6290: 062020F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D6294: BF870194
	v_fma_f32 v17, -v17, v29, v28                              // 0000001D6298: D6130011 24723B11
	v_fmac_f32_e32 v49, v18, v20                               // 0000001D62A0: 56622912
	v_cndmask_b32_e64 v18, 0, v27, s1                          // 0000001D62A4: D5010012 00063680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D62AC: BF870214
	v_div_scale_f32 v27, null, v16, v16, v0                    // 0000001D62B0: D6FC7C1B 04022110
	v_div_fmas_f32 v17, v17, v19, v29                          // 0000001D62B8: D6370011 04762711
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000001D62C0: 7C3630FF C2B17218
	v_fma_f32 v19, -v26, v49, v21                              // 0000001D62C8: D6130013 2456631A
	.long 0x7f3039b6                                           // 0000001D62D0: 7F3039B6
	v_rcp_f32_e32 v21, v27                                     // 0000001D62D4: 7E2A551B
	v_div_fixup_f32 v8, v17, v8, v12                           // 0000001D62D8: D6270008 04321111
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001D62E0: 022424FF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001D62E8: BEEA0000
	v_lshlrev_b32_e32 v17, 16, v42                             // 0000001D62EC: 30225490
	v_div_fmas_f32 v19, v19, v20, v49                          // 0000001D62F0: D6370013 04C62913
	.long 0x7e303988                                           // 0000001D62F8: 7E303988
	v_add_f32_e32 v18, 1.0, v18                                // 0000001D62FC: 062424F2
	v_mul_f32_e32 v42, 0xbfb8aa3b, v32                         // 0000001D6300: 105440FF BFB8AA3B
	v_mul_f32_e32 v20, 0xbfb8aa3b, v17                         // 0000001D6308: 102822FF BFB8AA3B
	v_div_fixup_f32 v11, v19, v11, v13                         // 0000001D6310: D627000B 04361713
	v_fma_f32 v13, -v27, v21, 1.0                              // 0000001D6318: D613000D 23CA2B1B
	v_div_scale_f32 v12, null, v18, v18, v1                    // 0000001D6320: D6FC7C0C 04062512
	v_and_b32_e32 v24, 1, v24                                  // 0000001D6328: 36303081
	v_fma_f32 v28, 0xbfb8aa3b, v17, -v20                       // 0000001D632C: D613001C 845222FF BFB8AA3B
	v_rndne_f32_e32 v29, v20                                   // 0000001D6338: 7E3A4714
	v_fmac_f32_e32 v21, v13, v21                               // 0000001D633C: 562A2B0D
	v_div_scale_f32 v13, vcc_lo, v0, v16, v0                   // 0000001D6340: D6FC6A0D 04022100
	v_rcp_f32_e32 v19, v12                                     // 0000001D6348: 7E26550C
	v_fmac_f32_e32 v28, 0xb2a5705f, v17                        // 0000001D634C: 563822FF B2A5705F
	v_sub_f32_e32 v20, v20, v29                                // 0000001D6354: 08283B14
	.long 0x7e6c398b                                           // 0000001D6358: 7E6C398B
	v_mul_f32_e32 v25, v13, v21                                // 0000001D635C: 10322B0D
	v_add3_u32 v8, v8, v24, 0x7fff                             // 0000001D6360: D6550008 03FE3108 00007FFF
	v_fma_f32 v43, 0xbfb8aa3b, v32, -v42                       // 0000001D636C: D613002B 84AA40FF BFB8AA3B
	v_add_f32_e32 v20, v20, v28                                // 0000001D6378: 06283914
	v_lshlrev_b32_e32 v28, 16, v44                             // 0000001D637C: 30385890
	v_fma_f32 v30, -v27, v25, v13                              // 0000001D6380: D613001E 2436331B
	v_fma_f32 v31, -v12, v19, 1.0                              // 0000001D6388: D613001F 23CA270C
	v_and_b32_e32 v26, 1, v54                                  // 0000001D6390: 36346C81
	v_exp_f32_e32 v20, v20                                     // 0000001D6394: 7E284B14
	v_rndne_f32_e32 v44, v42                                   // 0000001D6398: 7E58472A
	v_fmac_f32_e32 v25, v30, v21                               // 0000001D639C: 56322B1E
	v_fmac_f32_e32 v19, v31, v19                               // 0000001D63A0: 5626271F
	s_waitcnt vmcnt(0)                                         // 0000001D63A4: BF8903F7
	v_lshlrev_b32_e32 v31, 16, v45                             // 0000001D63A8: 303E5A90
	v_add3_u32 v11, v11, v26, 0x7fff                           // 0000001D63AC: D655000B 03FE350B 00007FFF
	v_div_scale_f32 v26, s0, v1, v18, v1                       // 0000001D63B8: D6FC001A 04062501
	v_fma_f32 v13, -v27, v25, v13                              // 0000001D63C0: D613000D 2436331B
	v_mul_f32_e32 v27, 0xbfb8aa3b, v28                         // 0000001D63C8: 103638FF BFB8AA3B
	v_fmac_f32_e32 v43, 0xb2a5705f, v32                        // 0000001D63D0: 565640FF B2A5705F
	v_sub_f32_e32 v42, v42, v44                                // 0000001D63D8: 0854592A
	v_mul_f32_e32 v24, v26, v19                                // 0000001D63DC: 1030271A
	v_div_fmas_f32 v13, v13, v21, v25                          // 0000001D63E0: D637000D 04662B0D
	v_cvt_i32_f32_e32 v25, v29                                 // 0000001D63E8: 7E32111D
	v_fma_f32 v29, 0xbfb8aa3b, v28, -v27                       // 0000001D63EC: D613001D 846E38FF BFB8AA3B
	v_rndne_f32_e32 v30, v27                                   // 0000001D63F8: 7E3C471B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000001D63FC: 7C3C22FF 42CE8ED0
	v_fma_f32 v21, -v12, v24, v26                              // 0000001D6404: D6130015 246A310C
	.long 0xd71c0014                                           // 0000001D640C: D71C0014
	v_cndmask_b32_e32 v1, v20, v25, vcc_lo                     // 0000001D6410: 02023314
	v_fmac_f32_e32 v29, 0xb2a5705f, v28                        // 0000001D6414: 563A38FF B2A5705F
	v_sub_f32_e32 v25, v27, v30                                // 0000001D641C: 08323D1B
	v_mul_f32_e32 v27, 0xbfb8aa3b, v31                         // 0000001D6420: 10363EFF BFB8AA3B
	v_cvt_i32_f32_e32 v30, v30                                 // 0000001D6428: 7E3C111E
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001D642C: 02282880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000001D6430: 7C3622FF C2B17218
	v_add_f32_e32 v25, v25, v29                                // 0000001D6438: 06323B19
	v_fma_f32 v29, 0xbfb8aa3b, v31, -v27                       // 0000001D643C: D613001D 846E3EFF BFB8AA3B
	v_fmac_f32_e32 v24, v21, v19                               // 0000001D6448: 56302715
	s_clause 0x3                                               // 0000001D644C: BF850003
	global_store_d16_hi_b16 v[6:7], v9, off offset:64          // 0000001D6450: DC960040 007C0906
	global_store_d16_hi_b16 v[14:15], v10, off offset:64       // 0000001D6458: DC960040 007C0A0E
	global_store_d16_hi_b16 v[22:23], v8, off offset:64        // 0000001D6460: DC960040 007C0816
	global_store_d16_hi_b16 v[36:37], v11, off offset:64       // 0000001D6468: DC960040 007C0B24
	v_cndmask_b32_e32 v17, 0x7f800000, v20, vcc_lo             // 0000001D6470: 022228FF 7F800000
	v_rndne_f32_e32 v20, v27                                   // 0000001D6478: 7E28471B
	v_exp_f32_e32 v25, v25                                     // 0000001D647C: 7E324B19
	v_fmac_f32_e32 v29, 0xb2a5705f, v31                        // 0000001D6480: 563A3EFF B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v28                  // 0000001D6488: 7C3C38FF 42CE8ED0
	v_fma_f32 v12, -v12, v24, v26                              // 0000001D6490: D613000C 246A310C
	v_sub_f32_e32 v27, v27, v20                                // 0000001D6498: 0836291B
	v_cvt_i32_f32_e32 v20, v20                                 // 0000001D649C: 7E281114
	v_cvt_i32_f32_e32 v26, v44                                 // 0000001D64A0: 7E34112C
	v_add_f32_e32 v17, 1.0, v17                                // 0000001D64A4: 062222F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001D64A8: BF870294
	v_add_f32_e32 v27, v27, v29                                // 0000001D64AC: 06363B1B
	.long 0xd71c0015                                           // 0000001D64B0: D71C0015
	v_cndmask_b32_e32 v1, v25, v30, vcc_lo                     // 0000001D64B4: 02023D19
	v_add_f32_e32 v29, v42, v43                                // 0000001D64B8: 063A572A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D64BC: BF870214
	v_div_scale_f32 v25, null, v17, v17, v2                    // 0000001D64C0: D6FC7C19 040A2311
	v_exp_f32_e32 v27, v27                                     // 0000001D64C8: 7E364B1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D64CC: BF870193
	v_cndmask_b32_e32 v21, 0, v21, vcc_lo                      // 0000001D64D0: 022A2A80
	v_exp_f32_e32 v29, v29                                     // 0000001D64D4: 7E3A4B1D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v28                  // 0000001D64D8: 7C3638FF C2B17218
	v_rcp_f32_e32 v30, v25                                     // 0000001D64E0: 7E3C5519
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_3)// 0000001D64E4: BF8703A2
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001D64E8: 022A2AFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v31                  // 0000001D64F0: 7C3C3EFF 42CE8ED0
	.long 0xd71c0014                                           // 0000001D64F8: D71C0014
	v_cndmask_b32_e32 v1, v27, v20, vcc_lo                     // 0000001D64FC: 0202291B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D6500: BF870216
	.long 0xd71c001a                                           // 0000001D6504: D71C001A
	v_cndmask_b32_e32 v1, v29, v26, vcc_lo                     // 0000001D6508: 0202351D
	v_add_f32_e32 v21, 1.0, v21                                // 0000001D650C: 062A2AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D6510: BF870215
	v_fma_f32 v27, -v25, v30, 1.0                              // 0000001D6514: D613001B 23CA3D19
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001D651C: 02282880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 0000001D6520: 7C3C40FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D6528: BF870214
	v_div_scale_f32 v28, null, v21, v21, v3                    // 0000001D652C: D6FC7C1C 040E2B15
	v_fmac_f32_e32 v30, v27, v30                               // 0000001D6534: 563C3D1B
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000001D6538: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v31                  // 0000001D653C: 7C363EFF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001D6544: BF870134
	v_rcp_f32_e32 v29, v28                                     // 0000001D6548: 7E3A551C
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 0000001D654C: 022828FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 0000001D6554: 7C3640FF C2B17218
	v_add_f32_e32 v20, 1.0, v20                                // 0000001D655C: 062828F2
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 0000001D6560: 023434FF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001D6568: BEEA0000
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001D656C: BF870005
	v_fma_f32 v27, -v28, v29, 1.0                              // 0000001D6570: D613001B 23CA3B1C
	v_div_fmas_f32 v12, v12, v19, v24                          // 0000001D6578: D637000C 0462270C
	v_div_scale_f32 v19, null, v20, v20, v4                    // 0000001D6580: D6FC7C13 04122914
	v_add_f32_e32 v24, 1.0, v26                                // 0000001D6588: 063034F2
	v_div_scale_f32 v26, vcc_lo, v2, v17, v2                   // 0000001D658C: D6FC6A1A 040A2302
	v_fmac_f32_e32 v29, v27, v29                               // 0000001D6594: 563A3B1B
	v_div_scale_f32 v10, s0, v3, v21, v3                       // 0000001D6598: D6FC000A 040E2B03
	v_rcp_f32_e32 v31, v19                                     // 0000001D65A0: 7E3E5513
	v_div_scale_f32 v32, null, v24, v24, v5                    // 0000001D65A4: D6FC7C20 04163118
	v_mul_f32_e32 v8, v26, v30                                 // 0000001D65AC: 10103D1A
	v_div_fixup_f32 v1, v12, v18, v1                           // 0000001D65B0: D6270001 0406250C
	.long 0x7f2439b6                                           // 0000001D65B8: 7F2439B6
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D65BC: BF870194
	v_rcp_f32_e32 v9, v32                                      // 0000001D65C0: 7E125520
	v_fma_f32 v12, -v25, v8, v26                               // 0000001D65C4: D613000C 246A1119
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001D65CC: BF870313
	.long 0x7e6c3981                                           // 0000001D65D0: 7E6C3981
	v_fma_f32 v11, -v19, v31, 1.0                              // 0000001D65D4: D613000B 23CA3F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D65DC: BF870121
	v_dual_fmac_f32 v8, v12, v30 :: v_dual_fmac_f32 v31, v11, v31// 0000001D65E0: C8003D0C 081E3F0B
	v_div_scale_f32 v11, s1, v4, v20, v4                       // 0000001D65E8: D6FC010B 04122904
	v_fma_f32 v25, -v25, v8, v26                               // 0000001D65F0: D6130019 246A1119
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001D65F8: BF870002
	v_mul_f32_e32 v27, v11, v31                                // 0000001D65FC: 10363F0B
	v_div_fixup_f32 v0, v13, v16, v0                           // 0000001D6600: D6270000 0402210D
	v_mul_f32_e32 v13, v10, v29                                // 0000001D6608: 101A3B0A
	v_fma_f32 v16, -v32, v9, 1.0                               // 0000001D660C: D6130010 23CA1320
	v_div_fmas_f32 v8, v25, v30, v8                            // 0000001D6614: D6370008 04223D19
	s_mov_b32 vcc_lo, s0                                       // 0000001D661C: BEEA0000
	.long 0x7e243980                                           // 0000001D6620: 7E243980
	v_fma_f32 v12, -v28, v13, v10                              // 0000001D6624: D613000C 242A1B1C
	v_fmac_f32_e32 v9, v16, v9                                 // 0000001D662C: 56121310
	v_div_scale_f32 v16, s2, v5, v24, v5                       // 0000001D6630: D6FC0210 04163105
	v_div_fixup_f32 v2, v8, v17, v2                            // 0000001D6638: D6270002 040A2308
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D6640: BF870224
	v_fmac_f32_e32 v13, v12, v29                               // 0000001D6644: 561A3B0C
	v_fma_f32 v12, -v19, v27, v11                              // 0000001D6648: D613000C 242E3713
	v_mul_f32_e32 v26, v16, v9                                 // 0000001D6650: 10341310
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D6654: BF870193
	v_fma_f32 v10, -v28, v13, v10                              // 0000001D6658: D613000A 242A1B1C
	v_fmac_f32_e32 v27, v12, v31                               // 0000001D6660: 56363F0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D6664: BF870223
	v_fma_f32 v25, -v32, v26, v16                              // 0000001D6668: D6130019 24423520
	v_and_b32_e32 v12, 1, v54                                  // 0000001D6670: 36186C81
	v_div_fmas_f32 v10, v10, v29, v13                          // 0000001D6674: D637000A 04363B0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D667C: BF870214
	v_fma_f32 v8, -v19, v27, v11                               // 0000001D6680: D6130008 242E3713
	v_fmac_f32_e32 v26, v25, v9                                // 0000001D6688: 56341319
	s_mov_b32 vcc_lo, s1                                       // 0000001D668C: BEEA0001
	.long 0x7f1639b6                                           // 0000001D6690: 7F1639B6
	v_div_fixup_f32 v3, v10, v21, v3                           // 0000001D6694: D6270003 040E2B0A
	v_div_fmas_f32 v8, v8, v31, v27                            // 0000001D669C: D6370008 046E3F08
	v_fma_f32 v10, -v32, v26, v16                              // 0000001D66A4: D613000A 24423520
	s_mov_b32 vcc_lo, s2                                       // 0000001D66AC: BEEA0002
	v_add3_u32 v1, v1, v12, 0x7fff                             // 0000001D66B0: D6550001 03FE1901 00007FFF
	.long 0x7e6c3983                                           // 0000001D66BC: 7E6C3983
	v_div_fixup_f32 v4, v8, v20, v4                            // 0000001D66C0: D6270004 04122908
	v_div_fmas_f32 v9, v10, v9, v26                            // 0000001D66C8: D6370009 046A130A
	v_and_b32_e32 v10, 1, v18                                  // 0000001D66D0: 36142481
	.long 0x7e103982                                           // 0000001D66D4: 7E103982
	.long 0x7f1039b6                                           // 0000001D66D8: 7F1039B6
	.long 0x7e163984                                           // 0000001D66DC: 7E163984
	v_div_fixup_f32 v5, v9, v24, v5                            // 0000001D66E0: D6270005 04163109
	v_and_b32_e32 v9, 1, v54                                   // 0000001D66E8: 36126C81
	v_add3_u32 v0, v0, v10, 0x7fff                             // 0000001D66EC: D6550000 03FE1500 00007FFF
	v_and_b32_e32 v8, 1, v8                                    // 0000001D66F8: 36101081
	v_and_b32_e32 v10, 1, v11                                  // 0000001D66FC: 36141681
	.long 0x7e6c3985                                           // 0000001D6700: 7E6C3985
	global_store_d16_hi_b16 v[34:35], v0, off offset:96        // 0000001D6704: DC960060 007C0022
	v_add3_u32 v0, v2, v8, 0x7fff                              // 0000001D670C: D6550000 03FE1102 00007FFF
	v_add3_u32 v2, v3, v9, 0x7fff                              // 0000001D6718: D6550002 03FE1303 00007FFF
	v_and_b32_e32 v11, 1, v54                                  // 0000001D6724: 36166C81
	v_add3_u32 v3, v4, v10, 0x7fff                             // 0000001D6728: D6550003 03FE1504 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001D6734: BF870002
	v_add3_u32 v4, v5, v11, 0x7fff                             // 0000001D6738: D6550004 03FE1705 00007FFF
	s_clause 0x4                                               // 0000001D6744: BF850004
	global_store_d16_hi_b16 v[38:39], v1, off offset:96        // 0000001D6748: DC960060 007C0126
	global_store_d16_hi_b16 v[6:7], v0, off offset:96          // 0000001D6750: DC960060 007C0006
	global_store_d16_hi_b16 v[14:15], v2, off offset:96        // 0000001D6758: DC960060 007C020E
	global_store_d16_hi_b16 v[22:23], v3, off offset:96        // 0000001D6760: DC960060 007C0316
	global_store_d16_hi_b16 v[36:37], v4, off offset:96        // 0000001D6768: DC960060 007C0424
	s_nop 0                                                    // 0000001D6770: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001D6774: BFB60003
	s_endpgm                                                   // 0000001D6778: BFB00000
		...

