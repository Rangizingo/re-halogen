000000000006f700 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 00000006F700: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 00000006F704: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000006F70C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 00000006F714: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 00000006F718: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000006F71C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 00000006F720: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000006F728: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000006F72C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 00000006F730: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 00000006F734: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000006F73C: 84928214
	s_add_u32 s25, s16, s18                                    // 00000006F740: 80191210
	s_addc_u32 s28, s17, s19                                   // 00000006F744: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 00000006F748: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006F74C: BF870009
	s_add_u32 s25, s25, s20                                    // 00000006F750: 80191419
	s_addc_u32 s30, s28, s21                                   // 00000006F754: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 00000006F758: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000006F75C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 00000006F764: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000006F76C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 00000006F770: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 00000006F774: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000006F778: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000006F77C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 00000006F780: 821E191E
	.long 0xd7001f02                                           // 00000006F784: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 00000006F788: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000006F78C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 00000006F794: BE9E0080
	s_nop 0                                                    // 00000006F798: BF800000
	s_nop 0                                                    // 00000006F79C: BF800000
	s_nop 0                                                    // 00000006F7A0: BF800000
	s_nop 0                                                    // 00000006F7A4: BF800000
	s_nop 0                                                    // 00000006F7A8: BF800000
	s_nop 0                                                    // 00000006F7AC: BF800000
	s_nop 0                                                    // 00000006F7B0: BF800000
	s_nop 0                                                    // 00000006F7B4: BF800000
	s_nop 0                                                    // 00000006F7B8: BF800000
	s_nop 0                                                    // 00000006F7BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 00000006F7C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 00000006F7C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006F7CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 00000006F7D0: 300C1089
	.long 0xd7006a06                                           // 00000006F7D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000006F7D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006F7DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 00000006F7E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000006F7E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 00000006F7F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 00000006F7F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 00000006F7FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 00000006F808: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000006F80C: BF8903F7
	ds_store_b32 v6, v9                                        // 00000006F810: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 00000006F818: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000006F81C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 00000006F820: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 00000006F824: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 00000006F82C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 00000006F834: 32040084
	s_mov_b32 s0, 0                                            // 00000006F838: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000006F83C: BF89FC07
	s_barrier                                                  // 00000006F840: BFBD0000
	buffer_gl0_inv                                             // 00000006F844: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000006F84C: BF02801E
	s_cbranch_scc1 12                                          // 00000006F850: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 00000006F854: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000006F85C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 00000006F864: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 00000006F868: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 00000006F870: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000006F874: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000006F878: 916A007E
	s_cbranch_vccz 2                                           // 00000006F87C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2216                                              // 00000006F880: BFA008A8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2424>
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000006F884: 304E0A82
	s_add_i32 s0, s30, 63                                      // 00000006F888: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000006F88C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 00000006F894: 85218600
	s_add_u32 s34, s10, s24                                    // 00000006F898: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000006F89C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 00000006F8A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 00000006F8A4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 00000006F8AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 00000006F8B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000006F8B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 00000006F8B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 00000006F8BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 00000006F8C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 00000006F8C4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 00000006F8C8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 00000006F8D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 00000006F8D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 00000006F8DC: B00A0204
	.long 0xd7000b2c                                           // 00000006F8E0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 00000006F8E4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000006F8E8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 00000006F8EC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 00000006F8F4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 00000006F900: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 00000006F904: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 00000006F910: 3816500A
	.long 0xd7000a05                                           // 00000006F914: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 00000006F918: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006F91C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 00000006F920: D5207C06 00290001
	.long 0xd7000107                                           // 00000006F928: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 00000006F92C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006F930: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 00000006F934: D5207C08 0006180D
	.long 0xd7000109                                           // 00000006F93C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 00000006F940: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 00000006F944: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 00000006F94C: 84848E02
	.long 0xd700010b                                           // 00000006F950: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 00000006F954: 02021606
	s_add_u32 s4, s14, s4                                      // 00000006F958: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 00000006F95C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 00000006F964: 8205050F
	.long 0xd700010d                                           // 00000006F968: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 00000006F96C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006F970: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 00000006F974: D5207C0E 00050005
	.long 0xd700010f                                           // 00000006F97C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 00000006F980: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 00000006F988: D5207C10 00061880
	.long 0xd7000111                                           // 00000006F990: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 00000006F994: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006F99C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 00000006F9A0: D5207C12 00061880
	.long 0xd7000113                                           // 00000006F9A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 00000006F9AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 00000006F9B4: D5207C14 00061880
	.long 0xd7000115                                           // 00000006F9BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 00000006F9C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006F9C8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 00000006F9CC: D5207C16 00061880
	.long 0xd7000117                                           // 00000006F9D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 00000006F9D8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 00000006F9E0: D5207C18 00061880
	.long 0xd7000119                                           // 00000006F9E8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 00000006F9EC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006F9F4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 00000006F9F8: D5207C1A 00061880
	.long 0xd700011b                                           // 00000006FA00: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 00000006FA04: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 00000006FA0C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 00000006FA14: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000006FA18: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 00000006FA20: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 00000006FA24: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 00000006FA2C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 00000006FA34: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 00000006FA3C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 00000006FA44: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 00000006FA4C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 00000006FA54: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 00000006FA5C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 00000006FA64: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 00000006FA6C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 00000006FA74: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 00000006FA7C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 00000006FA84: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 00000006FA8C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 00000006FA94: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 00000006FA9C: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 00000006FAA0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 00000006FAA4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000006FAAC: BF870499
	s_add_i32 s6, s31, s1                                      // 00000006FAB0: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 00000006FAB4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006FAB8: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 00000006FABC: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 00000006FAC0: 84078605
	s_add_u32 s10, s8, s10                                     // 00000006FAC4: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 00000006FAC8: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 00000006FACC: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 00000006FAD4: BE84206A
	s_cbranch_execz 77                                         // 00000006FAD8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510>
	v_or_b32_e32 v29, s7, v0                                   // 00000006FADC: 383A0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FAE0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 00000006FAE4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 00000006FAEC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FAF0: BF870091
	.long 0xd73c001d                                           // 00000006FAF4: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 00000006FAF8: 02023A82
	.long 0xd700011d                                           // 00000006FAFC: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 00000006FB00: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000006FB04: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 00000006FB08: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 00000006FB10: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000006FB18: BF890007
	v_sub_f32_e32 v30, s6, v29                                 // 00000006FB1C: 083C3A06
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 00000006FB20: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000006FB2C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 00000006FB30: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 00000006FB3C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 00000006FB40: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 00000006FB4C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006FB50: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 00000006FB54: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 00000006FB60: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006FB64: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 00000006FB68: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 00000006FB70: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 00000006FB74: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 00000006FB7C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 00000006FB84: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 00000006FB88: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006FB8C: BF870193
	v_exp_f32_e32 v32, v32                                     // 00000006FB90: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 00000006FB94: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000006FB98: BF870296
	.long 0xd71c0020                                           // 00000006FB9C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 00000006FBA0: 02024520
	.long 0xd71c001f                                           // 00000006FBA4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 00000006FBA8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006FBAC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 00000006FBB0: D501001F 00063E80
	.long 0xd41b0001                                           // 00000006FBB8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 00000006FBBC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 00000006FBC4: D5010020 00064080
	.long 0xd41e0001                                           // 00000006FBCC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 00000006FBD0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006FBD8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 00000006FBDC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 00000006FBE8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 00000006FBEC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 00000006FBF4: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 00000006FC00: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 00000006FC08: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006FC10: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 00000006FC14: CA100108 1E1C0107
	s_mov_b32 s10, 0                                           // 00000006FC1C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000006FC20: BF89FC07
	s_barrier                                                  // 00000006FC24: BFBD0000
	buffer_gl0_inv                                             // 00000006FC28: E0AC0000 00000000
	s_branch 15                                                // 00000006FC30: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006FC34: 8C7E047E
	.long 0xd700011d                                           // 00000006FC38: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 00000006FC3C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006FC44: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000006FC48: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 00000006FC50: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000006FC54: BF08B70A
	s_mov_b32 s10, s1                                          // 00000006FC58: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 00000006FC5C: BF89FC07
	s_barrier                                                  // 00000006FC60: BFBD0000
	buffer_gl0_inv                                             // 00000006FC64: E0AC0000 00000000
	s_cbranch_scc1 706                                         // 00000006FC6C: BFA202C2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 00000006FC70: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 00000006FC78: CA100128 21220126
	s_mov_b32 s11, 0                                           // 00000006FC80: BE8B0080
	s_nop 0                                                    // 00000006FC84: BF800000
	s_nop 0                                                    // 00000006FC88: BF800000
	s_nop 0                                                    // 00000006FC8C: BF800000
	s_nop 0                                                    // 00000006FC90: BF800000
	s_nop 0                                                    // 00000006FC94: BF800000
	s_nop 0                                                    // 00000006FC98: BF800000
	s_nop 0                                                    // 00000006FC9C: BF800000
	s_nop 0                                                    // 00000006FCA0: BF800000
	s_nop 0                                                    // 00000006FCA4: BF800000
	s_nop 0                                                    // 00000006FCA8: BF800000
	s_nop 0                                                    // 00000006FCAC: BF800000
	s_nop 0                                                    // 00000006FCB0: BF800000
	s_nop 0                                                    // 00000006FCB4: BF800000
	s_nop 0                                                    // 00000006FCB8: BF800000
	s_nop 0                                                    // 00000006FCBC: BF800000
	global_load_b32 v35, v[31:32], off                         // 00000006FCC0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 00000006FCC8: 4A4444FF 00000080
	.long 0xd700011f                                           // 00000006FCD0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 00000006FCD4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006FCDC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 00000006FCE0: D5207C20 00064080
	.long 0xd4490004                                           // 00000006FCE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 00000006FCEC: 020244FF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000006FCF4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000006FCF8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 00000006FCFC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 00000006FD04: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000006FD0C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000006FD10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000006FD14: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000006FD18: BF89FC07
	s_barrier                                                  // 00000006FD1C: BFBD0000
	buffer_gl0_inv                                             // 00000006FD20: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000006FD28: BE842000
	s_cbranch_execz 65473                                      // 00000006FD2C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 00000006FD30: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 00000006FD38: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 00000006FD40: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 00000006FD48: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 00000006FD50: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 00000006FD58: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 00000006FD60: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 00000006FD68: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v46 offset0:14 offset1:15      // 00000006FD70: D8DC0F0E 4800002E
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 00000006FD78: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 00000006FD80: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 00000006FD88: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 00000006FD90: D8DCFFEE 50000001
	v_or3_b32 v70, s10, s7, v2                                 // 00000006FD98: D6580046 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FDA0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 00000006FDA4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 00000006FDAC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 00000006FDB0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FDB4: BF870091
	.long 0xd7000146                                           // 00000006FDB8: D7000146
	v_cndmask_b32_e32 v1, v44, v70, vcc_lo                     // 00000006FDBC: 02028D2C
	v_add_co_ci_u32_e64 v71, null, v45, v71, s1                // 00000006FDC0: D5207C47 00068F2D
	global_load_b32 v70, v[70:71], off                         // 00000006FDC8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 00000006FDD0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 00000006FDD4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006FDDC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 00000006FDE0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 00000006FDE8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 00000006FDEC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 00000006FDF4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:10 offset1:11      // 00000006FDFC: D8DC0B0A 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:12 offset1:13      // 00000006FE04: D8DC0D0C 4600002E
	v_fma_f32 v33, -v34, v65, v33                              // 00000006FE0C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 00000006FE14: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FE18: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 00000006FE1C: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 00000006FE24: D6130021 24868724
	s_waitcnt lgkmcnt(8)                                       // 00000006FE2C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FE30: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 00000006FE34: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 00000006FE3C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 00000006FE44: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FE48: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 00000006FE4C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 00000006FE54: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 00000006FE5C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006FE60: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000006FE64: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 00000006FE6C: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 00000006FE74: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 00000006FE7C: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 00000006FE84: D8DC1716 3C00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:16 offset1:33      // 00000006FE8C: D8DC2110 40000030
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 00000006FE94: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:84 offset1:101     // 00000006FE9C: D8DC6554 44000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 00000006FEA4: D8DC8776 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 00000006FEAC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 00000006FEB4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FEB8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 00000006FEBC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 00000006FEC4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FECC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 00000006FED0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 00000006FED8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 00000006FEE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FEE4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 00000006FEE8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 00000006FEF0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 00000006FEF8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006FEFC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 00000006FF00: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 00000006FF08: D8DC1918 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 00000006FF10: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 00000006FF18: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 00000006FF20: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:152 offset1:169    // 00000006FF28: D8DCA998 48000030
	ds_load_2addr_b32 v[76:77], v48 offset0:186 offset1:203    // 00000006FF30: D8DCCBBA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:220 offset1:237    // 00000006FF38: D8DCEDDC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:126 offset1:143    // 00000006FF40: D8DC8F7E 50000031
	v_fma_f32 v33, -v34, v67, v33                              // 00000006FF48: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 00000006FF50: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FF54: BF870091
	v_fma_f32 v33, -v35, v68, v33                              // 00000006FF58: D6130021 24868923
	v_fma_f32 v33, -v36, v69, v33                              // 00000006FF60: D6130021 24868B24
	s_waitcnt lgkmcnt(8)                                       // 00000006FF68: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FF6C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 00000006FF70: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 00000006FF78: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 00000006FF80: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FF84: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 00000006FF88: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 00000006FF90: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 00000006FF98: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006FF9C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 00000006FFA0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 00000006FFA8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 00000006FFB0: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 00000006FFB8: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 00000006FFC0: D8DC2726 3C00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 00000006FFC8: D8DC3120 42000032
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 00000006FFD0: D8DC5342 44000032
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 00000006FFD8: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 00000006FFE0: D8DC9786 4A000032
	v_fma_f32 v62, -v63, v77, v62                              // 00000006FFE8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 00000006FFF0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006FFF4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 00000006FFF8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000070000: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000070008: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007000C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 000000070010: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 000000070018: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 000000070020: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070024: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 000000070028: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 000000070030: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 000000070038: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007003C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 000000070040: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 000000070048: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 000000070050: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:44 offset1:45      // 000000070058: D8DC2D2C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:46 offset1:47      // 000000070060: D8DC2F2E 4200002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 000000070068: D8DCB9A8 46000032
	ds_load_2addr_b32 v[76:77], v50 offset0:202 offset1:219    // 000000070070: D8DCDBCA 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:236 offset1:253    // 000000070078: D8DCFDEC 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:14 offset1:31      // 000000070080: D8DC1F0E 50000033
	v_fma_f32 v33, -v34, v69, v33                              // 000000070088: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 000000070090: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070094: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000070098: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000700A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000700A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000700AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000700B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000700B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000700C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000700C4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 0000000700C8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 0000000700D0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 0000000700D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000700DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000700E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 0000000700E8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 0000000700F0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 0000000700F8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 000000070100: D8DC3736 3C00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:48 offset1:65      // 000000070108: D8DC4130 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:82 offset1:99      // 000000070110: D8DC6352 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 000000070118: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 000000070120: D8DCA796 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 000000070128: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000070130: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070134: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000070138: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000070140: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000070148: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007014C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000070150: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000070158: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000070160: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070164: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000070168: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000070170: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000070178: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007017C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000070180: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 000000070188: D8DC3938 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:58 offset1:59      // 000000070190: D8DC3B3A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:60 offset1:61      // 000000070198: D8DC3D3C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:62 offset1:63      // 0000000701A0: D8DC3F3E 4200002E
	ds_load_2addr_b32 v[68:69], v51 offset0:184 offset1:201    // 0000000701A8: D8DCC9B8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:218 offset1:235    // 0000000701B0: D8DCEBDA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:124 offset1:141    // 0000000701B8: D8DC8D7C 4E000034
	ds_load_2addr_b32 v[80:81], v53 offset0:30 offset1:47      // 0000000701C0: D8DC2F1E 50000035
	v_fma_f32 v33, -v34, v71, v33                              // 0000000701C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000701D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000701D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000701D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000701E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000701E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000701EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000701F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000701F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000070200: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070204: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000070208: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000070210: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000070218: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007021C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000070220: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 000000070228: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 000000070230: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 000000070238: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 000000070240: D8DC4746 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:64 offset1:81      // 000000070248: D8DC5140 44000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 000000070250: D8DC7362 46000035
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 000000070258: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 000000070260: D8DCB7A6 4A000035
	v_fma_f32 v62, -v63, v77, v62                              // 000000070268: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000070270: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070274: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000070278: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000070280: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000070288: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007028C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000070290: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000070298: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000702A0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000702A4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000702A8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000702B0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000702B8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000702BC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000702C0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 0000000702C8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 0000000702D0: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 0000000702D8: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:78 offset1:79      // 0000000702E0: D8DC4F4E 4200002E
	ds_load_2addr_b32 v[68:69], v53 offset0:200 offset1:217    // 0000000702E8: D8DCD9C8 44000035
	ds_load_2addr_b32 v[76:77], v53 offset0:234 offset1:251    // 0000000702F0: D8DCFBEA 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:12 offset1:29      // 0000000702F8: D8DC1D0C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:46 offset1:63      // 000000070300: D8DC3F2E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 000000070308: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000070310: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070314: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000070318: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 000000070320: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 000000070328: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007032C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000070330: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000070338: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000070340: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070344: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000070348: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000070350: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000070358: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007035C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000070360: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 000000070368: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 000000070370: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 000000070378: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 000000070380: D8DC5756 3C00002E
	ds_load_2addr_b32 v[68:69], v54 offset0:80 offset1:97      // 000000070388: D8DC6150 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 000000070390: D8DC8372 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 000000070398: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000703A0: D8DCC7B6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 0000000703A8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000703B0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000703B4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000703B8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000703C0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000703C8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000703CC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000703D0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000703D8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000703E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000703E4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000703E8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000703F0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000703F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000703FC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000070400: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 000000070408: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 000000070410: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:92 offset1:93      // 000000070418: D8DC5D5C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:94 offset1:95      // 000000070420: D8DC5F5E 4200002E
	ds_load_2addr_b32 v[68:69], v54 offset0:216 offset1:233    // 000000070428: D8DCE9D8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:122 offset1:139    // 000000070430: D8DC8B7A 4C000037
	ds_load_2addr_b32 v[78:79], v56 offset0:28 offset1:45      // 000000070438: D8DC2D1C 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:62 offset1:79      // 000000070440: D8DC4F3E 50000038
	v_fma_f32 v33, -v34, v71, v33                              // 000000070448: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000070450: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070454: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000070458: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 000000070460: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 000000070468: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007046C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000070470: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000070478: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000070480: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070484: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000070488: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000070490: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000070498: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007049C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000704A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 0000000704A8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 0000000704B0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 0000000704B8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 0000000704C0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:96 offset1:113     // 0000000704C8: D8DC7160 44000038
	ds_load_2addr_b32 v[70:71], v56 offset0:130 offset1:147    // 0000000704D0: D8DC9382 46000038
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000704D8: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000704E0: D8DCD7C6 4A000038
	v_fma_f32 v62, -v63, v77, v62                              // 0000000704E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000704F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000704F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000704F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000070500: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000070508: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007050C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000070510: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000070518: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000070520: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070524: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000070528: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000070530: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000070538: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007053C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000070540: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 000000070548: D8DC6968 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:106 offset1:107    // 000000070550: D8DC6B6A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:108 offset1:109    // 000000070558: D8DC6D6C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:110 offset1:111    // 000000070560: D8DC6F6E 4200002E
	ds_load_2addr_b32 v[68:69], v56 offset0:232 offset1:249    // 000000070568: D8DCF9E8 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:10 offset1:27      // 000000070570: D8DC1B0A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:44 offset1:61      // 000000070578: D8DC3D2C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:78 offset1:95      // 000000070580: D8DC5F4E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 000000070588: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000070590: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070594: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000070598: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000705A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000705A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000705AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000705B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000705B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000705C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000705C4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000705C8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000705D0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000705D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000705DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000705E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 0000000705E8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 0000000705F0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 0000000705F8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 000000070600: D8DC7776 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 000000070608: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 000000070610: D8DCA392 46000039
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 000000070618: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 000000070620: D8DCE7D6 4A000039
	v_fma_f32 v62, -v63, v77, v62                              // 000000070628: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000070630: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070634: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000070638: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000070640: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000070648: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007064C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000070650: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000070658: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000070660: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070664: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000070668: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000070670: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000070678: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007067C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000070680: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 000000070688: D8DC7978 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 000000070690: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 000000070698: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:126 offset1:127    // 0000000706A0: D8DC7F7E 4200002E
	ds_load_2addr_b32 v[68:69], v58 offset0:120 offset1:137    // 0000000706A8: D8DC8978 4400003A
	ds_load_2addr_b32 v[76:77], v59 offset0:26 offset1:43      // 0000000706B0: D8DC2B1A 4C00003B
	ds_load_2addr_b32 v[78:79], v59 offset0:60 offset1:77      // 0000000706B8: D8DC4D3C 4E00003B
	ds_load_2addr_b32 v[80:81], v59 offset0:94 offset1:111     // 0000000706C0: D8DC6F5E 5000003B
	v_fma_f32 v33, -v34, v71, v33                              // 0000000706C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000706D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000706D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000706D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000706E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000706E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000706EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000706F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000706F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000070700: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070704: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000070708: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000070710: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000070718: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007071C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 000000070720: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 000000070728: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 000000070730: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070734: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 000000070738: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 000000070740: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 000000070748: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007074C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 000000070750: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s10, v[4:5]            // 000000070758: D6FE7C1F 041014FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 000000070764: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 00000007076C: D8340000 0000201F
	s_branch 64815                                             // 000000070774: BFA0FD2F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_mov_b32_e32 v30, v14                                     // 000000070778: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 00000007077C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 000000070784: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 000000070788: 7E46032B
	s_mov_b32 s10, 0                                           // 00000007078C: BE8A0080
	s_branch 21                                                // 000000070790: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000070794: 8C7E0B7E
	.long 0xd700011f                                           // 000000070798: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 00000007079C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000707A4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000707A8: D5207C20 00064080
	.long 0xd700011d                                           // 0000000707B0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000707B4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 0000000707BC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000707C0: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 0000000707C8: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 0000000707CC: BF08B70A
	s_mov_b32 s10, s1                                          // 0000000707D0: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000707D4: BC7C0000
	s_barrier                                                  // 0000000707D8: BFBD0000
	buffer_gl0_inv                                             // 0000000707DC: E0AC0000 00000000
	s_cbranch_scc1 214                                         // 0000000707E4: BFA200D6 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1440>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000707E8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000707EC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 0000000707F4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 0000000707F8: 7E780326
	s_mov_b32 s11, 0                                           // 0000000707FC: BE8B0080
	global_load_b32 v61, v[33:34], off                         // 000000070800: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 000000070808: 4A7878FF 00000080
	.long 0xd7000121                                           // 000000070810: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 000000070814: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007081C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 000000070820: D5207C22 00064480
	.long 0xd4490004                                           // 000000070828: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 00000007082C: 020278FF 0000037F
	s_or_b32 s11, s4, s11                                      // 000000070834: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 000000070838: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 00000007083C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 000000070844: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000007084C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000070850: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000070854: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000070858: BF89FC07
	s_barrier                                                  // 00000007085C: BFBD0000
	buffer_gl0_inv                                             // 000000070860: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 000000070868: BE8B2000
	s_cbranch_execz 65481                                      // 00000007086C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s10, v2                                  // 000000070870: 3842040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070874: BF870091
	v_or_b32_e32 v36, s7, v33                                  // 000000070878: 38484207
	.long 0xd4440001                                           // 00000007087C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 000000070880: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 000000070884: 8B7E017E
	s_cbranch_execz 65474                                      // 000000070888: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_mov_b32_e32 v60, 0                                       // 00000007088C: 7E780280
	s_mov_b32 s1, 0                                            // 000000070890: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000070894: BF870009
	v_mad_u64_u32 v[61:62], null, 0x44, s1, v[1:2]             // 000000070898: D6FE7C3D 040402FF 00000044
	v_lshl_add_u32 v34, s1, 2, v46                             // 0000000708A4: D6460022 04B90401
	s_add_i32 s4, s1, 16                                       // 0000000708AC: 81049001
	s_cmpk_lt_u32 s1, 0x70                                     // 0000000708B0: B6810070
	s_mov_b32 s1, s4                                           // 0000000708B4: BE810004
	ds_load_2addr_b32 v[64:65], v34 offset0:2 offset1:3        // 0000000708B8: D8DC0302 40000022
	ds_load_2addr_b32 v[66:67], v34 offset0:4 offset1:5        // 0000000708C0: D8DC0504 42000022
	ds_load_2addr_b32 v[62:63], v61 offset0:68 offset1:85      // 0000000708C8: D8DC5544 3E00003D
	ds_load_2addr_b32 v[68:69], v34 offset0:6 offset1:7        // 0000000708D0: D8DC0706 44000022
	ds_load_2addr_b32 v[72:73], v34 offset0:8 offset1:9        // 0000000708D8: D8DC0908 48000022
	ds_load_2addr_b32 v[74:75], v34 offset0:10 offset1:11      // 0000000708E0: D8DC0B0A 4A000022
	ds_load_2addr_b32 v[76:77], v34 offset0:12 offset1:13      // 0000000708E8: D8DC0D0C 4C000022
	ds_load_2addr_b32 v[78:79], v34 offset0:14 offset1:15      // 0000000708F0: D8DC0F0E 4E000022
	s_waitcnt lgkmcnt(5)                                       // 0000000708F8: BF89FC57
	v_cvt_f16_f32_e32 v88, v62                                 // 0000000708FC: 7EB0153E
	v_cvt_f16_f32_e32 v89, v63                                 // 000000070900: 7EB2153F
	ds_load_2addr_b32 v[62:63], v61 offset0:34 offset1:51      // 000000070904: D8DC3322 3E00003D
	s_waitcnt lgkmcnt(0)                                       // 00000007090C: BF89FC07
	v_cvt_f16_f32_e32 v90, v62                                 // 000000070910: 7EB4153E
	v_cvt_f16_f32_e32 v91, v63                                 // 000000070914: 7EB6153F
	ds_load_2addr_b32 v[62:63], v61 offset1:17                 // 000000070918: D8DC1100 3E00003D
	s_waitcnt lgkmcnt(0)                                       // 000000070920: BF89FC07
	v_cvt_f16_f32_e32 v92, v62                                 // 000000070924: 7EB8153E
	v_cvt_f16_f32_e32 v93, v63                                 // 000000070928: 7EBA153F
	ds_load_2addr_b32 v[62:63], v34 offset1:1                  // 00000007092C: D8DC0100 3E000022
	s_waitcnt lgkmcnt(0)                                       // 000000070934: BF89FC07
	v_cvt_f16_f32_e32 v34, v62                                 // 000000070938: 7E44153E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007093C: BF870001
	v_fma_mix_f32 v34, v34, v92, v60 op_sel_hi:[1,1,0]         // 000000070940: CC200022 1CF2B922
	v_cvt_f16_f32_e32 v60, v64                                 // 000000070948: 7E781540
	ds_load_2addr_b32 v[70:71], v61 offset0:102 offset1:119    // 00000007094C: D8DC7766 4600003D
	ds_load_2addr_b32 v[80:81], v61 offset0:136 offset1:153    // 000000070954: D8DC9988 5000003D
	ds_load_2addr_b32 v[82:83], v61 offset0:170 offset1:187    // 00000007095C: D8DCBBAA 5200003D
	ds_load_2addr_b32 v[84:85], v61 offset0:204 offset1:221    // 000000070964: D8DCDDCC 5400003D
	ds_load_2addr_b32 v[86:87], v61 offset0:238 offset1:255    // 00000007096C: D8DCFFEE 5600003D
	v_cvt_f16_f32_e32 v61, v63                                 // 000000070974: 7E7A153F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070978: BF870121
	v_fma_mix_f32 v34, v61, v93, v34 op_sel_hi:[1,1,0]         // 00000007097C: CC200022 1C8ABB3D
	v_cvt_f16_f32_e32 v61, v65                                 // 000000070984: 7E7A1541
	v_fma_mix_f32 v34, v60, v90, v34 op_sel_hi:[1,1,0]         // 000000070988: CC200022 1C8AB53C
	v_cvt_f16_f32_e32 v60, v66                                 // 000000070990: 7E781542
	s_delay_alu instid0(VALU_DEP_2)                            // 000000070994: BF870002
	v_fma_mix_f32 v34, v61, v91, v34 op_sel_hi:[1,1,0]         // 000000070998: CC200022 1C8AB73D
	v_cvt_f16_f32_e32 v61, v67                                 // 0000000709A0: 7E7A1543
	s_waitcnt lgkmcnt(4)                                       // 0000000709A4: BF89FC47
	v_cvt_f16_f32_e32 v62, v70                                 // 0000000709A8: 7E7C1546
	v_cvt_f16_f32_e32 v63, v71                                 // 0000000709AC: 7E7E1547
	v_fma_mix_f32 v34, v60, v88, v34 op_sel_hi:[1,1,0]         // 0000000709B0: CC200022 1C8AB13C
	v_cvt_f16_f32_e32 v60, v68                                 // 0000000709B8: 7E781544
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000709BC: BF870122
	v_fma_mix_f32 v34, v61, v89, v34 op_sel_hi:[1,1,0]         // 0000000709C0: CC200022 1C8AB33D
	v_cvt_f16_f32_e32 v61, v69                                 // 0000000709C8: 7E7A1545
	v_fma_mix_f32 v34, v60, v62, v34 op_sel_hi:[1,1,0]         // 0000000709CC: CC200022 1C8A7D3C
	v_cvt_f16_f32_e32 v60, v72                                 // 0000000709D4: 7E781548
	s_waitcnt lgkmcnt(3)                                       // 0000000709D8: BF89FC37
	v_cvt_f16_f32_e32 v62, v80                                 // 0000000709DC: 7E7C1550
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000709E0: BF8701B3
	v_fma_mix_f32 v34, v61, v63, v34 op_sel_hi:[1,1,0]         // 0000000709E4: CC200022 1C8A7F3D
	v_cvt_f16_f32_e32 v61, v73                                 // 0000000709EC: 7E7A1549
	v_cvt_f16_f32_e32 v63, v81                                 // 0000000709F0: 7E7E1551
	v_fma_mix_f32 v34, v60, v62, v34 op_sel_hi:[1,1,0]         // 0000000709F4: CC200022 1C8A7D3C
	v_cvt_f16_f32_e32 v60, v74                                 // 0000000709FC: 7E78154A
	s_waitcnt lgkmcnt(2)                                       // 000000070A00: BF89FC27
	v_cvt_f16_f32_e32 v62, v82                                 // 000000070A04: 7E7C1552
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000070A08: BF8701B3
	v_fma_mix_f32 v34, v61, v63, v34 op_sel_hi:[1,1,0]         // 000000070A0C: CC200022 1C8A7F3D
	v_cvt_f16_f32_e32 v61, v75                                 // 000000070A14: 7E7A154B
	v_cvt_f16_f32_e32 v63, v83                                 // 000000070A18: 7E7E1553
	v_fma_mix_f32 v34, v60, v62, v34 op_sel_hi:[1,1,0]         // 000000070A1C: CC200022 1C8A7D3C
	v_cvt_f16_f32_e32 v60, v76                                 // 000000070A24: 7E78154C
	s_waitcnt lgkmcnt(1)                                       // 000000070A28: BF89FC17
	v_cvt_f16_f32_e32 v62, v84                                 // 000000070A2C: 7E7C1554
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000070A30: BF8701B3
	v_fma_mix_f32 v34, v61, v63, v34 op_sel_hi:[1,1,0]         // 000000070A34: CC200022 1C8A7F3D
	v_cvt_f16_f32_e32 v61, v77                                 // 000000070A3C: 7E7A154D
	v_cvt_f16_f32_e32 v63, v85                                 // 000000070A40: 7E7E1555
	v_fma_mix_f32 v34, v60, v62, v34 op_sel_hi:[1,1,0]         // 000000070A44: CC200022 1C8A7D3C
	v_cvt_f16_f32_e32 v60, v78                                 // 000000070A4C: 7E78154E
	s_waitcnt lgkmcnt(0)                                       // 000000070A50: BF89FC07
	v_cvt_f16_f32_e32 v62, v86                                 // 000000070A54: 7E7C1556
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000070A58: BF8701B3
	v_fma_mix_f32 v34, v61, v63, v34 op_sel_hi:[1,1,0]         // 000000070A5C: CC200022 1C8A7F3D
	v_cvt_f16_f32_e32 v61, v79                                 // 000000070A64: 7E7A154F
	v_cvt_f16_f32_e32 v63, v87                                 // 000000070A68: 7E7E1557
	v_fma_mix_f32 v34, v60, v62, v34 op_sel_hi:[1,1,0]         // 000000070A6C: CC200022 1C8A7D3C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000070A74: BF870001
	v_fma_mix_f32 v60, v61, v63, v34 op_sel_hi:[1,1,0]         // 000000070A78: CC20003C 1C8A7F3D
	s_cbranch_scc1 65412                                       // 000000070A80: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1194>
	v_lshlrev_b32_e32 v33, 2, v33                              // 000000070A84: 30424282
	v_mov_b32_e32 v61, v1                                      // 000000070A88: 7E7A0301
	s_mov_b32 s12, 0                                           // 000000070A8C: BE8C0080
	ds_load_b32 v62, v33 offset:17440                          // 000000070A90: D8D84420 3E000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 000000070A98: CA10011E 2220011D
	s_waitcnt lgkmcnt(0)                                       // 000000070AA0: BF89FC07
	v_mul_f32_e32 v60, v60, v62                                // 000000070AA4: 10787D3C
	v_mov_b32_e32 v62, v35                                     // 000000070AA8: 7E7C0323
	s_nop 0                                                    // 000000070AAC: BF800000
	s_nop 0                                                    // 000000070AB0: BF800000
	s_nop 0                                                    // 000000070AB4: BF800000
	s_nop 0                                                    // 000000070AB8: BF800000
	s_nop 0                                                    // 000000070ABC: BF800000
	global_load_b32 v63, v[33:34], off                         // 000000070AC0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 000000070AC8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 000000070AD0: 4A7C7CC1
	.long 0xd7000121                                           // 000000070AD4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 000000070AD8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000070ADC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 000000070AE0: D5207C22 00064480
	.long 0xd44a0004                                           // 000000070AE8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 000000070AEC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 000000070AF0: 4A7A7AFF 00000044
	s_or_b32 s12, s4, s12                                      // 000000070AF8: 8C0C0C04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000070AFC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 000000070B00: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 000000070B04: 917E0C7E
	s_cbranch_execnz 65517                                     // 000000070B08: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13c0>
	s_or_b32 exec_lo, exec_lo, s12                             // 000000070B0C: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070B10: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 000000070B14: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 000000070B1C: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 000000070B28: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 000000070B34: DC960000 007C2421
	s_branch 65301                                             // 000000070B3C: BFA0FF15 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 000000070B40: A201FF06 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 000000070B48: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000070B4C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 000000070B50: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 000000070B58: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 000000070B5C: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 000000070B64: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 000000070B6C: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000070B70: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 000000070B74: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 000000070B7C: A0010401
	s_mov_b32 s4, 0                                            // 000000070B80: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 000000070B84: BF87000A
	v_exp_f32_e32 v29, s1                                      // 000000070B88: 7E3A4A01
	s_cvt_i32_f32 s1, s7                                       // 000000070B8C: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000070B90: BF870585
	.long 0xd71c001d                                           // 000000070B94: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 000000070B98: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 000000070B9C: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 000000070BA0: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000070BA8: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 000000070BAC: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 000000070BB4: 980180C1
	v_mov_b32_e32 v29, v37                                     // 000000070BB8: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 000000070BBC: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 000000070BC8: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 000000070BD0: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000070BD8: BF870001
	.long 0xd4490001                                           // 000000070BDC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 000000070BE0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 000000070BE8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 000000070BEC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 000000070BF0: 1040411E
	ds_store_b32 v29, v32                                      // 000000070BF4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 000000070BFC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000070C04: 917E047E
	s_cbranch_execnz 65519                                     // 000000070C08: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14c8>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000070C0C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 000000070C10: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 000000070C18: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 000000070C20: 7E420326
	s_mov_b32 s6, 0                                            // 000000070C24: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000070C28: BF89FC07
	s_barrier                                                  // 000000070C2C: BFBD0000
	buffer_gl0_inv                                             // 000000070C30: E0AC0000 00000000
	s_nop 0                                                    // 000000070C38: BF800000
	s_nop 0                                                    // 000000070C3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000070C40: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 000000070C48: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000070C50: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000070C58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000070C5C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 000000070C64: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000070C68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000070C70: BF870004
	.long 0xd4490004                                           // 000000070C74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000070C78: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000070C80: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000070C84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000070C88: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 000000070C8C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 000000070C94: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000070C9C: 917E067E
	s_cbranch_execnz 65511                                     // 000000070CA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1540>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000070CA4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000070CA8: BF89FC07
	s_barrier                                                  // 000000070CAC: BFBD0000
	buffer_gl0_inv                                             // 000000070CB0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 000000070CB8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 000000070CC0: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 000000070CC8: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 000000070CD0: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 000000070CD8: 7E780300
	s_mov_b32 s4, 0                                            // 000000070CDC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000070CE0: BF840001
	s_nop 0                                                    // 000000070CE4: BF800000
	s_nop 0                                                    // 000000070CE8: BF800000
	s_nop 0                                                    // 000000070CEC: BF800000
	s_nop 0                                                    // 000000070CF0: BF800000
	s_nop 0                                                    // 000000070CF4: BF800000
	s_nop 0                                                    // 000000070CF8: BF800000
	s_nop 0                                                    // 000000070CFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070D00: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000070D04: 327A7884
	.long 0xd4490001                                           // 000000070D08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000070D0C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000070D14: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000070D18: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000070D24: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000070D28: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000070D30: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000070D38: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000070D40: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000070D48: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000070D50: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000070D58: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000070D60: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 000000070D64: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000070D70: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 000000070D74: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000070D78: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000070D80: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000070D84: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000070D88: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 000000070D8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070D90: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000070D94: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000070D98: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 000000070D9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070DA0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000070DA4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000070DB0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000070DB8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000070DC0: 917E047E
	s_cbranch_execnz 65486                                     // 000000070DC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1600>
	s_set_inst_prefetch_distance 0x2                           // 000000070DC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000070DCC: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 000000070DD0: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000070DD8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000070DE0: 7E420326
	s_mov_b32 s6, 0                                            // 000000070DE4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000070DE8: BF89FC07
	s_barrier                                                  // 000000070DEC: BFBD0000
	buffer_gl0_inv                                             // 000000070DF0: E0AC0000 00000000
	s_nop 0                                                    // 000000070DF8: BF800000
	s_nop 0                                                    // 000000070DFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000070E00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 000000070E08: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000070E10: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000070E18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000070E1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000070E24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000070E28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000070E30: BF870004
	.long 0xd4490004                                           // 000000070E34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000070E38: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000070E40: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000070E44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000070E48: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 000000070E4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000070E54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000070E5C: 917E067E
	s_cbranch_execnz 65511                                     // 000000070E60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1700>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000070E64: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000070E68: BF89FC07
	s_barrier                                                  // 000000070E6C: BFBD0000
	buffer_gl0_inv                                             // 000000070E70: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 000000070E78: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 000000070E80: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 000000070E88: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 000000070E90: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 000000070E98: 7E780300
	s_mov_b32 s4, 0                                            // 000000070E9C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000070EA0: BF840001
	s_nop 0                                                    // 000000070EA4: BF800000
	s_nop 0                                                    // 000000070EA8: BF800000
	s_nop 0                                                    // 000000070EAC: BF800000
	s_nop 0                                                    // 000000070EB0: BF800000
	s_nop 0                                                    // 000000070EB4: BF800000
	s_nop 0                                                    // 000000070EB8: BF800000
	s_nop 0                                                    // 000000070EBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000070EC0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000070EC4: 327A7884
	.long 0xd4490001                                           // 000000070EC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000070ECC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000070ED4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000070ED8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000070EE4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000070EE8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000070EF0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000070EF8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000070F00: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000070F08: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000070F10: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000070F18: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000070F20: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 000000070F24: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000070F30: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 000000070F34: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000070F38: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000070F40: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000070F44: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000070F48: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 000000070F4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070F50: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000070F54: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000070F58: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 000000070F5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000070F60: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000070F64: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000070F70: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000070F78: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000070F80: 917E047E
	s_cbranch_execnz 65486                                     // 000000070F84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x17c0>
	s_set_inst_prefetch_distance 0x2                           // 000000070F88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000070F8C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 000000070F90: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000070F98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000070FA0: 7E420326
	s_mov_b32 s6, 0                                            // 000000070FA4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000070FA8: BF89FC07
	s_barrier                                                  // 000000070FAC: BFBD0000
	buffer_gl0_inv                                             // 000000070FB0: E0AC0000 00000000
	s_nop 0                                                    // 000000070FB8: BF800000
	s_nop 0                                                    // 000000070FBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000070FC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 000000070FC8: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000070FD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000070FD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000070FDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000070FE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000070FE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000070FF0: BF870004
	.long 0xd4490004                                           // 000000070FF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000070FF8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000071000: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000071004: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000071008: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007100C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000071014: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007101C: 917E067E
	s_cbranch_execnz 65511                                     // 000000071020: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x18c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000071024: 8C7E067E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 000000071028: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000071030: BF89FC07
	s_barrier                                                  // 000000071034: BFBD0000
	buffer_gl0_inv                                             // 000000071038: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 000000071040: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 000000071044: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 00000007104C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 000000071054: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 00000007105C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 000000071064: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000071068: BF840001
	s_nop 0                                                    // 00000007106C: BF800000
	s_nop 0                                                    // 000000071070: BF800000
	s_nop 0                                                    // 000000071074: BF800000
	s_nop 0                                                    // 000000071078: BF800000
	s_nop 0                                                    // 00000007107C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000071080: 327C7A84
	.long 0xd4490001                                           // 000000071084: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000071088: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000071090: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000071094: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000071098: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000710A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000710A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000710B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000710B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000710C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000710C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000710D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000710D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000710E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000710E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000710E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000710EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000710F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000071100: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000071104: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000071108: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000007110C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071110: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000071114: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000071118: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000007111C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071120: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000071124: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000071130: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000071138: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000071140: 917E047E
	s_cbranch_execnz 65486                                     // 000000071144: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1980>
	s_set_inst_prefetch_distance 0x2                           // 000000071148: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007114C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 000000071150: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000071158: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000071160: 7E420326
	s_mov_b32 s6, 0                                            // 000000071164: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000071168: BF89FC07
	s_barrier                                                  // 00000007116C: BFBD0000
	buffer_gl0_inv                                             // 000000071170: E0AC0000 00000000
	s_nop 0                                                    // 000000071178: BF800000
	s_nop 0                                                    // 00000007117C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000071180: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 000000071188: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000071190: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000071198: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007119C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000711A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000711A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000711B0: BF870004
	.long 0xd4490004                                           // 0000000711B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000711B8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 0000000711C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000711C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000711C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000711CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000711D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000000711DC: 917E067E
	s_cbranch_execnz 65511                                     // 0000000711E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a80>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000711E4: 8C7E067E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000000711E8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000711F0: BF89FC07
	s_barrier                                                  // 0000000711F4: BFBD0000
	buffer_gl0_inv                                             // 0000000711F8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 000000071200: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 000000071208: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 000000071210: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 000000071218: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 000000071220: 7E780300
	s_mov_b32 s4, 0                                            // 000000071224: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000071228: BF840001
	s_nop 0                                                    // 00000007122C: BF800000
	s_nop 0                                                    // 000000071230: BF800000
	s_nop 0                                                    // 000000071234: BF800000
	s_nop 0                                                    // 000000071238: BF800000
	s_nop 0                                                    // 00000007123C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000071240: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000071244: 327A7884
	.long 0xd4490001                                           // 000000071248: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000007124C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000071254: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000071258: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000071264: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000071268: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000071270: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000071278: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000071280: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000071288: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000071290: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000071298: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000712A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000712A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000712B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000712B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000712B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000712C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000712C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000712C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000712CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000712D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000712D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000712D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000712DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000712E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000712E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000712F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000712F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000071300: 917E047E
	s_cbranch_execnz 65486                                     // 000000071304: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b40>
	s_set_inst_prefetch_distance 0x2                           // 000000071308: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007130C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 000000071310: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000071318: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000071320: 7E420326
	s_mov_b32 s6, 0                                            // 000000071324: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000071328: BF89FC07
	s_barrier                                                  // 00000007132C: BFBD0000
	buffer_gl0_inv                                             // 000000071330: E0AC0000 00000000
	s_nop 0                                                    // 000000071338: BF800000
	s_nop 0                                                    // 00000007133C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000071340: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 000000071348: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000071350: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000071358: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007135C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000071364: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000071368: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000071370: BF870004
	.long 0xd4490004                                           // 000000071374: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000071378: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000071380: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000071384: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000071388: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007138C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000071394: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007139C: 917E067E
	s_cbranch_execnz 65511                                     // 0000000713A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c40>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000713A4: 8C7E067E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 0000000713A8: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000000713B0: BF89FC07
	s_barrier                                                  // 0000000713B4: BFBD0000
	buffer_gl0_inv                                             // 0000000713B8: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 0000000713C0: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 0000000713C4: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 0000000713CC: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 0000000713D4: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 0000000713DC: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000000713E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000713E8: BF840001
	s_nop 0                                                    // 0000000713EC: BF800000
	s_nop 0                                                    // 0000000713F0: BF800000
	s_nop 0                                                    // 0000000713F4: BF800000
	s_nop 0                                                    // 0000000713F8: BF800000
	s_nop 0                                                    // 0000000713FC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 000000071400: 327C7884
	.long 0xd4490001                                           // 000000071404: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000071408: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000071410: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000071414: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000071418: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000071424: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000071428: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000071430: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000071438: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000071440: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000071448: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000071450: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000071458: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000071460: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000071464: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000071468: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000007146C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000071478: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000071480: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000071484: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000071488: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000007148C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071490: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000071494: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000071498: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000007149C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000714A0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000000714A4: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 0000000714B0: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000714B4: BF870002
	v_mov_b32_e32 v60, v63                                     // 0000000714B8: 7E78033F
	ds_store_b32 v62, v70                                      // 0000000714BC: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000714C4: 917E047E
	s_cbranch_execnz 65485                                     // 0000000714C8: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d00>
	s_set_inst_prefetch_distance 0x2                           // 0000000714CC: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000714D0: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 0000000714D4: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000714DC: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000714E4: 7E420326
	s_mov_b32 s6, 0                                            // 0000000714E8: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000714EC: BF89FC07
	s_barrier                                                  // 0000000714F0: BFBD0000
	buffer_gl0_inv                                             // 0000000714F4: E0AC0000 00000000
	s_nop 0                                                    // 0000000714FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000071500: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 000000071508: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000071510: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000071518: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007151C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000071524: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000071528: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000071530: BF870004
	.long 0xd4490004                                           // 000000071534: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000071538: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000071540: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000071544: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000071548: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007154C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000071554: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007155C: 917E067E
	s_cbranch_execnz 65511                                     // 000000071560: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e00>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000071564: 8C7E067E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 000000071568: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 000000071570: BF89FC07
	s_barrier                                                  // 000000071574: BFBD0000
	buffer_gl0_inv                                             // 000000071578: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 000000071580: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 000000071588: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 000000071590: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 000000071598: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000715A0: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000715A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000715A8: BF840001
	s_nop 0                                                    // 0000000715AC: BF800000
	s_nop 0                                                    // 0000000715B0: BF800000
	s_nop 0                                                    // 0000000715B4: BF800000
	s_nop 0                                                    // 0000000715B8: BF800000
	s_nop 0                                                    // 0000000715BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000715C0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000715C4: 327C7A84
	.long 0xd4490001                                           // 0000000715C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000715CC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000715D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000715D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000715E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000715E8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000715F0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000715F8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000071600: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000071608: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000071610: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000071618: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000071620: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000071624: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000071628: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000007162C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000071638: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000071640: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000071644: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000071648: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000007164C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071650: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000071654: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000071658: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000007165C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071660: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000071664: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000071670: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000071678: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000071680: 917E047E
	s_cbranch_execnz 65486                                     // 000000071684: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ec0>
	s_set_inst_prefetch_distance 0x2                           // 000000071688: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007168C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 000000071690: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000071698: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000716A0: 7E420326
	s_mov_b32 s6, 0                                            // 0000000716A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000716A8: BF89FC07
	s_barrier                                                  // 0000000716AC: BFBD0000
	buffer_gl0_inv                                             // 0000000716B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000716B8: BF800000
	s_nop 0                                                    // 0000000716BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000716C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 0000000716C8: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000716D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000716D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000716DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000716E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000716E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000716F0: BF870004
	.long 0xd4490004                                           // 0000000716F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000716F8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000071700: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000071704: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000071708: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000007170C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000071714: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000007171C: 917E067E
	s_cbranch_execnz 65511                                     // 000000071720: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000071724: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000071728: BF89FC07
	s_barrier                                                  // 00000007172C: BFBD0000
	buffer_gl0_inv                                             // 000000071730: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 000000071738: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 000000071740: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 000000071748: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 000000071750: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000071758: 7E7A0300
	s_mov_b32 s4, 0                                            // 00000007175C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000071760: BF840001
	s_nop 0                                                    // 000000071764: BF800000
	s_nop 0                                                    // 000000071768: BF800000
	s_nop 0                                                    // 00000007176C: BF800000
	s_nop 0                                                    // 000000071770: BF800000
	s_nop 0                                                    // 000000071774: BF800000
	s_nop 0                                                    // 000000071778: BF800000
	s_nop 0                                                    // 00000007177C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000071780: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000071784: 327C7A84
	.long 0xd4490001                                           // 000000071788: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 00000007178C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000071794: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000071798: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000717A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000717A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000717B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000717B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000717C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000717C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000717D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000717D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000717E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000717E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000717E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000717EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000717F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000071800: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000071804: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000071808: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000007180C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071810: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000071814: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000071818: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000007181C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071820: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000071824: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000071830: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000071838: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000071840: 917E047E
	s_cbranch_execnz 65486                                     // 000000071844: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2080>
	s_set_inst_prefetch_distance 0x2                           // 000000071848: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007184C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 000000071850: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000071858: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000071860: 7E420326
	s_mov_b32 s6, 0                                            // 000000071864: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000071868: BF89FC07
	s_barrier                                                  // 00000007186C: BFBD0000
	buffer_gl0_inv                                             // 000000071870: E0AC0000 00000000
	s_nop 0                                                    // 000000071878: BF800000
	s_nop 0                                                    // 00000007187C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000071880: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 000000071888: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000071890: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000071898: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000007189C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000718A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000718A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000718B0: BF870004
	.long 0xd4490004                                           // 0000000718B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000718B8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 0000000718C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000718C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000718C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000718CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000718D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000000718DC: 917E067E
	s_cbranch_execnz 65511                                     // 0000000718E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2180>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000718E4: 8C7E067E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 0000000718E8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 0000000718F0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000718F8: BF89FC07
	s_barrier                                                  // 0000000718FC: BFBD0000
	buffer_gl0_inv                                             // 000000071900: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 000000071908: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 000000071910: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 000000071918: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 000000071920: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 000000071928: 7E780300
	s_mov_b32 s4, 0                                            // 00000007192C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000071930: BF840001
	s_nop 0                                                    // 000000071934: BF800000
	s_nop 0                                                    // 000000071938: BF800000
	s_nop 0                                                    // 00000007193C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000071940: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000071944: 327A7884
	.long 0xd4490001                                           // 000000071948: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000007194C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000071954: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000071958: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000071964: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000071968: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000071970: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000071978: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000071980: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000071988: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000071990: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000071998: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000719A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000719A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000719B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000719B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000719B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000719C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000719C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000719C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000719CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000719D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000719D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000719D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000719DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000719E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000719E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000719F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000719F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000071A00: 917E047E
	s_cbranch_execnz 65486                                     // 000000071A04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2240>
	s_set_inst_prefetch_distance 0x2                           // 000000071A08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000071A0C: 8C7E047E
	.long 0xd7000107                                           // 000000071A10: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 000000071A14: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000071A1C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 000000071A20: D5207C08 00061080
	.long 0xd7000109                                           // 000000071A28: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 000000071A2C: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 000000071A34: D5207C0A 00061480
	.long 0xd700010d                                           // 000000071A3C: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 000000071A40: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000071A48: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 000000071A4C: D5207C0E 00061C80
	.long 0xd700010b                                           // 000000071A54: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 000000071A58: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 000000071A60: D5207C0C 00061880
	.long 0xd700010f                                           // 000000071A68: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 000000071A6C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000071A74: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 000000071A78: D5207C10 00062080
	.long 0xd7000111                                           // 000000071A80: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 000000071A84: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 000000071A8C: D5207C12 00062480
	.long 0xd7000113                                           // 000000071A94: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 000000071A98: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000071AA0: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 000000071AA4: D5207C14 00062880
	.long 0xd7000115                                           // 000000071AAC: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 000000071AB0: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 000000071AB8: D5207C16 00062C80
	.long 0xd7000117                                           // 000000071AC0: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 000000071AC4: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000071ACC: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 000000071AD0: D5207C18 00063080
	.long 0xd7000119                                           // 000000071AD8: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 000000071ADC: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 000000071AE4: D5207C1A 00063480
	.long 0xd700011b                                           // 000000071AEC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 000000071AF0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000071AF8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 000000071AFC: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 000000071B04: 81058105
	s_waitcnt lgkmcnt(0)                                       // 000000071B08: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 000000071B0C: BF062105
	s_barrier                                                  // 000000071B10: BFBD0000
	buffer_gl0_inv                                             // 000000071B14: E0AC0000 00000000
	s_cbranch_scc0 63457                                       // 000000071B1C: BFA1F7E1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a4>
	v_mov_b32_e32 v4, v38                                      // 000000071B20: 7E080326
	s_add_u32 s0, s28, s20                                     // 000000071B24: 8000141C
	.long 0xd73c0000                                           // 000000071B28: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 000000071B2C: 02020489
	s_addc_u32 s1, s29, s21                                    // 000000071B30: 8201151D
	s_add_u32 s2, s24, s18                                     // 000000071B34: 80021218
	s_addc_u32 s3, s25, s19                                    // 000000071B38: 82031319
	s_add_u32 s0, s2, s0                                       // 000000071B3C: 80000002
	s_addc_u32 s1, s3, s1                                      // 000000071B40: 82010103
	.long 0xd7006a00                                           // 000000071B44: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000071B48: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000071B4C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000071B50: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 000000071B58: BE810080
	.long 0xd7006a00                                           // 000000071B5C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 000000071B60: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000071B64: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000071B6C: BF870092
	.long 0xd7006a00                                           // 000000071B70: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000071B74: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000071B78: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 000000071B80: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 000000071B88: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 000000071B90: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000071B98: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 000000071B9C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 000000071BA4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 000000071BA8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 000000071BAC: DC6A0000 007C0200
	.long 0xd7000000                                           // 000000071BB4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 000000071BB8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 000000071BC0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000071BC8: 917E017E
	s_cbranch_execnz 65516                                     // 000000071BCC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2480>
	s_endpgm                                                   // 000000071BD0: BFB00000
		...

