00000000001d8c00 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi5EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi5EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_clause 0x1                                               // 0000001D8C00: BF850001
	s_load_b128 s[12:15], s[0:1], 0x20                         // 0000001D8C04: F4080300 F8000020
	s_load_b128 s[16:19], s[0:1], 0x38                         // 0000001D8C0C: F4080400 F8000038
	s_mov_b32 s20, s3                                          // 0000001D8C14: BE940003
	s_ashr_i32 s3, s2, 31                                      // 0000001D8C18: 86039F02
	s_waitcnt lgkmcnt(0)                                       // 0000001D8C1C: BF89FC07
	s_load_b32 s22, s[14:15], null                             // 0000001D8C20: F4000587 F8000000
	s_clause 0x1                                               // 0000001D8C28: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 0000001D8C2C: F40C0100 F8000000
	s_load_b32 s14, s[0:1], 0x48                               // 0000001D8C34: F4000380 F8000048
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000001D8C3C: 84808202
	s_waitcnt lgkmcnt(0)                                       // 0000001D8C40: BF89FC07
	s_add_i32 s22, s22, s2                                     // 0000001D8C44: 81160216
	s_add_u32 s0, s18, s0                                      // 0000001D8C48: 80000012
	s_addc_u32 s1, s19, s1                                     // 0000001D8C4C: 82010113
	s_add_i32 s3, s22, 1                                       // 0000001D8C50: 81038116
	s_load_b32 s19, s[0:1], null                               // 0000001D8C54: F40004C0 F8000000
	s_ashr_i32 s0, s3, 31                                      // 0000001D8C5C: 86009F03
	s_mul_hi_i32 s1, s14, s2                                   // 0000001D8C60: 9701020E
	s_lshr_b32 s0, s0, 30                                      // 0000001D8C64: 85009E00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001D8C68: BF870499
	s_add_i32 s3, s3, s0                                       // 0000001D8C6C: 81030003
	s_and_b32 s18, s3, -4                                      // 0000001D8C70: 8B12C403
	s_ashr_i32 s3, s3, 2                                       // 0000001D8C74: 86038203
	s_sub_i32 s0, s22, s18                                     // 0000001D8C78: 81801216
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001D8C7C: BF870009
	s_cmp_gt_i32 s0, -1                                        // 0000001D8C80: BF02C100
	s_mul_i32 s0, s14, s2                                      // 0000001D8C84: 9600020E
	s_cselect_b32 s15, -1, 0                                   // 0000001D8C88: 980F80C1
	s_mov_b32 s14, s3                                          // 0000001D8C8C: BE8E0003
	s_and_b32 vcc_lo, exec_lo, s15                             // 0000001D8C90: 8B6A0F7E
	s_cbranch_vccnz 15                                         // 0000001D8C94: BFA4000F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi5EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd4>
	s_lshl_b64 s[24:25], s[0:1], 2                             // 0000001D8C98: 84988200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001D8C9C: BF8704D9
	s_add_u32 s14, s16, s24                                    // 0000001D8CA0: 800E1810
	s_addc_u32 s21, s17, s25                                   // 0000001D8CA4: 82151911
	s_waitcnt lgkmcnt(0)                                       // 0000001D8CA8: BF89FC07
	s_max_i32 s24, s19, 1                                      // 0000001D8CAC: 8A188113
	s_mov_b32 s25, 0                                           // 0000001D8CB0: BE990080
	s_lshl_b64 s[24:25], s[24:25], 2                           // 0000001D8CB4: 84988218
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001D8CB8: BF870009
	s_add_u32 s14, s14, s24                                    // 0000001D8CBC: 800E180E
	s_addc_u32 s21, s21, s25                                   // 0000001D8CC0: 82151915
	s_add_u32 s24, s14, -4                                     // 0000001D8CC4: 8018C40E
	s_addc_u32 s25, s21, -1                                    // 0000001D8CC8: 8219C115
	s_load_b32 s14, s[24:25], null                             // 0000001D8CCC: F400038C F8000000
	v_cndmask_b32_e64 v1, 0, 1, s15                            // 0000001D8CD4: D5010001 003D0280
	s_mov_b32 s24, exec_lo                                     // 0000001D8CDC: BE98007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001D8CE0: BF8704B1
	v_readfirstlane_b32 s15, v1                                // 0000001D8CE4: 7E1E0501
	s_waitcnt lgkmcnt(0)                                       // 0000001D8CE8: BF89FC07
	s_add_i32 s15, s19, s15                                    // 0000001D8CEC: 810F0F13
	s_add_i32 s21, s15, 3                                      // 0000001D8CF0: 8115830F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001D8CF4: BF870499
	s_and_b32 s23, s21, -4                                     // 0000001D8CF8: 8B17C415
	.long 0xd4c4007e                                           // 0000001D8CFC: D4C4007E
	v_cndmask_b32_e32 v1, s23, v0, vcc_lo                      // 0000001D8D00: 02020017
	s_cbranch_execz 46                                         // 0000001D8D04: BFA5002E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi5EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1c0>
	v_dual_mov_b32 v4, v0 :: v_dual_lshlrev_b32 v3, 2, v0      // 0000001D8D08: CA220100 04020082
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000001D8D10: 84808200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D8D14: BF8700A9
	s_add_u32 s0, s16, s0                                      // 0000001D8D18: 80000010
	s_addc_u32 s1, s17, s1                                     // 0000001D8D1C: 82010111
	.long 0xd7000001                                           // 0000001D8D20: D7000001
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000001D8D24: 02020600
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D8D28: BF870001
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 0000001D8D2C: D5207C02 00010001
	s_mov_b32 s1, 0                                            // 0000001D8D34: BE810080
	s_set_inst_prefetch_distance 0x1                           // 0000001D8D38: BF840001
	s_branch 19                                                // 0000001D8D3C: BFA00013 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi5EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x18c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001D8D40: 8C7E007E
	v_add_nc_u32_e32 v6, 0x200, v3                             // 0000001D8D44: 4A0C06FF 00000200
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001D8D4C: 4A0808FF 00000080
	s_waitcnt vmcnt(0)                                         // 0000001D8D54: BF8903F7
	ds_store_b32 v3, v5 offset:512                             // 0000001D8D58: D8340200 00000503
	.long 0xd7000001                                           // 0000001D8D60: D7000001
	v_cndmask_b32_e32 v1, 0x200, v1, vcc_lo                    // 0000001D8D64: 020202FF 00000200
	v_mov_b32_e32 v3, v6                                       // 0000001D8D6C: 7E060306
	v_cmp_le_i32_e32 vcc_lo, s23, v4                           // 0000001D8D70: 7C860817
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001D8D74: D5207C02 00020480
	s_or_b32 s1, vcc_lo, s1                                    // 0000001D8D7C: 8C01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001D8D80: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001D8D84: 917E017E
	s_cbranch_execz 13                                         // 0000001D8D88: BFA5000D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi5EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1c0>
	s_mov_b32 s0, exec_lo                                      // 0000001D8D8C: BE80007E
	.long 0xd4c3007e                                           // 0000001D8D90: D4C3007E
	v_cndmask_b32_e32 v1, s19, v4, vcc_lo                      // 0000001D8D94: 02020813
	s_xor_b32 s0, exec_lo, s0                                  // 0000001D8D98: 8D00007E
	v_mov_b32_e32 v5, s3                                       // 0000001D8D9C: 7E0A0203
	v_cmp_gt_i32_e32 vcc_lo, s15, v4                           // 0000001D8DA0: 7C88080F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001D8DA4: BF870002
	v_cndmask_b32_e32 v5, s14, v5, vcc_lo                      // 0000001D8DA8: 020A0A0E
	s_and_not1_saveexec_b32 s0, s0                             // 0000001D8DAC: BE803000
	s_cbranch_execz 65507                                      // 0000001D8DB0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi5EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	global_load_b32 v5, v[1:2], off                            // 0000001D8DB4: DC520000 057C0001
	s_branch 65504                                             // 0000001D8DBC: BFA0FFE0 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi5EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	s_set_inst_prefetch_distance 0x2                           // 0000001D8DC0: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 0000001D8DC4: 8C7E187E
	v_dual_mov_b32 v78, 0 :: v_dual_and_b32 v73, 15, v0        // 0000001D8DC8: CA240080 4E48008F
	v_bfe_u32 v76, v0, 4, 1                                    // 0000001D8DD0: D610004C 02050900
	s_mul_i32 s3, s20, 12                                      // 0000001D8DD8: 96038C14
	s_mul_hi_i32 s15, s2, 0x1800                               // 0000001D8DDC: 970FFF02 00001800
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001D8DE4: BF870002
	v_cmp_gt_u32_e32 vcc_lo, 12, v73                           // 0000001D8DE8: 7C98928C
	s_mul_i32 s14, s2, 0x1800                                  // 0000001D8DEC: 960EFF02 00001800
	v_lshrrev_b32_e32 v74, 5, v0                               // 0000001D8DF4: 32940085
	s_lshl_b64 s[0:1], s[14:15], 1                             // 0000001D8DF8: 8480810E
	s_ashr_i32 s16, s21, 2                                     // 0000001D8DFC: 86108215
	v_dual_cndmask_b32 v1, 0, v73 :: v_dual_lshlrev_b32 v72, 5, v76// 0000001D8E00: CA629280 01489885
	s_add_u32 s0, s4, s0                                       // 0000001D8E08: 80000004
	s_addc_u32 s1, s5, s1                                      // 0000001D8E0C: 82010105
	v_lshlrev_b32_e32 v75, 6, v74                              // 0000001D8E10: 30969486
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001D8E14: BF8700B2
	v_add_lshl_u32 v1, v1, s3, 8                               // 0000001D8E18: D6470001 02200701
	s_mov_b32 s4, 0                                            // 0000001D8E20: BE840080
	s_cmp_gt_i32 s16, 0                                        // 0000001D8E24: BF028010
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000001D8E28: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D8E2C: BF870121
	.long 0xd73c0002                                           // 0000001D8E30: D73C0002
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000001D8E34: 02020281
	v_lshlrev_b32_e32 v1, 7, v74                               // 0000001D8E38: 30029487
	.long 0xd7006a02                                           // 0000001D8E3C: D7006A02
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 0000001D8E40: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D8E44: BF870111
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 0000001D8E48: D5207C03 01AA0601
	.long 0xd7006a02                                           // 0000001D8E50: D7006A02
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000001D8E54: 02020302
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D8E58: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000001D8E5C: D5207C03 01AA0680
	s_clause 0x7                                               // 0000001D8E64: BF850007
	global_load_b128 v[36:39], v[2:3], off offset:16           // 0000001D8E68: DC5E0010 247C0002
	global_load_b128 v[32:35], v[2:3], off                     // 0000001D8E70: DC5E0000 207C0002
	global_load_b128 v[44:47], v[2:3], off offset:48           // 0000001D8E78: DC5E0030 2C7C0002
	global_load_b128 v[40:43], v[2:3], off offset:32           // 0000001D8E80: DC5E0020 287C0002
	global_load_b128 v[52:55], v[2:3], off offset:80           // 0000001D8E88: DC5E0050 347C0002
	global_load_b128 v[48:51], v[2:3], off offset:64           // 0000001D8E90: DC5E0040 307C0002
	global_load_b128 v[60:63], v[2:3], off offset:112          // 0000001D8E98: DC5E0070 3C7C0002
	global_load_b128 v[56:59], v[2:3], off offset:96           // 0000001D8EA0: DC5E0060 387C0002
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001D8EA8: BF890007
	s_barrier                                                  // 0000001D8EAC: BFBD0000
	buffer_gl0_inv                                             // 0000001D8EB0: E0AC0000 00000000
	s_cbranch_scc0 522                                         // 0000001D8EB8: BFA1020A <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi5EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xae4>
	v_mul_u32_u24_e32 v2, 0x140, v76                           // 0000001D8EBC: 160498FF 00000140
	v_mul_u32_u24_e32 v3, 20, v73                              // 0000001D8EC4: 16069294
	s_ashr_i32 s21, s20, 31                                    // 0000001D8EC8: 86159F14
	v_dual_mov_b32 v77, 0 :: v_dual_lshlrev_b32 v0, 5, v0      // 0000001D8ECC: CA220080 4D000085
	s_lshl_b64 s[0:1], s[20:21], 11                            // 0000001D8ED4: 84808B14
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000001D8ED8: BF870152
	v_add3_u32 v2, v3, v2, 0x2210                              // 0000001D8EDC: D6550002 03FE0503 00002210
	v_dual_mov_b32 v64, 0 :: v_dual_lshlrev_b32 v3, 9, v74     // 0000001D8EE8: CA220080 40029489
	s_add_u32 s0, s6, s0                                       // 0000001D8EF0: 80000006
	s_addc_u32 s1, s7, s1                                      // 0000001D8EF4: 82010107
	v_or_b32_e32 v81, 0x3610, v72                              // 0000001D8EF8: 38A290FF 00003610
	.long 0xd7000003                                           // 0000001D8F00: D7000003
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000001D8F04: 02020600
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D8F08: BF870001
	v_add_co_ci_u32_e64 v4, null, s1, 0, s0                    // 0000001D8F0C: D5207C04 00010001
	s_lshl_b64 s[0:1], s[20:21], 8                             // 0000001D8F14: 84808814
	v_and_b32_e32 v0, 0x60, v0                                 // 0000001D8F18: 360000FF 00000060
	v_lshl_add_u32 v82, v74, 2, v2                             // 0000001D8F20: D6460052 0409054A
	v_lshl_or_b32 v5, v73, 1, v72                              // 0000001D8F28: D6560005 05210349
	v_or_b32_e32 v6, 64, v1                                    // 0000001D8F30: 380C02C0
	v_dual_mov_b32 v88, 0xf149f2ca :: v_dual_lshlrev_b32 v83, 5, v73// 0000001D8F34: CA2200FF 58529285 F149F2CA
	.long 0xd7006a4f                                           // 0000001D8F40: D7006A4F
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 0000001D8F44: 02020103
	v_or_b32_e32 v0, s0, v73                                   // 0000001D8F48: 38009200
	v_add_co_ci_u32_e64 v80, null, 0, v4, vcc_lo               // 0000001D8F4C: D5207C50 01AA0880
	v_mov_b32_e32 v3, s1                                       // 0000001D8F54: 7E060201
	v_mul_u32_u24_e32 v4, 0x500, v74                           // 0000001D8F58: 160894FF 00000500
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D8F60: BF870004
	.long 0xd7006a55                                           // 0000001D8F64: D7006A55
	v_cndmask_b32_e32 v1, v0, v75, vcc_lo                      // 0000001D8F68: 02029700
	s_lshl2_add_u32 s0, s19, s22                               // 0000001D8F6C: 87801613
	v_lshl_add_u32 v84, v74, 3, v81                            // 0000001D8F70: D6460054 0545074A
	v_add_co_ci_u32_e64 v86, null, 0, v3, vcc_lo               // 0000001D8F78: D5207C56 01AA0680
	v_dual_mov_b32 v66, v64 :: v_dual_and_b32 v87, 12, v73     // 0000001D8F80: CA240140 4256928C
	v_dual_mov_b32 v65, v64 :: v_dual_add_nc_u32 v90, v5, v1   // 0000001D8F88: CA200140 415A0305
	v_dual_mov_b32 v67, v64 :: v_dual_add_nc_u32 v92, 0x400, v82// 0000001D8F90: CA200140 435CA4FF 00000400
	v_dual_mov_b32 v68, v64 :: v_dual_add_nc_u32 v89, v2, v4   // 0000001D8F9C: CA200140 44580902
	v_dual_mov_b32 v69, v64 :: v_dual_add_nc_u32 v94, 0xe00, v82// 0000001D8FA4: CA200140 455EA4FF 00000E00
	v_dual_mov_b32 v70, v64 :: v_dual_add_nc_u32 v91, v5, v6   // 0000001D8FB0: CA200140 465A0D05
	v_dual_mov_b32 v71, v64 :: v_dual_mov_b32 v78, 0           // 0000001D8FB8: CA100140 474E0080
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v93, 0xa00, v82 // 0000001D8FC0: CA200080 185CA4FF 00000A00
	v_dual_mov_b32 v95, 0xf149f2ca :: v_dual_mov_b32 v26, v77  // 0000001D8FCC: CA1000FF 5F1A014D F149F2CA
	v_dual_mov_b32 v25, v77 :: v_dual_mov_b32 v16, 0           // 0000001D8FD8: CA10014D 19100080
	v_dual_mov_b32 v27, v77 :: v_dual_mov_b32 v8, 0            // 0000001D8FE0: CA10014D 1B080080
	v_mov_b32_e32 v28, v77                                     // 0000001D8FE8: 7E38034D
	v_dual_mov_b32 v29, v77 :: v_dual_mov_b32 v0, 0            // 0000001D8FEC: CA10014D 1D000080
	v_mov_b32_e32 v30, v77                                     // 0000001D8FF4: 7E3C034D
	v_mov_b32_e32 v31, v77                                     // 0000001D8FF8: 7E3E034D
	v_mov_b32_e32 v17, v77                                     // 0000001D8FFC: 7E22034D
	v_mov_b32_e32 v18, v77                                     // 0000001D9000: 7E24034D
	v_mov_b32_e32 v19, v77                                     // 0000001D9004: 7E26034D
	v_mov_b32_e32 v20, v77                                     // 0000001D9008: 7E28034D
	v_mov_b32_e32 v21, v77                                     // 0000001D900C: 7E2A034D
	v_mov_b32_e32 v22, v77                                     // 0000001D9010: 7E2C034D
	v_mov_b32_e32 v23, v77                                     // 0000001D9014: 7E2E034D
	v_mov_b32_e32 v9, v77                                      // 0000001D9018: 7E12034D
	v_mov_b32_e32 v10, v77                                     // 0000001D901C: 7E14034D
	v_mov_b32_e32 v11, v77                                     // 0000001D9020: 7E16034D
	v_mov_b32_e32 v12, v77                                     // 0000001D9024: 7E18034D
	v_mov_b32_e32 v13, v77                                     // 0000001D9028: 7E1A034D
	v_mov_b32_e32 v14, v77                                     // 0000001D902C: 7E1C034D
	v_mov_b32_e32 v15, v77                                     // 0000001D9030: 7E1E034D
	v_mov_b32_e32 v1, v77                                      // 0000001D9034: 7E02034D
	v_mov_b32_e32 v2, v77                                      // 0000001D9038: 7E04034D
	v_mov_b32_e32 v3, v77                                      // 0000001D903C: 7E06034D
	v_mov_b32_e32 v4, v77                                      // 0000001D9040: 7E08034D
	v_mov_b32_e32 v5, v77                                      // 0000001D9044: 7E0A034D
	v_mov_b32_e32 v6, v77                                      // 0000001D9048: 7E0C034D
	v_mov_b32_e32 v7, v77                                      // 0000001D904C: 7E0E034D
	s_sub_i32 s0, s0, s18                                      // 0000001D9050: 81801200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001D9054: BF870009
	s_add_i32 s5, s0, 1                                        // 0000001D9058: 81058100
	v_dual_mov_b32 v97, s4 :: v_dual_add_nc_u32 v96, s4, v87   // 0000001D905C: CA200004 6160AE04
	s_add_i32 s16, s16, -1                                     // 0000001D9064: 8110C110
	s_add_i32 s4, s4, 16                                       // 0000001D9068: 81049004
	ds_load_b32 v101, v96 offset:512                           // 0000001D906C: D8D80200 65000060
	ds_load_b128 v[96:99], v97 offset:512                      // 0000001D9074: DBFC0200 60000061
	s_waitcnt lgkmcnt(1)                                       // 0000001D907C: BF89FC17
	v_ashrrev_i32_e32 v102, 31, v101                           // 0000001D9080: 34CCCA9F
	s_waitcnt lgkmcnt(0)                                       // 0000001D9084: BF89FC07
	v_ashrrev_i32_e32 v104, 31, v96                            // 0000001D9088: 34D0C09F
	v_dual_mov_b32 v103, v96 :: v_dual_mov_b32 v96, v98        // 0000001D908C: CA100160 67600162
	v_ashrrev_i32_e32 v106, 31, v97                            // 0000001D9094: 34D4C29F
	v_mov_b32_e32 v105, v97                                    // 0000001D9098: 7ED20361
	.long 0xd73c0065                                           // 0000001D909C: D73C0065
	v_cndmask_b32_e32 v1, 12, v101, vcc_lo                     // 0000001D90A0: 0202CA8C
	v_ashrrev_i32_e32 v97, 31, v98                             // 0000001D90A4: 34C2C49F
	.long 0xd73c0067                                           // 0000001D90A8: D73C0067
	v_cndmask_b32_e32 v1, 9, v103, vcc_lo                      // 0000001D90AC: 0202CE89
	v_ashrrev_i32_e32 v100, 31, v99                            // 0000001D90B0: 34C8C69F
	.long 0xd73c0069                                           // 0000001D90B4: D73C0069
	v_cndmask_b32_e32 v1, 9, v105, vcc_lo                      // 0000001D90B8: 0202D289
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D90BC: BF870224
	.long 0xd73c0060                                           // 0000001D90C0: D73C0060
	v_cndmask_b32_e32 v1, 9, v96, vcc_lo                       // 0000001D90C4: 0202C089
	.long 0xd7006a78                                           // 0000001D90C8: D7006A78
	v_cndmask_b32_e32 v1, v79, v101, vcc_lo                    // 0000001D90CC: 0202CB4F
	.long 0xd73c0062                                           // 0000001D90D0: D73C0062
	v_cndmask_b32_e32 v1, 9, v99, vcc_lo                       // 0000001D90D4: 0202C689
	v_add_co_ci_u32_e64 v121, null, v80, v102, vcc_lo          // 0000001D90D8: D5207C79 01AACD50
	.long 0xd7006a7a                                           // 0000001D90E0: D7006A7A
	v_cndmask_b32_e32 v1, v103, v85, vcc_lo                    // 0000001D90E4: 0202AB67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D90E8: BF8700A1
	v_add_co_ci_u32_e64 v123, null, v104, v86, vcc_lo          // 0000001D90EC: D5207C7B 01AAAD68
	.long 0xd7006a80                                           // 0000001D90F4: D7006A80
	v_cndmask_b32_e32 v1, v105, v85, vcc_lo                    // 0000001D90F8: 0202AB69
	v_add_co_ci_u32_e64 v129, null, v106, v86, vcc_lo          // 0000001D90FC: D5207C81 01AAAD6A
	.long 0xd7006a82                                           // 0000001D9104: D7006A82
	v_cndmask_b32_e32 v1, v96, v85, vcc_lo                     // 0000001D9108: 0202AB60
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D910C: BF870001
	v_add_co_ci_u32_e64 v131, null, v97, v86, vcc_lo           // 0000001D9110: D5207C83 01AAAD61
	.long 0xd7006a84                                           // 0000001D9118: D7006A84
	v_cndmask_b32_e32 v1, v98, v85, vcc_lo                     // 0000001D911C: 0202AB62
	.long 0xd73c0086                                           // 0000001D9120: D73C0086
	v_cndmask_b32_e32 v1, 3, v122, vcc_lo                      // 0000001D9124: 0202F483
	v_add_co_ci_u32_e64 v133, null, v99, v86, vcc_lo           // 0000001D9128: D5207C85 01AAAD63
	.long 0xd73c0080                                           // 0000001D9130: D73C0080
	v_cndmask_b32_e32 v1, 3, v128, vcc_lo                      // 0000001D9134: 02030083
	.long 0xd73c0082                                           // 0000001D9138: D73C0082
	v_cndmask_b32_e32 v1, 3, v130, vcc_lo                      // 0000001D913C: 02030483
	s_clause 0x5                                               // 0000001D9140: BF850005
	global_load_b128 v[100:103], v[120:121], off offset:16     // 0000001D9144: DC5E0010 647C0078
	global_load_b128 v[96:99], v[120:121], off                 // 0000001D914C: DC5E0000 607C0078
	global_load_b128 v[108:111], v[120:121], off offset:144    // 0000001D9154: DC5E0090 6C7C0078
	global_load_b128 v[104:107], v[120:121], off offset:128    // 0000001D915C: DC5E0080 687C0078
	global_load_b128 v[116:119], v[120:121], off offset:272    // 0000001D9164: DC5E0110 747C0078
	global_load_b128 v[112:115], v[120:121], off offset:256    // 0000001D916C: DC5E0100 707C0078
	.long 0xd73c0084                                           // 0000001D9174: D73C0084
	v_cndmask_b32_e32 v1, 3, v132, vcc_lo                      // 0000001D9178: 02030883
	.long 0xd7006a86                                           // 0000001D917C: D7006A86
	v_cndmask_b32_e32 v1, s8, v134, vcc_lo                     // 0000001D9180: 02030C08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D9184: BF8700A1
	v_add_co_ci_u32_e64 v135, null, s9, v135, vcc_lo           // 0000001D9188: D5207C87 01AB0E09
	.long 0xd7006a8c                                           // 0000001D9190: D7006A8C
	v_cndmask_b32_e32 v1, s8, v128, vcc_lo                     // 0000001D9194: 02030008
	v_add_co_ci_u32_e64 v141, null, s9, v129, vcc_lo           // 0000001D9198: D5207C8D 01AB0209
	.long 0xd7006a8e                                           // 0000001D91A0: D7006A8E
	v_cndmask_b32_e32 v1, s8, v130, vcc_lo                     // 0000001D91A4: 02030408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D91A8: BF8700A1
	v_add_co_ci_u32_e64 v143, null, s9, v131, vcc_lo           // 0000001D91AC: D5207C8F 01AB0609
	.long 0xd7006a9e                                           // 0000001D91B4: D7006A9E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 0000001D91B8: 02030808
	v_add_co_ci_u32_e64 v159, null, s9, v133, vcc_lo           // 0000001D91BC: D5207C9F 01AB0A09
	s_clause 0x1                                               // 0000001D91C4: BF850001
	global_load_b128 v[124:127], v[120:121], off offset:400    // 0000001D91C8: DC5E0190 7C7C0078
	global_load_b128 v[120:123], v[120:121], off offset:384    // 0000001D91D0: DC5E0180 787C0078
	s_clause 0xf                                               // 0000001D91D8: BF85000F
	global_load_b64 v[128:129], v[134:135], off                // 0000001D91DC: DC560000 807C0086
	global_load_b64 v[136:137], v[134:135], off offset:128     // 0000001D91E4: DC560080 887C0086
	global_load_b64 v[144:145], v[134:135], off offset:256     // 0000001D91EC: DC560100 907C0086
	global_load_b64 v[152:153], v[134:135], off offset:384     // 0000001D91F4: DC560180 987C0086
	global_load_b64 v[130:131], v[140:141], off                // 0000001D91FC: DC560000 827C008C
	global_load_b64 v[138:139], v[140:141], off offset:128     // 0000001D9204: DC560080 8A7C008C
	global_load_b64 v[146:147], v[140:141], off offset:256     // 0000001D920C: DC560100 927C008C
	global_load_b64 v[154:155], v[140:141], off offset:384     // 0000001D9214: DC560180 9A7C008C
	global_load_b64 v[132:133], v[142:143], off                // 0000001D921C: DC560000 847C008E
	global_load_b64 v[140:141], v[142:143], off offset:128     // 0000001D9224: DC560080 8C7C008E
	global_load_b64 v[148:149], v[142:143], off offset:256     // 0000001D922C: DC560100 947C008E
	global_load_b64 v[156:157], v[142:143], off offset:384     // 0000001D9234: DC560180 9C7C008E
	global_load_b64 v[134:135], v[158:159], off                // 0000001D923C: DC560000 867C009E
	global_load_b64 v[142:143], v[158:159], off offset:128     // 0000001D9244: DC560080 8E7C009E
	global_load_b64 v[150:151], v[158:159], off offset:256     // 0000001D924C: DC560100 967C009E
	global_load_b64 v[158:159], v[158:159], off offset:384     // 0000001D9254: DC560180 9E7C009E
	v_cmp_gt_i32_e32 vcc_lo, s5, v73                           // 0000001D925C: 7C889205
	s_add_i32 s5, s5, -16                                      // 0000001D9260: 8105D005
	s_cmp_eq_u32 s16, 0                                        // 0000001D9264: BF068010
	s_waitcnt vmcnt(22)                                        // 0000001D9268: BF895BF7
	v_wmma_f32_16x16x16_bf16 v[160:167], v[32:39], v[96:103], v[64:71]// 0000001D926C: CC4140A0 1D02C120
	s_waitcnt vmcnt(20)                                        // 0000001D9274: BF8953F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D9278: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[160:167], v[40:47], v[104:111], v[160:167]// 0000001D927C: CC4140A0 1E82D128
	s_waitcnt vmcnt(18)                                        // 0000001D9284: BF894BF7
	v_wmma_f32_16x16x16_bf16 v[160:167], v[48:55], v[112:119], v[160:167]// 0000001D9288: CC4140A0 1E82E130
	s_waitcnt vmcnt(16)                                        // 0000001D9290: BF8943F7
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D9294: BF870001
	v_wmma_f32_16x16x16_bf16 v[160:167], v[56:63], v[120:127], v[160:167]// 0000001D9298: CC4140A0 1E82F138
	ds_store_2addr_b32 v82, v160, v161 offset1:160             // 0000001D92A0: D838A000 00A1A052
	ds_store_2addr_b32 v92, v162, v163 offset0:64 offset1:224  // 0000001D92A8: D838E040 00A3A25C
	ds_store_2addr_b32 v93, v164, v165 offset1:160             // 0000001D92B0: D838A000 00A5A45D
	ds_store_2addr_b32 v94, v166, v167 offset0:64 offset1:224  // 0000001D92B8: D838E040 00A7A65E
	s_waitcnt lgkmcnt(0)                                       // 0000001D92C0: BF89FC07
	s_barrier                                                  // 0000001D92C4: BFBD0000
	ds_load_2addr_b32 v[96:97], v89 offset0:2 offset1:3        // 0000001D92C8: D8DC0302 60000059
	ds_load_2addr_b32 v[98:99], v89 offset0:162 offset1:163    // 0000001D92D0: D8DCA3A2 62000059
	ds_load_2addr_b32 v[100:101], v89 offset0:160 offset1:161  // 0000001D92D8: D8DCA1A0 64000059
	ds_load_2addr_b32 v[102:103], v89 offset1:1                // 0000001D92E0: D8DC0100 66000059
	s_waitcnt lgkmcnt(1)                                       // 0000001D92E8: BF89FC17
	v_add_f32_e32 v100, v100, v101                             // 0000001D92EC: 06C8CB64
	s_waitcnt lgkmcnt(0)                                       // 0000001D92F0: BF89FC07
	v_add_f32_e32 v102, v102, v103                             // 0000001D92F4: 06CCCF66
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D92F8: BF870112
	v_add_f32_e32 v98, v100, v98                               // 0000001D92FC: 06C4C564
	v_add_f32_e32 v96, v102, v96                               // 0000001D9300: 06C0C166
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D9304: BF870091
	v_dual_add_f32 v96, v96, v97 :: v_dual_add_f32 v97, v98, v99// 0000001D9308: C908C360 6060C762
	v_mul_f32_e32 v97, 0x3d800000, v97                         // 0000001D9310: 10C2C2FF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D9318: BF870091
	v_cndmask_b32_e32 v97, 0xf149f2ca, v97, vcc_lo             // 0000001D931C: 02C2C2FF F149F2CA
	v_mov_b32_dpp v99, v97 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D9324: 7EC602FA FF096161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D932C: BF870091
	v_dual_max_f32 v99, v99, v99 :: v_dual_mul_f32 v96, 0x3d800000, v96// 0000001D9330: CA86C763 6360C0FF 3D800000
	v_max_f32_e32 v99, v97, v99                                // 0000001D933C: 20C6C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D9340: BF870091
	v_mov_b32_dpp v101, v99 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D9344: 7ECA02FA FF096263
	v_dual_cndmask_b32 v96, 0xf149f2ca, v96 :: v_dual_max_f32 v101, v101, v101// 0000001D934C: CA54C0FF 6064CB65 F149F2CA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D9358: BF870091
	v_mov_b32_dpp v98, v96 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D935C: 7EC402FA FF096160
	v_dual_max_f32 v99, v99, v101 :: v_dual_max_f32 v98, v98, v98// 0000001D9364: CA94CB63 6362C562
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D936C: BF870091
	v_mov_b32_dpp v101, v99 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D9370: 7ECA02FA FF096463
	v_dual_max_f32 v98, v96, v98 :: v_dual_max_f32 v101, v101, v101// 0000001D9378: CA94C560 6264CB65
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D9380: BF870091
	v_mov_b32_dpp v100, v98 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D9384: 7EC802FA FF096262
	v_dual_max_f32 v99, v99, v101 :: v_dual_max_f32 v100, v100, v100// 0000001D938C: CA94CB63 6364C964
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D9394: BF870091
	v_mov_b32_dpp v101, v99 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D9398: 7ECA02FA FF096863
	v_max3_f32 v99, v95, v99, v101                             // 0000001D93A0: D61C0063 0596C75F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D93A8: BF870091
	v_dual_max_f32 v98, v98, v100 :: v_dual_sub_f32 v97, v97, v99// 0000001D93AC: CA8AC962 6260C761
	v_mov_b32_dpp v100, v98 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D93B4: 7EC802FA FF096462
	v_sub_f32_e32 v101, v95, v99                               // 0000001D93BC: 08CAC75F
	v_mov_b32_e32 v95, v99                                     // 0000001D93C0: 7EBE0363
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D93C4: BF870194
	.long 0xd41b0000                                           // 0000001D93C8: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v97, vcc_lo              // 0000001D93CC: 0202C2FF C2CE8ED0
	v_dual_max_f32 v100, v100, v100 :: v_dual_mul_f32 v103, 0x3fb8aa3b, v101// 0000001D93D4: CA86C964 6466CAFF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001D93E0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v101, vcc_lo             // 0000001D93E4: 0202CAFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D93EC: BF870192
	v_max_f32_e32 v98, v98, v100                               // 0000001D93F0: 20C4C962
	v_fma_f32 v110, 0x3fb8aa3b, v101, -v103                    // 0000001D93F4: D613006E 859ECAFF 3FB8AA3B
	v_rndne_f32_e32 v111, v103                                 // 0000001D9400: 7EDE4767
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D9404: BF870113
	v_mov_b32_dpp v100, v98 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D9408: 7EC802FA FF096862
	v_dual_fmac_f32 v110, 0x32a5705f, v101 :: v_dual_sub_f32 v103, v103, v111// 0000001D9410: C80ACAFF 6E66DF67 32A5705F
	v_cvt_i32_f32_e32 v111, v111                               // 0000001D941C: 7EDE116F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D9420: BF870193
	v_max3_f32 v98, v88, v98, v100                             // 0000001D9424: D61C0062 0592C558
	v_add_f32_e32 v103, v103, v110                             // 0000001D942C: 06CEDD67
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D9430: BF8701A2
	v_sub_f32_e32 v100, v88, v98                               // 0000001D9434: 08C8C558
	v_sub_f32_e32 v96, v96, v98                                // 0000001D9438: 08C0C560
	v_exp_f32_e32 v103, v103                                   // 0000001D943C: 7ECE4B67
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D9440: BF8701A2
	v_mul_f32_e32 v99, 0x3fb8aa3b, v100                        // 0000001D9444: 10C6C8FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v100                 // 0000001D944C: 7C36C8FF C2CE8ED0
	.long 0xd41b0002                                           // 0000001D9454: D41B0002
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v96, vcc_lo              // 0000001D9458: 0202C0FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 0000001D9460: BF8702C3
	v_fma_f32 v106, 0x3fb8aa3b, v100, -v99                     // 0000001D9464: D613006A 858EC8FF 3FB8AA3B
	v_rndne_f32_e32 v107, v99                                  // 0000001D9470: 7ED64763
	v_mov_b32_e32 v88, v98                                     // 0000001D9474: 7EB00362
	v_mul_f32_e32 v98, 0x3fb8aa3b, v96                         // 0000001D9478: 10C4C0FF 3FB8AA3B
	.long 0xd71c0067                                           // 0000001D9480: D71C0067
	v_cndmask_b32_e32 v1, v103, v111, vcc_lo                   // 0000001D9484: 0202DF67
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D9488: BF870224
	v_dual_fmac_f32 v106, 0x32a5705f, v100 :: v_dual_sub_f32 v99, v99, v107// 0000001D948C: C80AC8FF 6A62D763 32A5705F
	v_mul_f32_e32 v102, 0x3fb8aa3b, v97                        // 0000001D9498: 10CCC2FF 3FB8AA3B
	v_fma_f32 v104, 0x3fb8aa3b, v96, -v98                      // 0000001D94A0: D6130068 858AC0FF 3FB8AA3B
	v_cvt_i32_f32_e32 v107, v107                               // 0000001D94AC: 7ED6116B
	v_rndne_f32_e32 v105, v98                                  // 0000001D94B0: 7ED24762
	v_add_f32_e32 v99, v99, v106                               // 0000001D94B4: 06C6D563
	v_fma_f32 v108, 0x3fb8aa3b, v97, -v102                     // 0000001D94B8: D613006C 859AC2FF 3FB8AA3B
	v_fmac_f32_e32 v104, 0x32a5705f, v96                       // 0000001D94C4: 56D0C0FF 32A5705F
	v_rndne_f32_e32 v109, v102                                 // 0000001D94CC: 7EDA4766
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D94D0: BF870194
	v_exp_f32_e32 v99, v99                                     // 0000001D94D4: 7EC64B63
	v_fmac_f32_e32 v108, 0x32a5705f, v97                       // 0000001D94D8: 56D8C2FF 32A5705F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001D94E0: BF8701B5
	.long 0xd71c0063                                           // 0000001D94E4: D71C0063
	v_cndmask_b32_e32 v1, v99, v107, vcc_lo                    // 0000001D94E8: 0202D763
	v_sub_f32_e32 v98, v98, v105                               // 0000001D94EC: 08C4D362
	v_cvt_i32_f32_e32 v105, v105                               // 0000001D94F0: 7ED21169
	v_cndmask_b32_e32 v99, 0, v99, vcc_lo                      // 0000001D94F4: 02C6C680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v100                 // 0000001D94F8: 7C3CC8FF 42B17218
	v_sub_f32_e32 v102, v102, v109                             // 0000001D9500: 08CCDB66
	v_add_f32_e32 v98, v98, v104                               // 0000001D9504: 06C4D162
	v_cvt_i32_f32_e32 v109, v109                               // 0000001D9508: 7EDA116D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D950C: BF870193
	v_dual_cndmask_b32 v111, 0x7f800000, v99 :: v_dual_add_f32 v102, v102, v108// 0000001D9510: CA48C6FF 6F66D966 7F800000
	v_exp_f32_e32 v98, v98                                     // 0000001D951C: 7EC44B62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001D9520: BF870311
	v_exp_f32_e32 v102, v102                                   // 0000001D9524: 7ECC4B66
	.long 0xd71c0062                                           // 0000001D9528: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 0000001D952C: 0202D362
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D9530: BF870115
	.long 0xd71c0066                                           // 0000001D9534: D71C0066
	v_cndmask_b32_e32 v1, v102, v109, vcc_lo                   // 0000001D9538: 0202DB66
	v_cndmask_b32_e64 v98, 0, v98, s2                          // 0000001D953C: D5010062 000AC480
	.long 0xd41e0002                                           // 0000001D9544: D41E0002
	v_cndmask_b32_e32 v1, 0x42b17218, v96, vcc_lo              // 0000001D9548: 0202C0FF 42B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001D9550: BF870253
	v_cndmask_b32_e64 v100, 0, v102, s0                        // 0000001D9554: D5010064 0002CC80
	.long 0xd41e0000                                           // 0000001D955C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v97, vcc_lo              // 0000001D9560: 0202C2FF 42B17218
	v_cndmask_b32_e64 v97, 0, v103, s1                         // 0000001D9568: D5010061 0006CE80
	.long 0xd41e0001                                           // 0000001D9570: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v101, vcc_lo             // 0000001D9574: 0202CAFF 42B17218
	v_cndmask_b32_e64 v96, 0x7f800000, v98, s2                 // 0000001D957C: D5010060 000AC4FF 7F800000
	v_cndmask_b32_e64 v113, 0x7f800000, v100, s0               // 0000001D9588: D5010071 0002C8FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D9594: BF870193
	v_cndmask_b32_e64 v112, 0x7f800000, v97, s1                // 0000001D9598: D5010070 0006C2FF 7F800000
	v_bfe_u32 v97, v96, 16, 1                                  // 0000001D95A4: D6100061 02052160
	v_fma_f32 v77, v77, v111, v96                              // 0000001D95AC: D613004D 0582DF4D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D95B4: BF870214
	v_bfe_u32 v98, v113, 16, 1                                 // 0000001D95B8: D6100062 02052171
	v_fma_f32 v78, v78, v112, v113                             // 0000001D95C0: D613004E 05C6E14E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D95C8: BF870194
	v_add3_u32 v96, v96, v97, 0x7fff                           // 0000001D95CC: D6550060 03FEC360 00007FFF
	v_add3_u32 v97, v113, v98, 0x7fff                          // 0000001D95D8: D6550061 03FEC571 00007FFF
	ds_store_b16_d16_hi v90, v96                               // 0000001D95E4: DA840000 0000605A
	ds_store_b16_d16_hi v91, v97                               // 0000001D95EC: DA840000 0000615B
	ds_store_b64 v84, v[111:112]                               // 0000001D95F4: D9340000 00006F54
	s_waitcnt lgkmcnt(0)                                       // 0000001D95FC: BF89FC07
	s_barrier                                                  // 0000001D9600: BFBD0000
	ds_load_b128 v[104:107], v81                               // 0000001D9604: DBFC0000 68000051
	ds_load_b128 v[108:111], v81 offset:16                     // 0000001D960C: DBFC0010 6C000051
	ds_load_b128 v[96:99], v83                                 // 0000001D9614: DBFC0000 60000053
	ds_load_b128 v[100:103], v83 offset:16                     // 0000001D961C: DBFC0010 64000053
	s_waitcnt lgkmcnt(3)                                       // 0000001D9624: BF89FC37
	v_dual_mul_f32 v24, v104, v24 :: v_dual_mul_f32 v19, v107, v19// 0000001D9628: C8C63168 1812276B
	v_dual_mul_f32 v25, v105, v25 :: v_dual_mul_f32 v26, v106, v26// 0000001D9630: C8C63369 191A356A
	s_waitcnt lgkmcnt(2)                                       // 0000001D9638: BF89FC27
	v_mul_f32_e32 v21, v109, v21                               // 0000001D963C: 102A2B6D
	v_dual_mul_f32 v27, v107, v27 :: v_dual_mul_f32 v28, v108, v28// 0000001D9640: C8C6376B 1B1C396C
	v_mul_f32_e32 v23, v111, v23                               // 0000001D9648: 102E2F6F
	v_dual_mul_f32 v29, v109, v29 :: v_dual_mul_f32 v30, v110, v30// 0000001D964C: C8C63B6D 1D1E3D6E
	v_mul_f32_e32 v9, v105, v9                                 // 0000001D9654: 10121369
	v_dual_mul_f32 v31, v111, v31 :: v_dual_mul_f32 v16, v104, v16// 0000001D9658: C8C63F6F 1F102168
	v_mul_f32_e32 v11, v107, v11                               // 0000001D9660: 1016176B
	v_dual_mul_f32 v17, v105, v17 :: v_dual_mul_f32 v18, v106, v18// 0000001D9664: C8C62369 1112256A
	v_dual_mul_f32 v13, v109, v13 :: v_dual_mul_f32 v20, v108, v20// 0000001D966C: C8C61B6D 0D14296C
	v_dual_mul_f32 v15, v111, v15 :: v_dual_mul_f32 v22, v110, v22// 0000001D9674: C8C61F6F 0F162D6E
	v_dual_mul_f32 v1, v105, v1 :: v_dual_mul_f32 v8, v104, v8 // 0000001D967C: C8C60369 01081168
	v_dual_mul_f32 v3, v107, v3 :: v_dual_mul_f32 v10, v106, v10// 0000001D9684: C8C6076B 030A156A
	v_dual_mul_f32 v5, v109, v5 :: v_dual_mul_f32 v12, v108, v12// 0000001D968C: C8C60B6D 050C196C
	v_dual_mul_f32 v7, v111, v7 :: v_dual_mul_f32 v14, v110, v14// 0000001D9694: C8C60F6F 070E1D6E
	v_mul_f32_e32 v0, v104, v0                                 // 0000001D969C: 10000168
	v_mul_f32_e32 v2, v106, v2                                 // 0000001D96A0: 1004056A
	v_mul_f32_e32 v4, v108, v4                                 // 0000001D96A4: 1008096C
	v_mul_f32_e32 v6, v110, v6                                 // 0000001D96A8: 100C0D6E
	s_waitcnt vmcnt(3) lgkmcnt(0)                              // 0000001D96AC: BF890C07
	v_wmma_f32_16x16x16_bf16 v[24:31], v[96:103], v[128:135], v[24:31]// 0000001D96B0: CC414018 1C630160
	s_waitcnt vmcnt(2)                                         // 0000001D96B8: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[16:23], v[96:103], v[136:143], v[16:23]// 0000001D96BC: CC414010 1C431160
	s_waitcnt vmcnt(1)                                         // 0000001D96C4: BF8907F7
	v_wmma_f32_16x16x16_bf16 v[8:15], v[96:103], v[144:151], v[8:15]// 0000001D96C8: CC414008 1C232160
	s_waitcnt vmcnt(0)                                         // 0000001D96D0: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[0:7], v[96:103], v[152:159], v[0:7]// 0000001D96D4: CC414000 1C033160
	s_cbranch_scc0 65119                                       // 0000001D96DC: BFA1FE5F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi5EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x45c>
	s_branch 25                                                // 0000001D96E0: BFA00019 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi5EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xb48>
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v1, 0               // 0000001D96E4: CA100080 00000080
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 0000001D96EC: CA100080 02020080
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 0000001D96F4: CA100080 04040080
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000001D96FC: CA100080 08080080
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 0000001D9704: CA100080 0A0A0080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 0000001D970C: CA100080 0C0C0080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v17, 0             // 0000001D9714: CA100080 10100080
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 0000001D971C: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 0000001D9724: CA100080 14140080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 0000001D972C: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 0000001D9734: CA100080 1A1A0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0             // 0000001D973C: CA100080 1C1C0080
	v_mov_b32_e32 v77, 0                                       // 0000001D9744: 7E9A0280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D9748: BF870111
	v_add_f32_dpp v7, v78, v78 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D974C: 060E9CFA FF09614E
	v_add_f32_dpp v6, v77, v77 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D9754: 060C9AFA FF09614D
	v_or_b32_e32 v35, v75, v73                                 // 0000001D975C: 3846934B
	s_barrier                                                  // 0000001D9760: BFBD0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D9764: BF870193
	v_add_f32_dpp v7, v7, v7 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D9768: 060E0EFA FF096207
	v_add_f32_dpp v6, v6, v6 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D9770: 060C0CFA FF096206
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D9778: BF870223
	v_or_b32_e32 v40, s14, v35                                 // 0000001D977C: 3850460E
	.long 0x7f6c3880                                           // 0000001D9780: 7F6C3880
	v_add_f32_dpp v7, v7, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D9784: 060E0EFA FF096407
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D978C: BF870194
	v_add_f32_dpp v6, v6, v6 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D9790: 060C0CFA FF096406
	.long 0x7f7839b6                                           // 0000001D9798: 7F7839B6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D979C: BF870193
	v_add_f32_dpp v31, v7, v7 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D97A0: 063E0EFA FF096807
	v_add_f32_dpp v30, v6, v6 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D97A8: 063C0CFA FF096806
	v_or_b32_e32 v6, s3, v76                                   // 0000001D97B0: 380C9803
	v_or_b32_e32 v7, 0x3610, v72                               // 0000001D97B4: 380E90FF 00003610
	.long 0x7f7239b6                                           // 0000001D97BC: 7F7239B6
	v_div_scale_f32 v33, null, v31, v31, 1.0                   // 0000001D97C0: D6FC7C21 03CA3F1F
	v_div_scale_f32 v32, null, v30, v30, 1.0                   // 0000001D97C8: D6FC7C20 03CA3D1E
	v_div_scale_f32 v42, vcc_lo, 1.0, v30, 1.0                 // 0000001D97D0: D6FC6A2A 03CA3CF2
	v_lshl_add_u32 v39, v74, 3, v7                             // 0000001D97D8: D6460027 041D074A
	.long 0x7f7a39b6                                           // 0000001D97E0: 7F7A39B6
	v_rcp_f32_e32 v37, v33                                     // 0000001D97E4: 7E4A5521
	v_rcp_f32_e32 v34, v32                                     // 0000001D97E8: 7E445520
	.long 0x7f7639b6                                           // 0000001D97EC: 7F7639B6
	.long 0x7f7439b6                                           // 0000001D97F0: 7F7439B6
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001D97F4: BF8702A6
	v_fma_f32 v15, -v33, v37, 1.0                              // 0000001D97F8: D613000F 23CA4B21
	v_lshlrev_b32_e32 v36, 8, v6                               // 0000001D9800: 30480C88
	v_fma_f32 v6, -v32, v34, 1.0                               // 0000001D9804: D6130006 23CA4520
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D980C: BF870193
	v_dual_fmac_f32 v37, v15, v37 :: v_dual_mov_b32 v38, s15   // 0000001D9810: C8104B0F 2526000F
	v_add_nc_u32_e32 v41, 0x800, v36                           // 0000001D9818: 4A5248FF 00000800
	v_ashrrev_i32_e32 v7, 31, v36                              // 0000001D9820: 340E489F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001D9824: BF870234
	v_fmac_f32_e32 v34, v6, v34                                // 0000001D9828: 56444506
	.long 0xd7000006                                           // 0000001D982C: D7000006
	v_cndmask_b32_e32 v1, v40, v36, vcc_lo                     // 0000001D9830: 02024928
	v_add_nc_u32_e32 v14, 0x400, v36                           // 0000001D9834: 4A1C48FF 00000400
	v_add_co_ci_u32_e64 v7, null, v38, v7, s0                  // 0000001D983C: D5207C07 00020F26
	v_div_scale_f32 v43, s0, 1.0, v31, 1.0                     // 0000001D9844: D6FC002B 03CA3EF2
	v_mul_f32_e32 v44, v42, v34                                // 0000001D984C: 1058452A
	v_add_nc_u32_e32 v22, 0x600, v36                           // 0000001D9850: 4A2C48FF 00000600
	v_ashrrev_i32_e32 v15, 31, v14                             // 0000001D9858: 341E1C9F
	.long 0xd700010e                                           // 0000001D985C: D700010E
	v_cndmask_b32_e32 v1, v40, v14, vcc_lo                     // 0000001D9860: 02021D28
	v_mul_f32_e32 v46, v43, v37                                // 0000001D9864: 105C4B2B
	v_fma_f32 v47, -v32, v44, v42                              // 0000001D9868: D613002F 24AA5920
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000001D9870: 342E2C9F
	v_add_co_ci_u32_e64 v15, null, v38, v15, s1                // 0000001D9874: D5207C0F 00061F26
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D987C: BF870214
	v_fma_f32 v48, -v33, v46, v43                              // 0000001D9880: D6130030 24AE5D21
	v_fmac_f32_e32 v44, v47, v34                               // 0000001D9888: 5658452F
	.long 0xd7000116                                           // 0000001D988C: D7000116
	v_cndmask_b32_e32 v1, v40, v22, vcc_lo                     // 0000001D9890: 02022D28
	.long 0xd73c0006                                           // 0000001D9894: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000001D9898: 02020C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D989C: BF870214
	v_fmac_f32_e32 v46, v48, v37                               // 0000001D98A0: 565C4B30
	v_fma_f32 v32, -v32, v44, v42                              // 0000001D98A4: D6130020 24AA5920
	v_add_co_ci_u32_e64 v23, null, v38, v23, s1                // 0000001D98AC: D5207C17 00062F26
	.long 0xd73c000e                                           // 0000001D98B4: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000001D98B8: 02021C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D98BC: BF870214
	v_fma_f32 v33, -v33, v46, v43                              // 0000001D98C0: D6130021 24AE5D21
	v_div_fmas_f32 v32, v32, v34, v44                          // 0000001D98C8: D6370020 04B24520
	s_mov_b32 vcc_lo, s0                                       // 0000001D98D0: BEEA0000
	.long 0xd73c0016                                           // 0000001D98D4: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000001D98D8: 02022C81
	v_ashrrev_i32_e32 v45, 31, v41                             // 0000001D98DC: 345A529F
	v_div_fmas_f32 v33, v33, v37, v46                          // 0000001D98E0: D6370021 04BA4B21
	v_div_fixup_f32 v30, v32, v30, 1.0                         // 0000001D98E8: D627001E 03CA3D20
	.long 0xd7006a32                                           // 0000001D98F0: D7006A32
	v_cndmask_b32_e32 v1, s10, v6, vcc_lo                      // 0000001D98F4: 02020C0A
	v_add_nc_u32_e32 v32, 0xa00, v36                           // 0000001D98F8: 4A4048FF 00000A00
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001D9900: BF8700B4
	v_div_fixup_f32 v31, v33, v31, 1.0                         // 0000001D9904: D627001F 03CA3F21
	v_add_co_ci_u32_e64 v51, null, s11, v7, vcc_lo             // 0000001D990C: D5207C33 01AA0E0B
	.long 0xd7006a2a                                           // 0000001D9914: D7006A2A
	v_cndmask_b32_e32 v1, s10, v14, vcc_lo                     // 0000001D9918: 02021C0A
	v_add_co_ci_u32_e64 v43, null, s11, v15, vcc_lo            // 0000001D991C: D5207C2B 01AA1E0B
	ds_store_b64 v39, v[30:31]                                 // 0000001D9924: D9340000 00001E27
	.long 0xd7006a1e                                           // 0000001D992C: D7006A1E
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                     // 0000001D9930: 02025328
	v_ashrrev_i32_e32 v33, 31, v32                             // 0000001D9934: 3442409F
	v_add_co_ci_u32_e64 v31, null, v38, v45, vcc_lo            // 0000001D9938: D5207C1F 01AA5B26
	.long 0xd7006a2c                                           // 0000001D9940: D7006A2C
	v_cndmask_b32_e32 v1, s10, v22, vcc_lo                     // 0000001D9944: 02022C0A
	v_or_b32_e32 v34, 0x200, v36                               // 0000001D9948: 384448FF 00000200
	v_add_co_ci_u32_e64 v45, null, s11, v23, vcc_lo            // 0000001D9950: D5207C2D 01AA2E0B
	.long 0xd7006a20                                           // 0000001D9958: D7006A20
	v_cndmask_b32_e32 v1, v40, v32, vcc_lo                     // 0000001D995C: 02024128
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D9960: BF8700A1
	v_add_co_ci_u32_e64 v33, null, v38, v33, vcc_lo            // 0000001D9964: D5207C21 01AA4326
	.long 0xd7000023                                           // 0000001D996C: D7000023
	v_cndmask_b32_e32 v1, s14, v35, vcc_lo                     // 0000001D9970: 0202460E
	v_add_co_ci_u32_e64 v38, null, s15, 0, s0                  // 0000001D9974: D5207C26 0001000F
	v_ashrrev_i32_e32 v39, 31, v34                             // 0000001D997C: 344E449F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D9980: BF870214
	.long 0xd73c0024                                           // 0000001D9984: D73C0024
	v_cndmask_b32_e32 v1, 1, v32, vcc_lo                       // 0000001D9988: 02024081
	.long 0xd7006a20                                           // 0000001D998C: D7006A20
	v_cndmask_b32_e32 v1, v35, v34, vcc_lo                     // 0000001D9990: 02024523
	.long 0xd73c001e                                           // 0000001D9994: D73C001E
	v_cndmask_b32_e32 v1, 1, v30, vcc_lo                       // 0000001D9998: 02023C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001D999C: BF8700B4
	v_add_co_ci_u32_e64 v33, null, v38, v39, vcc_lo            // 0000001D99A0: D5207C21 01AA4F26
	s_waitcnt lgkmcnt(0)                                       // 0000001D99A8: BF89FC07
	s_barrier                                                  // 0000001D99AC: BFBD0000
	.long 0xd73c0026                                           // 0000001D99B0: D73C0026
	v_cndmask_b32_e32 v1, 1, v32, vcc_lo                       // 0000001D99B4: 02024081
	s_clause 0x1                                               // 0000001D99B8: BF850001
	global_load_u16 v55, v[50:51], off                         // 0000001D99BC: DC4A0000 377C0032
	global_load_u16 v56, v[50:51], off offset:1024             // 0000001D99C4: DC4A0400 387C0032
	.long 0xd7006a2e                                           // 0000001D99CC: D7006A2E
	v_cndmask_b32_e32 v1, s10, v30, vcc_lo                     // 0000001D99D0: 02023C0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D99D4: BF8700A1
	v_add_co_ci_u32_e64 v47, null, s11, v31, vcc_lo            // 0000001D99D8: D5207C2F 01AA3E0B
	.long 0xd7006a30                                           // 0000001D99E0: D7006A30
	v_cndmask_b32_e32 v1, s10, v36, vcc_lo                     // 0000001D99E4: 0202480A
	v_add_co_ci_u32_e64 v49, null, s11, v37, vcc_lo            // 0000001D99E8: D5207C31 01AA4A0B
	.long 0xd7006a34                                           // 0000001D99F0: D7006A34
	v_cndmask_b32_e32 v1, s10, v38, vcc_lo                     // 0000001D99F4: 02024C0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D99F8: BF870001
	v_add_co_ci_u32_e64 v53, null, s11, v39, vcc_lo            // 0000001D99FC: D5207C35 01AA4E0B
	s_clause 0xb                                               // 0000001D9A04: BF85000B
	global_load_u16 v64, v[44:45], off                         // 0000001D9A08: DC4A0000 407C002C
	global_load_u16 v63, v[42:43], off                         // 0000001D9A10: DC4A0000 3F7C002A
	global_load_u16 v66, v[48:49], off                         // 0000001D9A18: DC4A0000 427C0030
	global_load_u16 v65, v[46:47], off                         // 0000001D9A20: DC4A0000 417C002E
	global_load_u16 v68, v[52:53], off offset:32               // 0000001D9A28: DC4A0020 447C0034
	global_load_u16 v67, v[50:51], off offset:32               // 0000001D9A30: DC4A0020 437C0032
	global_load_u16 v70, v[44:45], off offset:32               // 0000001D9A38: DC4A0020 467C002C
	global_load_u16 v69, v[42:43], off offset:32               // 0000001D9A40: DC4A0020 457C002A
	global_load_u16 v73, v[48:49], off offset:32               // 0000001D9A48: DC4A0020 497C0030
	global_load_u16 v74, v[46:47], off offset:32               // 0000001D9A50: DC4A0020 4A7C002E
	global_load_u16 v75, v[52:53], off offset:64               // 0000001D9A58: DC4A0040 4B7C0034
	global_load_u16 v76, v[50:51], off offset:64               // 0000001D9A60: DC4A0040 4C7C0032
	.long 0xd7006a22                                           // 0000001D9A68: D7006A22
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 0000001D9A6C: 02020C0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D9A70: BF8700A1
	v_add_co_ci_u32_e64 v35, null, s13, v7, vcc_lo             // 0000001D9A74: D5207C23 01AA0E0D
	.long 0xd7006a06                                           // 0000001D9A7C: D7006A06
	v_cndmask_b32_e32 v1, s12, v14, vcc_lo                     // 0000001D9A80: 02021C0C
	v_add_co_ci_u32_e64 v7, null, s13, v15, vcc_lo             // 0000001D9A84: D5207C07 01AA1E0D
	.long 0xd7006a0e                                           // 0000001D9A8C: D7006A0E
	v_cndmask_b32_e32 v1, s12, v22, vcc_lo                     // 0000001D9A90: 02022C0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D9A94: BF8700A1
	v_add_co_ci_u32_e64 v15, null, s13, v23, vcc_lo            // 0000001D9A98: D5207C0F 01AA2E0D
	.long 0xd7006a16                                           // 0000001D9AA0: D7006A16
	v_cndmask_b32_e32 v1, s12, v30, vcc_lo                     // 0000001D9AA4: 02023C0C
	v_add_co_ci_u32_e64 v23, null, s13, v31, vcc_lo            // 0000001D9AA8: D5207C17 01AA3E0D
	ds_load_b128 v[30:33], v72 offset:13840                    // 0000001D9AB0: DBFC3610 1E000048
	ds_load_b64 v[40:41], v72 offset:13856                     // 0000001D9AB8: D9D83620 28000048
	s_clause 0x9                                               // 0000001D9AC0: BF850009
	global_load_u16 v62, v[42:43], off offset:64               // 0000001D9AC4: DC4A0040 3E7C002A
	global_load_u16 v50, v[50:51], off offset:96               // 0000001D9ACC: DC4A0060 327C0032
	global_load_u16 v71, v[44:45], off offset:64               // 0000001D9AD4: DC4A0040 477C002C
	global_load_u16 v51, v[46:47], off offset:64               // 0000001D9ADC: DC4A0040 337C002E
	global_load_u16 v44, v[44:45], off offset:96               // 0000001D9AE4: DC4A0060 2C7C002C
	global_load_u16 v42, v[42:43], off offset:96               // 0000001D9AEC: DC4A0060 2A7C002A
	global_load_u16 v72, v[48:49], off offset:64               // 0000001D9AF4: DC4A0040 487C0030
	global_load_u16 v52, v[52:53], off offset:96               // 0000001D9AFC: DC4A0060 347C0034
	global_load_u16 v43, v[48:49], off offset:96               // 0000001D9B04: DC4A0060 2B7C0030
	global_load_u16 v45, v[46:47], off offset:96               // 0000001D9B0C: DC4A0060 2D7C002E
	.long 0xd7006a24                                           // 0000001D9B14: D7006A24
	v_cndmask_b32_e32 v1, s12, v36, vcc_lo                     // 0000001D9B18: 0202480C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D9B1C: BF8700A1
	v_add_co_ci_u32_e64 v37, null, s13, v37, vcc_lo            // 0000001D9B20: D5207C25 01AA4A0D
	.long 0xd7006a26                                           // 0000001D9B28: D7006A26
	v_cndmask_b32_e32 v1, s12, v38, vcc_lo                     // 0000001D9B2C: 02024C0C
	v_add_co_ci_u32_e64 v39, null, s13, v39, vcc_lo            // 0000001D9B30: D5207C27 01AA4E0D
	s_waitcnt lgkmcnt(1)                                       // 0000001D9B38: BF89FC17
	v_mul_f32_e32 v26, v26, v32                                // 0000001D9B3C: 1034411A
	v_mul_f32_e32 v24, v24, v30                                // 0000001D9B40: 10303D18
	v_mul_f32_e32 v16, v16, v30                                // 0000001D9B44: 10203D10
	s_waitcnt lgkmcnt(0)                                       // 0000001D9B48: BF89FC07
	v_mul_f32_e32 v28, v28, v40                                // 0000001D9B4C: 1038511C
	v_dual_mul_f32 v18, v18, v32 :: v_dual_mul_f32 v29, v29, v41// 0000001D9B50: C8C64112 121C531D
	v_mul_f32_e32 v25, v25, v31                                // 0000001D9B58: 10323F19
	v_mul_f32_e32 v27, v27, v33                                // 0000001D9B5C: 1036431B
	v_mul_f32_e32 v21, v21, v41                                // 0000001D9B60: 102A5315
	v_mul_f32_e32 v17, v17, v31                                // 0000001D9B64: 10223F11
	v_dual_mul_f32 v19, v19, v33 :: v_dual_mul_f32 v8, v8, v30 // 0000001D9B68: C8C64313 13083D08
	v_mul_f32_e32 v10, v10, v32                                // 0000001D9B70: 1014410A
	v_mul_f32_e32 v2, v2, v32                                  // 0000001D9B74: 10044102
	v_mul_f32_e32 v12, v12, v40                                // 0000001D9B78: 1018510C
	v_mul_f32_e32 v0, v0, v30                                  // 0000001D9B7C: 10003D00
	v_dual_mul_f32 v4, v4, v40 :: v_dual_mul_f32 v9, v9, v31   // 0000001D9B80: C8C65104 04083F09
	v_mul_f32_e32 v11, v11, v33                                // 0000001D9B88: 1016430B
	v_mul_f32_e32 v13, v13, v41                                // 0000001D9B8C: 101A530D
	v_mul_f32_e32 v1, v1, v31                                  // 0000001D9B90: 10023F01
	v_mul_f32_e32 v3, v3, v33                                  // 0000001D9B94: 10064303
	v_mul_f32_e32 v5, v5, v41                                  // 0000001D9B98: 100A5305
	s_waitcnt vmcnt(23)                                        // 0000001D9B9C: BF895FF7
	v_lshlrev_b32_e32 v47, 16, v55                             // 0000001D9BA0: 305E6E90
	s_waitcnt vmcnt(20)                                        // 0000001D9BA4: BF8953F7
	v_lshlrev_b32_e32 v49, 16, v63                             // 0000001D9BA8: 30627E90
	s_waitcnt vmcnt(19)                                        // 0000001D9BAC: BF894FF7
	v_lshlrev_b32_e32 v53, 16, v66                             // 0000001D9BB0: 306A8490
	v_lshlrev_b32_e32 v46, 16, v56                             // 0000001D9BB4: 305C7090
	s_waitcnt vmcnt(18)                                        // 0000001D9BB8: BF894BF7
	v_lshlrev_b32_e32 v55, 16, v65                             // 0000001D9BBC: 306E8290
	s_waitcnt vmcnt(16)                                        // 0000001D9BC0: BF8943F7
	v_lshlrev_b32_e32 v63, 16, v67                             // 0000001D9BC4: 307E8690
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v47                  // 0000001D9BC8: 7C3C5EFF 42CE8ED0
	v_dual_mul_f32 v77, 0xbfb8aa3b, v53 :: v_dual_mul_f32 v20, v20, v40// 0000001D9BD0: C8C66AFF 4D145114 BFB8AA3B
	s_waitcnt vmcnt(13)                                        // 0000001D9BDC: BF8937F7
	v_dual_mul_f32 v73, 0xbfb8aa3b, v46 :: v_dual_lshlrev_b32 v66, 16, v73// 0000001D9BE0: C8E25CFF 49429290 BFB8AA3B
	v_lshlrev_b32_e32 v65, 16, v69                             // 0000001D9BEC: 30828A90
	s_waitcnt vmcnt(10)                                        // 0000001D9BF0: BF892BF7
	v_lshlrev_b32_e32 v69, 16, v76                             // 0000001D9BF4: 308A9890
	v_fma_f32 v96, 0xbfb8aa3b, v53, -v77                       // 0000001D9BF8: D6130060 85366AFF BFB8AA3B
	v_rndne_f32_e32 v97, v77                                   // 0000001D9C04: 7EC2474D
	v_rndne_f32_e32 v89, v73                                   // 0000001D9C08: 7EB24749
	v_lshlrev_b32_e32 v56, 16, v68                             // 0000001D9C0C: 30708890
	v_fma_f32 v88, 0xbfb8aa3b, v46, -v73                       // 0000001D9C10: D6130058 85265CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D9C1C: BF870214
	v_dual_mul_f32 v78, 0xbfb8aa3b, v63 :: v_dual_sub_f32 v77, v77, v97// 0000001D9C20: C8CA7EFF 4E4CC34D BFB8AA3B
	v_sub_f32_e32 v73, v73, v89                                // 0000001D9C2C: 0892B349
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001D9C30: BF8701C4
	v_mul_f32_e32 v79, 0xbfb8aa3b, v56                         // 0000001D9C34: 109E70FF BFB8AA3B
	v_dual_mul_f32 v83, 0xbfb8aa3b, v66 :: v_dual_lshlrev_b32 v48, 16, v64// 0000001D9C3C: C8E284FF 53308090 BFB8AA3B
	v_lshlrev_b32_e32 v64, 16, v70                             // 0000001D9C48: 30808C90
	v_mul_f32_e32 v70, 0xbfb8aa3b, v47                         // 0000001D9C4C: 108C5EFF BFB8AA3B
	v_dual_mul_f32 v75, 0xbfb8aa3b, v48 :: v_dual_lshlrev_b32 v68, 16, v75// 0000001D9C54: C8E260FF 4B449690 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D9C60: BF870214
	v_rndne_f32_e32 v109, v83                                  // 0000001D9C64: 7EDA4753
	v_mul_f32_e32 v81, 0xbfb8aa3b, v64                         // 0000001D9C68: 10A280FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D9C70: BF870004
	v_fma_f32 v86, 0xbfb8aa3b, v47, -v70                       // 0000001D9C74: D6130056 851A5EFF BFB8AA3B
	v_rndne_f32_e32 v87, v70                                   // 0000001D9C80: 7EAE4746
	v_fma_f32 v108, 0xbfb8aa3b, v66, -v83                      // 0000001D9C84: D613006C 854E84FF BFB8AA3B
	v_fmac_f32_e32 v96, 0xb2a5705f, v53                        // 0000001D9C90: 56C06AFF B2A5705F
	v_rndne_f32_e32 v105, v81                                  // 0000001D9C98: 7ED24751
	v_fmac_f32_e32 v86, 0xb2a5705f, v47                        // 0000001D9C9C: 56AC5EFF B2A5705F
	v_dual_sub_f32 v70, v70, v87 :: v_dual_sub_f32 v83, v83, v109// 0000001D9CA4: C94AAF46 4652DB53
	v_fma_f32 v104, 0xbfb8aa3b, v64, -v81                      // 0000001D9CAC: D6130068 854680FF BFB8AA3B
	v_dual_fmac_f32 v88, 0xb2a5705f, v46 :: v_dual_add_f32 v77, v77, v96// 0000001D9CB8: C8085CFF 584CC14D B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001D9CC4: BF870233
	v_dual_sub_f32 v81, v81, v105 :: v_dual_add_f32 v70, v70, v86// 0000001D9CC8: C948D351 5146AD46
	v_dual_mul_f32 v74, 0xbfb8aa3b, v49 :: v_dual_lshlrev_b32 v67, 16, v74// 0000001D9CD0: C8E262FF 4A429490 BFB8AA3B
	v_dual_mul_f32 v85, 0xbfb8aa3b, v68 :: v_dual_mul_f32 v80, 0xbfb8aa3b, v65// 0000001D9CDC: C8C688FF 555082FF BFB8AA3B
	v_add_f32_e32 v73, v73, v88                                // 0000001D9CE8: 0692B149
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D9CEC: BF870194
	v_exp_f32_e32 v70, v70                                     // 0000001D9CF0: 7E8C4B46
	v_fma_f32 v90, 0xbfb8aa3b, v49, -v74                       // 0000001D9CF4: D613005A 852A62FF BFB8AA3B
	v_rndne_f32_e32 v91, v74                                   // 0000001D9D00: 7EB6474A
	v_fma_f32 v100, 0xbfb8aa3b, v56, -v79                      // 0000001D9D04: D6130064 853E70FF BFB8AA3B
	v_rndne_f32_e32 v101, v79                                  // 0000001D9D10: 7ECA474F
	v_cvt_i32_f32_e32 v87, v87                                 // 0000001D9D14: 7EAE1157
	v_exp_f32_e32 v73, v73                                     // 0000001D9D18: 7E924B49
	v_mul_f32_e32 v82, 0xbfb8aa3b, v67                         // 0000001D9D1C: 10A486FF BFB8AA3B
	v_fma_f32 v92, 0xbfb8aa3b, v48, -v75                       // 0000001D9D24: D613005C 852E60FF BFB8AA3B
	v_rndne_f32_e32 v93, v75                                   // 0000001D9D30: 7EBA474B
	v_mul_f32_e32 v76, 0xbfb8aa3b, v55                         // 0000001D9D34: 10986EFF BFB8AA3B
	v_cvt_i32_f32_e32 v89, v89                                 // 0000001D9D3C: 7EB21159
	v_dual_fmac_f32 v100, 0xb2a5705f, v56 :: v_dual_sub_f32 v79, v79, v101// 0000001D9D40: C80A70FF 644ECB4F B2A5705F
	v_fmac_f32_e32 v90, 0xb2a5705f, v49                        // 0000001D9D4C: 56B462FF B2A5705F
	v_fmac_f32_e32 v104, 0xb2a5705f, v64                       // 0000001D9D54: 56D080FF B2A5705F
	v_sub_f32_e32 v74, v74, v91                                // 0000001D9D5C: 0894B74A
	v_exp_f32_e32 v77, v77                                     // 0000001D9D60: 7E9A4B4D
	.long 0xd71c0046                                           // 0000001D9D64: D71C0046
	v_cndmask_b32_e32 v1, v70, v87, vcc_lo                     // 0000001D9D68: 0202AF46
	v_sub_f32_e32 v75, v75, v93                                // 0000001D9D6C: 0896BB4B
	v_fma_f32 v94, 0xbfb8aa3b, v55, -v76                       // 0000001D9D70: D613005E 85326EFF BFB8AA3B
	v_rndne_f32_e32 v95, v76                                   // 0000001D9D7C: 7EBE474C
	v_cvt_i32_f32_e32 v97, v97                                 // 0000001D9D80: 7EC21161
	v_add_f32_e32 v79, v79, v100                               // 0000001D9D84: 069EC94F
	v_dual_add_f32 v81, v81, v104 :: v_dual_add_f32 v74, v74, v90// 0000001D9D88: C908D151 514AB54A
	.long 0xd71c0049                                           // 0000001D9D90: D71C0049
	v_cndmask_b32_e32 v1, v73, v89, vcc_lo                     // 0000001D9D94: 0202B349
	v_cndmask_b32_e32 v70, 0, v70, vcc_lo                      // 0000001D9D98: 028C8C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v46                  // 0000001D9D9C: 7C3C5CFF 42CE8ED0
	v_fmac_f32_e32 v92, 0xb2a5705f, v48                        // 0000001D9DA4: 56B860FF B2A5705F
	v_fmac_f32_e32 v108, 0xb2a5705f, v66                       // 0000001D9DAC: 56D884FF B2A5705F
	v_fmac_f32_e32 v94, 0xb2a5705f, v55                        // 0000001D9DB4: 56BC6EFF B2A5705F
	v_exp_f32_e32 v74, v74                                     // 0000001D9DBC: 7E944B4A
	v_exp_f32_e32 v81, v81                                     // 0000001D9DC0: 7EA24B51
	.long 0xd71c004d                                           // 0000001D9DC4: D71C004D
	v_cndmask_b32_e32 v1, v77, v97, vcc_lo                     // 0000001D9DC8: 0202C34D
	v_dual_sub_f32 v76, v76, v95 :: v_dual_cndmask_b32 v73, 0, v73// 0000001D9DCC: C952BF4C 4C489280
	v_dual_mul_f32 v84, 0xbfb8aa3b, v69 :: v_dual_add_f32 v75, v75, v92// 0000001D9DD4: C8C88AFF 544AB94B BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v63, -v78                       // 0000001D9DE0: D6130062 853A7EFF BFB8AA3B
	v_rndne_f32_e32 v99, v78                                   // 0000001D9DEC: 7EC6474E
	v_cvt_i32_f32_e32 v91, v91                                 // 0000001D9DF0: 7EB6115B
	v_cvt_i32_f32_e32 v105, v105                               // 0000001D9DF4: 7ED21169
	v_dual_add_f32 v83, v83, v108 :: v_dual_add_f32 v76, v76, v94// 0000001D9DF8: C908D953 534CBD4C
	v_exp_f32_e32 v75, v75                                     // 0000001D9E00: 7E964B4B
	v_cvt_i32_f32_e32 v93, v93                                 // 0000001D9E04: 7EBA115D
	v_sub_f32_e32 v78, v78, v99                                // 0000001D9E08: 089CC74E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D9E0C: BF870003
	v_exp_f32_e32 v83, v83                                     // 0000001D9E10: 7EA64B53
	v_exp_f32_e32 v76, v76                                     // 0000001D9E14: 7E984B4C
	.long 0xd71c004a                                           // 0000001D9E18: D71C004A
	v_cndmask_b32_e32 v1, v74, v91, vcc_lo                     // 0000001D9E1C: 0202B74A
	.long 0xd71c0051                                           // 0000001D9E20: D71C0051
	v_cndmask_b32_e32 v1, v81, v105, vcc_lo                    // 0000001D9E24: 0202D351
	v_fmac_f32_e32 v98, 0xb2a5705f, v63                        // 0000001D9E28: 56C47EFF B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001D9E30: 7C3C62FF 42CE8ED0
	v_fma_f32 v102, 0xbfb8aa3b, v65, -v80                      // 0000001D9E38: D6130066 854282FF BFB8AA3B
	v_rndne_f32_e32 v103, v80                                  // 0000001D9E44: 7ECE4750
	v_cvt_i32_f32_e32 v95, v95                                 // 0000001D9E48: 7EBE115F
	v_cvt_i32_f32_e32 v109, v109                               // 0000001D9E4C: 7EDA116D
	v_add_f32_e32 v78, v78, v98                                // 0000001D9E50: 069CC54E
	.long 0xd71c004b                                           // 0000001D9E54: D71C004B
	v_cndmask_b32_e32 v1, v75, v93, vcc_lo                     // 0000001D9E58: 0202BB4B
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000001D9E5C: 02949480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 0000001D9E60: 7C3C60FF 42CE8ED0
	v_sub_f32_e32 v80, v80, v103                               // 0000001D9E68: 08A0CF50
	v_exp_f32_e32 v78, v78                                     // 0000001D9E6C: 7E9C4B4E
	.long 0xd71c004c                                           // 0000001D9E70: D71C004C
	v_cndmask_b32_e32 v1, v76, v95, vcc_lo                     // 0000001D9E74: 0202BF4C
	.long 0xd71c0053                                           // 0000001D9E78: D71C0053
	v_cndmask_b32_e32 v1, v83, v109, vcc_lo                    // 0000001D9E7C: 0202DB53
	v_dual_fmac_f32 v102, 0xb2a5705f, v65 :: v_dual_cndmask_b32 v75, 0, v75// 0000001D9E80: C81282FF 664A9680 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v55                  // 0000001D9E8C: 7C3C6EFF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v67, -v82                      // 0000001D9E94: D613006A 854A86FF BFB8AA3B
	v_rndne_f32_e32 v107, v82                                  // 0000001D9EA0: 7ED64752
	v_cvt_i32_f32_e32 v99, v99                                 // 0000001D9EA4: 7EC61163
	v_add_f32_e32 v80, v80, v102                               // 0000001D9EA8: 06A0CD50
	v_exp_f32_e32 v79, v79                                     // 0000001D9EAC: 7E9E4B4F
	v_cndmask_b32_e32 v76, 0, v76, vcc_lo                      // 0000001D9EB0: 02989880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v53                  // 0000001D9EB4: 7C3C6AFF 42CE8ED0
	v_cvt_i32_f32_e32 v101, v101                               // 0000001D9EBC: 7ECA1165
	v_fmac_f32_e32 v106, 0xb2a5705f, v67                       // 0000001D9EC0: 56D486FF B2A5705F
	v_sub_f32_e32 v82, v82, v107                               // 0000001D9EC8: 08A4D752
	v_exp_f32_e32 v80, v80                                     // 0000001D9ECC: 7EA04B50
	.long 0xd71c004e                                           // 0000001D9ED0: D71C004E
	v_cndmask_b32_e32 v1, v78, v99, vcc_lo                     // 0000001D9ED4: 0202C74E
	v_cndmask_b32_e32 v77, 0, v77, vcc_lo                      // 0000001D9ED8: 029A9A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v63                  // 0000001D9EDC: 7C3C7EFF 42CE8ED0
	v_cvt_i32_f32_e32 v103, v103                               // 0000001D9EE4: 7ECE1167
	v_add_f32_e32 v82, v82, v106                               // 0000001D9EE8: 06A4D552
	.long 0xd71c004f                                           // 0000001D9EEC: D71C004F
	v_cndmask_b32_e32 v1, v79, v101, vcc_lo                    // 0000001D9EF0: 0202CB4F
	v_cvt_i32_f32_e32 v107, v107                               // 0000001D9EF4: 7ED6116B
	v_cndmask_b32_e32 v78, 0, v78, vcc_lo                      // 0000001D9EF8: 029C9C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 0000001D9EFC: 7C3C70FF 42CE8ED0
	v_exp_f32_e32 v82, v82                                     // 0000001D9F04: 7EA44B52
	.long 0xd71c0050                                           // 0000001D9F08: D71C0050
	v_cndmask_b32_e32 v1, v80, v103, vcc_lo                    // 0000001D9F0C: 0202CF50
	v_rndne_f32_e32 v111, v84                                  // 0000001D9F10: 7EDE4754
	v_fma_f32 v110, 0xbfb8aa3b, v69, -v84                      // 0000001D9F14: D613006E 85528AFF BFB8AA3B
	v_cndmask_b32_e32 v79, 0, v79, vcc_lo                      // 0000001D9F20: 029E9E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000001D9F24: 7C3C82FF 42CE8ED0
	v_fma_f32 v112, 0xbfb8aa3b, v68, -v85                      // 0000001D9F2C: D6130070 855688FF BFB8AA3B
	v_rndne_f32_e32 v113, v85                                  // 0000001D9F38: 7EE24755
	s_waitcnt vmcnt(1)                                         // 0000001D9F3C: BF8907F7
	v_lshlrev_b32_e32 v32, 16, v43                             // 0000001D9F40: 30405690
	v_cndmask_b32_e32 v80, 0, v80, vcc_lo                      // 0000001D9F44: 02A0A080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 0000001D9F48: 7C3C80FF 42CE8ED0
	.long 0xd71c0052                                           // 0000001D9F50: D71C0052
	v_cndmask_b32_e32 v1, v82, v107, vcc_lo                    // 0000001D9F54: 0202D752
	v_dual_fmac_f32 v112, 0xb2a5705f, v68 :: v_dual_cndmask_b32 v81, 0, v81// 0000001D9F58: C81288FF 7050A280 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v67                  // 0000001D9F64: 7C3C86FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D9F6C: BF870003
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000001D9F70: 02A4A480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v66                  // 0000001D9F74: 7C3C84FF 42CE8ED0
	v_cndmask_b32_e32 v83, 0, v83, vcc_lo                      // 0000001D9F7C: 02A6A680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v47                  // 0000001D9F80: 7C365EFF C2B17218
	v_cndmask_b32_e32 v47, 0x7f800000, v70, vcc_lo             // 0000001D9F88: 025E8CFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v46                  // 0000001D9F90: 7C365CFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D9F98: BF870122
	v_dual_add_f32 v47, 1.0, v47 :: v_dual_cndmask_b32 v46, 0x7f800000, v73// 0000001D9F9C: C9125EF2 2F2E92FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001D9FA8: 7C3662FF C2B17218
	v_div_scale_f32 v70, null, v47, v47, v24                   // 0000001D9FB0: D6FC7C46 04625F2F
	v_cndmask_b32_e32 v49, 0x7f800000, v74, vcc_lo             // 0000001D9FB8: 026294FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 0000001D9FC0: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D9FC8: BF870113
	v_rcp_f32_e32 v98, v70                                     // 0000001D9FCC: 7EC45546
	v_dual_add_f32 v49, 1.0, v49 :: v_dual_cndmask_b32 v48, 0x7f800000, v75// 0000001D9FD0: C91262F2 313096FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v55                  // 0000001D9FDC: 7C366EFF C2B17218
	v_cndmask_b32_e32 v55, 0x7f800000, v76, vcc_lo             // 0000001D9FE4: 026E98FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v53                  // 0000001D9FEC: 7C366AFF C2B17218
	v_sub_f32_e32 v84, v84, v111                               // 0000001D9FF4: 08A8DF54
	v_fmac_f32_e32 v110, 0xb2a5705f, v69                       // 0000001D9FF8: 56DC8AFF B2A5705F
	v_div_scale_f32 v76, null, v49, v49, v26                   // 0000001DA000: D6FC7C4C 046A6331
	v_add_f32_e32 v55, 1.0, v55                                // 0000001DA008: 066E6EF2
	v_cndmask_b32_e32 v53, 0x7f800000, v77, vcc_lo             // 0000001DA00C: 026A9AFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v63                  // 0000001DA014: 7C367EFF C2B17218
	v_div_scale_f32 v77, s1, v26, v49, v26                     // 0000001DA01C: D6FC014D 046A631A
	v_rcp_f32_e32 v100, v76                                    // 0000001DA024: 7EC8554C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001DA028: BF870133
	v_add_f32_e32 v53, 1.0, v53                                // 0000001DA02C: 066A6AF2
	v_cndmask_b32_e32 v63, 0x7f800000, v78, vcc_lo             // 0000001DA030: 027E9CFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 0000001DA038: 7C3670FF C2B17218
	v_add_f32_e32 v63, 1.0, v63                                // 0000001DA040: 067E7EF2
	v_cndmask_b32_e32 v56, 0x7f800000, v79, vcc_lo             // 0000001DA044: 02709EFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000001DA04C: 7C3682FF C2B17218
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DA054: BF870215
	v_fma_f32 v115, -v76, v100, 1.0                            // 0000001DA058: D6130073 23CAC94C
	v_div_scale_f32 v86, null, v63, v63, v16                   // 0000001DA060: D6FC7C56 04427F3F
	v_div_scale_f32 v87, s5, v16, v63, v16                     // 0000001DA068: D6FC0557 04427F10
	v_cndmask_b32_e32 v65, 0x7f800000, v80, vcc_lo             // 0000001DA070: 0282A0FF 7F800000
	v_div_scale_f32 v80, null, v55, v55, v28                   // 0000001DA078: D6FC7C50 04726F37
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 0000001DA080: 7C3680FF C2B17218
	v_rcp_f32_e32 v104, v86                                    // 0000001DA088: 7ED05556
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DA08C: BF870193
	v_dual_fmac_f32 v100, v115, v100 :: v_dual_add_f32 v65, 1.0, v65// 0000001DA090: C808C973 644082F2
	v_rcp_f32_e32 v102, v80                                    // 0000001DA098: 7ECC5550
	v_cndmask_b32_e32 v64, 0x7f800000, v81, vcc_lo             // 0000001DA09C: 0280A2FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v67                  // 0000001DA0A4: 7C3686FF C2B17218
	v_div_scale_f32 v81, s3, v28, v55, v28                     // 0000001DA0AC: D6FC0351 04726F1C
	v_mul_f32_e32 v115, v77, v100                              // 0000001DA0B4: 10E6C94D
	v_div_scale_f32 v90, null, v65, v65, v18                   // 0000001DA0B8: D6FC7C5A 044A8341
	v_div_scale_f32 v91, s7, v18, v65, v18                     // 0000001DA0C0: D6FC075B 044A8312
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001DA0C8: BF870256
	v_fma_f32 v119, -v86, v104, 1.0                            // 0000001DA0CC: D6130077 23CAD156
	v_cndmask_b32_e32 v67, 0x7f800000, v82, vcc_lo             // 0000001DA0D4: 0286A4FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v66                  // 0000001DA0DC: 7C3684FF C2B17218
	v_fma_f32 v117, -v80, v102, 1.0                            // 0000001DA0E4: D6130075 23CACD50
	v_div_scale_f32 v82, null, v53, v53, v29                   // 0000001DA0EC: D6FC7C52 04766B35
	v_dual_fmac_f32 v104, v119, v104 :: v_dual_add_f32 v67, 1.0, v67// 0000001DA0F4: C808D177 684286F2
	v_fma_f32 v126, -v76, v115, v77                            // 0000001DA0FC: D613007E 2536E74C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DA104: BF870194
	v_fmac_f32_e32 v102, v117, v102                            // 0000001DA108: 56CCCD75
	v_dual_cndmask_b32 v66, 0x7f800000, v83 :: v_dual_mul_f32 v119, v87, v104// 0000001DA10C: CA46A6FF 4276D157 7F800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001DA118: BF8701A4
	v_div_scale_f32 v94, null, v67, v67, v20                   // 0000001DA11C: D6FC7C5E 04528743
	v_rcp_f32_e32 v103, v82                                    // 0000001DA124: 7ECE5552
	v_mul_f32_e32 v117, v81, v102                              // 0000001DA128: 10EACD51
	v_fmac_f32_e32 v115, v126, v100                            // 0000001DA12C: 56E6C97E
	v_fma_f32 v130, -v86, v119, v87                            // 0000001DA130: D6130082 255EEF56
	v_add_f32_e32 v46, 1.0, v46                                // 0000001DA138: 065C5CF2
	v_add_f32_e32 v66, 1.0, v66                                // 0000001DA13C: 068484F2
	v_fma_f32 v128, -v80, v117, v81                            // 0000001DA140: D6130080 2546EB50
	v_add_f32_e32 v48, 1.0, v48                                // 0000001DA148: 066060F2
	v_fmac_f32_e32 v119, v130, v104                            // 0000001DA14C: 56EED182
	v_div_scale_f32 v74, null, v46, v46, v25                   // 0000001DA150: D6FC7C4A 04665D2E
	v_rcp_f32_e32 v108, v94                                    // 0000001DA158: 7ED8555E
	v_fmac_f32_e32 v117, v128, v102                            // 0000001DA15C: 56EACD80
	v_div_scale_f32 v78, null, v48, v48, v27                   // 0000001DA160: D6FC7C4E 046E6130
	v_div_scale_f32 v96, null, v66, v66, v21                   // 0000001DA168: D6FC7C60 04568542
	v_rcp_f32_e32 v99, v74                                     // 0000001DA170: 7EC6554A
	v_fma_f32 v118, -v82, v103, 1.0                            // 0000001DA174: D6130076 23CACF52
	v_add_f32_e32 v84, v84, v110                               // 0000001DA17C: 06A8DD54
	v_rcp_f32_e32 v101, v78                                    // 0000001DA180: 7ECA554E
	v_rcp_f32_e32 v109, v96                                    // 0000001DA184: 7EDA5560
	v_fma_f32 v110, -v70, v98, 1.0                             // 0000001DA188: D613006E 23CAC546
	v_fma_f32 v123, -v94, v108, 1.0                            // 0000001DA190: D613007B 23CAD95E
	v_div_scale_f32 v73, vcc_lo, v24, v47, v24                 // 0000001DA198: D6FC6A49 04625F18
	v_div_scale_f32 v75, s0, v25, v46, v25                     // 0000001DA1A0: D6FC004B 04665D19
	v_div_scale_f32 v95, s9, v20, v67, v20                     // 0000001DA1A8: D6FC095F 04528714
	v_fma_f32 v114, -v74, v99, 1.0                             // 0000001DA1B0: D6130072 23CAC74A
	v_fmac_f32_e32 v98, v110, v98                              // 0000001DA1B8: 56C4C56E
	v_fmac_f32_e32 v108, v123, v108                            // 0000001DA1BC: 56D8D97B
	v_fma_f32 v116, -v78, v101, 1.0                            // 0000001DA1C0: D6130074 23CACB4E
	v_fma_f32 v124, -v96, v109, 1.0                            // 0000001DA1C8: D613007C 23CADB60
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001DA1D0: BF8701C4
	v_dual_fmac_f32 v99, v114, v99 :: v_dual_mul_f32 v110, v73, v98// 0000001DA1D4: C806C772 636EC549
	v_rcp_f32_e32 v106, v90                                    // 0000001DA1DC: 7ED4555A
	v_mul_f32_e32 v123, v95, v108                              // 0000001DA1E0: 10F6D95F
	v_div_scale_f32 v79, s2, v27, v48, v27                     // 0000001DA1E4: D6FC024F 046E611B
	v_dual_mul_f32 v114, v75, v99 :: v_dual_fmac_f32 v101, v116, v101// 0000001DA1EC: C8C0C74B 7264CB74
	v_fmac_f32_e32 v109, v124, v109                            // 0000001DA1F4: 56DADB7C
	v_fma_f32 v124, -v70, v110, v73                            // 0000001DA1F8: D613007C 2526DD46
	v_div_scale_f32 v83, s4, v29, v53, v29                     // 0000001DA200: D6FC0453 04766B1D
	v_fmac_f32_e32 v103, v118, v103                            // 0000001DA208: 56CECF76
	v_fma_f32 v125, -v74, v114, v75                            // 0000001DA20C: D613007D 252EE54A
	v_mul_f32_e32 v116, v79, v101                              // 0000001DA214: 10E8CB4F
	v_fmac_f32_e32 v110, v124, v98                             // 0000001DA218: 56DCC57C
	v_fma_f32 v121, -v90, v106, 1.0                            // 0000001DA21C: D6130079 23CAD55A
	v_mul_f32_e32 v118, v83, v103                              // 0000001DA224: 10ECCF53
	v_fmac_f32_e32 v114, v125, v99                             // 0000001DA228: 56E4C77D
	v_fma_f32 v127, -v78, v116, v79                            // 0000001DA22C: D613007F 253EE94E
	v_fma_f32 v70, -v70, v110, v73                             // 0000001DA234: D6130046 2526DD46
	v_fmac_f32_e32 v106, v121, v106                            // 0000001DA23C: 56D4D579
	v_fma_f32 v129, -v82, v118, v83                            // 0000001DA240: D6130081 254EED52
	v_fma_f32 v73, -v74, v114, v75                             // 0000001DA248: D6130049 252EE54A
	v_fmac_f32_e32 v116, v127, v101                            // 0000001DA250: 56E8CB7F
	v_div_fmas_f32 v70, v70, v98, v110                         // 0000001DA254: D6370046 05BAC546
	s_mov_b32 vcc_lo, s0                                       // 0000001DA25C: BEEA0000
	v_fma_f32 v74, -v76, v115, v77                             // 0000001DA260: D613004A 2536E74C
	v_dual_mul_f32 v121, v91, v106 :: v_dual_fmac_f32 v118, v129, v103// 0000001DA268: C8C0D55B 7976CF81
	v_div_fmas_f32 v73, v73, v99, v114                         // 0000001DA270: D6370049 05CAC749
	v_fma_f32 v75, -v78, v116, v79                             // 0000001DA278: D613004B 253EE94E
	s_mov_b32 vcc_lo, s1                                       // 0000001DA280: BEEA0001
	v_fma_f32 v76, -v80, v117, v81                             // 0000001DA284: D613004C 2546EB50
	v_div_fmas_f32 v74, v74, v100, v115                        // 0000001DA28C: D637004A 05CEC94A
	s_mov_b32 vcc_lo, s2                                       // 0000001DA294: BEEA0002
	v_fma_f32 v132, -v90, v121, v91                            // 0000001DA298: D6130084 256EF35A
	v_add_f32_e32 v56, 1.0, v56                                // 0000001DA2A0: 067070F2
	v_fma_f32 v77, -v82, v118, v83                             // 0000001DA2A4: D613004D 254EED52
	v_div_fixup_f32 v25, v73, v46, v25                         // 0000001DA2AC: D6270019 04665D49
	v_div_fixup_f32 v24, v70, v47, v24                         // 0000001DA2B4: D6270018 04625F46
	v_div_fmas_f32 v47, v75, v101, v116                        // 0000001DA2BC: D637002F 05D2CB4B
	s_mov_b32 vcc_lo, s3                                       // 0000001DA2C4: BEEA0003
	v_fmac_f32_e32 v121, v132, v106                            // 0000001DA2C8: 56F2D584
	v_div_fmas_f32 v46, v76, v102, v117                        // 0000001DA2CC: D637002E 05D6CD4C
	s_mov_b32 vcc_lo, s4                                       // 0000001DA2D4: BEEA0004
	v_div_scale_f32 v88, null, v56, v56, v17                   // 0000001DA2D8: D6FC7C58 04467138
	v_div_fixup_f32 v26, v74, v49, v26                         // 0000001DA2E0: D627001A 046A634A
	v_div_fmas_f32 v49, v77, v103, v118                        // 0000001DA2E8: D6370031 05DACF4D
	.long 0x7e6c3999                                           // 0000001DA2F0: 7E6C3999
	v_add_f32_e32 v64, 1.0, v64                                // 0000001DA2F4: 068080F2
	v_rcp_f32_e32 v105, v88                                    // 0000001DA2F8: 7ED25558
	v_div_scale_f32 v89, s6, v17, v56, v17                     // 0000001DA2FC: D6FC0659 04467111
	v_div_fixup_f32 v29, v49, v53, v29                         // 0000001DA304: D627001D 04766B31
	v_and_b32_e32 v53, 1, v54                                  // 0000001DA30C: 366A6C81
	v_div_scale_f32 v92, null, v64, v64, v19                   // 0000001DA310: D6FC7C5C 044E8140
	v_div_scale_f32 v93, s8, v19, v64, v19                     // 0000001DA318: D6FC085D 044E8113
	v_fma_f32 v78, -v86, v119, v87                             // 0000001DA320: D613004E 255EEF56
	v_div_fixup_f32 v27, v47, v48, v27                         // 0000001DA328: D627001B 046E612F
	s_mov_b32 vcc_lo, s5                                       // 0000001DA330: BEEA0005
	v_rcp_f32_e32 v107, v92                                    // 0000001DA334: 7ED6555C
	v_fma_f32 v120, -v88, v105, 1.0                            // 0000001DA338: D6130078 23CAD358
	v_fma_f32 v80, -v90, v121, v91                             // 0000001DA340: D6130050 256EF35A
	v_div_fmas_f32 v47, v78, v104, v119                        // 0000001DA348: D637002F 05DED14E
	s_mov_b32 vcc_lo, s6                                       // 0000001DA350: BEEA0006
	.long 0x7e7a3998                                           // 0000001DA354: 7E7A3998
	v_fmac_f32_e32 v105, v120, v105                            // 0000001DA358: 56D2D378
	v_div_fixup_f32 v28, v46, v55, v28                         // 0000001DA35C: D627001C 04726F2E
	.long 0x7e6c399b                                           // 0000001DA364: 7E6C399B
	v_div_fixup_f32 v16, v47, v63, v16                         // 0000001DA368: D6270010 04427F2F
	v_fma_f32 v122, -v92, v107, 1.0                            // 0000001DA370: D613007A 23CAD75C
	v_mul_f32_e32 v120, v89, v105                              // 0000001DA378: 10F0D359
	v_and_b32_e32 v48, 1, v61                                  // 0000001DA37C: 36607A81
	.long 0x7e78399a                                           // 0000001DA380: 7E78399A
	.long 0x7e76399c                                           // 0000001DA384: 7E76399C
	v_fmac_f32_e32 v107, v122, v107                            // 0000001DA388: 56D6D77A
	v_fma_f32 v131, -v88, v120, v89                            // 0000001DA38C: D6130083 2566F158
	v_add3_u32 v24, v24, v48, 0x7fff                           // 0000001DA394: D6550018 03FE6118 00007FFF
	.long 0x7e743990                                           // 0000001DA3A0: 7E743990
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DA3A4: BF870214
	v_dual_mul_f32 v122, v93, v107 :: v_dual_and_b32 v55, 1, v60// 0000001DA3A8: C8E4D75D 7A367881
	v_fmac_f32_e32 v120, v131, v105                            // 0000001DA3B0: 56F0D383
	v_add3_u32 v25, v25, v53, 0x7fff                           // 0000001DA3B4: D6550019 03FE6B19 00007FFF
	v_and_b32_e32 v48, 1, v59                                  // 0000001DA3C0: 36607681
	s_clause 0x1                                               // 0000001DA3C4: BF850001
	global_store_d16_hi_b16 v[34:35], v24, off                 // 0000001DA3C8: DC960000 007C1822
	global_store_d16_hi_b16 v[34:35], v25, off offset:1024     // 0000001DA3D0: DC960400 007C1922
	v_fma_f32 v133, -v92, v122, v93                            // 0000001DA3D8: D6130085 2576F55C
	v_fma_f32 v79, -v88, v120, v89                             // 0000001DA3E0: D613004F 2566F158
	v_and_b32_e32 v24, 1, v58                                  // 0000001DA3E8: 36307481
	v_add3_u32 v26, v26, v55, 0x7fff                           // 0000001DA3EC: D655001A 03FE6F1A 00007FFF
	v_add3_u32 v28, v28, v48, 0x7fff                           // 0000001DA3F8: D655001C 03FE611C 00007FFF
	v_fmac_f32_e32 v122, v133, v107                            // 0000001DA404: 56F4D785
	v_div_fmas_f32 v46, v79, v105, v120                        // 0000001DA408: D637002E 05E2D34F
	s_mov_b32 vcc_lo, s7                                       // 0000001DA410: BEEA0007
	v_exp_f32_e32 v84, v84                                     // 0000001DA414: 7EA84B54
	v_div_fmas_f32 v49, v80, v106, v121                        // 0000001DA418: D6370031 05E6D550
	v_fma_f32 v81, -v92, v122, v93                             // 0000001DA420: D6130051 2576F55C
	s_mov_b32 vcc_lo, s8                                       // 0000001DA428: BEEA0008
	v_div_fixup_f32 v17, v46, v56, v17                         // 0000001DA42C: D6270011 0446712E
	v_and_b32_e32 v46, 1, v54                                  // 0000001DA434: 365C6C81
	.long 0x7e6c399d                                           // 0000001DA438: 7E6C399D
	v_div_fmas_f32 v47, v81, v107, v122                        // 0000001DA43C: D637002F 05EAD751
	v_add3_u32 v16, v16, v24, 0x7fff                           // 0000001DA444: D6550010 03FE3110 00007FFF
	v_div_scale_f32 v97, s10, v21, v66, v21                    // 0000001DA450: D6FC0A61 04568515
	v_add3_u32 v25, v27, v46, 0x7fff                           // 0000001DA458: D6550019 03FE5D1B 00007FFF
	v_cvt_i32_f32_e32 v24, v111                                // 0000001DA464: 7E30116F
	v_div_fixup_f32 v19, v47, v64, v19                         // 0000001DA468: D6270013 044E812F
	v_and_b32_e32 v47, 1, v54                                  // 0000001DA470: 365E6C81
	.long 0x7e6c3991                                           // 0000001DA474: 7E6C3991
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v69                  // 0000001DA478: 7C3C8AFF 42CE8ED0
	.long 0xd71c0018                                           // 0000001DA480: D71C0018
	v_cndmask_b32_e32 v1, v84, v24, vcc_lo                     // 0000001DA484: 02023154
	v_div_fixup_f32 v18, v49, v65, v18                         // 0000001DA488: D6270012 044A8331
	v_add3_u32 v29, v29, v47, 0x7fff                           // 0000001DA490: D655001D 03FE5F1D 00007FFF
	v_and_b32_e32 v27, 1, v54                                  // 0000001DA49C: 36366C81
	.long 0x7e6c3993                                           // 0000001DA4A0: 7E6C3993
	v_cndmask_b32_e32 v24, 0, v24, vcc_lo                      // 0000001DA4A4: 02303080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v69                  // 0000001DA4A8: 7C368AFF C2B17218
	.long 0x7e723992                                           // 0000001DA4B0: 7E723992
	v_add3_u32 v17, v17, v27, 0x7fff                           // 0000001DA4B4: D6550011 03FE3711 00007FFF
	s_clause 0x5                                               // 0000001DA4C0: BF850005
	global_store_d16_hi_b16 v[6:7], v26, off                   // 0000001DA4C4: DC960000 007C1A06
	global_store_d16_hi_b16 v[14:15], v25, off                 // 0000001DA4CC: DC960000 007C190E
	global_store_d16_hi_b16 v[22:23], v28, off                 // 0000001DA4D4: DC960000 007C1C16
	global_store_d16_hi_b16 v[36:37], v29, off                 // 0000001DA4DC: DC960000 007C1D24
	global_store_d16_hi_b16 v[34:35], v16, off offset:32       // 0000001DA4E4: DC960020 007C1022
	global_store_d16_hi_b16 v[38:39], v17, off offset:32       // 0000001DA4EC: DC960020 007C1126
	v_sub_f32_e32 v16, v85, v113                               // 0000001DA4F4: 0820E355
	v_fma_f32 v25, -v94, v123, v95                             // 0000001DA4F8: D6130019 257EF75E
	v_dual_mul_f32 v26, v97, v109 :: v_dual_and_b32 v17, 1, v54// 0000001DA500: C8E4DB61 1A106C81
	v_cndmask_b32_e32 v24, 0x7f800000, v24, vcc_lo             // 0000001DA508: 023030FF 7F800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DA510: BF870214
	v_add_f32_e32 v16, v16, v112                               // 0000001DA514: 0620E110
	v_fmac_f32_e32 v123, v25, v108                             // 0000001DA518: 56F6D919
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001DA51C: BF870004
	v_fma_f32 v25, -v96, v26, v97                              // 0000001DA520: D6130019 25863560
	s_mov_b32 vcc_lo, s9                                       // 0000001DA528: BEEA0009
	v_add_f32_e32 v24, 1.0, v24                                // 0000001DA52C: 063030F2
	v_exp_f32_e32 v16, v16                                     // 0000001DA530: 7E204B10
	v_fma_f32 v28, -v94, v123, v95                             // 0000001DA534: D613001C 257EF75E
	v_fmac_f32_e32 v26, v25, v109                              // 0000001DA53C: 5634DB19
	v_cvt_i32_f32_e32 v25, v113                                // 0000001DA540: 7E321171
	v_and_b32_e32 v27, 1, v57                                  // 0000001DA544: 36367281
	v_add3_u32 v17, v19, v17, 0x7fff                           // 0000001DA548: D6550011 03FE2313 00007FFF
	v_div_fmas_f32 v28, v28, v108, v123                        // 0000001DA554: D637001C 05EED91C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v68                  // 0000001DA55C: 7C3C88FF 42CE8ED0
	v_lshlrev_b32_e32 v49, 16, v71                             // 0000001DA564: 30628E90
	v_add3_u32 v18, v18, v27, 0x7fff                           // 0000001DA568: D6550012 03FE3712 00007FFF
	.long 0xd71c0010                                           // 0000001DA574: D71C0010
	v_cndmask_b32_e32 v1, v16, v25, vcc_lo                     // 0000001DA578: 02023310
	v_fma_f32 v25, -v96, v26, v97                              // 0000001DA57C: D6130019 25863560
	v_div_fixup_f32 v20, v28, v67, v20                         // 0000001DA584: D6270014 0452871C
	v_mul_f32_e32 v56, 0xbfb8aa3b, v49                         // 0000001DA58C: 107062FF BFB8AA3B
	.long 0x7f3839b6                                           // 0000001DA594: 7F3839B6
	v_cndmask_b32_e32 v16, 0, v16, vcc_lo                      // 0000001DA598: 02202080
	s_mov_b32 vcc_lo, s10                                      // 0000001DA59C: BEEA000A
	.long 0x7e383994                                           // 0000001DA5A0: 7E383994
	v_div_fmas_f32 v25, v25, v109, v26                         // 0000001DA5A4: D6370019 046ADB19
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v68                  // 0000001DA5AC: 7C3688FF C2B17218
	v_div_scale_f32 v26, null, v24, v24, v8                    // 0000001DA5B4: D6FC7C1A 04223118
	v_fma_f32 v59, 0xbfb8aa3b, v49, -v56                       // 0000001DA5BC: D613003B 84E262FF BFB8AA3B
	v_rndne_f32_e32 v60, v56                                   // 0000001DA5C8: 7E784738
	v_div_fixup_f32 v19, v25, v66, v21                         // 0000001DA5CC: D6270013 04568519
	v_cndmask_b32_e32 v16, 0x7f800000, v16, vcc_lo             // 0000001DA5D4: 022020FF 7F800000
	v_rcp_f32_e32 v21, v26                                     // 0000001DA5DC: 7E2A551A
	v_lshlrev_b32_e32 v25, 16, v62                             // 0000001DA5E0: 30327C90
	v_fmac_f32_e32 v59, 0xb2a5705f, v49                        // 0000001DA5E4: 567662FF B2A5705F
	.long 0x7e6c3993                                           // 0000001DA5EC: 7E6C3993
	v_add_f32_e32 v16, 1.0, v16                                // 0000001DA5F0: 062020F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001DA5F4: BF870224
	v_dual_sub_f32 v56, v56, v60 :: v_dual_mul_f32 v29, 0xbfb8aa3b, v25// 0000001DA5F8: C9467938 381C32FF BFB8AA3B
	.long 0xd41e0001                                           // 0000001DA604: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001DA608: 020232FF 42CE8ED0
	v_and_b32_e32 v48, 1, v54                                  // 0000001DA610: 36606C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001DA614: BF870294
	v_div_scale_f32 v27, null, v16, v16, v9                    // 0000001DA618: D6FC7C1B 04262110
	v_fma_f32 v46, -v26, v21, 1.0                              // 0000001DA620: D613002E 23CA2B1A
	v_fma_f32 v53, 0xbfb8aa3b, v25, -v29                       // 0000001DA628: D6130035 847632FF BFB8AA3B
	v_rndne_f32_e32 v55, v29                                   // 0000001DA634: 7E6E471D
	v_add_f32_e32 v56, v56, v59                                // 0000001DA638: 06707738
	v_rcp_f32_e32 v47, v27                                     // 0000001DA63C: 7E5E551B
	v_fmac_f32_e32 v21, v46, v21                               // 0000001DA640: 562A2B2E
	v_div_scale_f32 v46, vcc_lo, v8, v24, v8                   // 0000001DA644: D6FC6A2E 04223108
	v_fmac_f32_e32 v53, 0xb2a5705f, v25                        // 0000001DA64C: 566A32FF B2A5705F
	v_sub_f32_e32 v29, v29, v55                                // 0000001DA654: 083A6F1D
	v_cvt_i32_f32_e32 v55, v55                                 // 0000001DA658: 7E6E1137
	v_add3_u32 v19, v19, v48, 0x7fff                           // 0000001DA65C: D6550013 03FE6113 00007FFF
	v_mul_f32_e32 v58, v46, v21                                // 0000001DA668: 10742B2E
	v_exp_f32_e32 v48, v56                                     // 0000001DA66C: 7E604B38
	v_add_f32_e32 v29, v29, v53                                // 0000001DA670: 063A6B1D
	v_fma_f32 v57, -v27, v47, 1.0                              // 0000001DA674: D6130039 23CA5F1B
	v_div_scale_f32 v53, s0, v9, v16, v9                       // 0000001DA67C: D6FC0035 04262109
	v_and_b32_e32 v28, 1, v28                                  // 0000001DA684: 36383881
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DA688: BF870194
	v_exp_f32_e32 v29, v29                                     // 0000001DA68C: 7E3A4B1D
	v_fmac_f32_e32 v47, v57, v47                               // 0000001DA690: 565E5F39
	v_fma_f32 v57, -v26, v58, v46                              // 0000001DA694: D6130039 24BA751A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001DA69C: BF870003
	v_add3_u32 v20, v20, v28, 0x7fff                           // 0000001DA6A0: D6550014 03FE3914 00007FFF
	s_clause 0x3                                               // 0000001DA6AC: BF850003
	global_store_d16_hi_b16 v[6:7], v18, off offset:32         // 0000001DA6B0: DC960020 007C1206
	global_store_d16_hi_b16 v[14:15], v17, off offset:32       // 0000001DA6B8: DC960020 007C110E
	global_store_d16_hi_b16 v[22:23], v20, off offset:32       // 0000001DA6C0: DC960020 007C1416
	global_store_d16_hi_b16 v[36:37], v19, off offset:32       // 0000001DA6C8: DC960020 007C1324
	v_fmac_f32_e32 v58, v57, v21                               // 0000001DA6D0: 56742B39
	v_mul_f32_e32 v61, v53, v47                                // 0000001DA6D4: 107A5F35
	.long 0xd71c001d                                           // 0000001DA6D8: D71C001D
	v_cndmask_b32_e32 v1, v29, v55, vcc_lo                     // 0000001DA6DC: 02026F1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DA6E0: BF870193
	v_fma_f32 v26, -v26, v58, v46                              // 0000001DA6E4: D613001A 24BA751A
	v_fma_f32 v57, -v27, v61, v53                              // 0000001DA6EC: D6130039 24D67B1B
	v_cvt_i32_f32_e32 v46, v60                                 // 0000001DA6F4: 7E5C113C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DA6F8: BF870214
	v_cndmask_b32_e64 v29, 0, v29, s1                          // 0000001DA6FC: D501001D 00063A80
	v_div_fmas_f32 v21, v26, v21, v58                          // 0000001DA704: D6370015 04EA2B1A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001DA70C: 7C3632FF C2B17218
	v_fmac_f32_e32 v61, v57, v47                               // 0000001DA714: 567A5F39
	.long 0xd71c001a                                           // 0000001DA718: D71C001A
	v_cndmask_b32_e32 v1, v48, v46, vcc_lo                     // 0000001DA71C: 02025D30
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001DA720: BF870004
	v_div_fixup_f32 v8, v21, v24, v8                           // 0000001DA724: D6270008 04223115
	v_cndmask_b32_e32 v25, 0x7f800000, v29, vcc_lo             // 0000001DA72C: 02323AFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001DA734: 7C3C62FF 42CE8ED0
	v_fma_f32 v27, -v27, v61, v53                              // 0000001DA73C: D613001B 24D67B1B
	v_lshlrev_b32_e32 v29, 16, v51                             // 0000001DA744: 303A6690
	.long 0x7e303988                                           // 0000001DA748: 7E303988
	v_dual_add_f32 v25, 1.0, v25 :: v_dual_cndmask_b32 v26, 0, v26// 0000001DA74C: C91232F2 191A3480
	s_mov_b32 vcc_lo, s0                                       // 0000001DA754: BEEA0000
	.long 0x7f3039b6                                           // 0000001DA758: 7F3039B6
	v_div_fmas_f32 v27, v27, v47, v61                          // 0000001DA75C: D637001B 04F65F1B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001DA764: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DA76C: BF870193
	v_dual_mul_f32 v47, 0xbfb8aa3b, v29 :: v_dual_and_b32 v24, 1, v24// 0000001DA770: C8E43AFF 2F183081 BFB8AA3B
	v_div_fixup_f32 v9, v27, v16, v9                           // 0000001DA77C: D6270009 0426211B
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 0000001DA784: 023434FF 7F800000
	v_div_scale_f32 v16, null, v25, v25, v10                   // 0000001DA78C: D6FC7C10 042A3319
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001DA794: BF870004
	v_fma_f32 v18, 0xbfb8aa3b, v29, -v47                       // 0000001DA798: D6130012 84BE3AFF BFB8AA3B
	v_rndne_f32_e32 v19, v47                                   // 0000001DA7A4: 7E26472F
	.long 0x7e6c3989                                           // 0000001DA7A8: 7E6C3989
	v_add_f32_e32 v21, 1.0, v26                                // 0000001DA7AC: 062A34F2
	v_rcp_f32_e32 v26, v16                                     // 0000001DA7B0: 7E345510
	v_add3_u32 v8, v8, v24, 0x7fff                             // 0000001DA7B4: D6550008 03FE3108 00007FFF
	v_fmac_f32_e32 v18, 0xb2a5705f, v29                        // 0000001DA7C0: 56243AFF B2A5705F
	v_and_b32_e32 v28, 1, v54                                  // 0000001DA7C8: 36386C81
	v_div_scale_f32 v27, null, v21, v21, v11                   // 0000001DA7CC: D6FC7C1B 042E2B15
	v_sub_f32_e32 v24, v47, v19                                // 0000001DA7D4: 0830272F
	global_store_d16_hi_b16 v[34:35], v8, off offset:64        // 0000001DA7D8: DC960040 007C0822
	v_cvt_i32_f32_e32 v19, v19                                 // 0000001DA7E0: 7E261113
	v_add3_u32 v9, v9, v28, 0x7fff                             // 0000001DA7E4: D6550009 03FE3909 00007FFF
	v_rcp_f32_e32 v46, v27                                     // 0000001DA7F0: 7E5C551B
	v_fma_f32 v17, -v16, v26, 1.0                              // 0000001DA7F4: D6130011 23CA3510
	v_lshlrev_b32_e32 v28, 16, v72                             // 0000001DA7FC: 30389090
	v_add_f32_e32 v18, v24, v18                                // 0000001DA800: 06242518
	global_store_d16_hi_b16 v[38:39], v9, off offset:64        // 0000001DA804: DC960040 007C0926
	v_fmac_f32_e32 v26, v17, v26                               // 0000001DA80C: 56343511
	v_div_scale_f32 v17, vcc_lo, v10, v25, v10                 // 0000001DA810: D6FC6A11 042A330A
	v_mul_f32_e32 v24, 0xbfb8aa3b, v28                         // 0000001DA818: 103038FF BFB8AA3B
	v_exp_f32_e32 v18, v18                                     // 0000001DA820: 7E244B12
	v_fma_f32 v20, -v27, v46, 1.0                              // 0000001DA824: D6130014 23CA5D1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DA82C: BF870193
	v_mul_f32_e32 v47, v17, v26                                // 0000001DA830: 105E3511
	v_fma_f32 v49, 0xbfb8aa3b, v28, -v24                       // 0000001DA834: D6130031 846238FF BFB8AA3B
	v_rndne_f32_e32 v51, v24                                   // 0000001DA840: 7E664718
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001DA844: BF870234
	v_fmac_f32_e32 v46, v20, v46                               // 0000001DA848: 565C5D14
	v_div_scale_f32 v20, s0, v11, v21, v11                     // 0000001DA84C: D6FC0014 042E2B0B
	v_fma_f32 v8, -v16, v47, v17                               // 0000001DA854: D6130008 24465F10
	v_dual_fmac_f32 v49, 0xb2a5705f, v28 :: v_dual_sub_f32 v24, v24, v51// 0000001DA85C: C80A38FF 31186718 B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DA868: BF870193
	v_mul_f32_e32 v48, v20, v46                                // 0000001DA86C: 10605D14
	v_fmac_f32_e32 v47, v8, v26                                // 0000001DA870: 565E3508
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DA874: BF870112
	v_fma_f32 v8, -v27, v48, v20                               // 0000001DA878: D6130008 2452611B
	v_fma_f32 v9, -v16, v47, v17                               // 0000001DA880: D6130009 24465F10
	v_add_f32_e32 v16, v24, v49                                // 0000001DA888: 06206318
	v_lshlrev_b32_e32 v24, 16, v52                             // 0000001DA88C: 30306890
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001DA890: BF870004
	v_fmac_f32_e32 v48, v8, v46                                // 0000001DA894: 56605D08
	.long 0xd71c0008                                           // 0000001DA898: D71C0008
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000001DA89C: 02022712
	v_div_fmas_f32 v9, v9, v26, v47                            // 0000001DA8A0: D6370009 04BE3509
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001DA8A8: 7C3C3AFF 42CE8ED0
	v_exp_f32_e32 v16, v16                                     // 0000001DA8B0: 7E204B10
	v_fma_f32 v17, -v27, v48, v20                              // 0000001DA8B4: D6130011 2452611B
	v_cvt_i32_f32_e32 v18, v51                                 // 0000001DA8BC: 7E241133
	v_div_fixup_f32 v9, v9, v25, v10                           // 0000001DA8C0: D6270009 042A3309
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo                        // 0000001DA8C8: 02101080
	s_mov_b32 vcc_lo, s0                                       // 0000001DA8CC: BEEA0000
	v_mul_f32_e32 v27, 0xbfb8aa3b, v24                         // 0000001DA8D0: 103630FF BFB8AA3B
	v_div_fmas_f32 v17, v17, v46, v48                          // 0000001DA8D8: D6370011 04C25D11
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001DA8E0: 7C363AFF C2B17218
	.long 0x7e323989                                           // 0000001DA8E8: 7E323989
	.long 0x7f3239b6                                           // 0000001DA8EC: 7F3239B6
	v_fma_f32 v29, 0xbfb8aa3b, v24, -v27                       // 0000001DA8F0: D613001D 846E30FF BFB8AA3B
	v_div_fixup_f32 v10, v17, v21, v11                         // 0000001DA8FC: D627000A 042E2B11
	v_cndmask_b32_e32 v8, 0x7f800000, v8, vcc_lo               // 0000001DA904: 021010FF 7F800000
	.long 0xd71c000b                                           // 0000001DA90C: D71C000B
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 0000001DA910: 02022510
	v_lshlrev_b32_e32 v16, 16, v50                             // 0000001DA914: 30206490
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v28                  // 0000001DA918: 7C3C38FF 42CE8ED0
	v_rndne_f32_e32 v46, v27                                   // 0000001DA920: 7E5C471B
	v_add_f32_e32 v8, 1.0, v8                                  // 0000001DA924: 061010F2
	v_fmac_f32_e32 v29, 0xb2a5705f, v24                        // 0000001DA928: 563A30FF B2A5705F
	v_dual_mul_f32 v18, 0xbfb8aa3b, v16 :: v_dual_cndmask_b32 v11, 0, v11// 0000001DA930: C8D220FF 120A1680 BFB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v28                  // 0000001DA93C: 7C3638FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001DA944: BF870224
	v_div_scale_f32 v17, null, v8, v8, v12                     // 0000001DA948: D6FC7C11 04321108
	v_sub_f32_e32 v27, v27, v46                                // 0000001DA950: 08365D1B
	v_fma_f32 v20, 0xbfb8aa3b, v16, -v18                       // 0000001DA954: D6130014 844A20FF BFB8AA3B
	v_rndne_f32_e32 v21, v18                                   // 0000001DA960: 7E2A4712
	v_cndmask_b32_e32 v11, 0x7f800000, v11, vcc_lo             // 0000001DA964: 021616FF 7F800000
	v_rcp_f32_e32 v19, v17                                     // 0000001DA96C: 7E265511
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DA970: BF870113
	v_dual_add_f32 v27, v27, v29 :: v_dual_fmac_f32 v20, 0xb2a5705f, v16// 0000001DA974: C9003B1B 1B1420FF B2A5705F
	v_dual_sub_f32 v18, v18, v21 :: v_dual_add_f32 v11, 1.0, v11// 0000001DA980: C9482B12 120A16F2
	v_cvt_i32_f32_e32 v21, v21                                 // 0000001DA988: 7E2A1115
	.long 0xd41e0001                                           // 0000001DA98C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v16, vcc_lo              // 0000001DA990: 020220FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DA998: BF870194
	v_exp_f32_e32 v27, v27                                     // 0000001DA99C: 7E364B1B
	v_add_f32_e32 v18, v18, v20                                // 0000001DA9A0: 06242912
	v_div_scale_f32 v26, null, v11, v11, v13                   // 0000001DA9A4: D6FC7C1A 0436170B
	s_delay_alu instid0(TRANS32_DEP_2)                         // 0000001DA9AC: BF870006
	v_fma_f32 v28, -v17, v19, 1.0                              // 0000001DA9B0: D613001C 23CA2711
	v_cvt_i32_f32_e32 v46, v46                                 // 0000001DA9B8: 7E5C112E
	v_and_b32_e32 v25, 1, v25                                  // 0000001DA9BC: 36323281
	v_exp_f32_e32 v18, v18                                     // 0000001DA9C0: 7E244B12
	v_rcp_f32_e32 v20, v26                                     // 0000001DA9C4: 7E28551A
	v_fmac_f32_e32 v19, v28, v19                               // 0000001DA9C8: 5626271C
	v_div_scale_f32 v28, vcc_lo, v12, v8, v12                  // 0000001DA9CC: D6FC6A1C 0432110C
	.long 0xd71c001b                                           // 0000001DA9D4: D71C001B
	v_cndmask_b32_e32 v1, v27, v46, vcc_lo                     // 0000001DA9D8: 02025D1B
	v_add3_u32 v9, v9, v25, 0x7fff                             // 0000001DA9DC: D6550009 03FE3309 00007FFF
	.long 0x7e6c398a                                           // 0000001DA9E8: 7E6C398A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001DA9EC: BF870314
	v_mul_f32_e32 v29, v28, v19                                // 0000001DA9F0: 103A271C
	.long 0xd71c0012                                           // 0000001DA9F4: D71C0012
	v_cndmask_b32_e32 v1, v18, v21, vcc_lo                     // 0000001DA9F8: 02022B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001DA9FC: BF870235
	v_fma_f32 v48, -v26, v20, 1.0                              // 0000001DAA00: D6130030 23CA291A
	v_div_scale_f32 v21, s0, v13, v11, v13                     // 0000001DAA08: D6FC0015 0436170D
	v_and_b32_e32 v47, 1, v54                                  // 0000001DAA10: 365E6C81
	v_cndmask_b32_e64 v18, 0, v18, s1                          // 0000001DAA14: D5010012 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001DAA1C: BF870244
	v_fmac_f32_e32 v20, v48, v20                               // 0000001DAA20: 56282930
	.long 0xd41b0001                                           // 0000001DAA24: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v16, vcc_lo              // 0000001DAA28: 020220FF C2B17218
	v_fma_f32 v48, -v17, v29, v28                              // 0000001DAA30: D6130030 24723B11
	v_add3_u32 v10, v10, v47, 0x7fff                           // 0000001DAA38: D655000A 03FE5F0A 00007FFF
	v_mul_f32_e32 v49, v21, v20                                // 0000001DAA44: 10622915
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DAA48: BF870214
	v_cndmask_b32_e64 v16, 0x7f800000, v18, s1                 // 0000001DAA4C: D5010010 000624FF 7F800000
	v_fmac_f32_e32 v29, v48, v19                               // 0000001DAA58: 563A2730
	.long 0xd41e0001                                           // 0000001DAA5C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v24, vcc_lo              // 0000001DAA60: 020230FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DAA68: BF870214
	v_fma_f32 v18, -v26, v49, v21                              // 0000001DAA6C: D6130012 2456631A
	v_add_f32_e32 v16, 1.0, v16                                // 0000001DAA74: 062020F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DAA78: BF870194
	v_fma_f32 v17, -v17, v29, v28                              // 0000001DAA7C: D6130011 24723B11
	v_fmac_f32_e32 v49, v18, v20                               // 0000001DAA84: 56622912
	v_cndmask_b32_e64 v18, 0, v27, s1                          // 0000001DAA88: D5010012 00063680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DAA90: BF870214
	v_div_scale_f32 v27, null, v16, v16, v0                    // 0000001DAA94: D6FC7C1B 04022110
	v_div_fmas_f32 v17, v17, v19, v29                          // 0000001DAA9C: D6370011 04762711
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000001DAAA4: 7C3630FF C2B17218
	v_fma_f32 v19, -v26, v49, v21                              // 0000001DAAAC: D6130013 2456631A
	.long 0x7f3039b6                                           // 0000001DAAB4: 7F3039B6
	v_rcp_f32_e32 v21, v27                                     // 0000001DAAB8: 7E2A551B
	v_div_fixup_f32 v8, v17, v8, v12                           // 0000001DAABC: D6270008 04321111
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001DAAC4: 022424FF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001DAACC: BEEA0000
	v_lshlrev_b32_e32 v17, 16, v42                             // 0000001DAAD0: 30225490
	v_div_fmas_f32 v19, v19, v20, v49                          // 0000001DAAD4: D6370013 04C62913
	.long 0x7e303988                                           // 0000001DAADC: 7E303988
	v_add_f32_e32 v18, 1.0, v18                                // 0000001DAAE0: 062424F2
	v_mul_f32_e32 v42, 0xbfb8aa3b, v32                         // 0000001DAAE4: 105440FF BFB8AA3B
	v_mul_f32_e32 v20, 0xbfb8aa3b, v17                         // 0000001DAAEC: 102822FF BFB8AA3B
	v_div_fixup_f32 v11, v19, v11, v13                         // 0000001DAAF4: D627000B 04361713
	v_fma_f32 v13, -v27, v21, 1.0                              // 0000001DAAFC: D613000D 23CA2B1B
	v_div_scale_f32 v12, null, v18, v18, v1                    // 0000001DAB04: D6FC7C0C 04062512
	v_and_b32_e32 v24, 1, v24                                  // 0000001DAB0C: 36303081
	v_fma_f32 v28, 0xbfb8aa3b, v17, -v20                       // 0000001DAB10: D613001C 845222FF BFB8AA3B
	v_rndne_f32_e32 v29, v20                                   // 0000001DAB1C: 7E3A4714
	v_fmac_f32_e32 v21, v13, v21                               // 0000001DAB20: 562A2B0D
	v_div_scale_f32 v13, vcc_lo, v0, v16, v0                   // 0000001DAB24: D6FC6A0D 04022100
	v_rcp_f32_e32 v19, v12                                     // 0000001DAB2C: 7E26550C
	v_fmac_f32_e32 v28, 0xb2a5705f, v17                        // 0000001DAB30: 563822FF B2A5705F
	v_sub_f32_e32 v20, v20, v29                                // 0000001DAB38: 08283B14
	.long 0x7e6c398b                                           // 0000001DAB3C: 7E6C398B
	v_mul_f32_e32 v25, v13, v21                                // 0000001DAB40: 10322B0D
	v_add3_u32 v8, v8, v24, 0x7fff                             // 0000001DAB44: D6550008 03FE3108 00007FFF
	v_fma_f32 v43, 0xbfb8aa3b, v32, -v42                       // 0000001DAB50: D613002B 84AA40FF BFB8AA3B
	v_add_f32_e32 v20, v20, v28                                // 0000001DAB5C: 06283914
	v_lshlrev_b32_e32 v28, 16, v44                             // 0000001DAB60: 30385890
	v_fma_f32 v30, -v27, v25, v13                              // 0000001DAB64: D613001E 2436331B
	v_fma_f32 v31, -v12, v19, 1.0                              // 0000001DAB6C: D613001F 23CA270C
	v_and_b32_e32 v26, 1, v54                                  // 0000001DAB74: 36346C81
	v_exp_f32_e32 v20, v20                                     // 0000001DAB78: 7E284B14
	v_rndne_f32_e32 v44, v42                                   // 0000001DAB7C: 7E58472A
	v_fmac_f32_e32 v25, v30, v21                               // 0000001DAB80: 56322B1E
	v_fmac_f32_e32 v19, v31, v19                               // 0000001DAB84: 5626271F
	s_waitcnt vmcnt(0)                                         // 0000001DAB88: BF8903F7
	v_lshlrev_b32_e32 v31, 16, v45                             // 0000001DAB8C: 303E5A90
	v_add3_u32 v11, v11, v26, 0x7fff                           // 0000001DAB90: D655000B 03FE350B 00007FFF
	v_div_scale_f32 v26, s0, v1, v18, v1                       // 0000001DAB9C: D6FC001A 04062501
	v_fma_f32 v13, -v27, v25, v13                              // 0000001DABA4: D613000D 2436331B
	v_mul_f32_e32 v27, 0xbfb8aa3b, v28                         // 0000001DABAC: 103638FF BFB8AA3B
	v_fmac_f32_e32 v43, 0xb2a5705f, v32                        // 0000001DABB4: 565640FF B2A5705F
	v_sub_f32_e32 v42, v42, v44                                // 0000001DABBC: 0854592A
	v_mul_f32_e32 v24, v26, v19                                // 0000001DABC0: 1030271A
	v_div_fmas_f32 v13, v13, v21, v25                          // 0000001DABC4: D637000D 04662B0D
	v_cvt_i32_f32_e32 v25, v29                                 // 0000001DABCC: 7E32111D
	v_fma_f32 v29, 0xbfb8aa3b, v28, -v27                       // 0000001DABD0: D613001D 846E38FF BFB8AA3B
	v_rndne_f32_e32 v30, v27                                   // 0000001DABDC: 7E3C471B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000001DABE0: 7C3C22FF 42CE8ED0
	v_fma_f32 v21, -v12, v24, v26                              // 0000001DABE8: D6130015 246A310C
	.long 0xd71c0014                                           // 0000001DABF0: D71C0014
	v_cndmask_b32_e32 v1, v20, v25, vcc_lo                     // 0000001DABF4: 02023314
	v_fmac_f32_e32 v29, 0xb2a5705f, v28                        // 0000001DABF8: 563A38FF B2A5705F
	v_sub_f32_e32 v25, v27, v30                                // 0000001DAC00: 08323D1B
	v_mul_f32_e32 v27, 0xbfb8aa3b, v31                         // 0000001DAC04: 10363EFF BFB8AA3B
	v_cvt_i32_f32_e32 v30, v30                                 // 0000001DAC0C: 7E3C111E
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001DAC10: 02282880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000001DAC14: 7C3622FF C2B17218
	v_add_f32_e32 v25, v25, v29                                // 0000001DAC1C: 06323B19
	v_fma_f32 v29, 0xbfb8aa3b, v31, -v27                       // 0000001DAC20: D613001D 846E3EFF BFB8AA3B
	v_fmac_f32_e32 v24, v21, v19                               // 0000001DAC2C: 56302715
	s_clause 0x3                                               // 0000001DAC30: BF850003
	global_store_d16_hi_b16 v[6:7], v9, off offset:64          // 0000001DAC34: DC960040 007C0906
	global_store_d16_hi_b16 v[14:15], v10, off offset:64       // 0000001DAC3C: DC960040 007C0A0E
	global_store_d16_hi_b16 v[22:23], v8, off offset:64        // 0000001DAC44: DC960040 007C0816
	global_store_d16_hi_b16 v[36:37], v11, off offset:64       // 0000001DAC4C: DC960040 007C0B24
	v_cndmask_b32_e32 v17, 0x7f800000, v20, vcc_lo             // 0000001DAC54: 022228FF 7F800000
	v_rndne_f32_e32 v20, v27                                   // 0000001DAC5C: 7E28471B
	v_exp_f32_e32 v25, v25                                     // 0000001DAC60: 7E324B19
	v_fmac_f32_e32 v29, 0xb2a5705f, v31                        // 0000001DAC64: 563A3EFF B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v28                  // 0000001DAC6C: 7C3C38FF 42CE8ED0
	v_fma_f32 v12, -v12, v24, v26                              // 0000001DAC74: D613000C 246A310C
	v_sub_f32_e32 v27, v27, v20                                // 0000001DAC7C: 0836291B
	v_cvt_i32_f32_e32 v20, v20                                 // 0000001DAC80: 7E281114
	v_cvt_i32_f32_e32 v26, v44                                 // 0000001DAC84: 7E34112C
	v_add_f32_e32 v17, 1.0, v17                                // 0000001DAC88: 062222F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001DAC8C: BF870294
	v_add_f32_e32 v27, v27, v29                                // 0000001DAC90: 06363B1B
	.long 0xd71c0015                                           // 0000001DAC94: D71C0015
	v_cndmask_b32_e32 v1, v25, v30, vcc_lo                     // 0000001DAC98: 02023D19
	v_add_f32_e32 v29, v42, v43                                // 0000001DAC9C: 063A572A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DACA0: BF870214
	v_div_scale_f32 v25, null, v17, v17, v2                    // 0000001DACA4: D6FC7C19 040A2311
	v_exp_f32_e32 v27, v27                                     // 0000001DACAC: 7E364B1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DACB0: BF870193
	v_cndmask_b32_e32 v21, 0, v21, vcc_lo                      // 0000001DACB4: 022A2A80
	v_exp_f32_e32 v29, v29                                     // 0000001DACB8: 7E3A4B1D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v28                  // 0000001DACBC: 7C3638FF C2B17218
	v_rcp_f32_e32 v30, v25                                     // 0000001DACC4: 7E3C5519
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_3)// 0000001DACC8: BF8703A2
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001DACCC: 022A2AFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v31                  // 0000001DACD4: 7C3C3EFF 42CE8ED0
	.long 0xd71c0014                                           // 0000001DACDC: D71C0014
	v_cndmask_b32_e32 v1, v27, v20, vcc_lo                     // 0000001DACE0: 0202291B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DACE4: BF870216
	.long 0xd71c001a                                           // 0000001DACE8: D71C001A
	v_cndmask_b32_e32 v1, v29, v26, vcc_lo                     // 0000001DACEC: 0202351D
	v_add_f32_e32 v21, 1.0, v21                                // 0000001DACF0: 062A2AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DACF4: BF870215
	v_fma_f32 v27, -v25, v30, 1.0                              // 0000001DACF8: D613001B 23CA3D19
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001DAD00: 02282880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 0000001DAD04: 7C3C40FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DAD0C: BF870214
	v_div_scale_f32 v28, null, v21, v21, v3                    // 0000001DAD10: D6FC7C1C 040E2B15
	v_fmac_f32_e32 v30, v27, v30                               // 0000001DAD18: 563C3D1B
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000001DAD1C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v31                  // 0000001DAD20: 7C363EFF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001DAD28: BF870134
	v_rcp_f32_e32 v29, v28                                     // 0000001DAD2C: 7E3A551C
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 0000001DAD30: 022828FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 0000001DAD38: 7C3640FF C2B17218
	v_add_f32_e32 v20, 1.0, v20                                // 0000001DAD40: 062828F2
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 0000001DAD44: 023434FF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001DAD4C: BEEA0000
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001DAD50: BF870005
	v_fma_f32 v27, -v28, v29, 1.0                              // 0000001DAD54: D613001B 23CA3B1C
	v_div_fmas_f32 v12, v12, v19, v24                          // 0000001DAD5C: D637000C 0462270C
	v_div_scale_f32 v19, null, v20, v20, v4                    // 0000001DAD64: D6FC7C13 04122914
	v_add_f32_e32 v24, 1.0, v26                                // 0000001DAD6C: 063034F2
	v_div_scale_f32 v26, vcc_lo, v2, v17, v2                   // 0000001DAD70: D6FC6A1A 040A2302
	v_fmac_f32_e32 v29, v27, v29                               // 0000001DAD78: 563A3B1B
	v_div_scale_f32 v10, s0, v3, v21, v3                       // 0000001DAD7C: D6FC000A 040E2B03
	v_rcp_f32_e32 v31, v19                                     // 0000001DAD84: 7E3E5513
	v_div_scale_f32 v32, null, v24, v24, v5                    // 0000001DAD88: D6FC7C20 04163118
	v_mul_f32_e32 v8, v26, v30                                 // 0000001DAD90: 10103D1A
	v_div_fixup_f32 v1, v12, v18, v1                           // 0000001DAD94: D6270001 0406250C
	.long 0x7f2439b6                                           // 0000001DAD9C: 7F2439B6
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DADA0: BF870194
	v_rcp_f32_e32 v9, v32                                      // 0000001DADA4: 7E125520
	v_fma_f32 v12, -v25, v8, v26                               // 0000001DADA8: D613000C 246A1119
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001DADB0: BF870313
	.long 0x7e6c3981                                           // 0000001DADB4: 7E6C3981
	v_fma_f32 v11, -v19, v31, 1.0                              // 0000001DADB8: D613000B 23CA3F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DADC0: BF870121
	v_dual_fmac_f32 v8, v12, v30 :: v_dual_fmac_f32 v31, v11, v31// 0000001DADC4: C8003D0C 081E3F0B
	v_div_scale_f32 v11, s1, v4, v20, v4                       // 0000001DADCC: D6FC010B 04122904
	v_fma_f32 v25, -v25, v8, v26                               // 0000001DADD4: D6130019 246A1119
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001DADDC: BF870002
	v_mul_f32_e32 v27, v11, v31                                // 0000001DADE0: 10363F0B
	v_div_fixup_f32 v0, v13, v16, v0                           // 0000001DADE4: D6270000 0402210D
	v_mul_f32_e32 v13, v10, v29                                // 0000001DADEC: 101A3B0A
	v_fma_f32 v16, -v32, v9, 1.0                               // 0000001DADF0: D6130010 23CA1320
	v_div_fmas_f32 v8, v25, v30, v8                            // 0000001DADF8: D6370008 04223D19
	s_mov_b32 vcc_lo, s0                                       // 0000001DAE00: BEEA0000
	.long 0x7e243980                                           // 0000001DAE04: 7E243980
	v_fma_f32 v12, -v28, v13, v10                              // 0000001DAE08: D613000C 242A1B1C
	v_fmac_f32_e32 v9, v16, v9                                 // 0000001DAE10: 56121310
	v_div_scale_f32 v16, s2, v5, v24, v5                       // 0000001DAE14: D6FC0210 04163105
	v_div_fixup_f32 v2, v8, v17, v2                            // 0000001DAE1C: D6270002 040A2308
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001DAE24: BF870224
	v_fmac_f32_e32 v13, v12, v29                               // 0000001DAE28: 561A3B0C
	v_fma_f32 v12, -v19, v27, v11                              // 0000001DAE2C: D613000C 242E3713
	v_mul_f32_e32 v26, v16, v9                                 // 0000001DAE34: 10341310
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DAE38: BF870193
	v_fma_f32 v10, -v28, v13, v10                              // 0000001DAE3C: D613000A 242A1B1C
	v_fmac_f32_e32 v27, v12, v31                               // 0000001DAE44: 56363F0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001DAE48: BF870223
	v_fma_f32 v25, -v32, v26, v16                              // 0000001DAE4C: D6130019 24423520
	v_and_b32_e32 v12, 1, v54                                  // 0000001DAE54: 36186C81
	v_div_fmas_f32 v10, v10, v29, v13                          // 0000001DAE58: D637000A 04363B0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DAE60: BF870214
	v_fma_f32 v8, -v19, v27, v11                               // 0000001DAE64: D6130008 242E3713
	v_fmac_f32_e32 v26, v25, v9                                // 0000001DAE6C: 56341319
	s_mov_b32 vcc_lo, s1                                       // 0000001DAE70: BEEA0001
	.long 0x7f1639b6                                           // 0000001DAE74: 7F1639B6
	v_div_fixup_f32 v3, v10, v21, v3                           // 0000001DAE78: D6270003 040E2B0A
	v_div_fmas_f32 v8, v8, v31, v27                            // 0000001DAE80: D6370008 046E3F08
	v_fma_f32 v10, -v32, v26, v16                              // 0000001DAE88: D613000A 24423520
	s_mov_b32 vcc_lo, s2                                       // 0000001DAE90: BEEA0002
	v_add3_u32 v1, v1, v12, 0x7fff                             // 0000001DAE94: D6550001 03FE1901 00007FFF
	.long 0x7e6c3983                                           // 0000001DAEA0: 7E6C3983
	v_div_fixup_f32 v4, v8, v20, v4                            // 0000001DAEA4: D6270004 04122908
	v_div_fmas_f32 v9, v10, v9, v26                            // 0000001DAEAC: D6370009 046A130A
	v_and_b32_e32 v10, 1, v18                                  // 0000001DAEB4: 36142481
	.long 0x7e103982                                           // 0000001DAEB8: 7E103982
	.long 0x7f1039b6                                           // 0000001DAEBC: 7F1039B6
	.long 0x7e163984                                           // 0000001DAEC0: 7E163984
	v_div_fixup_f32 v5, v9, v24, v5                            // 0000001DAEC4: D6270005 04163109
	v_and_b32_e32 v9, 1, v54                                   // 0000001DAECC: 36126C81
	v_add3_u32 v0, v0, v10, 0x7fff                             // 0000001DAED0: D6550000 03FE1500 00007FFF
	v_and_b32_e32 v8, 1, v8                                    // 0000001DAEDC: 36101081
	v_and_b32_e32 v10, 1, v11                                  // 0000001DAEE0: 36141681
	.long 0x7e6c3985                                           // 0000001DAEE4: 7E6C3985
	global_store_d16_hi_b16 v[34:35], v0, off offset:96        // 0000001DAEE8: DC960060 007C0022
	v_add3_u32 v0, v2, v8, 0x7fff                              // 0000001DAEF0: D6550000 03FE1102 00007FFF
	v_add3_u32 v2, v3, v9, 0x7fff                              // 0000001DAEFC: D6550002 03FE1303 00007FFF
	v_and_b32_e32 v11, 1, v54                                  // 0000001DAF08: 36166C81
	v_add3_u32 v3, v4, v10, 0x7fff                             // 0000001DAF0C: D6550003 03FE1504 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001DAF18: BF870002
	v_add3_u32 v4, v5, v11, 0x7fff                             // 0000001DAF1C: D6550004 03FE1705 00007FFF
	s_clause 0x4                                               // 0000001DAF28: BF850004
	global_store_d16_hi_b16 v[38:39], v1, off offset:96        // 0000001DAF2C: DC960060 007C0126
	global_store_d16_hi_b16 v[6:7], v0, off offset:96          // 0000001DAF34: DC960060 007C0006
	global_store_d16_hi_b16 v[14:15], v2, off offset:96        // 0000001DAF3C: DC960060 007C020E
	global_store_d16_hi_b16 v[22:23], v3, off offset:96        // 0000001DAF44: DC960060 007C0316
	global_store_d16_hi_b16 v[36:37], v4, off offset:96        // 0000001DAF4C: DC960060 007C0424
	s_nop 0                                                    // 0000001DAF54: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001DAF58: BFB60003
	s_endpgm                                                   // 0000001DAF5C: BFB00000
		...

