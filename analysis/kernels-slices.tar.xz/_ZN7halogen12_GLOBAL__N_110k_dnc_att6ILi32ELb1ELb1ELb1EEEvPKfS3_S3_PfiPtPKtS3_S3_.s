0000000000218600 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_():
	s_clause 0x1                                               // 000000218600: BF850001
	s_load_b256 s[8:15], s[0:1], 0x28                          // 000000218604: F40C0200 F8000028
	s_load_b32 s20, s[0:1], 0x20                               // 00000021860C: F4000500 F8000020
	s_mul_hi_i32 s6, s2, 0x55555556                            // 000000218614: 9706FF02 55555556
	v_dual_mov_b32 v5, v0 :: v_dual_and_b32 v2, 0x7f, v0       // 00000021861C: CA240100 050200FF 0000007F
	s_lshr_b32 s7, s6, 31                                      // 000000218628: 85079F06
	s_mov_b32 s4, s3                                           // 00000021862C: BE840003
	s_add_i32 s6, s6, s7                                       // 000000218630: 81060706
	s_lshl_b32 s21, s3, 5                                      // 000000218634: 84158503
	s_ashr_i32 s3, s2, 31                                      // 000000218638: 86039F02
	s_lshl_b32 s18, s6, 7                                      // 00000021863C: 84128706
	s_lshl_b64 s[6:7], s[2:3], 2                               // 000000218640: 84868202
	v_lshlrev_b32_e32 v1, 2, v2                                // 000000218644: 30020482
	v_dual_mov_b32 v3, v0 :: v_dual_lshlrev_b32 v2, 1, v2      // 000000218648: CA220100 03020481
	s_ashr_i32 s19, s18, 31                                    // 000000218650: 86139F12
	s_mov_b32 s5, 0                                            // 000000218654: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000218658: BF89FC07
	s_add_u32 s16, s14, s6                                     // 00000021865C: 8010060E
	s_addc_u32 s17, s15, s7                                    // 000000218660: 8211070F
	s_lshl_b64 s[14:15], s[18:19], 1                           // 000000218664: 848E8112
	s_set_inst_prefetch_distance 0x1                           // 000000218668: BF840001
	s_branch 19                                                // 00000021866C: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0xbc>
	s_nop 0                                                    // 000000218670: BF800000
	s_nop 0                                                    // 000000218674: BF800000
	s_nop 0                                                    // 000000218678: BF800000
	s_nop 0                                                    // 00000021867C: BF800000
	s_or_b32 exec_lo, exec_lo, s18                             // 000000218680: 8C7E127E
	v_add_nc_u32_e32 v6, 0x100, v3                             // 000000218684: 4A0C06FF 00000100
	v_mad_u64_u32 v[8:9], null, 0x204, v4, v[1:2]              // 00000021868C: D6FE7C08 040608FF 00000204
	v_cmp_lt_u32_e32 vcc_lo, 0xeff, v3                         // 000000218698: 7C9206FF 00000EFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002186A0: BF870003
	v_mov_b32_e32 v3, v6                                       // 0000002186A4: 7E060306
	s_or_b32 s5, vcc_lo, s5                                    // 0000002186A8: 8C05056A
	ds_store_b32 v8, v7                                        // 0000002186AC: D8340000 00000708
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000002186B4: 917E057E
	s_cbranch_execz 40                                         // 0000002186B8: BFA50028 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x15c>
	v_lshrrev_b32_e32 v4, 7, v3                                // 0000002186BC: 32080687
	v_mov_b32_e32 v7, 0                                        // 0000002186C0: 7E0E0280
	s_mov_b32 s18, exec_lo                                     // 0000002186C4: BE92007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002186C8: BF870092
	v_or_b32_e32 v6, s21, v4                                   // 0000002186CC: 380C0815
	.long 0xd4c4007e                                           // 0000002186D0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 0000002186D4: 02020C14
	s_cbranch_execz 65513                                      // 0000002186D8: BFA5FFE9 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x80>
	v_mad_i64_i32 v[7:8], null, 0x5000, v6, s[10:11]           // 0000002186DC: D6FF7C07 002A0CFF 00005000
	v_mad_i64_i32 v[9:10], null, 0xc0, v6, s[16:17]            // 0000002186E8: D6FF7C09 00420CFF 000000C0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002186F4: BF870092
	.long 0xd7006a07                                           // 0000002186F8: D7006A07
	v_cndmask_b32_e32 v0, v7, v14, vcc_lo                      // 0000002186FC: 02001D07
	v_add_co_ci_u32_e64 v8, null, s15, v8, vcc_lo              // 000000218700: D5207C08 01AA100F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000218708: BF870092
	.long 0xd7006a07                                           // 00000021870C: D7006A07
	v_cndmask_b32_e32 v1, v7, v2, vcc_lo                       // 000000218710: 02020507
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 000000218714: D5207C08 01AA1080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000021871C: BF870092
	.long 0xd7006a07                                           // 000000218720: D7006A07
	v_cndmask_b32_e32 v1, 0x1000, v7, vcc_lo                   // 000000218724: 02020EFF 00001000
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 00000021872C: D5207C08 01AA1080
	global_load_u16 v6, v[7:8], off                            // 000000218734: DC4A0000 067C0007
	global_load_b32 v7, v[9:10], off                           // 00000021873C: DC520000 077C0009
	s_waitcnt vmcnt(1)                                         // 000000218744: BF8907F7
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000218748: 300C0C90
	s_waitcnt vmcnt(0)                                         // 00000021874C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1)                            // 000000218750: BF870001
	v_mul_f32_e32 v7, v7, v6                                   // 000000218754: 100E0D07
	s_branch 65481                                             // 000000218758: BFA0FFC9 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x80>
	s_set_inst_prefetch_distance 0x2                           // 00000021875C: BF840002
	s_or_b32 exec_lo, exec_lo, s5                              // 000000218760: 8C7E057E
	s_load_b128 s[16:19], s[0:1], 0x10                         // 000000218764: F4080400 F8000010
	s_lshr_b32 s0, s4, 31                                      // 00000021876C: 85009F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000218770: BF8704B9
	s_add_i32 s4, s4, s0                                       // 000000218774: 81040004
	s_mov_b32 s0, exec_lo                                      // 000000218778: BE80007E
	s_ashr_i32 s4, s4, 1                                       // 00000021877C: 86048104
	s_lshl_b32 s22, s4, 6                                      // 000000218780: 84168604
	v_cmpx_gt_u32_e32 64, v0                                   // 000000218784: 7D9800C0
	s_cbranch_execz 17                                         // 000000218788: BFA50011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x1d0>
	v_or_b32_e32 v1, s22, v0                                   // 00000021878C: 38020016
	s_waitcnt lgkmcnt(0)                                       // 000000218790: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000218794: BF870091
	v_mad_i64_i32 v[1:2], null, 0xc0, v1, s[16:17]             // 000000218798: D6FF7C01 004202FF 000000C0
	.long 0xd7006a01                                           // 0000002187A4: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 0000002187A8: 02000D01
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002187AC: BF870001
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 0000002187B0: D5207C02 01AA0407
	global_load_b32 v1, v[1:2], off                            // 0000002187B8: DC520000 017C0001
	v_lshlrev_b32_e32 v2, 2, v0                                // 0000002187C0: 30040082
	s_waitcnt vmcnt(0)                                         // 0000002187C4: BF8903F7
	ds_store_b32 v2, v1 offset:16512                           // 0000002187C8: D8344080 00000102
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002187D0: 8C7E007E
	s_mov_b64 s[0:1], 0                                        // 0000002187D4: BE800180
	s_waitcnt lgkmcnt(0)                                       // 0000002187D8: BF89FC07
	s_cmp_eq_u64 s[18:19], 0                                   // 0000002187DC: BF108012
	s_mul_hi_i32 s16, s4, 48                                   // 0000002187E0: 9710B004
	s_mul_i32 s17, s4, 48                                      // 0000002187E4: 9611B004
	s_mov_b64 s[4:5], 0                                        // 0000002187E8: BE840180
	s_barrier                                                  // 0000002187EC: BFBD0000
	buffer_gl0_inv                                             // 0000002187F0: E0AC0000 00000000
	s_cbranch_scc1 6                                           // 0000002187F8: BFA20006 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x214>
	s_add_u32 s4, s17, s2                                      // 0000002187FC: 80040211
	s_addc_u32 s5, s16, s3                                     // 000000218800: 82050310
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000218804: BF870499
	s_lshl_b64 s[4:5], s[4:5], 14                              // 000000218808: 84848E04
	s_add_u32 s4, s18, s4                                      // 00000021880C: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000218810: 82050513
	s_cmp_eq_u64 s[8:9], 0                                     // 000000218814: BF108008
	s_cbranch_scc1 6                                           // 000000218818: BFA20006 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x234>
	s_add_u32 s0, s17, s2                                      // 00000021881C: 80000211
	s_addc_u32 s1, s16, s3                                     // 000000218820: 82010310
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000218824: BF870499
	s_lshl_b64 s[0:1], s[0:1], 13                              // 000000218828: 84808D00
	s_add_u32 s0, s8, s0                                       // 00000021882C: 80000008
	s_addc_u32 s1, s9, s1                                      // 000000218830: 82010109
	s_sub_i32 s9, s21, s22                                     // 000000218834: 81891615
	v_lshrrev_b32_e32 v6, 5, v0                                // 000000218838: 320C0085
	s_lshl_b32 s8, s9, 5                                       // 00000021883C: 84088509
	s_mov_b32 s17, exec_lo                                     // 000000218840: BE91007E
	s_sub_i32 s16, 0x800, s8                                   // 000000218844: 819008FF 00000800
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000021884C: BF870009
	.long 0xd4c4007e                                           // 000000218850: D4C4007E
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000218854: 02020010
	s_cbranch_execz 197                                        // 000000218858: BFA500C5 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x570>
	s_add_u32 s10, s10, s14                                    // 00000021885C: 800A0E0A
	v_mul_u32_u24_e32 v1, 0x204, v0                            // 000000218860: 160200FF 00000204
	v_mul_u32_u24_e32 v2, 0x4080, v6                           // 000000218868: 16040CFF 00004080
	s_addc_u32 s11, s11, s15                                   // 000000218870: 820B0F0B
	s_add_u32 s6, s12, s6                                      // 000000218874: 8006060C
	s_addc_u32 s7, s13, s7                                     // 000000218878: 8207070D
	s_cmp_lg_u64 s[4:5], 0                                     // 00000021887C: BF118004
	v_sub_nc_u32_e32 v7, v1, v2                                // 000000218880: 4C0E0501
	v_mov_b32_e32 v8, 0                                        // 000000218884: 7E100280
	s_cselect_b32 s12, -1, 0                                   // 000000218888: 980C80C1
	s_cmp_lg_u64 s[0:1], 0                                     // 00000021888C: BF118000
	s_mov_b32 s14, 0                                           // 000000218890: BE8E0080
	s_cselect_b32 s13, -1, 0                                   // 000000218894: 980D80C1
	s_mov_b32 s15, 0x41800000                                  // 000000218898: BE8F00FF 41800000
	s_branch 7                                                 // 0000002188A0: BFA00007 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x2c0>
	v_add_nc_u32_e32 v5, 0x100, v5                             // 0000002188A4: 4A0A0AFF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002188AC: BF8704A1
	v_cmp_le_i32_e32 vcc_lo, s16, v5                           // 0000002188B0: 7C860A10
	s_or_b32 s14, vcc_lo, s14                                  // 0000002188B4: 8C0E0E6A
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000002188B8: 917E0E7E
	s_cbranch_execz 172                                        // 0000002188BC: BFA500AC <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x570>
	v_lshrrev_b32_e32 v2, 5, v5                                // 0000002188C0: 32040A85
	v_add_nc_u32_e32 v1, s9, v5                                // 0000002188C4: 4A020A09
	v_dual_mov_b32 v9, 0 :: v_dual_and_b32 v4, 0x7fffffe0, v5  // 0000002188C8: CA240080 09040AFF 7FFFFFE0
	s_mov_b32 s18, exec_lo                                     // 0000002188D4: BE92007E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002188D8: BF870113
	v_add_nc_u32_e32 v3, s9, v2                                // 0000002188DC: 4A060409
	v_sub_nc_u32_e32 v1, v1, v4                                // 0000002188E0: 4C020901
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002188E4: BF870001
	.long 0xd4c3007e                                           // 0000002188E8: D4C3007E
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000002188EC: 02020701
	s_cbranch_execz 116                                        // 0000002188F0: BFA50074 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x4c4>
	v_add_nc_u32_e32 v2, s21, v2                               // 0000002188F4: 4A040415
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002188F8: BF870001
	v_readfirstlane_b32 s2, v2                                 // 0000002188FC: 7E040502
	v_mov_b32_e32 v2, 0                                        // 000000218900: 7E040280
	s_cmp_ge_i32 s2, s20                                       // 000000218904: BF031402
	s_cbranch_scc1 75                                          // 000000218908: BFA2004B <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x438>
	s_mul_i32 s3, s2, 0x5000                                   // 00000021890C: 9603FF02 00005000
	s_mul_hi_i32 s22, s2, 0x5000                               // 000000218914: 9716FF02 00005000
	s_add_u32 s19, s10, s3                                     // 00000021891C: 8013030A
	s_mul_i32 s3, s2, 0xc0                                     // 000000218920: 9603FF02 000000C0
	s_addc_u32 s22, s11, s22                                   // 000000218928: 8216160B
	s_mul_hi_i32 s23, s2, 0xc0                                 // 00000021892C: 9717FF02 000000C0
	s_add_u32 s2, s6, s3                                       // 000000218934: 80020306
	s_addc_u32 s3, s7, s23                                     // 000000218938: 82031707
	v_mov_b32_e32 v2, 0                                        // 00000021893C: 7E040280
	s_load_b32 s23, s[2:3], null                               // 000000218940: F40005C1 F8000000
	v_mov_b32_e32 v4, v7                                       // 000000218948: 7E080307
	s_mov_b64 s[2:3], 0                                        // 00000021894C: BE820180
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000218950: BF870009
	s_add_u32 s24, s19, s2                                     // 000000218954: 80180213
	s_addc_u32 s25, s22, s3                                    // 000000218958: 82190316
	ds_load_2addr_b32 v[13:14], v4 offset1:1                   // 00000021895C: D8DC0100 0D000004
	ds_load_2addr_b32 v[15:16], v4 offset0:2 offset1:3         // 000000218964: D8DC0302 0F000004
	ds_load_2addr_b32 v[17:18], v4 offset0:4 offset1:5         // 00000021896C: D8DC0504 11000004
	ds_load_2addr_b32 v[19:20], v4 offset0:6 offset1:7         // 000000218974: D8DC0706 13000004
	global_load_b128 v[9:12], v8, s[24:25]                     // 00000021897C: DC5E0000 09180008
	v_add_nc_u32_e32 v4, 32, v4                                // 000000218984: 4A0808A0
	s_waitcnt vmcnt(0)                                         // 000000218988: BF8903F7
	v_readfirstlane_b32 s24, v9                                // 00000021898C: 7E300509
	v_readfirstlane_b32 s26, v10                               // 000000218990: 7E34050A
	s_lshl_b32 s25, s24, 16                                    // 000000218994: 84199018
	s_and_b32 s24, s24, 0xffff0000                             // 000000218998: 8B18FF18 FFFF0000
	s_waitcnt lgkmcnt(0)                                       // 0000002189A0: BF89FC07
	s_mul_f32 s25, s23, s25                                    // 0000002189A4: A2191917
	s_mul_f32 s24, s23, s24                                    // 0000002189A8: A2181817
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002189AC: BF8700BA
	v_fmac_f32_e32 v2, s25, v13                                // 0000002189B0: 56041A19
	s_lshl_b32 s25, s26, 16                                    // 0000002189B4: 8419901A
	s_and_b32 s26, s26, 0xffff0000                             // 0000002189B8: 8B1AFF1A FFFF0000
	v_fmac_f32_e32 v2, s24, v14                                // 0000002189C0: 56041C18
	s_mul_f32 s24, s23, s25                                    // 0000002189C4: A2181917
	v_readfirstlane_b32 s25, v11                               // 0000002189C8: 7E32050B
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_2)    // 0000002189CC: BF870502
	v_fmac_f32_e32 v2, s24, v15                                // 0000002189D0: 56041E18
	s_mul_f32 s24, s23, s26                                    // 0000002189D4: A2181A17
	s_lshl_b32 s26, s25, 16                                    // 0000002189D8: 841A9019
	s_and_b32 s25, s25, 0xffff0000                             // 0000002189DC: 8B19FF19 FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000002189E4: BF870481
	v_fmac_f32_e32 v2, s24, v16                                // 0000002189E8: 56042018
	s_mul_f32 s24, s23, s26                                    // 0000002189EC: A2181A17
	v_readfirstlane_b32 s26, v12                               // 0000002189F0: 7E34050C
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_2)    // 0000002189F4: BF870502
	v_fmac_f32_e32 v2, s24, v17                                // 0000002189F8: 56042218
	s_mul_f32 s24, s23, s25                                    // 0000002189FC: A2181917
	s_lshl_b32 s25, s26, 16                                    // 000000218A00: 8419901A
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_2)    // 000000218A04: BF870501
	v_fmac_f32_e32 v2, s24, v18                                // 000000218A08: 56042418
	s_mul_f32 s24, s23, s25                                    // 000000218A0C: A2181917
	s_and_b32 s25, s26, 0xffff0000                             // 000000218A10: 8B19FF1A FFFF0000
	s_add_u32 s2, s2, 16                                       // 000000218A18: 80029002
	s_addc_u32 s3, s3, 0                                       // 000000218A1C: 82038003
	v_fmac_f32_e32 v2, s24, v19                                // 000000218A20: 56042618
	s_mul_f32 s24, s23, s25                                    // 000000218A24: A2181917
	s_cmpk_lg_i32 s2, 0x100                                    // 000000218A28: B2020100
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_2)    // 000000218A2C: BF870501
	v_fmac_f32_e32 v2, s24, v20                                // 000000218A30: 56042818
	s_cbranch_scc1 65478                                       // 000000218A34: BFA2FFC6 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x350>
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000218A38: 30080682
	v_lshlrev_b32_e32 v9, 2, v1                                // 000000218A3C: 30120282
	ds_load_b32 v4, v4 offset:16512                            // 000000218A40: D8D84080 04000004
	ds_load_b32 v9, v9 offset:16512                            // 000000218A48: D8D84080 09000009
	s_waitcnt lgkmcnt(0)                                       // 000000218A50: BF89FC07
	v_sub_f32_e32 v4, v4, v9                                   // 000000218A54: 08081304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000218A58: BF870091
	v_mul_f32_e32 v9, 0x3fb8aa3b, v4                           // 000000218A5C: 101208FF 3FB8AA3B
	v_fma_f32 v10, 0x3fb8aa3b, v4, -v9                         // 000000218A64: D613000A 842608FF 3FB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 000000218A70: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000218A74: BF870121
	v_dual_sub_f32 v9, v9, v11 :: v_dual_fmac_f32 v10, 0x32a5705f, v4// 000000218A78: C9401709 090A08FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 000000218A84: 7C3608FF C2CE8ED0
	v_add_f32_e32 v9, v9, v10                                  // 000000218A8C: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 000000218A90: 7E14110B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000218A94: BF870292
	v_exp_f32_e32 v9, v9                                       // 000000218A98: 7E124B09
	.long 0xd71c0009                                           // 000000218A9C: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000218AA0: 02021509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000218AA4: BF870121
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 000000218AA8: 02121280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 000000218AAC: 7C3C08FF 42B17218
	v_cndmask_b32_e32 v4, 0x7f800000, v9, vcc_lo               // 000000218AB4: 020812FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000218ABC: BF870001
	v_mul_f32_e32 v9, v2, v4                                   // 000000218AC0: 10120902
	s_or_b32 exec_lo, exec_lo, s18                             // 000000218AC4: 8C7E127E
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000218AC8: 3408069F
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000218ACC: 3404029F
	s_and_not1_b32 vcc_lo, exec_lo, s12                        // 000000218AD0: 916A0C7E
	s_cbranch_vccnz 17                                         // 000000218AD4: BFA40011 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x51c>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000218AD8: BF870112
	.long 0xd73c000a                                           // 000000218ADC: D73C000A
	v_cndmask_b32_e32 v1, 8, v3, vcc_lo                        // 000000218AE0: 02020688
	.long 0xd73c000c                                           // 000000218AE4: D73C000C
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000218AE8: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000218AEC: BF870092
	.long 0xd7006a0a                                           // 000000218AF0: D7006A0A
	v_cndmask_b32_e32 v1, s4, v10, vcc_lo                      // 000000218AF4: 02021404
	v_add_co_ci_u32_e64 v11, null, s5, v11, vcc_lo             // 000000218AF8: D5207C0B 01AA1605
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000218B00: BF870092
	.long 0xd7006a0a                                           // 000000218B04: D7006A0A
	v_cndmask_b32_e32 v1, v10, v12, vcc_lo                     // 000000218B08: 0202190A
	v_add_co_ci_u32_e64 v11, null, v11, v13, vcc_lo            // 000000218B0C: D5207C0B 01AA1B0B
	global_store_b32 v[10:11], v9, off                         // 000000218B14: DC6A0000 007C090A
	s_and_not1_b32 vcc_lo, exec_lo, s13                        // 000000218B1C: 916A0D7E
	s_cbranch_vccnz 65376                                      // 000000218B20: BFA4FF60 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x2a4>
	.long 0xd73c0003                                           // 000000218B24: D73C0003
	v_cndmask_b32_e32 v1, 7, v3, vcc_lo                        // 000000218B28: 02020687
	.long 0xd73c000a                                           // 000000218B2C: D73C000A
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000218B30: 02020281
	v_fma_mixlo_f16 v1, v9, s15, 0                             // 000000218B34: CC210001 02001F09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000218B3C: BF870093
	.long 0xd7006a02                                           // 000000218B40: D7006A02
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 000000218B44: 02020600
	v_add_co_ci_u32_e64 v3, null, s1, v4, vcc_lo               // 000000218B48: D5207C03 01AA0801
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000218B50: BF870092
	.long 0xd7006a02                                           // 000000218B54: D7006A02
	v_cndmask_b32_e32 v1, v2, v10, vcc_lo                      // 000000218B58: 02021502
	v_add_co_ci_u32_e64 v3, null, v3, v11, vcc_lo              // 000000218B5C: D5207C03 01AA1703
	global_store_b16 v[2:3], v1, off                           // 000000218B64: DC660000 007C0102
	s_branch 65357                                             // 000000218B6C: BFA0FF4D <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x2a4>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000218B70: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000218B74: BF870009
	s_mov_b32 s2, exec_lo                                      // 000000218B78: BE82007E
	.long 0xd4c4007e                                           // 000000218B7C: D4C4007E
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000218B80: 02020008
	s_cbranch_execz 94                                         // 000000218B84: BFA5005E <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x700>
	s_cmp_lg_u64 s[4:5], 0                                     // 000000218B88: BF118004
	v_and_b32_e32 v1, 0xe0, v0                                 // 000000218B8C: 360200FF 000000E0
	s_cselect_b32 s2, -1, 0                                    // 000000218B94: 980280C1
	s_ashr_i32 s3, s9, 31                                      // 000000218B98: 86039F09
	.long 0xd7000602                                           // 000000218B9C: D7000602
	v_cndmask_b32_e32 v1, s9, v0, vcc_lo                       // 000000218BA0: 02020009
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000218BA4: BF8700B1
	v_add_co_ci_u32_e64 v3, null, s3, 0, s6                    // 000000218BA8: D5207C03 00190003
	s_cmp_lg_u64 s[0:1], 0                                     // 000000218BB0: BF118000
	.long 0xd7016a02                                           // 000000218BB4: D7016A02
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000218BB8: 02020302
	v_subrev_co_ci_u32_e64 v3, null, 0, v3, vcc_lo             // 000000218BBC: D5227C03 01AA0680
	v_mov_b32_e32 v1, 0                                        // 000000218BC4: 7E020280
	v_lshlrev_b32_e32 v7, 8, v6                                // 000000218BC8: 300E0C88
	v_lshlrev_b32_e32 v6, 7, v6                                // 000000218BCC: 300C0C87
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000218BD0: BF870134
	.long 0xd73c0004                                           // 000000218BD4: D73C0004
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000218BD8: 02020482
	.long 0xd73c0002                                           // 000000218BDC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 000000218BE0: 02020481
	s_mov_b32 s3, 0                                            // 000000218BE4: BE830080
	.long 0xd7006a04                                           // 000000218BE8: D7006A04
	v_cndmask_b32_e32 v1, v7, v4, vcc_lo                       // 000000218BEC: 02020907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000218BF0: BF870191
	v_add_co_ci_u32_e64 v5, null, 0, v5, vcc_lo                // 000000218BF4: D5207C05 01AA0A80
	.long 0xd7006a06                                           // 000000218BFC: D7006A06
	v_cndmask_b32_e32 v1, v6, v2, vcc_lo                       // 000000218C00: 02020506
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000218C04: BF870211
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 000000218C08: D5207C07 01AA0680
	.long 0xd7006a02                                           // 000000218C10: D7006A02
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 000000218C14: 02020804
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000218C18: BF870211
	v_add_co_ci_u32_e64 v3, null, s5, v5, vcc_lo               // 000000218C1C: D5207C03 01AA0A05
	.long 0xd7006a04                                           // 000000218C24: D7006A04
	v_cndmask_b32_e32 v1, s0, v6, vcc_lo                       // 000000218C28: 02020C00
	s_delay_alu instid0(VALU_DEP_1)                            // 000000218C2C: BF870001
	v_add_co_ci_u32_e64 v5, null, s1, v7, vcc_lo               // 000000218C30: D5207C05 01AA0E01
	v_dual_mov_b32 v7, v1 :: v_dual_mov_b32 v6, v0             // 000000218C38: CA100101 07060100
	s_cselect_b32 s1, -1, 0                                    // 000000218C40: 980180C1
	s_set_inst_prefetch_distance 0x1                           // 000000218C44: BF840001
	s_branch 35                                                // 000000218C48: BFA00023 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x6d8>
	s_nop 0                                                    // 000000218C4C: BF800000
	s_nop 0                                                    // 000000218C50: BF800000
	s_nop 0                                                    // 000000218C54: BF800000
	s_nop 0                                                    // 000000218C58: BF800000
	s_nop 0                                                    // 000000218C5C: BF800000
	s_nop 0                                                    // 000000218C60: BF800000
	s_nop 0                                                    // 000000218C64: BF800000
	s_nop 0                                                    // 000000218C68: BF800000
	s_nop 0                                                    // 000000218C6C: BF800000
	s_nop 0                                                    // 000000218C70: BF800000
	s_nop 0                                                    // 000000218C74: BF800000
	s_nop 0                                                    // 000000218C78: BF800000
	s_nop 0                                                    // 000000218C7C: BF800000
	.long 0xd7006a06                                           // 000000218C80: D7006A06
	v_cndmask_b32_e32 v1, 0x100, v6, vcc_lo                    // 000000218C84: 02020CFF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000218C8C: BF8700A1
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 000000218C90: D5207C07 01AA0E80
	.long 0xd7006a02                                           // 000000218C98: D7006A02
	v_cndmask_b32_e32 v1, 0x800, v2, vcc_lo                    // 000000218C9C: 020204FF 00000800
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000218CA4: D5207C03 01AA0680
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000218CAC: BF8700A4
	v_cmp_le_i32_e32 vcc_lo, s8, v6                            // 000000218CB0: 7C860C08
	.long 0xd7000004                                           // 000000218CB4: D7000004
	v_cndmask_b32_e32 v1, 0x400, v4, vcc_lo                    // 000000218CB8: 020208FF 00000400
	v_add_co_ci_u32_e64 v5, null, 0, v5, s0                    // 000000218CC0: D5207C05 00020A80
	s_or_b32 s3, vcc_lo, s3                                    // 000000218CC8: 8C03036A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000218CCC: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000218CD0: 917E037E
	s_cbranch_execz 10                                         // 000000218CD4: BFA5000A <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x700>
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 000000218CD8: 916A027E
	s_cbranch_vccnz 2                                          // 000000218CDC: BFA40002 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x6e8>
	global_store_b32 v[2:3], v1, off                           // 000000218CE0: DC6A0000 007C0102
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000218CE8: 916A017E
	s_cbranch_vccnz 65508                                      // 000000218CEC: BFA4FFE4 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x680>
	.long 0x7e003880                                           // 000000218CF0: 7E003880
	global_store_b16 v[4:5], v0, off                           // 000000218CF4: DC660000 007C0004
	s_branch 65504                                             // 000000218CFC: BFA0FFE0 <_ZN7halogen12_GLOBAL__N_110k_dnc_att6ILi32ELb1ELb1ELb1EEEvPKfS3_S3_PfiPtPKtS3_S3_+0x680>
	s_set_inst_prefetch_distance 0x2                           // 000000218D00: BF840002
	s_endpgm                                                   // 000000218D04: BFB00000
		...

