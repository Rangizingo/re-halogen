000000000012e700 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 00000012E700: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 00000012E704: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000012E70C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 00000012E714: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 00000012E718: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000012E71C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 00000012E720: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000012E728: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000012E72C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 00000012E730: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 00000012E734: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000012E73C: 84928214
	s_add_u32 s25, s16, s18                                    // 00000012E740: 80191210
	s_addc_u32 s28, s17, s19                                   // 00000012E744: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 00000012E748: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000012E74C: BF870009
	s_add_u32 s25, s25, s20                                    // 00000012E750: 80191419
	s_addc_u32 s30, s28, s21                                   // 00000012E754: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 00000012E758: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000012E75C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 00000012E764: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000012E76C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 00000012E770: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 00000012E774: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000012E778: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000012E77C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 00000012E780: 821E191E
	.long 0xd7001f02                                           // 00000012E784: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 00000012E788: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000012E78C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 00000012E794: BE9E0080
	s_nop 0                                                    // 00000012E798: BF800000
	s_nop 0                                                    // 00000012E79C: BF800000
	s_nop 0                                                    // 00000012E7A0: BF800000
	s_nop 0                                                    // 00000012E7A4: BF800000
	s_nop 0                                                    // 00000012E7A8: BF800000
	s_nop 0                                                    // 00000012E7AC: BF800000
	s_nop 0                                                    // 00000012E7B0: BF800000
	s_nop 0                                                    // 00000012E7B4: BF800000
	s_nop 0                                                    // 00000012E7B8: BF800000
	s_nop 0                                                    // 00000012E7BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 00000012E7C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 00000012E7C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E7CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 00000012E7D0: 300C1089
	.long 0xd7006a06                                           // 00000012E7D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000012E7D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012E7DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 00000012E7E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000012E7E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 00000012E7F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 00000012E7F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 00000012E7FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 00000012E808: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000012E80C: BF8903F7
	ds_store_b32 v6, v9                                        // 00000012E810: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 00000012E818: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000012E81C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 00000012E820: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 00000012E824: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 00000012E82C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 00000012E834: 32040084
	s_mov_b32 s0, 0                                            // 00000012E838: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000012E83C: BF89FC07
	s_barrier                                                  // 00000012E840: BFBD0000
	buffer_gl0_inv                                             // 00000012E844: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000012E84C: BF02801E
	s_cbranch_scc1 12                                          // 00000012E850: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 00000012E854: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000012E85C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 00000012E864: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 00000012E868: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 00000012E870: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000012E874: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000012E878: 916A007E
	s_cbranch_vccz 2                                           // 00000012E87C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2600                                              // 00000012E880: BFA00A28 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a24>
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000012E884: 304E0A82
	s_add_i32 s0, s30, 63                                      // 00000012E888: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000012E88C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 00000012E894: 85218600
	s_add_u32 s34, s10, s24                                    // 00000012E898: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000012E89C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 00000012E8A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 00000012E8A4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 00000012E8AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 00000012E8B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000012E8B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 00000012E8B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 00000012E8BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 00000012E8C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 00000012E8C4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 00000012E8C8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 00000012E8D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 00000012E8D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 00000012E8DC: B00A0204
	.long 0xd7000b2c                                           // 00000012E8E0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 00000012E8E4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000012E8E8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 00000012E8EC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 00000012E8F4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 00000012E900: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 00000012E904: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 00000012E910: 3816500A
	.long 0xd7000a05                                           // 00000012E914: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 00000012E918: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012E91C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 00000012E920: D5207C06 00290001
	.long 0xd7000107                                           // 00000012E928: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 00000012E92C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012E930: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 00000012E934: D5207C08 0006180D
	.long 0xd7000109                                           // 00000012E93C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 00000012E940: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 00000012E944: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 00000012E94C: 84848E02
	.long 0xd700010b                                           // 00000012E950: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 00000012E954: 02021606
	s_add_u32 s4, s14, s4                                      // 00000012E958: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 00000012E95C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 00000012E964: 8205050F
	.long 0xd700010d                                           // 00000012E968: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 00000012E96C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012E970: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 00000012E974: D5207C0E 00050005
	.long 0xd700010f                                           // 00000012E97C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 00000012E980: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 00000012E988: D5207C10 00061880
	.long 0xd7000111                                           // 00000012E990: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 00000012E994: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012E99C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 00000012E9A0: D5207C12 00061880
	.long 0xd7000113                                           // 00000012E9A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 00000012E9AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 00000012E9B4: D5207C14 00061880
	.long 0xd7000115                                           // 00000012E9BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 00000012E9C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012E9C8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 00000012E9CC: D5207C16 00061880
	.long 0xd7000117                                           // 00000012E9D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 00000012E9D8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 00000012E9E0: D5207C18 00061880
	.long 0xd7000119                                           // 00000012E9E8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 00000012E9EC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012E9F4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 00000012E9F8: D5207C1A 00061880
	.long 0xd700011b                                           // 00000012EA00: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 00000012EA04: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 00000012EA0C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 00000012EA14: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000012EA18: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 00000012EA20: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 00000012EA24: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 00000012EA2C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 00000012EA34: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 00000012EA3C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 00000012EA44: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 00000012EA4C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 00000012EA54: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 00000012EA5C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 00000012EA64: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 00000012EA6C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 00000012EA74: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 00000012EA7C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 00000012EA84: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 00000012EA8C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 00000012EA94: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 00000012EA9C: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 00000012EAA0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 00000012EAA4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000012EAAC: BF870499
	s_add_i32 s6, s31, s1                                      // 00000012EAB0: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 00000012EAB4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000012EAB8: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 00000012EABC: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 00000012EAC0: 84078605
	s_add_u32 s10, s8, s10                                     // 00000012EAC4: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 00000012EAC8: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 00000012EACC: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 00000012EAD4: BE84206A
	s_cbranch_execz 77                                         // 00000012EAD8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510>
	v_or_b32_e32 v29, s7, v0                                   // 00000012EADC: 383A0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EAE0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 00000012EAE4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 00000012EAEC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EAF0: BF870091
	.long 0xd73c001d                                           // 00000012EAF4: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 00000012EAF8: 02023A82
	.long 0xd700011d                                           // 00000012EAFC: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 00000012EB00: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000012EB04: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 00000012EB08: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 00000012EB10: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012EB18: BF890007
	v_sub_f32_e32 v30, s6, v29                                 // 00000012EB1C: 083C3A06
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 00000012EB20: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000012EB2C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 00000012EB30: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 00000012EB3C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 00000012EB40: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 00000012EB4C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012EB50: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 00000012EB54: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 00000012EB60: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012EB64: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 00000012EB68: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 00000012EB70: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 00000012EB74: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 00000012EB7C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 00000012EB84: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 00000012EB88: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012EB8C: BF870193
	v_exp_f32_e32 v32, v32                                     // 00000012EB90: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 00000012EB94: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012EB98: BF870296
	.long 0xd71c0020                                           // 00000012EB9C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 00000012EBA0: 02024520
	.long 0xd71c001f                                           // 00000012EBA4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 00000012EBA8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012EBAC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 00000012EBB0: D501001F 00063E80
	.long 0xd41b0001                                           // 00000012EBB8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 00000012EBBC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 00000012EBC4: D5010020 00064080
	.long 0xd41e0001                                           // 00000012EBCC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 00000012EBD0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012EBD8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 00000012EBDC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 00000012EBE8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 00000012EBEC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 00000012EBF4: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 00000012EC00: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 00000012EC08: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012EC10: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 00000012EC14: CA100108 1E1C0107
	s_mov_b32 s10, 0                                           // 00000012EC1C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000012EC20: BF89FC07
	s_barrier                                                  // 00000012EC24: BFBD0000
	buffer_gl0_inv                                             // 00000012EC28: E0AC0000 00000000
	s_branch 15                                                // 00000012EC30: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012EC34: 8C7E047E
	.long 0xd700011d                                           // 00000012EC38: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 00000012EC3C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012EC44: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012EC48: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 00000012EC50: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000012EC54: BF08B70A
	s_mov_b32 s10, s1                                          // 00000012EC58: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 00000012EC5C: BF89FC07
	s_barrier                                                  // 00000012EC60: BFBD0000
	buffer_gl0_inv                                             // 00000012EC64: E0AC0000 00000000
	s_cbranch_scc1 702                                         // 00000012EC6C: BFA202BE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1068>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 00000012EC70: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 00000012EC78: CA100128 21220126
	s_mov_b32 s11, 0                                           // 00000012EC80: BE8B0080
	s_nop 0                                                    // 00000012EC84: BF800000
	s_nop 0                                                    // 00000012EC88: BF800000
	s_nop 0                                                    // 00000012EC8C: BF800000
	s_nop 0                                                    // 00000012EC90: BF800000
	s_nop 0                                                    // 00000012EC94: BF800000
	s_nop 0                                                    // 00000012EC98: BF800000
	s_nop 0                                                    // 00000012EC9C: BF800000
	s_nop 0                                                    // 00000012ECA0: BF800000
	s_nop 0                                                    // 00000012ECA4: BF800000
	s_nop 0                                                    // 00000012ECA8: BF800000
	s_nop 0                                                    // 00000012ECAC: BF800000
	s_nop 0                                                    // 00000012ECB0: BF800000
	s_nop 0                                                    // 00000012ECB4: BF800000
	s_nop 0                                                    // 00000012ECB8: BF800000
	s_nop 0                                                    // 00000012ECBC: BF800000
	global_load_b32 v35, v[31:32], off                         // 00000012ECC0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 00000012ECC8: 4A4444FF 00000080
	.long 0xd700011f                                           // 00000012ECD0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 00000012ECD4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012ECDC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 00000012ECE0: D5207C20 00064080
	.long 0xd4490004                                           // 00000012ECE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 00000012ECEC: 020244FF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000012ECF4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000012ECF8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 00000012ECFC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 00000012ED04: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000012ED0C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000012ED10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000012ED14: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000012ED18: BF89FC07
	s_barrier                                                  // 00000012ED1C: BFBD0000
	buffer_gl0_inv                                             // 00000012ED20: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000012ED28: BE842000
	s_cbranch_execz 65473                                      // 00000012ED2C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 00000012ED30: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 00000012ED38: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 00000012ED40: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 00000012ED48: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:8 offset1:9        // 00000012ED50: D8DC0908 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:10 offset1:11      // 00000012ED58: D8DC0B0A 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:12 offset1:13      // 00000012ED60: D8DC0D0C 4200002E
	ds_load_2addr_b32 v[68:69], v46 offset0:14 offset1:15      // 00000012ED68: D8DC0F0E 4400002E
	ds_load_2addr_b32 v[70:71], v1 offset1:17                  // 00000012ED70: D8DC1100 46000001
	ds_load_2addr_b32 v[72:73], v1 offset0:34 offset1:51       // 00000012ED78: D8DC3322 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:68 offset1:85       // 00000012ED80: D8DC5544 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:102 offset1:119     // 00000012ED88: D8DC7766 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:136 offset1:153     // 00000012ED90: D8DC9988 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:170 offset1:187     // 00000012ED98: D8DCBBAA 50000001
	ds_load_2addr_b32 v[82:83], v1 offset0:204 offset1:221     // 00000012EDA0: D8DCDDCC 52000001
	ds_load_2addr_b32 v[84:85], v1 offset0:238 offset1:255     // 00000012EDA8: D8DCFFEE 54000001
	ds_load_2addr_b32 v[88:89], v48 offset0:118 offset1:135    // 00000012EDB0: D8DC8776 58000030
	ds_load_2addr_b32 v[90:91], v48 offset0:152 offset1:169    // 00000012EDB8: D8DCA998 5A000030
	ds_load_2addr_b32 v[92:93], v48 offset0:186 offset1:203    // 00000012EDC0: D8DCCBBA 5C000030
	ds_load_2addr_b32 v[94:95], v48 offset0:220 offset1:237    // 00000012EDC8: D8DCEDDC 5E000030
	ds_load_2addr_b32 v[96:97], v49 offset0:126 offset1:143    // 00000012EDD0: D8DC8F7E 60000031
	v_or3_b32 v86, s10, s7, v2                                 // 00000012EDD8: D6580056 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EDE0: BF870091
	v_mad_u64_u32 v[86:87], null, v86, 48, s[2:3]              // 00000012EDE4: D6FE7C56 00096156
	.long 0xd73c0056                                           // 00000012EDEC: D73C0056
	v_cndmask_b32_e32 v1, 9, v86, vcc_lo                       // 00000012EDF0: 0202AC89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EDF4: BF870091
	.long 0xd7000156                                           // 00000012EDF8: D7000156
	v_cndmask_b32_e32 v1, v44, v86, vcc_lo                     // 00000012EDFC: 0202AD2C
	v_add_co_ci_u32_e64 v87, null, v45, v87, s1                // 00000012EE00: D5207C57 0006AF2D
	global_load_b32 v86, v[86:87], off                         // 00000012EE08: DC520000 567C0056
	s_waitcnt vmcnt(0) lgkmcnt(12)                             // 00000012EE10: BF8900C7
	v_fma_f32 v31, -v31, v70, v86                              // 00000012EE14: D613001F 255A8D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012EE1C: BF8700A1
	v_fma_f32 v31, -v32, v71, v31                              // 00000012EE20: D613001F 247E8F20
	s_waitcnt lgkmcnt(11)                                      // 00000012EE28: BF89FCB7
	v_fma_f32 v31, -v33, v72, v31                              // 00000012EE2C: D613001F 247E9121
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012EE34: BF8700A1
	v_fma_f32 v31, -v34, v73, v31                              // 00000012EE38: D613001F 247E9322
	s_waitcnt lgkmcnt(10)                                      // 00000012EE40: BF89FCA7
	v_fma_f32 v31, -v35, v74, v31                              // 00000012EE44: D613001F 247E9523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012EE4C: BF8700A1
	v_fma_f32 v31, -v36, v75, v31                              // 00000012EE50: D613001F 247E9724
	s_waitcnt lgkmcnt(9)                                       // 00000012EE58: BF89FC97
	v_fma_f32 v31, -v60, v76, v31                              // 00000012EE5C: D613001F 247E993C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012EE64: BF8700A1
	v_fma_f32 v31, -v61, v77, v31                              // 00000012EE68: D613001F 247E9B3D
	s_waitcnt lgkmcnt(8)                                       // 00000012EE70: BF89FC87
	v_fma_f32 v31, -v62, v78, v31                              // 00000012EE74: D613001F 247E9D3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012EE7C: BF8700A1
	v_fma_f32 v31, -v63, v79, v31                              // 00000012EE80: D613001F 247E9F3F
	s_waitcnt lgkmcnt(7)                                       // 00000012EE88: BF89FC77
	v_fma_f32 v64, -v64, v80, v31                              // 00000012EE8C: D6130040 247EA140
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 00000012EE94: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 00000012EE9C: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 00000012EEA4: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 00000012EEAC: D8DC1716 3C00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:24 offset1:25      // 00000012EEB4: D8DC1918 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:26 offset1:27      // 00000012EEBC: D8DC1B1A 4600002E
	ds_load_2addr_b32 v[72:73], v46 offset0:28 offset1:29      // 00000012EEC4: D8DC1D1C 4800002E
	ds_load_2addr_b32 v[74:75], v46 offset0:30 offset1:31      // 00000012EECC: D8DC1F1E 4A00002E
	ds_load_2addr_b32 v[76:77], v48 offset0:16 offset1:33      // 00000012EED4: D8DC2110 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:50 offset1:67      // 00000012EEDC: D8DC4332 4E000030
	ds_load_2addr_b32 v[86:87], v48 offset0:84 offset1:101     // 00000012EEE4: D8DC6554 56000030
	v_fma_f32 v64, -v65, v81, v64                              // 00000012EEEC: D6130040 2502A341
	s_waitcnt lgkmcnt(17)                                      // 00000012EEF4: BF89FD17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EEF8: BF870091
	v_fma_f32 v64, -v66, v82, v64                              // 00000012EEFC: D6130040 2502A542
	v_fma_f32 v64, -v67, v83, v64                              // 00000012EF04: D6130040 2502A743
	s_waitcnt lgkmcnt(16)                                      // 00000012EF0C: BF89FD07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EF10: BF870091
	v_fma_f32 v64, -v68, v84, v64                              // 00000012EF14: D6130040 2502A944
	v_fma_f32 v64, -v69, v85, v64                              // 00000012EF1C: D6130040 2502AB45
	s_waitcnt lgkmcnt(2)                                       // 00000012EF24: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EF28: BF870091
	v_fma_f32 v31, -v31, v76, v64                              // 00000012EF2C: D613001F 2502991F
	v_fma_f32 v31, -v32, v77, v31                              // 00000012EF34: D613001F 247E9B20
	s_waitcnt lgkmcnt(1)                                       // 00000012EF3C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EF40: BF870091
	v_fma_f32 v31, -v33, v78, v31                              // 00000012EF44: D613001F 247E9D21
	v_fma_f32 v31, -v34, v79, v31                              // 00000012EF4C: D613001F 247E9F22
	s_waitcnt lgkmcnt(0)                                       // 00000012EF54: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EF58: BF870091
	v_fma_f32 v31, -v35, v86, v31                              // 00000012EF5C: D613001F 247EAD23
	v_fma_f32 v31, -v36, v87, v31                              // 00000012EF64: D613001F 247EAF24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EF6C: BF870091
	v_fma_f32 v31, -v60, v88, v31                              // 00000012EF70: D613001F 247EB13C
	v_fma_f32 v31, -v61, v89, v31                              // 00000012EF78: D613001F 247EB33D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EF80: BF870091
	v_fma_f32 v31, -v62, v90, v31                              // 00000012EF84: D613001F 247EB53E
	v_fma_f32 v31, -v63, v91, v31                              // 00000012EF8C: D613001F 247EB73F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012EF94: BF870001
	v_fma_f32 v70, -v70, v92, v31                              // 00000012EF98: D6130046 247EB946
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 00000012EFA0: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 00000012EFA8: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 00000012EFB0: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 00000012EFB8: D8DC2726 3C00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:40 offset1:41      // 00000012EFC0: D8DC2928 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:42 offset1:43      // 00000012EFC8: D8DC2B2A 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:44 offset1:45      // 00000012EFD0: D8DC2D2C 4200002E
	ds_load_2addr_b32 v[68:69], v46 offset0:46 offset1:47      // 00000012EFD8: D8DC2F2E 4400002E
	ds_load_2addr_b32 v[76:77], v50 offset0:32 offset1:49      // 00000012EFE0: D8DC3120 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:66 offset1:83      // 00000012EFE8: D8DC5342 4E000032
	ds_load_2addr_b32 v[80:81], v50 offset0:100 offset1:117    // 00000012EFF0: D8DC7564 50000032
	ds_load_2addr_b32 v[82:83], v50 offset0:134 offset1:151    // 00000012EFF8: D8DC9786 52000032
	ds_load_2addr_b32 v[84:85], v50 offset0:168 offset1:185    // 00000012F000: D8DCB9A8 54000032
	ds_load_2addr_b32 v[86:87], v50 offset0:202 offset1:219    // 00000012F008: D8DCDBCA 56000032
	ds_load_2addr_b32 v[88:89], v50 offset0:236 offset1:253    // 00000012F010: D8DCFDEC 58000032
	ds_load_2addr_b32 v[90:91], v51 offset0:14 offset1:31      // 00000012F018: D8DC1F0E 5A000033
	v_fma_f32 v70, -v71, v93, v70                              // 00000012F020: D6130046 251ABB47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F028: BF870091
	v_fma_f32 v70, -v72, v94, v70                              // 00000012F02C: D6130046 251ABD48
	v_fma_f32 v70, -v73, v95, v70                              // 00000012F034: D6130046 251ABF49
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F03C: BF870091
	v_fma_f32 v70, -v74, v96, v70                              // 00000012F040: D6130046 251AC14A
	v_fma_f32 v70, -v75, v97, v70                              // 00000012F048: D6130046 251AC34B
	s_waitcnt lgkmcnt(7)                                       // 00000012F050: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F054: BF870091
	v_fma_f32 v31, -v31, v76, v70                              // 00000012F058: D613001F 251A991F
	v_fma_f32 v31, -v32, v77, v31                              // 00000012F060: D613001F 247E9B20
	s_waitcnt lgkmcnt(6)                                       // 00000012F068: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F06C: BF870091
	v_fma_f32 v31, -v33, v78, v31                              // 00000012F070: D613001F 247E9D21
	v_fma_f32 v31, -v34, v79, v31                              // 00000012F078: D613001F 247E9F22
	s_waitcnt lgkmcnt(5)                                       // 00000012F080: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F084: BF870091
	v_fma_f32 v31, -v35, v80, v31                              // 00000012F088: D613001F 247EA123
	v_fma_f32 v31, -v36, v81, v31                              // 00000012F090: D613001F 247EA324
	s_waitcnt lgkmcnt(4)                                       // 00000012F098: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F09C: BF870091
	v_fma_f32 v31, -v60, v82, v31                              // 00000012F0A0: D613001F 247EA53C
	v_fma_f32 v31, -v61, v83, v31                              // 00000012F0A8: D613001F 247EA73D
	s_waitcnt lgkmcnt(3)                                       // 00000012F0B0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F0B4: BF870091
	v_fma_f32 v31, -v62, v84, v31                              // 00000012F0B8: D613001F 247EA93E
	v_fma_f32 v31, -v63, v85, v31                              // 00000012F0C0: D613001F 247EAB3F
	s_waitcnt lgkmcnt(2)                                       // 00000012F0C8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012F0CC: BF870001
	v_fma_f32 v64, -v64, v86, v31                              // 00000012F0D0: D6130040 247EAD40
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 00000012F0D8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 00000012F0E0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 00000012F0E8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 00000012F0F0: D8DC3736 3C00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:56 offset1:57      // 00000012F0F8: D8DC3938 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:58 offset1:59      // 00000012F100: D8DC3B3A 4600002E
	ds_load_2addr_b32 v[72:73], v46 offset0:60 offset1:61      // 00000012F108: D8DC3D3C 4800002E
	ds_load_2addr_b32 v[74:75], v46 offset0:62 offset1:63      // 00000012F110: D8DC3F3E 4A00002E
	ds_load_2addr_b32 v[76:77], v51 offset0:48 offset1:65      // 00000012F118: D8DC4130 4C000033
	ds_load_2addr_b32 v[78:79], v51 offset0:82 offset1:99      // 00000012F120: D8DC6352 4E000033
	ds_load_2addr_b32 v[80:81], v51 offset0:116 offset1:133    // 00000012F128: D8DC8574 50000033
	ds_load_2addr_b32 v[82:83], v51 offset0:150 offset1:167    // 00000012F130: D8DCA796 52000033
	ds_load_2addr_b32 v[84:85], v51 offset0:184 offset1:201    // 00000012F138: D8DCC9B8 54000033
	ds_load_2addr_b32 v[92:93], v51 offset0:218 offset1:235    // 00000012F140: D8DCEBDA 5C000033
	ds_load_2addr_b32 v[94:95], v52 offset0:124 offset1:141    // 00000012F148: D8DC8D7C 5E000034
	ds_load_2addr_b32 v[96:97], v53 offset0:30 offset1:47      // 00000012F150: D8DC2F1E 60000035
	v_fma_f32 v64, -v65, v87, v64                              // 00000012F158: D6130040 2502AF41
	s_waitcnt lgkmcnt(17)                                      // 00000012F160: BF89FD17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F164: BF870091
	v_fma_f32 v64, -v66, v88, v64                              // 00000012F168: D6130040 2502B142
	v_fma_f32 v64, -v67, v89, v64                              // 00000012F170: D6130040 2502B343
	s_waitcnt lgkmcnt(16)                                      // 00000012F178: BF89FD07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F17C: BF870091
	v_fma_f32 v64, -v68, v90, v64                              // 00000012F180: D6130040 2502B544
	v_fma_f32 v64, -v69, v91, v64                              // 00000012F188: D6130040 2502B745
	s_waitcnt lgkmcnt(7)                                       // 00000012F190: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F194: BF870091
	v_fma_f32 v31, -v31, v76, v64                              // 00000012F198: D613001F 2502991F
	v_fma_f32 v31, -v32, v77, v31                              // 00000012F1A0: D613001F 247E9B20
	s_waitcnt lgkmcnt(6)                                       // 00000012F1A8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F1AC: BF870091
	v_fma_f32 v31, -v33, v78, v31                              // 00000012F1B0: D613001F 247E9D21
	v_fma_f32 v31, -v34, v79, v31                              // 00000012F1B8: D613001F 247E9F22
	s_waitcnt lgkmcnt(5)                                       // 00000012F1C0: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F1C4: BF870091
	v_fma_f32 v31, -v35, v80, v31                              // 00000012F1C8: D613001F 247EA123
	v_fma_f32 v31, -v36, v81, v31                              // 00000012F1D0: D613001F 247EA324
	s_waitcnt lgkmcnt(4)                                       // 00000012F1D8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F1DC: BF870091
	v_fma_f32 v31, -v60, v82, v31                              // 00000012F1E0: D613001F 247EA53C
	v_fma_f32 v31, -v61, v83, v31                              // 00000012F1E8: D613001F 247EA73D
	s_waitcnt lgkmcnt(3)                                       // 00000012F1F0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F1F4: BF870091
	v_fma_f32 v31, -v62, v84, v31                              // 00000012F1F8: D613001F 247EA93E
	v_fma_f32 v31, -v63, v85, v31                              // 00000012F200: D613001F 247EAB3F
	s_waitcnt lgkmcnt(2)                                       // 00000012F208: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012F20C: BF870001
	v_fma_f32 v70, -v70, v92, v31                              // 00000012F210: D6130046 247EB946
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 00000012F218: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 00000012F220: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 00000012F228: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 00000012F230: D8DC4746 3C00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:72 offset1:73      // 00000012F238: D8DC4948 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:74 offset1:75      // 00000012F240: D8DC4B4A 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:76 offset1:77      // 00000012F248: D8DC4D4C 4200002E
	ds_load_2addr_b32 v[68:69], v46 offset0:78 offset1:79      // 00000012F250: D8DC4F4E 4400002E
	ds_load_2addr_b32 v[76:77], v53 offset0:64 offset1:81      // 00000012F258: D8DC5140 4C000035
	ds_load_2addr_b32 v[78:79], v53 offset0:98 offset1:115     // 00000012F260: D8DC7362 4E000035
	ds_load_2addr_b32 v[80:81], v53 offset0:132 offset1:149    // 00000012F268: D8DC9584 50000035
	ds_load_2addr_b32 v[82:83], v53 offset0:166 offset1:183    // 00000012F270: D8DCB7A6 52000035
	ds_load_2addr_b32 v[84:85], v53 offset0:200 offset1:217    // 00000012F278: D8DCD9C8 54000035
	ds_load_2addr_b32 v[86:87], v53 offset0:234 offset1:251    // 00000012F280: D8DCFBEA 56000035
	ds_load_2addr_b32 v[88:89], v54 offset0:12 offset1:29      // 00000012F288: D8DC1D0C 58000036
	ds_load_2addr_b32 v[90:91], v54 offset0:46 offset1:63      // 00000012F290: D8DC3F2E 5A000036
	v_fma_f32 v70, -v71, v93, v70                              // 00000012F298: D6130046 251ABB47
	s_waitcnt lgkmcnt(17)                                      // 00000012F2A0: BF89FD17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F2A4: BF870091
	v_fma_f32 v70, -v72, v94, v70                              // 00000012F2A8: D6130046 251ABD48
	v_fma_f32 v70, -v73, v95, v70                              // 00000012F2B0: D6130046 251ABF49
	s_waitcnt lgkmcnt(16)                                      // 00000012F2B8: BF89FD07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F2BC: BF870091
	v_fma_f32 v70, -v74, v96, v70                              // 00000012F2C0: D6130046 251AC14A
	v_fma_f32 v70, -v75, v97, v70                              // 00000012F2C8: D6130046 251AC34B
	s_waitcnt lgkmcnt(7)                                       // 00000012F2D0: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F2D4: BF870091
	v_fma_f32 v31, -v31, v76, v70                              // 00000012F2D8: D613001F 251A991F
	v_fma_f32 v31, -v32, v77, v31                              // 00000012F2E0: D613001F 247E9B20
	s_waitcnt lgkmcnt(6)                                       // 00000012F2E8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F2EC: BF870091
	v_fma_f32 v31, -v33, v78, v31                              // 00000012F2F0: D613001F 247E9D21
	v_fma_f32 v31, -v34, v79, v31                              // 00000012F2F8: D613001F 247E9F22
	s_waitcnt lgkmcnt(5)                                       // 00000012F300: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F304: BF870091
	v_fma_f32 v31, -v35, v80, v31                              // 00000012F308: D613001F 247EA123
	v_fma_f32 v31, -v36, v81, v31                              // 00000012F310: D613001F 247EA324
	s_waitcnt lgkmcnt(4)                                       // 00000012F318: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F31C: BF870091
	v_fma_f32 v31, -v60, v82, v31                              // 00000012F320: D613001F 247EA53C
	v_fma_f32 v31, -v61, v83, v31                              // 00000012F328: D613001F 247EA73D
	s_waitcnt lgkmcnt(3)                                       // 00000012F330: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F334: BF870091
	v_fma_f32 v31, -v62, v84, v31                              // 00000012F338: D613001F 247EA93E
	v_fma_f32 v31, -v63, v85, v31                              // 00000012F340: D613001F 247EAB3F
	s_waitcnt lgkmcnt(2)                                       // 00000012F348: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012F34C: BF870001
	v_fma_f32 v64, -v64, v86, v31                              // 00000012F350: D6130040 247EAD40
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 00000012F358: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 00000012F360: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 00000012F368: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 00000012F370: D8DC5756 3C00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:88 offset1:89      // 00000012F378: D8DC5958 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:90 offset1:91      // 00000012F380: D8DC5B5A 4600002E
	ds_load_2addr_b32 v[72:73], v46 offset0:92 offset1:93      // 00000012F388: D8DC5D5C 4800002E
	ds_load_2addr_b32 v[74:75], v46 offset0:94 offset1:95      // 00000012F390: D8DC5F5E 4A00002E
	ds_load_2addr_b32 v[76:77], v54 offset0:80 offset1:97      // 00000012F398: D8DC6150 4C000036
	ds_load_2addr_b32 v[78:79], v54 offset0:114 offset1:131    // 00000012F3A0: D8DC8372 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:148 offset1:165    // 00000012F3A8: D8DCA594 50000036
	ds_load_2addr_b32 v[82:83], v54 offset0:182 offset1:199    // 00000012F3B0: D8DCC7B6 52000036
	ds_load_2addr_b32 v[84:85], v54 offset0:216 offset1:233    // 00000012F3B8: D8DCE9D8 54000036
	ds_load_2addr_b32 v[92:93], v55 offset0:122 offset1:139    // 00000012F3C0: D8DC8B7A 5C000037
	ds_load_2addr_b32 v[94:95], v56 offset0:28 offset1:45      // 00000012F3C8: D8DC2D1C 5E000038
	ds_load_2addr_b32 v[96:97], v56 offset0:62 offset1:79      // 00000012F3D0: D8DC4F3E 60000038
	v_fma_f32 v64, -v65, v87, v64                              // 00000012F3D8: D6130040 2502AF41
	s_waitcnt lgkmcnt(17)                                      // 00000012F3E0: BF89FD17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F3E4: BF870091
	v_fma_f32 v64, -v66, v88, v64                              // 00000012F3E8: D6130040 2502B142
	v_fma_f32 v64, -v67, v89, v64                              // 00000012F3F0: D6130040 2502B343
	s_waitcnt lgkmcnt(16)                                      // 00000012F3F8: BF89FD07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F3FC: BF870091
	v_fma_f32 v64, -v68, v90, v64                              // 00000012F400: D6130040 2502B544
	v_fma_f32 v64, -v69, v91, v64                              // 00000012F408: D6130040 2502B745
	s_waitcnt lgkmcnt(7)                                       // 00000012F410: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F414: BF870091
	v_fma_f32 v31, -v31, v76, v64                              // 00000012F418: D613001F 2502991F
	v_fma_f32 v31, -v32, v77, v31                              // 00000012F420: D613001F 247E9B20
	s_waitcnt lgkmcnt(6)                                       // 00000012F428: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F42C: BF870091
	v_fma_f32 v31, -v33, v78, v31                              // 00000012F430: D613001F 247E9D21
	v_fma_f32 v31, -v34, v79, v31                              // 00000012F438: D613001F 247E9F22
	s_waitcnt lgkmcnt(5)                                       // 00000012F440: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F444: BF870091
	v_fma_f32 v31, -v35, v80, v31                              // 00000012F448: D613001F 247EA123
	v_fma_f32 v31, -v36, v81, v31                              // 00000012F450: D613001F 247EA324
	s_waitcnt lgkmcnt(4)                                       // 00000012F458: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F45C: BF870091
	v_fma_f32 v31, -v60, v82, v31                              // 00000012F460: D613001F 247EA53C
	v_fma_f32 v31, -v61, v83, v31                              // 00000012F468: D613001F 247EA73D
	s_waitcnt lgkmcnt(3)                                       // 00000012F470: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F474: BF870091
	v_fma_f32 v31, -v62, v84, v31                              // 00000012F478: D613001F 247EA93E
	v_fma_f32 v31, -v63, v85, v31                              // 00000012F480: D613001F 247EAB3F
	s_waitcnt lgkmcnt(2)                                       // 00000012F488: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012F48C: BF870001
	v_fma_f32 v70, -v70, v92, v31                              // 00000012F490: D6130046 247EB946
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 00000012F498: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 00000012F4A0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 00000012F4A8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 00000012F4B0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:104 offset1:105    // 00000012F4B8: D8DC6968 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 00000012F4C0: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:108 offset1:109    // 00000012F4C8: D8DC6D6C 4200002E
	ds_load_2addr_b32 v[68:69], v46 offset0:110 offset1:111    // 00000012F4D0: D8DC6F6E 4400002E
	ds_load_2addr_b32 v[76:77], v56 offset0:96 offset1:113     // 00000012F4D8: D8DC7160 4C000038
	ds_load_2addr_b32 v[78:79], v56 offset0:130 offset1:147    // 00000012F4E0: D8DC9382 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:164 offset1:181    // 00000012F4E8: D8DCB5A4 50000038
	ds_load_2addr_b32 v[82:83], v56 offset0:198 offset1:215    // 00000012F4F0: D8DCD7C6 52000038
	ds_load_2addr_b32 v[84:85], v56 offset0:232 offset1:249    // 00000012F4F8: D8DCF9E8 54000038
	ds_load_2addr_b32 v[86:87], v57 offset0:10 offset1:27      // 00000012F500: D8DC1B0A 56000039
	ds_load_2addr_b32 v[88:89], v57 offset0:44 offset1:61      // 00000012F508: D8DC3D2C 58000039
	ds_load_2addr_b32 v[90:91], v57 offset0:78 offset1:95      // 00000012F510: D8DC5F4E 5A000039
	v_fma_f32 v70, -v71, v93, v70                              // 00000012F518: D6130046 251ABB47
	s_waitcnt lgkmcnt(17)                                      // 00000012F520: BF89FD17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F524: BF870091
	v_fma_f32 v70, -v72, v94, v70                              // 00000012F528: D6130046 251ABD48
	v_fma_f32 v70, -v73, v95, v70                              // 00000012F530: D6130046 251ABF49
	s_waitcnt lgkmcnt(16)                                      // 00000012F538: BF89FD07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F53C: BF870091
	v_fma_f32 v70, -v74, v96, v70                              // 00000012F540: D6130046 251AC14A
	v_fma_f32 v70, -v75, v97, v70                              // 00000012F548: D6130046 251AC34B
	s_waitcnt lgkmcnt(7)                                       // 00000012F550: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F554: BF870091
	v_fma_f32 v31, -v31, v76, v70                              // 00000012F558: D613001F 251A991F
	v_fma_f32 v31, -v32, v77, v31                              // 00000012F560: D613001F 247E9B20
	s_waitcnt lgkmcnt(6)                                       // 00000012F568: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F56C: BF870091
	v_fma_f32 v31, -v33, v78, v31                              // 00000012F570: D613001F 247E9D21
	v_fma_f32 v31, -v34, v79, v31                              // 00000012F578: D613001F 247E9F22
	s_waitcnt lgkmcnt(5)                                       // 00000012F580: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F584: BF870091
	v_fma_f32 v31, -v35, v80, v31                              // 00000012F588: D613001F 247EA123
	v_fma_f32 v31, -v36, v81, v31                              // 00000012F590: D613001F 247EA324
	s_waitcnt lgkmcnt(4)                                       // 00000012F598: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F59C: BF870091
	v_fma_f32 v31, -v60, v82, v31                              // 00000012F5A0: D613001F 247EA53C
	v_fma_f32 v31, -v61, v83, v31                              // 00000012F5A8: D613001F 247EA73D
	s_waitcnt lgkmcnt(3)                                       // 00000012F5B0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F5B4: BF870091
	v_fma_f32 v31, -v62, v84, v31                              // 00000012F5B8: D613001F 247EA93E
	v_fma_f32 v31, -v63, v85, v31                              // 00000012F5C0: D613001F 247EAB3F
	s_waitcnt lgkmcnt(2)                                       // 00000012F5C8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012F5CC: BF870001
	v_fma_f32 v64, -v64, v86, v31                              // 00000012F5D0: D6130040 247EAD40
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 00000012F5D8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 00000012F5E0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 00000012F5E8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 00000012F5F0: D8DC7776 3C00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:120 offset1:121    // 00000012F5F8: D8DC7978 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:122 offset1:123    // 00000012F600: D8DC7B7A 4600002E
	ds_load_2addr_b32 v[72:73], v46 offset0:124 offset1:125    // 00000012F608: D8DC7D7C 4800002E
	ds_load_2addr_b32 v[74:75], v46 offset0:126 offset1:127    // 00000012F610: D8DC7F7E 4A00002E
	ds_load_2addr_b32 v[76:77], v57 offset0:112 offset1:129    // 00000012F618: D8DC8170 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:146 offset1:163    // 00000012F620: D8DCA392 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:180 offset1:197    // 00000012F628: D8DCC5B4 50000039
	ds_load_2addr_b32 v[82:83], v57 offset0:214 offset1:231    // 00000012F630: D8DCE7D6 52000039
	ds_load_2addr_b32 v[84:85], v58 offset0:120 offset1:137    // 00000012F638: D8DC8978 5400003A
	ds_load_2addr_b32 v[92:93], v59 offset0:26 offset1:43      // 00000012F640: D8DC2B1A 5C00003B
	ds_load_2addr_b32 v[94:95], v59 offset0:60 offset1:77      // 00000012F648: D8DC4D3C 5E00003B
	ds_load_2addr_b32 v[96:97], v59 offset0:94 offset1:111     // 00000012F650: D8DC6F5E 6000003B
	v_fma_f32 v64, -v65, v87, v64                              // 00000012F658: D6130040 2502AF41
	s_waitcnt lgkmcnt(17)                                      // 00000012F660: BF89FD17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F664: BF870091
	v_fma_f32 v64, -v66, v88, v64                              // 00000012F668: D6130040 2502B142
	v_fma_f32 v64, -v67, v89, v64                              // 00000012F670: D6130040 2502B343
	s_waitcnt lgkmcnt(16)                                      // 00000012F678: BF89FD07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F67C: BF870091
	v_fma_f32 v64, -v68, v90, v64                              // 00000012F680: D6130040 2502B544
	v_fma_f32 v64, -v69, v91, v64                              // 00000012F688: D6130040 2502B745
	s_waitcnt lgkmcnt(7)                                       // 00000012F690: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F694: BF870091
	v_fma_f32 v31, -v31, v76, v64                              // 00000012F698: D613001F 2502991F
	v_fma_f32 v31, -v32, v77, v31                              // 00000012F6A0: D613001F 247E9B20
	s_waitcnt lgkmcnt(6)                                       // 00000012F6A8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F6AC: BF870091
	v_fma_f32 v31, -v33, v78, v31                              // 00000012F6B0: D613001F 247E9D21
	v_fma_f32 v31, -v34, v79, v31                              // 00000012F6B8: D613001F 247E9F22
	s_waitcnt lgkmcnt(5)                                       // 00000012F6C0: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F6C4: BF870091
	v_fma_f32 v31, -v35, v80, v31                              // 00000012F6C8: D613001F 247EA123
	v_fma_f32 v31, -v36, v81, v31                              // 00000012F6D0: D613001F 247EA324
	s_waitcnt lgkmcnt(4)                                       // 00000012F6D8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F6DC: BF870091
	v_fma_f32 v31, -v60, v82, v31                              // 00000012F6E0: D613001F 247EA53C
	v_fma_f32 v31, -v61, v83, v31                              // 00000012F6E8: D613001F 247EA73D
	s_waitcnt lgkmcnt(3)                                       // 00000012F6F0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F6F4: BF870091
	v_fma_f32 v31, -v62, v84, v31                              // 00000012F6F8: D613001F 247EA93E
	v_fma_f32 v31, -v63, v85, v31                              // 00000012F700: D613001F 247EAB3F
	s_waitcnt lgkmcnt(2)                                       // 00000012F708: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F70C: BF870091
	v_fma_f32 v31, -v70, v92, v31                              // 00000012F710: D613001F 247EB946
	v_fma_f32 v31, -v71, v93, v31                              // 00000012F718: D613001F 247EBB47
	s_waitcnt lgkmcnt(1)                                       // 00000012F720: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F724: BF870091
	v_fma_f32 v31, -v72, v94, v31                              // 00000012F728: D613001F 247EBD48
	v_fma_f32 v31, -v73, v95, v31                              // 00000012F730: D613001F 247EBF49
	s_waitcnt lgkmcnt(0)                                       // 00000012F738: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012F73C: BF870121
	v_fma_f32 v33, -v74, v96, v31                              // 00000012F740: D6130021 247EC14A
	v_mad_u64_u32 v[31:32], null, 0x44, s10, v[4:5]            // 00000012F748: D6FE7C1F 041014FF 00000044
	v_fma_f32 v32, -v75, v97, v33                              // 00000012F754: D6130020 2486C34B
	ds_store_b32 v31, v32                                      // 00000012F75C: D8340000 0000201F
	s_branch 64819                                             // 00000012F764: BFA0FD33 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_mov_b32_e32 v30, v14                                     // 00000012F768: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 00000012F76C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 00000012F774: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 00000012F778: 7E46032B
	s_mov_b32 s10, 0                                           // 00000012F77C: BE8A0080
	s_branch 21                                                // 00000012F780: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10d8>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000012F784: 8C7E0B7E
	.long 0xd700011f                                           // 00000012F788: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 00000012F78C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012F794: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 00000012F798: D5207C20 00064080
	.long 0xd700011d                                           // 00000012F7A0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 00000012F7A4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 00000012F7AC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000012F7B0: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 00000012F7B8: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000012F7BC: BF08B70A
	s_mov_b32 s10, s1                                          // 00000012F7C0: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 00000012F7C4: BC7C0000
	s_barrier                                                  // 00000012F7C8: BFBD0000
	buffer_gl0_inv                                             // 00000012F7CC: E0AC0000 00000000
	s_cbranch_scc1 602                                         // 00000012F7D4: BFA2025A <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a40>
	s_delay_alu instid0(VALU_DEP_2)                            // 00000012F7D8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 00000012F7DC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 00000012F7E4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 00000012F7E8: 7E780326
	s_mov_b32 s11, 0                                           // 00000012F7EC: BE8B0080
	s_nop 0                                                    // 00000012F7F0: BF800000
	s_nop 0                                                    // 00000012F7F4: BF800000
	s_nop 0                                                    // 00000012F7F8: BF800000
	s_nop 0                                                    // 00000012F7FC: BF800000
	global_load_b32 v61, v[33:34], off                         // 00000012F800: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 00000012F808: 4A7878FF 00000080
	.long 0xd7000121                                           // 00000012F810: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 00000012F814: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012F81C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 00000012F820: D5207C22 00064480
	.long 0xd4490004                                           // 00000012F828: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 00000012F82C: 020278FF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000012F834: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000012F838: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 00000012F83C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 00000012F844: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000012F84C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000012F850: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000012F854: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000012F858: BF89FC07
	s_barrier                                                  // 00000012F85C: BFBD0000
	buffer_gl0_inv                                             // 00000012F860: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 00000012F868: BE8B2000
	s_cbranch_execz 65477                                      // 00000012F86C: BFA5FFC5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1084>
	v_or_b32_e32 v33, s10, v2                                  // 00000012F870: 3842040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F874: BF870091
	v_or_b32_e32 v36, s7, v33                                  // 00000012F878: 38484207
	.long 0xd4440001                                           // 00000012F87C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 00000012F880: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 00000012F884: 8B7E017E
	s_cbranch_execz 65470                                      // 00000012F888: BFA5FFBE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1084>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 00000012F88C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 00000012F894: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:2 offset1:3        // 00000012F89C: D8DC0302 4000002E
	ds_load_2addr_b32 v[72:73], v1 offset0:34 offset1:51       // 00000012F8A4: D8DC3322 48000001
	ds_load_2addr_b32 v[66:67], v46 offset0:4 offset1:5        // 00000012F8AC: D8DC0504 4200002E
	ds_load_2addr_b32 v[68:69], v46 offset0:6 offset1:7        // 00000012F8B4: D8DC0706 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:8 offset1:9        // 00000012F8BC: D8DC0908 4600002E
	ds_load_2addr_b32 v[74:75], v46 offset0:10 offset1:11      // 00000012F8C4: D8DC0B0A 4A00002E
	ds_load_2addr_b32 v[76:77], v46 offset0:12 offset1:13      // 00000012F8CC: D8DC0D0C 4C00002E
	ds_load_2addr_b32 v[78:79], v46 offset0:14 offset1:15      // 00000012F8D4: D8DC0F0E 4E00002E
	ds_load_2addr_b32 v[80:81], v1 offset0:68 offset1:85       // 00000012F8DC: D8DC5544 50000001
	ds_load_2addr_b32 v[82:83], v1 offset0:102 offset1:119     // 00000012F8E4: D8DC7766 52000001
	ds_load_2addr_b32 v[84:85], v1 offset0:136 offset1:153     // 00000012F8EC: D8DC9988 54000001
	ds_load_2addr_b32 v[86:87], v1 offset0:170 offset1:187     // 00000012F8F4: D8DCBBAA 56000001
	ds_load_2addr_b32 v[88:89], v1 offset0:204 offset1:221     // 00000012F8FC: D8DCDDCC 58000001
	ds_load_2addr_b32 v[90:91], v1 offset0:238 offset1:255     // 00000012F904: D8DCFFEE 5A000001
	s_mov_b32 s12, 0                                           // 00000012F90C: BE8C0080
	s_waitcnt lgkmcnt(14)                                      // 00000012F910: BF89FCE7
	v_fma_f32 v92, v60, v62, 0                                 // 00000012F914: D613005C 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012F91C: BF8700A1
	v_fmac_f32_e32 v92, v61, v63                               // 00000012F920: 56B87F3D
	s_waitcnt lgkmcnt(12)                                      // 00000012F924: BF89FCC7
	v_fmac_f32_e32 v92, v64, v72                               // 00000012F928: 56B89140
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012F92C: BF8700A1
	v_fmac_f32_e32 v92, v65, v73                               // 00000012F930: 56B89341
	s_waitcnt lgkmcnt(5)                                       // 00000012F934: BF89FC57
	v_fmac_f32_e32 v92, v66, v80                               // 00000012F938: 56B8A142
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012F93C: BF8700A1
	v_fmac_f32_e32 v92, v67, v81                               // 00000012F940: 56B8A343
	s_waitcnt lgkmcnt(4)                                       // 00000012F944: BF89FC47
	v_fmac_f32_e32 v92, v68, v82                               // 00000012F948: 56B8A544
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012F94C: BF8700A1
	v_fmac_f32_e32 v92, v69, v83                               // 00000012F950: 56B8A745
	s_waitcnt lgkmcnt(3)                                       // 00000012F954: BF89FC37
	v_fmac_f32_e32 v92, v70, v84                               // 00000012F958: 56B8A946
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012F95C: BF8700A1
	v_fmac_f32_e32 v92, v71, v85                               // 00000012F960: 56B8AB47
	s_waitcnt lgkmcnt(2)                                       // 00000012F964: BF89FC27
	v_fmac_f32_e32 v92, v74, v86                               // 00000012F968: 56B8AD4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012F96C: BF8700A1
	v_fmac_f32_e32 v92, v75, v87                               // 00000012F970: 56B8AF4B
	s_waitcnt lgkmcnt(1)                                       // 00000012F974: BF89FC17
	v_fmac_f32_e32 v92, v76, v88                               // 00000012F978: 56B8B14C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012F97C: BF8700A1
	v_fmac_f32_e32 v92, v77, v89                               // 00000012F980: 56B8B34D
	s_waitcnt lgkmcnt(0)                                       // 00000012F984: BF89FC07
	v_fmac_f32_e32 v92, v78, v90                               // 00000012F988: 56B8B54E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012F98C: BF870001
	v_fmac_f32_e32 v92, v79, v91                               // 00000012F990: 56B8B74F
	ds_load_2addr_b32 v[60:61], v46 offset0:16 offset1:17      // 00000012F994: D8DC1110 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:16 offset1:33      // 00000012F99C: D8DC2110 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:18 offset1:19      // 00000012F9A4: D8DC1312 4000002E
	ds_load_2addr_b32 v[72:73], v48 offset0:50 offset1:67      // 00000012F9AC: D8DC4332 48000030
	ds_load_2addr_b32 v[66:67], v46 offset0:20 offset1:21      // 00000012F9B4: D8DC1514 4200002E
	ds_load_2addr_b32 v[68:69], v46 offset0:22 offset1:23      // 00000012F9BC: D8DC1716 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:24 offset1:25      // 00000012F9C4: D8DC1918 4600002E
	ds_load_2addr_b32 v[74:75], v46 offset0:26 offset1:27      // 00000012F9CC: D8DC1B1A 4A00002E
	ds_load_2addr_b32 v[76:77], v46 offset0:28 offset1:29      // 00000012F9D4: D8DC1D1C 4C00002E
	ds_load_2addr_b32 v[78:79], v46 offset0:30 offset1:31      // 00000012F9DC: D8DC1F1E 4E00002E
	ds_load_2addr_b32 v[80:81], v48 offset0:84 offset1:101     // 00000012F9E4: D8DC6554 50000030
	ds_load_2addr_b32 v[82:83], v48 offset0:118 offset1:135    // 00000012F9EC: D8DC8776 52000030
	ds_load_2addr_b32 v[84:85], v48 offset0:152 offset1:169    // 00000012F9F4: D8DCA998 54000030
	ds_load_2addr_b32 v[86:87], v48 offset0:186 offset1:203    // 00000012F9FC: D8DCCBBA 56000030
	ds_load_2addr_b32 v[88:89], v48 offset0:220 offset1:237    // 00000012FA04: D8DCEDDC 58000030
	ds_load_2addr_b32 v[90:91], v49 offset0:126 offset1:143    // 00000012FA0C: D8DC8F7E 5A000031
	s_waitcnt lgkmcnt(14)                                      // 00000012FA14: BF89FCE7
	v_fmac_f32_e32 v92, v60, v62                               // 00000012FA18: 56B87D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FA1C: BF8700A1
	v_fmac_f32_e32 v92, v61, v63                               // 00000012FA20: 56B87F3D
	s_waitcnt lgkmcnt(12)                                      // 00000012FA24: BF89FCC7
	v_fmac_f32_e32 v92, v64, v72                               // 00000012FA28: 56B89140
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FA2C: BF8700A1
	v_fmac_f32_e32 v92, v65, v73                               // 00000012FA30: 56B89341
	s_waitcnt lgkmcnt(5)                                       // 00000012FA34: BF89FC57
	v_fmac_f32_e32 v92, v66, v80                               // 00000012FA38: 56B8A142
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FA3C: BF8700A1
	v_fmac_f32_e32 v92, v67, v81                               // 00000012FA40: 56B8A343
	s_waitcnt lgkmcnt(4)                                       // 00000012FA44: BF89FC47
	v_fmac_f32_e32 v92, v68, v82                               // 00000012FA48: 56B8A544
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FA4C: BF8700A1
	v_fmac_f32_e32 v92, v69, v83                               // 00000012FA50: 56B8A745
	s_waitcnt lgkmcnt(3)                                       // 00000012FA54: BF89FC37
	v_fmac_f32_e32 v92, v70, v84                               // 00000012FA58: 56B8A946
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FA5C: BF8700A1
	v_fmac_f32_e32 v92, v71, v85                               // 00000012FA60: 56B8AB47
	s_waitcnt lgkmcnt(2)                                       // 00000012FA64: BF89FC27
	v_fmac_f32_e32 v92, v74, v86                               // 00000012FA68: 56B8AD4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FA6C: BF8700A1
	v_fmac_f32_e32 v92, v75, v87                               // 00000012FA70: 56B8AF4B
	s_waitcnt lgkmcnt(1)                                       // 00000012FA74: BF89FC17
	v_fmac_f32_e32 v92, v76, v88                               // 00000012FA78: 56B8B14C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FA7C: BF8700A1
	v_fmac_f32_e32 v92, v77, v89                               // 00000012FA80: 56B8B34D
	s_waitcnt lgkmcnt(0)                                       // 00000012FA84: BF89FC07
	v_fmac_f32_e32 v92, v78, v90                               // 00000012FA88: 56B8B54E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012FA8C: BF870001
	v_fmac_f32_e32 v92, v79, v91                               // 00000012FA90: 56B8B74F
	ds_load_2addr_b32 v[60:61], v46 offset0:32 offset1:33      // 00000012FA94: D8DC2120 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:32 offset1:49      // 00000012FA9C: D8DC3120 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 00000012FAA4: D8DC2322 4000002E
	ds_load_2addr_b32 v[72:73], v50 offset0:66 offset1:83      // 00000012FAAC: D8DC5342 48000032
	ds_load_2addr_b32 v[66:67], v46 offset0:36 offset1:37      // 00000012FAB4: D8DC2524 4200002E
	ds_load_2addr_b32 v[68:69], v46 offset0:38 offset1:39      // 00000012FABC: D8DC2726 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:40 offset1:41      // 00000012FAC4: D8DC2928 4600002E
	ds_load_2addr_b32 v[74:75], v46 offset0:42 offset1:43      // 00000012FACC: D8DC2B2A 4A00002E
	ds_load_2addr_b32 v[76:77], v46 offset0:44 offset1:45      // 00000012FAD4: D8DC2D2C 4C00002E
	ds_load_2addr_b32 v[78:79], v46 offset0:46 offset1:47      // 00000012FADC: D8DC2F2E 4E00002E
	ds_load_2addr_b32 v[80:81], v50 offset0:100 offset1:117    // 00000012FAE4: D8DC7564 50000032
	ds_load_2addr_b32 v[82:83], v50 offset0:134 offset1:151    // 00000012FAEC: D8DC9786 52000032
	ds_load_2addr_b32 v[84:85], v50 offset0:168 offset1:185    // 00000012FAF4: D8DCB9A8 54000032
	ds_load_2addr_b32 v[86:87], v50 offset0:202 offset1:219    // 00000012FAFC: D8DCDBCA 56000032
	ds_load_2addr_b32 v[88:89], v50 offset0:236 offset1:253    // 00000012FB04: D8DCFDEC 58000032
	ds_load_2addr_b32 v[90:91], v51 offset0:14 offset1:31      // 00000012FB0C: D8DC1F0E 5A000033
	s_waitcnt lgkmcnt(14)                                      // 00000012FB14: BF89FCE7
	v_fmac_f32_e32 v92, v60, v62                               // 00000012FB18: 56B87D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FB1C: BF8700A1
	v_fmac_f32_e32 v92, v61, v63                               // 00000012FB20: 56B87F3D
	s_waitcnt lgkmcnt(12)                                      // 00000012FB24: BF89FCC7
	v_fmac_f32_e32 v92, v64, v72                               // 00000012FB28: 56B89140
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FB2C: BF8700A1
	v_fmac_f32_e32 v92, v65, v73                               // 00000012FB30: 56B89341
	s_waitcnt lgkmcnt(5)                                       // 00000012FB34: BF89FC57
	v_fmac_f32_e32 v92, v66, v80                               // 00000012FB38: 56B8A142
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FB3C: BF8700A1
	v_fmac_f32_e32 v92, v67, v81                               // 00000012FB40: 56B8A343
	s_waitcnt lgkmcnt(4)                                       // 00000012FB44: BF89FC47
	v_fmac_f32_e32 v92, v68, v82                               // 00000012FB48: 56B8A544
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FB4C: BF8700A1
	v_fmac_f32_e32 v92, v69, v83                               // 00000012FB50: 56B8A745
	s_waitcnt lgkmcnt(3)                                       // 00000012FB54: BF89FC37
	v_fmac_f32_e32 v92, v70, v84                               // 00000012FB58: 56B8A946
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FB5C: BF8700A1
	v_fmac_f32_e32 v92, v71, v85                               // 00000012FB60: 56B8AB47
	s_waitcnt lgkmcnt(2)                                       // 00000012FB64: BF89FC27
	v_fmac_f32_e32 v92, v74, v86                               // 00000012FB68: 56B8AD4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FB6C: BF8700A1
	v_fmac_f32_e32 v92, v75, v87                               // 00000012FB70: 56B8AF4B
	s_waitcnt lgkmcnt(1)                                       // 00000012FB74: BF89FC17
	v_fmac_f32_e32 v92, v76, v88                               // 00000012FB78: 56B8B14C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FB7C: BF8700A1
	v_fmac_f32_e32 v92, v77, v89                               // 00000012FB80: 56B8B34D
	s_waitcnt lgkmcnt(0)                                       // 00000012FB84: BF89FC07
	v_fmac_f32_e32 v92, v78, v90                               // 00000012FB88: 56B8B54E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012FB8C: BF870001
	v_fmac_f32_e32 v92, v79, v91                               // 00000012FB90: 56B8B74F
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 00000012FB94: D8DC3130 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:48 offset1:65      // 00000012FB9C: D8DC4130 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:50 offset1:51      // 00000012FBA4: D8DC3332 4000002E
	ds_load_2addr_b32 v[72:73], v51 offset0:82 offset1:99      // 00000012FBAC: D8DC6352 48000033
	ds_load_2addr_b32 v[66:67], v46 offset0:52 offset1:53      // 00000012FBB4: D8DC3534 4200002E
	ds_load_2addr_b32 v[68:69], v46 offset0:54 offset1:55      // 00000012FBBC: D8DC3736 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:56 offset1:57      // 00000012FBC4: D8DC3938 4600002E
	ds_load_2addr_b32 v[74:75], v46 offset0:58 offset1:59      // 00000012FBCC: D8DC3B3A 4A00002E
	ds_load_2addr_b32 v[76:77], v46 offset0:60 offset1:61      // 00000012FBD4: D8DC3D3C 4C00002E
	ds_load_2addr_b32 v[78:79], v46 offset0:62 offset1:63      // 00000012FBDC: D8DC3F3E 4E00002E
	ds_load_2addr_b32 v[80:81], v51 offset0:116 offset1:133    // 00000012FBE4: D8DC8574 50000033
	ds_load_2addr_b32 v[82:83], v51 offset0:150 offset1:167    // 00000012FBEC: D8DCA796 52000033
	ds_load_2addr_b32 v[84:85], v51 offset0:184 offset1:201    // 00000012FBF4: D8DCC9B8 54000033
	ds_load_2addr_b32 v[86:87], v51 offset0:218 offset1:235    // 00000012FBFC: D8DCEBDA 56000033
	ds_load_2addr_b32 v[88:89], v52 offset0:124 offset1:141    // 00000012FC04: D8DC8D7C 58000034
	ds_load_2addr_b32 v[90:91], v53 offset0:30 offset1:47      // 00000012FC0C: D8DC2F1E 5A000035
	s_waitcnt lgkmcnt(14)                                      // 00000012FC14: BF89FCE7
	v_fmac_f32_e32 v92, v60, v62                               // 00000012FC18: 56B87D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FC1C: BF8700A1
	v_fmac_f32_e32 v92, v61, v63                               // 00000012FC20: 56B87F3D
	s_waitcnt lgkmcnt(12)                                      // 00000012FC24: BF89FCC7
	v_fmac_f32_e32 v92, v64, v72                               // 00000012FC28: 56B89140
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FC2C: BF8700A1
	v_fmac_f32_e32 v92, v65, v73                               // 00000012FC30: 56B89341
	s_waitcnt lgkmcnt(5)                                       // 00000012FC34: BF89FC57
	v_fmac_f32_e32 v92, v66, v80                               // 00000012FC38: 56B8A142
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FC3C: BF8700A1
	v_fmac_f32_e32 v92, v67, v81                               // 00000012FC40: 56B8A343
	s_waitcnt lgkmcnt(4)                                       // 00000012FC44: BF89FC47
	v_fmac_f32_e32 v92, v68, v82                               // 00000012FC48: 56B8A544
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FC4C: BF8700A1
	v_fmac_f32_e32 v92, v69, v83                               // 00000012FC50: 56B8A745
	s_waitcnt lgkmcnt(3)                                       // 00000012FC54: BF89FC37
	v_fmac_f32_e32 v92, v70, v84                               // 00000012FC58: 56B8A946
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FC5C: BF8700A1
	v_fmac_f32_e32 v92, v71, v85                               // 00000012FC60: 56B8AB47
	s_waitcnt lgkmcnt(2)                                       // 00000012FC64: BF89FC27
	v_fmac_f32_e32 v92, v74, v86                               // 00000012FC68: 56B8AD4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FC6C: BF8700A1
	v_fmac_f32_e32 v92, v75, v87                               // 00000012FC70: 56B8AF4B
	s_waitcnt lgkmcnt(1)                                       // 00000012FC74: BF89FC17
	v_fmac_f32_e32 v92, v76, v88                               // 00000012FC78: 56B8B14C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FC7C: BF8700A1
	v_fmac_f32_e32 v92, v77, v89                               // 00000012FC80: 56B8B34D
	s_waitcnt lgkmcnt(0)                                       // 00000012FC84: BF89FC07
	v_fmac_f32_e32 v92, v78, v90                               // 00000012FC88: 56B8B54E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012FC8C: BF870001
	v_fmac_f32_e32 v92, v79, v91                               // 00000012FC90: 56B8B74F
	ds_load_2addr_b32 v[60:61], v46 offset0:64 offset1:65      // 00000012FC94: D8DC4140 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:64 offset1:81      // 00000012FC9C: D8DC5140 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:66 offset1:67      // 00000012FCA4: D8DC4342 4000002E
	ds_load_2addr_b32 v[72:73], v53 offset0:98 offset1:115     // 00000012FCAC: D8DC7362 48000035
	ds_load_2addr_b32 v[66:67], v46 offset0:68 offset1:69      // 00000012FCB4: D8DC4544 4200002E
	ds_load_2addr_b32 v[68:69], v46 offset0:70 offset1:71      // 00000012FCBC: D8DC4746 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:72 offset1:73      // 00000012FCC4: D8DC4948 4600002E
	ds_load_2addr_b32 v[74:75], v46 offset0:74 offset1:75      // 00000012FCCC: D8DC4B4A 4A00002E
	ds_load_2addr_b32 v[76:77], v46 offset0:76 offset1:77      // 00000012FCD4: D8DC4D4C 4C00002E
	ds_load_2addr_b32 v[78:79], v46 offset0:78 offset1:79      // 00000012FCDC: D8DC4F4E 4E00002E
	ds_load_2addr_b32 v[80:81], v53 offset0:132 offset1:149    // 00000012FCE4: D8DC9584 50000035
	ds_load_2addr_b32 v[82:83], v53 offset0:166 offset1:183    // 00000012FCEC: D8DCB7A6 52000035
	ds_load_2addr_b32 v[84:85], v53 offset0:200 offset1:217    // 00000012FCF4: D8DCD9C8 54000035
	ds_load_2addr_b32 v[86:87], v53 offset0:234 offset1:251    // 00000012FCFC: D8DCFBEA 56000035
	ds_load_2addr_b32 v[88:89], v54 offset0:12 offset1:29      // 00000012FD04: D8DC1D0C 58000036
	ds_load_2addr_b32 v[90:91], v54 offset0:46 offset1:63      // 00000012FD0C: D8DC3F2E 5A000036
	s_waitcnt lgkmcnt(14)                                      // 00000012FD14: BF89FCE7
	v_fmac_f32_e32 v92, v60, v62                               // 00000012FD18: 56B87D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FD1C: BF8700A1
	v_fmac_f32_e32 v92, v61, v63                               // 00000012FD20: 56B87F3D
	s_waitcnt lgkmcnt(12)                                      // 00000012FD24: BF89FCC7
	v_fmac_f32_e32 v92, v64, v72                               // 00000012FD28: 56B89140
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FD2C: BF8700A1
	v_fmac_f32_e32 v92, v65, v73                               // 00000012FD30: 56B89341
	s_waitcnt lgkmcnt(5)                                       // 00000012FD34: BF89FC57
	v_fmac_f32_e32 v92, v66, v80                               // 00000012FD38: 56B8A142
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FD3C: BF8700A1
	v_fmac_f32_e32 v92, v67, v81                               // 00000012FD40: 56B8A343
	s_waitcnt lgkmcnt(4)                                       // 00000012FD44: BF89FC47
	v_fmac_f32_e32 v92, v68, v82                               // 00000012FD48: 56B8A544
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FD4C: BF8700A1
	v_fmac_f32_e32 v92, v69, v83                               // 00000012FD50: 56B8A745
	s_waitcnt lgkmcnt(3)                                       // 00000012FD54: BF89FC37
	v_fmac_f32_e32 v92, v70, v84                               // 00000012FD58: 56B8A946
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FD5C: BF8700A1
	v_fmac_f32_e32 v92, v71, v85                               // 00000012FD60: 56B8AB47
	s_waitcnt lgkmcnt(2)                                       // 00000012FD64: BF89FC27
	v_fmac_f32_e32 v92, v74, v86                               // 00000012FD68: 56B8AD4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FD6C: BF8700A1
	v_fmac_f32_e32 v92, v75, v87                               // 00000012FD70: 56B8AF4B
	s_waitcnt lgkmcnt(1)                                       // 00000012FD74: BF89FC17
	v_fmac_f32_e32 v92, v76, v88                               // 00000012FD78: 56B8B14C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FD7C: BF8700A1
	v_fmac_f32_e32 v92, v77, v89                               // 00000012FD80: 56B8B34D
	s_waitcnt lgkmcnt(0)                                       // 00000012FD84: BF89FC07
	v_fmac_f32_e32 v92, v78, v90                               // 00000012FD88: 56B8B54E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012FD8C: BF870001
	v_fmac_f32_e32 v92, v79, v91                               // 00000012FD90: 56B8B74F
	ds_load_2addr_b32 v[60:61], v46 offset0:80 offset1:81      // 00000012FD94: D8DC5150 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:80 offset1:97      // 00000012FD9C: D8DC6150 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 00000012FDA4: D8DC5352 4000002E
	ds_load_2addr_b32 v[72:73], v54 offset0:114 offset1:131    // 00000012FDAC: D8DC8372 48000036
	ds_load_2addr_b32 v[66:67], v46 offset0:84 offset1:85      // 00000012FDB4: D8DC5554 4200002E
	ds_load_2addr_b32 v[68:69], v46 offset0:86 offset1:87      // 00000012FDBC: D8DC5756 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:88 offset1:89      // 00000012FDC4: D8DC5958 4600002E
	ds_load_2addr_b32 v[74:75], v46 offset0:90 offset1:91      // 00000012FDCC: D8DC5B5A 4A00002E
	ds_load_2addr_b32 v[76:77], v46 offset0:92 offset1:93      // 00000012FDD4: D8DC5D5C 4C00002E
	ds_load_2addr_b32 v[78:79], v46 offset0:94 offset1:95      // 00000012FDDC: D8DC5F5E 4E00002E
	ds_load_2addr_b32 v[80:81], v54 offset0:148 offset1:165    // 00000012FDE4: D8DCA594 50000036
	ds_load_2addr_b32 v[82:83], v54 offset0:182 offset1:199    // 00000012FDEC: D8DCC7B6 52000036
	ds_load_2addr_b32 v[84:85], v54 offset0:216 offset1:233    // 00000012FDF4: D8DCE9D8 54000036
	ds_load_2addr_b32 v[86:87], v55 offset0:122 offset1:139    // 00000012FDFC: D8DC8B7A 56000037
	ds_load_2addr_b32 v[88:89], v56 offset0:28 offset1:45      // 00000012FE04: D8DC2D1C 58000038
	ds_load_2addr_b32 v[90:91], v56 offset0:62 offset1:79      // 00000012FE0C: D8DC4F3E 5A000038
	s_waitcnt lgkmcnt(14)                                      // 00000012FE14: BF89FCE7
	v_fmac_f32_e32 v92, v60, v62                               // 00000012FE18: 56B87D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FE1C: BF8700A1
	v_fmac_f32_e32 v92, v61, v63                               // 00000012FE20: 56B87F3D
	s_waitcnt lgkmcnt(12)                                      // 00000012FE24: BF89FCC7
	v_fmac_f32_e32 v92, v64, v72                               // 00000012FE28: 56B89140
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FE2C: BF8700A1
	v_fmac_f32_e32 v92, v65, v73                               // 00000012FE30: 56B89341
	s_waitcnt lgkmcnt(5)                                       // 00000012FE34: BF89FC57
	v_fmac_f32_e32 v92, v66, v80                               // 00000012FE38: 56B8A142
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FE3C: BF8700A1
	v_fmac_f32_e32 v92, v67, v81                               // 00000012FE40: 56B8A343
	s_waitcnt lgkmcnt(4)                                       // 00000012FE44: BF89FC47
	v_fmac_f32_e32 v92, v68, v82                               // 00000012FE48: 56B8A544
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FE4C: BF8700A1
	v_fmac_f32_e32 v92, v69, v83                               // 00000012FE50: 56B8A745
	s_waitcnt lgkmcnt(3)                                       // 00000012FE54: BF89FC37
	v_fmac_f32_e32 v92, v70, v84                               // 00000012FE58: 56B8A946
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FE5C: BF8700A1
	v_fmac_f32_e32 v92, v71, v85                               // 00000012FE60: 56B8AB47
	s_waitcnt lgkmcnt(2)                                       // 00000012FE64: BF89FC27
	v_fmac_f32_e32 v92, v74, v86                               // 00000012FE68: 56B8AD4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FE6C: BF8700A1
	v_fmac_f32_e32 v92, v75, v87                               // 00000012FE70: 56B8AF4B
	s_waitcnt lgkmcnt(1)                                       // 00000012FE74: BF89FC17
	v_fmac_f32_e32 v92, v76, v88                               // 00000012FE78: 56B8B14C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FE7C: BF8700A1
	v_fmac_f32_e32 v92, v77, v89                               // 00000012FE80: 56B8B34D
	s_waitcnt lgkmcnt(0)                                       // 00000012FE84: BF89FC07
	v_fmac_f32_e32 v92, v78, v90                               // 00000012FE88: 56B8B54E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012FE8C: BF870001
	v_fmac_f32_e32 v92, v79, v91                               // 00000012FE90: 56B8B74F
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 00000012FE94: D8DC6160 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:96 offset1:113     // 00000012FE9C: D8DC7160 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:98 offset1:99      // 00000012FEA4: D8DC6362 4000002E
	ds_load_2addr_b32 v[72:73], v56 offset0:130 offset1:147    // 00000012FEAC: D8DC9382 48000038
	ds_load_2addr_b32 v[66:67], v46 offset0:100 offset1:101    // 00000012FEB4: D8DC6564 4200002E
	ds_load_2addr_b32 v[68:69], v46 offset0:102 offset1:103    // 00000012FEBC: D8DC6766 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:104 offset1:105    // 00000012FEC4: D8DC6968 4600002E
	ds_load_2addr_b32 v[74:75], v46 offset0:106 offset1:107    // 00000012FECC: D8DC6B6A 4A00002E
	ds_load_2addr_b32 v[76:77], v46 offset0:108 offset1:109    // 00000012FED4: D8DC6D6C 4C00002E
	ds_load_2addr_b32 v[78:79], v46 offset0:110 offset1:111    // 00000012FEDC: D8DC6F6E 4E00002E
	ds_load_2addr_b32 v[80:81], v56 offset0:164 offset1:181    // 00000012FEE4: D8DCB5A4 50000038
	ds_load_2addr_b32 v[82:83], v56 offset0:198 offset1:215    // 00000012FEEC: D8DCD7C6 52000038
	ds_load_2addr_b32 v[84:85], v56 offset0:232 offset1:249    // 00000012FEF4: D8DCF9E8 54000038
	ds_load_2addr_b32 v[86:87], v57 offset0:10 offset1:27      // 00000012FEFC: D8DC1B0A 56000039
	ds_load_2addr_b32 v[88:89], v57 offset0:44 offset1:61      // 00000012FF04: D8DC3D2C 58000039
	ds_load_2addr_b32 v[90:91], v57 offset0:78 offset1:95      // 00000012FF0C: D8DC5F4E 5A000039
	s_waitcnt lgkmcnt(14)                                      // 00000012FF14: BF89FCE7
	v_fmac_f32_e32 v92, v60, v62                               // 00000012FF18: 56B87D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FF1C: BF8700A1
	v_fmac_f32_e32 v92, v61, v63                               // 00000012FF20: 56B87F3D
	s_waitcnt lgkmcnt(12)                                      // 00000012FF24: BF89FCC7
	v_fmac_f32_e32 v92, v64, v72                               // 00000012FF28: 56B89140
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FF2C: BF8700A1
	v_fmac_f32_e32 v92, v65, v73                               // 00000012FF30: 56B89341
	s_waitcnt lgkmcnt(5)                                       // 00000012FF34: BF89FC57
	v_fmac_f32_e32 v92, v66, v80                               // 00000012FF38: 56B8A142
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FF3C: BF8700A1
	v_fmac_f32_e32 v92, v67, v81                               // 00000012FF40: 56B8A343
	s_waitcnt lgkmcnt(4)                                       // 00000012FF44: BF89FC47
	v_fmac_f32_e32 v92, v68, v82                               // 00000012FF48: 56B8A544
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FF4C: BF8700A1
	v_fmac_f32_e32 v92, v69, v83                               // 00000012FF50: 56B8A745
	s_waitcnt lgkmcnt(3)                                       // 00000012FF54: BF89FC37
	v_fmac_f32_e32 v92, v70, v84                               // 00000012FF58: 56B8A946
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FF5C: BF8700A1
	v_fmac_f32_e32 v92, v71, v85                               // 00000012FF60: 56B8AB47
	s_waitcnt lgkmcnt(2)                                       // 00000012FF64: BF89FC27
	v_fmac_f32_e32 v92, v74, v86                               // 00000012FF68: 56B8AD4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FF6C: BF8700A1
	v_fmac_f32_e32 v92, v75, v87                               // 00000012FF70: 56B8AF4B
	s_waitcnt lgkmcnt(1)                                       // 00000012FF74: BF89FC17
	v_fmac_f32_e32 v92, v76, v88                               // 00000012FF78: 56B8B14C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FF7C: BF8700A1
	v_fmac_f32_e32 v92, v77, v89                               // 00000012FF80: 56B8B34D
	s_waitcnt lgkmcnt(0)                                       // 00000012FF84: BF89FC07
	v_fmac_f32_e32 v92, v78, v90                               // 00000012FF88: 56B8B54E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012FF8C: BF870001
	v_fmac_f32_e32 v92, v79, v91                               // 00000012FF90: 56B8B74F
	ds_load_2addr_b32 v[60:61], v46 offset0:112 offset1:113    // 00000012FF94: D8DC7170 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:112 offset1:129    // 00000012FF9C: D8DC8170 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:114 offset1:115    // 00000012FFA4: D8DC7372 4000002E
	ds_load_2addr_b32 v[72:73], v57 offset0:146 offset1:163    // 00000012FFAC: D8DCA392 48000039
	ds_load_2addr_b32 v[66:67], v46 offset0:116 offset1:117    // 00000012FFB4: D8DC7574 4200002E
	ds_load_2addr_b32 v[68:69], v46 offset0:118 offset1:119    // 00000012FFBC: D8DC7776 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:120 offset1:121    // 00000012FFC4: D8DC7978 4600002E
	ds_load_2addr_b32 v[74:75], v46 offset0:122 offset1:123    // 00000012FFCC: D8DC7B7A 4A00002E
	ds_load_2addr_b32 v[76:77], v46 offset0:124 offset1:125    // 00000012FFD4: D8DC7D7C 4C00002E
	ds_load_2addr_b32 v[78:79], v46 offset0:126 offset1:127    // 00000012FFDC: D8DC7F7E 4E00002E
	ds_load_2addr_b32 v[80:81], v57 offset0:180 offset1:197    // 00000012FFE4: D8DCC5B4 50000039
	ds_load_2addr_b32 v[82:83], v57 offset0:214 offset1:231    // 00000012FFEC: D8DCE7D6 52000039
	ds_load_2addr_b32 v[84:85], v58 offset0:120 offset1:137    // 00000012FFF4: D8DC8978 5400003A
	ds_load_2addr_b32 v[86:87], v59 offset0:26 offset1:43      // 00000012FFFC: D8DC2B1A 5600003B
	ds_load_2addr_b32 v[88:89], v59 offset0:60 offset1:77      // 000000130004: D8DC4D3C 5800003B
	ds_load_2addr_b32 v[90:91], v59 offset0:94 offset1:111     // 00000013000C: D8DC6F5E 5A00003B
	v_lshlrev_b32_e32 v33, 2, v33                              // 000000130014: 30424282
	s_waitcnt lgkmcnt(14)                                      // 000000130018: BF89FCE7
	v_fmac_f32_e32 v92, v60, v62                               // 00000013001C: 56B87D3C
	ds_load_b32 v60, v33 offset:17440                          // 000000130020: D8D84420 3C000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 000000130028: CA10011E 2220011D
	v_mov_b32_e32 v62, v35                                     // 000000130030: 7E7C0323
	v_fmac_f32_e32 v92, v61, v63                               // 000000130034: 56B87F3D
	v_mov_b32_e32 v61, v1                                      // 000000130038: 7E7A0301
	s_waitcnt lgkmcnt(13)                                      // 00000013003C: BF89FCD7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130040: BF870092
	v_fmac_f32_e32 v92, v64, v72                               // 000000130044: 56B89140
	v_fmac_f32_e32 v92, v65, v73                               // 000000130048: 56B89341
	s_waitcnt lgkmcnt(6)                                       // 00000013004C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130050: BF870091
	v_fmac_f32_e32 v92, v66, v80                               // 000000130054: 56B8A142
	v_fmac_f32_e32 v92, v67, v81                               // 000000130058: 56B8A343
	s_waitcnt lgkmcnt(5)                                       // 00000013005C: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130060: BF870091
	v_fmac_f32_e32 v92, v68, v82                               // 000000130064: 56B8A544
	v_fmac_f32_e32 v92, v69, v83                               // 000000130068: 56B8A745
	s_waitcnt lgkmcnt(4)                                       // 00000013006C: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130070: BF870091
	v_fmac_f32_e32 v92, v70, v84                               // 000000130074: 56B8A946
	v_fmac_f32_e32 v92, v71, v85                               // 000000130078: 56B8AB47
	s_waitcnt lgkmcnt(3)                                       // 00000013007C: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130080: BF870091
	v_fmac_f32_e32 v92, v74, v86                               // 000000130084: 56B8AD4A
	v_fmac_f32_e32 v92, v75, v87                               // 000000130088: 56B8AF4B
	s_waitcnt lgkmcnt(2)                                       // 00000013008C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130090: BF870091
	v_fmac_f32_e32 v92, v76, v88                               // 000000130094: 56B8B14C
	v_fmac_f32_e32 v92, v77, v89                               // 000000130098: 56B8B34D
	s_waitcnt lgkmcnt(1)                                       // 00000013009C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001300A0: BF870091
	v_fmac_f32_e32 v92, v78, v90                               // 0000001300A4: 56B8B54E
	v_fmac_f32_e32 v92, v79, v91                               // 0000001300A8: 56B8B74F
	s_waitcnt lgkmcnt(0)                                       // 0000001300AC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001300B0: BF870001
	v_mul_f32_e32 v60, v92, v60                                // 0000001300B4: 1078795C
	s_nop 0                                                    // 0000001300B8: BF800000
	s_nop 0                                                    // 0000001300BC: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000001300C0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000001300C8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000001300D0: 4A7C7CC1
	.long 0xd7000121                                           // 0000001300D4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000001300D8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001300DC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000001300E0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000001300E8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000001300EC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000001300F0: 4A7A7AFF 00000044
	s_or_b32 s12, s4, s12                                      // 0000001300F8: 8C0C0C04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001300FC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 000000130100: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 000000130104: 917E0C7E
	s_cbranch_execnz 65517                                     // 000000130108: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19c0>
	s_or_b32 exec_lo, exec_lo, s12                             // 00000013010C: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130110: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 000000130114: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 00000013011C: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 000000130128: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 000000130134: DC960000 007C2421
	s_branch 64913                                             // 00000013013C: BFA0FD91 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1084>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 000000130140: A201FF06 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 000000130148: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000013014C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 000000130150: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 000000130158: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 00000013015C: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 000000130164: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 00000013016C: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000130170: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 000000130174: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 00000013017C: A0010401
	s_mov_b32 s4, 0                                            // 000000130180: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 000000130184: BF87000A
	v_exp_f32_e32 v29, s1                                      // 000000130188: 7E3A4A01
	s_cvt_i32_f32 s1, s7                                       // 00000013018C: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000130190: BF870585
	.long 0xd71c001d                                           // 000000130194: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 000000130198: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 00000013019C: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 0000001301A0: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001301A8: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000001301AC: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000001301B4: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000001301B8: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000001301BC: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000001301C8: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000001301D0: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001301D8: BF870001
	.long 0xd4490001                                           // 0000001301DC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000001301E0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000001301E8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000001301EC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000001301F0: 1040411E
	ds_store_b32 v29, v32                                      // 0000001301F4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000001301FC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000130204: 917E047E
	s_cbranch_execnz 65519                                     // 000000130208: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ac8>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000013020C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 000000130210: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 000000130218: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 000000130220: 7E420326
	s_mov_b32 s6, 0                                            // 000000130224: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000130228: BF89FC07
	s_barrier                                                  // 00000013022C: BFBD0000
	buffer_gl0_inv                                             // 000000130230: E0AC0000 00000000
	s_nop 0                                                    // 000000130238: BF800000
	s_nop 0                                                    // 00000013023C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000130240: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 000000130248: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000130250: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000130258: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000013025C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 000000130264: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000130268: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000130270: BF870004
	.long 0xd4490004                                           // 000000130274: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000130278: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000130280: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000130284: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000130288: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 00000013028C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 000000130294: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000013029C: 917E067E
	s_cbranch_execnz 65511                                     // 0000001302A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b40>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001302A4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000001302A8: BF89FC07
	s_barrier                                                  // 0000001302AC: BFBD0000
	buffer_gl0_inv                                             // 0000001302B0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000001302B8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 0000001302C0: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 0000001302C8: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 0000001302D0: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000001302D8: 7E780300
	s_mov_b32 s4, 0                                            // 0000001302DC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001302E0: BF840001
	s_nop 0                                                    // 0000001302E4: BF800000
	s_nop 0                                                    // 0000001302E8: BF800000
	s_nop 0                                                    // 0000001302EC: BF800000
	s_nop 0                                                    // 0000001302F0: BF800000
	s_nop 0                                                    // 0000001302F4: BF800000
	s_nop 0                                                    // 0000001302F8: BF800000
	s_nop 0                                                    // 0000001302FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130300: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000130304: 327A7884
	.long 0xd4490001                                           // 000000130308: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000013030C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000130314: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000130318: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000130324: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000130328: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000130330: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000130338: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000130340: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000130348: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000130350: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000130358: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000130360: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 000000130364: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000130370: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 000000130374: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000130378: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000130380: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000130384: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000130388: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000013038C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130390: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000130394: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000130398: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000013039C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001303A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000001303A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000001303B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000001303B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001303C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000001303C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c00>
	s_set_inst_prefetch_distance 0x2                           // 0000001303C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001303CC: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 0000001303D0: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000001303D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000001303E0: 7E420326
	s_mov_b32 s6, 0                                            // 0000001303E4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000001303E8: BF89FC07
	s_barrier                                                  // 0000001303EC: BFBD0000
	buffer_gl0_inv                                             // 0000001303F0: E0AC0000 00000000
	s_nop 0                                                    // 0000001303F8: BF800000
	s_nop 0                                                    // 0000001303FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000130400: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 000000130408: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000130410: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000130418: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000013041C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000130424: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000130428: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000130430: BF870004
	.long 0xd4490004                                           // 000000130434: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000130438: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000130440: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000130444: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000130448: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000013044C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000130454: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000013045C: 917E067E
	s_cbranch_execnz 65511                                     // 000000130460: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d00>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000130464: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000130468: BF89FC07
	s_barrier                                                  // 00000013046C: BFBD0000
	buffer_gl0_inv                                             // 000000130470: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 000000130478: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 000000130480: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 000000130488: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 000000130490: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 000000130498: 7E780300
	s_mov_b32 s4, 0                                            // 00000013049C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001304A0: BF840001
	s_nop 0                                                    // 0000001304A4: BF800000
	s_nop 0                                                    // 0000001304A8: BF800000
	s_nop 0                                                    // 0000001304AC: BF800000
	s_nop 0                                                    // 0000001304B0: BF800000
	s_nop 0                                                    // 0000001304B4: BF800000
	s_nop 0                                                    // 0000001304B8: BF800000
	s_nop 0                                                    // 0000001304BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001304C0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000001304C4: 327A7884
	.long 0xd4490001                                           // 0000001304C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000001304CC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000001304D4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000001304D8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000001304E4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000001304E8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000001304F0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000001304F8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000130500: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000130508: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000130510: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000130518: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000130520: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 000000130524: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000130530: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 000000130534: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000130538: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000130540: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000130544: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000130548: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000013054C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130550: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000130554: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000130558: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000013055C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130560: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000130564: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000130570: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000130578: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000130580: 917E047E
	s_cbranch_execnz 65486                                     // 000000130584: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dc0>
	s_set_inst_prefetch_distance 0x2                           // 000000130588: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000013058C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 000000130590: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000130598: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000001305A0: 7E420326
	s_mov_b32 s6, 0                                            // 0000001305A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000001305A8: BF89FC07
	s_barrier                                                  // 0000001305AC: BFBD0000
	buffer_gl0_inv                                             // 0000001305B0: E0AC0000 00000000
	s_nop 0                                                    // 0000001305B8: BF800000
	s_nop 0                                                    // 0000001305BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000001305C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 0000001305C8: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000001305D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000001305D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000001305DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000001305E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000001305E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001305F0: BF870004
	.long 0xd4490004                                           // 0000001305F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000001305F8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000130600: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000130604: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000130608: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000013060C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000130614: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000013061C: 917E067E
	s_cbranch_execnz 65511                                     // 000000130620: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ec0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000130624: 8C7E067E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 000000130628: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000130630: BF89FC07
	s_barrier                                                  // 000000130634: BFBD0000
	buffer_gl0_inv                                             // 000000130638: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 000000130640: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 000000130644: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 00000013064C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 000000130654: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 00000013065C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 000000130664: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000130668: BF840001
	s_nop 0                                                    // 00000013066C: BF800000
	s_nop 0                                                    // 000000130670: BF800000
	s_nop 0                                                    // 000000130674: BF800000
	s_nop 0                                                    // 000000130678: BF800000
	s_nop 0                                                    // 00000013067C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000130680: 327C7A84
	.long 0xd4490001                                           // 000000130684: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000130688: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000130690: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000130694: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000130698: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000001306A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000001306A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000001306B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000001306B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000001306C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000001306C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000001306D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000001306D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000001306E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000001306E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001306E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000001306EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000001306F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000130700: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000130704: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000130708: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000013070C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130710: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000130714: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000130718: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000013071C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130720: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000130724: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000130730: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000130738: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000130740: 917E047E
	s_cbranch_execnz 65486                                     // 000000130744: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f80>
	s_set_inst_prefetch_distance 0x2                           // 000000130748: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000013074C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 000000130750: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000130758: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000130760: 7E420326
	s_mov_b32 s6, 0                                            // 000000130764: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000130768: BF89FC07
	s_barrier                                                  // 00000013076C: BFBD0000
	buffer_gl0_inv                                             // 000000130770: E0AC0000 00000000
	s_nop 0                                                    // 000000130778: BF800000
	s_nop 0                                                    // 00000013077C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000130780: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 000000130788: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000130790: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000130798: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000013079C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000001307A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000001307A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001307B0: BF870004
	.long 0xd4490004                                           // 0000001307B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000001307B8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 0000001307C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001307C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000001307C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000001307CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000001307D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000001307DC: 917E067E
	s_cbranch_execnz 65511                                     // 0000001307E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2080>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001307E4: 8C7E067E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000001307E8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000001307F0: BF89FC07
	s_barrier                                                  // 0000001307F4: BFBD0000
	buffer_gl0_inv                                             // 0000001307F8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 000000130800: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 000000130808: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 000000130810: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 000000130818: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 000000130820: 7E780300
	s_mov_b32 s4, 0                                            // 000000130824: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000130828: BF840001
	s_nop 0                                                    // 00000013082C: BF800000
	s_nop 0                                                    // 000000130830: BF800000
	s_nop 0                                                    // 000000130834: BF800000
	s_nop 0                                                    // 000000130838: BF800000
	s_nop 0                                                    // 00000013083C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130840: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000130844: 327A7884
	.long 0xd4490001                                           // 000000130848: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000013084C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000130854: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000130858: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000130864: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000130868: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000130870: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000130878: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000130880: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000130888: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000130890: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000130898: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000001308A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000001308A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001308B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000001308B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000001308B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000001308C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000001308C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000001308C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000001308CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001308D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000001308D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000001308D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000001308DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001308E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000001308E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000001308F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000001308F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000130900: 917E047E
	s_cbranch_execnz 65486                                     // 000000130904: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2140>
	s_set_inst_prefetch_distance 0x2                           // 000000130908: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000013090C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 000000130910: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000130918: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000130920: 7E420326
	s_mov_b32 s6, 0                                            // 000000130924: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000130928: BF89FC07
	s_barrier                                                  // 00000013092C: BFBD0000
	buffer_gl0_inv                                             // 000000130930: E0AC0000 00000000
	s_nop 0                                                    // 000000130938: BF800000
	s_nop 0                                                    // 00000013093C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000130940: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 000000130948: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000130950: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000130958: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000013095C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000130964: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000130968: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000130970: BF870004
	.long 0xd4490004                                           // 000000130974: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000130978: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000130980: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000130984: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000130988: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000013098C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000130994: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000013099C: 917E067E
	s_cbranch_execnz 65511                                     // 0000001309A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2240>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001309A4: 8C7E067E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 0000001309A8: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000001309B0: BF89FC07
	s_barrier                                                  // 0000001309B4: BFBD0000
	buffer_gl0_inv                                             // 0000001309B8: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 0000001309C0: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 0000001309C4: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 0000001309CC: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 0000001309D4: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 0000001309DC: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000001309E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001309E8: BF840001
	s_nop 0                                                    // 0000001309EC: BF800000
	s_nop 0                                                    // 0000001309F0: BF800000
	s_nop 0                                                    // 0000001309F4: BF800000
	s_nop 0                                                    // 0000001309F8: BF800000
	s_nop 0                                                    // 0000001309FC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 000000130A00: 327C7884
	.long 0xd4490001                                           // 000000130A04: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000130A08: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000130A10: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000130A14: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000130A18: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000130A24: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000130A28: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000130A30: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000130A38: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000130A40: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000130A48: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000130A50: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000130A58: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000130A60: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000130A64: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000130A68: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000130A6C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000130A78: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000130A80: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000130A84: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000130A88: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 000000130A8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130A90: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000130A94: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000130A98: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 000000130A9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130AA0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 000000130AA4: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 000000130AB0: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 000000130AB4: BF870002
	v_mov_b32_e32 v60, v63                                     // 000000130AB8: 7E78033F
	ds_store_b32 v62, v70                                      // 000000130ABC: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000130AC4: 917E047E
	s_cbranch_execnz 65485                                     // 000000130AC8: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2300>
	s_set_inst_prefetch_distance 0x2                           // 000000130ACC: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000130AD0: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 000000130AD4: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000130ADC: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000130AE4: 7E420326
	s_mov_b32 s6, 0                                            // 000000130AE8: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000130AEC: BF89FC07
	s_barrier                                                  // 000000130AF0: BFBD0000
	buffer_gl0_inv                                             // 000000130AF4: E0AC0000 00000000
	s_nop 0                                                    // 000000130AFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000130B00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 000000130B08: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000130B10: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000130B18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000130B1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000130B24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000130B28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000130B30: BF870004
	.long 0xd4490004                                           // 000000130B34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000130B38: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000130B40: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000130B44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000130B48: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 000000130B4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000130B54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000130B5C: 917E067E
	s_cbranch_execnz 65511                                     // 000000130B60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2400>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000130B64: 8C7E067E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 000000130B68: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 000000130B70: BF89FC07
	s_barrier                                                  // 000000130B74: BFBD0000
	buffer_gl0_inv                                             // 000000130B78: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 000000130B80: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 000000130B88: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 000000130B90: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 000000130B98: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000130BA0: 7E7A0300
	s_mov_b32 s4, 0                                            // 000000130BA4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000130BA8: BF840001
	s_nop 0                                                    // 000000130BAC: BF800000
	s_nop 0                                                    // 000000130BB0: BF800000
	s_nop 0                                                    // 000000130BB4: BF800000
	s_nop 0                                                    // 000000130BB8: BF800000
	s_nop 0                                                    // 000000130BBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130BC0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000130BC4: 327C7A84
	.long 0xd4490001                                           // 000000130BC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000130BCC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000130BD4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000130BD8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000130BE4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000130BE8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000130BF0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000130BF8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000130C00: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000130C08: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000130C10: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000130C18: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000130C20: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000130C24: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000130C28: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000130C2C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000130C38: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000130C40: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000130C44: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000130C48: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 000000130C4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130C50: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000130C54: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000130C58: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 000000130C5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130C60: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000130C64: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000130C70: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000130C78: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000130C80: 917E047E
	s_cbranch_execnz 65486                                     // 000000130C84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x24c0>
	s_set_inst_prefetch_distance 0x2                           // 000000130C88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000130C8C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 000000130C90: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000130C98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000130CA0: 7E420326
	s_mov_b32 s6, 0                                            // 000000130CA4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000130CA8: BF89FC07
	s_barrier                                                  // 000000130CAC: BFBD0000
	buffer_gl0_inv                                             // 000000130CB0: E0AC0000 00000000
	s_nop 0                                                    // 000000130CB8: BF800000
	s_nop 0                                                    // 000000130CBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000130CC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 000000130CC8: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000130CD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000130CD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000130CDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000130CE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000130CE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000130CF0: BF870004
	.long 0xd4490004                                           // 000000130CF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000130CF8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000130D00: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000130D04: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000130D08: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 000000130D0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000130D14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000130D1C: 917E067E
	s_cbranch_execnz 65511                                     // 000000130D20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000130D24: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000130D28: BF89FC07
	s_barrier                                                  // 000000130D2C: BFBD0000
	buffer_gl0_inv                                             // 000000130D30: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 000000130D38: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 000000130D40: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 000000130D48: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 000000130D50: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000130D58: 7E7A0300
	s_mov_b32 s4, 0                                            // 000000130D5C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000130D60: BF840001
	s_nop 0                                                    // 000000130D64: BF800000
	s_nop 0                                                    // 000000130D68: BF800000
	s_nop 0                                                    // 000000130D6C: BF800000
	s_nop 0                                                    // 000000130D70: BF800000
	s_nop 0                                                    // 000000130D74: BF800000
	s_nop 0                                                    // 000000130D78: BF800000
	s_nop 0                                                    // 000000130D7C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130D80: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000130D84: 327C7A84
	.long 0xd4490001                                           // 000000130D88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000130D8C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000130D94: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000130D98: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000130DA4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000130DA8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000130DB0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000130DB8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000130DC0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000130DC8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000130DD0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000130DD8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000130DE0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000130DE4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000130DE8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000130DEC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000130DF8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000130E00: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000130E04: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000130E08: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 000000130E0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130E10: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000130E14: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000130E18: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 000000130E1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130E20: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000130E24: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000130E30: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000130E38: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000130E40: 917E047E
	s_cbranch_execnz 65486                                     // 000000130E44: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2680>
	s_set_inst_prefetch_distance 0x2                           // 000000130E48: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000130E4C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 000000130E50: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000130E58: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000130E60: 7E420326
	s_mov_b32 s6, 0                                            // 000000130E64: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000130E68: BF89FC07
	s_barrier                                                  // 000000130E6C: BFBD0000
	buffer_gl0_inv                                             // 000000130E70: E0AC0000 00000000
	s_nop 0                                                    // 000000130E78: BF800000
	s_nop 0                                                    // 000000130E7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000130E80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 000000130E88: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000130E90: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000130E98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000130E9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000130EA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000130EA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000130EB0: BF870004
	.long 0xd4490004                                           // 000000130EB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000130EB8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000130EC0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000130EC4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000130EC8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 000000130ECC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000130ED4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000130EDC: 917E067E
	s_cbranch_execnz 65511                                     // 000000130EE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2780>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000130EE4: 8C7E067E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 000000130EE8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 000000130EF0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 000000130EF8: BF89FC07
	s_barrier                                                  // 000000130EFC: BFBD0000
	buffer_gl0_inv                                             // 000000130F00: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 000000130F08: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 000000130F10: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 000000130F18: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 000000130F20: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 000000130F28: 7E780300
	s_mov_b32 s4, 0                                            // 000000130F2C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000130F30: BF840001
	s_nop 0                                                    // 000000130F34: BF800000
	s_nop 0                                                    // 000000130F38: BF800000
	s_nop 0                                                    // 000000130F3C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130F40: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000130F44: 327A7884
	.long 0xd4490001                                           // 000000130F48: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000130F4C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000130F54: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000130F58: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000130F64: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000130F68: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000130F70: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000130F78: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000130F80: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000130F88: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000130F90: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000130F98: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000130FA0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 000000130FA4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000130FB0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 000000130FB4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000130FB8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000130FC0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000130FC4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000130FC8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 000000130FCC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130FD0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000130FD4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000130FD8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 000000130FDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130FE0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000130FE4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000130FF0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000130FF8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000131000: 917E047E
	s_cbranch_execnz 65486                                     // 000000131004: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2840>
	s_set_inst_prefetch_distance 0x2                           // 000000131008: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000013100C: 8C7E047E
	.long 0xd7000107                                           // 000000131010: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 000000131014: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013101C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 000000131020: D5207C08 00061080
	.long 0xd7000109                                           // 000000131028: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 00000013102C: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 000000131034: D5207C0A 00061480
	.long 0xd700010d                                           // 00000013103C: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 000000131040: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000131048: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 00000013104C: D5207C0E 00061C80
	.long 0xd700010b                                           // 000000131054: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 000000131058: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 000000131060: D5207C0C 00061880
	.long 0xd700010f                                           // 000000131068: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 00000013106C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000131074: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 000000131078: D5207C10 00062080
	.long 0xd7000111                                           // 000000131080: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 000000131084: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 00000013108C: D5207C12 00062480
	.long 0xd7000113                                           // 000000131094: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 000000131098: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001310A0: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000001310A4: D5207C14 00062880
	.long 0xd7000115                                           // 0000001310AC: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000001310B0: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000001310B8: D5207C16 00062C80
	.long 0xd7000117                                           // 0000001310C0: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000001310C4: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001310CC: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000001310D0: D5207C18 00063080
	.long 0xd7000119                                           // 0000001310D8: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000001310DC: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000001310E4: D5207C1A 00063480
	.long 0xd700011b                                           // 0000001310EC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000001310F0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001310F8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000001310FC: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 000000131104: 81058105
	s_waitcnt lgkmcnt(0)                                       // 000000131108: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 00000013110C: BF062105
	s_barrier                                                  // 000000131110: BFBD0000
	buffer_gl0_inv                                             // 000000131114: E0AC0000 00000000
	s_cbranch_scc0 63073                                       // 00000013111C: BFA1F661 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a4>
	v_mov_b32_e32 v4, v38                                      // 000000131120: 7E080326
	s_add_u32 s0, s28, s20                                     // 000000131124: 8000141C
	.long 0xd73c0000                                           // 000000131128: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000013112C: 02020489
	s_addc_u32 s1, s29, s21                                    // 000000131130: 8201151D
	s_add_u32 s2, s24, s18                                     // 000000131134: 80021218
	s_addc_u32 s3, s25, s19                                    // 000000131138: 82031319
	s_add_u32 s0, s2, s0                                       // 00000013113C: 80000002
	s_addc_u32 s1, s3, s1                                      // 000000131140: 82010103
	.long 0xd7006a00                                           // 000000131144: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000131148: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000013114C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000131150: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 000000131158: BE810080
	.long 0xd7006a00                                           // 00000013115C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 000000131160: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000131164: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013116C: BF870092
	.long 0xd7006a00                                           // 000000131170: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000131174: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000131178: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 000000131180: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 000000131188: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 000000131190: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000131198: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000013119C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001311A4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001311A8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000001311AC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000001311B4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000001311B8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000001311C0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001311C8: 917E017E
	s_cbranch_execnz 65516                                     // 0000001311CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi16ELb1ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a80>
	s_nop 0                                                    // 0000001311D0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001311D4: BFB60003
	s_endpgm                                                   // 0000001311D8: BFB00000
		...

