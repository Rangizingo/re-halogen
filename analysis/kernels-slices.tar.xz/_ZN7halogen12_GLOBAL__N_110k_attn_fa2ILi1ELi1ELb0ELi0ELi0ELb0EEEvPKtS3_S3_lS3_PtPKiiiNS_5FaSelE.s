00000000000ac100 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 0000000AC100: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 0000000AC104: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 0000000AC10C: F4080500 F8000050
	v_and_b32_e32 v131, 31, v0                                 // 0000000AC114: 3706009F
	v_lshrrev_b32_e32 v149, 5, v0                              // 0000000AC118: 332A0085
	s_mov_b32 s24, s3                                          // 0000000AC11C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AC120: BF870112
	.long 0xd44c0003                                           // 0000000AC124: D44C0003
	v_cndmask_b32_e32 v1, 16, v131, vcc_lo                     // 0000000AC128: 02030690
	v_lshlrev_b32_e32 v132, 6, v149                            // 0000000AC12C: 31092A86
	s_waitcnt lgkmcnt(0)                                       // 0000000AC130: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 0000000AC134: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 0000000AC13C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AC140: BF870001
	v_lshl_add_u32 v1, v131, 2, v132                           // 0000000AC144: D6460001 06110583
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 0000000AC14C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:156 offset1:162// 0000000AC158: D83CA29C 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000AC160: 8C7E047E
	v_mul_u32_u24_e32 v1, 0xab, v0                             // 0000000AC164: 160200FF 000000AB
	.long 0x7f043880                                           // 0000000AC16C: 7F043880
	v_dual_mov_b32 v142, 0 :: v_dual_and_b32 v147, 15, v0      // 0000000AC170: CA240080 8E92008F
	s_cmp_eq_u64 s[14:15], 0                                   // 0000000AC178: BF10800E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000AC17C: BF8704B3
	.long 0x7e043981                                           // 0000000AC180: 7E043981
	v_mov_b32_e32 v141, 0                                      // 0000000AC184: 7F1A0280
	s_cselect_b32 s25, -1, 0                                   // 0000000AC188: 981980C1
	s_and_b32 vcc_lo, exec_lo, s25                             // 0000000AC18C: 8B6A197E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AC190: BF870092
	v_add_lshl_u32 v148, s2, v2, 4                             // 0000000AC194: D6470094 02120402
	v_or_b32_e32 v129, v148, v147                              // 0000000AC19C: 39032794
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AC1A0: BF870001
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000000AC1A4: 3505029F
	s_cbranch_vccnz 10                                         // 0000000AC1A8: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xd4>
	v_mad_i64_i32 v[1:2], null, s23, v129, 0                   // 0000000AC1AC: D6FF7C01 02030217
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AC1B4: BF870091
	.long 0xd73c0001                                           // 0000000AC1B8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000000AC1BC: 02020282
	.long 0xd7006a8d                                           // 0000000AC1C0: D7006A8D
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000000AC1C4: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AC1C8: BF870001
	v_add_co_ci_u32_e64 v142, null, s15, v2, vcc_lo            // 0000000AC1CC: D5207C8E 01AA040F
	s_clause 0x2                                               // 0000000AC1D4: BF850002
	s_load_b64 s[14:15], s[0:1], 0x38                          // 0000000AC1D8: F4040380 F8000038
	s_load_b128 s[16:19], s[0:1], 0x20                         // 0000000AC1E0: F4080400 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 0000000AC1E8: F40C0100 F8000000
	v_mov_b32_e32 v151, 0                                      // 0000000AC1F0: 7F2E0280
	s_xor_b32 s0, s25, -1                                      // 0000000AC1F4: 8D00C119
	s_waitcnt lgkmcnt(0)                                       // 0000000AC1F8: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v129                         // 0000000AC1FC: 7C89020E
	s_and_b32 s23, s0, vcc_lo                                  // 0000000AC200: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AC204: BF870009
	s_and_saveexec_b32 s0, s23                                 // 0000000AC208: BE802017
	s_cbranch_execz 9                                          // 0000000AC20C: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x134>
	.long 0xd73c0001                                           // 0000000AC210: D73C0001
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 0000000AC214: 02030282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AC218: BF870091
	.long 0xd7006a01                                           // 0000000AC21C: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 0000000AC220: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 0000000AC224: D5207C02 01AA0415
	global_load_b32 v151, v[1:2], off                          // 0000000AC22C: DC520000 977C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000AC234: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 0000000AC238: BF10800C
	s_mov_b64 s[20:21], 0                                      // 0000000AC23C: BE940180
	s_cbranch_scc1 10                                          // 0000000AC240: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c>
	s_ashr_i32 s0, s22, 31                                     // 0000000AC244: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 0000000AC248: 96810216
	s_mul_i32 s0, s0, s2                                       // 0000000AC24C: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000AC250: BF8704A9
	s_add_i32 s1, s1, s0                                       // 0000000AC254: 81010001
	s_mul_i32 s0, s22, s2                                      // 0000000AC258: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000000AC25C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AC260: BF870009
	s_add_u32 s20, s12, s0                                     // 0000000AC264: 8014000C
	s_addc_u32 s21, s13, s1                                    // 0000000AC268: 8215010D
	.long 0xd7050001                                           // 0000000AC26C: D7050001
	v_cndmask_b32_e32 v0, v149, v150, vcc_lo                   // 0000000AC270: 02012D95
	s_lshl_b32 s0, s2, 4                                       // 0000000AC274: 84008402
	s_add_i32 s1, s14, -1                                      // 0000000AC278: 8101C10E
	s_or_b32 s0, s0, 15                                        // 0000000AC27C: 8C008F00
	v_lshrrev_b32_e32 v150, 4, v131                            // 0000000AC280: 332D0684
	.long 0xd7390001                                           // 0000000AC284: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 0000000AC288: 02020288
	s_min_i32 s0, s0, s1                                       // 0000000AC28C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000AC290: BF870499
	s_add_i32 s0, s26, s0                                      // 0000000AC294: 8100001A
	s_cmp_lt_i32 s0, -15                                       // 0000000AC298: BF04CF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AC29C: BF870091
	.long 0xd7050001                                           // 0000000AC2A0: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 0000000AC2A4: 02011901
	.long 0xd7040001                                           // 0000000AC2A8: D7040001
	v_cndmask_b32_e32 v1, v149, v1, vcc_lo                     // 0000000AC2AC: 02020395
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AC2B0: BF870091
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 0000000AC2B4: CA240080 480002FF 000000FF
	v_mov_b32_e32 v71, v72                                     // 0000000AC2C0: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 0000000AC2C4: 7E8A0348
	v_mov_b32_e32 v68, v72                                     // 0000000AC2C8: 7E880348
	v_mov_b32_e32 v67, v72                                     // 0000000AC2CC: 7E860348
	v_mad_u64_u32 v[138:139], null, s24, 12, v[1:2]            // 0000000AC2D0: D6FE7C8A 04051818
	v_mov_b32_e32 v70, v72                                     // 0000000AC2D8: 7E8C0348
	v_mov_b32_e32 v66, v72                                     // 0000000AC2DC: 7E840348
	v_mov_b32_e32 v65, v72                                     // 0000000AC2E0: 7E820348
	v_mov_b32_e32 v80, v72                                     // 0000000AC2E4: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 0000000AC2E8: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 0000000AC2EC: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 0000000AC2F0: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 0000000AC2F4: CA220148 4C011488
	v_mov_b32_e32 v75, v72                                     // 0000000AC2FC: 7E960348
	v_mov_b32_e32 v74, v72                                     // 0000000AC300: 7E940348
	v_mov_b32_e32 v73, v72                                     // 0000000AC304: 7E920348
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000AC308: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000000AC30C: 3404029F
	v_mov_b32_e32 v88, v72                                     // 0000000AC310: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 0000000AC314: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 0000000AC318: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 0000000AC31C: 7EAA0348
	.long 0xd73c008b                                           // 0000000AC320: D73C008B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000000AC324: 02020281
	v_mov_b32_e32 v84, v72                                     // 0000000AC328: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 0000000AC32C: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 0000000AC330: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 0000000AC334: 7EA20348
	v_mov_b32_e32 v96, v72                                     // 0000000AC338: 7EC00348
	v_mov_b32_e32 v95, v72                                     // 0000000AC33C: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 0000000AC340: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 0000000AC344: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 0000000AC348: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 0000000AC34C: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 0000000AC350: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 0000000AC354: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 0000000AC358: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 0000000AC35C: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 0000000AC360: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 0000000AC364: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 0000000AC368: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 0000000AC36C: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 0000000AC370: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 0000000AC374: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 0000000AC378: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 0000000AC37C: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 0000000AC380: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 0000000AC384: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 0000000AC388: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 0000000AC38C: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 0000000AC390: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 0000000AC394: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 0000000AC398: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 0000000AC39C: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 0000000AC3A0: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 0000000AC3A4: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 0000000AC3A8: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 0000000AC3AC: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 0000000AC3B0: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 0000000AC3B4: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 0000000AC3B8: 7F000348
	v_mov_b32_e32 v127, v72                                    // 0000000AC3BC: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 0000000AC3C0: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 0000000AC3C4: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 0000000AC3C8: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 0000000AC3CC: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 0000000AC3D0: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 0000000AC3D4: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 0000000AC3D8: 7E800348
	v_mov_b32_e32 v63, v72                                     // 0000000AC3DC: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 0000000AC3E0: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 0000000AC3E4: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 0000000AC3E8: 7E780348
	v_mov_b32_e32 v59, v72                                     // 0000000AC3EC: 7E760348
	v_mov_b32_e32 v58, v72                                     // 0000000AC3F0: 7E740348
	v_mov_b32_e32 v57, v72                                     // 0000000AC3F4: 7E720348
	v_mov_b32_e32 v56, v72                                     // 0000000AC3F8: 7E700348
	v_mov_b32_e32 v55, v72                                     // 0000000AC3FC: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 0000000AC400: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 0000000AC404: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 0000000AC408: 7E680348
	v_mov_b32_e32 v51, v72                                     // 0000000AC40C: 7E660348
	v_mov_b32_e32 v50, v72                                     // 0000000AC410: 7E640348
	v_mov_b32_e32 v49, v72                                     // 0000000AC414: 7E620348
	v_mov_b32_e32 v48, v72                                     // 0000000AC418: 7E600348
	v_mov_b32_e32 v47, v72                                     // 0000000AC41C: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 0000000AC420: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 0000000AC424: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 0000000AC428: 7E580348
	v_mov_b32_e32 v43, v72                                     // 0000000AC42C: 7E560348
	v_mov_b32_e32 v42, v72                                     // 0000000AC430: 7E540348
	v_mov_b32_e32 v41, v72                                     // 0000000AC434: 7E520348
	v_mov_b32_e32 v40, v72                                     // 0000000AC438: 7E500348
	v_mov_b32_e32 v39, v72                                     // 0000000AC43C: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 0000000AC440: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 0000000AC444: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 0000000AC448: 7E480348
	v_mov_b32_e32 v35, v72                                     // 0000000AC44C: 7E460348
	v_mov_b32_e32 v34, v72                                     // 0000000AC450: 7E440348
	v_mov_b32_e32 v33, v72                                     // 0000000AC454: 7E420348
	v_mov_b32_e32 v32, v72                                     // 0000000AC458: 7E400348
	v_mov_b32_e32 v31, v72                                     // 0000000AC45C: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 0000000AC460: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 0000000AC464: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 0000000AC468: 7E380348
	v_mov_b32_e32 v27, v72                                     // 0000000AC46C: 7E360348
	v_mov_b32_e32 v26, v72                                     // 0000000AC470: 7E340348
	v_mov_b32_e32 v25, v72                                     // 0000000AC474: 7E320348
	v_mov_b32_e32 v24, v72                                     // 0000000AC478: 7E300348
	v_mov_b32_e32 v23, v72                                     // 0000000AC47C: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 0000000AC480: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 0000000AC484: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 0000000AC488: 7E280348
	v_mov_b32_e32 v19, v72                                     // 0000000AC48C: 7E260348
	v_mov_b32_e32 v18, v72                                     // 0000000AC490: 7E240348
	v_mov_b32_e32 v17, v72                                     // 0000000AC494: 7E220348
	v_mov_b32_e32 v16, v72                                     // 0000000AC498: 7E200348
	v_mov_b32_e32 v15, v72                                     // 0000000AC49C: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 0000000AC4A0: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 0000000AC4A4: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 0000000AC4A8: 7E180348
	v_mov_b32_e32 v11, v72                                     // 0000000AC4AC: 7E160348
	v_mov_b32_e32 v10, v72                                     // 0000000AC4B0: 7E140348
	v_mov_b32_e32 v9, v72                                      // 0000000AC4B4: 7E120348
	v_mov_b32_e32 v8, v72                                      // 0000000AC4B8: 7E100348
	v_mov_b32_e32 v7, v72                                      // 0000000AC4BC: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 0000000AC4C0: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 0000000AC4C4: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 0000000AC4C8: 7E080348
	v_mov_b32_e32 v3, v72                                      // 0000000AC4CC: 7E060348
	v_mov_b32_e32 v2, v72                                      // 0000000AC4D0: 7E040348
	v_mov_b32_e32 v1, v72                                      // 0000000AC4D4: 7E020348
	s_cbranch_scc1 2265                                        // 0000000AC4D8: BFA208D9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2740>
	v_mad_i64_i32 v[1:2], null, 0x3000, v129, s[4:5]           // 0000000AC4DC: D6FF7C01 001302FF 00003000
	v_add3_u32 v3, v129, s26, 1                                // 0000000AC4E8: D6550003 02043581
	s_ashr_i32 s1, s0, 31                                      // 0000000AC4F0: 86019F00
	v_dual_mov_b32 v129, 0 :: v_dual_lshlrev_b32 v4, 2, v131   // 0000000AC4F4: CA220080 81050682
	s_lshr_b32 s1, s1, 28                                      // 0000000AC4FC: 85019C01
	v_add3_u32 v155, v148, v131, s26                           // 0000000AC500: D655009B 006B0794
	s_add_i32 s0, s0, s1                                       // 0000000AC508: 81000100
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000000AC50C: BF8701D4
	.long 0xd7006a8f                                           // 0000000AC510: D7006A8F
	v_cndmask_b32_e32 v1, v1, v139, vcc_lo                     // 0000000AC514: 02031701
	v_ashrrev_i32_e32 v1, 31, v3                               // 0000000AC518: 3402069F
	s_movk_i32 s1, 0x440                                       // 0000000AC51C: B0010440
	v_add_co_ci_u32_e64 v144, null, v2, v140, vcc_lo           // 0000000AC520: D5207C90 01AB1902
	v_mad_u32_u24 v2, v149, s1, 0x1800                         // 0000000AC528: D60B0002 03FC0395 00001800
	v_lshrrev_b32_e32 v1, 30, v1                               // 0000000AC534: 3202029E
	s_ashr_i32 s2, s0, 4                                       // 0000000AC538: 86028400
	s_cmp_eq_u64 s[20:21], 0                                   // 0000000AC53C: BF108014
	.long 0xd44c0000                                           // 0000000AC540: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000000AC544: 020200FF 00000200
	v_mad_u32_u24 v5, 0x44, v150, v2                           // 0000000AC54C: D60B0005 040B2CFF 00000044
	v_add_nc_u32_e32 v1, v3, v1                                // 0000000AC558: 4A020303
	v_mad_u32_u24 v157, 0x44, v131, v2                         // 0000000AC55C: D60B009D 040B06FF 00000044
	v_lshlrev_b32_e32 v2, 4, v0                                // 0000000AC568: 30040084
	s_cselect_b32 s12, -1, 0                                   // 0000000AC56C: 980C80C1
	s_cmp_lg_u64 s[20:21], 0                                   // 0000000AC570: BF118014
	v_ashrrev_i32_e32 v154, 2, v1                              // 0000000AC574: 35340282
	v_dual_mov_b32 v6, v129 :: v_dual_lshlrev_b32 v1, 9, v149  // 0000000AC578: CA220181 06012A89
	s_cselect_b32 s13, -1, 0                                   // 0000000AC580: 980D80C1
	s_ashr_i32 s25, s24, 31                                    // 0000000AC584: 86199F18
	s_add_i32 s15, s15, -1                                     // 0000000AC588: 810FC10F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AC58C: BF870001
	v_lshl_add_u32 v158, v131, 5, v1                           // 0000000AC590: D646009E 04050B83
	v_lshl_or_b32 v162, v147, 5, v1                            // 0000000AC598: D65600A2 04050B93
	v_dual_mov_b32 v12, v129 :: v_dual_and_b32 v1, 0x1f0, v2   // 0000000AC5A0: CA240181 0C0004FF 000001F0
	s_lshl_b64 s[4:5], s[24:25], 9                             // 0000000AC5AC: 84848918
	v_add_nc_u32_e32 v3, v4, v132                              // 0000000AC5B0: 4A070904
	v_lshl_add_u32 v153, v147, 2, v5                           // 0000000AC5B4: D6460099 04150593
	v_dual_mov_b32 v8, v129 :: v_dual_add_nc_u32 v5, 0x9f00, v132// 0000000AC5BC: CA200181 080508FF 00009F00
	v_mul_u32_u24_e32 v2, 0x210, v149                          // 0000000AC5C8: 16052AFF 00000210
	s_add_u32 s1, s6, s4                                       // 0000000AC5D0: 80010406
	s_movk_i32 s6, 0x210                                       // 0000000AC5D4: B0060210
	s_addc_u32 s7, s7, s5                                      // 0000000AC5D8: 82070507
	.long 0xd70001a4                                           // 0000000AC5DC: D70001A4
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 0000000AC5E0: 02020201
	v_mad_u32_u24 v152, v147, s6, 0x7b00                       // 0000000AC5E4: D60B0098 03FC0D93 00007B00
	v_dual_mov_b32 v9, 0 :: v_dual_add_nc_u32 v160, v5, v4     // 0000000AC5F0: CA200080 09A00905
	v_lshl_or_b32 v161, v150, 2, v5                            // 0000000AC5F8: D65600A1 04150596
	v_mad_u32_u24 v163, v147, 48, 0x4b00                       // 0000000AC600: D60B00A3 03FD6193 00004B00
	v_add_co_ci_u32_e64 v165, null, s7, 0, s1                  // 0000000AC60C: D5207CA5 00050007
	v_lshl_or_b32 v166, v147, 1, 0x4b00                        // 0000000AC614: D65600A6 03FD0393 00004B00
	v_dual_mov_b32 v14, v129 :: v_dual_add_nc_u32 v167, 0xfffffe80, v0// 0000000AC620: CA200181 0EA600FF FFFFFE80
	v_lshl_add_u32 v168, v131, 4, v2                           // 0000000AC62C: D64600A8 04090983
	v_lshrrev_b32_e32 v0, 1, v0                                // 0000000AC634: 32000081
	v_mov_b32_e32 v169, v149                                   // 0000000AC638: 7F520395
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, v129            // 0000000AC63C: CA100080 01020181
	v_mov_b32_e32 v4, v129                                     // 0000000AC644: 7E080381
	v_add_nc_u32_e32 v156, 0x9c00, v3                          // 0000000AC648: 4B3806FF 00009C00
	v_dual_mov_b32 v10, v129 :: v_dual_add_nc_u32 v159, 0xa200, v3// 0000000AC650: CA200181 0A9E06FF 0000A200
	v_mov_b32_e32 v3, v129                                     // 0000000AC65C: 7E060381
	v_mov_b32_e32 v5, v129                                     // 0000000AC660: 7E0A0381
	v_mov_b32_e32 v7, v129                                     // 0000000AC664: 7E0E0381
	v_mov_b32_e32 v11, v129                                    // 0000000AC668: 7E160381
	v_mov_b32_e32 v13, v129                                    // 0000000AC66C: 7E1A0381
	v_mov_b32_e32 v15, v129                                    // 0000000AC670: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v17, 0          // 0000000AC674: CA100181 10100080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v25, 0          // 0000000AC67C: CA100181 12180080
	v_mov_b32_e32 v19, v129                                    // 0000000AC684: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v33, 0          // 0000000AC688: CA100181 14200080
	v_mov_b32_e32 v21, v129                                    // 0000000AC690: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v41, 0          // 0000000AC694: CA100181 16280080
	v_mov_b32_e32 v23, v129                                    // 0000000AC69C: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v49, 0          // 0000000AC6A0: CA100181 18300080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v57, 0          // 0000000AC6A8: CA100181 1A380080
	v_mov_b32_e32 v27, v129                                    // 0000000AC6B0: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v121, 0         // 0000000AC6B4: CA100181 1C780080
	v_mov_b32_e32 v29, v129                                    // 0000000AC6BC: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v113, 0         // 0000000AC6C0: CA100181 1E700080
	v_mov_b32_e32 v31, v129                                    // 0000000AC6C8: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v105, 0         // 0000000AC6CC: CA100181 20680080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v97, 0          // 0000000AC6D4: CA100181 22600080
	v_mov_b32_e32 v35, v129                                    // 0000000AC6DC: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v89, 0          // 0000000AC6E0: CA100181 24580080
	v_mov_b32_e32 v37, v129                                    // 0000000AC6E8: 7E4A0381
	v_dual_mov_b32 v38, v129 :: v_dual_mov_b32 v81, 0          // 0000000AC6EC: CA100181 26500080
	v_mov_b32_e32 v39, v129                                    // 0000000AC6F4: 7E4E0381
	v_dual_mov_b32 v40, v129 :: v_dual_mov_b32 v73, 0          // 0000000AC6F8: CA100181 28480080
	v_dual_mov_b32 v42, v129 :: v_dual_mov_b32 v65, 0          // 0000000AC700: CA100181 2A400080
	v_mov_b32_e32 v43, v129                                    // 0000000AC708: 7E560381
	v_dual_mov_b32 v44, v129 :: v_dual_mov_b32 v145, 0         // 0000000AC70C: CA100181 2C900080
	v_mov_b32_e32 v45, v129                                    // 0000000AC714: 7E5A0381
	v_mov_b32_e32 v46, v129                                    // 0000000AC718: 7E5C0381
	v_mov_b32_e32 v47, v129                                    // 0000000AC71C: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 0000000AC720: 7E600381
	v_mov_b32_e32 v50, v129                                    // 0000000AC724: 7E640381
	v_mov_b32_e32 v51, v129                                    // 0000000AC728: 7E660381
	v_mov_b32_e32 v52, v129                                    // 0000000AC72C: 7E680381
	v_mov_b32_e32 v53, v129                                    // 0000000AC730: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 0000000AC734: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 0000000AC738: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 0000000AC73C: 7E700381
	v_mov_b32_e32 v58, v129                                    // 0000000AC740: 7E740381
	v_mov_b32_e32 v59, v129                                    // 0000000AC744: 7E760381
	v_mov_b32_e32 v60, v129                                    // 0000000AC748: 7E780381
	v_mov_b32_e32 v61, v129                                    // 0000000AC74C: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 0000000AC750: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 0000000AC754: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 0000000AC758: 7E800381
	v_mov_b32_e32 v122, v129                                   // 0000000AC75C: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 0000000AC760: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 0000000AC764: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 0000000AC768: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 0000000AC76C: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 0000000AC770: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 0000000AC774: 7F000381
	v_mov_b32_e32 v114, v129                                   // 0000000AC778: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 0000000AC77C: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 0000000AC780: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 0000000AC784: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 0000000AC788: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 0000000AC78C: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 0000000AC790: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 0000000AC794: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 0000000AC798: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 0000000AC79C: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 0000000AC7A0: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 0000000AC7A4: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 0000000AC7A8: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 0000000AC7AC: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 0000000AC7B0: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 0000000AC7B4: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 0000000AC7B8: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 0000000AC7BC: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 0000000AC7C0: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 0000000AC7C4: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 0000000AC7C8: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 0000000AC7CC: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 0000000AC7D0: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 0000000AC7D4: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 0000000AC7D8: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 0000000AC7DC: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 0000000AC7E0: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 0000000AC7E4: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 0000000AC7E8: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 0000000AC7EC: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 0000000AC7F0: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 0000000AC7F4: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 0000000AC7F8: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 0000000AC7FC: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 0000000AC800: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 0000000AC804: 7E940381
	v_mov_b32_e32 v75, v129                                    // 0000000AC808: 7E960381
	v_mov_b32_e32 v76, v129                                    // 0000000AC80C: 7E980381
	v_mov_b32_e32 v77, v129                                    // 0000000AC810: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 0000000AC814: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 0000000AC818: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 0000000AC81C: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 0000000AC820: 7E840381
	v_mov_b32_e32 v67, v129                                    // 0000000AC824: 7E860381
	v_mov_b32_e32 v68, v129                                    // 0000000AC828: 7E880381
	v_mov_b32_e32 v69, v129                                    // 0000000AC82C: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 0000000AC830: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 0000000AC834: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 0000000AC838: 7E900381
	s_add_u32 s4, s8, s4                                       // 0000000AC83C: 80040408
	s_addc_u32 s5, s9, s5                                      // 0000000AC840: 82050509
	s_mov_b32 s6, 0                                            // 0000000AC844: BE860080
	s_branch 299                                               // 0000000AC848: BFA0012B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbf8>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000AC84C: 8C7E017E
	v_add_f32_e32 v131, v133, v132                             // 0000000AC850: 07070985
	ds_load_b32 v132, v159                                     // 0000000AC854: D8D80000 8400009F
	v_add_f32_e32 v131, v131, v135                             // 0000000AC85C: 07070F83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AC860: BF870091
	v_add_f32_e32 v131, v131, v134                             // 0000000AC864: 07070D83
	v_add_f32_e32 v131, v131, v137                             // 0000000AC868: 07071383
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AC86C: BF870091
	v_add_f32_e32 v131, v131, v136                             // 0000000AC870: 07071183
	v_add_f32_e32 v131, v131, v170                             // 0000000AC874: 07075583
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AC878: BF870091
	v_add_f32_e32 v131, v131, v146                             // 0000000AC87C: 07072583
	v_add_f32_e32 v131, v131, v172                             // 0000000AC880: 07075983
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AC884: BF870091
	v_add_f32_e32 v131, v131, v171                             // 0000000AC888: 07075783
	v_add_f32_e32 v131, v131, v174                             // 0000000AC88C: 07075D83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AC890: BF870091
	v_add_f32_e32 v131, v131, v173                             // 0000000AC894: 07075B83
	v_add_f32_e32 v131, v131, v176                             // 0000000AC898: 07076183
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AC89C: BF870091
	v_add_f32_e32 v131, v131, v175                             // 0000000AC8A0: 07075F83
	v_add_f32_e32 v131, v131, v178                             // 0000000AC8A4: 07076583
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000AC8A8: BF8700A1
	v_add_f32_e32 v131, v131, v177                             // 0000000AC8AC: 07076383
	s_waitcnt lgkmcnt(0)                                       // 0000000AC8B0: BF89FC07
	v_fmac_f32_e32 v131, v179, v132                            // 0000000AC8B4: 570709B3
	ds_store_b32 v156, v130                                    // 0000000AC8B8: D8340000 0000829C
	ds_store_b32 v159, v131                                    // 0000000AC8C0: D8340000 0000839F
	ds_store_b32 v160, v179                                    // 0000000AC8C8: D8340000 0000B3A0
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AC8D0: 8C7E087E
	s_waitcnt lgkmcnt(0)                                       // 0000000AC8D4: BF89FC07
	s_barrier                                                  // 0000000AC8D8: BFBD0000
	buffer_gl0_inv                                             // 0000000AC8DC: E0AC0000 00000000
	ds_load_b128 v[130:133], v162                              // 0000000AC8E4: DBFC0000 820000A2
	ds_load_b128 v[134:137], v162 offset:16                    // 0000000AC8EC: DBFC0010 860000A2
	ds_load_b128 v[170:173], v163                              // 0000000AC8F4: DBFC0000 AA0000A3
	ds_load_b128 v[174:177], v163 offset:16                    // 0000000AC8FC: DBFC0010 AE0000A3
	ds_load_2addr_b32 v[178:179], v161 offset1:2               // 0000000AC904: D8DC0200 B20000A1
	ds_load_2addr_b32 v[180:181], v161 offset0:4 offset1:6     // 0000000AC90C: D8DC0604 B40000A1
	ds_load_2addr_b32 v[182:183], v161 offset0:8 offset1:10    // 0000000AC914: D8DC0A08 B60000A1
	ds_load_2addr_b32 v[184:185], v161 offset0:12 offset1:14   // 0000000AC91C: D8DC0E0C B80000A1
	s_waitcnt lgkmcnt(3)                                       // 0000000AC924: BF89FC37
	v_dual_mul_f32 v121, v178, v121 :: v_dual_mul_f32 v122, v179, v122// 0000000AC928: C8C6F3B2 797AF5B3
	s_waitcnt lgkmcnt(2)                                       // 0000000AC930: BF89FC27
	v_dual_mul_f32 v123, v180, v123 :: v_dual_mul_f32 v124, v181, v124// 0000000AC934: C8C6F7B4 7B7CF9B5
	s_waitcnt lgkmcnt(1)                                       // 0000000AC93C: BF89FC17
	v_dual_mul_f32 v125, v182, v125 :: v_dual_mul_f32 v126, v183, v126// 0000000AC940: C8C6FBB6 7D7EFDB7
	s_waitcnt lgkmcnt(0)                                       // 0000000AC948: BF89FC07
	v_dual_mul_f32 v127, v184, v127 :: v_dual_mul_f32 v128, v185, v128// 0000000AC94C: C8C6FFB8 7F8101B9
	v_dual_mul_f32 v113, v178, v113 :: v_dual_mul_f32 v114, v179, v114// 0000000AC954: C8C6E3B2 7172E5B3
	v_dual_mul_f32 v115, v180, v115 :: v_dual_mul_f32 v116, v181, v116// 0000000AC95C: C8C6E7B4 7374E9B5
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000AC964: BF870003
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[170:177], v[121:128]// 0000000AC968: CC414079 1DE75582
	ds_load_b128 v[174:177], v163 offset:784                   // 0000000AC970: DBFC0310 AE0000A3
	ds_load_b128 v[170:173], v163 offset:768                   // 0000000AC978: DBFC0300 AA0000A3
	v_dual_mul_f32 v117, v182, v117 :: v_dual_mul_f32 v118, v183, v118// 0000000AC980: C8C6EBB6 7576EDB7
	v_dual_mul_f32 v119, v184, v119 :: v_dual_mul_f32 v120, v185, v120// 0000000AC988: C8C6EFB8 7778F1B9
	v_dual_mul_f32 v105, v178, v105 :: v_dual_mul_f32 v106, v179, v106// 0000000AC990: C8C6D3B2 696AD5B3
	v_dual_mul_f32 v107, v180, v107 :: v_dual_mul_f32 v108, v181, v108// 0000000AC998: C8C6D7B4 6B6CD9B5
	v_dual_mul_f32 v109, v182, v109 :: v_dual_mul_f32 v110, v183, v110// 0000000AC9A0: C8C6DBB6 6D6EDDB7
	v_dual_mul_f32 v111, v184, v111 :: v_dual_mul_f32 v112, v185, v112// 0000000AC9A8: C8C6DFB8 6F70E1B9
	v_dual_mul_f32 v97, v178, v97 :: v_dual_mul_f32 v98, v179, v98// 0000000AC9B0: C8C6C3B2 6162C5B3
	v_dual_mul_f32 v99, v180, v99 :: v_dual_mul_f32 v100, v181, v100// 0000000AC9B8: C8C6C7B4 6364C9B5
	v_dual_mul_f32 v101, v182, v101 :: v_dual_mul_f32 v102, v183, v102// 0000000AC9C0: C8C6CBB6 6566CDB7
	v_dual_mul_f32 v103, v184, v103 :: v_dual_mul_f32 v104, v185, v104// 0000000AC9C8: C8C6CFB8 6768D1B9
	s_waitcnt lgkmcnt(0)                                       // 0000000AC9D0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[170:177], v[113:120]// 0000000AC9D4: CC414071 1DC75582
	ds_load_b128 v[174:177], v163 offset:1552                  // 0000000AC9DC: DBFC0610 AE0000A3
	ds_load_b128 v[170:173], v163 offset:1536                  // 0000000AC9E4: DBFC0600 AA0000A3
	v_dual_mul_f32 v89, v178, v89 :: v_dual_mul_f32 v90, v179, v90// 0000000AC9EC: C8C6B3B2 595AB5B3
	v_dual_mul_f32 v91, v180, v91 :: v_dual_mul_f32 v92, v181, v92// 0000000AC9F4: C8C6B7B4 5B5CB9B5
	v_dual_mul_f32 v93, v182, v93 :: v_dual_mul_f32 v94, v183, v94// 0000000AC9FC: C8C6BBB6 5D5EBDB7
	v_dual_mul_f32 v95, v184, v95 :: v_dual_mul_f32 v96, v185, v96// 0000000ACA04: C8C6BFB8 5F60C1B9
	v_dual_mul_f32 v81, v178, v81 :: v_dual_mul_f32 v82, v179, v82// 0000000ACA0C: C8C6A3B2 5152A5B3
	v_dual_mul_f32 v83, v180, v83 :: v_dual_mul_f32 v84, v181, v84// 0000000ACA14: C8C6A7B4 5354A9B5
	v_dual_mul_f32 v85, v182, v85 :: v_dual_mul_f32 v86, v183, v86// 0000000ACA1C: C8C6ABB6 5556ADB7
	v_dual_mul_f32 v87, v184, v87 :: v_dual_mul_f32 v88, v185, v88// 0000000ACA24: C8C6AFB8 5758B1B9
	v_dual_mul_f32 v73, v178, v73 :: v_dual_mul_f32 v74, v179, v74// 0000000ACA2C: C8C693B2 494A95B3
	v_dual_mul_f32 v75, v180, v75 :: v_dual_mul_f32 v76, v181, v76// 0000000ACA34: C8C697B4 4B4C99B5
	s_waitcnt lgkmcnt(0)                                       // 0000000ACA3C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[170:177], v[105:112]// 0000000ACA40: CC414069 1DA75582
	ds_load_b128 v[174:177], v163 offset:2320                  // 0000000ACA48: DBFC0910 AE0000A3
	ds_load_b128 v[170:173], v163 offset:2304                  // 0000000ACA50: DBFC0900 AA0000A3
	v_dual_mul_f32 v77, v182, v77 :: v_dual_mul_f32 v78, v183, v78// 0000000ACA58: C8C69BB6 4D4E9DB7
	v_dual_mul_f32 v79, v184, v79 :: v_dual_mul_f32 v80, v185, v80// 0000000ACA60: C8C69FB8 4F50A1B9
	v_dual_mul_f32 v65, v178, v65 :: v_dual_mul_f32 v66, v179, v66// 0000000ACA68: C8C683B2 414285B3
	v_dual_mul_f32 v67, v180, v67 :: v_dual_mul_f32 v68, v181, v68// 0000000ACA70: C8C687B4 434489B5
	v_dual_mul_f32 v69, v182, v69 :: v_dual_mul_f32 v70, v183, v70// 0000000ACA78: C8C68BB6 45468DB7
	v_dual_mul_f32 v71, v184, v71 :: v_dual_mul_f32 v72, v185, v72// 0000000ACA80: C8C68FB8 474891B9
	v_dual_mul_f32 v57, v178, v57 :: v_dual_mul_f32 v58, v179, v58// 0000000ACA88: C8C673B2 393A75B3
	v_dual_mul_f32 v59, v180, v59 :: v_dual_mul_f32 v60, v181, v60// 0000000ACA90: C8C677B4 3B3C79B5
	v_dual_mul_f32 v61, v182, v61 :: v_dual_mul_f32 v62, v183, v62// 0000000ACA98: C8C67BB6 3D3E7DB7
	v_dual_mul_f32 v63, v184, v63 :: v_dual_mul_f32 v64, v185, v64// 0000000ACAA0: C8C67FB8 3F4081B9
	s_waitcnt lgkmcnt(0)                                       // 0000000ACAA8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[170:177], v[97:104]// 0000000ACAAC: CC414061 1D875582
	ds_load_b128 v[174:177], v163 offset:3088                  // 0000000ACAB4: DBFC0C10 AE0000A3
	ds_load_b128 v[170:173], v163 offset:3072                  // 0000000ACABC: DBFC0C00 AA0000A3
	v_dual_mul_f32 v49, v178, v49 :: v_dual_mul_f32 v50, v179, v50// 0000000ACAC4: C8C663B2 313265B3
	v_dual_mul_f32 v51, v180, v51 :: v_dual_mul_f32 v52, v181, v52// 0000000ACACC: C8C667B4 333469B5
	v_dual_mul_f32 v53, v182, v53 :: v_dual_mul_f32 v54, v183, v54// 0000000ACAD4: C8C66BB6 35366DB7
	v_dual_mul_f32 v55, v184, v55 :: v_dual_mul_f32 v56, v185, v56// 0000000ACADC: C8C66FB8 373871B9
	v_dual_mul_f32 v41, v178, v41 :: v_dual_mul_f32 v42, v179, v42// 0000000ACAE4: C8C653B2 292A55B3
	v_dual_mul_f32 v43, v180, v43 :: v_dual_mul_f32 v44, v181, v44// 0000000ACAEC: C8C657B4 2B2C59B5
	v_dual_mul_f32 v45, v182, v45 :: v_dual_mul_f32 v46, v183, v46// 0000000ACAF4: C8C65BB6 2D2E5DB7
	v_dual_mul_f32 v47, v184, v47 :: v_dual_mul_f32 v48, v185, v48// 0000000ACAFC: C8C65FB8 2F3061B9
	v_dual_mul_f32 v33, v178, v33 :: v_dual_mul_f32 v34, v179, v34// 0000000ACB04: C8C643B2 212245B3
	v_dual_mul_f32 v35, v180, v35 :: v_dual_mul_f32 v36, v181, v36// 0000000ACB0C: C8C647B4 232449B5
	s_waitcnt lgkmcnt(0)                                       // 0000000ACB14: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[170:177], v[89:96]// 0000000ACB18: CC414059 1D675582
	ds_load_b128 v[174:177], v163 offset:3856                  // 0000000ACB20: DBFC0F10 AE0000A3
	ds_load_b128 v[170:173], v163 offset:3840                  // 0000000ACB28: DBFC0F00 AA0000A3
	v_dual_mul_f32 v37, v182, v37 :: v_dual_mul_f32 v38, v183, v38// 0000000ACB30: C8C64BB6 25264DB7
	v_dual_mul_f32 v39, v184, v39 :: v_dual_mul_f32 v40, v185, v40// 0000000ACB38: C8C64FB8 272851B9
	v_dual_mul_f32 v25, v178, v25 :: v_dual_mul_f32 v26, v179, v26// 0000000ACB40: C8C633B2 191A35B3
	v_dual_mul_f32 v27, v180, v27 :: v_dual_mul_f32 v28, v181, v28// 0000000ACB48: C8C637B4 1B1C39B5
	v_dual_mul_f32 v29, v182, v29 :: v_dual_mul_f32 v30, v183, v30// 0000000ACB50: C8C63BB6 1D1E3DB7
	v_dual_mul_f32 v31, v184, v31 :: v_dual_mul_f32 v32, v185, v32// 0000000ACB58: C8C63FB8 1F2041B9
	v_dual_mul_f32 v17, v178, v17 :: v_dual_mul_f32 v18, v179, v18// 0000000ACB60: C8C623B2 111225B3
	v_dual_mul_f32 v19, v180, v19 :: v_dual_mul_f32 v20, v181, v20// 0000000ACB68: C8C627B4 131429B5
	v_dual_mul_f32 v21, v182, v21 :: v_dual_mul_f32 v22, v183, v22// 0000000ACB70: C8C62BB6 15162DB7
	v_dual_mul_f32 v23, v184, v23 :: v_dual_mul_f32 v24, v185, v24// 0000000ACB78: C8C62FB8 171831B9
	s_waitcnt lgkmcnt(0)                                       // 0000000ACB80: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[170:177], v[81:88]// 0000000ACB84: CC414051 1D475582
	ds_load_b128 v[174:177], v163 offset:4624                  // 0000000ACB8C: DBFC1210 AE0000A3
	ds_load_b128 v[170:173], v163 offset:4608                  // 0000000ACB94: DBFC1200 AA0000A3
	v_dual_mul_f32 v9, v178, v9 :: v_dual_mul_f32 v10, v179, v10// 0000000ACB9C: C8C613B2 090A15B3
	v_dual_mul_f32 v11, v180, v11 :: v_dual_mul_f32 v12, v181, v12// 0000000ACBA4: C8C617B4 0B0C19B5
	v_dual_mul_f32 v13, v182, v13 :: v_dual_mul_f32 v14, v183, v14// 0000000ACBAC: C8C61BB6 0D0E1DB7
	v_dual_mul_f32 v15, v184, v15 :: v_dual_mul_f32 v16, v185, v16// 0000000ACBB4: C8C61FB8 0F1021B9
	v_dual_mul_f32 v1, v178, v1 :: v_dual_mul_f32 v2, v179, v2 // 0000000ACBBC: C8C603B2 010205B3
	v_dual_mul_f32 v3, v180, v3 :: v_dual_mul_f32 v4, v181, v4 // 0000000ACBC4: C8C607B4 030409B5
	v_dual_mul_f32 v5, v182, v5 :: v_dual_mul_f32 v6, v183, v6 // 0000000ACBCC: C8C60BB6 05060DB7
	v_dual_mul_f32 v7, v184, v7 :: v_dual_mul_f32 v8, v185, v8 // 0000000ACBD4: C8C60FB8 070811B9
	s_waitcnt lgkmcnt(0)                                       // 0000000ACBDC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[170:177], v[73:80]// 0000000ACBE0: CC414049 1D275582
	ds_load_b128 v[174:177], v163 offset:5392                  // 0000000ACBE8: DBFC1510 AE0000A3
	ds_load_b128 v[170:173], v163 offset:5376                  // 0000000ACBF0: DBFC1500 AA0000A3
	s_waitcnt lgkmcnt(0)                                       // 0000000ACBF8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[170:177], v[65:72]// 0000000ACBFC: CC414041 1D075582
	ds_load_b128 v[174:177], v163 offset:6160                  // 0000000ACC04: DBFC1810 AE0000A3
	ds_load_b128 v[170:173], v163 offset:6144                  // 0000000ACC0C: DBFC1800 AA0000A3
	s_waitcnt lgkmcnt(0)                                       // 0000000ACC14: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[170:177], v[57:64]// 0000000ACC18: CC414039 1CE75582
	ds_load_b128 v[174:177], v163 offset:6928                  // 0000000ACC20: DBFC1B10 AE0000A3
	ds_load_b128 v[170:173], v163 offset:6912                  // 0000000ACC28: DBFC1B00 AA0000A3
	s_waitcnt lgkmcnt(0)                                       // 0000000ACC30: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[170:177], v[49:56]// 0000000ACC34: CC414031 1CC75582
	ds_load_b128 v[174:177], v163 offset:7696                  // 0000000ACC3C: DBFC1E10 AE0000A3
	ds_load_b128 v[170:173], v163 offset:7680                  // 0000000ACC44: DBFC1E00 AA0000A3
	s_waitcnt lgkmcnt(0)                                       // 0000000ACC4C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[170:177], v[41:48]// 0000000ACC50: CC414029 1CA75582
	ds_load_b128 v[174:177], v163 offset:8464                  // 0000000ACC58: DBFC2110 AE0000A3
	ds_load_b128 v[170:173], v163 offset:8448                  // 0000000ACC60: DBFC2100 AA0000A3
	s_waitcnt lgkmcnt(0)                                       // 0000000ACC68: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[170:177], v[33:40]// 0000000ACC6C: CC414021 1C875582
	ds_load_b128 v[174:177], v163 offset:9232                  // 0000000ACC74: DBFC2410 AE0000A3
	ds_load_b128 v[170:173], v163 offset:9216                  // 0000000ACC7C: DBFC2400 AA0000A3
	s_waitcnt lgkmcnt(0)                                       // 0000000ACC84: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[170:177], v[25:32]// 0000000ACC88: CC414019 1C675582
	ds_load_b128 v[174:177], v163 offset:10000                 // 0000000ACC90: DBFC2710 AE0000A3
	ds_load_b128 v[170:173], v163 offset:9984                  // 0000000ACC98: DBFC2700 AA0000A3
	s_waitcnt lgkmcnt(0)                                       // 0000000ACCA0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[170:177], v[17:24]// 0000000ACCA4: CC414011 1C475582
	ds_load_b128 v[174:177], v163 offset:10768                 // 0000000ACCAC: DBFC2A10 AE0000A3
	ds_load_b128 v[170:173], v163 offset:10752                 // 0000000ACCB4: DBFC2A00 AA0000A3
	s_waitcnt lgkmcnt(0)                                       // 0000000ACCBC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[170:177], v[9:16]// 0000000ACCC0: CC414009 1C275582
	ds_load_b128 v[174:177], v163 offset:11536                 // 0000000ACCC8: DBFC2D10 AE0000A3
	ds_load_b128 v[170:173], v163 offset:11520                 // 0000000ACCD0: DBFC2D00 AA0000A3
	s_waitcnt lgkmcnt(0)                                       // 0000000ACCD8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[170:177], v[1:8]// 0000000ACCDC: CC414001 1C075582
	v_add_nc_u32_e32 v169, 16, v169                            // 0000000ACCE4: 4B535290
	s_add_i32 s1, s6, 1                                        // 0000000ACCE8: 81018106
	s_cmp_eq_u32 s6, s2                                        // 0000000ACCEC: BF060206
	s_mov_b32 s6, s1                                           // 0000000ACCF0: BE860001
	s_cbranch_scc1 1746                                        // 0000000ACCF4: BFA206D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2740>
	s_and_not1_b32 vcc_lo, exec_lo, s13                        // 0000000ACCF8: 916A0D7E
	s_mov_b32 s1, s12                                          // 0000000ACCFC: BE81000C
	s_cbranch_vccnz 13                                         // 0000000ACD00: BFA4000D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc38>
	s_lshr_b32 s1, s6, 3                                       // 0000000ACD04: 85018306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000ACD08: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 0000000ACD0C: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 0000000ACD14: 7F040201
	global_load_b32 v130, v130, s[20:21]                       // 0000000ACD18: DC520000 82140082
	s_waitcnt vmcnt(0)                                         // 0000000ACD20: BF8903F7
	v_lshrrev_b32_e32 v130, s6, v130                           // 0000000ACD24: 33050406
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ACD28: BF870091
	v_and_b32_e32 v130, 1, v130                                // 0000000ACD2C: 37050481
	.long 0xd44a0001                                           // 0000000ACD30: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000000ACD34: 02030481
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ACD38: BF870001
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000000ACD3C: 916A017E
	s_cbranch_vccnz 65512                                      // 0000000ACD40: BFA4FFE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbe4>
	s_lshl_b32 s7, s6, 4                                       // 0000000ACD44: 84078406
	s_waitcnt vmcnt(0)                                         // 0000000ACD48: BF8903F7
	s_barrier                                                  // 0000000ACD4C: BFBD0000
	buffer_gl0_inv                                             // 0000000ACD50: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000000ACD58: BE812000
	s_cbranch_execz 112                                        // 0000000ACD5C: BFA50070 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xe20>
	v_dual_mov_b32 v130, v169 :: v_dual_mov_b32 v131, v168     // 0000000ACD60: CA1001A9 828201A8
	v_mov_b32_e32 v132, v167                                   // 0000000ACD68: 7F0803A7
	s_mov_b32 s8, 0                                            // 0000000ACD6C: BE880080
	s_nop 0                                                    // 0000000ACD70: BF800000
	s_nop 0                                                    // 0000000ACD74: BF800000
	s_nop 0                                                    // 0000000ACD78: BF800000
	s_nop 0                                                    // 0000000ACD7C: BF800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ACD80: BF870112
	v_min_i32_e32 v133, s15, v130                              // 0000000ACD84: 230B040F
	v_add_nc_u32_e32 v132, 0x180, v132                         // 0000000ACD88: 4B0908FF 00000180
	v_add_nc_u32_e32 v130, 12, v130                            // 0000000ACD90: 4B05048C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000ACD94: BF8701B3
	v_ashrrev_i32_e32 v135, 31, v133                           // 0000000ACD98: 350F0A9F
	.long 0xd72c0088                                           // 0000000ACD9C: D72C0088
	v_cndmask_b32_e32 v1, s11, v133, vcc_lo                    // 0000000ACDA0: 02030A0B
	v_mad_u64_u32 v[133:134], null, s10, v133, 0               // 0000000ACDA4: D6FE7C85 02030A0A
	.long 0xd72c0087                                           // 0000000ACDAC: D72C0087
	v_cndmask_b32_e32 v1, s10, v135, vcc_lo                    // 0000000ACDB0: 02030E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ACDB4: BF870091
	v_add3_u32 v134, v134, v135, v136                          // 0000000ACDB8: D6550086 06230F86
	.long 0xd73c0085                                           // 0000000ACDC0: D73C0085
	v_cndmask_b32_e32 v1, 1, v133, vcc_lo                      // 0000000ACDC4: 02030A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ACDC8: BF870091
	.long 0xd7006a85                                           // 0000000ACDCC: D7006A85
	v_cndmask_b32_e32 v1, v164, v133, vcc_lo                   // 0000000ACDD0: 02030BA4
	v_add_co_ci_u32_e64 v134, null, v165, v134, vcc_lo         // 0000000ACDD4: D5207C86 01AB0DA5
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v132                        // 0000000ACDDC: 7C9308FF 0000007F
	global_load_b128 v[133:136], v[133:134], off               // 0000000ACDE4: DC5E0000 857C0085
	s_or_b32 s8, vcc_lo, s8                                    // 0000000ACDEC: 8C08086A
	s_waitcnt vmcnt(0)                                         // 0000000ACDF0: BF8903F7
	ds_store_b128 v131, v[133:136] offset:31488                // 0000000ACDF4: DB7C7B00 00008583
	v_add_nc_u32_e32 v131, 0x18c0, v131                        // 0000000ACDFC: 4B0706FF 000018C0
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 0000000ACE04: 917E087E
	s_cbranch_execnz 65501                                     // 0000000ACE08: BFA6FFDD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc80>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000ACE0C: 8C7E087E
	v_or_b32_e32 v130, s7, v147                                // 0000000ACE10: 39052607
	s_mov_b32 s8, 0                                            // 0000000ACE14: BE880080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ACE18: BF870091
	v_min_i32_e32 v130, s15, v130                              // 0000000ACE1C: 2305040F
	v_ashrrev_i32_e32 v132, 31, v130                           // 0000000ACE20: 3509049F
	.long 0xd72c0085                                           // 0000000ACE24: D72C0085
	v_cndmask_b32_e32 v1, s11, v130, vcc_lo                    // 0000000ACE28: 0203040B
	v_mad_u64_u32 v[130:131], null, s10, v130, 0               // 0000000ACE2C: D6FE7C82 0203040A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ACE34: BF870093
	.long 0xd72c0084                                           // 0000000ACE38: D72C0084
	v_cndmask_b32_e32 v1, s10, v132, vcc_lo                    // 0000000ACE3C: 0203080A
	v_add3_u32 v131, v131, v132, v133                          // 0000000ACE40: D6550083 06170983
	v_mov_b32_e32 v133, v167                                   // 0000000ACE48: 7F0A03A7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ACE4C: BF870122
	.long 0xd73c0083                                           // 0000000ACE50: D73C0083
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000000ACE54: 02030481
	v_mov_b32_e32 v130, v0                                     // 0000000ACE58: 7F040300
	.long 0xd7006a83                                           // 0000000ACE5C: D7006A83
	v_cndmask_b32_e32 v1, s4, v131, vcc_lo                     // 0000000ACE60: 02030604
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ACE64: BF870001
	v_add_co_ci_u32_e64 v132, null, s5, v132, vcc_lo           // 0000000ACE68: D5207C84 01AB0805
	s_set_inst_prefetch_distance 0x1                           // 0000000ACE70: BF840001
	s_nop 0                                                    // 0000000ACE74: BF800000
	s_nop 0                                                    // 0000000ACE78: BF800000
	s_nop 0                                                    // 0000000ACE7C: BF800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000ACE80: BF8701B3
	v_and_b32_e32 v146, 0xf8, v130                             // 0000000ACE84: 372504FF 000000F8
	v_add_nc_u32_e32 v133, 0x180, v133                         // 0000000ACE8C: 4B0B0AFF 00000180
	v_add_nc_u32_e32 v130, 0xc0, v130                          // 0000000ACE94: 4B0504FF 000000C0
	v_lshlrev_b32_e32 v134, 1, v146                            // 0000000ACE9C: 310D2481
	v_mad_u32_u24 v146, v146, 48, v166                         // 0000000ACEA0: D60B0092 06996192
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ACEA8: BF870092
	.long 0xd7006a86                                           // 0000000ACEAC: D7006A86
	v_cndmask_b32_e32 v1, v131, v134, vcc_lo                   // 0000000ACEB0: 02030D83
	v_add_co_ci_u32_e64 v135, null, 0, v132, vcc_lo            // 0000000ACEB4: D5207C87 01AB0880
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v133                        // 0000000ACEBC: 7C930AFF 0000007F
	global_load_b128 v[134:137], v[134:135], off               // 0000000ACEC4: DC5E0000 867C0086
	s_waitcnt vmcnt(0)                                         // 0000000ACECC: BF8903F7
	ds_store_b16 v146, v134                                    // 0000000ACED0: D87C0000 00008692
	ds_store_b16_d16_hi v146, v134 offset:48                   // 0000000ACED8: DA840030 00008692
	ds_store_b16 v146, v135 offset:96                          // 0000000ACEE0: D87C0060 00008792
	ds_store_b16_d16_hi v146, v135 offset:144                  // 0000000ACEE8: DA840090 00008792
	ds_store_b16 v146, v136 offset:192                         // 0000000ACEF0: D87C00C0 00008892
	ds_store_b16_d16_hi v146, v136 offset:240                  // 0000000ACEF8: DA8400F0 00008892
	ds_store_b16 v146, v137 offset:288                         // 0000000ACF00: D87C0120 00008992
	ds_store_b16_d16_hi v146, v137 offset:336                  // 0000000ACF08: DA840150 00008992
	s_or_b32 s8, vcc_lo, s8                                    // 0000000ACF10: 8C08086A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000ACF14: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 0000000ACF18: 917E087E
	s_cbranch_execnz 65496                                     // 0000000ACF1C: BFA6FFD8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xd80>
	s_set_inst_prefetch_distance 0x2                           // 0000000ACF20: BF840002
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000ACF24: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 0000000ACF28: BF89FC07
	s_barrier                                                  // 0000000ACF2C: BFBD0000
	buffer_gl0_inv                                             // 0000000ACF30: E0AC0000 00000000
	s_clause 0x3                                               // 0000000ACF38: BF850003
	global_load_b128 v[174:177], v[143:144], off offset:16     // 0000000ACF3C: DC5E0010 AE7C008F
	global_load_b128 v[170:173], v[143:144], off               // 0000000ACF44: DC5E0000 AA7C008F
	global_load_b128 v[182:185], v[143:144], off offset:48     // 0000000ACF4C: DC5E0030 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:32     // 0000000ACF54: DC5E0020 B27C008F
	ds_load_b128 v[186:189], v152                              // 0000000ACF5C: DBFC0000 BA000098
	ds_load_b128 v[190:193], v152 offset:16                    // 0000000ACF64: DBFC0010 BE000098
	v_mov_b32_e32 v136, v129                                   // 0000000ACF6C: 7F100381
	v_mov_b32_e32 v130, v129                                   // 0000000ACF70: 7F040381
	v_mov_b32_e32 v131, v129                                   // 0000000ACF74: 7F060381
	v_mov_b32_e32 v132, v129                                   // 0000000ACF78: 7F080381
	v_mov_b32_e32 v133, v129                                   // 0000000ACF7C: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 0000000ACF80: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 0000000ACF84: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 0000000ACF88: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000ACF8C: BF870212
	v_mov_b32_e32 v136, v135                                   // 0000000ACF90: 7F100387
	v_mov_b32_e32 v135, v134                                   // 0000000ACF94: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 0000000ACF98: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 0000000ACF9C: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 0000000ACFA0: 7F080383
	v_mov_b32_e32 v131, v130                                   // 0000000ACFA4: 7F060382
	v_mov_b32_e32 v130, v129                                   // 0000000ACFA8: 7F040381
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000ACFAC: BF890807
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ACFB0: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[170:177], v[186:193], v[130:137]// 0000000ACFB4: CC414082 1E0B75AA
	s_clause 0x1                                               // 0000000ACFBC: BF850001
	global_load_b128 v[174:177], v[143:144], off offset:80     // 0000000ACFC0: DC5E0050 AE7C008F
	global_load_b128 v[170:173], v[143:144], off offset:64     // 0000000ACFC8: DC5E0040 AA7C008F
	ds_load_b128 v[186:189], v152 offset:32                    // 0000000ACFD0: DBFC0020 BA000098
	ds_load_b128 v[190:193], v152 offset:48                    // 0000000ACFD8: DBFC0030 BE000098
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000ACFE0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 0000000ACFE4: CC414082 1E0B75B2
	s_clause 0x1                                               // 0000000ACFEC: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:112    // 0000000ACFF0: DC5E0070 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:96     // 0000000ACFF8: DC5E0060 B27C008F
	ds_load_b128 v[190:193], v152 offset:80                    // 0000000AD000: DBFC0050 BE000098
	ds_load_b128 v[186:189], v152 offset:64                    // 0000000AD008: DBFC0040 BA000098
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000AD010: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[170:177], v[186:193], v[130:137]// 0000000AD014: CC414082 1E0B75AA
	s_clause 0x1                                               // 0000000AD01C: BF850001
	global_load_b128 v[174:177], v[143:144], off offset:144    // 0000000AD020: DC5E0090 AE7C008F
	global_load_b128 v[170:173], v[143:144], off offset:128    // 0000000AD028: DC5E0080 AA7C008F
	ds_load_b128 v[190:193], v152 offset:112                   // 0000000AD030: DBFC0070 BE000098
	ds_load_b128 v[186:189], v152 offset:96                    // 0000000AD038: DBFC0060 BA000098
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000AD040: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 0000000AD044: CC414082 1E0B75B2
	s_clause 0x1                                               // 0000000AD04C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:176    // 0000000AD050: DC5E00B0 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:160    // 0000000AD058: DC5E00A0 B27C008F
	ds_load_b128 v[190:193], v152 offset:144                   // 0000000AD060: DBFC0090 BE000098
	ds_load_b128 v[186:189], v152 offset:128                   // 0000000AD068: DBFC0080 BA000098
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000AD070: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[170:177], v[186:193], v[130:137]// 0000000AD074: CC414082 1E0B75AA
	s_clause 0x1                                               // 0000000AD07C: BF850001
	global_load_b128 v[174:177], v[143:144], off offset:208    // 0000000AD080: DC5E00D0 AE7C008F
	global_load_b128 v[170:173], v[143:144], off offset:192    // 0000000AD088: DC5E00C0 AA7C008F
	ds_load_b128 v[190:193], v152 offset:176                   // 0000000AD090: DBFC00B0 BE000098
	ds_load_b128 v[186:189], v152 offset:160                   // 0000000AD098: DBFC00A0 BA000098
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000AD0A0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 0000000AD0A4: CC414082 1E0B75B2
	s_clause 0x1                                               // 0000000AD0AC: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:240    // 0000000AD0B0: DC5E00F0 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:224    // 0000000AD0B8: DC5E00E0 B27C008F
	ds_load_b128 v[190:193], v152 offset:208                   // 0000000AD0C0: DBFC00D0 BE000098
	ds_load_b128 v[186:189], v152 offset:192                   // 0000000AD0C8: DBFC00C0 BA000098
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000AD0D0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[170:177], v[186:193], v[130:137]// 0000000AD0D4: CC414082 1E0B75AA
	s_clause 0x1                                               // 0000000AD0DC: BF850001
	global_load_b128 v[174:177], v[143:144], off offset:272    // 0000000AD0E0: DC5E0110 AE7C008F
	global_load_b128 v[170:173], v[143:144], off offset:256    // 0000000AD0E8: DC5E0100 AA7C008F
	ds_load_b128 v[190:193], v152 offset:240                   // 0000000AD0F0: DBFC00F0 BE000098
	ds_load_b128 v[186:189], v152 offset:224                   // 0000000AD0F8: DBFC00E0 BA000098
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000AD100: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 0000000AD104: CC414082 1E0B75B2
	s_clause 0x1                                               // 0000000AD10C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:304    // 0000000AD110: DC5E0130 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:288    // 0000000AD118: DC5E0120 B27C008F
	ds_load_b128 v[190:193], v152 offset:272                   // 0000000AD120: DBFC0110 BE000098
	ds_load_b128 v[186:189], v152 offset:256                   // 0000000AD128: DBFC0100 BA000098
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000AD130: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[170:177], v[186:193], v[130:137]// 0000000AD134: CC414082 1E0B75AA
	s_clause 0x1                                               // 0000000AD13C: BF850001
	global_load_b128 v[174:177], v[143:144], off offset:336    // 0000000AD140: DC5E0150 AE7C008F
	global_load_b128 v[170:173], v[143:144], off offset:320    // 0000000AD148: DC5E0140 AA7C008F
	ds_load_b128 v[190:193], v152 offset:304                   // 0000000AD150: DBFC0130 BE000098
	ds_load_b128 v[186:189], v152 offset:288                   // 0000000AD158: DBFC0120 BA000098
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000AD160: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 0000000AD164: CC414082 1E0B75B2
	s_clause 0x1                                               // 0000000AD16C: BF850001
	global_load_b128 v[182:185], v[143:144], off offset:368    // 0000000AD170: DC5E0170 B67C008F
	global_load_b128 v[178:181], v[143:144], off offset:352    // 0000000AD178: DC5E0160 B27C008F
	ds_load_b128 v[190:193], v152 offset:336                   // 0000000AD180: DBFC0150 BE000098
	ds_load_b128 v[186:189], v152 offset:320                   // 0000000AD188: DBFC0140 BA000098
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000AD190: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[170:177], v[186:193], v[130:137]// 0000000AD194: CC414082 1E0B75AA
	s_clause 0x1                                               // 0000000AD19C: BF850001
	global_load_b128 v[174:177], v[143:144], off offset:400    // 0000000AD1A0: DC5E0190 AE7C008F
	global_load_b128 v[170:173], v[143:144], off offset:384    // 0000000AD1A8: DC5E0180 AA7C008F
	ds_load_b128 v[190:193], v152 offset:368                   // 0000000AD1B0: DBFC0170 BE000098
	ds_load_b128 v[186:189], v152 offset:352                   // 0000000AD1B8: DBFC0160 BA000098
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000AD1C0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[178:185], v[186:193], v[130:137]// 0000000AD1C4: CC414082 1E0B75B2
	ds_load_b128 v[182:185], v152 offset:400                   // 0000000AD1CC: DBFC0190 B6000098
	ds_load_b128 v[178:181], v152 offset:384                   // 0000000AD1D4: DBFC0180 B2000098
	s_clause 0x1                                               // 0000000AD1DC: BF850001
	global_load_b128 v[190:193], v[143:144], off offset:432    // 0000000AD1E0: DC5E01B0 BE7C008F
	global_load_b128 v[186:189], v[143:144], off offset:416    // 0000000AD1E8: DC5E01A0 BA7C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000AD1F0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[170:177], v[178:185], v[130:137]// 0000000AD1F4: CC414082 1E0B65AA
	s_clause 0x1                                               // 0000000AD1FC: BF850001
	global_load_b128 v[174:177], v[143:144], off offset:464    // 0000000AD200: DC5E01D0 AE7C008F
	global_load_b128 v[170:173], v[143:144], off offset:448    // 0000000AD208: DC5E01C0 AA7C008F
	ds_load_b128 v[182:185], v152 offset:432                   // 0000000AD210: DBFC01B0 B6000098
	ds_load_b128 v[178:181], v152 offset:416                   // 0000000AD218: DBFC01A0 B2000098
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000AD220: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[186:193], v[178:185], v[130:137]// 0000000AD224: CC414082 1E0B65BA
	ds_load_b128 v[182:185], v152 offset:464                   // 0000000AD22C: DBFC01D0 B6000098
	ds_load_b128 v[178:181], v152 offset:448                   // 0000000AD234: DBFC01C0 B2000098
	s_clause 0x1                                               // 0000000AD23C: BF850001
	global_load_b128 v[190:193], v[143:144], off offset:496    // 0000000AD240: DC5E01F0 BE7C008F
	global_load_b128 v[186:189], v[143:144], off offset:480    // 0000000AD248: DC5E01E0 BA7C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000AD250: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[170:177], v[178:185], v[130:137]// 0000000AD254: CC414082 1E0B65AA
	ds_load_b128 v[174:177], v152 offset:496                   // 0000000AD25C: DBFC01F0 AE000098
	ds_load_b128 v[170:173], v152 offset:480                   // 0000000AD264: DBFC01E0 AA000098
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000AD26C: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[186:193], v[170:177], v[130:137]// 0000000AD270: CC414082 1E0B55BA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AD278: BF870111
	v_dual_mul_f32 v130, 0x3d800000, v130 :: v_dual_mul_f32 v131, 0x3d800000, v131// 0000000AD27C: C8C704FF 828306FF 3D800000
	v_mul_f32_e32 v146, 0x3d800000, v133                       // 0000000AD288: 11250AFF 3D800000
	v_mov_b32_e32 v133, 0xffff                                 // 0000000AD290: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000AD298: BF870004
	v_mul_f32_e32 v132, 0x3d800000, v132                       // 0000000AD29C: 110908FF 3D800000
	v_dual_mul_f32 v134, 0x3d800000, v134 :: v_dual_mul_f32 v135, 0x3d800000, v135// 0000000AD2A4: C8C70CFF 86870EFF 3D800000
	v_dual_mul_f32 v136, 0x3d800000, v136 :: v_dual_mul_f32 v137, 0x3d800000, v137// 0000000AD2B0: C8C710FF 888912FF 3D800000
	ds_store_2addr_b32 v153, v130, v131 offset1:34             // 0000000AD2BC: D8382200 00838299
	ds_store_2addr_b32 v153, v132, v146 offset0:68 offset1:102 // 0000000AD2C4: D8386644 00928499
	ds_store_2addr_b32 v153, v134, v135 offset0:136 offset1:170// 0000000AD2CC: D838AA88 00878699
	ds_store_2addr_b32 v153, v136, v137 offset0:204 offset1:238// 0000000AD2D4: D838EECC 00898899
	s_waitcnt lgkmcnt(0)                                       // 0000000AD2DC: BF89FC07
	s_barrier                                                  // 0000000AD2E0: BFBD0000
	buffer_gl0_inv                                             // 0000000AD2E4: E0AC0000 00000000
	s_and_saveexec_b32 s8, s23                                 // 0000000AD2EC: BE882017
	s_cbranch_execz 359                                        // 0000000AD2F0: BFA50167 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1790>
	s_lshl_b32 s9, s6, 2                                       // 0000000AD2F4: 84098206
	s_mov_b32 s22, exec_lo                                     // 0000000AD2F8: BE96007E
	.long 0xd4c1007e                                           // 0000000AD2FC: D4C1007E
	v_cndmask_b32_e32 v1, v145, v151, vcc_lo                   // 0000000AD300: 02032F91
	s_cbranch_execz 44                                         // 0000000AD304: BFA5002C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12b8>
	v_ashrrev_i32_e32 v146, 31, v145                           // 0000000AD308: 3525229F
	s_mov_b32 s24, 0                                           // 0000000AD30C: BE980080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AD310: BF870091
	.long 0xd73c0082                                           // 0000000AD314: D73C0082
	v_cndmask_b32_e32 v1, 2, v145, vcc_lo                      // 0000000AD318: 02032282
	.long 0xd7006a82                                           // 0000000AD31C: D7006A82
	v_cndmask_b32_e32 v1, v141, v130, vcc_lo                   // 0000000AD320: 0203058D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AD324: BF870001
	v_add_co_ci_u32_e64 v131, null, v142, v131, vcc_lo         // 0000000AD328: D5207C83 01AB078E
	s_branch 11                                                // 0000000AD330: BFA0000B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1260>
	s_nop 0                                                    // 0000000AD334: BF800000
	s_nop 0                                                    // 0000000AD338: BF800000
	s_nop 0                                                    // 0000000AD33C: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 0000000AD340: 8C7E1A7E
	v_mov_b32_e32 v133, v145                                   // 0000000AD344: 7F0A0391
	v_mov_b32_e32 v145, v132                                   // 0000000AD348: 7F220384
	s_and_b32 s1, exec_lo, s25                                 // 0000000AD34C: 8B01197E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000AD350: BF870499
	s_or_b32 s24, s1, s24                                      // 0000000AD354: 8C181801
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 0000000AD358: 917E187E
	s_cbranch_execz 20                                         // 0000000AD35C: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12b0>
	global_load_b32 v132, v[130:131], off                      // 0000000AD360: DC520000 847C0082
	s_or_b32 s25, s25, exec_lo                                 // 0000000AD368: 8C197E19
	s_waitcnt vmcnt(0)                                         // 0000000AD36C: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s9, v132                          // 0000000AD370: 7C890809
	s_and_saveexec_b32 s26, vcc_lo                             // 0000000AD374: BE9A206A
	s_cbranch_execz 65521                                      // 0000000AD378: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1240>
	v_dual_mov_b32 v145, v151 :: v_dual_add_nc_u32 v132, 1, v145// 0000000AD37C: CA200197 91852281
	.long 0xd7000182                                           // 0000000AD384: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 0000000AD388: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000AD38C: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 0000000AD390: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v151, v132                        // 0000000AD398: 7C950997
	s_and_not1_b32 s1, s25, exec_lo                            // 0000000AD39C: 91017E19
	s_and_b32 s25, vcc_lo, exec_lo                             // 0000000AD3A0: 8B197E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD3A4: BF870009
	s_or_b32 s25, s1, s25                                      // 0000000AD3A8: 8C191901
	s_branch 65508                                             // 0000000AD3AC: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1240>
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000AD3B0: 8C7E187E
	v_mov_b32_e32 v145, v133                                   // 0000000AD3B4: 7F220385
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000AD3B8: 8C7E167E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AD3BC: BF870001
	v_dual_mov_b32 v133, 15 :: v_dual_mov_b32 v130, v145       // 0000000AD3C0: CA10008F 85820191
	s_mov_b32 s1, exec_lo                                      // 0000000AD3C8: BE81007E
	.long 0xd4c1007e                                           // 0000000AD3CC: D4C1007E
	v_cndmask_b32_e32 v1, s9, v154, vcc_lo                     // 0000000AD3D0: 02033409
	s_cbranch_execz 62                                         // 0000000AD3D4: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13d0>
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v145        // 0000000AD3D8: CA100080 85820191
	s_mov_b32 s22, exec_lo                                     // 0000000AD3E0: BE96007E
	.long 0xd4c1007e                                           // 0000000AD3E4: D4C1007E
	v_cndmask_b32_e32 v1, v145, v151, vcc_lo                   // 0000000AD3E8: 02032F91
	s_cbranch_execz 54                                         // 0000000AD3EC: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13c8>
	v_mov_b32_e32 v130, v145                                   // 0000000AD3F0: 7F040391
	s_mov_b32 s25, 0                                           // 0000000AD3F4: BE990080
	s_set_inst_prefetch_distance 0x1                           // 0000000AD3F8: BF840001
	s_branch 10                                                // 0000000AD3FC: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1328>
	s_or_b32 exec_lo, exec_lo, s28                             // 0000000AD400: 8C7E1C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000AD404: BF870499
	s_and_b32 s28, exec_lo, s27                                // 0000000AD408: 8B1C1B7E
	s_or_b32 s25, s28, s25                                     // 0000000AD40C: 8C19191C
	s_and_not1_b32 s24, s24, exec_lo                           // 0000000AD410: 91187E18
	s_and_b32 s28, s26, exec_lo                                // 0000000AD414: 8B1C7E1A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD418: BF870009
	s_or_b32 s24, s24, s28                                     // 0000000AD41C: 8C181C18
	s_and_not1_b32 exec_lo, exec_lo, s25                       // 0000000AD420: 917E197E
	s_cbranch_execz 28                                         // 0000000AD424: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1398>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000AD428: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 0000000AD42C: 7F060382
	s_or_b32 s26, s26, exec_lo                                 // 0000000AD430: 8C1A7E1A
	s_or_b32 s27, s27, exec_lo                                 // 0000000AD434: 8C1B7E1B
	s_mov_b32 s28, exec_lo                                     // 0000000AD438: BE9C007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000AD43C: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AD440: BF870091
	.long 0xd73c0084                                           // 0000000AD444: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000AD448: 02030682
	.long 0xd7006a84                                           // 0000000AD44C: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 0000000AD450: 0203098D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AD454: BF870001
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 0000000AD458: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 0000000AD460: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 0000000AD468: BF8903F7
	.long 0xd4c4007e                                           // 0000000AD46C: D4C4007E
	v_cndmask_b32_e32 v1, s9, v132, vcc_lo                     // 0000000AD470: 02030809
	s_cbranch_execz 65506                                      // 0000000AD474: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1300>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000AD478: 4B050681
	s_and_not1_b32 s27, s27, exec_lo                           // 0000000AD47C: 911B7E1B
	s_and_not1_b32 s26, s26, exec_lo                           // 0000000AD480: 911A7E1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000AD484: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v151, v130                        // 0000000AD488: 7C950597
	s_and_b32 s29, vcc_lo, exec_lo                             // 0000000AD48C: 8B1D7E6A
	s_or_b32 s27, s27, s29                                     // 0000000AD490: 8C1B1D1B
	s_branch 65498                                             // 0000000AD494: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1300>
	s_set_inst_prefetch_distance 0x2                           // 0000000AD498: BF840002
	s_or_b32 exec_lo, exec_lo, s25                             // 0000000AD49C: 8C7E197E
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v151        // 0000000AD4A0: CA100080 85820197
	s_and_saveexec_b32 s25, s24                                // 0000000AD4A8: BE992018
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD4AC: BF870009
	s_xor_b32 s24, exec_lo, s25                                // 0000000AD4B0: 8D18197E
	v_cmp_eq_u32_e32 vcc_lo, s9, v132                          // 0000000AD4B4: 7C950809
	v_mov_b32_e32 v130, v131                                   // 0000000AD4B8: 7F040383
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 0000000AD4BC: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000AD4C4: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD4C8: BF870009
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000AD4CC: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD4D0: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000AD4D4: 8C7E017E
	s_or_b32 s22, s9, 1                                        // 0000000AD4D8: 8C168109
	s_mov_b32 s1, exec_lo                                      // 0000000AD4DC: BE81007E
	.long 0xd4c6007e                                           // 0000000AD4E0: D4C6007E
	v_cndmask_b32_e32 v1, s22, v154, vcc_lo                    // 0000000AD4E4: 02033416
	s_xor_b32 s1, exec_lo, s1                                  // 0000000AD4E8: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 0000000AD4EC: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 0000000AD4F4: BE813001
	s_cbranch_execz 70                                         // 0000000AD4F8: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1514>
	s_mov_b32 s24, exec_lo                                     // 0000000AD4FC: BE98007E
	.long 0xd4c1007e                                           // 0000000AD500: D4C1007E
	v_cndmask_b32_e32 v1, v130, v151, vcc_lo                   // 0000000AD504: 02032F82
	s_cbranch_execz 64                                         // 0000000AD508: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x150c>
	s_mov_b32 s26, 0                                           // 0000000AD50C: BE9A0080
	s_set_inst_prefetch_distance 0x1                           // 0000000AD510: BF840001
	s_branch 20                                                // 0000000AD514: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1468>
	s_nop 0                                                    // 0000000AD518: BF800000
	s_nop 0                                                    // 0000000AD51C: BF800000
	s_nop 0                                                    // 0000000AD520: BF800000
	s_nop 0                                                    // 0000000AD524: BF800000
	s_nop 0                                                    // 0000000AD528: BF800000
	s_nop 0                                                    // 0000000AD52C: BF800000
	s_nop 0                                                    // 0000000AD530: BF800000
	s_nop 0                                                    // 0000000AD534: BF800000
	s_nop 0                                                    // 0000000AD538: BF800000
	s_nop 0                                                    // 0000000AD53C: BF800000
	s_or_b32 exec_lo, exec_lo, s29                             // 0000000AD540: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000AD544: BF870499
	s_and_b32 s29, exec_lo, s28                                // 0000000AD548: 8B1D1C7E
	s_or_b32 s26, s29, s26                                     // 0000000AD54C: 8C1A1A1D
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000AD550: 91197E19
	s_and_b32 s29, s27, exec_lo                                // 0000000AD554: 8B1D7E1B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD558: BF870009
	s_or_b32 s25, s25, s29                                     // 0000000AD55C: 8C191D19
	s_and_not1_b32 exec_lo, exec_lo, s26                       // 0000000AD560: 917E1A7E
	s_cbranch_execz 27                                         // 0000000AD564: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14d4>
	v_mov_b32_e32 v131, v130                                   // 0000000AD568: 7F060382
	s_or_b32 s27, s27, exec_lo                                 // 0000000AD56C: 8C1B7E1B
	s_or_b32 s28, s28, exec_lo                                 // 0000000AD570: 8C1C7E1C
	s_mov_b32 s29, exec_lo                                     // 0000000AD574: BE9D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AD578: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000AD57C: 3509069F
	.long 0xd73c0086                                           // 0000000AD580: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000AD584: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AD588: BF870091
	.long 0xd7006a86                                           // 0000000AD58C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 0000000AD590: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 0000000AD594: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 0000000AD59C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 0000000AD5A4: BF8903F7
	.long 0xd4c6007e                                           // 0000000AD5A8: D4C6007E
	v_cndmask_b32_e32 v1, s9, v132, vcc_lo                     // 0000000AD5AC: 02030809
	s_cbranch_execz 65507                                      // 0000000AD5B0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1440>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000AD5B4: 4B050681
	s_and_not1_b32 s28, s28, exec_lo                           // 0000000AD5B8: 911C7E1C
	s_and_not1_b32 s27, s27, exec_lo                           // 0000000AD5BC: 911B7E1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000AD5C0: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v151, v130                        // 0000000AD5C4: 7C950597
	s_and_b32 s30, vcc_lo, exec_lo                             // 0000000AD5C8: 8B1E7E6A
	s_or_b32 s28, s28, s30                                     // 0000000AD5CC: 8C1C1E1C
	s_branch 65499                                             // 0000000AD5D0: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1440>
	s_set_inst_prefetch_distance 0x2                           // 0000000AD5D4: BF840002
	s_or_b32 exec_lo, exec_lo, s26                             // 0000000AD5D8: 8C7E1A7E
	v_mov_b32_e32 v130, v151                                   // 0000000AD5DC: 7F040397
	s_and_saveexec_b32 s26, s25                                // 0000000AD5E0: BE9A2019
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD5E4: BF870009
	s_xor_b32 s25, exec_lo, s26                                // 0000000AD5E8: 8D191A7E
	v_cmp_eq_u32_e32 vcc_lo, s22, v132                         // 0000000AD5EC: 7C950816
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 0000000AD5F0: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AD5FC: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000AD600: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 0000000AD604: 7F040383
	s_or_b32 exec_lo, exec_lo, s25                             // 0000000AD608: 8C7E197E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD60C: BF870009
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000AD610: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD614: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000AD618: 8C7E017E
	s_or_b32 s22, s9, 2                                        // 0000000AD61C: 8C168209
	s_mov_b32 s1, exec_lo                                      // 0000000AD620: BE81007E
	.long 0xd4c6007e                                           // 0000000AD624: D4C6007E
	v_cndmask_b32_e32 v1, s22, v154, vcc_lo                    // 0000000AD628: 02033416
	s_xor_b32 s1, exec_lo, s1                                  // 0000000AD62C: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 0000000AD630: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 0000000AD638: BE813001
	s_cbranch_execz 69                                         // 0000000AD63C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1654>
	s_mov_b32 s24, exec_lo                                     // 0000000AD640: BE98007E
	.long 0xd4c1007e                                           // 0000000AD644: D4C1007E
	v_cndmask_b32_e32 v1, v130, v151, vcc_lo                   // 0000000AD648: 02032F82
	s_cbranch_execz 63                                         // 0000000AD64C: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x164c>
	s_mov_b32 s26, 0                                           // 0000000AD650: BE9A0080
	s_set_inst_prefetch_distance 0x1                           // 0000000AD654: BF840001
	s_branch 19                                                // 0000000AD658: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15a8>
	s_nop 0                                                    // 0000000AD65C: BF800000
	s_nop 0                                                    // 0000000AD660: BF800000
	s_nop 0                                                    // 0000000AD664: BF800000
	s_nop 0                                                    // 0000000AD668: BF800000
	s_nop 0                                                    // 0000000AD66C: BF800000
	s_nop 0                                                    // 0000000AD670: BF800000
	s_nop 0                                                    // 0000000AD674: BF800000
	s_nop 0                                                    // 0000000AD678: BF800000
	s_nop 0                                                    // 0000000AD67C: BF800000
	s_or_b32 exec_lo, exec_lo, s29                             // 0000000AD680: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000AD684: BF870499
	s_and_b32 s29, exec_lo, s28                                // 0000000AD688: 8B1D1C7E
	s_or_b32 s26, s29, s26                                     // 0000000AD68C: 8C1A1A1D
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000AD690: 91197E19
	s_and_b32 s29, s27, exec_lo                                // 0000000AD694: 8B1D7E1B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD698: BF870009
	s_or_b32 s25, s25, s29                                     // 0000000AD69C: 8C191D19
	s_and_not1_b32 exec_lo, exec_lo, s26                       // 0000000AD6A0: 917E1A7E
	s_cbranch_execz 27                                         // 0000000AD6A4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1614>
	v_mov_b32_e32 v131, v130                                   // 0000000AD6A8: 7F060382
	s_or_b32 s27, s27, exec_lo                                 // 0000000AD6AC: 8C1B7E1B
	s_or_b32 s28, s28, exec_lo                                 // 0000000AD6B0: 8C1C7E1C
	s_mov_b32 s29, exec_lo                                     // 0000000AD6B4: BE9D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AD6B8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000AD6BC: 3509069F
	.long 0xd73c0086                                           // 0000000AD6C0: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000AD6C4: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AD6C8: BF870091
	.long 0xd7006a86                                           // 0000000AD6CC: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 0000000AD6D0: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 0000000AD6D4: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 0000000AD6DC: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 0000000AD6E4: BF8903F7
	.long 0xd4c4007e                                           // 0000000AD6E8: D4C4007E
	v_cndmask_b32_e32 v1, s22, v132, vcc_lo                    // 0000000AD6EC: 02030816
	s_cbranch_execz 65507                                      // 0000000AD6F0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1580>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000AD6F4: 4B050681
	s_and_not1_b32 s28, s28, exec_lo                           // 0000000AD6F8: 911C7E1C
	s_and_not1_b32 s27, s27, exec_lo                           // 0000000AD6FC: 911B7E1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000AD700: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v151, v130                        // 0000000AD704: 7C950597
	s_and_b32 s30, vcc_lo, exec_lo                             // 0000000AD708: 8B1E7E6A
	s_or_b32 s28, s28, s30                                     // 0000000AD70C: 8C1C1E1C
	s_branch 65499                                             // 0000000AD710: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1580>
	s_set_inst_prefetch_distance 0x2                           // 0000000AD714: BF840002
	s_or_b32 exec_lo, exec_lo, s26                             // 0000000AD718: 8C7E1A7E
	v_mov_b32_e32 v130, v151                                   // 0000000AD71C: 7F040397
	s_and_saveexec_b32 s26, s25                                // 0000000AD720: BE9A2019
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD724: BF870009
	s_xor_b32 s25, exec_lo, s26                                // 0000000AD728: 8D191A7E
	v_cmp_eq_u32_e32 vcc_lo, s22, v132                         // 0000000AD72C: 7C950816
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 0000000AD730: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AD73C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000AD740: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 0000000AD744: 7F040383
	s_or_b32 exec_lo, exec_lo, s25                             // 0000000AD748: 8C7E197E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD74C: BF870009
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000AD750: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD754: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000AD758: 8C7E017E
	s_or_b32 s9, s9, 3                                         // 0000000AD75C: 8C098309
	s_mov_b32 s1, exec_lo                                      // 0000000AD760: BE81007E
	.long 0xd4c6007e                                           // 0000000AD764: D4C6007E
	v_cndmask_b32_e32 v1, s9, v154, vcc_lo                     // 0000000AD768: 02033409
	s_xor_b32 s1, exec_lo, s1                                  // 0000000AD76C: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 0000000AD770: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 0000000AD778: BE813001
	s_cbranch_execz 66                                         // 0000000AD77C: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1788>
	s_mov_b32 s22, exec_lo                                     // 0000000AD780: BE96007E
	.long 0xd4c1007e                                           // 0000000AD784: D4C1007E
	v_cndmask_b32_e32 v1, v130, v151, vcc_lo                   // 0000000AD788: 02032F82
	s_cbranch_execz 60                                         // 0000000AD78C: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1780>
	s_mov_b32 s25, 0                                           // 0000000AD790: BE990080
	s_set_inst_prefetch_distance 0x1                           // 0000000AD794: BF840001
	s_branch 19                                                // 0000000AD798: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16e8>
	s_nop 0                                                    // 0000000AD79C: BF800000
	s_nop 0                                                    // 0000000AD7A0: BF800000
	s_nop 0                                                    // 0000000AD7A4: BF800000
	s_nop 0                                                    // 0000000AD7A8: BF800000
	s_nop 0                                                    // 0000000AD7AC: BF800000
	s_nop 0                                                    // 0000000AD7B0: BF800000
	s_nop 0                                                    // 0000000AD7B4: BF800000
	s_nop 0                                                    // 0000000AD7B8: BF800000
	s_nop 0                                                    // 0000000AD7BC: BF800000
	s_or_b32 exec_lo, exec_lo, s28                             // 0000000AD7C0: 8C7E1C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000AD7C4: BF870499
	s_and_b32 s28, exec_lo, s27                                // 0000000AD7C8: 8B1C1B7E
	s_or_b32 s25, s28, s25                                     // 0000000AD7CC: 8C19191C
	s_and_not1_b32 s24, s24, exec_lo                           // 0000000AD7D0: 91187E18
	s_and_b32 s28, s26, exec_lo                                // 0000000AD7D4: 8B1C7E1A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD7D8: BF870009
	s_or_b32 s24, s24, s28                                     // 0000000AD7DC: 8C181C18
	s_and_not1_b32 exec_lo, exec_lo, s25                       // 0000000AD7E0: 917E197E
	s_cbranch_execz 26                                         // 0000000AD7E4: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1750>
	v_ashrrev_i32_e32 v131, 31, v130                           // 0000000AD7E8: 3507049F
	s_or_b32 s26, s26, exec_lo                                 // 0000000AD7EC: 8C1A7E1A
	s_or_b32 s27, s27, exec_lo                                 // 0000000AD7F0: 8C1B7E1B
	s_mov_b32 s28, exec_lo                                     // 0000000AD7F4: BE9C007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AD7F8: BF870091
	.long 0xd73c0083                                           // 0000000AD7FC: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 0000000AD800: 02030482
	.long 0xd7006a83                                           // 0000000AD804: D7006A83
	v_cndmask_b32_e32 v1, v141, v131, vcc_lo                   // 0000000AD808: 0203078D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AD80C: BF870001
	v_add_co_ci_u32_e64 v132, null, v142, v132, vcc_lo         // 0000000AD810: D5207C84 01AB098E
	global_load_b32 v131, v[131:132], off                      // 0000000AD818: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 0000000AD820: BF8903F7
	.long 0xd4c4007e                                           // 0000000AD824: D4C4007E
	v_cndmask_b32_e32 v1, s9, v131, vcc_lo                     // 0000000AD828: 02030609
	s_cbranch_execz 65508                                      // 0000000AD82C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c0>
	v_add_nc_u32_e32 v130, 1, v130                             // 0000000AD830: 4B050481
	s_and_not1_b32 s27, s27, exec_lo                           // 0000000AD834: 911B7E1B
	s_and_not1_b32 s26, s26, exec_lo                           // 0000000AD838: 911A7E1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000AD83C: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v151, v130                        // 0000000AD840: 7C950597
	s_and_b32 s29, vcc_lo, exec_lo                             // 0000000AD844: 8B1D7E6A
	s_or_b32 s27, s27, s29                                     // 0000000AD848: 8C1B1D1B
	s_branch 65500                                             // 0000000AD84C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000AD850: BF840002
	s_or_b32 exec_lo, exec_lo, s25                             // 0000000AD854: 8C7E197E
	s_and_saveexec_b32 s25, s24                                // 0000000AD858: BE992018
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD85C: BF870009
	s_xor_b32 s24, exec_lo, s25                                // 0000000AD860: 8D18197E
	v_cmp_eq_u32_e32 vcc_lo, s9, v131                          // 0000000AD864: 7C950609
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 0000000AD868: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AD874: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000AD878: 390B0B82
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000AD87C: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD880: BF870009
	s_or_b32 exec_lo, exec_lo, s22                             // 0000000AD884: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD888: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000AD88C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD890: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AD894: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AD898: BE882003
	s_cbranch_execz 64524                                      // 0000000AD89C: BFA5FC0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7d0>
	ds_load_b32 v131, v156                                     // 0000000AD8A0: D8D80000 8300009C
	v_and_b32_e32 v130, 1, v133                                // 0000000AD8A8: 37050A81
	v_cmp_le_i32_e32 vcc_lo, s7, v155                          // 0000000AD8AC: 7C873607
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000AD8B0: BF870002
	.long 0xd44a0001                                           // 0000000AD8B4: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000000AD8B8: 02030481
	s_and_b32 s37, vcc_lo, s1                                  // 0000000AD8BC: 8B25016A
	s_waitcnt lgkmcnt(0)                                       // 0000000AD8C0: BF89FC07
	v_mov_b32_e32 v130, v131                                   // 0000000AD8C4: 7F040383
	s_and_saveexec_b32 s1, s37                                 // 0000000AD8C8: BE812025
	s_cbranch_execz 7                                          // 0000000AD8CC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17ec>
	ds_load_b32 v130, v157                                     // 0000000AD8D0: D8D80000 8200009D
	v_max_f32_e32 v132, v131, v131                             // 0000000AD8D8: 21090783
	s_waitcnt lgkmcnt(0)                                       // 0000000AD8DC: BF89FC07
	v_max_f32_e32 v130, v130, v130                             // 0000000AD8E0: 21050582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AD8E4: BF870001
	v_max_f32_e32 v130, v132, v130                             // 0000000AD8E8: 21050584
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000AD8EC: 8C7E017E
	v_and_b32_e32 v132, 2, v133                                // 0000000AD8F0: 37090A82
	v_cmp_lt_i32_e32 vcc_lo, s7, v155                          // 0000000AD8F4: 7C833607
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000AD8F8: BF8704A2
	.long 0xd44d0001                                           // 0000000AD8FC: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000AD900: 02030880
	s_and_b32 s36, vcc_lo, s1                                  // 0000000AD904: 8B24016A
	s_and_saveexec_b32 s1, s36                                 // 0000000AD908: BE812024
	s_cbranch_execz 7                                          // 0000000AD90C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x182c>
	ds_load_b32 v132, v157 offset:4                            // 0000000AD910: D8D80004 8400009D
	v_max_f32_e32 v130, v130, v130                             // 0000000AD918: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000AD91C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000AD920: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AD924: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000AD928: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000AD92C: 8C7E017E
	v_and_b32_e32 v132, 4, v133                                // 0000000AD930: 37090A84
	s_or_b32 s1, s7, 2                                         // 0000000AD934: 8C018207
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AD938: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v155                          // 0000000AD93C: 7C873601
	.long 0xd44d0001                                           // 0000000AD940: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000AD944: 02030880
	s_and_b32 s35, vcc_lo, s1                                  // 0000000AD948: 8B23016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD94C: BF870009
	s_and_saveexec_b32 s1, s35                                 // 0000000AD950: BE812023
	s_cbranch_execz 7                                          // 0000000AD954: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1874>
	ds_load_b32 v132, v157 offset:8                            // 0000000AD958: D8D80008 8400009D
	v_max_f32_e32 v130, v130, v130                             // 0000000AD960: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000AD964: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000AD968: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AD96C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000AD970: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000AD974: 8C7E017E
	v_and_b32_e32 v132, 8, v133                                // 0000000AD978: 37090A88
	s_or_b32 s1, s7, 3                                         // 0000000AD97C: 8C018307
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AD980: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v155                          // 0000000AD984: 7C873601
	.long 0xd44d0001                                           // 0000000AD988: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000AD98C: 02030880
	s_and_b32 s34, vcc_lo, s1                                  // 0000000AD990: 8B22016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD994: BF870009
	s_and_saveexec_b32 s1, s34                                 // 0000000AD998: BE812022
	s_cbranch_execz 7                                          // 0000000AD99C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18bc>
	ds_load_b32 v132, v157 offset:12                           // 0000000AD9A0: D8D8000C 8400009D
	v_max_f32_e32 v130, v130, v130                             // 0000000AD9A8: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000AD9AC: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000AD9B0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AD9B4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000AD9B8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000AD9BC: 8C7E017E
	v_and_b32_e32 v132, 16, v133                               // 0000000AD9C0: 37090A90
	s_or_b32 s1, s7, 4                                         // 0000000AD9C4: 8C018407
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AD9C8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v155                          // 0000000AD9CC: 7C873601
	.long 0xd44d0001                                           // 0000000AD9D0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000AD9D4: 02030880
	s_and_b32 s33, vcc_lo, s1                                  // 0000000AD9D8: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000AD9DC: BF870009
	s_and_saveexec_b32 s1, s33                                 // 0000000AD9E0: BE812021
	s_cbranch_execz 7                                          // 0000000AD9E4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1904>
	ds_load_b32 v132, v157 offset:16                           // 0000000AD9E8: D8D80010 8400009D
	v_max_f32_e32 v130, v130, v130                             // 0000000AD9F0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000AD9F4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000AD9F8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AD9FC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000ADA00: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000ADA04: 8C7E017E
	v_and_b32_e32 v132, 32, v133                               // 0000000ADA08: 37090AA0
	s_or_b32 s1, s7, 5                                         // 0000000ADA0C: 8C018507
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ADA10: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v155                          // 0000000ADA14: 7C873601
	.long 0xd44d0001                                           // 0000000ADA18: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000ADA1C: 02030880
	s_and_b32 s31, vcc_lo, s1                                  // 0000000ADA20: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000ADA24: BF870009
	s_and_saveexec_b32 s1, s31                                 // 0000000ADA28: BE81201F
	s_cbranch_execz 7                                          // 0000000ADA2C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x194c>
	ds_load_b32 v132, v157 offset:20                           // 0000000ADA30: D8D80014 8400009D
	v_max_f32_e32 v130, v130, v130                             // 0000000ADA38: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000ADA3C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000ADA40: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ADA44: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000ADA48: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000ADA4C: 8C7E017E
	v_and_b32_e32 v132, 64, v133                               // 0000000ADA50: 37090AC0
	s_or_b32 s1, s7, 6                                         // 0000000ADA54: 8C018607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ADA58: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v155                          // 0000000ADA5C: 7C873601
	.long 0xd44d0001                                           // 0000000ADA60: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000ADA64: 02030880
	s_and_b32 s30, vcc_lo, s1                                  // 0000000ADA68: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000ADA6C: BF870009
	s_and_saveexec_b32 s1, s30                                 // 0000000ADA70: BE81201E
	s_cbranch_execz 7                                          // 0000000ADA74: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1994>
	ds_load_b32 v132, v157 offset:24                           // 0000000ADA78: D8D80018 8400009D
	v_max_f32_e32 v130, v130, v130                             // 0000000ADA80: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000ADA84: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000ADA88: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ADA8C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000ADA90: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000ADA94: 8C7E017E
	v_and_b32_e32 v132, 0x80, v133                             // 0000000ADA98: 37090AFF 00000080
	s_or_b32 s1, s7, 7                                         // 0000000ADAA0: 8C018707
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ADAA4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v155                          // 0000000ADAA8: 7C873601
	.long 0xd44d0001                                           // 0000000ADAAC: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000ADAB0: 02030880
	s_and_b32 s29, vcc_lo, s1                                  // 0000000ADAB4: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000ADAB8: BF870009
	s_and_saveexec_b32 s1, s29                                 // 0000000ADABC: BE81201D
	s_cbranch_execz 7                                          // 0000000ADAC0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19e0>
	ds_load_b32 v132, v157 offset:28                           // 0000000ADAC4: D8D8001C 8400009D
	v_max_f32_e32 v130, v130, v130                             // 0000000ADACC: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000ADAD0: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000ADAD4: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ADAD8: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000ADADC: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000ADAE0: 8C7E017E
	v_and_b32_e32 v132, 0x100, v133                            // 0000000ADAE4: 37090AFF 00000100
	s_or_b32 s1, s7, 8                                         // 0000000ADAEC: 8C018807
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ADAF0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v155                          // 0000000ADAF4: 7C873601
	.long 0xd44d0001                                           // 0000000ADAF8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000ADAFC: 02030880
	s_and_b32 s28, vcc_lo, s1                                  // 0000000ADB00: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000ADB04: BF870009
	s_and_saveexec_b32 s1, s28                                 // 0000000ADB08: BE81201C
	s_cbranch_execz 7                                          // 0000000ADB0C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a2c>
	ds_load_b32 v132, v157 offset:32                           // 0000000ADB10: D8D80020 8400009D
	v_max_f32_e32 v130, v130, v130                             // 0000000ADB18: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000ADB1C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000ADB20: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ADB24: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000ADB28: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000ADB2C: 8C7E017E
	v_and_b32_e32 v132, 0x200, v133                            // 0000000ADB30: 37090AFF 00000200
	s_or_b32 s1, s7, 9                                         // 0000000ADB38: 8C018907
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ADB3C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v155                          // 0000000ADB40: 7C873601
	.long 0xd44d0001                                           // 0000000ADB44: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000ADB48: 02030880
	s_and_b32 s27, vcc_lo, s1                                  // 0000000ADB4C: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000ADB50: BF870009
	s_and_saveexec_b32 s1, s27                                 // 0000000ADB54: BE81201B
	s_cbranch_execz 7                                          // 0000000ADB58: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a78>
	ds_load_b32 v132, v157 offset:36                           // 0000000ADB5C: D8D80024 8400009D
	v_max_f32_e32 v130, v130, v130                             // 0000000ADB64: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000ADB68: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000ADB6C: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ADB70: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000ADB74: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000ADB78: 8C7E017E
	v_and_b32_e32 v132, 0x400, v133                            // 0000000ADB7C: 37090AFF 00000400
	s_or_b32 s1, s7, 10                                        // 0000000ADB84: 8C018A07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ADB88: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v155                          // 0000000ADB8C: 7C873601
	.long 0xd44d0001                                           // 0000000ADB90: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000ADB94: 02030880
	s_and_b32 s26, vcc_lo, s1                                  // 0000000ADB98: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000ADB9C: BF870009
	s_and_saveexec_b32 s1, s26                                 // 0000000ADBA0: BE81201A
	s_cbranch_execz 7                                          // 0000000ADBA4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ac4>
	ds_load_b32 v132, v157 offset:40                           // 0000000ADBA8: D8D80028 8400009D
	v_max_f32_e32 v130, v130, v130                             // 0000000ADBB0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000ADBB4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000ADBB8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ADBBC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000ADBC0: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000ADBC4: 8C7E017E
	v_and_b32_e32 v132, 0x800, v133                            // 0000000ADBC8: 37090AFF 00000800
	s_or_b32 s1, s7, 11                                        // 0000000ADBD0: 8C018B07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ADBD4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v155                          // 0000000ADBD8: 7C873601
	.long 0xd44d0001                                           // 0000000ADBDC: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000ADBE0: 02030880
	s_and_b32 s25, vcc_lo, s1                                  // 0000000ADBE4: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000ADBE8: BF870009
	s_and_saveexec_b32 s1, s25                                 // 0000000ADBEC: BE812019
	s_cbranch_execz 7                                          // 0000000ADBF0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b10>
	ds_load_b32 v132, v157 offset:44                           // 0000000ADBF4: D8D8002C 8400009D
	v_max_f32_e32 v130, v130, v130                             // 0000000ADBFC: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000ADC00: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000ADC04: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ADC08: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000ADC0C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000ADC10: 8C7E017E
	v_and_b32_e32 v132, 0x1000, v133                           // 0000000ADC14: 37090AFF 00001000
	s_or_b32 s1, s7, 12                                        // 0000000ADC1C: 8C018C07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ADC20: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v155                          // 0000000ADC24: 7C873601
	.long 0xd44d0001                                           // 0000000ADC28: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000ADC2C: 02030880
	s_and_b32 s24, vcc_lo, s1                                  // 0000000ADC30: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000ADC34: BF870009
	s_and_saveexec_b32 s1, s24                                 // 0000000ADC38: BE812018
	s_cbranch_execz 7                                          // 0000000ADC3C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b5c>
	ds_load_b32 v132, v157 offset:48                           // 0000000ADC40: D8D80030 8400009D
	v_max_f32_e32 v130, v130, v130                             // 0000000ADC48: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000ADC4C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000ADC50: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ADC54: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000ADC58: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000ADC5C: 8C7E017E
	v_and_b32_e32 v132, 0x2000, v133                           // 0000000ADC60: 37090AFF 00002000
	s_or_b32 s1, s7, 13                                        // 0000000ADC68: 8C018D07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ADC6C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v155                          // 0000000ADC70: 7C873601
	.long 0xd44d0001                                           // 0000000ADC74: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000ADC78: 02030880
	s_and_b32 s22, vcc_lo, s1                                  // 0000000ADC7C: 8B16016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000ADC80: BF870009
	s_and_saveexec_b32 s1, s22                                 // 0000000ADC84: BE812016
	s_cbranch_execz 7                                          // 0000000ADC88: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ba8>
	ds_load_b32 v132, v157 offset:52                           // 0000000ADC8C: D8D80034 8400009D
	v_max_f32_e32 v130, v130, v130                             // 0000000ADC94: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000ADC98: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000ADC9C: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ADCA0: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000ADCA4: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000ADCA8: 8C7E017E
	v_and_b32_e32 v132, 0x4000, v133                           // 0000000ADCAC: 37090AFF 00004000
	s_or_b32 s1, s7, 14                                        // 0000000ADCB4: 8C018E07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ADCB8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v155                          // 0000000ADCBC: 7C873601
	.long 0xd44d0001                                           // 0000000ADCC0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000ADCC4: 02030880
	s_and_b32 s9, vcc_lo, s1                                   // 0000000ADCC8: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000ADCCC: BF870009
	s_and_saveexec_b32 s1, s9                                  // 0000000ADCD0: BE812009
	s_cbranch_execz 7                                          // 0000000ADCD4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1bf4>
	ds_load_b32 v132, v157 offset:56                           // 0000000ADCD8: D8D80038 8400009D
	v_max_f32_e32 v130, v130, v130                             // 0000000ADCE0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000ADCE4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000ADCE8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ADCEC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000ADCF0: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000ADCF4: 8C7E017E
	v_and_b32_e32 v132, 0x8000, v133                           // 0000000ADCF8: 37090AFF 00008000
	s_or_b32 s7, s7, 15                                        // 0000000ADD00: 8C078F07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ADD04: BF870119
	v_cmp_le_i32_e32 vcc_lo, s7, v155                          // 0000000ADD08: 7C873607
	.long 0xd44d0001                                           // 0000000ADD0C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000ADD10: 02030880
	s_and_b32 s1, vcc_lo, s1                                   // 0000000ADD14: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000ADD18: BF870009
	s_and_saveexec_b32 s7, s1                                  // 0000000ADD1C: BE872001
	s_cbranch_execz 7                                          // 0000000ADD20: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c40>
	ds_load_b32 v132, v157 offset:60                           // 0000000ADD24: D8D8003C 8400009D
	v_max_f32_e32 v130, v130, v130                             // 0000000ADD2C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000ADD30: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000ADD34: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000ADD38: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000ADD3C: 21050982
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000ADD40: 8C7E077E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v133, 0           // 0000000ADD44: CA100080 84840080
	s_and_saveexec_b32 s7, s37                                 // 0000000ADD4C: BE872025
	s_cbranch_execz 30                                         // 0000000ADD50: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ccc>
	ds_load_b32 v133, v157                                     // 0000000ADD54: D8D80000 8500009D
	s_waitcnt lgkmcnt(0)                                       // 0000000ADD5C: BF89FC07
	v_sub_f32_e32 v133, v133, v130                             // 0000000ADD60: 090B0585
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ADD64: BF870091
	v_mul_f32_e32 v134, 0x3fb8aa3b, v133                       // 0000000ADD68: 110D0AFF 3FB8AA3B
	v_fma_f32 v135, 0x3fb8aa3b, v133, -v134                    // 0000000ADD70: D6130087 861B0AFF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 0000000ADD7C: 7F104786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000ADD80: BF870221
	v_sub_f32_e32 v134, v134, v136                             // 0000000ADD84: 090D1186
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 0000000ADD88: 7C370AFF C2CE8ED0
	v_fmac_f32_e32 v135, 0x32a5705f, v133                      // 0000000ADD90: 570F0AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ADD98: BF870121
	v_add_f32_e32 v134, v134, v135                             // 0000000ADD9C: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 0000000ADDA0: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 0000000ADDA4: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ADDA8: BF870095
	.long 0xd71c0086                                           // 0000000ADDAC: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 0000000ADDB0: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 0000000ADDB4: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 0000000ADDB8: 7C3D0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000ADDC0: BF870002
	v_cndmask_b32_e32 v133, 0x7f800000, v134, vcc_lo           // 0000000ADDC4: 030B0CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000ADDCC: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ADDD0: BF870091
	v_bfe_u32 v134, v133, 16, 1                                // 0000000ADDD4: D6100086 02052185
	v_add3_u32 v134, v133, v134, 0x7fff                        // 0000000ADDDC: D6550086 03FF0D85 00007FFF
	ds_store_b16_d16_hi v158, v134                             // 0000000ADDE8: DA840000 0000869E
	s_and_saveexec_b32 s7, s36                                 // 0000000ADDF0: BE872024
	s_cbranch_execz 30                                         // 0000000ADDF4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d70>
	ds_load_b32 v132, v157 offset:4                            // 0000000ADDF8: D8D80004 8400009D
	s_waitcnt lgkmcnt(0)                                       // 0000000ADE00: BF89FC07
	v_sub_f32_e32 v132, v132, v130                             // 0000000ADE04: 09090584
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ADE08: BF870121
	v_mul_f32_e32 v134, 0x3fb8aa3b, v132                       // 0000000ADE0C: 110D08FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v132                 // 0000000ADE14: 7C3708FF C2CE8ED0
	v_fma_f32 v135, 0x3fb8aa3b, v132, -v134                    // 0000000ADE1C: D6130087 861B08FF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 0000000ADE28: 7F104786
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ADE2C: BF870112
	v_fmac_f32_e32 v135, 0x32a5705f, v132                      // 0000000ADE30: 570F08FF 32A5705F
	v_sub_f32_e32 v134, v134, v136                             // 0000000ADE38: 090D1186
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ADE3C: BF870121
	v_add_f32_e32 v134, v134, v135                             // 0000000ADE40: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 0000000ADE44: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 0000000ADE48: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ADE4C: BF870095
	.long 0xd71c0086                                           // 0000000ADE50: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 0000000ADE54: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 0000000ADE58: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v132                 // 0000000ADE5C: 7C3D08FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000ADE64: BF870002
	v_cndmask_b32_e32 v132, 0x7f800000, v134, vcc_lo           // 0000000ADE68: 03090CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000ADE70: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ADE74: BF870121
	v_bfe_u32 v134, v132, 16, 1                                // 0000000ADE78: D6100086 02052184
	v_mov_b32_e32 v135, 0                                      // 0000000ADE80: 7F0E0280
	v_add3_u32 v136, v132, v134, 0x7fff                        // 0000000ADE84: D6550088 03FF0D84 00007FFF
	v_mov_b32_e32 v134, 0                                      // 0000000ADE90: 7F0C0280
	ds_store_b16_d16_hi v158, v136 offset:2                    // 0000000ADE94: DA840002 0000889E
	s_and_saveexec_b32 s7, s35                                 // 0000000ADE9C: BE872023
	s_cbranch_execz 29                                         // 0000000ADEA0: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e18>
	ds_load_b32 v135, v157 offset:8                            // 0000000ADEA4: D8D80008 8700009D
	s_waitcnt lgkmcnt(0)                                       // 0000000ADEAC: BF89FC07
	v_sub_f32_e32 v135, v135, v130                             // 0000000ADEB0: 090F0587
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ADEB4: BF870091
	v_mul_f32_e32 v136, 0x3fb8aa3b, v135                       // 0000000ADEB8: 11110EFF 3FB8AA3B
	v_fma_f32 v137, 0x3fb8aa3b, v135, -v136                    // 0000000ADEC0: D6130089 86230EFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 0000000ADECC: 7F244788
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ADED0: BF870091
	v_dual_fmac_f32 v137, 0x32a5705f, v135 :: v_dual_sub_f32 v136, v136, v146// 0000000ADED4: C80B0EFF 89892588 32A5705F
	v_add_f32_e32 v136, v136, v137                             // 0000000ADEE0: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 0000000ADEE4: 7F121192
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 0000000ADEE8: 7C370EFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000ADEF0: BF870293
	v_exp_f32_e32 v136, v136                                   // 0000000ADEF4: 7F104B88
	.long 0xd71c0088                                           // 0000000ADEF8: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 0000000ADEFC: 02031388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ADF00: BF870121
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 0000000ADF04: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 0000000ADF08: 7C3D0EFF 42B17218
	v_cndmask_b32_e32 v135, 0x7f800000, v136, vcc_lo           // 0000000ADF10: 030F10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000ADF18: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ADF1C: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 0000000ADF20: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 0000000ADF28: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v158, v136 offset:4                    // 0000000ADF34: DA840004 0000889E
	s_and_saveexec_b32 s7, s34                                 // 0000000ADF3C: BE872022
	s_cbranch_execz 30                                         // 0000000ADF40: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ebc>
	ds_load_b32 v134, v157 offset:12                           // 0000000ADF44: D8D8000C 8600009D
	s_waitcnt lgkmcnt(0)                                       // 0000000ADF4C: BF89FC07
	v_sub_f32_e32 v134, v134, v130                             // 0000000ADF50: 090D0586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ADF54: BF870121
	v_mul_f32_e32 v136, 0x3fb8aa3b, v134                       // 0000000ADF58: 11110CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 0000000ADF60: 7C370CFF C2CE8ED0
	v_fma_f32 v137, 0x3fb8aa3b, v134, -v136                    // 0000000ADF68: D6130089 86230CFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 0000000ADF74: 7F244788
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000ADF78: BF870112
	v_fmac_f32_e32 v137, 0x32a5705f, v134                      // 0000000ADF7C: 57130CFF 32A5705F
	v_sub_f32_e32 v136, v136, v146                             // 0000000ADF84: 09112588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ADF88: BF870121
	v_add_f32_e32 v136, v136, v137                             // 0000000ADF8C: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 0000000ADF90: 7F121192
	v_exp_f32_e32 v136, v136                                   // 0000000ADF94: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ADF98: BF870095
	.long 0xd71c0088                                           // 0000000ADF9C: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 0000000ADFA0: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 0000000ADFA4: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 0000000ADFA8: 7C3D0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000ADFB0: BF870002
	v_cndmask_b32_e32 v134, 0x7f800000, v136, vcc_lo           // 0000000ADFB4: 030D10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000ADFBC: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ADFC0: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 0000000ADFC4: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 0000000ADFCC: 7F120280
	v_add3_u32 v146, v134, v136, 0x7fff                        // 0000000ADFD0: D6550092 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 0000000ADFDC: 7F100280
	ds_store_b16_d16_hi v158, v146 offset:6                    // 0000000ADFE0: DA840006 0000929E
	s_and_saveexec_b32 s7, s33                                 // 0000000ADFE8: BE872021
	s_cbranch_execz 30                                         // 0000000ADFEC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f68>
	ds_load_b32 v137, v157 offset:16                           // 0000000ADFF0: D8D80010 8900009D
	s_waitcnt lgkmcnt(0)                                       // 0000000ADFF8: BF89FC07
	v_sub_f32_e32 v137, v137, v130                             // 0000000ADFFC: 09130589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE000: BF870091
	v_mul_f32_e32 v146, 0x3fb8aa3b, v137                       // 0000000AE004: 112512FF 3FB8AA3B
	v_fma_f32 v170, 0x3fb8aa3b, v137, -v146                    // 0000000AE00C: D61300AA 864B12FF 3FB8AA3B
	v_rndne_f32_e32 v171, v146                                 // 0000000AE018: 7F564792
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000AE01C: BF870191
	v_sub_f32_e32 v146, v146, v171                             // 0000000AE020: 09255792
	v_fmac_f32_e32 v170, 0x32a5705f, v137                      // 0000000AE024: 575512FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v137                 // 0000000AE02C: 7C3712FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE034: BF870122
	v_add_f32_e32 v146, v146, v170                             // 0000000AE038: 07255592
	v_cvt_i32_f32_e32 v170, v171                               // 0000000AE03C: 7F5411AB
	v_exp_f32_e32 v146, v146                                   // 0000000AE040: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE044: BF870095
	.long 0xd71c0092                                           // 0000000AE048: D71C0092
	v_cndmask_b32_e32 v1, v146, v170, vcc_lo                   // 0000000AE04C: 02035592
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 0000000AE050: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v137                 // 0000000AE054: 7C3D12FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000AE05C: BF870002
	v_cndmask_b32_e32 v137, 0x7f800000, v146, vcc_lo           // 0000000AE060: 031324FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000AE068: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE06C: BF870091
	v_bfe_u32 v146, v137, 16, 1                                // 0000000AE070: D6100092 02052189
	v_add3_u32 v146, v137, v146, 0x7fff                        // 0000000AE078: D6550092 03FF2589 00007FFF
	ds_store_b16_d16_hi v158, v146 offset:8                    // 0000000AE084: DA840008 0000929E
	s_and_saveexec_b32 s7, s31                                 // 0000000AE08C: BE87201F
	s_cbranch_execz 30                                         // 0000000AE090: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x200c>
	ds_load_b32 v136, v157 offset:20                           // 0000000AE094: D8D80014 8800009D
	s_waitcnt lgkmcnt(0)                                       // 0000000AE09C: BF89FC07
	v_sub_f32_e32 v136, v136, v130                             // 0000000AE0A0: 09110588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE0A4: BF870121
	v_mul_f32_e32 v146, 0x3fb8aa3b, v136                       // 0000000AE0A8: 112510FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 0000000AE0B0: 7C3710FF C2CE8ED0
	v_fma_f32 v170, 0x3fb8aa3b, v136, -v146                    // 0000000AE0B8: D61300AA 864B10FF 3FB8AA3B
	v_rndne_f32_e32 v171, v146                                 // 0000000AE0C4: 7F564792
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AE0C8: BF870112
	v_fmac_f32_e32 v170, 0x32a5705f, v136                      // 0000000AE0CC: 575510FF 32A5705F
	v_sub_f32_e32 v146, v146, v171                             // 0000000AE0D4: 09255792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE0D8: BF870121
	v_add_f32_e32 v146, v146, v170                             // 0000000AE0DC: 07255592
	v_cvt_i32_f32_e32 v170, v171                               // 0000000AE0E0: 7F5411AB
	v_exp_f32_e32 v146, v146                                   // 0000000AE0E4: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE0E8: BF870095
	.long 0xd71c0092                                           // 0000000AE0EC: D71C0092
	v_cndmask_b32_e32 v1, v146, v170, vcc_lo                   // 0000000AE0F0: 02035592
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 0000000AE0F4: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 0000000AE0F8: 7C3D10FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000AE100: BF870002
	v_cndmask_b32_e32 v136, 0x7f800000, v146, vcc_lo           // 0000000AE104: 031124FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000AE10C: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE110: BF870121
	v_bfe_u32 v146, v136, 16, 1                                // 0000000AE114: D6100092 02052188
	v_mov_b32_e32 v170, 0                                      // 0000000AE11C: 7F540280
	v_add3_u32 v171, v136, v146, 0x7fff                        // 0000000AE120: D65500AB 03FF2588 00007FFF
	v_mov_b32_e32 v146, 0                                      // 0000000AE12C: 7F240280
	ds_store_b16_d16_hi v158, v171 offset:10                   // 0000000AE130: DA84000A 0000AB9E
	s_and_saveexec_b32 s7, s30                                 // 0000000AE138: BE87201E
	s_cbranch_execz 30                                         // 0000000AE13C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x20b8>
	ds_load_b32 v170, v157 offset:24                           // 0000000AE140: D8D80018 AA00009D
	s_waitcnt lgkmcnt(0)                                       // 0000000AE148: BF89FC07
	v_sub_f32_e32 v170, v170, v130                             // 0000000AE14C: 095505AA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE150: BF870091
	v_mul_f32_e32 v171, 0x3fb8aa3b, v170                       // 0000000AE154: 115754FF 3FB8AA3B
	v_fma_f32 v172, 0x3fb8aa3b, v170, -v171                    // 0000000AE15C: D61300AC 86AF54FF 3FB8AA3B
	v_rndne_f32_e32 v173, v171                                 // 0000000AE168: 7F5A47AB
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AE16C: BF870221
	v_sub_f32_e32 v171, v171, v173                             // 0000000AE170: 09575BAB
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v170                 // 0000000AE174: 7C3754FF C2CE8ED0
	v_fmac_f32_e32 v172, 0x32a5705f, v170                      // 0000000AE17C: 575954FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE184: BF870121
	v_add_f32_e32 v171, v171, v172                             // 0000000AE188: 075759AB
	v_cvt_i32_f32_e32 v172, v173                               // 0000000AE18C: 7F5811AD
	v_exp_f32_e32 v171, v171                                   // 0000000AE190: 7F564BAB
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE194: BF870095
	.long 0xd71c00ab                                           // 0000000AE198: D71C00AB
	v_cndmask_b32_e32 v1, v171, v172, vcc_lo                   // 0000000AE19C: 020359AB
	v_cndmask_b32_e32 v171, 0, v171, vcc_lo                    // 0000000AE1A0: 03575680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v170                 // 0000000AE1A4: 7C3D54FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000AE1AC: BF870002
	v_cndmask_b32_e32 v170, 0x7f800000, v171, vcc_lo           // 0000000AE1B0: 035556FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000AE1B8: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE1BC: BF870091
	v_bfe_u32 v171, v170, 16, 1                                // 0000000AE1C0: D61000AB 020521AA
	v_add3_u32 v171, v170, v171, 0x7fff                        // 0000000AE1C8: D65500AB 03FF57AA 00007FFF
	ds_store_b16_d16_hi v158, v171 offset:12                   // 0000000AE1D4: DA84000C 0000AB9E
	s_and_saveexec_b32 s7, s29                                 // 0000000AE1DC: BE87201D
	s_cbranch_execz 30                                         // 0000000AE1E0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x215c>
	ds_load_b32 v146, v157 offset:28                           // 0000000AE1E4: D8D8001C 9200009D
	s_waitcnt lgkmcnt(0)                                       // 0000000AE1EC: BF89FC07
	v_sub_f32_e32 v146, v146, v130                             // 0000000AE1F0: 09250592
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE1F4: BF870091
	v_mul_f32_e32 v171, 0x3fb8aa3b, v146                       // 0000000AE1F8: 115724FF 3FB8AA3B
	v_fma_f32 v172, 0x3fb8aa3b, v146, -v171                    // 0000000AE200: D61300AC 86AF24FF 3FB8AA3B
	v_rndne_f32_e32 v173, v171                                 // 0000000AE20C: 7F5A47AB
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AE210: BF870221
	v_sub_f32_e32 v171, v171, v173                             // 0000000AE214: 09575BAB
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 0000000AE218: 7C3724FF C2CE8ED0
	v_fmac_f32_e32 v172, 0x32a5705f, v146                      // 0000000AE220: 575924FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE228: BF870121
	v_add_f32_e32 v171, v171, v172                             // 0000000AE22C: 075759AB
	v_cvt_i32_f32_e32 v172, v173                               // 0000000AE230: 7F5811AD
	v_exp_f32_e32 v171, v171                                   // 0000000AE234: 7F564BAB
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE238: BF870095
	.long 0xd71c00ab                                           // 0000000AE23C: D71C00AB
	v_cndmask_b32_e32 v1, v171, v172, vcc_lo                   // 0000000AE240: 020359AB
	v_cndmask_b32_e32 v171, 0, v171, vcc_lo                    // 0000000AE244: 03575680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 0000000AE248: 7C3D24FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000AE250: BF870002
	v_cndmask_b32_e32 v146, 0x7f800000, v171, vcc_lo           // 0000000AE254: 032556FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000AE25C: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE260: BF870121
	v_bfe_u32 v171, v146, 16, 1                                // 0000000AE264: D61000AB 02052192
	v_mov_b32_e32 v172, 0                                      // 0000000AE26C: 7F580280
	v_add3_u32 v173, v146, v171, 0x7fff                        // 0000000AE270: D65500AD 03FF5792 00007FFF
	v_mov_b32_e32 v171, 0                                      // 0000000AE27C: 7F560280
	ds_store_b16_d16_hi v158, v173 offset:14                   // 0000000AE280: DA84000E 0000AD9E
	s_and_saveexec_b32 s7, s28                                 // 0000000AE288: BE87201C
	s_cbranch_execz 30                                         // 0000000AE28C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2208>
	ds_load_b32 v172, v157 offset:32                           // 0000000AE290: D8D80020 AC00009D
	s_waitcnt lgkmcnt(0)                                       // 0000000AE298: BF89FC07
	v_sub_f32_e32 v172, v172, v130                             // 0000000AE29C: 095905AC
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE2A0: BF870091
	v_mul_f32_e32 v173, 0x3fb8aa3b, v172                       // 0000000AE2A4: 115B58FF 3FB8AA3B
	v_fma_f32 v174, 0x3fb8aa3b, v172, -v173                    // 0000000AE2AC: D61300AE 86B758FF 3FB8AA3B
	v_rndne_f32_e32 v175, v173                                 // 0000000AE2B8: 7F5E47AD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AE2BC: BF870221
	v_sub_f32_e32 v173, v173, v175                             // 0000000AE2C0: 095B5FAD
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v172                 // 0000000AE2C4: 7C3758FF C2CE8ED0
	v_fmac_f32_e32 v174, 0x32a5705f, v172                      // 0000000AE2CC: 575D58FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE2D4: BF870121
	v_add_f32_e32 v173, v173, v174                             // 0000000AE2D8: 075B5DAD
	v_cvt_i32_f32_e32 v174, v175                               // 0000000AE2DC: 7F5C11AF
	v_exp_f32_e32 v173, v173                                   // 0000000AE2E0: 7F5A4BAD
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE2E4: BF870095
	.long 0xd71c00ad                                           // 0000000AE2E8: D71C00AD
	v_cndmask_b32_e32 v1, v173, v174, vcc_lo                   // 0000000AE2EC: 02035DAD
	v_cndmask_b32_e32 v173, 0, v173, vcc_lo                    // 0000000AE2F0: 035B5A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v172                 // 0000000AE2F4: 7C3D58FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000AE2FC: BF870002
	v_cndmask_b32_e32 v172, 0x7f800000, v173, vcc_lo           // 0000000AE300: 03595AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000AE308: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE30C: BF870091
	v_bfe_u32 v173, v172, 16, 1                                // 0000000AE310: D61000AD 020521AC
	v_add3_u32 v173, v172, v173, 0x7fff                        // 0000000AE318: D65500AD 03FF5BAC 00007FFF
	ds_store_b16_d16_hi v158, v173 offset:16                   // 0000000AE324: DA840010 0000AD9E
	s_and_saveexec_b32 s7, s27                                 // 0000000AE32C: BE87201B
	s_cbranch_execz 30                                         // 0000000AE330: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x22ac>
	ds_load_b32 v171, v157 offset:36                           // 0000000AE334: D8D80024 AB00009D
	s_waitcnt lgkmcnt(0)                                       // 0000000AE33C: BF89FC07
	v_sub_f32_e32 v171, v171, v130                             // 0000000AE340: 095705AB
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE344: BF870121
	v_mul_f32_e32 v173, 0x3fb8aa3b, v171                       // 0000000AE348: 115B56FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v171                 // 0000000AE350: 7C3756FF C2CE8ED0
	v_fma_f32 v174, 0x3fb8aa3b, v171, -v173                    // 0000000AE358: D61300AE 86B756FF 3FB8AA3B
	v_rndne_f32_e32 v175, v173                                 // 0000000AE364: 7F5E47AD
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AE368: BF870112
	v_fmac_f32_e32 v174, 0x32a5705f, v171                      // 0000000AE36C: 575D56FF 32A5705F
	v_sub_f32_e32 v173, v173, v175                             // 0000000AE374: 095B5FAD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE378: BF870121
	v_add_f32_e32 v173, v173, v174                             // 0000000AE37C: 075B5DAD
	v_cvt_i32_f32_e32 v174, v175                               // 0000000AE380: 7F5C11AF
	v_exp_f32_e32 v173, v173                                   // 0000000AE384: 7F5A4BAD
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE388: BF870095
	.long 0xd71c00ad                                           // 0000000AE38C: D71C00AD
	v_cndmask_b32_e32 v1, v173, v174, vcc_lo                   // 0000000AE390: 02035DAD
	v_cndmask_b32_e32 v173, 0, v173, vcc_lo                    // 0000000AE394: 035B5A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v171                 // 0000000AE398: 7C3D56FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000AE3A0: BF870002
	v_cndmask_b32_e32 v171, 0x7f800000, v173, vcc_lo           // 0000000AE3A4: 03575AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000AE3AC: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE3B0: BF870121
	v_bfe_u32 v173, v171, 16, 1                                // 0000000AE3B4: D61000AD 020521AB
	v_mov_b32_e32 v174, 0                                      // 0000000AE3BC: 7F5C0280
	v_add3_u32 v175, v171, v173, 0x7fff                        // 0000000AE3C0: D65500AF 03FF5BAB 00007FFF
	v_mov_b32_e32 v173, 0                                      // 0000000AE3CC: 7F5A0280
	ds_store_b16_d16_hi v158, v175 offset:18                   // 0000000AE3D0: DA840012 0000AF9E
	s_and_saveexec_b32 s7, s26                                 // 0000000AE3D8: BE87201A
	s_cbranch_execz 30                                         // 0000000AE3DC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2358>
	ds_load_b32 v174, v157 offset:40                           // 0000000AE3E0: D8D80028 AE00009D
	s_waitcnt lgkmcnt(0)                                       // 0000000AE3E8: BF89FC07
	v_sub_f32_e32 v174, v174, v130                             // 0000000AE3EC: 095D05AE
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE3F0: BF870091
	v_mul_f32_e32 v175, 0x3fb8aa3b, v174                       // 0000000AE3F4: 115F5CFF 3FB8AA3B
	v_fma_f32 v176, 0x3fb8aa3b, v174, -v175                    // 0000000AE3FC: D61300B0 86BF5CFF 3FB8AA3B
	v_rndne_f32_e32 v177, v175                                 // 0000000AE408: 7F6247AF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AE40C: BF870221
	v_sub_f32_e32 v175, v175, v177                             // 0000000AE410: 095F63AF
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v174                 // 0000000AE414: 7C375CFF C2CE8ED0
	v_fmac_f32_e32 v176, 0x32a5705f, v174                      // 0000000AE41C: 57615CFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE424: BF870121
	v_add_f32_e32 v175, v175, v176                             // 0000000AE428: 075F61AF
	v_cvt_i32_f32_e32 v176, v177                               // 0000000AE42C: 7F6011B1
	v_exp_f32_e32 v175, v175                                   // 0000000AE430: 7F5E4BAF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE434: BF870095
	.long 0xd71c00af                                           // 0000000AE438: D71C00AF
	v_cndmask_b32_e32 v1, v175, v176, vcc_lo                   // 0000000AE43C: 020361AF
	v_cndmask_b32_e32 v175, 0, v175, vcc_lo                    // 0000000AE440: 035F5E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v174                 // 0000000AE444: 7C3D5CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000AE44C: BF870002
	v_cndmask_b32_e32 v174, 0x7f800000, v175, vcc_lo           // 0000000AE450: 035D5EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000AE458: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE45C: BF870091
	v_bfe_u32 v175, v174, 16, 1                                // 0000000AE460: D61000AF 020521AE
	v_add3_u32 v175, v174, v175, 0x7fff                        // 0000000AE468: D65500AF 03FF5FAE 00007FFF
	ds_store_b16_d16_hi v158, v175 offset:20                   // 0000000AE474: DA840014 0000AF9E
	s_and_saveexec_b32 s7, s25                                 // 0000000AE47C: BE872019
	s_cbranch_execz 30                                         // 0000000AE480: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x23fc>
	ds_load_b32 v173, v157 offset:44                           // 0000000AE484: D8D8002C AD00009D
	s_waitcnt lgkmcnt(0)                                       // 0000000AE48C: BF89FC07
	v_sub_f32_e32 v173, v173, v130                             // 0000000AE490: 095B05AD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE494: BF870121
	v_mul_f32_e32 v175, 0x3fb8aa3b, v173                       // 0000000AE498: 115F5AFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v173                 // 0000000AE4A0: 7C375AFF C2CE8ED0
	v_fma_f32 v176, 0x3fb8aa3b, v173, -v175                    // 0000000AE4A8: D61300B0 86BF5AFF 3FB8AA3B
	v_rndne_f32_e32 v177, v175                                 // 0000000AE4B4: 7F6247AF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AE4B8: BF870112
	v_fmac_f32_e32 v176, 0x32a5705f, v173                      // 0000000AE4BC: 57615AFF 32A5705F
	v_sub_f32_e32 v175, v175, v177                             // 0000000AE4C4: 095F63AF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE4C8: BF870121
	v_add_f32_e32 v175, v175, v176                             // 0000000AE4CC: 075F61AF
	v_cvt_i32_f32_e32 v176, v177                               // 0000000AE4D0: 7F6011B1
	v_exp_f32_e32 v175, v175                                   // 0000000AE4D4: 7F5E4BAF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE4D8: BF870095
	.long 0xd71c00af                                           // 0000000AE4DC: D71C00AF
	v_cndmask_b32_e32 v1, v175, v176, vcc_lo                   // 0000000AE4E0: 020361AF
	v_cndmask_b32_e32 v175, 0, v175, vcc_lo                    // 0000000AE4E4: 035F5E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v173                 // 0000000AE4E8: 7C3D5AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000AE4F0: BF870002
	v_cndmask_b32_e32 v173, 0x7f800000, v175, vcc_lo           // 0000000AE4F4: 035B5EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000AE4FC: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE500: BF870121
	v_bfe_u32 v175, v173, 16, 1                                // 0000000AE504: D61000AF 020521AD
	v_mov_b32_e32 v176, 0                                      // 0000000AE50C: 7F600280
	v_add3_u32 v177, v173, v175, 0x7fff                        // 0000000AE510: D65500B1 03FF5FAD 00007FFF
	v_mov_b32_e32 v175, 0                                      // 0000000AE51C: 7F5E0280
	ds_store_b16_d16_hi v158, v177 offset:22                   // 0000000AE520: DA840016 0000B19E
	s_and_saveexec_b32 s7, s24                                 // 0000000AE528: BE872018
	s_cbranch_execz 30                                         // 0000000AE52C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x24a8>
	ds_load_b32 v176, v157 offset:48                           // 0000000AE530: D8D80030 B000009D
	s_waitcnt lgkmcnt(0)                                       // 0000000AE538: BF89FC07
	v_sub_f32_e32 v176, v176, v130                             // 0000000AE53C: 096105B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE540: BF870091
	v_mul_f32_e32 v177, 0x3fb8aa3b, v176                       // 0000000AE544: 116360FF 3FB8AA3B
	v_fma_f32 v178, 0x3fb8aa3b, v176, -v177                    // 0000000AE54C: D61300B2 86C760FF 3FB8AA3B
	v_rndne_f32_e32 v179, v177                                 // 0000000AE558: 7F6647B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AE55C: BF870221
	v_sub_f32_e32 v177, v177, v179                             // 0000000AE560: 096367B1
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v176                 // 0000000AE564: 7C3760FF C2CE8ED0
	v_fmac_f32_e32 v178, 0x32a5705f, v176                      // 0000000AE56C: 576560FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE574: BF870121
	v_add_f32_e32 v177, v177, v178                             // 0000000AE578: 076365B1
	v_cvt_i32_f32_e32 v178, v179                               // 0000000AE57C: 7F6411B3
	v_exp_f32_e32 v177, v177                                   // 0000000AE580: 7F624BB1
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE584: BF870095
	.long 0xd71c00b1                                           // 0000000AE588: D71C00B1
	v_cndmask_b32_e32 v1, v177, v178, vcc_lo                   // 0000000AE58C: 020365B1
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 0000000AE590: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v176                 // 0000000AE594: 7C3D60FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000AE59C: BF870002
	v_cndmask_b32_e32 v176, 0x7f800000, v177, vcc_lo           // 0000000AE5A0: 036162FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000AE5A8: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE5AC: BF870091
	v_bfe_u32 v177, v176, 16, 1                                // 0000000AE5B0: D61000B1 020521B0
	v_add3_u32 v177, v176, v177, 0x7fff                        // 0000000AE5B8: D65500B1 03FF63B0 00007FFF
	ds_store_b16_d16_hi v158, v177 offset:24                   // 0000000AE5C4: DA840018 0000B19E
	s_and_saveexec_b32 s7, s22                                 // 0000000AE5CC: BE872016
	s_cbranch_execz 30                                         // 0000000AE5D0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x254c>
	ds_load_b32 v175, v157 offset:52                           // 0000000AE5D4: D8D80034 AF00009D
	s_waitcnt lgkmcnt(0)                                       // 0000000AE5DC: BF89FC07
	v_sub_f32_e32 v175, v175, v130                             // 0000000AE5E0: 095F05AF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE5E4: BF870121
	v_mul_f32_e32 v177, 0x3fb8aa3b, v175                       // 0000000AE5E8: 11635EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v175                 // 0000000AE5F0: 7C375EFF C2CE8ED0
	v_fma_f32 v178, 0x3fb8aa3b, v175, -v177                    // 0000000AE5F8: D61300B2 86C75EFF 3FB8AA3B
	v_rndne_f32_e32 v179, v177                                 // 0000000AE604: 7F6647B1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AE608: BF870112
	v_fmac_f32_e32 v178, 0x32a5705f, v175                      // 0000000AE60C: 57655EFF 32A5705F
	v_sub_f32_e32 v177, v177, v179                             // 0000000AE614: 096367B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE618: BF870121
	v_add_f32_e32 v177, v177, v178                             // 0000000AE61C: 076365B1
	v_cvt_i32_f32_e32 v178, v179                               // 0000000AE620: 7F6411B3
	v_exp_f32_e32 v177, v177                                   // 0000000AE624: 7F624BB1
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE628: BF870095
	.long 0xd71c00b1                                           // 0000000AE62C: D71C00B1
	v_cndmask_b32_e32 v1, v177, v178, vcc_lo                   // 0000000AE630: 020365B1
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 0000000AE634: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v175                 // 0000000AE638: 7C3D5EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000AE640: BF870002
	v_cndmask_b32_e32 v175, 0x7f800000, v177, vcc_lo           // 0000000AE644: 035F62FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000AE64C: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE650: BF870121
	v_bfe_u32 v177, v175, 16, 1                                // 0000000AE654: D61000B1 020521AF
	v_mov_b32_e32 v178, 0                                      // 0000000AE65C: 7F640280
	v_add3_u32 v179, v175, v177, 0x7fff                        // 0000000AE660: D65500B3 03FF63AF 00007FFF
	v_mov_b32_e32 v177, 0                                      // 0000000AE66C: 7F620280
	ds_store_b16_d16_hi v158, v179 offset:26                   // 0000000AE670: DA84001A 0000B39E
	s_and_saveexec_b32 s7, s9                                  // 0000000AE678: BE872009
	s_cbranch_execz 30                                         // 0000000AE67C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x25f8>
	ds_load_b32 v178, v157 offset:56                           // 0000000AE680: D8D80038 B200009D
	s_waitcnt lgkmcnt(0)                                       // 0000000AE688: BF89FC07
	v_sub_f32_e32 v178, v178, v130                             // 0000000AE68C: 096505B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE690: BF870091
	v_mul_f32_e32 v179, 0x3fb8aa3b, v178                       // 0000000AE694: 116764FF 3FB8AA3B
	v_fma_f32 v180, 0x3fb8aa3b, v178, -v179                    // 0000000AE69C: D61300B4 86CF64FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000000AE6A8: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AE6AC: BF870221
	v_sub_f32_e32 v179, v179, v181                             // 0000000AE6B0: 09676BB3
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v178                 // 0000000AE6B4: 7C3764FF C2CE8ED0
	v_fmac_f32_e32 v180, 0x32a5705f, v178                      // 0000000AE6BC: 576964FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE6C4: BF870121
	v_add_f32_e32 v179, v179, v180                             // 0000000AE6C8: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 0000000AE6CC: 7F6811B5
	v_exp_f32_e32 v179, v179                                   // 0000000AE6D0: 7F664BB3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE6D4: BF870095
	.long 0xd71c00b3                                           // 0000000AE6D8: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 0000000AE6DC: 020369B3
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 0000000AE6E0: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v178                 // 0000000AE6E4: 7C3D64FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000AE6EC: BF870002
	v_cndmask_b32_e32 v178, 0x7f800000, v179, vcc_lo           // 0000000AE6F0: 036566FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000AE6F8: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE6FC: BF870091
	v_bfe_u32 v179, v178, 16, 1                                // 0000000AE700: D61000B3 020521B2
	v_add3_u32 v179, v178, v179, 0x7fff                        // 0000000AE708: D65500B3 03FF67B2 00007FFF
	ds_store_b16_d16_hi v158, v179 offset:28                   // 0000000AE714: DA84001C 0000B39E
	s_and_saveexec_b32 s7, s1                                  // 0000000AE71C: BE872001
	s_cbranch_execz 30                                         // 0000000AE720: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x269c>
	ds_load_b32 v177, v157 offset:60                           // 0000000AE724: D8D8003C B100009D
	s_waitcnt lgkmcnt(0)                                       // 0000000AE72C: BF89FC07
	v_sub_f32_e32 v177, v177, v130                             // 0000000AE730: 096305B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE734: BF870121
	v_mul_f32_e32 v179, 0x3fb8aa3b, v177                       // 0000000AE738: 116762FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v177                 // 0000000AE740: 7C3762FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v177, -v179                    // 0000000AE748: D61300B4 86CF62FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000000AE754: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AE758: BF870112
	v_fmac_f32_e32 v180, 0x32a5705f, v177                      // 0000000AE75C: 576962FF 32A5705F
	v_sub_f32_e32 v179, v179, v181                             // 0000000AE764: 09676BB3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE768: BF870121
	v_add_f32_e32 v179, v179, v180                             // 0000000AE76C: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 0000000AE770: 7F6811B5
	v_exp_f32_e32 v179, v179                                   // 0000000AE774: 7F664BB3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE778: BF870095
	.long 0xd71c00b3                                           // 0000000AE77C: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 0000000AE780: 020369B3
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 0000000AE784: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v177                 // 0000000AE788: 7C3D62FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000AE790: BF870002
	v_cndmask_b32_e32 v177, 0x7f800000, v179, vcc_lo           // 0000000AE794: 036366FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000AE79C: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000AE7A0: BF8700A1
	v_bfe_u32 v179, v177, 16, 1                                // 0000000AE7A4: D61000B3 020521B1
	s_mov_b32 s1, exec_lo                                      // 0000000AE7AC: BE81007E
	v_add3_u32 v180, v177, v179, 0x7fff                        // 0000000AE7B0: D65500B4 03FF67B1 00007FFF
	v_mov_b32_e32 v179, 0                                      // 0000000AE7BC: 7F660280
	ds_store_b16_d16_hi v158, v180 offset:30                   // 0000000AE7C0: DA84001E 0000B49E
	v_cmpx_lt_f32_e32 0xefa18f08, v131                         // 0000000AE7C8: 7D2306FF EFA18F08
	s_cbranch_execz 63518                                      // 0000000AE7D0: BFA5F81E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x74c>
	v_sub_f32_e32 v131, v131, v130                             // 0000000AE7D4: 09070583
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE7D8: BF870121
	v_mul_f32_e32 v179, 0x3fb8aa3b, v131                       // 0000000AE7DC: 116706FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 0000000AE7E4: 7C3706FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v131, -v179                    // 0000000AE7EC: D61300B4 86CF06FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000000AE7F8: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE7FC: BF870091
	v_dual_fmac_f32 v180, 0x32a5705f, v131 :: v_dual_sub_f32 v179, v179, v181// 0000000AE800: C80B06FF B4B36BB3 32A5705F
	v_add_f32_e32 v179, v179, v180                             // 0000000AE80C: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 0000000AE810: 7F6811B5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000AE814: BF870292
	v_exp_f32_e32 v179, v179                                   // 0000000AE818: 7F664BB3
	.long 0xd71c00b3                                           // 0000000AE81C: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 0000000AE820: 020369B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AE824: BF870121
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 0000000AE828: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 0000000AE82C: 7C3D06FF 42B17218
	v_cndmask_b32_e32 v179, 0x7f800000, v179, vcc_lo           // 0000000AE834: 036766FF 7F800000
	s_branch 63491                                             // 0000000AE83C: BFA0F803 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x74c>
	v_lshlrev_b32_e32 v0, 2, v150                              // 0000000AE840: 30012C82
	.long 0xd700008b                                           // 0000000AE844: D700008B
	v_cndmask_b32_e32 v1, s18, v139, vcc_lo                    // 0000000AE848: 02031612
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000AE84C: BF870191
	v_add_co_ci_u32_e64 v140, null, s19, v140, s0              // 0000000AE850: D5207C8C 00031813
	v_lshl_or_b32 v0, v149, 6, v0                              // 0000000AE858: D6560000 04010D95
	v_lshlrev_b32_e32 v147, 1, v147                            // 0000000AE860: 31272681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000000AE864: BF870152
	v_add_nc_u32_e32 v133, 0xa000, v0                          // 0000000AE868: 4B0A00FF 0000A000
	ds_load_2addr_b32 v[141:142], v133 offset0:128 offset1:130 // 0000000AE870: D8DC8280 8D000085
	s_waitcnt lgkmcnt(0)                                       // 0000000AE878: BF89FC07
	v_div_scale_f32 v143, null, v141, v141, 1.0                // 0000000AE87C: D6FC7C8F 03CB1B8D
	v_div_scale_f32 v145, vcc_lo, 1.0, v141, 1.0               // 0000000AE884: D6FC6A91 03CB1AF2
	v_rcp_f32_e32 v144, v143                                   // 0000000AE88C: 7F20558F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000000AE890: BF870005
	v_fma_f32 v0, -v143, v144, 1.0                             // 0000000AE894: D6130000 23CB218F
	v_lshlrev_b32_e32 v129, 9, v138                            // 0000000AE89C: 31031489
	ds_load_2addr_b32 v[137:138], v133 offset0:132 offset1:134 // 0000000AE8A0: D8DC8684 89000085
	ds_load_2addr_b32 v[135:136], v133 offset0:136 offset1:138 // 0000000AE8A8: D8DC8A88 87000085
	ds_load_2addr_b32 v[133:134], v133 offset0:140 offset1:142 // 0000000AE8B0: D8DC8E8C 85000085
	v_fmac_f32_e32 v144, v0, v144                              // 0000000AE8B8: 57212100
	v_or_b32_e32 v0, v148, v150                                // 0000000AE8BC: 38012D94
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000000AE8C0: 3505029F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AE8C4: BF870113
	v_mul_f32_e32 v146, v145, v144                             // 0000000AE8C8: 11252191
	.long 0xd73c0083                                           // 0000000AE8CC: D73C0083
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 0000000AE8D0: 02030281
	.long 0xd7000081                                           // 0000000AE8D4: D7000081
	v_cndmask_b32_e32 v1, v139, v147, vcc_lo                   // 0000000AE8D8: 0203278B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AE8DC: BF870223
	v_fma_f32 v148, -v143, v146, v145                          // 0000000AE8E0: D6130094 2647258F
	v_add_co_ci_u32_e64 v130, null, 0, v140, s0                // 0000000AE8E8: D5207C82 00031880
	.long 0xd7000083                                           // 0000000AE8F0: D7000083
	v_cndmask_b32_e32 v1, s16, v131, vcc_lo                    // 0000000AE8F4: 02030610
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000AE8F8: BF8701B3
	v_fmac_f32_e32 v146, v148, v144                            // 0000000AE8FC: 57252194
	v_add_co_ci_u32_e64 v132, null, s17, v132, s0              // 0000000AE900: D5207C84 00030811
	.long 0xd4440000                                           // 0000000AE908: D4440000
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 0000000AE90C: 0202000E
	v_fma_f32 v139, -v143, v146, v145                          // 0000000AE910: D613008B 2647258F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000AE918: BF8700A1
	v_div_fmas_f32 v139, v139, v144, v146                      // 0000000AE91C: D637008B 064B218B
	.long 0xd7006a83                                           // 0000000AE924: D7006A83
	v_cndmask_b32_e32 v1, v131, v147, vcc_lo                   // 0000000AE928: 02032783
	v_add_co_ci_u32_e64 v132, null, 0, v132, vcc_lo            // 0000000AE92C: D5207C84 01AB0880
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000AE934: BF870003
	v_div_fixup_f32 v139, v139, v141, 1.0                      // 0000000AE938: D627008B 03CB1B8B
	s_and_saveexec_b32 s1, s0                                  // 0000000AE940: BE812000
	s_cbranch_execz 70                                         // 0000000AE944: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2960>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AE948: BF870112
	v_mad_i64_i32 v[140:141], null, 0x6000, v0, v[131:132]     // 0000000AE94C: D6FF7C8C 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 0000000AE958: 10F2F38B
	global_load_u16 v140, v[140:141], off offset:512           // 0000000AE95C: DC4A0200 8C7C008C
	s_waitcnt vmcnt(0)                                         // 0000000AE964: BF8903F7
	v_lshlrev_b32_e32 v140, 16, v140                           // 0000000AE968: 31191890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE96C: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v140                       // 0000000AE970: 111B18FF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v140, -v141                    // 0000000AE978: D613008F 863718FF BFB8AA3B
	v_rndne_f32_e32 v144, v141                                 // 0000000AE984: 7F20478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AE988: BF870112
	v_fmamk_f32 v143, v140, 0xb2a5705f, v143                   // 0000000AE98C: 591F1F8C B2A5705F
	v_sub_f32_e32 v141, v141, v144                             // 0000000AE994: 091B218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000AE998: BF8701B1
	v_add_f32_e32 v141, v141, v143                             // 0000000AE99C: 071B1F8D
	v_cvt_i32_f32_e32 v143, v144                               // 0000000AE9A0: 7F1E1190
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v140                 // 0000000AE9A4: 7C3D18FF 42CE8ED0
	v_exp_f32_e32 v141, v141                                   // 0000000AE9AC: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE9B0: BF870095
	.long 0xd71c008d                                           // 0000000AE9B4: D71C008D
	v_cndmask_b32_e32 v1, v141, v143, vcc_lo                   // 0000000AE9B8: 02031F8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 0000000AE9BC: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v140                 // 0000000AE9C0: 7C3718FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE9C8: BF870092
	v_cndmask_b32_e32 v140, 0x7f800000, v141, vcc_lo           // 0000000AE9CC: 03191AFF 7F800000
	v_add_f32_e32 v140, 1.0, v140                              // 0000000AE9D4: 071918F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE9D8: BF870091
	v_div_scale_f32 v141, null, v140, v140, v121               // 0000000AE9DC: D6FC7C8D 05E7198C
	v_rcp_f32_e32 v143, v141                                   // 0000000AE9E4: 7F1E558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AE9E8: BF870095
	v_fma_f32 v144, -v141, v143, 1.0                           // 0000000AE9EC: D6130090 23CB1F8D
	v_fmac_f32_e32 v143, v144, v143                            // 0000000AE9F4: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v140, v121             // 0000000AE9F8: D6FC6A90 05E71979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEA00: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000AEA04: 11231F90
	v_fma_f32 v146, -v141, v145, v144                          // 0000000AEA08: D6130092 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEA10: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000AEA14: 57231F92
	v_fma_f32 v141, -v141, v145, v144                          // 0000000AEA18: D613008D 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEA20: BF870091
	v_div_fmas_f32 v141, v141, v143, v145                      // 0000000AEA24: D637008D 06471F8D
	v_div_fixup_f32 v121, v141, v140, v121                     // 0000000AEA2C: D6270079 05E7198D
	v_mad_i64_i32 v[140:141], null, 0x3000, v0, v[129:130]     // 0000000AEA34: D6FF7C8C 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEA40: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 0000000AEA44: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 0000000AEA4C: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[140:141], v121, off              // 0000000AEA58: DC960000 007C798C
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000AEA60: 8C7E017E
	v_div_scale_f32 v121, null, v142, v142, 1.0                // 0000000AEA64: D6FC7C79 03CB1D8E
	v_div_scale_f32 v143, vcc_lo, 1.0, v142, 1.0               // 0000000AEA6C: D6FC6A8F 03CB1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000AEA74: BF870292
	v_rcp_f32_e32 v140, v121                                   // 0000000AEA78: 7F185579
	v_fma_f32 v141, -v121, v140, 1.0                           // 0000000AEA7C: D613008D 23CB1979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEA84: BF870091
	v_fmac_f32_e32 v140, v141, v140                            // 0000000AEA88: 5719198D
	v_mul_f32_e32 v141, v143, v140                             // 0000000AEA8C: 111B198F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEA90: BF870091
	v_fma_f32 v144, -v121, v141, v143                          // 0000000AEA94: D6130090 263F1B79
	v_fmac_f32_e32 v141, v144, v140                            // 0000000AEA9C: 571B1990
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEAA0: BF870091
	v_fma_f32 v121, -v121, v141, v143                          // 0000000AEAA4: D6130079 263F1B79
	v_div_fmas_f32 v140, v121, v140, v141                      // 0000000AEAAC: D637008C 06371979
	v_or_b32_e32 v121, 2, v0                                   // 0000000AEAB4: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AEAB8: BF870112
	v_div_fixup_f32 v140, v140, v142, 1.0                      // 0000000AEABC: D627008C 03CB1D8C
	.long 0xd4440001                                           // 0000000AEAC4: D4440001
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 0000000AEAC8: 0202F20E
	s_and_saveexec_b32 s2, s1                                  // 0000000AEACC: BE822001
	s_cbranch_execz 69                                         // 0000000AEAD0: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2ae8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 0000000AEAD4: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 0000000AEAE0: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 0000000AEAE4: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000AEAEC: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000AEAF0: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEAF4: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000AEAF8: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000AEB00: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000AEB0C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AEB10: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000AEB14: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000AEB18: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000AEB20: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AEB28: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000AEB2C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000AEB30: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000AEB34: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEB38: BF870095
	.long 0xd71c008e                                           // 0000000AEB3C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000AEB40: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000AEB44: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000AEB48: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEB50: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000AEB54: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000AEB5C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEB60: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 0000000AEB64: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000AEB6C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEB70: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000AEB74: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000AEB7C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 0000000AEB80: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEB88: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000AEB8C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000AEB90: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEB98: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000AEB9C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000AEBA0: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEBA8: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000AEBAC: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 0000000AEBB4: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 0000000AEBBC: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEBC8: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 0000000AEBCC: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 0000000AEBD4: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 0000000AEBE0: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000AEBE8: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 0000000AEBEC: BF89FC27
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 0000000AEBF0: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 0000000AEBF8: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000AEC00: BF870292
	v_rcp_f32_e32 v141, v122                                   // 0000000AEC04: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 0000000AEC08: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEC10: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000AEC14: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000AEC18: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEC1C: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 0000000AEC20: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 0000000AEC28: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEC2C: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 0000000AEC30: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 0000000AEC38: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 0000000AEC40: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AEC44: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 0000000AEC48: D6270089 03CB138D
	.long 0xd4440002                                           // 0000000AEC50: D4440002
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 0000000AEC54: 0202F40E
	s_and_saveexec_b32 s3, s2                                  // 0000000AEC58: BE832002
	s_cbranch_execz 69                                         // 0000000AEC5C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2c74>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 0000000AEC60: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 0000000AEC6C: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 0000000AEC70: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000AEC78: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000AEC7C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEC80: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000AEC84: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000AEC8C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000AEC98: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AEC9C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000AECA0: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000AECA4: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000AECAC: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AECB4: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000AECB8: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000AECBC: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000AECC0: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AECC4: BF870095
	.long 0xd71c008e                                           // 0000000AECC8: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000AECCC: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000AECD0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000AECD4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AECDC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000AECE0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000AECE8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AECEC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 0000000AECF0: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000AECF8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AECFC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000AED00: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000AED08: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 0000000AED0C: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AED14: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000AED18: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000AED1C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AED24: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000AED28: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000AED2C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AED34: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000AED38: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 0000000AED40: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 0000000AED48: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AED54: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 0000000AED58: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 0000000AED60: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 0000000AED6C: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000AED74: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 0000000AED78: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 0000000AED80: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000AED88: BF870292
	v_rcp_f32_e32 v141, v123                                   // 0000000AED8C: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 0000000AED90: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AED98: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000AED9C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000AEDA0: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEDA4: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 0000000AEDA8: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 0000000AEDB0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEDB4: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 0000000AEDB8: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 0000000AEDC0: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 0000000AEDC8: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AEDCC: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 0000000AEDD0: D627008A 03CB158D
	.long 0xd4440003                                           // 0000000AEDD8: D4440003
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 0000000AEDDC: 0202F60E
	s_and_saveexec_b32 s4, s3                                  // 0000000AEDE0: BE842003
	s_cbranch_execz 69                                         // 0000000AEDE4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2dfc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 0000000AEDE8: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 0000000AEDF4: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 0000000AEDF8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000AEE00: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000AEE04: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEE08: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000AEE0C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000AEE14: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000AEE20: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AEE24: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000AEE28: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000AEE2C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000AEE34: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AEE3C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000AEE40: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000AEE44: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000AEE48: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEE4C: BF870095
	.long 0xd71c008e                                           // 0000000AEE50: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000AEE54: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000AEE58: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000AEE5C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEE64: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000AEE68: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000AEE70: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEE74: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 0000000AEE78: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000AEE80: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEE84: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000AEE88: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000AEE90: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 0000000AEE94: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEE9C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000AEEA0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000AEEA4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEEAC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000AEEB0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000AEEB4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEEBC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000AEEC0: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 0000000AEEC8: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 0000000AEED0: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEEDC: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 0000000AEEE0: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 0000000AEEE8: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 0000000AEEF4: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000AEEFC: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 0000000AEF00: BF89FC17
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 0000000AEF04: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 0000000AEF0C: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000AEF14: BF870292
	v_rcp_f32_e32 v141, v124                                   // 0000000AEF18: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 0000000AEF1C: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEF24: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000AEF28: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000AEF2C: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEF30: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 0000000AEF34: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 0000000AEF3C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEF40: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 0000000AEF44: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 0000000AEF4C: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 0000000AEF54: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AEF58: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 0000000AEF5C: D6270087 03CB0F8D
	.long 0xd4440004                                           // 0000000AEF64: D4440004
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 0000000AEF68: 0202F80E
	s_and_saveexec_b32 s5, s4                                  // 0000000AEF6C: BE852004
	s_cbranch_execz 69                                         // 0000000AEF70: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2f88>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 0000000AEF74: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 0000000AEF80: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 0000000AEF84: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000AEF8C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000AEF90: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEF94: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000AEF98: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000AEFA0: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000AEFAC: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AEFB0: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000AEFB4: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000AEFB8: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000AEFC0: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AEFC8: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000AEFCC: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000AEFD0: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000AEFD4: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEFD8: BF870095
	.long 0xd71c008e                                           // 0000000AEFDC: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000AEFE0: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000AEFE4: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000AEFE8: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AEFF0: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000AEFF4: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000AEFFC: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF000: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 0000000AF004: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000AF00C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF010: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000AF014: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000AF01C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 0000000AF020: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF028: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000AF02C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000AF030: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF038: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000AF03C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000AF040: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF048: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000AF04C: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 0000000AF054: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 0000000AF05C: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF068: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 0000000AF06C: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 0000000AF074: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 0000000AF080: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000AF088: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 0000000AF08C: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 0000000AF094: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000AF09C: BF870292
	v_rcp_f32_e32 v141, v125                                   // 0000000AF0A0: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 0000000AF0A4: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF0AC: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000AF0B0: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000AF0B4: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF0B8: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 0000000AF0BC: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 0000000AF0C4: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF0C8: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 0000000AF0CC: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 0000000AF0D4: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 0000000AF0DC: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AF0E0: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 0000000AF0E4: D6270088 03CB118D
	.long 0xd4440005                                           // 0000000AF0EC: D4440005
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 0000000AF0F0: 0202FA0E
	s_and_saveexec_b32 s6, s5                                  // 0000000AF0F4: BE862005
	s_cbranch_execz 69                                         // 0000000AF0F8: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3110>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 0000000AF0FC: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 0000000AF108: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 0000000AF10C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000AF114: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000AF118: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF11C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000AF120: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000AF128: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000AF134: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AF138: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000AF13C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000AF140: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000AF148: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AF150: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000AF154: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000AF158: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000AF15C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF160: BF870095
	.long 0xd71c008e                                           // 0000000AF164: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000AF168: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000AF16C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000AF170: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF178: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000AF17C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000AF184: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF188: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 0000000AF18C: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000AF194: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF198: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000AF19C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000AF1A4: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 0000000AF1A8: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF1B0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000AF1B4: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000AF1B8: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF1C0: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000AF1C4: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000AF1C8: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF1D0: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000AF1D4: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 0000000AF1DC: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 0000000AF1E4: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF1F0: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 0000000AF1F4: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 0000000AF1FC: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 0000000AF208: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000AF210: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000000AF214: BF89FC07
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 0000000AF218: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 0000000AF220: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000AF228: BF870292
	v_rcp_f32_e32 v141, v126                                   // 0000000AF22C: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 0000000AF230: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF238: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000AF23C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000AF240: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF244: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 0000000AF248: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 0000000AF250: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF254: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 0000000AF258: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 0000000AF260: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 0000000AF268: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AF26C: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 0000000AF270: D6270085 03CB0B8D
	.long 0xd4440006                                           // 0000000AF278: D4440006
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 0000000AF27C: 0202FC0E
	s_and_saveexec_b32 s7, s6                                  // 0000000AF280: BE872006
	s_cbranch_execz 69                                         // 0000000AF284: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x329c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 0000000AF288: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 0000000AF294: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 0000000AF298: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000AF2A0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000AF2A4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF2A8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000AF2AC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000AF2B4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000AF2C0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AF2C4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000AF2C8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000AF2CC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000AF2D4: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AF2DC: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000AF2E0: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000AF2E4: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000AF2E8: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF2EC: BF870095
	.long 0xd71c008e                                           // 0000000AF2F0: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000AF2F4: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000AF2F8: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000AF2FC: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF304: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000AF308: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000AF310: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF314: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 0000000AF318: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000AF320: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF324: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000AF328: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000AF330: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 0000000AF334: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF33C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000AF340: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000AF344: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF34C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000AF350: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000AF354: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF35C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000AF360: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 0000000AF368: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 0000000AF370: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF37C: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 0000000AF380: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 0000000AF388: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 0000000AF394: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000AF39C: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 0000000AF3A0: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 0000000AF3A8: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000AF3B0: BF870292
	v_rcp_f32_e32 v141, v127                                   // 0000000AF3B4: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 0000000AF3B8: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF3C0: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000AF3C4: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000AF3C8: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF3CC: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 0000000AF3D0: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 0000000AF3D8: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF3DC: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 0000000AF3E0: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 0000000AF3E8: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 0000000AF3F0: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AF3F4: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 0000000AF3F8: D6270086 03CB0D8D
	.long 0xd4440007                                           // 0000000AF400: D4440007
	v_cndmask_b32_e32 v1, s14, v127, vcc_lo                    // 0000000AF404: 0202FE0E
	s_and_saveexec_b32 s8, s7                                  // 0000000AF408: BE882007
	s_cbranch_execnz 363                                       // 0000000AF40C: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF410: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AF414: BE882000
	s_cbranch_execnz 432                                       // 0000000AF418: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF41C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AF420: BE882001
	s_cbranch_execnz 501                                       // 0000000AF424: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3afc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF428: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AF42C: BE882002
	s_cbranch_execnz 570                                       // 0000000AF430: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF434: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AF438: BE882003
	s_cbranch_execnz 639                                       // 0000000AF43C: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF440: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AF444: BE882004
	s_cbranch_execnz 708                                       // 0000000AF448: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF44C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AF450: BE882005
	s_cbranch_execnz 777                                       // 0000000AF454: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF458: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AF45C: BE882006
	s_cbranch_execnz 846                                       // 0000000AF460: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x409c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF464: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AF468: BE882007
	s_cbranch_execnz 915                                       // 0000000AF46C: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF470: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AF474: BE882000
	s_cbranch_execnz 984                                       // 0000000AF478: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF47C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AF480: BE882001
	s_cbranch_execnz 1053                                      // 0000000AF484: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x43fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF488: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AF48C: BE882002
	s_cbranch_execnz 1122                                      // 0000000AF490: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x451c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF494: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AF498: BE882003
	s_cbranch_execnz 1191                                      // 0000000AF49C: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x463c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF4A0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AF4A4: BE882004
	s_cbranch_execnz 1260                                      // 0000000AF4A8: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x475c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF4AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AF4B0: BE882005
	s_cbranch_execnz 1329                                      // 0000000AF4B4: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x487c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF4B8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AF4BC: BE882006
	s_cbranch_execnz 1398                                      // 0000000AF4C0: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x499c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF4C4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AF4C8: BE882007
	s_cbranch_execnz 1467                                      // 0000000AF4CC: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4abc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF4D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AF4D4: BE882000
	s_cbranch_execnz 1536                                      // 0000000AF4D8: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4bdc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF4DC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AF4E0: BE882001
	s_cbranch_execnz 1605                                      // 0000000AF4E4: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4cfc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF4E8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AF4EC: BE882002
	s_cbranch_execnz 1674                                      // 0000000AF4F0: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4e1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF4F4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AF4F8: BE882003
	s_cbranch_execnz 1743                                      // 0000000AF4FC: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4f3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF500: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AF504: BE882004
	s_cbranch_execnz 1812                                      // 0000000AF508: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x505c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF50C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AF510: BE882005
	s_cbranch_execnz 1881                                      // 0000000AF514: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x517c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF518: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AF51C: BE882006
	s_cbranch_execnz 1950                                      // 0000000AF520: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x529c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF524: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AF528: BE882007
	s_cbranch_execnz 2019                                      // 0000000AF52C: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x53bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF530: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AF534: BE882000
	s_cbranch_execnz 2088                                      // 0000000AF538: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x54dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF53C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AF540: BE882001
	s_cbranch_execnz 2157                                      // 0000000AF544: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x55fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF548: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AF54C: BE882002
	s_cbranch_execnz 2226                                      // 0000000AF550: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x571c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF554: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AF558: BE882003
	s_cbranch_execnz 2295                                      // 0000000AF55C: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x583c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF560: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AF564: BE882004
	s_cbranch_execnz 2364                                      // 0000000AF568: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x595c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF56C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AF570: BE882005
	s_cbranch_execnz 2433                                      // 0000000AF574: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5a7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF578: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AF57C: BE882006
	s_cbranch_execnz 2502                                      // 0000000AF580: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5b9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF584: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AF588: BE882007
	s_cbranch_execnz 2571                                      // 0000000AF58C: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5cbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF590: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AF594: BE882000
	s_cbranch_execnz 2640                                      // 0000000AF598: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5ddc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF59C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AF5A0: BE882001
	s_cbranch_execnz 2709                                      // 0000000AF5A4: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5efc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF5A8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AF5AC: BE882002
	s_cbranch_execnz 2778                                      // 0000000AF5B0: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x601c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF5B4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AF5B8: BE882003
	s_cbranch_execnz 2847                                      // 0000000AF5BC: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x613c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF5C0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AF5C4: BE882004
	s_cbranch_execnz 2916                                      // 0000000AF5C8: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x625c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF5CC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AF5D0: BE882005
	s_cbranch_execnz 2985                                      // 0000000AF5D4: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x637c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF5D8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AF5DC: BE882006
	s_cbranch_execnz 3054                                      // 0000000AF5E0: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x649c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF5E4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AF5E8: BE882007
	s_cbranch_execnz 3123                                      // 0000000AF5EC: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x65bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF5F0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AF5F4: BE882000
	s_cbranch_execnz 3192                                      // 0000000AF5F8: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x66dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF5FC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AF600: BE882001
	s_cbranch_execnz 3261                                      // 0000000AF604: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x67fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF608: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AF60C: BE882002
	s_cbranch_execnz 3330                                      // 0000000AF610: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x691c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF614: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AF618: BE882003
	s_cbranch_execnz 3399                                      // 0000000AF61C: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6a3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF620: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AF624: BE882004
	s_cbranch_execnz 3468                                      // 0000000AF628: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6b5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF62C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AF630: BE882005
	s_cbranch_execnz 3537                                      // 0000000AF634: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6c7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF638: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AF63C: BE882006
	s_cbranch_execnz 3606                                      // 0000000AF640: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6d9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF644: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AF648: BE882007
	s_cbranch_execnz 3675                                      // 0000000AF64C: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6ebc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF650: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AF654: BE882000
	s_cbranch_execnz 3744                                      // 0000000AF658: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6fdc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF65C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AF660: BE882001
	s_cbranch_execnz 3813                                      // 0000000AF664: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x70fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF668: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AF66C: BE882002
	s_cbranch_execnz 3882                                      // 0000000AF670: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x721c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF674: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AF678: BE882003
	s_cbranch_execnz 3951                                      // 0000000AF67C: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x733c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF680: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AF684: BE882004
	s_cbranch_execnz 4020                                      // 0000000AF688: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x745c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF68C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AF690: BE882005
	s_cbranch_execnz 4089                                      // 0000000AF694: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x757c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF698: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AF69C: BE882006
	s_cbranch_execnz 4158                                      // 0000000AF6A0: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x769c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF6A4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AF6A8: BE882007
	s_cbranch_execnz 4227                                      // 0000000AF6AC: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x77bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF6B0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AF6B4: BE882000
	s_cbranch_execnz 4296                                      // 0000000AF6B8: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x78dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF6BC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AF6C0: BE882001
	s_cbranch_execnz 4365                                      // 0000000AF6C4: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x79fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF6C8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AF6CC: BE882002
	s_cbranch_execnz 4434                                      // 0000000AF6D0: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7b1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF6D4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AF6D8: BE882003
	s_cbranch_execnz 4503                                      // 0000000AF6DC: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7c3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF6E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AF6E4: BE882004
	s_cbranch_execnz 4572                                      // 0000000AF6E8: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7d5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF6EC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AF6F0: BE882005
	s_cbranch_execnz 4641                                      // 0000000AF6F4: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7e7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF6F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AF6FC: BE882006
	s_cbranch_execnz 4710                                      // 0000000AF700: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7f9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF704: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AF708: BE882007
	s_cbranch_execnz 4779                                      // 0000000AF70C: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x80bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF710: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AF714: BE882000
	s_cbranch_execnz 4848                                      // 0000000AF718: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x81dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF71C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AF720: BE882001
	s_cbranch_execnz 4917                                      // 0000000AF724: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x82fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF728: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AF72C: BE882002
	s_cbranch_execnz 4986                                      // 0000000AF730: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x841c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF734: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AF738: BE882003
	s_cbranch_execnz 5055                                      // 0000000AF73C: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x853c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF740: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AF744: BE882004
	s_cbranch_execnz 5124                                      // 0000000AF748: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x865c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF74C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AF750: BE882005
	s_cbranch_execnz 5193                                      // 0000000AF754: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x877c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF758: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AF75C: BE882006
	s_cbranch_execnz 5262                                      // 0000000AF760: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x889c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF764: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AF768: BE882007
	s_cbranch_execnz 5331                                      // 0000000AF76C: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x89bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF770: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AF774: BE882000
	s_cbranch_execnz 5400                                      // 0000000AF778: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8adc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF77C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AF780: BE882001
	s_cbranch_execnz 5469                                      // 0000000AF784: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8bfc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF788: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AF78C: BE882002
	s_cbranch_execnz 5538                                      // 0000000AF790: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8d1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF794: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AF798: BE882003
	s_cbranch_execnz 5607                                      // 0000000AF79C: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8e3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF7A0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AF7A4: BE882004
	s_cbranch_execnz 5676                                      // 0000000AF7A8: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8f5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF7AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AF7B0: BE882005
	s_cbranch_execnz 5745                                      // 0000000AF7B4: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x907c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF7B8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AF7BC: BE882006
	s_cbranch_execnz 5814                                      // 0000000AF7C0: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x919c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF7C4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AF7C8: BE882007
	s_cbranch_execnz 5883                                      // 0000000AF7CC: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x92bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF7D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AF7D4: BE882000
	s_cbranch_execnz 5952                                      // 0000000AF7D8: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x93dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF7DC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AF7E0: BE882001
	s_cbranch_execnz 6021                                      // 0000000AF7E4: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x94fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF7E8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AF7EC: BE882002
	s_cbranch_execnz 6090                                      // 0000000AF7F0: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x961c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF7F4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AF7F8: BE882003
	s_cbranch_execnz 6159                                      // 0000000AF7FC: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x973c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF800: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AF804: BE882004
	s_cbranch_execnz 6228                                      // 0000000AF808: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x985c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF80C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AF810: BE882005
	s_cbranch_execnz 6297                                      // 0000000AF814: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x997c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF818: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AF81C: BE882006
	s_cbranch_execnz 6366                                      // 0000000AF820: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9a9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF824: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AF828: BE882007
	s_cbranch_execnz 6435                                      // 0000000AF82C: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9bbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF830: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AF834: BE882000
	s_cbranch_execnz 6504                                      // 0000000AF838: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9cdc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF83C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AF840: BE882001
	s_cbranch_execnz 6573                                      // 0000000AF844: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9dfc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF848: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AF84C: BE882002
	s_cbranch_execnz 6642                                      // 0000000AF850: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9f1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF854: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AF858: BE882003
	s_cbranch_execnz 6711                                      // 0000000AF85C: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa03c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF860: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AF864: BE882004
	s_cbranch_execnz 6780                                      // 0000000AF868: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa15c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF86C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AF870: BE882005
	s_cbranch_execnz 6849                                      // 0000000AF874: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa27c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF878: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AF87C: BE882006
	s_cbranch_execnz 6918                                      // 0000000AF880: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa39c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF884: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AF888: BE882007
	s_cbranch_execnz 6987                                      // 0000000AF88C: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa4bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF890: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AF894: BE882000
	s_cbranch_execnz 7056                                      // 0000000AF898: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa5dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF89C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AF8A0: BE882001
	s_cbranch_execnz 7125                                      // 0000000AF8A4: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa6fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF8A8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AF8AC: BE882002
	s_cbranch_execnz 7194                                      // 0000000AF8B0: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa81c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF8B4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AF8B8: BE882003
	s_cbranch_execnz 7263                                      // 0000000AF8BC: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa93c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF8C0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AF8C4: BE882004
	s_cbranch_execnz 7332                                      // 0000000AF8C8: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaa5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF8CC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AF8D0: BE882005
	s_cbranch_execnz 7401                                      // 0000000AF8D4: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xab7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF8D8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AF8DC: BE882006
	s_cbranch_execnz 7470                                      // 0000000AF8E0: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF8E4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AF8E8: BE882007
	s_cbranch_execnz 7539                                      // 0000000AF8EC: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xadbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF8F0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AF8F4: BE882000
	s_cbranch_execnz 7608                                      // 0000000AF8F8: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaedc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF8FC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AF900: BE882001
	s_cbranch_execnz 7677                                      // 0000000AF904: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaffc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF908: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AF90C: BE882002
	s_cbranch_execnz 7746                                      // 0000000AF910: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb11c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF914: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AF918: BE882003
	s_cbranch_execnz 7815                                      // 0000000AF91C: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb23c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF920: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AF924: BE882004
	s_cbranch_execnz 7884                                      // 0000000AF928: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb35c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF92C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AF930: BE882005
	s_cbranch_execnz 7953                                      // 0000000AF934: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb47c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF938: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AF93C: BE882006
	s_cbranch_execnz 8022                                      // 0000000AF940: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb59c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF944: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AF948: BE882007
	s_cbranch_execnz 8091                                      // 0000000AF94C: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb6bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF950: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AF954: BE882000
	s_cbranch_execnz 8160                                      // 0000000AF958: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb7dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AF95C: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 0000000AF960: BE802001
	s_cbranch_execnz 8229                                      // 0000000AF964: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb8fc>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000AF968: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 0000000AF96C: BE802002
	s_cbranch_execnz 8298                                      // 0000000AF970: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xba1c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000AF974: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 0000000AF978: BE802003
	s_cbranch_execnz 8367                                      // 0000000AF97C: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbb3c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000AF980: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000000AF984: BE802004
	s_cbranch_execnz 8436                                      // 0000000AF988: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbc5c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000AF98C: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000000AF990: BE802005
	s_cbranch_execnz 8505                                      // 0000000AF994: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbd7c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000AF998: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000000AF99C: BE802006
	s_cbranch_execnz 8574                                      // 0000000AF9A0: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbe9c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000AF9A4: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000000AF9A8: BE802007
	s_cbranch_execnz 8643                                      // 0000000AF9AC: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbfbc>
	s_nop 0                                                    // 0000000AF9B0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000000AF9B4: BFB60003
	s_endpgm                                                   // 0000000AF9B8: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 0000000AF9BC: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 0000000AF9C8: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 0000000AF9CC: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000AF9D4: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000AF9D8: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AF9DC: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000AF9E0: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000AF9E8: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000AF9F4: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AF9F8: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000AF9FC: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000AFA00: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000AFA08: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AFA10: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000AFA14: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000AFA18: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000AFA1C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFA20: BF870095
	.long 0xd71c008e                                           // 0000000AFA24: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000AFA28: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000AFA2C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000AFA30: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFA38: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000AFA3C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000AFA44: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFA48: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 0000000AFA4C: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000AFA54: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFA58: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000AFA5C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000AFA64: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 0000000AFA68: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFA70: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000AFA74: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000AFA78: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFA80: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000AFA84: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000AFA88: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFA90: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000AFA94: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 0000000AFA9C: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 0000000AFAA4: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFAB0: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 0000000AFAB4: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 0000000AFABC: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 0000000AFAC8: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AFAD0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AFAD4: BE882000
	s_cbranch_execz 65104                                      // 0000000AFAD8: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x331c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 0000000AFADC: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 0000000AFAE8: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 0000000AFAEC: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 0000000AFAF4: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 0000000AFAF8: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFAFC: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 0000000AFB00: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 0000000AFB08: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 0000000AFB14: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AFB18: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 0000000AFB1C: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 0000000AFB20: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 0000000AFB28: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AFB30: BF870121
	v_add_f32_e32 v141, v141, v142                             // 0000000AFB34: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 0000000AFB38: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 0000000AFB3C: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFB40: BF870095
	.long 0xd71c008d                                           // 0000000AFB44: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 0000000AFB48: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 0000000AFB4C: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 0000000AFB50: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFB58: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 0000000AFB5C: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 0000000AFB64: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFB68: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 0000000AFB6C: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 0000000AFB74: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFB78: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 0000000AFB7C: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 0000000AFB84: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 0000000AFB88: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFB90: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 0000000AFB94: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 0000000AFB98: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFBA0: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 0000000AFBA4: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 0000000AFBA8: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFBB0: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 0000000AFBB4: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 0000000AFBBC: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 0000000AFBC4: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFBD0: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 0000000AFBD4: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 0000000AFBDC: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 0000000AFBE8: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AFBF0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AFBF4: BE882001
	s_cbranch_execz 65035                                      // 0000000AFBF8: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3328>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 0000000AFBFC: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 0000000AFC08: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 0000000AFC0C: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 0000000AFC14: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000AFC18: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFC1C: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 0000000AFC20: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 0000000AFC28: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 0000000AFC34: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AFC38: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 0000000AFC3C: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000AFC40: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 0000000AFC48: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AFC50: BF870121
	v_add_f32_e32 v128, v128, v141                             // 0000000AFC54: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 0000000AFC58: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 0000000AFC5C: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFC60: BF870095
	.long 0xd71c0080                                           // 0000000AFC64: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 0000000AFC68: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 0000000AFC6C: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000AFC70: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFC78: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 0000000AFC7C: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000AFC84: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFC88: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 0000000AFC8C: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 0000000AFC94: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFC98: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 0000000AFC9C: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 0000000AFCA4: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 0000000AFCA8: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFCB0: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 0000000AFCB4: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 0000000AFCB8: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFCC0: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 0000000AFCC4: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 0000000AFCC8: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFCD0: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 0000000AFCD4: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 0000000AFCDC: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 0000000AFCE4: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFCF0: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 0000000AFCF4: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 0000000AFCFC: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 0000000AFD08: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AFD10: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AFD14: BE882002
	s_cbranch_execz 64966                                      // 0000000AFD18: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3334>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 0000000AFD1C: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000AFD28: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000AFD30: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000AFD34: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFD38: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000AFD3C: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 0000000AFD44: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 0000000AFD50: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AFD54: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 0000000AFD58: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 0000000AFD60: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000AFD64: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 0000000AFD68: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 0000000AFD6C: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000AFD70: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 0000000AFD78: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFD7C: BF870095
	.long 0xd71c0072                                           // 0000000AFD80: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 0000000AFD84: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000AFD88: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000AFD8C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFD94: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 0000000AFD98: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000AFDA4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFDA8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000AFDAC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 0000000AFDB4: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFDB8: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 0000000AFDBC: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 0000000AFDC4: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 0000000AFDC8: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFDD0: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 0000000AFDD4: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 0000000AFDD8: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFDE0: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 0000000AFDE4: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 0000000AFDE8: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFDF0: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 0000000AFDF4: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000AFDFC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 0000000AFE04: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFE10: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 0000000AFE14: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 0000000AFE1C: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000AFE28: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AFE30: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AFE34: BE882003
	s_cbranch_execz 64897                                      // 0000000AFE38: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3340>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 0000000AFE3C: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000AFE48: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000AFE50: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000AFE54: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFE58: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000AFE5C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000AFE64: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 0000000AFE70: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AFE74: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 0000000AFE78: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000AFE7C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000AFE84: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AFE8C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000AFE90: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 0000000AFE94: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 0000000AFE98: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFE9C: BF870095
	.long 0xd71c0072                                           // 0000000AFEA0: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000AFEA4: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000AFEA8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000AFEAC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFEB4: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 0000000AFEB8: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000AFEC4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFEC8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000AFECC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000AFED4: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFED8: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 0000000AFEDC: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 0000000AFEE4: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 0000000AFEE8: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFEF0: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 0000000AFEF4: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 0000000AFEF8: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFF00: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 0000000AFF04: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 0000000AFF08: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFF10: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 0000000AFF14: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000AFF1C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 0000000AFF24: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFF30: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000AFF34: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000AFF3C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000AFF48: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AFF50: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AFF54: BE882004
	s_cbranch_execz 64828                                      // 0000000AFF58: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x334c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 0000000AFF5C: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000AFF68: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000AFF70: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000AFF74: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFF78: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000AFF7C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000AFF84: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000AFF90: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AFF94: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000AFF98: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000AFF9C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000AFFA4: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AFFAC: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000AFFB0: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000AFFB4: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000AFFB8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFFBC: BF870095
	.long 0xd71c0072                                           // 0000000AFFC0: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000AFFC4: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000AFFC8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000AFFCC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFFD4: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 0000000AFFD8: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000AFFE4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFFE8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000AFFEC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000AFFF4: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AFFF8: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000AFFFC: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000B0004: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000B0008: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0010: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 0000000B0014: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 0000000B0018: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0020: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 0000000B0024: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 0000000B0028: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0030: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 0000000B0034: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000B003C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 0000000B0044: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0050: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000B0054: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000B005C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000B0068: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B0070: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000B0074: BE882005
	s_cbranch_execz 64759                                      // 0000000B0078: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3358>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 0000000B007C: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000B0088: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000B0090: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000B0094: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0098: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000B009C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000B00A4: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000B00B0: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B00B4: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000B00B8: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000B00BC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000B00C4: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B00CC: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000B00D0: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000B00D4: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000B00D8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B00DC: BF870095
	.long 0xd71c0072                                           // 0000000B00E0: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000B00E4: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000B00E8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000B00EC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B00F4: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000000B00F8: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 0000000B0100: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0108: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000B010C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000B0114: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0118: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000B011C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000B0124: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000B0128: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0130: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000B0134: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 0000000B0138: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0140: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 0000000B0144: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 0000000B0148: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0150: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000B0154: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000B015C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 0000000B0164: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0170: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000B0174: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000B017C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000B0188: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B0190: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000B0194: BE882006
	s_cbranch_execz 64690                                      // 0000000B0198: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3364>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 0000000B019C: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000B01A8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000B01B0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000B01B4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B01B8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000B01BC: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000B01C4: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000B01D0: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B01D4: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000B01D8: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000B01DC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000B01E4: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B01EC: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000B01F0: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000B01F4: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000B01F8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B01FC: BF870095
	.long 0xd71c0072                                           // 0000000B0200: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000B0204: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000B0208: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000B020C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0214: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 0000000B0218: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000B0224: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0228: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000B022C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000B0234: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0238: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000B023C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000B0244: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000B0248: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0250: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000B0254: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000000B0258: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0260: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000000B0264: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000000B0268: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0270: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000B0274: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000B027C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 0000000B0284: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0290: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000B0294: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000B029C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000B02A8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B02B0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000B02B4: BE882007
	s_cbranch_execz 64621                                      // 0000000B02B8: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3370>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 0000000B02BC: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000B02C8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000B02D0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000B02D4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B02D8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000B02DC: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000B02E4: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000B02F0: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B02F4: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000B02F8: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000B02FC: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000B0304: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B030C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000B0310: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000B0314: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000B0318: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B031C: BF870095
	.long 0xd71c0072                                           // 0000000B0320: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000B0324: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000B0328: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000B032C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0334: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 0000000B0338: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000B0344: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0348: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000B034C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000B0354: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0358: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000B035C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000B0364: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000B0368: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0370: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000B0374: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000000B0378: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0380: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000000B0384: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000000B0388: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0390: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000B0394: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000B039C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 0000000B03A4: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B03B0: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000B03B4: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000B03BC: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000B03C8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B03D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000B03D4: BE882000
	s_cbranch_execz 64552                                      // 0000000B03D8: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x337c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 0000000B03DC: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 0000000B03E8: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 0000000B03EC: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000B03F4: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000B03F8: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B03FC: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000B0400: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000B0408: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000B0414: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B0418: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000B041C: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000B0420: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000B0428: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B0430: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000B0434: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000B0438: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000B043C: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0440: BF870095
	.long 0xd71c0072                                           // 0000000B0444: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000B0448: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000B044C: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000B0450: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0458: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000000B045C: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000B0464: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0468: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 0000000B046C: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 0000000B0474: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0478: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 0000000B047C: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 0000000B0484: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 0000000B0488: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0490: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 0000000B0494: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 0000000B0498: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B04A0: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 0000000B04A4: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 0000000B04A8: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B04B0: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 0000000B04B4: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 0000000B04BC: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 0000000B04C4: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B04D0: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 0000000B04D4: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 0000000B04DC: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 0000000B04E8: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B04F0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000B04F4: BE882001
	s_cbranch_execz 64483                                      // 0000000B04F8: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3388>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 0000000B04FC: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 0000000B0508: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 0000000B050C: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 0000000B0514: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000B0518: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B051C: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 0000000B0520: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000B0528: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 0000000B0530: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000000B053C: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B0540: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 0000000B0544: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 0000000B054C: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B0550: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000000B0554: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000000B0558: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000000B055C: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0560: BF870095
	.long 0xd71c0071                                           // 0000000B0564: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000000B0568: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000000B056C: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000B0570: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0578: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 0000000B057C: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000B0584: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0588: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 0000000B058C: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 0000000B0594: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0598: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 0000000B059C: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 0000000B05A4: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 0000000B05A8: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B05B0: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 0000000B05B4: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 0000000B05B8: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B05C0: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 0000000B05C4: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 0000000B05C8: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B05D0: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 0000000B05D4: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 0000000B05DC: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 0000000B05E4: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B05F0: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 0000000B05F4: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 0000000B05FC: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 0000000B0608: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B0610: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000B0614: BE882002
	s_cbranch_execz 64414                                      // 0000000B0618: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3394>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 0000000B061C: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000B0628: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000B0630: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000B0634: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0638: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000B063C: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 0000000B0644: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 0000000B0650: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B0654: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 0000000B0658: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000B065C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 0000000B0664: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B066C: BF870121
	v_add_f32_e32 v106, v106, v113                             // 0000000B0670: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 0000000B0674: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 0000000B0678: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B067C: BF870095
	.long 0xd71c006a                                           // 0000000B0680: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 0000000B0684: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000B0688: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000B068C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0694: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 0000000B0698: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000B06A4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B06A8: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000B06AC: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 0000000B06B4: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B06B8: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 0000000B06BC: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 0000000B06C4: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 0000000B06C8: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B06D0: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 0000000B06D4: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 0000000B06D8: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B06E0: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 0000000B06E4: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 0000000B06E8: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B06F0: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 0000000B06F4: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000B06FC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 0000000B0704: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0710: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 0000000B0714: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 0000000B071C: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000B0728: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B0730: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000B0734: BE882003
	s_cbranch_execz 64345                                      // 0000000B0738: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33a0>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 0000000B073C: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000B0748: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000B0750: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000B0754: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0758: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000B075C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000B0764: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 0000000B0770: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0774: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 0000000B0778: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 0000000B0784: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 0000000B0788: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000B078C: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B0794: BF870293
	v_exp_f32_e32 v106, v106                                   // 0000000B0798: 7ED44B6A
	.long 0xd71c006a                                           // 0000000B079C: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000B07A0: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B07A4: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000B07A8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000B07AC: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 0000000B07B4: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B07C0: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 0000000B07C4: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000B07C8: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B07D0: BF870291
	v_rcp_f32_e32 v108, v107                                   // 0000000B07D4: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 0000000B07D8: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B07E0: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 0000000B07E4: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 0000000B07E8: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 0000000B07F0: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B07F4: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 0000000B07F8: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 0000000B0800: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0804: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 0000000B0808: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 0000000B0810: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B0818: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000B081C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 0000000B0824: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 0000000B0830: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B0838: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000B083C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000B0848: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B0850: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000B0854: BE882004
	s_cbranch_execz 64276                                      // 0000000B0858: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33ac>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 0000000B085C: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000B0868: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000B0870: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000B0874: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0878: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000B087C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000B0884: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000B0890: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B0894: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000B0898: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000B089C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000B08A4: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B08AC: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000B08B0: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000B08B4: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000B08B8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B08BC: BF870095
	.long 0xd71c006a                                           // 0000000B08C0: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000B08C4: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000B08C8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000B08CC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B08D4: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 0000000B08D8: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000B08E4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B08E8: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000B08EC: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000B08F4: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B08F8: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000B08FC: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000B0904: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000B0908: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0910: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 0000000B0914: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 0000000B0918: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0920: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 0000000B0924: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 0000000B0928: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0930: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 0000000B0934: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000B093C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 0000000B0944: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0950: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000B0954: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000B095C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000B0968: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B0970: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000B0974: BE882005
	s_cbranch_execz 64207                                      // 0000000B0978: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33b8>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 0000000B097C: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000B0988: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000B0990: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000B0994: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0998: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000B099C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000B09A4: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000B09B0: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B09B4: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000B09B8: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000B09BC: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000B09C4: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B09CC: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000B09D0: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000B09D4: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000B09D8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B09DC: BF870095
	.long 0xd71c006a                                           // 0000000B09E0: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000B09E4: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000B09E8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000B09EC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B09F4: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 0000000B09F8: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 0000000B0A00: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0A08: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000B0A0C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000B0A14: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0A18: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000B0A1C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000B0A24: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000B0A28: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0A30: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000B0A34: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 0000000B0A38: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0A40: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 0000000B0A44: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 0000000B0A48: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0A50: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000B0A54: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000B0A5C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 0000000B0A64: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0A70: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000B0A74: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000B0A7C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000B0A88: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B0A90: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000B0A94: BE882006
	s_cbranch_execz 64138                                      // 0000000B0A98: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33c4>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 0000000B0A9C: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000B0AA8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000B0AB0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000B0AB4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0AB8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000B0ABC: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000B0AC4: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000B0AD0: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B0AD4: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000B0AD8: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000B0ADC: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000B0AE4: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B0AEC: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000B0AF0: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000B0AF4: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000B0AF8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0AFC: BF870095
	.long 0xd71c006a                                           // 0000000B0B00: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000B0B04: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000B0B08: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000B0B0C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0B14: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 0000000B0B18: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000B0B24: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0B28: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000B0B2C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000B0B34: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0B38: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000B0B3C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000B0B44: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000B0B48: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0B50: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000B0B54: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 0000000B0B58: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0B60: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 0000000B0B64: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 0000000B0B68: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0B70: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000B0B74: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000B0B7C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 0000000B0B84: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0B90: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000B0B94: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000B0B9C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000B0BA8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B0BB0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000B0BB4: BE882007
	s_cbranch_execz 64069                                      // 0000000B0BB8: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33d0>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 0000000B0BBC: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000B0BC8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000B0BD0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000B0BD4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0BD8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000B0BDC: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000B0BE4: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000B0BF0: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B0BF4: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000B0BF8: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000B0BFC: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000B0C04: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B0C0C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000B0C10: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000B0C14: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000B0C18: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0C1C: BF870095
	.long 0xd71c006a                                           // 0000000B0C20: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000B0C24: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000B0C28: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000B0C2C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0C34: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 0000000B0C38: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000B0C44: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0C48: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000B0C4C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000B0C54: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0C58: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000B0C5C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000B0C64: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000B0C68: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0C70: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000B0C74: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 0000000B0C78: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0C80: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 0000000B0C84: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 0000000B0C88: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0C90: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000B0C94: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000B0C9C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 0000000B0CA4: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0CB0: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000B0CB4: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000B0CBC: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000B0CC8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B0CD0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000B0CD4: BE882000
	s_cbranch_execz 64000                                      // 0000000B0CD8: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33dc>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 0000000B0CDC: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 0000000B0CE8: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 0000000B0CEC: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000B0CF4: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000B0CF8: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0CFC: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000B0D00: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000B0D08: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000B0D14: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B0D18: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000B0D1C: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000B0D20: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000B0D28: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B0D30: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000B0D34: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000B0D38: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000B0D3C: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0D40: BF870095
	.long 0xd71c006a                                           // 0000000B0D44: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000B0D48: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000B0D4C: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000B0D50: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0D58: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 0000000B0D5C: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000B0D64: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0D68: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 0000000B0D6C: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 0000000B0D74: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0D78: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 0000000B0D7C: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 0000000B0D84: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 0000000B0D88: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0D90: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 0000000B0D94: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 0000000B0D98: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0DA0: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 0000000B0DA4: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 0000000B0DA8: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0DB0: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 0000000B0DB4: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 0000000B0DBC: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 0000000B0DC4: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0DD0: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 0000000B0DD4: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 0000000B0DDC: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 0000000B0DE8: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B0DF0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000B0DF4: BE882001
	s_cbranch_execz 63931                                      // 0000000B0DF8: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33e8>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 0000000B0DFC: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 0000000B0E08: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 0000000B0E0C: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 0000000B0E14: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000B0E18: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B0E1C: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 0000000B0E20: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000B0E28: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 0000000B0E30: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000000B0E3C: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B0E40: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 0000000B0E44: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 0000000B0E4C: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B0E50: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000000B0E54: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 0000000B0E58: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 0000000B0E5C: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0E60: BF870095
	.long 0xd71c0069                                           // 0000000B0E64: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 0000000B0E68: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000000B0E6C: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000B0E70: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0E78: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 0000000B0E7C: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000B0E84: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0E88: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 0000000B0E8C: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 0000000B0E94: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0E98: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 0000000B0E9C: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 0000000B0EA4: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 0000000B0EA8: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0EB0: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 0000000B0EB4: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 0000000B0EB8: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0EC0: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 0000000B0EC4: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 0000000B0EC8: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0ED0: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 0000000B0ED4: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 0000000B0EDC: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 0000000B0EE4: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0EF0: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 0000000B0EF4: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 0000000B0EFC: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 0000000B0F08: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B0F10: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000B0F14: BE882002
	s_cbranch_execz 63862                                      // 0000000B0F18: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33f4>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 0000000B0F1C: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000B0F28: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000B0F30: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000B0F34: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0F38: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000B0F3C: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 0000000B0F44: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 0000000B0F50: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B0F54: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 0000000B0F58: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000B0F5C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 0000000B0F64: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B0F6C: BF870121
	v_add_f32_e32 v98, v98, v105                               // 0000000B0F70: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 0000000B0F74: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 0000000B0F78: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0F7C: BF870095
	.long 0xd71c0062                                           // 0000000B0F80: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 0000000B0F84: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000B0F88: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000B0F8C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0F94: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 0000000B0F98: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000B0FA4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0FA8: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000B0FAC: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 0000000B0FB4: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0FB8: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 0000000B0FBC: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 0000000B0FC4: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 0000000B0FC8: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0FD0: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 0000000B0FD4: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 0000000B0FD8: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0FE0: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 0000000B0FE4: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 0000000B0FE8: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B0FF0: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 0000000B0FF4: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000B0FFC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 0000000B1004: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1010: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 0000000B1014: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 0000000B101C: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000B1028: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B1030: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000B1034: BE882003
	s_cbranch_execz 63793                                      // 0000000B1038: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3400>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 0000000B103C: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000B1048: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000B1050: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000B1054: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1058: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000B105C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000B1064: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 0000000B1070: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1074: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 0000000B1078: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 0000000B1084: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 0000000B1088: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000B108C: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B1094: BF870293
	v_exp_f32_e32 v98, v98                                     // 0000000B1098: 7EC44B62
	.long 0xd71c0062                                           // 0000000B109C: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000B10A0: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B10A4: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000B10A8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000B10AC: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 0000000B10B4: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B10C0: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 0000000B10C4: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000B10C8: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B10D0: BF870291
	v_rcp_f32_e32 v100, v99                                    // 0000000B10D4: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 0000000B10D8: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B10E0: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 0000000B10E4: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 0000000B10E8: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 0000000B10F0: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B10F4: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 0000000B10F8: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 0000000B1100: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1104: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 0000000B1108: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 0000000B1110: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B1118: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000B111C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 0000000B1124: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000B1130: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B1138: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000B113C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000B1148: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B1150: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000B1154: BE882004
	s_cbranch_execz 63724                                      // 0000000B1158: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x340c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 0000000B115C: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000B1168: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000B1170: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000B1174: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1178: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000B117C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000B1184: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000B1190: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B1194: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000B1198: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000B119C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000B11A4: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B11AC: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000B11B0: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000B11B4: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000B11B8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B11BC: BF870095
	.long 0xd71c0062                                           // 0000000B11C0: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000B11C4: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000B11C8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000B11CC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B11D4: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 0000000B11D8: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000B11E4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B11E8: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000B11EC: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000B11F4: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B11F8: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000B11FC: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000B1204: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000B1208: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1210: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 0000000B1214: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 0000000B1218: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1220: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 0000000B1224: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 0000000B1228: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1230: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 0000000B1234: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000B123C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 0000000B1244: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1250: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000B1254: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000B125C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000B1268: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B1270: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000B1274: BE882005
	s_cbranch_execz 63655                                      // 0000000B1278: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3418>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 0000000B127C: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000B1288: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000B1290: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000B1294: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1298: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000B129C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000B12A4: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000B12B0: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B12B4: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000B12B8: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000B12BC: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000B12C4: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B12CC: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000B12D0: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000B12D4: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000B12D8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B12DC: BF870095
	.long 0xd71c0062                                           // 0000000B12E0: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000B12E4: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000B12E8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000B12EC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B12F4: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000000B12F8: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 0000000B1300: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1308: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000B130C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000B1314: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1318: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000B131C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000B1324: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000B1328: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1330: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000B1334: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 0000000B1338: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1340: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 0000000B1344: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 0000000B1348: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1350: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000B1354: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000B135C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 0000000B1364: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1370: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000B1374: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000B137C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000B1388: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B1390: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000B1394: BE882006
	s_cbranch_execz 63586                                      // 0000000B1398: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3424>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 0000000B139C: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000B13A8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000B13B0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000B13B4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B13B8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000B13BC: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000B13C4: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000B13D0: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B13D4: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000B13D8: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000B13DC: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000B13E4: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B13EC: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000B13F0: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000B13F4: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000B13F8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B13FC: BF870095
	.long 0xd71c0062                                           // 0000000B1400: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000B1404: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000B1408: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000B140C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1414: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 0000000B1418: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000B1424: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1428: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000B142C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000B1434: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1438: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000B143C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000B1444: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000B1448: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1450: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000B1454: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000000B1458: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1460: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000000B1464: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000000B1468: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1470: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000B1474: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000B147C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 0000000B1484: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1490: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000B1494: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000B149C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000B14A8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B14B0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000B14B4: BE882007
	s_cbranch_execz 63517                                      // 0000000B14B8: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3430>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 0000000B14BC: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000B14C8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000B14D0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000B14D4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B14D8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000B14DC: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000B14E4: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000B14F0: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B14F4: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000B14F8: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000B14FC: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000B1504: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B150C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000B1510: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000B1514: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000B1518: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B151C: BF870095
	.long 0xd71c0062                                           // 0000000B1520: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000B1524: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000B1528: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000B152C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1534: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 0000000B1538: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000B1544: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1548: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000B154C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000B1554: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1558: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000B155C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000B1564: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000B1568: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1570: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000B1574: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000000B1578: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1580: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000000B1584: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000000B1588: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1590: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000B1594: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000B159C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 0000000B15A4: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B15B0: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000B15B4: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000B15BC: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000B15C8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B15D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000B15D4: BE882000
	s_cbranch_execz 63448                                      // 0000000B15D8: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x343c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 0000000B15DC: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 0000000B15E8: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 0000000B15EC: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000B15F4: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000B15F8: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B15FC: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000B1600: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000B1608: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000B1614: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B1618: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000B161C: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000B1620: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000B1628: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B1630: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000B1634: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000B1638: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000B163C: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1640: BF870095
	.long 0xd71c0062                                           // 0000000B1644: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000B1648: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000B164C: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000B1650: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1658: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000000B165C: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000B1664: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1668: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 0000000B166C: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 0000000B1674: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1678: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 0000000B167C: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 0000000B1684: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 0000000B1688: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1690: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 0000000B1694: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 0000000B1698: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B16A0: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 0000000B16A4: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 0000000B16A8: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B16B0: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 0000000B16B4: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 0000000B16BC: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 0000000B16C4: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B16D0: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 0000000B16D4: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 0000000B16DC: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 0000000B16E8: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B16F0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000B16F4: BE882001
	s_cbranch_execz 63379                                      // 0000000B16F8: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3448>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 0000000B16FC: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 0000000B1708: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 0000000B170C: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 0000000B1714: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000B1718: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B171C: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 0000000B1720: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000B1728: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 0000000B1730: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000000B173C: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B1740: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 0000000B1744: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 0000000B174C: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B1750: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000000B1754: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000000B1758: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000000B175C: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1760: BF870095
	.long 0xd71c0061                                           // 0000000B1764: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000000B1768: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000000B176C: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000B1770: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1778: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 0000000B177C: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000B1784: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1788: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 0000000B178C: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 0000000B1794: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1798: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 0000000B179C: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 0000000B17A4: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 0000000B17A8: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B17B0: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 0000000B17B4: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 0000000B17B8: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B17C0: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 0000000B17C4: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 0000000B17C8: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B17D0: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 0000000B17D4: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 0000000B17DC: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 0000000B17E4: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B17F0: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 0000000B17F4: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 0000000B17FC: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 0000000B1808: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B1810: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000B1814: BE882002
	s_cbranch_execz 63310                                      // 0000000B1818: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3454>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 0000000B181C: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000B1828: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000B1830: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000B1834: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1838: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000B183C: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 0000000B1844: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 0000000B1850: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B1854: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 0000000B1858: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000B185C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 0000000B1864: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B186C: BF870121
	v_add_f32_e32 v90, v90, v97                                // 0000000B1870: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 0000000B1874: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 0000000B1878: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B187C: BF870095
	.long 0xd71c005a                                           // 0000000B1880: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 0000000B1884: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000B1888: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000B188C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1894: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 0000000B1898: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000B18A4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B18A8: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000B18AC: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 0000000B18B4: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B18B8: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 0000000B18BC: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 0000000B18C4: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 0000000B18C8: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B18D0: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 0000000B18D4: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 0000000B18D8: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B18E0: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 0000000B18E4: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 0000000B18E8: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B18F0: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 0000000B18F4: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000B18FC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 0000000B1904: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1910: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 0000000B1914: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 0000000B191C: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000B1928: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B1930: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000B1934: BE882003
	s_cbranch_execz 63241                                      // 0000000B1938: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3460>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 0000000B193C: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000B1948: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000B1950: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000B1954: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1958: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000B195C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000B1964: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 0000000B1970: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1974: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 0000000B1978: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 0000000B1984: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 0000000B1988: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000B198C: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B1994: BF870293
	v_exp_f32_e32 v90, v90                                     // 0000000B1998: 7EB44B5A
	.long 0xd71c005a                                           // 0000000B199C: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000B19A0: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B19A4: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000B19A8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000B19AC: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 0000000B19B4: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B19C0: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 0000000B19C4: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000B19C8: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B19D0: BF870291
	v_rcp_f32_e32 v92, v91                                     // 0000000B19D4: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 0000000B19D8: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B19E0: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 0000000B19E4: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 0000000B19E8: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 0000000B19F0: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B19F4: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 0000000B19F8: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 0000000B1A00: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1A04: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 0000000B1A08: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 0000000B1A10: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B1A18: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000B1A1C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 0000000B1A24: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000B1A30: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B1A38: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000B1A3C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000B1A48: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B1A50: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000B1A54: BE882004
	s_cbranch_execz 63172                                      // 0000000B1A58: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x346c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 0000000B1A5C: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000B1A68: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000B1A70: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000B1A74: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1A78: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000B1A7C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000B1A84: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000B1A90: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B1A94: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000B1A98: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000B1A9C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000B1AA4: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B1AAC: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000B1AB0: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000B1AB4: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000B1AB8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1ABC: BF870095
	.long 0xd71c005a                                           // 0000000B1AC0: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000B1AC4: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000B1AC8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000B1ACC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1AD4: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 0000000B1AD8: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000B1AE4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1AE8: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000B1AEC: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000B1AF4: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1AF8: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000B1AFC: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000B1B04: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000B1B08: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1B10: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 0000000B1B14: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 0000000B1B18: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1B20: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 0000000B1B24: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 0000000B1B28: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1B30: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 0000000B1B34: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000B1B3C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 0000000B1B44: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1B50: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000B1B54: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000B1B5C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000B1B68: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B1B70: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000B1B74: BE882005
	s_cbranch_execz 63103                                      // 0000000B1B78: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3478>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 0000000B1B7C: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000B1B88: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000B1B90: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000B1B94: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1B98: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000B1B9C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000B1BA4: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000B1BB0: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B1BB4: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000B1BB8: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000B1BBC: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000B1BC4: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B1BCC: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000B1BD0: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000B1BD4: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000B1BD8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1BDC: BF870095
	.long 0xd71c005a                                           // 0000000B1BE0: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000B1BE4: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000B1BE8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000B1BEC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1BF4: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000000B1BF8: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 0000000B1C00: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1C08: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000B1C0C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000B1C14: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1C18: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000B1C1C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000B1C24: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000B1C28: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1C30: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000B1C34: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 0000000B1C38: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1C40: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 0000000B1C44: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 0000000B1C48: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1C50: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000B1C54: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000B1C5C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 0000000B1C64: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1C70: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000B1C74: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000B1C7C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000B1C88: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B1C90: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000B1C94: BE882006
	s_cbranch_execz 63034                                      // 0000000B1C98: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3484>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 0000000B1C9C: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000B1CA8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000B1CB0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000B1CB4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1CB8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000B1CBC: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000B1CC4: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000B1CD0: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B1CD4: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000B1CD8: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000B1CDC: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000B1CE4: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B1CEC: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000B1CF0: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000B1CF4: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000B1CF8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1CFC: BF870095
	.long 0xd71c005a                                           // 0000000B1D00: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000B1D04: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000B1D08: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000B1D0C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1D14: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 0000000B1D18: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000B1D24: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1D28: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000B1D2C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000B1D34: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1D38: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000B1D3C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000B1D44: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000B1D48: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1D50: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000B1D54: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 0000000B1D58: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1D60: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 0000000B1D64: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 0000000B1D68: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1D70: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000B1D74: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000B1D7C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 0000000B1D84: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1D90: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000B1D94: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000B1D9C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000B1DA8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B1DB0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000B1DB4: BE882007
	s_cbranch_execz 62965                                      // 0000000B1DB8: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3490>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 0000000B1DBC: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000B1DC8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000B1DD0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000B1DD4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1DD8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000B1DDC: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000B1DE4: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000B1DF0: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B1DF4: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000B1DF8: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000B1DFC: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000B1E04: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B1E0C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000B1E10: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000B1E14: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000B1E18: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1E1C: BF870095
	.long 0xd71c005a                                           // 0000000B1E20: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000B1E24: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000B1E28: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000B1E2C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1E34: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 0000000B1E38: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000B1E44: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1E48: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000B1E4C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000B1E54: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1E58: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000B1E5C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000B1E64: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000B1E68: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1E70: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000B1E74: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 0000000B1E78: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1E80: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 0000000B1E84: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 0000000B1E88: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1E90: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000B1E94: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000B1E9C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 0000000B1EA4: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1EB0: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000B1EB4: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000B1EBC: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000B1EC8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B1ED0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000B1ED4: BE882000
	s_cbranch_execz 62896                                      // 0000000B1ED8: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x349c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 0000000B1EDC: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 0000000B1EE8: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 0000000B1EEC: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000B1EF4: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000B1EF8: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1EFC: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000B1F00: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000B1F08: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000B1F14: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B1F18: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000B1F1C: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000B1F20: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000B1F28: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B1F30: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000B1F34: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000B1F38: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000B1F3C: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1F40: BF870095
	.long 0xd71c005a                                           // 0000000B1F44: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000B1F48: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000B1F4C: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000B1F50: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1F58: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000000B1F5C: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000B1F64: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1F68: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 0000000B1F6C: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 0000000B1F74: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1F78: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 0000000B1F7C: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 0000000B1F84: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 0000000B1F88: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1F90: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 0000000B1F94: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 0000000B1F98: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1FA0: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 0000000B1FA4: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 0000000B1FA8: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1FB0: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 0000000B1FB4: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 0000000B1FBC: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 0000000B1FC4: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B1FD0: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 0000000B1FD4: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 0000000B1FDC: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 0000000B1FE8: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B1FF0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000B1FF4: BE882001
	s_cbranch_execz 62827                                      // 0000000B1FF8: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34a8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 0000000B1FFC: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 0000000B2008: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 0000000B200C: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 0000000B2014: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000B2018: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B201C: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 0000000B2020: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000B2028: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 0000000B2030: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000000B203C: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B2040: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 0000000B2044: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 0000000B204C: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B2050: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000000B2054: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 0000000B2058: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 0000000B205C: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2060: BF870095
	.long 0xd71c0059                                           // 0000000B2064: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000000B2068: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000000B206C: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000B2070: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2078: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 0000000B207C: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000B2084: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2088: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 0000000B208C: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 0000000B2094: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2098: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 0000000B209C: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 0000000B20A4: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 0000000B20A8: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B20B0: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 0000000B20B4: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 0000000B20B8: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B20C0: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 0000000B20C4: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 0000000B20C8: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B20D0: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 0000000B20D4: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 0000000B20DC: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 0000000B20E4: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B20F0: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 0000000B20F4: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 0000000B20FC: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 0000000B2108: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B2110: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000B2114: BE882002
	s_cbranch_execz 62758                                      // 0000000B2118: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34b4>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 0000000B211C: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000B2128: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000B2130: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000B2134: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2138: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000B213C: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 0000000B2144: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 0000000B2150: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B2154: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 0000000B2158: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000B215C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 0000000B2164: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B216C: BF870121
	v_add_f32_e32 v82, v82, v89                                // 0000000B2170: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 0000000B2174: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 0000000B2178: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B217C: BF870095
	.long 0xd71c0052                                           // 0000000B2180: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 0000000B2184: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000B2188: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000B218C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2194: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 0000000B2198: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000B21A4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B21A8: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000B21AC: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 0000000B21B4: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B21B8: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 0000000B21BC: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 0000000B21C4: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 0000000B21C8: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B21D0: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 0000000B21D4: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 0000000B21D8: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B21E0: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 0000000B21E4: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 0000000B21E8: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B21F0: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 0000000B21F4: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000B21FC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 0000000B2204: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2210: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 0000000B2214: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 0000000B221C: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000B2228: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B2230: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000B2234: BE882003
	s_cbranch_execz 62689                                      // 0000000B2238: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34c0>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 0000000B223C: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000B2248: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000B2250: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000B2254: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2258: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000B225C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000B2264: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 0000000B2270: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2274: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 0000000B2278: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 0000000B2284: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 0000000B2288: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000B228C: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B2294: BF870293
	v_exp_f32_e32 v82, v82                                     // 0000000B2298: 7EA44B52
	.long 0xd71c0052                                           // 0000000B229C: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000B22A0: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B22A4: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000B22A8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000B22AC: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 0000000B22B4: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B22C0: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 0000000B22C4: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000B22C8: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B22D0: BF870291
	v_rcp_f32_e32 v84, v83                                     // 0000000B22D4: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 0000000B22D8: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B22E0: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 0000000B22E4: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 0000000B22E8: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 0000000B22F0: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B22F4: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 0000000B22F8: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 0000000B2300: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2304: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 0000000B2308: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 0000000B2310: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B2318: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000B231C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 0000000B2324: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000B2330: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B2338: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000B233C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000B2348: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B2350: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000B2354: BE882004
	s_cbranch_execz 62620                                      // 0000000B2358: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34cc>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 0000000B235C: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000B2368: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000B2370: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000B2374: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2378: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000B237C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000B2384: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000B2390: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B2394: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000B2398: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000B239C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000B23A4: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B23AC: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000B23B0: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000B23B4: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000B23B8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B23BC: BF870095
	.long 0xd71c0052                                           // 0000000B23C0: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000B23C4: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000B23C8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000B23CC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B23D4: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 0000000B23D8: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000B23E4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B23E8: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000B23EC: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000B23F4: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B23F8: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000B23FC: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000B2404: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000B2408: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2410: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 0000000B2414: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 0000000B2418: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2420: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 0000000B2424: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 0000000B2428: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2430: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 0000000B2434: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000B243C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 0000000B2444: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2450: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000B2454: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000B245C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000B2468: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B2470: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000B2474: BE882005
	s_cbranch_execz 62551                                      // 0000000B2478: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34d8>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 0000000B247C: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000B2488: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000B2490: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000B2494: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2498: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000B249C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000B24A4: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000B24B0: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B24B4: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000B24B8: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000B24BC: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000B24C4: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B24CC: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000B24D0: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000B24D4: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000B24D8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B24DC: BF870095
	.long 0xd71c0052                                           // 0000000B24E0: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000B24E4: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000B24E8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000B24EC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B24F4: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 0000000B24F8: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 0000000B2500: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2508: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000B250C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000B2514: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2518: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000B251C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000B2524: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000B2528: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2530: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000B2534: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 0000000B2538: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2540: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 0000000B2544: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 0000000B2548: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2550: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000B2554: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000B255C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 0000000B2564: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2570: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000B2574: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000B257C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000B2588: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B2590: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000B2594: BE882006
	s_cbranch_execz 62482                                      // 0000000B2598: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34e4>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 0000000B259C: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000B25A8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000B25B0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000B25B4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B25B8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000B25BC: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000B25C4: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000B25D0: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B25D4: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000B25D8: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000B25DC: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000B25E4: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B25EC: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000B25F0: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000B25F4: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000B25F8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B25FC: BF870095
	.long 0xd71c0052                                           // 0000000B2600: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000B2604: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000B2608: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000B260C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2614: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 0000000B2618: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000B2624: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2628: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000B262C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000B2634: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2638: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000B263C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000B2644: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000B2648: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2650: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000B2654: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000000B2658: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2660: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000000B2664: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000000B2668: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2670: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000B2674: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000B267C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 0000000B2684: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2690: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000B2694: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000B269C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000B26A8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B26B0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000B26B4: BE882007
	s_cbranch_execz 62413                                      // 0000000B26B8: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34f0>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 0000000B26BC: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000B26C8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000B26D0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000B26D4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B26D8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000B26DC: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000B26E4: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000B26F0: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B26F4: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000B26F8: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000B26FC: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000B2704: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B270C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000B2710: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000B2714: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000B2718: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B271C: BF870095
	.long 0xd71c0052                                           // 0000000B2720: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000B2724: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000B2728: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000B272C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2734: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 0000000B2738: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000B2744: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2748: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000B274C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000B2754: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2758: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000B275C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000B2764: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000B2768: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2770: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000B2774: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000000B2778: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2780: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000000B2784: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000000B2788: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2790: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000B2794: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000B279C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 0000000B27A4: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B27B0: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000B27B4: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000B27BC: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000B27C8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B27D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000B27D4: BE882000
	s_cbranch_execz 62344                                      // 0000000B27D8: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34fc>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 0000000B27DC: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 0000000B27E8: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 0000000B27EC: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000B27F4: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000B27F8: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B27FC: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000B2800: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000B2808: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000B2814: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B2818: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000B281C: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000B2820: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000B2828: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B2830: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000B2834: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000B2838: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000B283C: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2840: BF870095
	.long 0xd71c0052                                           // 0000000B2844: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000B2848: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000B284C: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000B2850: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2858: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 0000000B285C: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000B2864: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2868: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 0000000B286C: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 0000000B2874: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2878: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 0000000B287C: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 0000000B2884: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 0000000B2888: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2890: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 0000000B2894: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 0000000B2898: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B28A0: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 0000000B28A4: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 0000000B28A8: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B28B0: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 0000000B28B4: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 0000000B28BC: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 0000000B28C4: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B28D0: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 0000000B28D4: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 0000000B28DC: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 0000000B28E8: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B28F0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000B28F4: BE882001
	s_cbranch_execz 62275                                      // 0000000B28F8: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3508>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 0000000B28FC: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 0000000B2908: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 0000000B290C: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 0000000B2914: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000B2918: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B291C: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 0000000B2920: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000B2928: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 0000000B2930: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 0000000B293C: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B2940: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 0000000B2944: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 0000000B294C: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B2950: BF870121
	v_add_f32_e32 v81, v81, v82                                // 0000000B2954: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 0000000B2958: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 0000000B295C: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2960: BF870095
	.long 0xd71c0051                                           // 0000000B2964: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 0000000B2968: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 0000000B296C: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000B2970: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2978: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 0000000B297C: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000B2984: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2988: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 0000000B298C: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 0000000B2994: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2998: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 0000000B299C: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 0000000B29A4: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 0000000B29A8: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B29B0: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 0000000B29B4: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 0000000B29B8: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B29C0: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 0000000B29C4: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 0000000B29C8: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B29D0: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 0000000B29D4: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 0000000B29DC: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 0000000B29E4: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B29F0: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 0000000B29F4: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 0000000B29FC: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 0000000B2A08: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B2A10: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000B2A14: BE882002
	s_cbranch_execz 62206                                      // 0000000B2A18: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3514>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 0000000B2A1C: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000B2A28: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000B2A30: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000B2A34: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2A38: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000B2A3C: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 0000000B2A44: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 0000000B2A50: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B2A54: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 0000000B2A58: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000B2A5C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 0000000B2A64: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B2A6C: BF870121
	v_add_f32_e32 v74, v74, v81                                // 0000000B2A70: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 0000000B2A74: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 0000000B2A78: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2A7C: BF870095
	.long 0xd71c004a                                           // 0000000B2A80: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 0000000B2A84: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000B2A88: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000B2A8C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2A94: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 0000000B2A98: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000B2AA4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2AA8: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000B2AAC: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 0000000B2AB4: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2AB8: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 0000000B2ABC: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 0000000B2AC4: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 0000000B2AC8: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2AD0: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 0000000B2AD4: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 0000000B2AD8: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2AE0: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 0000000B2AE4: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 0000000B2AE8: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2AF0: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 0000000B2AF4: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000B2AFC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 0000000B2B04: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2B10: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 0000000B2B14: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 0000000B2B1C: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000B2B28: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B2B30: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000B2B34: BE882003
	s_cbranch_execz 62137                                      // 0000000B2B38: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3520>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 0000000B2B3C: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000B2B48: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000B2B50: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000B2B54: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2B58: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000B2B5C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000B2B64: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 0000000B2B70: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2B74: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 0000000B2B78: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 0000000B2B84: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 0000000B2B88: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000B2B8C: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B2B94: BF870293
	v_exp_f32_e32 v74, v74                                     // 0000000B2B98: 7E944B4A
	.long 0xd71c004a                                           // 0000000B2B9C: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000B2BA0: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B2BA4: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000B2BA8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000B2BAC: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 0000000B2BB4: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2BC0: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 0000000B2BC4: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000B2BC8: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B2BD0: BF870291
	v_rcp_f32_e32 v76, v75                                     // 0000000B2BD4: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 0000000B2BD8: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B2BE0: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 0000000B2BE4: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 0000000B2BE8: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 0000000B2BF0: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2BF4: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 0000000B2BF8: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 0000000B2C00: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2C04: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 0000000B2C08: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 0000000B2C10: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B2C18: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000B2C1C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 0000000B2C24: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000B2C30: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B2C38: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000B2C3C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000B2C48: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B2C50: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000B2C54: BE882004
	s_cbranch_execz 62068                                      // 0000000B2C58: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x352c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 0000000B2C5C: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000B2C68: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000B2C70: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000B2C74: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2C78: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000B2C7C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000B2C84: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000B2C90: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B2C94: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000B2C98: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000B2C9C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000B2CA4: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B2CAC: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000B2CB0: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000B2CB4: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000B2CB8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2CBC: BF870095
	.long 0xd71c004a                                           // 0000000B2CC0: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000B2CC4: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000B2CC8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000B2CCC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2CD4: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 0000000B2CD8: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000B2CE4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2CE8: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000B2CEC: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000B2CF4: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2CF8: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000B2CFC: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000B2D04: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000B2D08: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2D10: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 0000000B2D14: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 0000000B2D18: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2D20: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 0000000B2D24: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 0000000B2D28: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2D30: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 0000000B2D34: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000B2D3C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 0000000B2D44: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2D50: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000B2D54: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000B2D5C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000B2D68: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B2D70: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000B2D74: BE882005
	s_cbranch_execz 61999                                      // 0000000B2D78: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3538>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 0000000B2D7C: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000B2D88: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000B2D90: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000B2D94: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2D98: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000B2D9C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000B2DA4: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000B2DB0: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B2DB4: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000B2DB8: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000B2DBC: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000B2DC4: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B2DCC: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000B2DD0: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000B2DD4: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000B2DD8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2DDC: BF870095
	.long 0xd71c004a                                           // 0000000B2DE0: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000B2DE4: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000B2DE8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000B2DEC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2DF4: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000000B2DF8: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 0000000B2E00: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2E08: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000B2E0C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000B2E14: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2E18: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000B2E1C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000B2E24: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000B2E28: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2E30: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000B2E34: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 0000000B2E38: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2E40: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 0000000B2E44: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 0000000B2E48: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2E50: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000B2E54: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000B2E5C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 0000000B2E64: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2E70: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000B2E74: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000B2E7C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000B2E88: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B2E90: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000B2E94: BE882006
	s_cbranch_execz 61930                                      // 0000000B2E98: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3544>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 0000000B2E9C: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000B2EA8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000B2EB0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000B2EB4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2EB8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000B2EBC: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000B2EC4: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000B2ED0: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B2ED4: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000B2ED8: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000B2EDC: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000B2EE4: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B2EEC: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000B2EF0: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000B2EF4: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000B2EF8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2EFC: BF870095
	.long 0xd71c004a                                           // 0000000B2F00: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000B2F04: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000B2F08: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000B2F0C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2F14: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 0000000B2F18: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000B2F24: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2F28: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000B2F2C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000B2F34: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2F38: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000B2F3C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000B2F44: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000B2F48: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2F50: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000B2F54: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000000B2F58: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2F60: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000B2F64: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000B2F68: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2F70: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000B2F74: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000B2F7C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 0000000B2F84: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2F90: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000B2F94: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000B2F9C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000B2FA8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B2FB0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000B2FB4: BE882007
	s_cbranch_execz 61861                                      // 0000000B2FB8: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3550>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 0000000B2FBC: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000B2FC8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000B2FD0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000B2FD4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B2FD8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000B2FDC: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000B2FE4: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000B2FF0: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B2FF4: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000B2FF8: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000B2FFC: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000B3004: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B300C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000B3010: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000B3014: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000B3018: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B301C: BF870095
	.long 0xd71c004a                                           // 0000000B3020: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000B3024: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000B3028: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000B302C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3034: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 0000000B3038: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000B3044: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3048: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000B304C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000B3054: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3058: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000B305C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000B3064: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000B3068: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3070: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000B3074: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000000B3078: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3080: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000B3084: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000B3088: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3090: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000B3094: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000B309C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 0000000B30A4: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B30B0: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000B30B4: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000B30BC: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000B30C8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B30D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000B30D4: BE882000
	s_cbranch_execz 61792                                      // 0000000B30D8: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x355c>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 0000000B30DC: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 0000000B30E8: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 0000000B30EC: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000B30F4: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000B30F8: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B30FC: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000B3100: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000B3108: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000B3114: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B3118: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000B311C: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000B3120: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000B3128: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B3130: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000B3134: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000B3138: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000B313C: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3140: BF870095
	.long 0xd71c004a                                           // 0000000B3144: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000B3148: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000B314C: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000B3150: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3158: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000000B315C: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000B3164: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3168: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 0000000B316C: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 0000000B3174: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3178: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 0000000B317C: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 0000000B3184: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 0000000B3188: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3190: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 0000000B3194: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 0000000B3198: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B31A0: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 0000000B31A4: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 0000000B31A8: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B31B0: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 0000000B31B4: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 0000000B31BC: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 0000000B31C4: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B31D0: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 0000000B31D4: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 0000000B31DC: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 0000000B31E8: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B31F0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000B31F4: BE882001
	s_cbranch_execz 61723                                      // 0000000B31F8: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3568>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 0000000B31FC: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 0000000B3208: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 0000000B320C: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 0000000B3214: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000B3218: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B321C: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 0000000B3220: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000B3228: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 0000000B3230: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000000B323C: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B3240: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 0000000B3244: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 0000000B324C: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B3250: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000000B3254: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 0000000B3258: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 0000000B325C: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3260: BF870095
	.long 0xd71c0049                                           // 0000000B3264: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000000B3268: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000B326C: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000B3270: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3278: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 0000000B327C: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000B3284: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3288: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 0000000B328C: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 0000000B3294: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3298: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 0000000B329C: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 0000000B32A4: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 0000000B32A8: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B32B0: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 0000000B32B4: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 0000000B32B8: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B32C0: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 0000000B32C4: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 0000000B32C8: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B32D0: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 0000000B32D4: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 0000000B32DC: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 0000000B32E4: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B32F0: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 0000000B32F4: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 0000000B32FC: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 0000000B3308: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B3310: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000B3314: BE882002
	s_cbranch_execz 61654                                      // 0000000B3318: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3574>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 0000000B331C: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000B3328: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000B3330: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000B3334: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3338: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000B333C: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 0000000B3344: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 0000000B3350: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B3354: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 0000000B3358: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000B335C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 0000000B3364: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B336C: BF870121
	v_add_f32_e32 v66, v66, v73                                // 0000000B3370: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 0000000B3374: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 0000000B3378: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B337C: BF870095
	.long 0xd71c0042                                           // 0000000B3380: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 0000000B3384: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000B3388: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000B338C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3394: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 0000000B3398: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000B33A4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B33A8: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000B33AC: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 0000000B33B4: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B33B8: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 0000000B33BC: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 0000000B33C4: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 0000000B33C8: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B33D0: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 0000000B33D4: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 0000000B33D8: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B33E0: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 0000000B33E4: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 0000000B33E8: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B33F0: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 0000000B33F4: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000B33FC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 0000000B3404: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3410: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 0000000B3414: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 0000000B341C: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000B3428: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B3430: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000B3434: BE882003
	s_cbranch_execz 61585                                      // 0000000B3438: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3580>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 0000000B343C: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000B3448: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000B3450: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000B3454: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3458: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000B345C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000B3464: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 0000000B3470: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3474: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 0000000B3478: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 0000000B3484: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 0000000B3488: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000B348C: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B3494: BF870293
	v_exp_f32_e32 v66, v66                                     // 0000000B3498: 7E844B42
	.long 0xd71c0042                                           // 0000000B349C: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000B34A0: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B34A4: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000B34A8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000B34AC: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 0000000B34B4: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B34C0: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 0000000B34C4: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000B34C8: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B34D0: BF870291
	v_rcp_f32_e32 v68, v67                                     // 0000000B34D4: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 0000000B34D8: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B34E0: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 0000000B34E4: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 0000000B34E8: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 0000000B34F0: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B34F4: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 0000000B34F8: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 0000000B3500: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3504: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 0000000B3508: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 0000000B3510: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B3518: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000B351C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 0000000B3524: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000B3530: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B3538: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000B353C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000B3548: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B3550: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000B3554: BE882004
	s_cbranch_execz 61516                                      // 0000000B3558: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x358c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 0000000B355C: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000B3568: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000B3570: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000B3574: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3578: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000B357C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000B3584: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000B3590: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B3594: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000B3598: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000B359C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000B35A4: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B35AC: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000B35B0: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000B35B4: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000B35B8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B35BC: BF870095
	.long 0xd71c0042                                           // 0000000B35C0: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000B35C4: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000B35C8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000B35CC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B35D4: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 0000000B35D8: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000B35E4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B35E8: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000B35EC: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000B35F4: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B35F8: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000B35FC: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000B3604: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000B3608: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3610: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 0000000B3614: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 0000000B3618: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3620: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 0000000B3624: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 0000000B3628: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3630: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 0000000B3634: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000B363C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 0000000B3644: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3650: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000B3654: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000B365C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000B3668: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B3670: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000B3674: BE882005
	s_cbranch_execz 61447                                      // 0000000B3678: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3598>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 0000000B367C: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000B3688: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000B3690: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000B3694: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3698: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000B369C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000B36A4: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000B36B0: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B36B4: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000B36B8: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000B36BC: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000B36C4: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B36CC: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000B36D0: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000B36D4: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000B36D8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B36DC: BF870095
	.long 0xd71c0042                                           // 0000000B36E0: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000B36E4: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000B36E8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000B36EC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B36F4: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 0000000B36F8: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 0000000B3700: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3708: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000B370C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000B3714: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3718: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000B371C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000B3724: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000B3728: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3730: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000B3734: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 0000000B3738: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3740: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 0000000B3744: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 0000000B3748: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3750: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000B3754: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000B375C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 0000000B3764: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3770: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000B3774: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000B377C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000B3788: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B3790: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000B3794: BE882006
	s_cbranch_execz 61378                                      // 0000000B3798: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35a4>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 0000000B379C: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000B37A8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000B37B0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000B37B4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B37B8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000B37BC: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000B37C4: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000B37D0: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B37D4: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000B37D8: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000B37DC: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000B37E4: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B37EC: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000B37F0: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000B37F4: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000B37F8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B37FC: BF870095
	.long 0xd71c0042                                           // 0000000B3800: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000B3804: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000B3808: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000B380C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3814: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 0000000B3818: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000B3824: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3828: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000B382C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000B3834: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3838: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000B383C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000B3844: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000B3848: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3850: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000B3854: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 0000000B3858: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3860: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 0000000B3864: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 0000000B3868: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3870: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000B3874: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000B387C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 0000000B3884: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3890: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000B3894: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000B389C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000B38A8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B38B0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000B38B4: BE882007
	s_cbranch_execz 61309                                      // 0000000B38B8: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35b0>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 0000000B38BC: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000B38C8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000B38D0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000B38D4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B38D8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000B38DC: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000B38E4: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000B38F0: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B38F4: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000B38F8: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000B38FC: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000B3904: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B390C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000B3910: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000B3914: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000B3918: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B391C: BF870095
	.long 0xd71c0042                                           // 0000000B3920: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000B3924: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000B3928: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000B392C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3934: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 0000000B3938: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000B3944: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3948: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000B394C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000B3954: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3958: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000B395C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000B3964: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000B3968: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3970: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000B3974: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 0000000B3978: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3980: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 0000000B3984: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 0000000B3988: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3990: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000B3994: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000B399C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 0000000B39A4: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B39B0: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000B39B4: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000B39BC: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000B39C8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B39D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000B39D4: BE882000
	s_cbranch_execz 61240                                      // 0000000B39D8: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35bc>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 0000000B39DC: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 0000000B39E8: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 0000000B39EC: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000B39F4: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000B39F8: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B39FC: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000B3A00: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000B3A08: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000B3A14: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B3A18: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000B3A1C: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000B3A20: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000B3A28: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B3A30: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000B3A34: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000B3A38: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000B3A3C: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3A40: BF870095
	.long 0xd71c0042                                           // 0000000B3A44: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000B3A48: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000B3A4C: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000B3A50: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3A58: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 0000000B3A5C: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000B3A64: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3A68: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 0000000B3A6C: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 0000000B3A74: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3A78: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 0000000B3A7C: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 0000000B3A84: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 0000000B3A88: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3A90: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 0000000B3A94: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 0000000B3A98: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3AA0: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 0000000B3AA4: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 0000000B3AA8: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3AB0: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 0000000B3AB4: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 0000000B3ABC: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 0000000B3AC4: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3AD0: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 0000000B3AD4: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 0000000B3ADC: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 0000000B3AE8: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B3AF0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000B3AF4: BE882001
	s_cbranch_execz 61171                                      // 0000000B3AF8: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35c8>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 0000000B3AFC: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 0000000B3B08: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 0000000B3B0C: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 0000000B3B14: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000B3B18: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B3B1C: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 0000000B3B20: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000B3B28: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 0000000B3B30: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 0000000B3B3C: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B3B40: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 0000000B3B44: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 0000000B3B4C: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B3B50: BF870121
	v_add_f32_e32 v65, v65, v66                                // 0000000B3B54: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 0000000B3B58: 7E841143
	v_exp_f32_e32 v65, v65                                     // 0000000B3B5C: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3B60: BF870095
	.long 0xd71c0041                                           // 0000000B3B64: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 0000000B3B68: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 0000000B3B6C: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000B3B70: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3B78: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 0000000B3B7C: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000B3B84: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3B88: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 0000000B3B8C: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 0000000B3B94: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3B98: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 0000000B3B9C: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 0000000B3BA4: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 0000000B3BA8: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3BB0: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 0000000B3BB4: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 0000000B3BB8: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3BC0: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 0000000B3BC4: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 0000000B3BC8: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3BD0: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 0000000B3BD4: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 0000000B3BDC: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 0000000B3BE4: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3BF0: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 0000000B3BF4: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 0000000B3BFC: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 0000000B3C08: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B3C10: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000B3C14: BE882002
	s_cbranch_execz 61102                                      // 0000000B3C18: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35d4>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 0000000B3C1C: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000B3C28: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000B3C30: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000B3C34: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3C38: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000B3C3C: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 0000000B3C44: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 0000000B3C50: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B3C54: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 0000000B3C58: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000B3C5C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 0000000B3C64: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B3C6C: BF870121
	v_add_f32_e32 v58, v58, v65                                // 0000000B3C70: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 0000000B3C74: 7E821142
	v_exp_f32_e32 v58, v58                                     // 0000000B3C78: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3C7C: BF870095
	.long 0xd71c003a                                           // 0000000B3C80: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 0000000B3C84: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000B3C88: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000B3C8C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3C94: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 0000000B3C98: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000B3CA4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3CA8: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000B3CAC: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 0000000B3CB4: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3CB8: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 0000000B3CBC: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 0000000B3CC4: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 0000000B3CC8: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3CD0: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 0000000B3CD4: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 0000000B3CD8: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3CE0: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 0000000B3CE4: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 0000000B3CE8: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3CF0: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 0000000B3CF4: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000B3CFC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 0000000B3D04: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3D10: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 0000000B3D14: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 0000000B3D1C: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000B3D28: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B3D30: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000B3D34: BE882003
	s_cbranch_execz 61033                                      // 0000000B3D38: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35e0>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 0000000B3D3C: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000B3D48: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000B3D50: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000B3D54: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3D58: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000B3D5C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000B3D64: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 0000000B3D70: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3D74: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 0000000B3D78: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 0000000B3D84: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 0000000B3D88: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000B3D8C: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B3D94: BF870293
	v_exp_f32_e32 v58, v58                                     // 0000000B3D98: 7E744B3A
	.long 0xd71c003a                                           // 0000000B3D9C: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000B3DA0: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B3DA4: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000B3DA8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000B3DAC: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 0000000B3DB4: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3DC0: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 0000000B3DC4: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000B3DC8: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B3DD0: BF870291
	v_rcp_f32_e32 v60, v59                                     // 0000000B3DD4: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 0000000B3DD8: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B3DE0: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 0000000B3DE4: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 0000000B3DE8: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 0000000B3DF0: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3DF4: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 0000000B3DF8: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 0000000B3E00: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3E04: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 0000000B3E08: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 0000000B3E10: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B3E18: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000B3E1C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 0000000B3E24: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000B3E30: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B3E38: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000B3E3C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000B3E48: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B3E50: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000B3E54: BE882004
	s_cbranch_execz 60964                                      // 0000000B3E58: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35ec>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 0000000B3E5C: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000B3E68: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000B3E70: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000B3E74: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3E78: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000B3E7C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000B3E84: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000B3E90: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B3E94: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000B3E98: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000B3E9C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000B3EA4: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B3EAC: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000B3EB0: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000B3EB4: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000B3EB8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3EBC: BF870095
	.long 0xd71c003a                                           // 0000000B3EC0: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000B3EC4: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000B3EC8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000B3ECC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3ED4: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 0000000B3ED8: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000B3EE4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3EE8: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000B3EEC: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000B3EF4: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3EF8: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000B3EFC: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000B3F04: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000B3F08: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3F10: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 0000000B3F14: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 0000000B3F18: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3F20: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 0000000B3F24: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 0000000B3F28: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3F30: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 0000000B3F34: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000B3F3C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 0000000B3F44: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3F50: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000B3F54: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000B3F5C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000B3F68: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B3F70: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000B3F74: BE882005
	s_cbranch_execz 60895                                      // 0000000B3F78: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35f8>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 0000000B3F7C: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000B3F88: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000B3F90: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000B3F94: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3F98: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000B3F9C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000B3FA4: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000B3FB0: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B3FB4: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000B3FB8: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000B3FBC: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000B3FC4: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B3FCC: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000B3FD0: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000B3FD4: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000B3FD8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3FDC: BF870095
	.long 0xd71c003a                                           // 0000000B3FE0: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000B3FE4: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000B3FE8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000B3FEC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B3FF4: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000000B3FF8: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 0000000B4000: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4008: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000B400C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000B4014: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4018: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000B401C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000B4024: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000B4028: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4030: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000B4034: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 0000000B4038: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4040: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 0000000B4044: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 0000000B4048: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4050: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000B4054: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000B405C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 0000000B4064: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4070: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000B4074: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000B407C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000B4088: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B4090: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000B4094: BE882006
	s_cbranch_execz 60826                                      // 0000000B4098: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3604>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 0000000B409C: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000B40A8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000B40B0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000B40B4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B40B8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000B40BC: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000B40C4: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000B40D0: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B40D4: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000B40D8: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000B40DC: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000B40E4: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B40EC: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000B40F0: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000B40F4: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000B40F8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B40FC: BF870095
	.long 0xd71c003a                                           // 0000000B4100: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000B4104: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000B4108: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000B410C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4114: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 0000000B4118: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000B4124: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4128: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000B412C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000B4134: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4138: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000B413C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000B4144: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000B4148: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4150: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000B4154: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000000B4158: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4160: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000B4164: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000B4168: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4170: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000B4174: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000B417C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 0000000B4184: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4190: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000B4194: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000B419C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000B41A8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B41B0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000B41B4: BE882007
	s_cbranch_execz 60757                                      // 0000000B41B8: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3610>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 0000000B41BC: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000B41C8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000B41D0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000B41D4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B41D8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000B41DC: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000B41E4: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000B41F0: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B41F4: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000B41F8: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000B41FC: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000B4204: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B420C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000B4210: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000B4214: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000B4218: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B421C: BF870095
	.long 0xd71c003a                                           // 0000000B4220: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000B4224: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000B4228: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000B422C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4234: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 0000000B4238: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000B4244: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4248: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000B424C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000B4254: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4258: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000B425C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000B4264: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000B4268: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4270: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000B4274: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000000B4278: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4280: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000B4284: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000B4288: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4290: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000B4294: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000B429C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 0000000B42A4: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B42B0: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000B42B4: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000B42BC: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000B42C8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B42D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000B42D4: BE882000
	s_cbranch_execz 60688                                      // 0000000B42D8: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x361c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 0000000B42DC: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 0000000B42E8: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 0000000B42EC: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000B42F4: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000B42F8: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B42FC: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000B4300: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000B4308: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000B4314: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B4318: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000B431C: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000B4320: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000B4328: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B4330: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000B4334: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000B4338: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000B433C: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4340: BF870095
	.long 0xd71c003a                                           // 0000000B4344: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000B4348: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000B434C: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000B4350: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4358: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000000B435C: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000B4364: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4368: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 0000000B436C: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 0000000B4374: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4378: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 0000000B437C: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 0000000B4384: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 0000000B4388: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4390: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 0000000B4394: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 0000000B4398: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B43A0: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 0000000B43A4: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 0000000B43A8: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B43B0: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 0000000B43B4: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 0000000B43BC: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 0000000B43C4: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B43D0: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 0000000B43D4: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 0000000B43DC: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 0000000B43E8: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B43F0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000B43F4: BE882001
	s_cbranch_execz 60619                                      // 0000000B43F8: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3628>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 0000000B43FC: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 0000000B4408: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 0000000B440C: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 0000000B4414: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000B4418: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B441C: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 0000000B4420: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000B4428: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 0000000B4430: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 0000000B443C: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B4440: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 0000000B4444: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 0000000B444C: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B4450: BF870121
	v_add_f32_e32 v57, v57, v58                                // 0000000B4454: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 0000000B4458: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 0000000B445C: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4460: BF870095
	.long 0xd71c0039                                           // 0000000B4464: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 0000000B4468: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000000B446C: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000B4470: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4478: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 0000000B447C: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000B4484: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4488: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 0000000B448C: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 0000000B4494: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4498: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 0000000B449C: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 0000000B44A4: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 0000000B44A8: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B44B0: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 0000000B44B4: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 0000000B44B8: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B44C0: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 0000000B44C4: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 0000000B44C8: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B44D0: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 0000000B44D4: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 0000000B44DC: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 0000000B44E4: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B44F0: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 0000000B44F4: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 0000000B44FC: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 0000000B4508: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B4510: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000B4514: BE882002
	s_cbranch_execz 60550                                      // 0000000B4518: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3634>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 0000000B451C: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000B4528: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000B4530: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000B4534: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4538: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000B453C: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 0000000B4544: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 0000000B4550: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B4554: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 0000000B4558: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000B455C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 0000000B4564: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B456C: BF870121
	v_add_f32_e32 v50, v50, v57                                // 0000000B4570: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 0000000B4574: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 0000000B4578: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B457C: BF870095
	.long 0xd71c0032                                           // 0000000B4580: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 0000000B4584: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000B4588: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000B458C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4594: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 0000000B4598: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000B45A4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B45A8: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000B45AC: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 0000000B45B4: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B45B8: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 0000000B45BC: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 0000000B45C4: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 0000000B45C8: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B45D0: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 0000000B45D4: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 0000000B45D8: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B45E0: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 0000000B45E4: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 0000000B45E8: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B45F0: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 0000000B45F4: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000B45FC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 0000000B4604: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4610: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 0000000B4614: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 0000000B461C: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000B4628: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B4630: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000B4634: BE882003
	s_cbranch_execz 60481                                      // 0000000B4638: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3640>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 0000000B463C: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000B4648: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000B4650: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000B4654: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4658: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000B465C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000B4664: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 0000000B4670: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4674: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 0000000B4678: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 0000000B4684: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 0000000B4688: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000B468C: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B4694: BF870293
	v_exp_f32_e32 v50, v50                                     // 0000000B4698: 7E644B32
	.long 0xd71c0032                                           // 0000000B469C: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000B46A0: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B46A4: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000B46A8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000B46AC: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 0000000B46B4: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B46C0: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 0000000B46C4: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000B46C8: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B46D0: BF870291
	v_rcp_f32_e32 v52, v51                                     // 0000000B46D4: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 0000000B46D8: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B46E0: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 0000000B46E4: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 0000000B46E8: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 0000000B46F0: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B46F4: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 0000000B46F8: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 0000000B4700: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4704: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 0000000B4708: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 0000000B4710: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B4718: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000B471C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 0000000B4724: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000B4730: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B4738: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000B473C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000B4748: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B4750: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000B4754: BE882004
	s_cbranch_execz 60412                                      // 0000000B4758: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x364c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 0000000B475C: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000B4768: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000B4770: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000B4774: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4778: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000B477C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000B4784: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000B4790: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B4794: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000B4798: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000B479C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000B47A4: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B47AC: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000B47B0: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000B47B4: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000B47B8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B47BC: BF870095
	.long 0xd71c0032                                           // 0000000B47C0: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000B47C4: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000B47C8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000B47CC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B47D4: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 0000000B47D8: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000B47E4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B47E8: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000B47EC: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000B47F4: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B47F8: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000B47FC: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000B4804: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000B4808: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4810: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 0000000B4814: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 0000000B4818: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4820: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 0000000B4824: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 0000000B4828: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4830: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 0000000B4834: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000B483C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 0000000B4844: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4850: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000B4854: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000B485C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000B4868: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B4870: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000B4874: BE882005
	s_cbranch_execz 60343                                      // 0000000B4878: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3658>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 0000000B487C: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000B4888: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000B4890: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000B4894: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4898: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000B489C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000B48A4: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000B48B0: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B48B4: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000B48B8: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000B48BC: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000B48C4: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B48CC: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000B48D0: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000B48D4: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000B48D8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B48DC: BF870095
	.long 0xd71c0032                                           // 0000000B48E0: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000B48E4: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000B48E8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000B48EC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B48F4: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 0000000B48F8: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 0000000B4900: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4908: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000B490C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000B4914: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4918: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000B491C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000B4924: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000B4928: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4930: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000B4934: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 0000000B4938: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4940: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 0000000B4944: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 0000000B4948: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4950: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000B4954: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000B495C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 0000000B4964: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4970: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000B4974: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000B497C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000B4988: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B4990: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000B4994: BE882006
	s_cbranch_execz 60274                                      // 0000000B4998: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3664>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 0000000B499C: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000B49A8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000B49B0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000B49B4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B49B8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000B49BC: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000B49C4: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000B49D0: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B49D4: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000B49D8: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000B49DC: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000B49E4: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B49EC: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000B49F0: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000B49F4: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000B49F8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B49FC: BF870095
	.long 0xd71c0032                                           // 0000000B4A00: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000B4A04: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000B4A08: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000B4A0C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4A14: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 0000000B4A18: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000B4A24: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4A28: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000B4A2C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000B4A34: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4A38: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000B4A3C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000B4A44: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000B4A48: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4A50: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000B4A54: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 0000000B4A58: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4A60: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 0000000B4A64: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 0000000B4A68: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4A70: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000B4A74: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000B4A7C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 0000000B4A84: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4A90: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000B4A94: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000B4A9C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000B4AA8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B4AB0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000B4AB4: BE882007
	s_cbranch_execz 60205                                      // 0000000B4AB8: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3670>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 0000000B4ABC: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000B4AC8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000B4AD0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000B4AD4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4AD8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000B4ADC: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000B4AE4: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000B4AF0: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B4AF4: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000B4AF8: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000B4AFC: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000B4B04: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B4B0C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000B4B10: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000B4B14: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000B4B18: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4B1C: BF870095
	.long 0xd71c0032                                           // 0000000B4B20: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000B4B24: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000B4B28: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000B4B2C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4B34: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 0000000B4B38: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000B4B44: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4B48: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000B4B4C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000B4B54: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4B58: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000B4B5C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000B4B64: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000B4B68: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4B70: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000B4B74: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 0000000B4B78: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4B80: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 0000000B4B84: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 0000000B4B88: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4B90: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000B4B94: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000B4B9C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 0000000B4BA4: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4BB0: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000B4BB4: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000B4BBC: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000B4BC8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B4BD0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000B4BD4: BE882000
	s_cbranch_execz 60136                                      // 0000000B4BD8: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x367c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 0000000B4BDC: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 0000000B4BE8: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 0000000B4BEC: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000B4BF4: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000B4BF8: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4BFC: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000B4C00: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000B4C08: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000B4C14: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B4C18: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000B4C1C: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000B4C20: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000B4C28: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B4C30: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000B4C34: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000B4C38: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000B4C3C: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4C40: BF870095
	.long 0xd71c0032                                           // 0000000B4C44: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000B4C48: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000B4C4C: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000B4C50: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4C58: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 0000000B4C5C: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000B4C64: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4C68: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 0000000B4C6C: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 0000000B4C74: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4C78: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 0000000B4C7C: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 0000000B4C84: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 0000000B4C88: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4C90: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 0000000B4C94: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 0000000B4C98: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4CA0: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 0000000B4CA4: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 0000000B4CA8: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4CB0: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 0000000B4CB4: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 0000000B4CBC: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 0000000B4CC4: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4CD0: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 0000000B4CD4: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 0000000B4CDC: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 0000000B4CE8: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B4CF0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000B4CF4: BE882001
	s_cbranch_execz 60067                                      // 0000000B4CF8: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3688>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 0000000B4CFC: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 0000000B4D08: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 0000000B4D0C: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 0000000B4D14: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000B4D18: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B4D1C: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 0000000B4D20: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000B4D28: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 0000000B4D30: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 0000000B4D3C: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B4D40: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 0000000B4D44: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 0000000B4D4C: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B4D50: BF870121
	v_add_f32_e32 v49, v49, v50                                // 0000000B4D54: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 0000000B4D58: 7E641133
	v_exp_f32_e32 v49, v49                                     // 0000000B4D5C: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4D60: BF870095
	.long 0xd71c0031                                           // 0000000B4D64: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 0000000B4D68: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 0000000B4D6C: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000B4D70: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4D78: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 0000000B4D7C: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000B4D84: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4D88: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 0000000B4D8C: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 0000000B4D94: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4D98: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 0000000B4D9C: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 0000000B4DA4: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 0000000B4DA8: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4DB0: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 0000000B4DB4: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 0000000B4DB8: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4DC0: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 0000000B4DC4: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 0000000B4DC8: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4DD0: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 0000000B4DD4: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 0000000B4DDC: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 0000000B4DE4: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4DF0: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 0000000B4DF4: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 0000000B4DFC: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 0000000B4E08: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B4E10: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000B4E14: BE882002
	s_cbranch_execz 59998                                      // 0000000B4E18: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3694>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 0000000B4E1C: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000B4E28: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000B4E30: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000B4E34: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4E38: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000B4E3C: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 0000000B4E44: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 0000000B4E50: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B4E54: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 0000000B4E58: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000B4E5C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 0000000B4E64: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B4E6C: BF870121
	v_add_f32_e32 v42, v42, v49                                // 0000000B4E70: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 0000000B4E74: 7E621132
	v_exp_f32_e32 v42, v42                                     // 0000000B4E78: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4E7C: BF870095
	.long 0xd71c002a                                           // 0000000B4E80: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 0000000B4E84: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000B4E88: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000B4E8C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4E94: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 0000000B4E98: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000B4EA4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4EA8: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000B4EAC: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 0000000B4EB4: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4EB8: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 0000000B4EBC: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 0000000B4EC4: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 0000000B4EC8: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4ED0: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 0000000B4ED4: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 0000000B4ED8: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4EE0: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 0000000B4EE4: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 0000000B4EE8: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4EF0: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 0000000B4EF4: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000B4EFC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 0000000B4F04: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4F10: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 0000000B4F14: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 0000000B4F1C: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000B4F28: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B4F30: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000B4F34: BE882003
	s_cbranch_execz 59929                                      // 0000000B4F38: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36a0>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 0000000B4F3C: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000B4F48: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000B4F50: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000B4F54: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4F58: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000B4F5C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000B4F64: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 0000000B4F70: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4F74: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 0000000B4F78: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 0000000B4F84: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 0000000B4F88: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000B4F8C: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B4F94: BF870293
	v_exp_f32_e32 v42, v42                                     // 0000000B4F98: 7E544B2A
	.long 0xd71c002a                                           // 0000000B4F9C: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000B4FA0: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B4FA4: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000B4FA8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000B4FAC: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 0000000B4FB4: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4FC0: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 0000000B4FC4: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000B4FC8: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B4FD0: BF870291
	v_rcp_f32_e32 v44, v43                                     // 0000000B4FD4: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 0000000B4FD8: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B4FE0: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 0000000B4FE4: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 0000000B4FE8: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 0000000B4FF0: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B4FF4: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 0000000B4FF8: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 0000000B5000: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5004: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 0000000B5008: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 0000000B5010: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B5018: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000B501C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 0000000B5024: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000B5030: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B5038: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000B503C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000B5048: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B5050: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000B5054: BE882004
	s_cbranch_execz 59860                                      // 0000000B5058: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36ac>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 0000000B505C: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000B5068: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000B5070: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000B5074: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5078: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000B507C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000B5084: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000B5090: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B5094: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000B5098: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000B509C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000B50A4: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B50AC: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000B50B0: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000B50B4: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000B50B8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B50BC: BF870095
	.long 0xd71c002a                                           // 0000000B50C0: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000B50C4: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000B50C8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000B50CC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B50D4: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 0000000B50D8: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000B50E4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B50E8: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000B50EC: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000B50F4: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B50F8: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000B50FC: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000B5104: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000B5108: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5110: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 0000000B5114: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 0000000B5118: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5120: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 0000000B5124: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 0000000B5128: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5130: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 0000000B5134: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000B513C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 0000000B5144: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5150: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000B5154: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000B515C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000B5168: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B5170: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000B5174: BE882005
	s_cbranch_execz 59791                                      // 0000000B5178: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36b8>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 0000000B517C: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000B5188: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000B5190: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000B5194: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5198: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000B519C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000B51A4: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000B51B0: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B51B4: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000B51B8: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000B51BC: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000B51C4: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B51CC: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000B51D0: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000B51D4: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000B51D8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B51DC: BF870095
	.long 0xd71c002a                                           // 0000000B51E0: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000B51E4: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000B51E8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000B51EC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B51F4: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000000B51F8: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 0000000B5200: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5208: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000B520C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000B5214: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5218: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000B521C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000B5224: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000B5228: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5230: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000B5234: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 0000000B5238: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5240: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 0000000B5244: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 0000000B5248: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5250: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000B5254: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000B525C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 0000000B5264: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5270: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000B5274: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000B527C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000B5288: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B5290: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000B5294: BE882006
	s_cbranch_execz 59722                                      // 0000000B5298: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36c4>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 0000000B529C: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000B52A8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000B52B0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000B52B4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B52B8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000B52BC: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000B52C4: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000B52D0: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B52D4: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000B52D8: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000B52DC: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000B52E4: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B52EC: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000B52F0: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000B52F4: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000B52F8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B52FC: BF870095
	.long 0xd71c002a                                           // 0000000B5300: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000B5304: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000B5308: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000B530C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5314: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 0000000B5318: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000B5324: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5328: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000B532C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000B5334: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5338: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000B533C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000B5344: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000B5348: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5350: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000B5354: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000000B5358: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5360: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000000B5364: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000000B5368: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5370: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000B5374: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000B537C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 0000000B5384: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5390: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000B5394: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000B539C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000B53A8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B53B0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000B53B4: BE882007
	s_cbranch_execz 59653                                      // 0000000B53B8: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36d0>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 0000000B53BC: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000B53C8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000B53D0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000B53D4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B53D8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000B53DC: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000B53E4: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000B53F0: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B53F4: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000B53F8: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000B53FC: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000B5404: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B540C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000B5410: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000B5414: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000B5418: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B541C: BF870095
	.long 0xd71c002a                                           // 0000000B5420: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000B5424: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000B5428: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000B542C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5434: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 0000000B5438: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000B5444: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5448: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000B544C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000B5454: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5458: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000B545C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000B5464: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000B5468: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5470: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000B5474: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000000B5478: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5480: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000000B5484: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000000B5488: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5490: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000B5494: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000B549C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 0000000B54A4: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B54B0: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000B54B4: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000B54BC: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000B54C8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B54D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000B54D4: BE882000
	s_cbranch_execz 59584                                      // 0000000B54D8: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36dc>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 0000000B54DC: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 0000000B54E8: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 0000000B54EC: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000B54F4: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000B54F8: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B54FC: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000B5500: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000B5508: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000B5514: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B5518: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000B551C: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000B5520: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000B5528: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B5530: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000B5534: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000B5538: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000B553C: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5540: BF870095
	.long 0xd71c002a                                           // 0000000B5544: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000B5548: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000B554C: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000B5550: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5558: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000000B555C: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000B5564: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5568: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 0000000B556C: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 0000000B5574: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5578: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 0000000B557C: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 0000000B5584: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 0000000B5588: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5590: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 0000000B5594: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 0000000B5598: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B55A0: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 0000000B55A4: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 0000000B55A8: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B55B0: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 0000000B55B4: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 0000000B55BC: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 0000000B55C4: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B55D0: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 0000000B55D4: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 0000000B55DC: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 0000000B55E8: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B55F0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000B55F4: BE882001
	s_cbranch_execz 59515                                      // 0000000B55F8: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36e8>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 0000000B55FC: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 0000000B5608: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 0000000B560C: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 0000000B5614: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000B5618: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B561C: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 0000000B5620: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000B5628: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 0000000B5630: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 0000000B563C: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B5640: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 0000000B5644: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 0000000B564C: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B5650: BF870121
	v_add_f32_e32 v41, v41, v42                                // 0000000B5654: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 0000000B5658: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 0000000B565C: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5660: BF870095
	.long 0xd71c0029                                           // 0000000B5664: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000000B5668: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000000B566C: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000B5670: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5678: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 0000000B567C: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000B5684: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5688: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 0000000B568C: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 0000000B5694: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5698: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 0000000B569C: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 0000000B56A4: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 0000000B56A8: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B56B0: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 0000000B56B4: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 0000000B56B8: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B56C0: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 0000000B56C4: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 0000000B56C8: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B56D0: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 0000000B56D4: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 0000000B56DC: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 0000000B56E4: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B56F0: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 0000000B56F4: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 0000000B56FC: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 0000000B5708: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B5710: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000B5714: BE882002
	s_cbranch_execz 59446                                      // 0000000B5718: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36f4>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 0000000B571C: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000B5728: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000B5730: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000B5734: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5738: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000B573C: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 0000000B5744: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 0000000B5750: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B5754: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 0000000B5758: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000B575C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 0000000B5764: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B576C: BF870121
	v_add_f32_e32 v34, v34, v41                                // 0000000B5770: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 0000000B5774: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 0000000B5778: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B577C: BF870095
	.long 0xd71c0022                                           // 0000000B5780: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 0000000B5784: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000B5788: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000B578C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5794: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 0000000B5798: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000B57A4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B57A8: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000B57AC: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 0000000B57B4: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B57B8: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 0000000B57BC: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 0000000B57C4: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 0000000B57C8: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B57D0: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 0000000B57D4: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 0000000B57D8: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B57E0: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 0000000B57E4: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 0000000B57E8: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B57F0: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 0000000B57F4: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000B57FC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 0000000B5804: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5810: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 0000000B5814: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 0000000B581C: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000B5828: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B5830: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000B5834: BE882003
	s_cbranch_execz 59377                                      // 0000000B5838: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3700>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 0000000B583C: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000B5848: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000B5850: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000B5854: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5858: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000B585C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000B5864: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 0000000B5870: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5874: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 0000000B5878: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 0000000B5884: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 0000000B5888: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000B588C: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B5894: BF870293
	v_exp_f32_e32 v34, v34                                     // 0000000B5898: 7E444B22
	.long 0xd71c0022                                           // 0000000B589C: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000B58A0: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B58A4: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000B58A8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000B58AC: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 0000000B58B4: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B58C0: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 0000000B58C4: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000B58C8: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B58D0: BF870291
	v_rcp_f32_e32 v36, v35                                     // 0000000B58D4: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 0000000B58D8: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B58E0: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 0000000B58E4: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 0000000B58E8: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 0000000B58F0: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B58F4: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 0000000B58F8: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 0000000B5900: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5904: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 0000000B5908: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 0000000B5910: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B5918: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000B591C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 0000000B5924: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000B5930: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B5938: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000B593C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000B5948: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B5950: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000B5954: BE882004
	s_cbranch_execz 59308                                      // 0000000B5958: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x370c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 0000000B595C: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000B5968: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000B5970: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000B5974: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5978: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000B597C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000B5984: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000B5990: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B5994: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000B5998: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000B599C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000B59A4: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B59AC: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000B59B0: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000B59B4: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000B59B8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B59BC: BF870095
	.long 0xd71c0022                                           // 0000000B59C0: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000B59C4: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000B59C8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000B59CC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B59D4: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 0000000B59D8: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000B59E4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B59E8: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000B59EC: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000B59F4: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B59F8: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000B59FC: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000B5A04: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000B5A08: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5A10: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 0000000B5A14: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 0000000B5A18: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5A20: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 0000000B5A24: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 0000000B5A28: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5A30: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 0000000B5A34: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000B5A3C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 0000000B5A44: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5A50: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000B5A54: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000B5A5C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000B5A68: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B5A70: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000B5A74: BE882005
	s_cbranch_execz 59239                                      // 0000000B5A78: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3718>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 0000000B5A7C: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000B5A88: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000B5A90: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000B5A94: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5A98: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000B5A9C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000B5AA4: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000B5AB0: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B5AB4: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000B5AB8: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000B5ABC: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000B5AC4: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B5ACC: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000B5AD0: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000B5AD4: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000B5AD8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5ADC: BF870095
	.long 0xd71c0022                                           // 0000000B5AE0: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000B5AE4: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000B5AE8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000B5AEC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5AF4: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000000B5AF8: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 0000000B5B00: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5B08: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000B5B0C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000B5B14: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5B18: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000B5B1C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000B5B24: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000B5B28: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5B30: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000B5B34: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 0000000B5B38: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5B40: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 0000000B5B44: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 0000000B5B48: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5B50: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000B5B54: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000B5B5C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 0000000B5B64: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5B70: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000B5B74: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000B5B7C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000B5B88: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B5B90: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000B5B94: BE882006
	s_cbranch_execz 59170                                      // 0000000B5B98: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3724>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 0000000B5B9C: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000B5BA8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000B5BB0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000B5BB4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5BB8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000B5BBC: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000B5BC4: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000B5BD0: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B5BD4: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000B5BD8: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000B5BDC: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000B5BE4: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B5BEC: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000B5BF0: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000B5BF4: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000B5BF8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5BFC: BF870095
	.long 0xd71c0022                                           // 0000000B5C00: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000B5C04: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000B5C08: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000B5C0C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5C14: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 0000000B5C18: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000B5C24: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5C28: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000B5C2C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000B5C34: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5C38: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000B5C3C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000B5C44: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000B5C48: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5C50: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000B5C54: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 0000000B5C58: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5C60: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 0000000B5C64: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 0000000B5C68: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5C70: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000B5C74: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000B5C7C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 0000000B5C84: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5C90: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000B5C94: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000B5C9C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000B5CA8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B5CB0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000B5CB4: BE882007
	s_cbranch_execz 59101                                      // 0000000B5CB8: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3730>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 0000000B5CBC: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000B5CC8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000B5CD0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000B5CD4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5CD8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000B5CDC: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000B5CE4: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000B5CF0: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B5CF4: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000B5CF8: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000B5CFC: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000B5D04: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B5D0C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000B5D10: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000B5D14: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000B5D18: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5D1C: BF870095
	.long 0xd71c0022                                           // 0000000B5D20: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000B5D24: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000B5D28: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000B5D2C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5D34: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 0000000B5D38: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000B5D44: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5D48: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000B5D4C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000B5D54: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5D58: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000B5D5C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000B5D64: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000B5D68: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5D70: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000B5D74: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 0000000B5D78: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5D80: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 0000000B5D84: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 0000000B5D88: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5D90: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000B5D94: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000B5D9C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 0000000B5DA4: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5DB0: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000B5DB4: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000B5DBC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000B5DC8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B5DD0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000B5DD4: BE882000
	s_cbranch_execz 59032                                      // 0000000B5DD8: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x373c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 0000000B5DDC: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 0000000B5DE8: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 0000000B5DEC: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000B5DF4: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000B5DF8: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5DFC: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000B5E00: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000B5E08: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000B5E14: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B5E18: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000B5E1C: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000B5E20: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000B5E28: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B5E30: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000B5E34: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000B5E38: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000B5E3C: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5E40: BF870095
	.long 0xd71c0022                                           // 0000000B5E44: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000B5E48: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000B5E4C: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000B5E50: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5E58: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000000B5E5C: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000B5E64: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5E68: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 0000000B5E6C: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 0000000B5E74: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5E78: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000000B5E7C: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 0000000B5E84: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 0000000B5E88: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5E90: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 0000000B5E94: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 0000000B5E98: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5EA0: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 0000000B5EA4: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 0000000B5EA8: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5EB0: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 0000000B5EB4: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 0000000B5EBC: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 0000000B5EC4: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5ED0: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 0000000B5ED4: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 0000000B5EDC: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 0000000B5EE8: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B5EF0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000B5EF4: BE882001
	s_cbranch_execz 58963                                      // 0000000B5EF8: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3748>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 0000000B5EFC: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 0000000B5F08: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 0000000B5F0C: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 0000000B5F14: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000B5F18: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B5F1C: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 0000000B5F20: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000B5F28: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 0000000B5F30: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 0000000B5F3C: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B5F40: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 0000000B5F44: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 0000000B5F4C: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B5F50: BF870121
	v_add_f32_e32 v33, v33, v34                                // 0000000B5F54: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 0000000B5F58: 7E441123
	v_exp_f32_e32 v33, v33                                     // 0000000B5F5C: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5F60: BF870095
	.long 0xd71c0021                                           // 0000000B5F64: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000000B5F68: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000000B5F6C: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000B5F70: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5F78: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 0000000B5F7C: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000B5F84: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5F88: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 0000000B5F8C: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 0000000B5F94: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5F98: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 0000000B5F9C: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 0000000B5FA4: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 0000000B5FA8: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5FB0: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 0000000B5FB4: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 0000000B5FB8: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5FC0: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 0000000B5FC4: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 0000000B5FC8: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5FD0: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 0000000B5FD4: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 0000000B5FDC: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 0000000B5FE4: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B5FF0: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 0000000B5FF4: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 0000000B5FFC: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 0000000B6008: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B6010: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000B6014: BE882002
	s_cbranch_execz 58894                                      // 0000000B6018: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3754>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 0000000B601C: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000B6028: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000B6030: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000B6034: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6038: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000B603C: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 0000000B6044: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 0000000B6050: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B6054: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 0000000B6058: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000B605C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 0000000B6064: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B606C: BF870121
	v_add_f32_e32 v26, v26, v33                                // 0000000B6070: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000B6074: 7E421122
	v_exp_f32_e32 v26, v26                                     // 0000000B6078: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B607C: BF870095
	.long 0xd71c001a                                           // 0000000B6080: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 0000000B6084: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000B6088: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000B608C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6094: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 0000000B6098: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000B60A4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B60A8: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000B60AC: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 0000000B60B4: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B60B8: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 0000000B60BC: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 0000000B60C4: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 0000000B60C8: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B60D0: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 0000000B60D4: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 0000000B60D8: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B60E0: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 0000000B60E4: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 0000000B60E8: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B60F0: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 0000000B60F4: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000B60FC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 0000000B6104: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6110: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 0000000B6114: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 0000000B611C: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000B6128: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B6130: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000B6134: BE882003
	s_cbranch_execz 58825                                      // 0000000B6138: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3760>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 0000000B613C: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000B6148: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000B6150: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000B6154: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6158: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000B615C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000B6164: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 0000000B6170: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6174: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 0000000B6178: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 0000000B6184: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 0000000B6188: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000B618C: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B6194: BF870293
	v_exp_f32_e32 v26, v26                                     // 0000000B6198: 7E344B1A
	.long 0xd71c001a                                           // 0000000B619C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000B61A0: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B61A4: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000B61A8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000B61AC: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 0000000B61B4: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B61C0: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 0000000B61C4: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000B61C8: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B61D0: BF870291
	v_rcp_f32_e32 v28, v27                                     // 0000000B61D4: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 0000000B61D8: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B61E0: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 0000000B61E4: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 0000000B61E8: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 0000000B61F0: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B61F4: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 0000000B61F8: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 0000000B6200: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6204: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 0000000B6208: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 0000000B6210: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B6218: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000B621C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 0000000B6224: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000B6230: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B6238: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000B623C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000B6248: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B6250: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000B6254: BE882004
	s_cbranch_execz 58756                                      // 0000000B6258: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x376c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 0000000B625C: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000B6268: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000B6270: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000B6274: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6278: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000B627C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000B6284: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000B6290: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B6294: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000B6298: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000B629C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000B62A4: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B62AC: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000B62B0: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000B62B4: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000B62B8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B62BC: BF870095
	.long 0xd71c001a                                           // 0000000B62C0: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000B62C4: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000B62C8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000B62CC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B62D4: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 0000000B62D8: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000B62E4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B62E8: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000B62EC: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000B62F4: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B62F8: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000B62FC: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000B6304: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000B6308: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6310: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 0000000B6314: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 0000000B6318: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6320: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 0000000B6324: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 0000000B6328: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6330: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 0000000B6334: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000B633C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 0000000B6344: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6350: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000B6354: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000B635C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000B6368: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B6370: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000B6374: BE882005
	s_cbranch_execz 58687                                      // 0000000B6378: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3778>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 0000000B637C: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000B6388: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000B6390: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000B6394: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6398: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000B639C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000B63A4: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000B63B0: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B63B4: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000B63B8: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000B63BC: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000B63C4: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B63CC: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000B63D0: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000B63D4: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000B63D8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B63DC: BF870095
	.long 0xd71c001a                                           // 0000000B63E0: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000B63E4: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000B63E8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000B63EC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B63F4: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 0000000B63F8: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 0000000B6400: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6408: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000B640C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000B6414: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6418: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000B641C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000B6424: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000B6428: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6430: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000B6434: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 0000000B6438: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6440: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 0000000B6444: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 0000000B6448: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6450: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000B6454: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000B645C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 0000000B6464: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6470: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000B6474: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000B647C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000B6488: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B6490: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000B6494: BE882006
	s_cbranch_execz 58618                                      // 0000000B6498: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3784>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 0000000B649C: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000B64A8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000B64B0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000B64B4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B64B8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000B64BC: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000B64C4: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000B64D0: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B64D4: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000B64D8: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000B64DC: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000B64E4: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B64EC: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000B64F0: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000B64F4: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000B64F8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B64FC: BF870095
	.long 0xd71c001a                                           // 0000000B6500: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000B6504: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000B6508: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000B650C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6514: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 0000000B6518: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000B6524: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6528: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000B652C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000B6534: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6538: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000B653C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000B6544: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000B6548: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6550: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000B6554: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000000B6558: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6560: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000000B6564: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000000B6568: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6570: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000B6574: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000B657C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 0000000B6584: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6590: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000B6594: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000B659C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000B65A8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B65B0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000B65B4: BE882007
	s_cbranch_execz 58549                                      // 0000000B65B8: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3790>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 0000000B65BC: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000B65C8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000B65D0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000B65D4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B65D8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000B65DC: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000B65E4: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000B65F0: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B65F4: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000B65F8: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000B65FC: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000B6604: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B660C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000B6610: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000B6614: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000B6618: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B661C: BF870095
	.long 0xd71c001a                                           // 0000000B6620: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000B6624: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000B6628: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000B662C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6634: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 0000000B6638: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000B6644: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6648: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000B664C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000B6654: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6658: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000B665C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000B6664: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000B6668: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6670: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000B6674: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000000B6678: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6680: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000000B6684: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000000B6688: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6690: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000B6694: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000B669C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 0000000B66A4: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B66B0: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000B66B4: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000B66BC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000B66C8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B66D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000B66D4: BE882000
	s_cbranch_execz 58480                                      // 0000000B66D8: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x379c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 0000000B66DC: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 0000000B66E8: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 0000000B66EC: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000B66F4: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000B66F8: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B66FC: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000B6700: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000B6708: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000B6714: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B6718: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000B671C: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000B6720: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000B6728: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B6730: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000B6734: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000B6738: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000B673C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6740: BF870095
	.long 0xd71c001a                                           // 0000000B6744: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000B6748: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000B674C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000B6750: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6758: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 0000000B675C: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000B6764: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6768: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 0000000B676C: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 0000000B6774: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6778: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 0000000B677C: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 0000000B6784: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 0000000B6788: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6790: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 0000000B6794: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 0000000B6798: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B67A0: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 0000000B67A4: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 0000000B67A8: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B67B0: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 0000000B67B4: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 0000000B67BC: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 0000000B67C4: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B67D0: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 0000000B67D4: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 0000000B67DC: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 0000000B67E8: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B67F0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000B67F4: BE882001
	s_cbranch_execz 58411                                      // 0000000B67F8: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37a8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 0000000B67FC: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 0000000B6808: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 0000000B680C: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 0000000B6814: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000B6818: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B681C: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 0000000B6820: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000B6828: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 0000000B6830: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 0000000B683C: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B6840: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 0000000B6844: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 0000000B684C: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B6850: BF870121
	v_add_f32_e32 v25, v25, v26                                // 0000000B6854: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 0000000B6858: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 0000000B685C: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6860: BF870095
	.long 0xd71c0019                                           // 0000000B6864: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000000B6868: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000000B686C: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000B6870: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6878: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 0000000B687C: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000B6884: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6888: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 0000000B688C: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 0000000B6894: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6898: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 0000000B689C: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 0000000B68A4: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 0000000B68A8: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B68B0: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 0000000B68B4: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 0000000B68B8: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B68C0: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 0000000B68C4: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 0000000B68C8: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B68D0: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 0000000B68D4: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 0000000B68DC: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 0000000B68E4: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B68F0: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 0000000B68F4: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 0000000B68FC: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 0000000B6908: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B6910: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000B6914: BE882002
	s_cbranch_execz 58342                                      // 0000000B6918: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37b4>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 0000000B691C: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000B6928: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000B6930: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000B6934: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6938: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000B693C: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 0000000B6944: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 0000000B6950: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B6954: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 0000000B6958: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000B695C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 0000000B6964: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B696C: BF870121
	v_add_f32_e32 v18, v18, v25                                // 0000000B6970: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 0000000B6974: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 0000000B6978: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B697C: BF870095
	.long 0xd71c0012                                           // 0000000B6980: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 0000000B6984: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000B6988: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000B698C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6994: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 0000000B6998: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000B69A4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B69A8: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000B69AC: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 0000000B69B4: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B69B8: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 0000000B69BC: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 0000000B69C4: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 0000000B69C8: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B69D0: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 0000000B69D4: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 0000000B69D8: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B69E0: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 0000000B69E4: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 0000000B69E8: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B69F0: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 0000000B69F4: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000B69FC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 0000000B6A04: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6A10: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 0000000B6A14: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 0000000B6A1C: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000B6A28: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B6A30: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000B6A34: BE882003
	s_cbranch_execz 58273                                      // 0000000B6A38: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37c0>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 0000000B6A3C: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000B6A48: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000B6A50: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000B6A54: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6A58: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000B6A5C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000B6A64: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 0000000B6A70: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6A74: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 0000000B6A78: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 0000000B6A84: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 0000000B6A88: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000B6A8C: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B6A94: BF870293
	v_exp_f32_e32 v18, v18                                     // 0000000B6A98: 7E244B12
	.long 0xd71c0012                                           // 0000000B6A9C: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000B6AA0: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B6AA4: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000B6AA8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000B6AAC: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 0000000B6AB4: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6AC0: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 0000000B6AC4: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000B6AC8: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B6AD0: BF870291
	v_rcp_f32_e32 v20, v19                                     // 0000000B6AD4: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 0000000B6AD8: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B6AE0: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 0000000B6AE4: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 0000000B6AE8: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 0000000B6AF0: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6AF4: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 0000000B6AF8: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 0000000B6B00: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6B04: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 0000000B6B08: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 0000000B6B10: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B6B18: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000B6B1C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 0000000B6B24: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000B6B30: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B6B38: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000B6B3C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000B6B48: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B6B50: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000B6B54: BE882004
	s_cbranch_execz 58204                                      // 0000000B6B58: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37cc>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 0000000B6B5C: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000B6B68: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000B6B70: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000B6B74: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6B78: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000B6B7C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000B6B84: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000B6B90: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B6B94: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000B6B98: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000B6B9C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000B6BA4: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B6BAC: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000B6BB0: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000B6BB4: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000B6BB8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6BBC: BF870095
	.long 0xd71c0012                                           // 0000000B6BC0: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000B6BC4: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000B6BC8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000B6BCC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6BD4: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 0000000B6BD8: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000B6BE4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6BE8: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000B6BEC: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000B6BF4: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6BF8: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000B6BFC: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000B6C04: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000B6C08: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6C10: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 0000000B6C14: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 0000000B6C18: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6C20: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 0000000B6C24: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 0000000B6C28: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6C30: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 0000000B6C34: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000B6C3C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 0000000B6C44: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6C50: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000B6C54: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000B6C5C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000B6C68: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B6C70: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000B6C74: BE882005
	s_cbranch_execz 58135                                      // 0000000B6C78: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37d8>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 0000000B6C7C: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000B6C88: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000B6C90: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000B6C94: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6C98: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000B6C9C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000B6CA4: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000B6CB0: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B6CB4: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000B6CB8: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000B6CBC: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000B6CC4: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B6CCC: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000B6CD0: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000B6CD4: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000B6CD8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6CDC: BF870095
	.long 0xd71c0012                                           // 0000000B6CE0: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000B6CE4: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000B6CE8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000B6CEC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6CF4: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000000B6CF8: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 0000000B6D00: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6D08: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000B6D0C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000B6D14: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6D18: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000B6D1C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000B6D24: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000B6D28: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6D30: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000B6D34: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 0000000B6D38: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6D40: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 0000000B6D44: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 0000000B6D48: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6D50: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000B6D54: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000B6D5C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 0000000B6D64: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6D70: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000B6D74: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000B6D7C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000B6D88: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B6D90: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000B6D94: BE882006
	s_cbranch_execz 58066                                      // 0000000B6D98: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37e4>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 0000000B6D9C: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000B6DA8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000B6DB0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000B6DB4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6DB8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000B6DBC: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000B6DC4: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000B6DD0: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B6DD4: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000B6DD8: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000B6DDC: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000B6DE4: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B6DEC: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000B6DF0: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000B6DF4: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000B6DF8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6DFC: BF870095
	.long 0xd71c0012                                           // 0000000B6E00: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000B6E04: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000B6E08: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000B6E0C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6E14: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 0000000B6E18: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000B6E24: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6E28: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000B6E2C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000B6E34: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6E38: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000B6E3C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000B6E44: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000B6E48: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6E50: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000B6E54: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000000B6E58: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6E60: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000000B6E64: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000B6E68: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6E70: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000B6E74: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000B6E7C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 0000000B6E84: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6E90: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000B6E94: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000B6E9C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000B6EA8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B6EB0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000B6EB4: BE882007
	s_cbranch_execz 57997                                      // 0000000B6EB8: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37f0>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 0000000B6EBC: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000B6EC8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000B6ED0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000B6ED4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6ED8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000B6EDC: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000B6EE4: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000B6EF0: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B6EF4: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000B6EF8: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000B6EFC: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000B6F04: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B6F0C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000B6F10: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000B6F14: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000B6F18: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6F1C: BF870095
	.long 0xd71c0012                                           // 0000000B6F20: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000B6F24: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000B6F28: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000B6F2C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6F34: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 0000000B6F38: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000B6F44: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6F48: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000B6F4C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000B6F54: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6F58: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000B6F5C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000B6F64: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000B6F68: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6F70: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000B6F74: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000000B6F78: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6F80: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000000B6F84: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000B6F88: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6F90: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000B6F94: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000B6F9C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 0000000B6FA4: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6FB0: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000B6FB4: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000B6FBC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000B6FC8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B6FD0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000B6FD4: BE882000
	s_cbranch_execz 57928                                      // 0000000B6FD8: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37fc>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 0000000B6FDC: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 0000000B6FE8: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 0000000B6FEC: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000B6FF4: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000B6FF8: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6FFC: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000B7000: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000B7008: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000B7014: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B7018: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000B701C: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000B7020: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000B7028: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B7030: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000B7034: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000B7038: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000B703C: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7040: BF870095
	.long 0xd71c0012                                           // 0000000B7044: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000B7048: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000B704C: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000B7050: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7058: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000000B705C: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000B7064: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7068: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 0000000B706C: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 0000000B7074: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7078: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 0000000B707C: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 0000000B7084: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 0000000B7088: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7090: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 0000000B7094: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 0000000B7098: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B70A0: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 0000000B70A4: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 0000000B70A8: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B70B0: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 0000000B70B4: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 0000000B70BC: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 0000000B70C4: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B70D0: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 0000000B70D4: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 0000000B70DC: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 0000000B70E8: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B70F0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000B70F4: BE882001
	s_cbranch_execz 57859                                      // 0000000B70F8: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3808>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 0000000B70FC: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 0000000B7108: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 0000000B710C: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 0000000B7114: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000B7118: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B711C: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 0000000B7120: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000B7128: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 0000000B7130: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 0000000B713C: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B7140: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 0000000B7144: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 0000000B714C: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B7150: BF870121
	v_add_f32_e32 v17, v17, v18                                // 0000000B7154: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 0000000B7158: 7E241113
	v_exp_f32_e32 v17, v17                                     // 0000000B715C: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7160: BF870095
	.long 0xd71c0011                                           // 0000000B7164: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000000B7168: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000000B716C: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000B7170: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7178: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 0000000B717C: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000B7184: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7188: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 0000000B718C: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 0000000B7194: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7198: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 0000000B719C: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 0000000B71A4: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 0000000B71A8: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B71B0: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 0000000B71B4: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 0000000B71B8: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B71C0: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 0000000B71C4: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 0000000B71C8: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B71D0: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 0000000B71D4: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 0000000B71DC: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 0000000B71E4: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B71F0: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 0000000B71F4: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 0000000B71FC: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 0000000B7208: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B7210: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000B7214: BE882002
	s_cbranch_execz 57790                                      // 0000000B7218: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3814>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 0000000B721C: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000B7228: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000B7230: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000B7234: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7238: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000B723C: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 0000000B7244: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 0000000B7250: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B7254: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 0000000B7258: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000B725C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 0000000B7264: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B726C: BF870121
	v_add_f32_e32 v10, v10, v17                                // 0000000B7270: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 0000000B7274: 7E221112
	v_exp_f32_e32 v10, v10                                     // 0000000B7278: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B727C: BF870095
	.long 0xd71c000a                                           // 0000000B7280: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 0000000B7284: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000B7288: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000B728C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7294: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 0000000B7298: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000B72A4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B72A8: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000B72AC: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 0000000B72B4: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B72B8: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 0000000B72BC: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 0000000B72C4: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 0000000B72C8: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B72D0: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 0000000B72D4: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 0000000B72D8: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B72E0: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 0000000B72E4: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 0000000B72E8: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B72F0: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 0000000B72F4: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000B72FC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 0000000B7304: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7310: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 0000000B7314: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 0000000B731C: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000B7328: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B7330: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000B7334: BE882003
	s_cbranch_execz 57721                                      // 0000000B7338: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3820>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 0000000B733C: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000B7348: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000B7350: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000B7354: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7358: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000B735C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000B7364: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 0000000B7370: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7374: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 0000000B7378: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 0000000B7384: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 0000000B7388: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000B738C: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B7394: BF870293
	v_exp_f32_e32 v10, v10                                     // 0000000B7398: 7E144B0A
	.long 0xd71c000a                                           // 0000000B739C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000B73A0: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B73A4: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000B73A8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000B73AC: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 0000000B73B4: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B73C0: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000B73C4: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000B73C8: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000B73D0: BF870291
	v_rcp_f32_e32 v12, v11                                     // 0000000B73D4: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 0000000B73D8: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B73E0: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 0000000B73E4: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 0000000B73E8: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 0000000B73F0: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B73F4: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 0000000B73F8: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 0000000B7400: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7404: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 0000000B7408: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 0000000B7410: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B7418: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000B741C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 0000000B7424: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000B7430: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B7438: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000B743C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000B7448: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B7450: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000B7454: BE882004
	s_cbranch_execz 57652                                      // 0000000B7458: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x382c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 0000000B745C: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000B7468: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000B7470: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000B7474: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7478: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000B747C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000B7484: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000B7490: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B7494: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000B7498: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000B749C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000B74A4: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B74AC: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000B74B0: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000B74B4: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000B74B8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B74BC: BF870095
	.long 0xd71c000a                                           // 0000000B74C0: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000B74C4: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000B74C8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000B74CC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B74D4: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 0000000B74D8: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000B74E4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B74E8: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000B74EC: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000B74F4: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B74F8: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000B74FC: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000B7504: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000B7508: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7510: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 0000000B7514: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 0000000B7518: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7520: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 0000000B7524: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 0000000B7528: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7530: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 0000000B7534: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000B753C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 0000000B7544: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7550: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000B7554: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000B755C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000B7568: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B7570: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000B7574: BE882005
	s_cbranch_execz 57583                                      // 0000000B7578: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3838>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 0000000B757C: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000B7588: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000B7590: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000B7594: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7598: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000B759C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000B75A4: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000B75B0: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B75B4: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000B75B8: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000B75BC: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000B75C4: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B75CC: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000B75D0: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000B75D4: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000B75D8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B75DC: BF870095
	.long 0xd71c000a                                           // 0000000B75E0: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000B75E4: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000B75E8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000B75EC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B75F4: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 0000000B75F8: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 0000000B7600: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7608: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000B760C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000B7614: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7618: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000B761C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000B7624: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000B7628: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7630: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000B7634: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 0000000B7638: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7640: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 0000000B7644: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 0000000B7648: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7650: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000B7654: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000B765C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 0000000B7664: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7670: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000B7674: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000B767C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000B7688: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B7690: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000B7694: BE882006
	s_cbranch_execz 57514                                      // 0000000B7698: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3844>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 0000000B769C: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000B76A8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000B76B0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000B76B4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B76B8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000B76BC: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000B76C4: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000B76D0: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B76D4: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000B76D8: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000B76DC: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000B76E4: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B76EC: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000B76F0: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000B76F4: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000B76F8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B76FC: BF870095
	.long 0xd71c000a                                           // 0000000B7700: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000B7704: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000B7708: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000B770C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7714: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 0000000B7718: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000B7724: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7728: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000B772C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000B7734: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7738: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000B773C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000B7744: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000B7748: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7750: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000B7754: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 0000000B7758: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7760: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000000B7764: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 0000000B7768: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7770: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000B7774: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000B777C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 0000000B7784: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7790: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000B7794: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000B779C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000B77A8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B77B0: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000B77B4: BE882007
	s_cbranch_execz 57445                                      // 0000000B77B8: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3850>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 0000000B77BC: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000B77C8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000B77D0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000B77D4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B77D8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000B77DC: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000B77E4: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000B77F0: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B77F4: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000B77F8: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000B77FC: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000B7804: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B780C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000B7810: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000B7814: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000B7818: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B781C: BF870095
	.long 0xd71c000a                                           // 0000000B7820: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000B7824: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000B7828: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000B782C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7834: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 0000000B7838: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000B7844: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7848: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000B784C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000B7854: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7858: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000B785C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000B7864: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000B7868: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7870: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000B7874: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 0000000B7878: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7880: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000000B7884: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 0000000B7888: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7890: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000B7894: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000B789C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 0000000B78A4: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B78B0: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000B78B4: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000B78BC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000B78C8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B78D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000B78D4: BE882000
	s_cbranch_execz 57376                                      // 0000000B78D8: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x385c>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 0000000B78DC: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 0000000B78E8: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 0000000B78EC: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000B78F4: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000B78F8: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B78FC: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000B7900: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000B7908: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000B7914: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B7918: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000B791C: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000B7920: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000B7928: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B7930: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000B7934: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000B7938: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000B793C: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7940: BF870095
	.long 0xd71c000a                                           // 0000000B7944: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000B7948: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000B794C: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000B7950: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7958: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 0000000B795C: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000B7964: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7968: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 0000000B796C: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 0000000B7974: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7978: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 0000000B797C: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 0000000B7984: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 0000000B7988: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7990: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 0000000B7994: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 0000000B7998: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B79A0: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 0000000B79A4: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 0000000B79A8: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B79B0: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 0000000B79B4: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 0000000B79BC: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 0000000B79C4: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B79D0: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 0000000B79D4: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000000B79DC: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 0000000B79E8: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000B79F0: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 0000000B79F4: BE802001
	s_cbranch_execz 57307                                      // 0000000B79F8: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3868>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 0000000B79FC: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000B7A08: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000B7A10: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000B7A14: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7A18: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000B7A1C: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 0000000B7A24: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 0000000B7A30: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B7A34: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 0000000B7A38: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 0000000B7A3C: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000B7A44: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B7A4C: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 0000000B7A50: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 0000000B7A54: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 0000000B7A58: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7A5C: BF870095
	.long 0xd71c0001                                           // 0000000B7A60: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 0000000B7A64: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000B7A68: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000B7A6C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7A74: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 0000000B7A78: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000B7A84: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7A88: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000B7A8C: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 0000000B7A94: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7A98: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 0000000B7A9C: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 0000000B7AA4: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 0000000B7AA8: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7AB0: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 0000000B7AB4: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 0000000B7AB8: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7AC0: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 0000000B7AC4: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 0000000B7AC8: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7AD0: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 0000000B7AD4: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000B7ADC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 0000000B7AE4: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7AF0: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 0000000B7AF4: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 0000000B7AFC: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000B7B08: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000B7B10: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 0000000B7B14: BE802002
	s_cbranch_execz 57238                                      // 0000000B7B18: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3874>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 0000000B7B1C: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000B7B28: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000B7B30: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000B7B34: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7B38: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000B7B3C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000B7B44: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 0000000B7B50: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B7B54: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 0000000B7B58: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000B7B5C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000B7B64: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B7B6C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000B7B70: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 0000000B7B74: 7E041109
	v_exp_f32_e32 v1, v1                                       // 0000000B7B78: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7B7C: BF870095
	.long 0xd71c0001                                           // 0000000B7B80: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000B7B84: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000B7B88: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000B7B8C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7B94: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 0000000B7B98: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000B7BA4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7BA8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000B7BAC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000B7BB4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7BB8: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 0000000B7BBC: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 0000000B7BC4: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 0000000B7BC8: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7BD0: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 0000000B7BD4: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 0000000B7BD8: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7BE0: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 0000000B7BE4: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 0000000B7BE8: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7BF0: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 0000000B7BF4: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000B7BFC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 0000000B7C04: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7C10: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000B7C14: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000B7C1C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000B7C28: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000B7C30: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 0000000B7C34: BE802003
	s_cbranch_execz 57169                                      // 0000000B7C38: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3880>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 0000000B7C3C: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000B7C48: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000B7C50: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000B7C54: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7C58: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000B7C5C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000B7C64: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000B7C70: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B7C74: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000B7C78: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000B7C7C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000B7C84: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B7C8C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000B7C90: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000B7C94: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000B7C98: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7C9C: BF870095
	.long 0xd71c0001                                           // 0000000B7CA0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000B7CA4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000B7CA8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000B7CAC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7CB4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 0000000B7CB8: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000B7CC4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7CC8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000B7CCC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000B7CD4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7CD8: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000B7CDC: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000B7CE4: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000B7CE8: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7CF0: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 0000000B7CF4: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 0000000B7CF8: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7D00: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 0000000B7D04: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 0000000B7D08: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7D10: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 0000000B7D14: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000B7D1C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 0000000B7D24: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7D30: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000B7D34: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000B7D3C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000B7D48: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000B7D50: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000000B7D54: BE802004
	s_cbranch_execz 57100                                      // 0000000B7D58: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x388c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 0000000B7D5C: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000B7D68: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000B7D70: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000B7D74: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7D78: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000B7D7C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000B7D84: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000B7D90: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B7D94: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000B7D98: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000B7D9C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000B7DA4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B7DAC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000B7DB0: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000B7DB4: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000B7DB8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7DBC: BF870095
	.long 0xd71c0001                                           // 0000000B7DC0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000B7DC4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000B7DC8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000B7DCC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7DD4: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 0000000B7DD8: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 0000000B7DE0: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7DE8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000B7DEC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000B7DF4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7DF8: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000B7DFC: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000B7E04: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000B7E08: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7E10: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000B7E14: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 0000000B7E18: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7E20: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 0000000B7E24: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000B7E28: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7E30: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000B7E34: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000B7E3C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 0000000B7E44: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7E50: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000B7E54: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000B7E5C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000B7E68: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000B7E70: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000000B7E74: BE802005
	s_cbranch_execz 57031                                      // 0000000B7E78: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3898>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 0000000B7E7C: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000B7E88: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000B7E90: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000B7E94: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7E98: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000B7E9C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000B7EA4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000B7EB0: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B7EB4: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000B7EB8: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000B7EBC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000B7EC4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B7ECC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000B7ED0: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000B7ED4: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000B7ED8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7EDC: BF870095
	.long 0xd71c0001                                           // 0000000B7EE0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000B7EE4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000B7EE8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000B7EEC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7EF4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 0000000B7EF8: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000B7F04: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7F08: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000B7F0C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000B7F14: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7F18: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000B7F1C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000B7F24: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000B7F28: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7F30: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000B7F34: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000B7F38: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7F40: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000B7F44: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000B7F48: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7F50: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000B7F54: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000B7F5C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 0000000B7F64: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7F70: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000B7F74: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000B7F7C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000B7F88: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000B7F90: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000000B7F94: BE802006
	s_cbranch_execz 56962                                      // 0000000B7F98: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38a4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 0000000B7F9C: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000B7FA8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000B7FB0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000B7FB4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7FB8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000B7FBC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000B7FC4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000B7FD0: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B7FD4: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000B7FD8: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000B7FDC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000B7FE4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B7FEC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000B7FF0: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000B7FF4: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000B7FF8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7FFC: BF870095
	.long 0xd71c0001                                           // 0000000B8000: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000B8004: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000B8008: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000B800C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8014: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 0000000B8018: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000B8024: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8028: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000B802C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000B8034: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8038: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000B803C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000B8044: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000B8048: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8050: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000B8054: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000B8058: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8060: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000B8064: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000B8068: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8070: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000B8074: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000B807C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 0000000B8084: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8090: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000B8094: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000B809C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000B80A8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000B80B0: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000000B80B4: BE802007
	s_cbranch_execz 56893                                      // 0000000B80B8: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38b0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 0000000B80BC: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000B80C8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000B80D0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000B80D4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B80D8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000B80DC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000B80E4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000B80F0: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000B80F4: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000B80F8: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000B80FC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000B8104: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B810C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000B8110: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000B8114: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000B8118: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B811C: BF870095
	.long 0xd71c0001                                           // 0000000B8120: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000B8124: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000B8128: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000B812C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8134: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 0000000B8138: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000B8144: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8148: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000B814C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000B8154: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8158: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000B815C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000B8164: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000B8168: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8170: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000B8174: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000B8178: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8180: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000B8184: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000B8188: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8190: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000B8194: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000B819C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 0000000B81A4: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B81B0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000B81B4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000B81BC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000B81C8: DC9601E0 007C0200
	s_nop 0                                                    // 0000000B81D0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000000B81D4: BFB60003
	s_endpgm                                                   // 0000000B81D8: BFB00000
		...

